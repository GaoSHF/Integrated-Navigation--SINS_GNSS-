
% Position (rad), altitude (rad), angular velocity (rad/s), acceleration
% (m/s^2), T (s)
% height_switch: 1 -- height on, 0 -- height off
function [Qua_new, Ctb_new, la_new, lon_new, h_new, v_new, pitch_new, roll_new, yaw_new] = ...
    sins_strapdown(T, Qua_old, Ctb_old, la_old, lon_old, h_old, v_old, w, f, height_switch)

wie = 7.292115147e-5; % rad/s
Re = 6378245; % m
e = 1 / 298.3;
g0 = 9.7803267714; % m/s^2
gk1 = 0.00193185138639;
gk2 = 0.00669437999013;


w_ib_b = w; % rad/s
f_b = f; % m/s^2

Rm = Re / (1 +2 * e - 3 * e * sin(la_old)^2) + h_old;
Rn = Re / (1 - e * sin(la_old)^2) + h_old;


w_ie_t = ...
    [0;
    wie * cos(la_old);
    wie * sin(la_old)];
w_et_t = ...
    [-v_old(2, 1) / Rm;
    v_old(1, 1) / Rn;
    v_old(1, 1) / Rn * tan(la_old)];


f_t = Ctb_old' * f_b;

% north, east, up (m/s)
v_new(1, 1) = ...
    (f_t(1) + ...
    (2 * w_ie_t(3) + w_et_t(3)) * v_old(2, 1) - ...
    (2 * w_ie_t(2) + w_et_t(2)) * v_old(3, 1)) * ...
    T + v_old(1, 1);
v_new(2, 1) = ...
    (f_t(2) - ...
    (2 * w_ie_t(3) + w_et_t(3)) * v_old(1, 1) + ...
    (2 * w_ie_t(1) + w_et_t(1)) * v_old(3, 1)) * ...
    T + v_old(2, 1);

if height_switch == 1
    g = g0 * (1 + gk1 * (sin(la_old)) ^ 2) * ...
        (1 - 2 * h_old / Re) / ...
        sqrt(1 - gk2 * (sin(la_old)) ^ 2);
    v_new(3, 1) = ...
        (f_t(3) + ...
        (2 * w_ie_t(2) + w_et_t(2)) * v_old(1, 1) - ...
        (2 * w_ie_t(1) + w_et_t(1)) * v_old(2, 1) - g) * ...
        T + v_old(3, 1);
else
    v_new(3, 1) = v_old(3, 1);
end



la_new = v_new(2, 1) / Rm * T + la_old;
lon_new = v_new(1, 1) / (Rn * cos(la_new)) * T + lon_old;
h_new = v_new(3, 1) * T + h_old;


w_tb_b = w_ib_b - Ctb_old * (w_ie_t + w_et_t);

seita_delta = T * ...
[0          -w_tb_b(1)           -w_tb_b(2)         -w_tb_b(3);
w_tb_b(1)       0               w_tb_b(3)            -w_tb_b(2);
w_tb_b(2)    -w_tb_b(3)             0               w_tb_b(1)
w_tb_b(3)    w_tb_b(2)          -w_tb_b(1)              0];

seita_delta_zero = sqrt(seita_delta(1, 2) ^ 2 + ...
    seita_delta(1, 3) ^ 2 + ...
    seita_delta(1, 4) ^ 2);

Qua_new = (cos(seita_delta_zero / 2) * eye(4) + ...
    sin(seita_delta_zero / 2) / seita_delta_zero * seita_delta) * Qua_old;


Ctb_new = ...
[Qua_new(1) ^ 2 + Qua_new(2) ^ 2 - Qua_new(3) ^ 2 - Qua_new(4) ^ 2 ...
2 * (Qua_new(2) * Qua_new(3) + Qua_new(1) * Qua_new(4)) ...
2 * (Qua_new(2) * Qua_new(4) - Qua_new(1) * Qua_new(3));
2 * (Qua_new(2) * Qua_new(3) - Qua_new(1) * Qua_new(4)) ...
Qua_new(1) ^ 2 - Qua_new(2) ^ 2 + Qua_new(3) ^ 2 - Qua_new(4) ^ 2 ...
2 * (Qua_new(3) * Qua_new(4) + Qua_new(1) * Qua_new(2));
2 * (Qua_new(2) * Qua_new(4) + Qua_new(1) * Qua_new(3)) ...
2 * (Qua_new(3) * Qua_new(4) - Qua_new(1) * Qua_new(2)) ...
Qua_new(1) ^ 2 - Qua_new(2) ^ 2 - Qua_new(3) ^ 2 + Qua_new(4) ^ 2];


% Verhicle coordinate: x-y-z --> right-forward-up --> pitch-roll-yaw --> seita-gamma-kesai (rad) 
% Geographic coordinate: x-y-z --> east-north-up
pitch_new = asin(Ctb_new(2, 3)); % -pi/2 to pi/2

roll_new = -atan2(Ctb_new(1, 3), Ctb_new(3, 3)); % -pi to pi

yaw_new = atan2(Ctb_new(2, 1), Ctb_new(2, 2)); % 0 to 2*pi
if yaw_new < 0
    yaw_new = yaw_new + 2 * pi;
end


end % function


