% Position (rad), altitude (rad), angular velocity (rad/s), acceleration
% (m/s^2), T (s)
% height_switch: 1 -- height on, 0 -- height off
function [la_kf, lon_kf, h_kf, v_kf, pitch_kf, roll_kf, yaw_kf, time_kf, time_es, Xes, sqrtP, Phi_i, H_i, countObs] = ...
    kf_observability(la0, lon0, h0, ve0, vn0, vu0, pitch0, roll0, yaw0, ...
    dataIMU, dataGNSS, ...
    T_ins, T_kf, mx0, Cx0, Q, R, height_switch, Hinfinity_switch, T_obs)

% Observability related variables
Phi_i = zeros(15, 15, 1);
H_i = zeros(6, 15, 1);
countObs = 0;



% Maximum channel number
RECEIVER_CHANNEL = 10;

% Global definition
wie = 7.292115147e-5; % rad/s
Re = 6378245; % Earth radius, m
e = 1 / 298.3; % Earth eccentrity
g0 = 9.7803267714; % m/s^2
gk1 = 0.00193185138639;
gk2 = 0.00669437999013;

unit_degree2rad = (pi / 180); % degrees to rad


%%%%%%%%%%%%%%%%%%%% Import IMU data
%% IMU data
[lenIMU, ~] = size(dataIMU);

timeIMU = dataIMU( : , 1)'; % ms

wibbx = dataIMU( : , 8)' * unit_degree2rad; % degrees/s to rad/s
wibby = dataIMU( : , 9)' * unit_degree2rad;
wibbz = dataIMU( : , 10)' * unit_degree2rad;

fbx = dataIMU( : , 11)'; % m/s^2
fby = dataIMU( : , 12)';
fbz = dataIMU( : , 13)';

% Gyroscope data (rad/s)
w_ib_b = [wibbx; wibby; wibbz];
% Accelerometer data (m/s^2)
f_b = [fbx; fby; fbz];


%%%%%%%%%%%%%%%%%%%% Import GNSS data
[lenGNSS, ~] = size(dataGNSS);

timePPS = dataGNSS( : , 1)'; % ms
timeGNSS = dataGNSS( : , 2)'; % ms
RcvTime = dataGNSS( : , 3)';
fixQuality = dataGNSS( : , 4)';
svNumber = dataGNSS( : , 5)';

laGNSS = dataGNSS( : , 6)' * unit_degree2rad; % rad
lonGNSS = dataGNSS( : , 7)' * unit_degree2rad;
altGNSS = dataGNSS( : , 8)';
PDOP = dataGNSS( : , 9)';
pGNSS = dataGNSS( : , 10 : 12)';
vGNSS = dataGNSS( : , 13 : 15)';

channelNo = zeros(lenGNSS, 10)';
channelSNR = zeros(lenGNSS, 10)';
channelPseu = zeros(lenGNSS, 10)';
channelPseuRate = zeros(lenGNSS, 10)';
channelPx = zeros(lenGNSS, 10)';
channelPy = zeros(lenGNSS, 10)';
channelPz = zeros(lenGNSS, 10)';
channelVx = zeros(lenGNSS, 10)';
channelVy = zeros(lenGNSS, 10)';
channelVz = zeros(lenGNSS, 10)';
for i = 1 : RECEIVER_CHANNEL
    channelNo(i, : ) = dataGNSS( : , 16 + (i - 1) * 10)';
    channelSNR(i, : ) = dataGNSS( : , 17 + (i - 1) * 10)';
    channelPseu(i, : ) = dataGNSS( : , 18 + (i - 1) * 10)';
    channelPseuRate(i, : ) = dataGNSS( : , 19 + (i - 1) * 10)';
    channelPx(i, : ) = dataGNSS( : , 20 + (i - 1) * 10)';
    channelPy(i, : ) = dataGNSS( : , 21 + (i - 1) * 10)';
    channelPz(i, : ) = dataGNSS( : , 22 + (i - 1) * 10)';
    channelVx(i, : ) = dataGNSS( : , 23 + (i - 1) * 10)';
    channelVy(i, : ) = dataGNSS( : , 24 + (i - 1) * 10)';
    channelVz(i, : ) = dataGNSS( : , 25 + (i - 1) * 10)';
end



% data length
len_kf = length(timeIMU);
%len_kf = 1000;

%%%%%%%%%%%%%%%%%%%% Declaration of strapdown navigation parameter

% Velocity
v_kf = zeros(3, len_kf);
v_kf(1 : 3, 1) = [ve0; vn0; vu0];

% Geographical position
la_kf = zeros(1, len_kf); la_kf(1, 1) = la0;
lon_kf = zeros(1, len_kf); lon_kf(1, 1) = lon0;
h_kf = zeros(1, len_kf); h_kf(1, 1) = h0;

% Attitude
roll_kf = zeros(1, len_kf); roll_kf(1, 1) = roll0;
pitch_kf = zeros(1, len_kf); pitch_kf(1, 1) = pitch0;
yaw_kf = zeros(1, len_kf); yaw_kf(1, 1) = yaw0;



Qua = [0; 0; 0; 0];
Qua(1) = cos(yaw0 / 2) * cos(pitch0 / 2) * cos(roll0 / 2) + sin(yaw0 / 2) * sin(pitch0 / 2) * sin(roll0 / 2);
Qua(2) = cos(yaw0 / 2) * sin(pitch0 / 2) * cos(roll0 / 2) + sin(yaw0 / 2) * cos(pitch0 / 2) * sin(roll0 / 2);
Qua(3) = cos(yaw0 / 2) * cos(pitch0 / 2) * sin(roll0 / 2) - sin(yaw0 / 2) * sin(pitch0 / 2) * cos(roll0 / 2);
Qua(4) = cos(yaw0 / 2) * sin(pitch0 / 2) * sin(roll0 / 2) - sin(yaw0 / 2) * cos(pitch0 / 2) * cos(roll0 / 2);

Ctb = [Qua(1) ^ 2 + Qua(2) ^ 2 - Qua(3) ^ 2 - Qua(4) ^ 2,   2 * (Qua(2) * Qua(3) + Qua(1) * Qua(4)),    2 * (Qua(2) * Qua(4) - Qua(1) * Qua(3));
        2 * (Qua(2) * Qua(3) - Qua(1) * Qua(4)),            Qua(1)^2-Qua(2)^2+Qua(3)^2-Qua(4)^2,        2*(Qua(3)*Qua(4)+Qua(1)*Qua(2));
        2*(Qua(2)*Qua(4)+Qua(1)*Qua(3)),                    2*(Qua(3)*Qua(4)-Qua(1)*Qua(2)),            Qua(1)^2-Qua(2)^2-Qua(3)^2+Qua(4)^2];


%%%%%%%%%%%%%%%%%%%% Declaration of Kalman Filter parameter
% Xdot = F * X + G * W  -->     X(k+1) = Phi * X(k) + Ka * W
% Z = H * X + V         -->     Z(k) = H * X(k) + V


% Xes: Estimation of system state
% Element:  Tilt at east axis (Ctp, rad, from ideal navigation coordinate to platform coordinate / actual navigation coordinate)
%           Tilt at north axis
%           Tilt at up axis
%           Velocity error at east axis (m/s)
%           Velocity error at north axis
%           Velocity error at up axis
%           Latitude error (rad)
%           Longitude error
%           height error (m)
%           Gyroscope bias at east axis (rad/s)
%           Gyroscope bias at north axis
%           Gyroscope bias at up axis
%           Accelerometer bias at east axis (m^2/s)
%           Accelerometer bias at north axis
%           Accelerometer bias at up axis
Xes = zeros(15, 1);
P = zeros(15, 15, 1);


% Q: Variance of System noise W
% Element:	Gyroscope random error at east axis (rad/s)
%        	Gyroscope random error at north axis
%        	Gyroscope random error at up axis
%       	Acceleration random error at east axis (m/s^2)
%         	Acceleration random error at north axis
%        	Acceleration random error at up axis



% Z: Observation
% Element:  Velocity error at east axis (m/s)
%         	Velocity error at north axis
%           Velocity error at up axis
%           Latitude error (rad)
%         	Longitude error
%           Height error (m)
Z = zeros(6, 1);


% R: Observation noise variance
% Element:  Velocity observation noise at east axis (m/s)
%         	Velocity observation noise at north axis
%           Velocity observation noise at up axis
%           Latitude observation noise (rad)
%         	Longitude observation noise
%           Height observation noise (m)
 
 
%% Loose coupled Kalman Filter






% Initial condition
Xes( : , 1) = mx0;
P( : , : , 1) = Cx0;

time_es = zeros(1, 1);
time_kf = zeros(1, 1);
count_es = 0;
indexGNSS = 1;
flagSync = 0;
for count_kf = 1 : lenIMU - 1
    
    % Record time
    time_kf(count_kf) = timeIMU(count_kf);
    
    
    %%%%%%% Strapdown navigation algorithm 
    Rm = Re / (1 + 2 * e - 3 * e * sin(la_kf(1, count_kf))^2); % Radius of meridian plane
    Rn = Re / (1 - e * sin(la_kf(1, count_kf))^2); % Radius of prime vertical plane
    
    w_ie_t = [0; wie * cos(la_kf(1, count_kf)); wie * sin(la_kf(1, count_kf))];
    w_et_t = [-v_kf(2, count_kf) / (Rm + h_kf(1, count_kf)); 
                v_kf(1, count_kf) / (Rn + h_kf(1, count_kf)); 
                v_kf(1, count_kf) / (Rn + h_kf(1, count_kf)) * tan(la_kf(1, count_kf))];

    % Refresh velocity, E-N-U coordinate system
    f_t = Ctb' * f_b(:, count_kf);

    v_kf(1, count_kf + 1) = (f_t(1) + ...
                            (2 * w_ie_t(3) + w_et_t(3)) * v_kf(2, count_kf) - ...
                            (2 * w_ie_t(2) + w_et_t(2)) * v_kf(3, count_kf)) * ...
                            T_ins + v_kf(1, count_kf);
    v_kf(2, count_kf + 1) = (f_t(2) - ...
                            (2 * w_ie_t(3) + w_et_t(3)) * v_kf(1, count_kf) + ...
                            (2 * w_ie_t(1) + w_et_t(1)) * v_kf(3, count_kf)) * ...
                            T_ins + v_kf(2, count_kf);

    if height_switch == 1
        g = g0 * (1 + gk1 * (sin(la_kf(1, count_kf))) ^ 2) * (1 - 2 * h_kf(1, count_kf) / Re) / sqrt(1 - gk2 * (sin(la_kf(1, count_kf))) ^ 2);

        v_kf(3, count_kf + 1) = (f_t(3) + ...
                            (2 * w_ie_t(2) + w_et_t(2)) * v_kf(1, count_kf) - ...
                            (2 * w_ie_t(1) + w_et_t(1)) * v_kf(2, count_kf) - g) * ...
                            T_ins + v_kf(3, count_kf);
    else
        v_kf(3, count_kf + 1) = v_kf(3, count_kf);
    end

    % Location
    la_kf(1, count_kf + 1) = v_kf(2, count_kf + 1) / (Rm + h_kf(1, count_kf)) * T_ins + la_kf(1, count_kf);
    lon_kf(1, count_kf + 1) = v_kf(1, count_kf + 1) / ((Rn + h_kf(1, count_kf)) * cos(la_kf(1, count_kf))) * T_ins + lon_kf(1, count_kf);
    h_kf(1, count_kf + 1) = v_kf(3, count_kf + 1) * T_ins + h_kf(1, count_kf);

    % Refresh quaternion
    w_tb_b = w_ib_b(:, count_kf) - Ctb * (w_ie_t + w_et_t);

    seita_delta = T_ins * ...
                            [0          -w_tb_b(1)           -w_tb_b(2)         -w_tb_b(3);
                            w_tb_b(1)       0               w_tb_b(3)            -w_tb_b(2);
                            w_tb_b(2)    -w_tb_b(3)             0               w_tb_b(1)
                            w_tb_b(3)    w_tb_b(2)          -w_tb_b(1)              0];

    seita_delta_zero = sqrt(seita_delta(1, 2) ^ 2 + seita_delta(1, 3) ^ 2 + seita_delta(1, 4) ^ 2);

    Qua = (cos(seita_delta_zero / 2) * eye(4) + sin(seita_delta_zero / 2) / seita_delta_zero * seita_delta) * Qua;

    quaternionNorm = sqrt(Qua(1) ^ 2 + Qua(2) ^ 2 + Qua(3) ^ 2 + Qua(4) ^ 2);
    Qua = Qua / quaternionNorm;
    
    % Refresh Ctb
    Ctb = [Qua(1) ^ 2 + Qua(2) ^ 2 - Qua(3) ^ 2 - Qua(4) ^ 2,   2 * (Qua(2) * Qua(3) + Qua(1) * Qua(4)),    2 * (Qua(2) * Qua(4) - Qua(1) * Qua(3));
            2 * (Qua(2) * Qua(3) - Qua(1) * Qua(4)),            Qua(1)^2-Qua(2)^2+Qua(3)^2-Qua(4)^2,        2*(Qua(3)*Qua(4)+Qua(1)*Qua(2));
            2*(Qua(2)*Qua(4)+Qua(1)*Qua(3)),                    2*(Qua(3)*Qua(4)-Qua(1)*Qua(2)),            Qua(1)^2-Qua(2)^2-Qua(3)^2+Qua(4)^2];

        
    % Refresh attitude
    pitch_kf(1, count_kf + 1) = asin(Ctb(2, 3)); % -pi/2 to pi/2

    roll_kf(1, count_kf + 1) = atan2(-Ctb(1, 3), Ctb(3, 3)); % -pi to pi

    yaw_kf(1, count_kf + 1) = atan2(Ctb(2, 1), Ctb(2, 2)); % 0 to 2*pi
    if yaw_kf(1, count_kf + 1) < 0
        yaw_kf(1, count_kf + 1) = yaw_kf(1, count_kf + 1) + 2 * pi;
    end
    
    
    
    %%%%%%%% Kalman Filter
    if (indexGNSS > lenGNSS)
        flagSync = -1;
    else
        if flagSync == 0
            while timePPS(indexGNSS) < timeIMU(count_kf)
                indexGNSS = indexGNSS + 1;
                if indexGNSS > lenGNSS
                    flagSync = -1;
                    disp('Index of GNSS out of bound!');
                    break;
                end
            end
            if flagSync ~= -1
                flagSync = 1;
            end
        end
            
        % Seek PPS
        if flagSync == 1
            if (timePPS(indexGNSS) >= timeIMU(count_kf)) && (timePPS(indexGNSS) <= timeIMU(count_kf + 1))
                flagSync = 2;
                timeSync = timePPS(indexGNSS);
                
                laSync = (la_kf(1, count_kf + 1) - la_kf(1, count_kf)) / (timeIMU(1, count_kf + 1) - timeIMU(1, count_kf)) * (timeSync - timeIMU(1, count_kf)) + la_kf(1, count_kf);
                lonSync = (lon_kf(1, count_kf + 1) - lon_kf(1, count_kf)) / (timeIMU(1, count_kf + 1) - timeIMU(1, count_kf)) * (timeSync - timeIMU(1, count_kf)) + lon_kf(1, count_kf);
                altSync = (h_kf(1, count_kf + 1) - h_kf(1, count_kf)) / (timeIMU(1, count_kf + 1) - timeIMU(1, count_kf)) * (timeSync - timeIMU(1, count_kf)) + h_kf(1, count_kf);
                veSync = (v_kf(1, count_kf + 1) - v_kf(1, count_kf)) / (timeIMU(1, count_kf + 1) - timeIMU(1, count_kf)) * (timeSync - timeIMU(1, count_kf)) + v_kf(1, count_kf);
                vnSync = (v_kf(2, count_kf + 1) - v_kf(2, count_kf)) / (timeIMU(1, count_kf + 1) - timeIMU(1, count_kf)) * (timeSync - timeIMU(1, count_kf)) + v_kf(2, count_kf);
                vuSync = (v_kf(3, count_kf + 1) - v_kf(3, count_kf)) / (timeIMU(1, count_kf + 1) - timeIMU(1, count_kf)) * (timeSync - timeIMU(1, count_kf)) + v_kf(3, count_kf);
            else
                flagSync = 0;
            end
        end
        
        % Seek GNSS
        if flagSync == 2
        	if (timeGNSS(indexGNSS) >= timeIMU(count_kf)) && (timeGNSS(indexGNSS) <= timeIMU(count_kf + 1))
                flagSync = 3;
                
                laError = la_kf(1, count_kf + 1) - laSync;
                lonError = lon_kf(1, count_kf + 1) - lonSync;
                altError = h_kf(1, count_kf + 1) - altSync;
                veError = v_kf(1, count_kf + 1) - veSync;
                vnError = v_kf(2, count_kf + 1) - vnSync;
                vuError = v_kf(3, count_kf + 1) - vuSync;
            end
        end
        
    end

    
    if flagSync == 3
        if fixQuality(indexGNSS) ~= 0
        
        count_es = count_es + 1;

        ve = v_kf(1, count_kf + 1);
        vn = v_kf(2, count_kf + 1);
        vu = v_kf(3, count_kf + 1);
        la = la_kf(1, count_kf + 1);
        lon = lon_kf(1, count_kf + 1);
        h = h_kf(1, count_kf + 1);

        % Transfer GNSS velocity from E-N-U to X-Y-Z
        laGNSStemp = laGNSS(indexGNSS);
        lonGNSStemp = lonGNSS(indexGNSS);
        Cte = [cos(pi / 2 + lonGNSStemp),       -cos(pi / 2 - laGNSStemp) * sin(pi / 2 + lonGNSStemp),      sin(pi / 2 - laGNSStemp) * sin(pi / 2 + lonGNSStemp);
                sin(pi / 2 + lonGNSStemp),      cos(pi / 2 - laGNSStemp) * cos(pi / 2 + lonGNSStemp),       -sin(pi / 2 - laGNSStemp) * cos(pi / 2 + lonGNSStemp);
                0,                          sin(pi / 2 - laGNSStemp),                               cos(pi / 2 - laGNSStemp)];
        
        venuGNSS = Cte' * [vGNSS(1, indexGNSS); vGNSS(2, indexGNSS); vGNSS(3, indexGNSS)];
            
        veSyncGNSS = venuGNSS(1, 1) + veError;
        vnSyncGNSS = venuGNSS(2, 1) + vnError;
        vuSyncGNSS = venuGNSS(3, 1) + vuError;
        laSyncGNSS = laGNSS(indexGNSS) + laError;
        lonSyncGNSS = lonGNSS(indexGNSS) + lonError;
        altSyncGNSS = altGNSS(indexGNSS) + altError;
        
        Z( : , 1) = [ve - veSyncGNSS;
                    vn - vnSyncGNSS;
                    vu - vuSyncGNSS;
                    la - laSyncGNSS;
                    lon - lonSyncGNSS;
                    h - altSyncGNSS];
        
        F_NN = [0,      (wie * sin(la) + ve / (Rn + h) * tan(la)),       -(wie * cos(la) + ve / (Rn + h)), ...
                0,	    -(1 / (Rm + h)),	                                                         0, ...
                0,      0,                                                                   0;

               -(wie * sin(la) + ve / (Rn + h) * tan(la)),      0,        -vn / (Rm + h), ...
               1 / (Rn + h),                                                              0,        0, ...
               -wie * sin(la),                                              0,        0;

               (wie * cos(la) + ve / (Rn + h)),                              vn / (Rm + h),        0, ...
               1 / (Rn + h) * tan(la),                                               0,                      0, ...
               (wie * cos(la) + ve / (Rn + h) * sec(la) ^ 2),       0,                      0;


                0,                                                           -f_t(3),                                           f_t(2), ...
                (vn / (Rm + h) * tan(la) - vu / (Rm + h)),     (2 * wie * sin(la) + ve / (Rn + h) * tan(la)),     -(2 * wie * cos(la) + ve / (Rn + h)), ...
                (2 * wie * cos(la) * vn + ve * vn / (Rn + h) * sec(la) ^ 2 + 2 * wie * sin(la) * vu),      0,      ((ve * vu - ve * vn * tan(la)) / (Rn + h) / (Rn + h));

                f_t(3),                                 0,                                      -f_t(1), ...
                -2 * (wie * sin(la) + ve / (Rn + h) * tan(la)),        -vu / (Rm + h),        -vn / (Rm + h), ...
                -(2 * wie * cos(la) + ve / (Rn + h) * sec(la) ^ 2) * ve,        0,          ((ve * ve * tan(la) + ve * vu) / (Rm + h) / (Rn + h));

                -f_t(2),                                f_t(1),                                     0, ...
                -2 * (wie * cos(la) + ve / (Rn + h)),         0,              2 * vn / (Rm + h), ...
                -2 * wie * sin(la) * ve,             0,              -((ve * ve + vn * vn) / (Rm + h) / (Rn + h));


                0,                              0,                          0, ...
                0,                              1 / (Rm + h),                     0, ...
                0,                              0,                          -vn / (Rm + h) / (Rn + h);

                0,                              0,                          0, ...
                sec(la) / (Rn + h),                   0,                          0, ...
                ve / (Rn + h) * sec(la) * tan(la),    0,                          -ve * sec(la) / (Rm + h) / (Rn + h);

                0,                              0,                          0, ...
                0,                              0,                          1, ...
                0,                              0,                          0];


        F_NS = [Ctb', zeros(3, 3);

                zeros(3, 3), Ctb';

                0,      0,      0,      0,      0,      0;
                0,      0,      0,      0,      0,      0;
                0,      0,      0,      0,      0,      0];

        % One step transfer matrix for X
        F = [F_NN, F_NS; zeros(6, 9), zeros(6, 6)];

        Phi = eye(15) + F * T_kf;

        G = [zeros(3, 3),  	zeros(3, 3);
             zeros(3, 3),	zeros(3, 3);
             zeros(3, 3),   zeros(3, 3);
             eye(3),        zeros(3, 3);
             zeros(3, 3),   eye(3)];
        
        Ka = (eye(15) * T_kf + F * T_kf ^ 2 / 2) * G;
        

        % Observation matrix
        H = [zeros(3, 3),   eye(3),        zeros(3, 3),    zeros(3, 6);
             zeros(3, 3),   zeros(3, 3),    eye(3),          zeros(3, 6)];
         
         
        

        if Hinfinity_switch == 0
            % One step estimation
            XesOneStep = Phi * Xes( : , count_es);
            PesOneStep = Phi * P( : , : , count_es) * Phi' + Ka * Q * Ka';

            % Kalman gain
            K = PesOneStep * H' / (H * PesOneStep * H' + R);

            % Estimation
            Xes( : , count_es + 1) = XesOneStep + K * (Z( : , 1) - H * XesOneStep);
            
            P( : , : , count_es + 1) = (eye(15) - K * H) * PesOneStep * (eye(15) - K * H)' + K * R * K';
        else
            alphaHinf = 10;
            gammaSquare = alphaHinf * max(eig(eye(15) / (eye(15) / P( : , : , count_es) + H' * H)));
            %disp(['gammaSquare = ', num2str(gammaSquare)]);
            
            Lk = eye(15);
            
            Rek = [R, zeros(6, 15); zeros(15, 6), -gammaSquare * eye(15)] + [H; Lk] * P( : , : , count_es) * [H', Lk'];
            % Estimation Pes
            P( : , : , count_es + 1) = Phi * P( : , : , count_es) * Phi' + Ka * Q * Ka' - Phi * P( : , : , count_es) * [H', Lk'] / Rek * [H; Lk] * P( : , : , count_es) * Phi';
            
            % Kalman gain
            K = P( : , : , count_es + 1) * H' / (H * P( : , : , count_es + 1) * H' + R);
            % Estimation
            Xes( : , count_es + 1) = Phi * Xes( : , count_es) + K * (Z( : , 1) - H * Phi * Xes( : , count_es));
        end
        
        
        % Feedback correction
        if count_es > 0
            
            % fix attitude Euler matrix
            Ctc = [1,                               Xes(3, count_es + 1),                  -Xes(2, count_es + 1);
                   -Xes(3, count_es + 1),             1                                    Xes(1, count_es + 1);
                    Xes(2, count_es + 1),          -Xes(1, count_es + 1),                     1];
            Ctb = Ctb * Ctc;
            
            % fix attitude quaternion  
            Qua(1) = sqrt(abs(1 + Ctb(1, 1) + Ctb(2, 2) + Ctb(3, 3))) / 2;
            Qua(2) = sqrt(abs(1 + Ctb(1, 1) - Ctb(2, 2) - Ctb(3, 3))) / 2;
            Qua(3) = sqrt(abs(1 - Ctb(1, 1) + Ctb(2, 2) - Ctb(3, 3))) / 2;
            Qua(4) = sqrt(abs(1 - Ctb(1, 1) - Ctb(2, 2) + Ctb(3, 3))) / 2;

            if ((Ctb(2, 3) - Ctb(3, 2)) / (4 * Qua(1)) < 0)
                Qua(2) = -Qua(2);
            end
            if ((Ctb(3, 1) - Ctb(1, 3)) / (4 * Qua(1)) < 0)
                Qua(3) = -Qua(3);
            end
            if ((Ctb(1, 2) - Ctb(2, 1)) / (4 * Qua(1)) < 0)
                Qua(4) = -Qua(4);
            end
            

            % fix attitude
            pitch_kf(1, count_kf + 1) = asin(Ctb(2, 3)); % -pi/2 to pi/2

            roll_kf(1, count_kf + 1) = atan2(-Ctb(1, 3), Ctb(3, 3)); % -pi to pi

            yaw_kf(1, count_kf + 1) = atan2(Ctb(2, 1), Ctb(2, 2)); % 0 to 2*pi
            if yaw_kf(1, count_kf + 1) < 0
                yaw_kf(1, count_kf + 1) = yaw_kf(1, count_kf + 1) + 2 * pi;
            end
            

            % fix velocity and position
            v_kf(1, count_kf + 1) = ve - Xes(4, count_es + 1);
            v_kf(2, count_kf + 1) = vn - Xes(5, count_es + 1);
            v_kf(3, count_kf + 1) = vu - Xes(6, count_es + 1);

            la_kf(1, count_kf + 1) = la - Xes(7, count_es + 1);
            lon_kf(1, count_kf + 1) = lon - Xes(8, count_es + 1);
            h_kf(1, count_kf + 1) = h - Xes(9, count_es + 1);
            
            
            % fix IMU
            w_ib_b( : , count_kf + 1) = w_ib_b( : , count_kf + 1) - [Xes(10, count_es + 1); Xes(11, count_es + 1); Xes(12, count_es + 1)];
            f_b( : , count_kf + 1) = f_b( : , count_kf + 1) - [Xes(13, count_es + 1); Xes(14, count_es + 1); Xes(15, count_es + 1)];

        end % Correction
    
        time_es(count_es) = timeIMU(count_kf);
        
        indexGNSS = indexGNSS + 1;
        flagSync = 0;

        else
        indexGNSS = indexGNSS + 1; 
        flagSync = 0;
        end
        
        
        % Observability preparation
        if rem(count_es - 1, (T_obs / T_kf)) == 0
            countObs = countObs + 1;
            Phi_i( : , : , countObs) = zeros(15, 15);
            H_i( : , : , countObs) = zeros(6, 15);
        end
        Phi_i( : , : , countObs) = Phi_i( : , : , countObs) + Phi;
        H_i( : , : , countObs) = H_i( : , : , countObs) + H;
        
        
        
    end % if flagSync == 3
    
    
end

disp(['count_es = ', num2str(count_es)]);
disp(['countObs = ', num2str(countObs)]);


% Extraction of estimation variance
sqrtP = zeros(15, count_es);
[~, ~, len_temp3] = size(P);
for count = 1 : 1 : len_temp3
    sqrtP(1, count) = sqrt(P(1, 1, count));
    sqrtP(2, count) = sqrt(P(2, 2, count));
    sqrtP(3, count) = sqrt(P(3, 3, count));
    
    sqrtP(4, count) = sqrt(P(4, 4, count));
    sqrtP(5, count) = sqrt(P(5, 5, count));
    sqrtP(6, count) = sqrt(P(6, 6, count));
    
    sqrtP(7, count) = sqrt(P(7, 7, count));
    sqrtP(8, count) = sqrt(P(8, 8, count));
    sqrtP(9, count) = sqrt(P(9, 9, count));
    
    sqrtP(10, count) = sqrt(P(10, 10, count));
    sqrtP(11, count) = sqrt(P(11, 11, count));
    sqrtP(12, count) = sqrt(P(12, 12, count));
    
    sqrtP(13, count) = sqrt(P(13, 13, count));
    sqrtP(14, count) = sqrt(P(14, 14, count));
    sqrtP(15, count) = sqrt(P(15, 15, count));    
    
end


end % function

