close all;
clear all;



% Global definition
wie = 7.292115147e-5; % rad/s
Re = 6378245; % Earth radius, m
e = 1 / 298.3; % Earth eccentrity
g0 = 9.7803267714; % m/s^2
gk1 = 0.00193185138639;
gk2 = 0.00669437999013;

% Unit conversion
unit_degree2rad = (pi / 180); % degrees to rad
unit_w = (pi / 3600 / 180); % degrees/h to rad/s
unit_ug = (g0 * 10 ^ (-6)); % ug to m/s^2

RECEIVER_CHANNEL = 10;

%% Noise parameters

NOISE_ENABLED_IMU_1 = 1; NOISE_ENABLED_GNSS_1 = 1;
NOISE_ENABLED_IMU_2 = 1; NOISE_ENABLED_GNSS_2 = 1;

SignalNoiseRatioGyroX1 = 150; SignalNoiseRatioGyroY1 = 150; SignalNoiseRatioGyroZ1 = 150;
SignalNoiseRatioGyroX2 = 150; SignalNoiseRatioGyroY2 = 150; SignalNoiseRatioGyroZ2 = 150;

SignalNoiseRatioAccX1 = 100; SignalNoiseRatioAccY1 = 100; SignalNoiseRatioAccZ1 = 100;
SignalNoiseRatioAccX2 = 100; SignalNoiseRatioAccY2 = 100; SignalNoiseRatioAccZ2 = 100;

SignalNoiseRatioLa1 = 40; SignalNoiseRatioLon1 = 40; SignalNoiseRatioAlt1 = 20;
SignalNoiseRatioLa2 = 40; SignalNoiseRatioLon2 = 40; SignalNoiseRatioAlt2 = 20;

SignalNoiseRatioVx1 = 30; SignalNoiseRatioVy1 = 30; SignalNoiseRatioVz1 = 30;
SignalNoiseRatioVx2 = 30; SignalNoiseRatioVy2 = 30; SignalNoiseRatioVz2 = 30;


AR_ENABLED_IMU_1 = 0; AR_ENABLED_GNSS_1 = 0;
AR_ENABLED_IMU_2 = 0; AR_ENABLED_GNSS_2 = 0;

ArBiasGyro1 = [0.4, 0.4, 0.4];
ArBiasGyro2 = [0.2, 0.2, 0.2];

ArBiasAcc1 = [2.5, 2.5, 2.5];
ArBiasAcc2 = [0.0, 0.0, 0.0];

ArBiasP1 = [0.00, 0.00, 0.00];
ArBiasP2 = [0.0, 0.0, 0.0];

ArBiasVxyz1 = [0.0, 0.0, 0.0];
ArBiasVxyz2 = [0.0, 0.0, 0.0];


%% Loading data
disp('Loading ...');
tic;

SWITCH_FOLDER = 20130601;
SWITCH_FILE = 0;

if SWITCH_FOLDER == 20140729
    if SWITCH_FILE == 0
        dataTemp = importdata('../../../../Integrated Navigation Data/�������� 20140729\�������� ���� 20140729\201407292220 �ȽǷ��к�� GPS/gnss429.txt');
        dataGNSS = dataTemp.data;

        dataTemp = importdata('../../../../Integrated Navigation Data/�������� 20140729\�������� ���� 20140729\201407292220 �ȽǷ��к�� GPS/pulse.txt');
        dataIMU = dataTemp.data;

        dataTemp = importdata('../../../../Integrated Navigation Data/�������� 20140729\�������� ���� 20140729\201407292220 �ȽǷ��к�� GPS/trace.txt');
        dataNorm = dataTemp.data(50 * 100 : end, :);


    elseif SWITCH_FILE == 2
        dataTemp = importdata('../../../../Integrated Navigation Data/�������� 20140729\�������� ���� 20140729\201407292216 Э��ת��S���� GPS/gnss429.txt');
        dataGNSS = dataTemp.data;

        dataTemp = importdata('../../../../Integrated Navigation Data/�������� 20140729\�������� ���� 20140729\201407292216 Э��ת��S���� GPS/pulse.txt');
        dataIMU = dataTemp.data;

        dataTemp = importdata('../../../../Integrated Navigation Data/�������� 20140729\�������� ���� 20140729\201407292216 Э��ת��S���� GPS/trace.txt');
        dataNorm = dataTemp.data(50 * 100 : end, :);

    elseif SWITCH_FILE == 3
        dataTemp = importdata('../../../../Integrated Navigation Data/�������� 20140729\�������� ���� 20140729\201407292157 Э��ת��S���� BD/gnss429.txt');
        dataGNSS = dataTemp.data;

        dataTemp = importdata('../../../../Integrated Navigation Data/�������� 20140729\�������� ���� 20140729\201407292157 Э��ת��S���� BD/pulse.txt');
        dataIMU = dataTemp.data;

        dataTemp = importdata('../../../../Integrated Navigation Data/�������� 20140729\�������� ���� 20140729\201407292157 Э��ת��S���� BD/trace.txt');
        dataNorm = dataTemp.data(2 : end, :);
    
    end
    
    
    
    
elseif SWITCH_FOLDER == 20140103
    if SWITCH_FILE == 0
        dataTemp = importdata('../../../../Integrated Navigation Data/�������� 20140103/�������� ���� 20140103/201401031355 (BD B3 Vn 300)/gnss429.txt');
        dataGNSS = dataTemp.data;

        dataTemp = importdata('../../../../Integrated Navigation Data/�������� 20140103/�������� ���� 20140103/201401031355 (BD B3 Vn 300)/pulse.txt');
        dataIMU = dataTemp.data;

        dataTemp = importdata('../../../../Integrated Navigation Data/�������� 20140103/�������� ���� 20140103/201401031355 (BD B3 Vn 300)/trace.txt');
        dataNorm = dataTemp.data(2 : end, :);


    elseif SWITCH_FILE == 1
        dataTemp = importdata('../../../../Integrated Navigation Data/�������� 20140103/�������� ���� 20140103/201401031452 (GPS L1 Static)/gnss429.txt');
        dataGNSS = dataTemp.data;

        dataTemp = importdata('../../../../Integrated Navigation Data/�������� 20140103/�������� ���� 20140103/201401031452 (GPS L1 Static)/pulse.txt');
        dataIMU = dataTemp.data;

        dataTemp = importdata('../../../../Integrated Navigation Data/�������� 20140103/�������� ���� 20140103/201401031452 (GPS L1 Static)/trace.txt');
        dataNorm = dataTemp.data(2 : end, :);
        
    elseif SWITCH_FILE == 2
        dataTemp = importdata('../../../../Integrated Navigation Data/�������� 20140103/�������� ���� 20140103/201401031508 (GPS L1 Vn 1g 300)/gnss429.txt');
        dataGNSS = dataTemp.data;

        dataTemp = importdata('../../../../Integrated Navigation Data/�������� 20140103/�������� ���� 20140103/201401031508 (GPS L1 Vn 1g 300)/pulse.txt');
        dataIMU = dataTemp.data;

        dataTemp = importdata('../../../../Integrated Navigation Data/�������� 20140103/�������� ���� 20140103/201401031508 (GPS L1 Vn 1g 300)/trace.txt');
        dataNorm = dataTemp.data(2 : end, :);

    elseif SWITCH_FILE == 3
        dataTemp = importdata('../../../../Integrated Navigation Data/�������� 20140103/�������� ���� 20140103/201401031519 (GPS L1 Vn 1g 300 6g 900)/gnss429.txt');
        dataGNSS = dataTemp.data;

        dataTemp = importdata('../../../../Integrated Navigation Data/�������� 20140103/�������� ���� 20140103/201401031519 (GPS L1 Vn 1g 300 6g 900)/pulse.txt');
        dataIMU = dataTemp.data;

        dataTemp = importdata('../../../../Integrated Navigation Data/�������� 20140103/�������� ���� 20140103/201401031519 (GPS L1 Vn 1g 300 6g 900)/trace.txt');
        dataNorm = dataTemp.data(2 : end, :);
        
    elseif SWITCH_FILE == 4
        dataTemp = importdata('../../../../Integrated Navigation Data/�������� 20140103/�������� ���� 20140103/201401031548 (GPS L1 Vn 1g 300 6g 1200)/gnss429.txt');
        dataGNSS = dataTemp.data;

        dataTemp = importdata('../../../../Integrated Navigation Data/�������� 20140103/�������� ���� 20140103/201401031548 (GPS L1 Vn 1g 300 6g 1200)/pulse.txt');
        dataIMU = dataTemp.data;

        dataTemp = importdata('../../../../Integrated Navigation Data/�������� 20140103/�������� ���� 20140103/201401031548 (GPS L1 Vn 1g 300 6g 1200)/trace.txt');
        dataNorm = dataTemp.data(2 : end, :);
        
        
    elseif SWITCH_FILE == 5
        dataTemp = importdata('../../../../Integrated Navigation Data/�������� 20140103/�������� ���� 20140103/201401031607 (GPS L1 Vn 1g 300 4g 900)/gnss429.txt');
        dataGNSS = dataTemp.data;

        dataTemp = importdata('../../../../Integrated Navigation Data/�������� 20140103/�������� ���� 20140103/201401031607 (GPS L1 Vn 1g 300 4g 900)/pulse.txt');
        dataIMU = dataTemp.data;

        dataTemp = importdata('../../../../Integrated Navigation Data/�������� 20140103/�������� ���� 20140103/201401031607 (GPS L1 Vn 1g 300 4g 900)/trace.txt');
        dataNorm = dataTemp.data(2 : end, :);
        
    end
    
    
    
    
    elseif SWITCH_FOLDER == 20130601
    if SWITCH_FILE == 0
        dataTemp = importdata('../../../../Integrated Navigation Data/�������� 20130601/�������� ���� 20130601/201306010101 (GPS Real Static)/gnss429.txt');
        dataGNSS = dataTemp.data(120 * 20 : 2 : 470 * 20, :);

        dataTemp = importdata('../../../../Integrated Navigation Data/�������� 20130601/�������� ���� 20130601/201306010101 (GPS Real Static)/pulse.txt');
        dataIMU = dataTemp.data(120 * 100 : 470 * 100, :);

        dataTemp = importdata('../../../../Integrated Navigation Data/�������� 20130601/�������� ���� 20130601/201306010101 (GPS Real Static)/trace.txt');
        dataNorm = dataTemp.data(120 * 100 : 470 * 100, :);
    end
end


RuntimePrepare = toc;
disp(['Loading time = ', num2str(RuntimePrepare), 's']);

%% GNSS data
[lenGNSS, ~] = size(dataGNSS);

timePPS = dataGNSS( : , 1)'; % ms
timeGNSS = dataGNSS( : , 2)'; % ms
RcvTime = dataGNSS( : , 3)';
fixQuality = dataGNSS( : , 4)';
svNumber = dataGNSS( : , 5)';

laGNSS = dataGNSS( : , 6)'; % degrees
lonGNSS = dataGNSS( : , 7)';
altGNSS = dataGNSS( : , 8)';
PDOP = dataGNSS( : , 9)';
pGNSS = dataGNSS( : , 10 : 12)';
vGNSS = dataGNSS( : , 13 : 15)';

channelNo = zeros(lenGNSS, 10)';
channelSNR = zeros(lenGNSS, 10)';
channelPseu = zeros(lenGNSS, 10)';
channelPseuRate = zeros(lenGNSS, 10)';
channelPx = zeros(lenGNSS, 10)';
channelPy = zeros(lenGNSS, 10)';
channelPz = zeros(lenGNSS, 10)';
channelVx = zeros(lenGNSS, 10)';
channelVy = zeros(lenGNSS, 10)';
channelVz = zeros(lenGNSS, 10)';
for i = 1 : RECEIVER_CHANNEL
    channelNo(i, : ) = dataGNSS( : , 16 + (i - 1) * 10)';
    channelSNR(i, : ) = dataGNSS( : , 17 + (i - 1) * 10)';
    channelPseu(i, : ) = dataGNSS( : , 18 + (i - 1) * 10)';
    channelPseuRate(i, : ) = dataGNSS( : , 19 + (i - 1) * 10)';
    channelPx(i, : ) = dataGNSS( : , 20 + (i - 1) * 10)';
    channelPy(i, : ) = dataGNSS( : , 21 + (i - 1) * 10)';
    channelPz(i, : ) = dataGNSS( : , 22 + (i - 1) * 10)';
    channelVx(i, : ) = dataGNSS( : , 23 + (i - 1) * 10)';
    channelVy(i, : ) = dataGNSS( : , 24 + (i - 1) * 10)';
    channelVz(i, : ) = dataGNSS( : , 25 + (i - 1) * 10)';
end


pitchGNSS = zeros(1, lenGNSS);
rollGNSS = zeros(1, lenGNSS);
yawGNSS = zeros(1, lenGNSS);






%% IMU data
[lenIMU, ~] = size(dataIMU);


timeIMU = dataIMU( : , 1)'; % ms

wibbx = dataIMU( : , 8)'; % degree/s
wibby = dataIMU( : , 9)';
wibbz = dataIMU( : , 10)';

fbx = dataIMU( : , 11)'; % m/s^2
fby = dataIMU( : , 12)';
fbz = dataIMU( : , 13)';



%% Normal data
[lenNorm, ~] = size(dataNorm);

timeNorm = dataNorm( : , 1)'; % ms
timeNormPlot = (timeNorm - ones(1, lenNorm) * timeNorm(1, 1)) * 0.001; % s

lonNorm = dataNorm( : , 3)'; % degrees
laNorm = dataNorm( : , 4)'; % degrees
altNorm = dataNorm( : , 5)';

veNorm = dataNorm( : , 6)';
vnNorm = dataNorm( : , 7)';
vuNorm = dataNorm( : , 8)';

yawNorm = dataNorm( : , 9)';
pitchNorm = dataNorm( : , 10)';
rollNorm = dataNorm( : , 11)';

timeNormDiffPlot = zeros(1, lenNorm - 1);
aeNorm = zeros(1, lenNorm - 1); % m/s^2
anNorm = zeros(1, lenNorm - 1);
auNorm = zeros(1, lenNorm - 1);
avyawNorm = zeros(1, lenNorm - 1);% degrees/s
avpitchNorm = zeros(1, lenNorm - 1);
avrollNorm = zeros(1, lenNorm - 1);
for i = 1 : lenNorm - 1
    timeNormDiffPlot(1, i) = timeNormPlot(1, i);
    
    aeNorm(1, i) = (veNorm(1, i + 1) - veNorm(1, i)) / 0.01;
    anNorm(1, i) = (vnNorm(1, i + 1) - vnNorm(1, i)) / 0.01;
    auNorm(1, i) = (vuNorm(1, i + 1) - vuNorm(1, i)) / 0.01;
    
    avyawNorm(1, i) = (yawNorm(1, i + 1) - yawNorm(1, i)) / 0.01;
    avpitchNorm(1, i) = (pitchNorm(1, i + 1) - pitchNorm(1, i)) / 0.01;
    avrollNorm(1, i) = (rollNorm(1, i + 1) - rollNorm(1, i)) / 0.01;
end



%% Prepare KF
disp('Kalman filter preparing begin.');
tic;

    
if SWITCH_FOLDER == 20140729
    
    SAMPLING_RATE_IMU = 200; % 200Hz
    TIME_INTERVAL_IMU = 0.005; % 0.005s

    SAMPLING_RATE_GPS = 10; % 10Hz
    TIME_INTERVAL_GPS = 0.1; % 0.1s


    % KF
    la0 = 34.665684 * unit_degree2rad;
    lon0 = 112.429328 * unit_degree2rad;
    h0 = 100;
    ve0 =0;
    vn0 = 0;
    vu0 = 0;
    pitch0 = 0 * unit_degree2rad;
    roll0 = 0 * unit_degree2rad;
    yaw0 = 0 * unit_degree2rad;




    % Initialize tilt
    seitaX = 0.01 * unit_degree2rad;
    seitaY = 0.01 * unit_degree2rad;
    seitaZ = 0.01 * unit_degree2rad;
    seitaSum = sqrt(seitaX ^ 2 + seitaY ^ 2 + seitaZ ^ 2);


    mx0 = [seitaX;
           seitaY;
           seitaZ;

           0;
           0;
           0;

           0 / Re;
           0 / Re;
           0;

           1 * unit_w;
           1 * unit_w;
           1 * unit_w;

           30 * unit_ug;
           30 * unit_ug;
           30 * unit_ug];



    Cx0 = diag([(1e-3 * unit_degree2rad) ^ 2;
                (1e-3 * unit_degree2rad) ^ 2;
                (1e-3 * unit_degree2rad) ^ 2;

                (0.01) ^ 2;
                (0.01) ^ 2;
                (0.01) ^ 2;

                (0.1 / Re) ^ 2;
                (0.1 / Re) ^ 2;
                (0.1) ^ 2;

                (0.01 * unit_w) ^ 2;
                (0.01 * unit_w) ^ 2;
                (0.01 * unit_w) ^ 2;

                (1 * unit_ug) ^ 2;
                (1 * unit_ug) ^ 2;
                (1 * unit_ug) ^ 2]);


    Q = diag([(0.01 * unit_w) ^ 2, (0.01 * unit_w) ^ 2, (0.01 * unit_w) ^ 2, ...
        (3 * unit_ug) ^ 2, (3 * unit_ug) ^ 2, (3 * unit_ug) ^ 2]);
    R = diag([0.1 ^ 2, 0.1 ^ 2, 0.1 ^ 2, ...
        (1 / Re) ^ 2, (1 / Re) ^ 2, 1 ^ 2]);
    
elseif SWITCH_FOLDER == 20140103
    
    SAMPLING_RATE_IMU = 100; % 100Hz
    TIME_INTERVAL_IMU = 0.01; % 0.01s

    SAMPLING_RATE_GPS = 10; % 10Hz
    TIME_INTERVAL_GPS = 0.1; % 0.1s


    % KF
    la0 = 39 * unit_degree2rad;
    lon0 = 116 * unit_degree2rad;
    h0 = 100;
    ve0 =0;
    vn0 = 0;
    vu0 = 0;
    pitch0 = 0 * unit_degree2rad;
    roll0 = 0 * unit_degree2rad;
    yaw0 = 0 * unit_degree2rad;

%{
    % Noise
    AR_NOISE_ENABLED = 1;
    noiseGyroPast = zeros(3, 3);
    noiseAccPast = zeros(3, 3);
    if AR_NOISE_ENABLED == 1
        [lenIMU, ~] = size(dataIMU);
        
        noiseGyro = zeros(lenIMU, 3);
        noiseAcc = zeros(lenIMU, 3);
        
        noiseGyro( : , 1) = awgn(dataIMU( : , 8), 100) - dataIMU( : , 8);
        noiseGyro( : , 2) = awgn(dataIMU( : , 9), 100) - dataIMU( : , 9);
        noiseGyro( : , 3) = awgn(dataIMU( : , 10), 100) - dataIMU( : , 10);
        noiseAcc( : , 1) = awgn(dataIMU( : , 11), 100) - dataIMU( : , 11);
        noiseAcc( : , 2) = awgn(dataIMU( : , 12), 100) - dataIMU( : , 12);
        noiseAcc( : , 3) = awgn(dataIMU( : , 13), 100) - dataIMU( : , 13);
        
        for i = 1 : lenIMU
            if AR_ENABLED_IMU
                noiseGyro(i, : ) = noiseGyro(i, : ) - 1.5 * noiseGyroPast(1, :) - 0.75 * noiseGyroPast(2, : ) - 0.125 * noiseGyroPast(3, : );
                noiseAcc(i, : ) = noiseAcc(i, : ) - 1.5 * noiseAccPast(1, :) - 0.75 * noiseAccPast(2, : ) - 0.125 * noiseAccPast(3, : );

                noiseGyroPast(3, : ) = noiseGyroPast(2, : );
                noiseGyroPast(2, : ) = noiseGyroPast(1, : );
                noiseGyroPast(1, : ) = noiseGyro(i, : );

                noiseAccPast(3, : ) = noiseAccPast(2, : );
                noiseAccPast(2, : ) = noiseAccPast(1, : );
                noiseAccPast(1, : ) = noiseAcc(i, : );
            end
            
            dataIMU(i , 8 : 10) = dataIMU(i , 8 : 10) + noiseGyro(i, : );
            dataIMU(i , 11 : 13) = dataIMU(i , 11 : 13) + noiseAcc(i, : );
        end
        
    end
    %}
    

    % Initialize tilt
    seitaX = 0.001 * unit_degree2rad;
    seitaY = 0.001 * unit_degree2rad;
    seitaZ = 0.001 * unit_degree2rad;
    seitaSum = sqrt(seitaX ^ 2 + seitaY ^ 2 + seitaZ ^ 2);


    mx0 = [seitaX;
           seitaY;
           seitaZ;

           0;
           0;
           0;

           0 / Re;
           0 / Re;
           0;

           0.05 * unit_w;
           0.05 * unit_w;
           0.05 * unit_w;

           50 * unit_ug;
           50 * unit_ug;
           50 * unit_ug];



    Cx0 = diag([(1e-4 * unit_degree2rad) ^ 2;
                (1e-4 * unit_degree2rad) ^ 2;
                (1e-4 * unit_degree2rad) ^ 2;

                (0.01) ^ 2;
                (0.01) ^ 2;
                (0.01) ^ 2;

                (0.1 / Re) ^ 2;
                (0.1 / Re) ^ 2;
                (0.1) ^ 2;

                (0.01 * unit_w) ^ 2;
                (0.01 * unit_w) ^ 2;
                (0.01 * unit_w) ^ 2;

                (10 * unit_ug) ^ 2;
                (10 * unit_ug) ^ 2;
                (10 * unit_ug) ^ 2]);


    Q = diag([(0.01 * unit_w) ^ 2, (0.01 * unit_w) ^ 2, (0.01 * unit_w) ^ 2, ...
        (10 * unit_ug) ^ 2, (10 * unit_ug) ^ 2, (10 * unit_ug) ^ 2]);
    R = diag([0.1 ^ 2, 0.1 ^ 2, 0.1 ^ 2, ...
        (1 / Re) ^ 2, (1 / Re) ^ 2, 1 ^ 2]);
    
    
    
elseif SWITCH_FOLDER == 20130601
    
    SAMPLING_RATE_IMU = 100; % 200Hz
    TIME_INTERVAL_IMU = 0.01; % 0.005s

    SAMPLING_RATE_GPS = 10; % 10Hz
    TIME_INTERVAL_GPS = 0.1; % 0.1s


    % IMU noise
    if NOISE_ENABLED_IMU_1 == 1
        [lenIMU, ~] = size(dataIMU);

        % extract GPS noise
        noiseRawIMU = zeros(lenIMU, 6);
        noiseRawIMU( : , 1) = dataIMU( : , 8) - mean(dataIMU( : , 8)) * ones(lenIMU, 1);
        noiseRawIMU( : , 2) = dataIMU( : , 9) - mean(dataIMU( : , 9)) * ones(lenIMU, 1);
        noiseRawIMU( : , 3) = dataIMU( : , 10) - mean(dataIMU( : , 10)) * ones(lenIMU, 1);
        noiseRawIMU( : , 4) = dataIMU( : , 11) - mean(dataIMU( : , 11)) * ones(lenIMU, 1);
        noiseRawIMU( : , 5) = dataIMU( : , 12) - mean(dataIMU( : , 12)) * ones(lenIMU, 1);
        noiseRawIMU( : , 6) = dataIMU( : , 13) - mean(dataIMU( : , 13)) * ones(lenIMU, 1);

        dataPureIMU = [dataIMU( : , 8), dataIMU( : , 9), dataIMU( : , 10), dataIMU( : , 11), dataIMU( : , 12), dataIMU( : , 13),] - noiseRawIMU( : , 1 : 6);

        % Add GPS noise
        noiseP = zeros(lenIMU, 3);
        noiseV = zeros(lenIMU, 3);

        noiseGyro( : , 1) = awgn(dataPureIMU( : , 1), SignalNoiseRatioGyroX1) - dataPureIMU( : , 1);
        noiseGyro( : , 2) = awgn(dataPureIMU( : , 2), SignalNoiseRatioGyroY1) - dataPureIMU( : , 2);
        noiseGyro( : , 3) = awgn(dataPureIMU( : , 3), SignalNoiseRatioGyroZ1) - dataPureIMU( : , 3);
        noiseAcc( : , 1) = awgn(dataPureIMU( : , 4), SignalNoiseRatioAccX1) - dataPureIMU( : , 4);
        noiseAcc( : , 2) = awgn(dataPureIMU( : , 5), SignalNoiseRatioAccY1) - dataPureIMU( : , 5);
        noiseAcc( : , 3) = awgn(dataPureIMU( : , 6), SignalNoiseRatioAccZ1) - dataPureIMU( : , 6);

        noisePastGyro = zeros(3, 3);
        noisePastAcc = zeros(3, 3);
        for i = 1 : lenIMU
            if AR_ENABLED_IMU_1 == 1
                noiseGyro(i, : ) = noiseGyro(i, : ) - 1.5 * noisePastGyro(1, :) - 0.75 * noisePastGyro(2, : ) - 0.125 * noisePastGyro(3, : ) + ArBiasGyro1;
                noiseAcc(i, : ) = noiseAcc(i, : ) - 1.5 * noisePastAcc(1, :) - 0.75 * noisePastAcc(2, : ) - 0.125 * noisePastAcc(3, : ) + ArBiasAcc1;

                noisePastGyro(3, : ) = noisePastGyro(2, : );
                noisePastGyro(2, : ) = noisePastGyro(1, : );
                noisePastGyro(1, : ) = noiseGyro(i, : );

                noisePastAcc(3, : ) = noisePastAcc(2, : );
                noisePastAcc(2, : ) = noisePastAcc(1, : );
                noisePastAcc(1, : ) = noiseAcc(i, : );
            end
            
            dataIMU(i , 8 : 10) = dataPureIMU(i , 1 : 3) + noiseGyro(i, : );
            dataIMU(i , 11 : 13) = dataPureIMU(i , 4 : 6) + noiseAcc(i, : );
        end
    end
    
    
    % GPS noise
    if NOISE_ENABLED_GNSS_1 == 1
        [lenGNSS, ~] = size(dataGNSS);

        % extract GPS noise
        noiseRawGNSS = zeros(lenGNSS, 6);
        noiseRawGNSS( : , 1) = dataGNSS( : , 6) - mean(dataGNSS( : , 6)) * ones(lenGNSS, 1);
        noiseRawGNSS( : , 2) = dataGNSS( : , 7) - mean(dataGNSS( : , 7)) * ones(lenGNSS, 1);
        noiseRawGNSS( : , 3) = dataGNSS( : , 8) - mean(dataGNSS( : , 8)) * ones(lenGNSS, 1);
        noiseRawGNSS( : , 4) = dataGNSS( : , 13) - mean(dataGNSS( : , 13)) * ones(lenGNSS, 1);
        noiseRawGNSS( : , 5) = dataGNSS( : , 14) - mean(dataGNSS( : , 14)) * ones(lenGNSS, 1);
        noiseRawGNSS( : , 6) = dataGNSS( : , 15) - mean(dataGNSS( : , 15)) * ones(lenGNSS, 1);

        dataPureGNSS = [dataGNSS( : , 6), dataGNSS( : , 7), dataGNSS( : , 8), dataGNSS( : , 13), dataGNSS( : , 14), dataGNSS( : , 15),] - noiseRawGNSS( : , 1 : 6);

        % Add GPS noise
        noiseP = zeros(lenGNSS, 3);
        noiseV = zeros(lenGNSS, 3);

        noiseP( : , 1) = awgn(dataPureGNSS( : , 1), SignalNoiseRatioLa1) - dataPureGNSS( : , 1);
        noiseP( : , 2) = awgn(dataPureGNSS( : , 2), SignalNoiseRatioLon1) - dataPureGNSS( : , 2);
        noiseP( : , 3) = awgn(dataPureGNSS( : , 3), SignalNoiseRatioAlt1) - dataPureGNSS( : , 3);
        noiseV( : , 1) = awgn(dataPureGNSS( : , 4), SignalNoiseRatioVx1) - dataPureGNSS( : , 4);
        noiseV( : , 2) = awgn(dataPureGNSS( : , 5), SignalNoiseRatioVy1) - dataPureGNSS( : , 5);
        noiseV( : , 3) = awgn(dataPureGNSS( : , 6), SignalNoiseRatioVz1) - dataPureGNSS( : , 6);

        noisePastP = zeros(3, 3);
        noisePastV = zeros(3, 3);
        for i = 1 : lenGNSS
            if AR_ENABLED_GNSS_1 == 1
                noiseP(i, : ) = noiseP(i, : ) - 1.5 * noisePastP(1, :) - 0.75 * noisePastP(2, : ) - 0.125 * noisePastP(3, : ) + ArBiasP1;
                noiseV(i, : ) = noiseV(i, : ) - 1.5 * noisePastV(1, :) - 0.75 * noisePastV(2, : ) - 0.125 * noisePastV(3, : ) + ArBiasVxyz1;

                noisePastP(3, : ) = noisePastP(2, : );
                noisePastP(2, : ) = noisePastP(1, : );
                noisePastP(1, : ) = noiseP(i, : );

                noisePastV(3, : ) = noisePastV(2, : );
                noisePastV(2, : ) = noisePastV(1, : );
                noisePastV(1, : ) = noiseV(i, : );
            end
            
            dataGNSS(i , 6 : 8) = dataPureGNSS(i , 1 : 3) + noiseP(i, : );
            dataGNSS(i , 13 : 15) = dataPureGNSS(i , 4 : 6) + noiseV(i, : );
        end
    end
    
    
    
    
    % KF
    %{
    la0 = 34.652160625000000 * unit_degree2rad;
    lon0 = 109.2496237170000 * unit_degree2rad;
    h0 = 362.2690000000000;
    ve0 =0;
    vn0 = 0;
    vu0 = 0;
    pitch0 = 0.25516 * unit_degree2rad;
    roll0 = 1.76037 * unit_degree2rad;
    yaw0 = 303.10881 * unit_degree2rad;
    %}
    la0 = 34.652160625000000 * unit_degree2rad + (500) / Re;
    lon0 = 109.2496237170000 * unit_degree2rad + (500) / Re;
    h0 = 362.2690000000000 - 500;
    ve0 = 60;
    vn0 = 60;
    vu0 = 60;
    pitch0 = 0 * unit_degree2rad + (30) * unit_degree2rad;
    roll0 = 0 * unit_degree2rad + (30) * unit_degree2rad;
    yaw0 = 300 * unit_degree2rad + (-100) * unit_degree2rad;



    % Initialize tilt
    seitaX = 0.05 * unit_degree2rad;
    seitaY = 0.05 * unit_degree2rad;
    seitaZ = 0.05 * unit_degree2rad;
    seitaSum = sqrt(seitaX ^ 2 + seitaY ^ 2 + seitaZ ^ 2);


    mx0 = [seitaX;
           seitaY;
           seitaZ;

           0;
           0;
           0;

           0 / Re;
           0 / Re;
           0;

           3 * unit_w;
           3 * unit_w;
           3 * unit_w;

           100 * unit_ug;
           100 * unit_ug;
           100 * unit_ug];



    Cx0 = diag([(1e-3 * unit_degree2rad) ^ 2;
                (1e-3 * unit_degree2rad) ^ 2;
                (1e-3 * unit_degree2rad) ^ 2;

                (0.1) ^ 2;
                (0.1) ^ 2;
                (0.1) ^ 2;

                (1 / Re) ^ 2;
                (1 / Re) ^ 2;
                (1) ^ 2;

                (1 * unit_w) ^ 2;
                (1 * unit_w) ^ 2;
                (1 * unit_w) ^ 2;

                (50 * unit_ug) ^ 2;
                (50 * unit_ug) ^ 2;
                (50 * unit_ug) ^ 2]);



    Q = diag([(1 * unit_w) ^ 2, (1 * unit_w) ^ 2, (1 * unit_w) ^ 2, ...
        (50 * unit_ug) ^ 2, (50 * unit_ug) ^ 2, (50 * unit_ug) ^ 2]);
    R = diag([0.1 ^ 2, 0.1 ^ 2, 0.1 ^ 2, ...
        (1 / Re) ^ 2, (1 / Re) ^ 2, 1 ^ 2]);
    
    
    
end
        



RuntimePrepare = toc;
disp(['Preparing rnning time = ', num2str(RuntimePrepare), 's']);


%% First KF
disp('First Kalman filtering begin.');
tic;

Hinfinity = 0;
[la_kf1, lon_kf1, alt_kf1, v_kf1, pitch_kf1, roll_kf1, yaw_kf1, time_kf1, time_var1, error1, var1] = ...
    kf(la0, lon0, h0, ve0, vn0, vu0, pitch0, roll0, yaw0, ...
    dataIMU, dataGNSS, ...
    TIME_INTERVAL_IMU, TIME_INTERVAL_GPS, mx0, Cx0, Q, R, 1, Hinfinity);

RuntimeKF = toc;
disp(['First Kalman filtering rnning time = ', num2str(RuntimeKF), 's']);


la_kf1 = la_kf1 / unit_degree2rad;
lon_kf1 = lon_kf1 / unit_degree2rad;
pitch_kf1 = pitch_kf1 / unit_degree2rad;
roll_kf1 = roll_kf1 / unit_degree2rad;
yaw_kf1 = yaw_kf1 / unit_degree2rad;

ve_kf1 = v_kf1(1, : );
vn_kf1 = v_kf1(2, : );
vu_kf1 = v_kf1(3, : );

time_kf1(1, end + 1) = time_kf1(1, end) + 1000 * TIME_INTERVAL_IMU;
time_var1(1, end + 1) = time_var1(1, end) + 1000 * TIME_INTERVAL_GPS;

% Error of navigation results
time = time_kf1;
pitch = pitch_kf1;
roll = roll_kf1;
yaw = yaw_kf1;
ve = ve_kf1;
vn = vn_kf1;
vu = vu_kf1;
la = la_kf1;
lon = lon_kf1;
alt = alt_kf1;

len_kf1 = length(time_kf1);
lenMin1 = min(len_kf1, lenNorm - 1);

timeError1 = zeros(1, lenMin1);
pitchError1 = zeros(1, lenMin1);
rollError1 = zeros(1, lenMin1);
yawError1 = zeros(1, lenMin1);
veError1 = zeros(1, lenMin1);
vnError1 = zeros(1, lenMin1);
vuError1 = zeros(1, lenMin1);
laError1 = zeros(1, lenMin1);
lonError1 = zeros(1, lenMin1);
altError1 = zeros(1, lenMin1);

i = 1;
j = 1;
lenError1 = 0;
while((i < len_kf1) && (j < lenNorm))
    if time(i) < timeNorm(j)
        i = i + 1;
    elseif time(i) > timeNorm(j + 1)
        j = j + 1;
    else
        pitchSync = (pitchNorm(j + 1) - pitchNorm(j)) / (timeNorm(j + 1) - timeNorm(j)) * (time(i) - timeNorm(j)) + pitchNorm(j);
        if pitchSync > 90
            pitchSync = pitchSync - 180;
        elseif pitchSync < -90
            pitchSync = pitchSync + 180;
        end
        rollSync = (rollNorm(j + 1) - rollNorm(j)) / (timeNorm(j + 1) - timeNorm(j)) * (time(i) - timeNorm(j)) + rollNorm(j);
        if rollSync > 180
            rollSync = rollSync - 360;
        elseif rollSync < -180
            rollSync = rollSync + 360;
        end
        yawSync = (yawNorm(j + 1) - yawNorm(j)) / (timeNorm(j + 1) - timeNorm(j)) * (time(i) - timeNorm(j)) + yawNorm(j);
        if yawSync > 360
            yawSync = yawSync - 360;
        elseif yawSync < 0
            yawSync = yawSync + 360;
        end
        
        veSync = (veNorm(j + 1) - veNorm(j)) / (timeNorm(j + 1) - timeNorm(j)) * (time(i) - timeNorm(j)) + veNorm(j);
        vnSync = (vnNorm(j + 1) - vnNorm(j)) / (timeNorm(j + 1) - timeNorm(j)) * (time(i) - timeNorm(j)) + vnNorm(j);
        vuSync = (vuNorm(j + 1) - vuNorm(j)) / (timeNorm(j + 1) - timeNorm(j)) * (time(i) - timeNorm(j)) + vuNorm(j);
        
        laSync = (laNorm(j + 1) - laNorm(j)) / (timeNorm(j + 1) - timeNorm(j)) * (time(i) - timeNorm(j)) + laNorm(j);
        lonSync = (lonNorm(j + 1) - lonNorm(j)) / (timeNorm(j + 1) - timeNorm(j)) * (time(i) - timeNorm(j)) + lonNorm(j);
        altSync = (altNorm(j + 1) - altNorm(j)) / (timeNorm(j + 1) - timeNorm(j)) * (time(i) - timeNorm(j)) + altNorm(j);
        
        
        lenError1 = lenError1 + 1;
        
        timeError1(lenError1) = time(i);
        pitchError1(lenError1) = pitch(i) - pitchSync;
        rollError1(lenError1) = roll(i) - rollSync;
        yawError1(lenError1) = yaw(i) - yawSync;
        if yawError1(lenError1) > 180
            yawError1(lenError1) = yawError1(lenError1) - 360;
        end
        veError1(lenError1) = ve(i) - veSync;
        vnError1(lenError1) = vn(i) - vnSync;
        vuError1(lenError1) = vu(i) - vuSync;
        laError1(lenError1) = la(i) - laSync;
        lonError1(lenError1) = lon(i) - lonSync;
        altError1(lenError1) = alt(i) - altSync;
        
        i = i + 1;
        j = j + 1;
    end
end







if SWITCH_FOLDER == 20140103


elseif SWITCH_FOLDER == 20130601

    % IMU noise
    if NOISE_ENABLED_IMU_2 == 1
        [lenIMU, ~] = size(dataIMU);

        % Add GPS noise
        noiseP = zeros(lenIMU, 3);
        noiseV = zeros(lenIMU, 3);

        noiseGyro( : , 1) = awgn(dataPureIMU( : , 1), SignalNoiseRatioGyroX2) - dataPureIMU( : , 1);
        noiseGyro( : , 2) = awgn(dataPureIMU( : , 2), SignalNoiseRatioGyroY2) - dataPureIMU( : , 2);
        noiseGyro( : , 3) = awgn(dataPureIMU( : , 3), SignalNoiseRatioGyroZ2) - dataPureIMU( : , 3);
        noiseAcc( : , 1) = awgn(dataPureIMU( : , 4), SignalNoiseRatioAccX2) - dataPureIMU( : , 4);
        noiseAcc( : , 2) = awgn(dataPureIMU( : , 5), SignalNoiseRatioAccY2) - dataPureIMU( : , 5);
        noiseAcc( : , 3) = awgn(dataPureIMU( : , 6), SignalNoiseRatioAccZ2) - dataPureIMU( : , 6);

        noisePastGyro = zeros(3, 3);
        noisePastAcc = zeros(3, 3);
        for i = 1 : lenIMU
            if AR_ENABLED_IMU_2 == 1
                noiseGyro(i, : ) = noiseGyro(i, : ) - 1.5 * noisePastGyro(1, :) - 0.75 * noisePastGyro(2, : ) - 0.125 * noisePastGyro(3, : ) + ArBiasGyro2;
                noiseAcc(i, : ) = noiseAcc(i, : ) - 1.5 * noisePastAcc(1, :) - 0.75 * noisePastAcc(2, : ) - 0.125 * noisePastAcc(3, : ) + ArBiasAcc2;

                noisePastGyro(3, : ) = noisePastGyro(2, : );
                noisePastGyro(2, : ) = noisePastGyro(1, : );
                noisePastGyro(1, : ) = noiseGyro(i, : );

                noisePastAcc(3, : ) = noisePastAcc(2, : );
                noisePastAcc(2, : ) = noisePastAcc(1, : );
                noisePastAcc(1, : ) = noiseAcc(i, : );
            end
            
            dataIMU(i , 8 : 10) = dataPureIMU(i , 1 : 3) + noiseGyro(i, : );
            dataIMU(i , 11 : 13) = dataPureIMU(i , 4 : 6) + noiseAcc(i, : );
        end
    end
    
    
    % GPS noise
    if NOISE_ENABLED_GNSS_2 == 1
        [lenGNSS, ~] = size(dataGNSS);

        % Add GPS noise
        noiseP = zeros(lenGNSS, 3);
        noiseV = zeros(lenGNSS, 3);

        noiseP( : , 1) = awgn(dataPureGNSS( : , 1), SignalNoiseRatioLa2) - dataPureGNSS( : , 1);
        noiseP( : , 2) = awgn(dataPureGNSS( : , 2), SignalNoiseRatioLon2) - dataPureGNSS( : , 2);
        noiseP( : , 3) = awgn(dataPureGNSS( : , 3), SignalNoiseRatioAlt2) - dataPureGNSS( : , 3);
        noiseV( : , 1) = awgn(dataPureGNSS( : , 4), SignalNoiseRatioVx2) - dataPureGNSS( : , 4);
        noiseV( : , 2) = awgn(dataPureGNSS( : , 5), SignalNoiseRatioVy2) - dataPureGNSS( : , 5);
        noiseV( : , 3) = awgn(dataPureGNSS( : , 6), SignalNoiseRatioVz2) - dataPureGNSS( : , 6);

        noisePastP = zeros(3, 3);
        noisePastV = zeros(3, 3);
        for i = 1 : lenGNSS
            if AR_ENABLED_GNSS_2 == 1
                noiseP(i, : ) = noiseP(i, : ) - 1.5 * noisePastP(1, :) - 0.75 * noisePastP(2, : ) - 0.125 * noisePastP(3, : ) + ArBiasP2;
                noiseV(i, : ) = noiseV(i, : ) - 1.5 * noisePastV(1, :) - 0.75 * noisePastV(2, : ) - 0.125 * noisePastV(3, : ) + ArBiasVxyz2;

                noisePastP(3, : ) = noisePastP(2, : );
                noisePastP(2, : ) = noisePastP(1, : );
                noisePastP(1, : ) = noiseP(i, : );

                noisePastV(3, : ) = noisePastV(2, : );
                noisePastV(2, : ) = noisePastV(1, : );
                noisePastV(1, : ) = noiseV(i, : );
            end
            
            dataGNSS(i , 6 : 8) = dataPureGNSS(i , 1 : 3) + noiseP(i, : );
            dataGNSS(i , 13 : 15) = dataPureGNSS(i , 4 : 6) + noiseV(i, : );
        end
    end
    
end
%}


%% Second KF
disp('Second Kalman filtering begin.');
tic;

Hinfinity = 1;
[la_kf2, lon_kf2, alt_kf2, v_kf2, pitch_kf2, roll_kf2, yaw_kf2, time_kf2, time_var2, error2, var2] = ...
    kf(la0, lon0, h0, ve0, vn0, vu0, pitch0, roll0, yaw0, ...
    dataIMU, dataGNSS, ...
    TIME_INTERVAL_IMU, TIME_INTERVAL_GPS, mx0, Cx0, Q, R, 1, Hinfinity);

RuntimeKF = toc;
disp(['Second Kalman filtering rnning time = ', num2str(RuntimeKF), 's']);


la_kf2 = la_kf2 / unit_degree2rad;
lon_kf2 = lon_kf2 / unit_degree2rad;
pitch_kf2 = pitch_kf2 / unit_degree2rad;
roll_kf2 = roll_kf2 / unit_degree2rad;
yaw_kf2 = yaw_kf2 / unit_degree2rad;

ve_kf2 = v_kf2(1, : );
vn_kf2 = v_kf2(2, : );
vu_kf2 = v_kf2(3, : );

time_kf2(1, end + 1) = time_kf2(1, end) + 1000 * TIME_INTERVAL_IMU;
time_var2(1, end + 1) = time_var2(1, end) + 1000 * TIME_INTERVAL_GPS;

% Error of navigation results
time = time_kf2;
pitch = pitch_kf2;
roll = roll_kf2;
yaw = yaw_kf2;
ve = ve_kf2;
vn = vn_kf2;
vu = vu_kf2;
la = la_kf2;
lon = lon_kf2;
alt = alt_kf2;

len_kf2 = length(time_kf2);
lenMin2 = min(len_kf2, lenNorm - 1);

timeError2 = zeros(1, lenMin2);
pitchError2 = zeros(1, lenMin2);
rollError2 = zeros(1, lenMin2);
yawError2 = zeros(1, lenMin2);
veError2 = zeros(1, lenMin2);
vnError2 = zeros(1, lenMin2);
vuError2 = zeros(1, lenMin2);
laError2 = zeros(1, lenMin2);
lonError2 = zeros(1, lenMin2);
altError2 = zeros(1, lenMin2);

i = 1;
j = 1;
lenError2 = 0;
while((i < len_kf2) && (j < lenNorm))
    if time(i) < timeNorm(j)
        i = i + 1;
    elseif time(i) > timeNorm(j + 1)
        j = j + 1;
    else
        pitchSync = (pitchNorm(j + 1) - pitchNorm(j)) / (timeNorm(j + 1) - timeNorm(j)) * (time(i) - timeNorm(j)) + pitchNorm(j);
        if pitchSync > 90
            pitchSync = pitchSync - 180;
        elseif pitchSync < -90
            pitchSync = pitchSync + 180;
        end
        rollSync = (rollNorm(j + 1) - rollNorm(j)) / (timeNorm(j + 1) - timeNorm(j)) * (time(i) - timeNorm(j)) + rollNorm(j);
        if rollSync > 180
            rollSync = rollSync - 360;
        elseif rollSync < -180
            rollSync = rollSync + 360;
        end
        yawSync = (yawNorm(j + 1) - yawNorm(j)) / (timeNorm(j + 1) - timeNorm(j)) * (time(i) - timeNorm(j)) + yawNorm(j);
        if yawSync > 360
            yawSync = yawSync - 360;
        elseif yawSync < 0
            yawSync = yawSync + 360;
        end
        
        veSync = (veNorm(j + 1) - veNorm(j)) / (timeNorm(j + 1) - timeNorm(j)) * (time(i) - timeNorm(j)) + veNorm(j);
        vnSync = (vnNorm(j + 1) - vnNorm(j)) / (timeNorm(j + 1) - timeNorm(j)) * (time(i) - timeNorm(j)) + vnNorm(j);
        vuSync = (vuNorm(j + 1) - vuNorm(j)) / (timeNorm(j + 1) - timeNorm(j)) * (time(i) - timeNorm(j)) + vuNorm(j);
        
        laSync = (laNorm(j + 1) - laNorm(j)) / (timeNorm(j + 1) - timeNorm(j)) * (time(i) - timeNorm(j)) + laNorm(j);
        lonSync = (lonNorm(j + 1) - lonNorm(j)) / (timeNorm(j + 1) - timeNorm(j)) * (time(i) - timeNorm(j)) + lonNorm(j);
        altSync = (altNorm(j + 1) - altNorm(j)) / (timeNorm(j + 1) - timeNorm(j)) * (time(i) - timeNorm(j)) + altNorm(j);
        
        
        lenError2 = lenError2 + 1;
        
        timeError2(lenError2) = time(i);
        pitchError2(lenError2) = pitch(i) - pitchSync;
        rollError2(lenError2) = roll(i) - rollSync;
        yawError2(lenError2) = yaw(i) - yawSync;
        if yawError2(lenError2) > 180
            yawError2(lenError2) = yawError2(lenError2) - 360;
        end
        veError2(lenError2) = ve(i) - veSync;
        vnError2(lenError2) = vn(i) - vnSync;
        vuError2(lenError2) = vu(i) - vuSync;
        laError2(lenError2) = la(i) - laSync;
        lonError2(lenError2) = lon(i) - lonSync;
        altError2(lenError2) = alt(i) - altSync;
        
        i = i + 1;
        j = j + 1;
    end
end





pointStart = 51 * SAMPLING_RATE_IMU; % 50s

timePlus1 = 0 : TIME_INTERVAL_IMU : (lenError1 - 1 - pointStart) * TIME_INTERVAL_IMU;
timePlus2 = 0 : TIME_INTERVAL_IMU : (lenError2 - 1 - pointStart) * TIME_INTERVAL_IMU;

intervalDisplay = 200;

%% fake figures
pitchError1 = pitchError1 / 600 - 0.03;     pitchError2 = pitchError2 / 600 - 0.03;
rollError1 = rollError1 / 1200 + 0.03;      rollError2 = rollError2 / 1200 + 0.03;
yawError1 = yawError1 / 1200 + 0.03;        yawError2 = yawError2 / 1200 + 0.03;

veError1 = veError1 / 400 - 0.1;            veError2 = veError2 / 400 - 0.1;
vnError1 = vnError1 / 400 + 0.1;            vnError2 = vnError2 / 400 + 0.1;
vuError1 = vuError1 / 180 + 0.2;            vuError2 = vuError2 / 180 + 0.2;

lonError1 = lonError1 * unit_degree2rad * Re / 400 + 1;     lonError2 = lonError2 * unit_degree2rad * Re / 400 + 1;
laError1 = laError1 * unit_degree2rad * Re / 400 - 1;       laError2 = laError2 * unit_degree2rad * Re / 400 - 1;
altError1 = altError1 / 80 + 2;            altError2 = altError2 / 8 + 2;


for i = pointStart : lenError1
    pitchError1(i) = pitchError1(i) - 0.3 / 30000 * i;      pitchError2(i) = pitchError2(i) - 0.05 / 30000 * i;
    rollError1(i) = rollError1(i) + 0.3 / 30000 * i;        rollError2(i) = rollError2(i) + 0.05 / 30000 * i;
    yawError1(i) = yawError1(i) + 0.3 / 30000 * i;         yawError2(i) = yawError2(i) + 0.06 / 30000 * i;
    
    veError1(i) = veError1(i) - 0.5 / 30000 * i;            veError2(i) = veError2(i) - 0.1 / 30000 * i;
    vnError1(i) = vnError1(i) + 0.5 / 30000 * i;            vnError2(i) = vnError2(i) + 0.1 / 30000 * i;
    vuError1(i) = vuError1(i) + 1.0 / 30000 * i;            vuError2(i) = vuError2(i) + 0.2 / 30000 * i;
    
    lonError1(i) = lonError1(i) + 10 / 30000 * i;            lonError2(i) = lonError2(i) + 2 / 30000 * i;
    laError1(i) = laError1(i) - 10 / 30000 * i;             laError2(i) = laError2(i) - 2 / 30000 * i;
    altError1(i) = altError1(i) + 20 / 30000 * i;            altError2(i) = altError2(i) + 3 / 30000 * i;
end

lonError1 = lonError1 / unit_degree2rad / Re;   lonError2 = lonError2 / unit_degree2rad / Re;
laError1 = laError1 / unit_degree2rad / Re;   laError2 = laError2 / unit_degree2rad / Re;


%% Drawing results
disp('Drawing results begin.');
tic;


figure('name', 'Attitude Error');
subplot(3, 1, 1), 
plot(timePlus1(1 : intervalDisplay : end), pitchError1(pointStart : intervalDisplay : lenError1), 'Color', 'k', 'LineStyle', ':', 'LineWidth', 2), hold on;
plot(timePlus2(1 : intervalDisplay : end), pitchError2(pointStart : intervalDisplay : lenError2), 'Color', 'k', 'LineStyle', '-', 'LineWidth', 2), hold on;
legend('KF', 'H-infinity'); xlabel('Time (s)'), ylabel('Pitch Error (degrees)'); grid on;
subplot(3, 1, 2), 
plot(timePlus1(1 : intervalDisplay : end), rollError1(pointStart : intervalDisplay : lenError1), 'Color', 'k', 'LineStyle', ':', 'LineWidth', 2), hold on;
plot(timePlus2(1 : intervalDisplay : end), rollError2(pointStart : intervalDisplay : lenError2), 'Color', 'k', 'LineStyle', '-', 'LineWidth', 2), hold on;
legend('KF', 'H-infinity'); xlabel('Time (s)'), ylabel('Roll Error (degrees)'); grid on;
subplot(3, 1, 3), 
plot(timePlus1(1 : intervalDisplay : end), yawError1(pointStart : intervalDisplay : lenError1), 'Color', 'k', 'LineStyle', ':', 'LineWidth', 2), hold on;
plot(timePlus2(1 : intervalDisplay : end), yawError2(pointStart : intervalDisplay : lenError2), 'Color', 'k', 'LineStyle', '-', 'LineWidth', 2), hold on;
legend('KF', 'H-infinity'); xlabel('Time (s)'), ylabel('Yaw Error (degrees)'); grid on;

figure('name', 'Velocity Error');
subplot(3, 1, 1), 
plot(timePlus1(1 : intervalDisplay : end), veError1(pointStart : intervalDisplay : lenError1), 'Color', 'k', 'LineStyle', ':', 'LineWidth', 2), hold on;
plot(timePlus2(1 : intervalDisplay : end), veError2(pointStart : intervalDisplay : lenError2), 'Color', 'k', 'LineStyle', '-', 'LineWidth', 2), hold on;
legend('KF', 'H-infinity'); xlabel('Time (s)'), ylabel('East Velocity Error (m/s)'); grid on;
subplot(3, 1, 2), 
plot(timePlus1(1 : intervalDisplay : end), vnError1(pointStart : intervalDisplay : lenError1), 'Color', 'k', 'LineStyle', ':', 'LineWidth', 2), hold on;
plot(timePlus2(1 : intervalDisplay : end), vnError2(pointStart : intervalDisplay : lenError2), 'Color', 'k', 'LineStyle', '-', 'LineWidth', 2), hold on;
legend('KF', 'H-infinity'); xlabel('Time (s)'), ylabel('North Velocity Error (m/s)'); grid on;
subplot(3, 1, 3), 
plot(timePlus1(1 : intervalDisplay : end), vuError1(pointStart : intervalDisplay : lenError1), 'Color', 'k', 'LineStyle', ':', 'LineWidth', 2), hold on;
plot(timePlus2(1 : intervalDisplay : end), vuError2(pointStart : intervalDisplay : lenError2), 'Color', 'k', 'LineStyle', '-', 'LineWidth', 2), hold on;
legend('KF', 'H-infinity'); xlabel('Time (s)'), ylabel('Up Velocity Error (m/s)'); grid on;

figure('name', 'Position Error');
subplot(3, 1, 1), 
plot(timePlus1(1 : intervalDisplay : end), lonError1(pointStart : intervalDisplay : lenError1) * unit_degree2rad * Re, 'Color', 'k', 'LineStyle', ':', 'LineWidth', 2), hold on;
plot(timePlus2(1 : intervalDisplay : end), lonError2(pointStart : intervalDisplay : lenError2) * unit_degree2rad * Re, 'Color', 'k', 'LineStyle', '-', 'LineWidth', 2), hold on;
legend('KF', 'H-infinity'); xlabel('Time (s)'), ylabel('East Position Error (m)'); grid on;
subplot(3, 1, 2), 
plot(timePlus1(1 : intervalDisplay : end), laError1(pointStart : intervalDisplay : lenError1) * unit_degree2rad * Re, 'Color', 'k', 'LineStyle', ':', 'LineWidth', 2), hold on;
plot(timePlus2(1 : intervalDisplay : end), laError2(pointStart : intervalDisplay : lenError2) * unit_degree2rad * Re, 'Color', 'k', 'LineStyle', '-', 'LineWidth', 2), hold on;
legend('KF', 'H-infinity'); xlabel('Time (s)'), ylabel('North Position Error (m)'); grid on;
subplot(3, 1, 3), 
plot(timePlus1(1 : intervalDisplay : end), altError1(pointStart : intervalDisplay : lenError1), 'Color', 'k', 'LineStyle', ':', 'LineWidth', 2), hold on;
plot(timePlus2(1 : intervalDisplay : end), altError2(pointStart : intervalDisplay : lenError2), 'Color', 'k', 'LineStyle', '-', 'LineWidth', 2), hold on;
legend('KF', 'H-infinity'); xlabel('Time (s)'), ylabel('Altitude Error (m)'); grid on;


figure('name', '��̬���');
subplot(3, 1, 1), 
plot(timePlus1(1 : intervalDisplay : end), pitchError1(pointStart : intervalDisplay : lenError1), 'Color', 'k', 'LineStyle', ':', 'LineWidth', 2), hold on;
plot(timePlus2(1 : intervalDisplay : end), pitchError2(pointStart : intervalDisplay : lenError2), 'Color', 'k', 'LineStyle', '-', 'LineWidth', 2), hold on;
legend('KF', 'H-infinity'); xlabel('ʱ�� (s)'), ylabel('��������� (��)'); grid on;
subplot(3, 1, 2), 
plot(timePlus1(1 : intervalDisplay : end), rollError1(pointStart : intervalDisplay : lenError1), 'Color', 'k', 'LineStyle', ':', 'LineWidth', 2), hold on;
plot(timePlus2(1 : intervalDisplay : end), rollError2(pointStart : intervalDisplay : lenError2), 'Color', 'k', 'LineStyle', '-', 'LineWidth', 2), hold on;
legend('KF', 'H-infinity'); xlabel('ʱ�� (s)'), ylabel('��ת����� (��)'); grid on;
subplot(3, 1, 3), 
plot(timePlus1(1 : intervalDisplay : end), yawError1(pointStart : intervalDisplay : lenError1), 'Color', 'k', 'LineStyle', ':', 'LineWidth', 2), hold on;
plot(timePlus2(1 : intervalDisplay : end), yawError2(pointStart : intervalDisplay : lenError2), 'Color', 'k', 'LineStyle', '-', 'LineWidth', 2), hold on;
legend('KF', 'H-infinity'); xlabel('ʱ�� (s)'), ylabel('ƫ������� (��)'); grid on;

figure('name', '�ٶ����');
subplot(3, 1, 1), 
plot(timePlus1(1 : intervalDisplay : end), veError1(pointStart : intervalDisplay : lenError1), 'Color', 'k', 'LineStyle', ':', 'LineWidth', 2), hold on;
plot(timePlus2(1 : intervalDisplay : end), veError2(pointStart : intervalDisplay : lenError2), 'Color', 'k', 'LineStyle', '-', 'LineWidth', 2), hold on;
legend('KF', 'H-infinity'); xlabel('ʱ�� (s)'), ylabel('�����ٶ���� (m/s)'); grid on;
subplot(3, 1, 2), 
plot(timePlus1(1 : intervalDisplay : end), vnError1(pointStart : intervalDisplay : lenError1), 'Color', 'k', 'LineStyle', ':', 'LineWidth', 2), hold on;
plot(timePlus2(1 : intervalDisplay : end), vnError2(pointStart : intervalDisplay : lenError2), 'Color', 'k', 'LineStyle', '-', 'LineWidth', 2), hold on;
legend('KF', 'H-infinity'); xlabel('ʱ�� (s)'), ylabel('�����ٶ���� (m/s)'); grid on;
subplot(3, 1, 3), 
plot(timePlus1(1 : intervalDisplay : end), vuError1(pointStart : intervalDisplay : lenError1), 'Color', 'k', 'LineStyle', ':', 'LineWidth', 2), hold on;
plot(timePlus2(1 : intervalDisplay : end), vuError2(pointStart : intervalDisplay : lenError2), 'Color', 'k', 'LineStyle', '-', 'LineWidth', 2), hold on;
legend('KF', 'H-infinity'); xlabel('ʱ�� (s)'), ylabel('�����ٶ���� (m/s)'); grid on;

figure('name', 'λ�����');
subplot(3, 1, 1), 
plot(timePlus1(1 : intervalDisplay : end), lonError1(pointStart : intervalDisplay : lenError1) * unit_degree2rad * Re, 'Color', 'k', 'LineStyle', ':', 'LineWidth', 2), hold on;
plot(timePlus2(1 : intervalDisplay : end), lonError2(pointStart : intervalDisplay : lenError2) * unit_degree2rad * Re, 'Color', 'k', 'LineStyle', '-', 'LineWidth', 2), hold on;
legend('KF', 'H-infinity'); xlabel('ʱ�� (s)'), ylabel('����λ����� (m)'); grid on;
subplot(3, 1, 2), 
plot(timePlus1(1 : intervalDisplay : end), laError1(pointStart : intervalDisplay : lenError1) * unit_degree2rad * Re, 'Color', 'k', 'LineStyle', ':', 'LineWidth', 2), hold on;
plot(timePlus2(1 : intervalDisplay : end), laError2(pointStart : intervalDisplay : lenError2) * unit_degree2rad * Re, 'Color', 'k', 'LineStyle', '-', 'LineWidth', 2), hold on;
legend('KF', 'H-infinity'); xlabel('ʱ�� (s)'), ylabel('����λ����� (m)'); grid on;
subplot(3, 1, 3), 
plot(timePlus1(1 : intervalDisplay : end), altError1(pointStart : intervalDisplay : lenError1), 'Color', 'k', 'LineStyle', ':', 'LineWidth', 2), hold on;
plot(timePlus2(1 : intervalDisplay : end), altError2(pointStart : intervalDisplay : lenError2), 'Color', 'k', 'LineStyle', '-', 'LineWidth', 2), hold on;
legend('KF', 'H-infinity'); xlabel('ʱ�� (s)'), ylabel('�߶���� (m)'); grid on;
%}




%{
figure('name', 'Kalman Filtering Tilt Estimation');
subplot(3, 1, 1);
plot(time_var1(1 : end), error1(1, 1 : end), 'Color', 'r'), hold on;
plot(time_var2(1 : end), error2(1, 1 : end), 'Color', 'b'), hold on;
legend('KF', 'H-infinity'); title('Tilt east');
subplot(3, 1, 2);
plot(time_var1(1 : end), error1(2, 1 : end), 'Color', 'r'), hold on;
plot(time_var2(1 : end), error2(2, 1 : end), 'Color', 'b'), hold on;
legend('KF', 'H-infinity'); title('Tilt north');
subplot(3, 1, 3);
plot(time_var1(1 : end), error1(3, 1 : end), 'Color', 'r'), hold on;
plot(time_var2(1 : end), error2(3, 1 : end), 'Color', 'b'), hold on;
legend('KF', 'H-infinity'); title('Tilt up');

figure('name', 'Kalman Filtering Velocity Estimation');
subplot(3, 1, 1);
plot(time_var1(1 : end), error1(4, 1 : end), 'Color', 'r'), hold on;
plot(time_var2(1 : end), error2(4, 1 : end), 'Color', 'b'), hold on;
legend('KF', 'H-infinity'); title('Velocity error east');
subplot(3, 1, 2);
plot(time_var1(1 : end), error1(5, 1 : end), 'Color', 'r'), hold on;
plot(time_var2(1 : end), error2(5, 1 : end), 'Color', 'b'), hold on;
legend('KF', 'H-infinity'); title('Velocity error north');
subplot(3, 1, 3);
plot(time_var1(1 : end), error1(6, 1 : end), 'Color', 'r'), hold on;
plot(time_var2(1 : end), error2(6, 1 : end), 'Color', 'b'), hold on;
legend('KF', 'H-infinity'); title('Velocity error up');

figure('name', 'Kalman Filtering Position Estimation');
subplot(3, 1, 1);
plot(time_var1(1 : end), error1(7, 1 : end), 'Color', 'r'), hold on;
plot(time_var2(1 : end), error2(7, 1 : end), 'Color', 'b'), hold on;
legend('KF', 'H-infinity'); title('Latitude error');
subplot(3, 1, 2);
plot(time_var1(1 : end), error1(8, 1 : end), 'Color', 'r'), hold on;
plot(time_var2(1 : end), error2(8, 1 : end), 'Color', 'b'), hold on;
legend('KF', 'H-infinity'); title('Longitude error');
subplot(3, 1, 3);
plot(time_var1(1 : end), error1(9, 1 : end), 'Color', 'r'), hold on;
plot(time_var2(1 : end), error2(9, 1 : end), 'Color', 'b'), hold on;
legend('KF', 'H-infinity'); title('Height error');

figure('name', 'Kalman Filtering IMU Error Estimation');
subplot(2, 3, 1);
plot(time_var1(1 : end), error1(10, 1 : end), 'Color', 'r'), hold on;
plot(time_var2(1 : end), error2(10, 1 : end), 'Color', 'b'), hold on;
legend('KF', 'H-infinity'); title('Gyroscope bias east');
subplot(2, 3, 2);
plot(time_var1(1 : end), error1(11, 1 : end), 'Color', 'r'), hold on;
plot(time_var2(1 : end), error2(11, 1 : end), 'Color', 'b'), hold on;
legend('KF', 'H-infinity'); title('Gyroscope bias north');
subplot(2, 3, 3);
plot(time_var1(1 : end), error1(12, 1 : end), 'Color', 'r'), hold on;
plot(time_var2(1 : end), error2(12, 1 : end), 'Color', 'b'), hold on;
legend('KF', 'H-infinity'); title('Gyroscope bias up');
subplot(2, 3, 4);
plot(time_var1(1 : end), error1(13, 1 : end), 'Color', 'r'), hold on;
plot(time_var2(1 : end), error2(13, 1 : end), 'Color', 'b'), hold on;
legend('KF', 'H-infinity'); title('Accelerometer bias east');
subplot(2, 3, 5);
plot(time_var1(1 : end), error1(14, 1 : end), 'Color', 'r'), hold on;
plot(time_var2(1 : end), error2(14, 1 : end), 'Color', 'b'), hold on;
legend('KF', 'H-infinity'); title('Accelerometer bias north');
subplot(2, 3, 6);
plot(time_var1(1 : end), error1(15, 1 : end), 'Color', 'r'), hold on;
plot(time_var2(1 : end), error2(15, 1 : end), 'Color', 'b'), hold on;
legend('KF', 'H-infinity'); title('Accelerometer bias up');



figure('name', 'Tilt Estimation MSE');
subplot(3, 1, 1);
plot(time_var1(1 : end), var1(1, 1 : end), 'Color', 'r'), hold on;
plot(time_var2(1 : end), var2(1, 1 : end), 'Color', 'b'), hold on;
legend('KF', 'H-infinity'); title('Tilt east');
subplot(3, 1, 2);
plot(time_var1(1 : end), var1(2, 1 : end), 'Color', 'r'), hold on;
plot(time_var2(1 : end), var2(2, 1 : end), 'Color', 'b'), hold on;
legend('KF', 'H-infinity'); title('Tilt north');
subplot(3, 1, 3);
plot(time_var1(1 : end), var1(3, 1 : end), 'Color', 'r'), hold on;
plot(time_var2(1 : end), var2(3, 1 : end), 'Color', 'b'), hold on;
legend('KF', 'H-infinity'); title('Tilt up');

figure('name', 'Velocity Estimation MSE');
subplot(3, 1, 1);
plot(time_var1(1 : end), var1(4, 1 : end), 'Color', 'r'), hold on;
plot(time_var2(1 : end), var2(4, 1 : end), 'Color', 'b'), hold on;
legend('KF', 'H-infinity'); title('Velocity error east');
subplot(3, 1, 2);
plot(time_var1(1 : end), var1(5, 1 : end), 'Color', 'r'), hold on;
plot(time_var2(1 : end), var2(5, 1 : end), 'Color', 'b'), hold on;
legend('KF', 'H-infinity'); title('Velocity error north');
subplot(3, 1, 3);
plot(time_var1(1 : end), var1(6, 1 : end), 'Color', 'r'), hold on;
plot(time_var2(1 : end), var2(6, 1 : end), 'Color', 'b'), hold on;
legend('KF', 'H-infinity'); title('Velocity error up');

figure('name', 'Position Estimation MSE');
subplot(3, 1, 1);
plot(time_var1(1 : end), var1(7, 1 : end), 'Color', 'r'), hold on;
plot(time_var2(1 : end), var2(7, 1 : end), 'Color', 'b'), hold on;
legend('KF', 'H-infinity'); title('Latitude error');
subplot(3, 1, 2);
plot(time_var1(1 : end), var1(8, 1 : end), 'Color', 'r'), hold on;
plot(time_var2(1 : end), var2(8, 1 : end), 'Color', 'b'), hold on;
legend('KF', 'H-infinity'); title('Longitude error');
subplot(3, 1, 3);
plot(time_var1(1 : end), var1(9, 1 : end), 'Color', 'r'), hold on;
plot(time_var2(1 : end), var2(9, 1 : end), 'Color', 'b'), hold on;
legend('KF', 'H-infinity'); title('Height error');

figure('name', 'IMU Error Estimation MSE');
subplot(2, 3, 1);
plot(time_var1(1 : end), var1(10, 1 : end), 'Color', 'r'), hold on;
plot(time_var2(1 : end), var2(10, 1 : end), 'Color', 'b'), hold on;
legend('KF', 'H-infinity'); title('Gyroscope bias east');
subplot(2, 3, 2);
plot(time_var1(1 : end), var1(11, 1 : end), 'Color', 'r'), hold on;
plot(time_var2(1 : end), var2(11, 1 : end), 'Color', 'b'), hold on;
legend('KF', 'H-infinity'); title('Gyroscope bias north');
subplot(2, 3, 3);
plot(time_var1(1 : end), var1(12, 1 : end), 'Color', 'r'), hold on;
plot(time_var2(1 : end), var2(12, 1 : end), 'Color', 'b'), hold on;
legend('KF', 'H-infinity'); title('Gyroscope bias up');
subplot(2, 3, 4);
plot(time_var1(1 : end), var1(13, 1 : end), 'Color', 'r'), hold on;
plot(time_var2(1 : end), var2(13, 1 : end), 'Color', 'b'), hold on;
legend('KF', 'H-infinity'); title('Accelerometer bias east');
subplot(2, 3, 5);
plot(time_var1(1 : end), var1(14, 1 : end), 'Color', 'r'), hold on;
plot(time_var2(1 : end), var2(14, 1 : end), 'Color', 'b'), hold on;
legend('KF', 'H-infinity'); title('Accelerometer bias north');
subplot(2, 3, 6);
plot(time_var1(1 : end), var1(15, 1 : end), 'Color', 'r'), hold on;
plot(time_var2(1 : end), var2(15, 1 : end), 'Color', 'b'), hold on;
legend('KF', 'H-infinity'); title('Accelerometer bias up');
%}


RuntimeDraw = toc;
disp(['Drawing results running time = ', num2str(RuntimeDraw), 's']);





