ve_save_data = ve_kf1';
vn_save_data = vn_kf1';
vu_save_data = vu_kf1';
la_save_data = la_kf1';
lon_save_data = lon_kf1';
alt_save_data = alt_kf1';

save('D:\\ve.dat', 've_save_data', '-ascii', '-double');
save('D:\\vn.dat', 'vn_save_data', '-ascii', '-double');
save('D:\\vu.dat', 'vu_save_data', '-ascii', '-double');
save('D:\\la.dat', 'la_save_data', '-ascii', '-double');
save('D:\\lon.dat', 'lon_save_data', '-ascii', '-double');
save('D:\\alt.dat', 'alt_save_data', '-ascii', '-double');