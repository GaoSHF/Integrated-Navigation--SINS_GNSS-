% Position (rad), altitude (rad), angular velocity (rad/s), acceleration
% (m/s^2), T (s)
function [Qua, Ctb, pitch0, roll0, yaw0] = sins_coarse_alignment(la0, w, f)

% Global definition
wie = 7.292115147e-5; % rad/s
g0 = 9.7803267714; % m/s^2


Ctb(1, 3) = f(1, 1) / g0;
Ctb(2, 3) = f(2, 1) / g0;
Ctb(3, 3) = f(3, 1) / g0;
Ctb(1, 2) = (w(1, 1) - wie * sin(la0) * Ctb(1, 3)) / (wie * cos(la0));
Ctb(2, 2) = (w(2, 1) - wie * sin(la0) * Ctb(2, 3)) / (wie * cos(la0));
Ctb(3, 2) = (w(3, 1) - wie * sin(la0) * Ctb(3, 3)) / (wie * cos(la0));
Ctb(1, 1) = -Ctb(3, 2) * Ctb(2, 3) + Ctb(2, 2) * Ctb(3, 3);
Ctb(2, 1) = Ctb(3, 2) * Ctb(1, 3) - Ctb(1, 2) * Ctb(3, 3);
Ctb(3, 1) = -Ctb(2, 2) * Ctb(1, 3) + Ctb(1, 2) * Ctb(2, 3);

pitch0 = asin(Ctb(2, 3)); % -pi/2 to pi/2
    
roll0 = atan2(-Ctb(1, 3), Ctb(3, 3)); % -pi to pi
    
yaw0 = atan2(Ctb(2, 1), Ctb(2, 2)); % 0 to 2*pi
if yaw0 < 0
    yaw0 = yaw0 + 2 * pi;
end

% ENU Coordinate rotation, 3-1-2, z-x-y, (-yaw)-pitch-roll
% Euler angle is coordinate rotate angle, not vector rotate.
% Clockwise from north to east is positive direction for yaw(converse to right hand rule).

% Method 1: Euler matrix to quaternion
%Ctb = [cos(roll0) * cos(yaw0) + sin(pitch0) * sin(yaw0) * sin(roll0) ...
%    -cos(roll0) * sin(yaw0) + sin(pitch0) * cos(yaw0) * sin(roll0) ...
%    -sin(roll0) * cos(pitch0);
%    sin(yaw0) * cos(pitch0) ...
%    cos(yaw0) * cos(pitch0) ...
%    sin(pitch0);
%    sin(roll0) * cos(yaw0) - cos(roll0) * sin(yaw0) * sin(pitch0) ...
%    -sin(roll0) * sin(yaw0) - cos(roll0) * cos(yaw0) * sin(pitch0) ...
%    cos(pitch0) * cos(roll0)];
%Qua = [0; 0; 0; 0];
%Qua(1) = sqrt(1 + Ctb(1, 1) + Ctb(2, 2) + Ctb(3, 3)) / 2;
%Qua(2) = (Ctb(2, 3) - Ctb(3, 2)) / (4 * Qua(1));
%Qua(3) = (Ctb(3, 1) - Ctb(1, 3)) / (4 * Qua(1));
%Qua(4) = (Ctb(1, 2) - Ctb(2, 1)) / (4 * Qua(1));

% Method 2: Quaternion to Euler matrix
Qua = [0; 0; 0; 0];
Qua(1) = cos(yaw0 / 2) * cos(pitch0 / 2) * cos(roll0 / 2) + sin(yaw0 / 2) * sin(pitch0 / 2) * sin(roll0 / 2);
Qua(2) = cos(yaw0 / 2) * sin(pitch0 / 2) * cos(roll0 / 2) + sin(yaw0 / 2) * cos(pitch0 / 2) * sin(roll0 / 2);
Qua(3) = cos(yaw0 / 2) * cos(pitch0 / 2) * sin(roll0 / 2) - sin(yaw0 / 2) * sin(pitch0 / 2) * cos(roll0 / 2);
Qua(4) = cos(yaw0 / 2) * sin(pitch0 / 2) * sin(roll0 / 2) - sin(yaw0 / 2) * cos(pitch0 / 2) * cos(roll0 / 2);
Ctb = ...
    [Qua(1) ^ 2 + Qua(2) ^ 2 - Qua(3) ^ 2 - Qua(4) ^ 2 ...
    2 * (Qua(2) * Qua(3) + Qua(1) * Qua(4)) ...
    2 * (Qua(2) * Qua(4) - Qua(1) * Qua(3));
	2 * (Qua(2) * Qua(3) - Qua(1) * Qua(4)) ...
    Qua(1) ^ 2 - Qua(2) ^ 2 + Qua(3) ^ 2 - Qua(4) ^ 2 ...
    2 * (Qua(3) * Qua(4) + Qua(1) * Qua(2));
	2 * (Qua(2) * Qua(4) + Qua(1) * Qua(3)) ...
    2 * (Qua(3) * Qua(4) - Qua(1) * Qua(2)) ...
    Qua(1) ^ 2 - Qua(2) ^ 2 - Qua(3) ^ 2 + Qua(4) ^ 2];

end % function

