% Position (rad), altitude (rad), angular velocity (rad/s), acceleration
% (m/s^2), T (s)
% height_switch: 1 -- height on, 0 -- height off
function [la_kf, lon_kf, h_kf, v_kf, pitch_kf, roll_kf, yaw_kf, time_kf, time_es, Xes, sqrtP] = ...
    qukf_pv_euler(la0, lon0, h0, ve0, vn0, vu0, pitch0, roll0, yaw0, ...
    data, ...
    T_ins, T_kf, mx0, Cx0, Q, R, height_switch, Hinfinity_switch)

% Maximum channel number
RECEIVER_CHANNEL = 10;

% Global definition
wie = 7.292115147e-5; % rad/s
Re = 6378245; % Earth radius, m
e = 1 / 298.3; % Earth eccentrity
g0 = 9.7803267714; % m/s^2
gk1 = 0.00193185138639;
gk2 = 0.00669437999013;

%%%%%%%%%%%%%%%%%%%% Import data result
time = data( : , 1);

% Gyroscope data (rad/s)
w_ib_b = data( : , 2 : 4)';
% Accelerometer data (m/s^2)
f_b = data( : , 5 : 7)';

fixQuality = data( : , 8)';
svNumber = data( : , 9)';

la_gps = data( : , 10)';
lon_gps = data( : , 11)';
h_gps = data( : , 12)';
%pxGNSS = data( : , 13)';
%pyGNSS = data( : , 14)';
%pzGNSS = data( : , 15)';
vxGNSS = data( : , 16)';
vyGNSS = data( : , 17)';
vzGNSS = data( : , 18)';

channelNo = zeros(length(svNumber), 10)';
channelSNR = zeros(length(svNumber), 10)';
channelPseu = zeros(length(svNumber), 10)';
channelPseuRate = zeros(length(svNumber), 10)';
channelPx = zeros(length(svNumber), 10)';
channelPy = zeros(length(svNumber), 10)';
channelPz = zeros(length(svNumber), 10)';
channelVx = zeros(length(svNumber), 10)';
channelVy = zeros(length(svNumber), 10)';
channelVz = zeros(length(svNumber), 10)';
for i = 1 : RECEIVER_CHANNEL
    channelNo(i, : ) = data( : , 19 + (i - 1) * 10)';
    channelSNR(i, : ) = data( : , 20 + (i - 1) * 10)';
    channelPseu(i, : ) = data( : , 21 + (i - 1) * 10)';
    channelPseuRate(i, : ) = data( : , 22 + (i - 1) * 10)';
    channelPx(i, : ) = data( : , 23 + (i - 1) * 10)';
    channelPy(i, : ) = data( : , 24 + (i - 1) * 10)';
    channelPz(i, : ) = data( : , 25 + (i - 1) * 10)';
    channelVx(i, : ) = data( : , 26 + (i - 1) * 10)';
    channelVy(i, : ) = data( : , 27 + (i - 1) * 10)';
    channelVz(i, : ) = data( : , 28 + (i - 1) * 10)';
end




% GPS data length
len_kf = length(time);
%len_kf = 1000;

%%%%%%%%%%%%%%%%%%%% Declaration of strapdown navigation parameter

% Velocity
v_kf = zeros(3, len_kf);
v_kf(1 : 3, 1) = [ve0; vn0; vu0];

% Geographical position
la_kf = zeros(1, len_kf); la_kf(1, 1) = la0;
lon_kf = zeros(1, len_kf); lon_kf(1, 1) = lon0;
h_kf = zeros(1, len_kf); h_kf(1, 1) = h0;

% Attitude
roll_kf = zeros(1, len_kf); roll_kf(1, 1) = roll0;
pitch_kf = zeros(1, len_kf); pitch_kf(1, 1) = pitch0;
yaw_kf = zeros(1, len_kf); yaw_kf(1, 1) = yaw0;



Qua = [0; 0; 0; 0];
Qua(1) = cos(yaw0 / 2) * cos(pitch0 / 2) * cos(roll0 / 2) + sin(yaw0 / 2) * sin(pitch0 / 2) * sin(roll0 / 2);
Qua(2) = cos(yaw0 / 2) * sin(pitch0 / 2) * cos(roll0 / 2) + sin(yaw0 / 2) * cos(pitch0 / 2) * sin(roll0 / 2);
Qua(3) = cos(yaw0 / 2) * cos(pitch0 / 2) * sin(roll0 / 2) - sin(yaw0 / 2) * sin(pitch0 / 2) * cos(roll0 / 2);
Qua(4) = cos(yaw0 / 2) * sin(pitch0 / 2) * sin(roll0 / 2) - sin(yaw0 / 2) * cos(pitch0 / 2) * cos(roll0 / 2);

Ctb = [Qua(1)^2 + Qua(2)^2 - Qua(3)^2 - Qua(4)^2,   2 * (Qua(2) * Qua(3) + Qua(1) * Qua(4)),    2 * (Qua(2) * Qua(4) - Qua(1) * Qua(3));
        2 * (Qua(2) * Qua(3) - Qua(1) * Qua(4)),            Qua(1)^2-Qua(2)^2+Qua(3)^2-Qua(4)^2,        2*(Qua(3)*Qua(4)+Qua(1)*Qua(2));
        2*(Qua(2)*Qua(4)+Qua(1)*Qua(3)),                    2*(Qua(3)*Qua(4)-Qua(1)*Qua(2)),            Qua(1)^2-Qua(2)^2-Qua(3)^2+Qua(4)^2];

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Quaternion based tightly coupled  UKF parameter
% Xdot = F * X + G * W -->     X(k + 1) = F(X(k)) + Ka * W
% Z = H(X) + V -->     Z(k) = H * X(k) + V


% Xes: Estimation of system state
% Element : Quaternion element 1 (Ctp, from ideal navigation coordinate to platform coordinate / actual navigation coordinate)
%			Quaternion element 2
%			Quaternion element 3
%			Quaternion element 4
%           Velocity error at east axis(m / s)
%			Velocity error at north axis
%           Velocity error at up axis
%           Latitude error(rad)
%			Longitude error
%           height error(m)
%			Gyroscope accNoise at x axis(rad / s)
%			Gyroscope accNoise at y axis
%           Gyroscope accNoise at z axis
%           Accelerometer accNoise at x axis(m ^ 2 / s)
%			Accelerometer accNoise at y axis
%           Accelerometer accNoise at z axis
sizeX = 16;
Xes = zeros(sizeX, 1);
P = zeros(sizeX, sizeX, 1);


% Q: Variance of System noise W
% Element : Gyroscope noise at x axis (rad/s)
%			Gyroscope noise at y axis
%        	Gyroscope noise at z axis
%       	Acceleration random error at x axis (m/s^2)
%			Acceleration random error at y axis
%        	Acceleration random error at z axis


% Z: Observation
% Element:  Velocity error at east axis (m/s)
%         	Velocity error at north axis
%           Velocity error at up axis
%           Latitude error (rad)
%         	Longitude error
%           Height error (m)
sizeZ = 6;



% R: Observation noise variance
% Element:  Velocity observation noise at east axis (m/s)
%         	Velocity observation noise at north axis
%           Velocity observation noise at up axis
%           Latitude observation noise (rad)
%         	Longitude observation noise
%           Height observation noise (m)
 
 
%% Tightly coupled Unscented Kalman Filter using quaternion

% Initial condition
Xes( : , 1) = mx0;
P( : , : , 1) = Cx0;
%Sq = chol(Q)';

time_es = zeros(1, 1);
time_kf = zeros(1, 1);
count_es = 0;
for count_kf = 1 : len_kf
    % Record time
    time_kf(count_kf) = time(count_kf);
    
    % Restore old Ctb
    CtbOld = Ctb;
    
    %%%%%%% Strapdown navigation algorithm 
    Rm = Re / (1 + 2 * e - 3 * e * sin(la_kf(1, count_kf))^2); % Radius of meridian plane
    Rn = Re / (1 - e * sin(la_kf(1, count_kf))^2); % Radius of prime vertical plane
    
    w_ie_t = [0; wie * cos(la_kf(1, count_kf)); wie * sin(la_kf(1, count_kf))];
    w_et_t = [-v_kf(2, count_kf) / (Rm + h_kf(1, count_kf)); 
                v_kf(1, count_kf) / (Rn + h_kf(1, count_kf)); 
                v_kf(1, count_kf) / (Rn + h_kf(1, count_kf)) * tan(la_kf(1, count_kf))];

    % Refresh velocity, E-N-U coordinate system
    f_t = Ctb' * f_b(:, count_kf);

    v_kf(1, count_kf + 1) = (f_t(1) + ...
                            (2 * w_ie_t(3) + w_et_t(3)) * v_kf(2, count_kf) - ...
                            (2 * w_ie_t(2) + w_et_t(2)) * v_kf(3, count_kf)) * ...
                            T_ins + v_kf(1, count_kf);
    v_kf(2, count_kf + 1) = (f_t(2) - ...
                            (2 * w_ie_t(3) + w_et_t(3)) * v_kf(1, count_kf) + ...
                            (2 * w_ie_t(1) + w_et_t(1)) * v_kf(3, count_kf)) * ...
                            T_ins + v_kf(2, count_kf);

    if height_switch == 1
        g = g0 * (1 + gk1 * (sin(la_kf(1, count_kf))) ^ 2) * (1 - 2 * h_kf(1, count_kf) / Re) / sqrt(1 - gk2 * (sin(la_kf(1, count_kf))) ^ 2);

        v_kf(3, count_kf + 1) = (f_t(3) + ...
                            (2 * w_ie_t(2) + w_et_t(2)) * v_kf(1, count_kf) - ...
                            (2 * w_ie_t(1) + w_et_t(1)) * v_kf(2, count_kf) - g) * ...
                            T_ins + v_kf(3, count_kf);
    else
        v_kf(3, count_kf + 1) = v_kf(3, count_kf);
    end

    % Location
    la_kf(1, count_kf + 1) = v_kf(2, count_kf + 1) / (Rm + h_kf(1, count_kf)) * T_ins + la_kf(1, count_kf);
    lon_kf(1, count_kf + 1) = v_kf(1, count_kf + 1) / ((Rn + h_kf(1, count_kf)) * cos(la_kf(1, count_kf + 1))) * T_ins + lon_kf(1, count_kf);
    h_kf(1, count_kf + 1) = v_kf(3, count_kf + 1) * T_ins + h_kf(1, count_kf);

    % Refresh quaternion
    w_tb_b = w_ib_b(:, count_kf) - Ctb * (w_ie_t + w_et_t);

    seita_delta = T_ins * ...
                            [0          -w_tb_b(1)           -w_tb_b(2)         -w_tb_b(3);
                            w_tb_b(1)       0               w_tb_b(3)            -w_tb_b(2);
                            w_tb_b(2)    -w_tb_b(3)             0               w_tb_b(1)
                            w_tb_b(3)    w_tb_b(2)          -w_tb_b(1)              0];

    seita_delta_zero = sqrt(seita_delta(1, 2) ^ 2 + seita_delta(1, 3) ^ 2 + seita_delta(1, 4) ^ 2);

    Qua = (cos(seita_delta_zero / 2) * eye(4) + sin(seita_delta_zero / 2) / seita_delta_zero * seita_delta) * Qua;

    % Refresh Ctb
    Ctb = [Qua(1) ^ 2 + Qua(2) ^ 2 - Qua(3) ^ 2 - Qua(4) ^ 2,   2 * (Qua(2) * Qua(3) + Qua(1) * Qua(4)),    2 * (Qua(2) * Qua(4) - Qua(1) * Qua(3));
            2 * (Qua(2) * Qua(3) - Qua(1) * Qua(4)),            Qua(1)^2-Qua(2)^2+Qua(3)^2-Qua(4)^2,        2*(Qua(3)*Qua(4)+Qua(1)*Qua(2));
            2*(Qua(2)*Qua(4)+Qua(1)*Qua(3)),                    2*(Qua(3)*Qua(4)-Qua(1)*Qua(2)),            Qua(1)^2-Qua(2)^2-Qua(3)^2+Qua(4)^2];

        
    % Refresh attitude
    pitch_kf(1, count_kf + 1) = asin(Ctb(2, 3)); % -pi/2 to pi/2

    roll_kf(1, count_kf + 1) = atan2(-Ctb(1, 3), Ctb(3, 3)); % -pi to pi

    yaw_kf(1, count_kf + 1) = atan2(Ctb(2, 1), Ctb(2, 2)); % 0 to 2*pi
    if yaw_kf(1, count_kf + 1) < 0
        yaw_kf(1, count_kf + 1) = yaw_kf(1, count_kf + 1) + 2 * pi;
    end
    
    
    
    
    %%%%%%%% Unscented Kalman Filter  
    if (fixQuality(count_kf) ~= 0)
        
        count_es = count_es + 1;
        %disp(['count_es = ', num2str(count_es), '    ', 'count_kf = ', num2str(count_kf)]);
        
        % Restore new Ctb
        CtbNew = Ctb;
        Ctb = CtbOld;
        
        ve = v_kf(1, count_kf);
        vn = v_kf(2, count_kf);
        vu = v_kf(3, count_kf);
        la = la_kf(1, count_kf);
        lon = lon_kf(1, count_kf);
        h = h_kf(1, count_kf);
 

        % Transfer GNSS velocity from E-N-U to X-Y-Z
        laGNSS = la_gps(count_kf);
        lonGNSS = lon_gps(count_kf);
        Cte = [cos(pi / 2 + lonGNSS),       -cos(pi / 2 - laGNSS) * sin(pi / 2 + lonGNSS),      sin(pi / 2 - laGNSS) * sin(pi / 2 + lonGNSS);
                sin(pi / 2 + lonGNSS),      cos(pi / 2 - laGNSS) * cos(pi / 2 + lonGNSS),       -sin(pi / 2 - laGNSS) * cos(pi / 2 + lonGNSS);
                0,                          sin(pi / 2 - laGNSS),                               cos(pi / 2 - laGNSS)];
        
        venuGNSS = Cte' * [vxGNSS(count_kf); vyGNSS(count_kf); vzGNSS(count_kf)];
            
        Z( : , 1) = [ve - venuGNSS(1, 1);
                    vn - venuGNSS(2, 1);
                    vu - venuGNSS(3, 1);
                    la - la_gps(count_kf);
                    lon - lon_gps(count_kf);
                    h - h_gps(count_kf)];

        
        
        % Sigma point
        weight_m = zeros(1, 2 * sizeX + 1);
        weight_c = zeros(1, 2 * sizeX + 1);
        XesSigma = zeros(sizeX, 2 * sizeX + 1);
        
        
        alpha = 0.6; % 1e-4 to 1, 0.518 to 1 will make lamda > 0 for n = 18, beta = 2 and kappa = 0
        beta = 2; % Best for Gauss white noise
        kappa = 0;
        lamda = alpha * alpha * (sizeX + kappa) - sizeX;
        weight_m(1) = lamda / (sizeX + lamda);
        weight_c(1) = lamda / (sizeX + lamda) + (1 - alpha * alpha + beta);
        
        
        %{
        lamda = 1;
        weight_m(1) = lamda / (sizeX + lamda);
        weight_c(1) = lamda / (sizeX + lamda);
        %}
        
        XesSigma( : , 1) = Xes( : , count_es);
        upperTriMatrix = chol(P( :, : , count_es));
        for i = 1 : sizeX
            weight_m(i + 1) = 1 / (2 * (sizeX + lamda));
            weight_m(i + 1 + sizeX) = 1 / (2 * (sizeX + lamda));
            
            weight_c(i + 1) = weight_m(i + 1);
            weight_c(i + 1 + sizeX) = weight_m(i + 1 + sizeX);
            
            temp = sqrt(sizeX + lamda) * upperTriMatrix(i, : )';
            %temp(1, 1) = sqrt(1 - temp(2, 1)^2 - temp(3, 1)^2 - temp(4, 1)^2);
            % quaternion part
            MQ = [temp(1, 1),   -temp(2, 1),    -temp(3, 1),     -temp(4, 1);
                     temp(2, 1),    temp(1, 1),     -temp(4, 1),     temp(3, 1);
                     temp(3, 1),    temp(4, 1),     temp(1, 1),      -temp(2, 1);
                     temp(4, 1),    -temp(3, 1),    temp(2, 1),      temp(1, 1)];
            
            MQinv = [temp(1, 1),   temp(2, 1),    temp(3, 1),     temp(4, 1);
                     -temp(2, 1),    temp(1, 1),     temp(4, 1),     -temp(3, 1);
                     -temp(3, 1),    -temp(4, 1),     temp(1, 1),      temp(2, 1);
                     -temp(4, 1),    temp(3, 1),    -temp(2, 1),      temp(1, 1)];
            %MQinv = MQinv / (temp(1, 1)^2 + temp(2, 1)^2 + temp(3, 1)^2 + temp(4, 1)^2);
            
            XesSigma(1 : 4, i + 1) = MQ * XesSigma(1 : 4, 1);
            XesSigma(1 : 4, i + 1 + sizeX) = MQinv * XesSigma(1 : 4, 1);
            XesSigma(1, i + 1) = sqrt(1 - XesSigma(2, i + 1)^2 - XesSigma(3, i + 1)^2 - XesSigma(4, i + 1)^2);
            XesSigma(1, i + 1 + sizeX) = sqrt(1 - XesSigma(2, i + 1 + sizeX)^2 - XesSigma(3, i + 1 + sizeX)^2 - XesSigma(4, i + 1 + sizeX)^2);
            
            % un-quaternion part
            XesSigma(5 : sizeX, i + 1) = XesSigma(5 : sizeX, 1) + temp(5 : sizeX, 1);
            XesSigma(5 : sizeX, i + 1 + sizeX) = XesSigma(5 : sizeX, 1) - temp(5 : sizeX, 1);
        end
        

        % One step estimation: XesOneStep = sum(weight_m * F(XesSigma))
        Cpb = Ctb;
        XesOneStep = zeros(sizeX, 1);
        XesSigmaOneStep = zeros(sizeX, 2 * sizeX + 1);
        M = zeros(4, 4);
        for i = 1 : 2 * sizeX + 1
            % XesOneStep
            Quapt = XesSigma(1 : 4, i);
            deltaV = XesSigma(5 : 7, i);
            deltaLa = XesSigma(8, i);
            deltaLon = XesSigma(9, i);
            deltaH = XesSigma(10, i);

            Ctp = [Quapt(1)^2 + Quapt(2)^2 - Quapt(3)^2 - Quapt(4)^2, ...
                2 * (Quapt(2) * Quapt(3) + Quapt(1) * Quapt(4)), ...
                2 * (Quapt(2) * Quapt(4) - Quapt(1) * Quapt(3));
                2 * (Quapt(2) * Quapt(3) - Quapt(1) * Quapt(4)), ...
                Quapt(1)^2 - Quapt(2)^2 + Quapt(3)^2 - Quapt(4)^2, ...
                2 * (Quapt(3) * Quapt(4) + Quapt(1) * Quapt(2));
                2 * (Quapt(2) * Quapt(4) + Quapt(1) * Quapt(3)), ...
                2 * (Quapt(3) * Quapt(4) - Quapt(1) * Quapt(2)), ...
                Quapt(1)^2 - Quapt(2)^2 - Quapt(3)^2 + Quapt(4)^2];

            B = [-Quapt(2) / 2,    -Quapt(3) / 2,     -Quapt(4) / 2;
                 Quapt(1) / 2,     -Quapt(4) / 2,     Quapt(3) / 2;
                 Quapt(4) / 2,     Quapt(1) / 2,      -Quapt(2) / 2;
                 -Quapt(3) / 2,    Quapt(2) / 2,      Quapt(1) / 2];

            
            w_ie_t = [0; 
                wie * cos(la); 
                wie * sin(la)];
            w_et_t = [-vn / (Rm + h);
                ve / (Rn + h); 
                ve / (Rn + h) * tan(la)];


            delta_w_ie_t = [0;
                -wie * sin(la) * deltaLa;
                wie * cos(la) * deltaLa];

            delta_w_et_t = [-1 / (Rm + h) * deltaV(2) + 1 / (Rm + h) / (Rm + h) * vn * deltaH;
                1 / (Rn + h) * deltaV(1) - 1 / (Rn + h) / (Rn + h) * ve * deltaH;
                1 / (Rn + h) * tan(la) * deltaV(1) + ...
                1 / (Rn + h) / cos(la) / cos(la) * ve * deltaLa - ...
                1 / (Rn + h) / (Rn + h) * tan(la) * ve * deltaH];
                 
            % Qdot = B * (I - Ctp) * witt + B * Cbp * gyroDrift
            temp = (B * (eye(3) - Ctp) * (w_ie_t + w_et_t) + B * Cpb' * XesSigma(11 : 13, i)) * T_kf;
            MQ = [temp(1, 1),   -temp(2, 1),    -temp(3, 1),     -temp(4, 1);
                     temp(2, 1),    temp(1, 1),     -temp(4, 1),     temp(3, 1);
                     temp(3, 1),    temp(4, 1),     temp(1, 1),      -temp(2, 1);
                     temp(4, 1),    -temp(3, 1),    temp(2, 1),      temp(1, 1)];
            XesSigmaOneStep(1 : 4, i) = MQ * Quapt;
            XesSigmaOneStep(1, i) = sqrt(1 - XesSigmaOneStep(2, i)^2 - XesSigmaOneStep(3, i)^2 - XesSigmaOneStep(4, i)^2);
            %XesSigmaOneStep(1 : 4, i) = XesSigmaOneStep(1 : 4, i) / sqrt(XesSigmaOneStep(1, i)^2 + XesSigmaOneStep(2, i)^2 + XesSigmaOneStep(3, i)^2 + XesSigmaOneStep(4, i)^2);
            
            
            % deltaVdot = (I - Cpt) * Cbp * fb - (2 * wiet + wett) X deltaV
            % - (2 * deltawiet + deltawett) X V - (2 * deltawiet +
            % deltawett) X deltaV + Cbp * accBias + deltagt
            XesSigmaOneStep(5 : 7, i) = deltaV + ((eye(3) - Ctp') * Cpb' * f_b(:, count_kf) - ...
                    cross((2 * w_ie_t + w_et_t), deltaV) - ...
                    cross((2 * delta_w_ie_t + delta_w_et_t), [ve; vn; vu]) - ...
                    cross((2 * delta_w_ie_t + delta_w_et_t), deltaV) + ...
                    Cpb' * XesSigma(14 : 16, i)) * T_kf;


            % deltaladot = (1 / (Rm + h)) * deltaVn - (Vn / (Rm + h)^2)
            % * deltah
            XesSigmaOneStep(8, i) = deltaLa + ((1 / (Rm + h)) * deltaV(2) - (vn / (Rm + h)^2) * deltaH) * T_kf;
            
            % deltalondot = (sec(la) / (Rn + h)) * deltaVe + (Ve * tan(la)
            % * sec(la) / (Rn + h)) * deltala - (Ve * sec(la) / (Rm + h) ^
            % 2) * deltah
            XesSigmaOneStep(9, i) = deltaLon + ((sec(la) / (Rn + h)) * deltaV(1) + (ve * tan(la) * sec(la) / (Rn + h)) * deltaLa - (ve * sec(la) / (Rm + h) ^ 2) * deltaH) * T_kf;
            
            % deltahdot = deltaVu
            XesSigmaOneStep(10, i) = deltaH + deltaV(3) * T_kf;
            
            XesSigmaOneStep(11, i) = XesSigma(11, i);
            XesSigmaOneStep(12, i) = XesSigma(12, i);
            XesSigmaOneStep(13, i) = XesSigma(13, i);
            
            XesSigmaOneStep(14, i) = XesSigma(14, i);
            XesSigmaOneStep(15, i) = XesSigma(15, i);
            XesSigmaOneStep(16, i) = XesSigma(16, i);
            
            
            
            % Get XesOneStep
            % quaternion part
            M = M + weight_m(i) * XesSigmaOneStep(1 : 4, i) * XesSigmaOneStep(1 : 4, i)';
            
            % un-quaternion part
            XesOneStep(5 : sizeX, 1) = XesOneStep(5 : sizeX, 1) + weight_m(i) * XesSigmaOneStep(5 : sizeX, i);

        end % i
        
        % XesOneStep for quaternion part q = argmax(q'Mq) =
        % eigvec(max(eig(M)))
        [eigenvectors, eigenvalues] = eig(M);
        [~, index] = max(max(eigenvalues));
        XesOneStep(1 : 4, 1) = eigenvectors( : , index);
        
        
        % Get PesOneStep
        PesOneStep = zeros(sizeX, sizeX);
        deltaXesOneStep = zeros(sizeX, 1);
        MQinv = [XesOneStep(1, 1),   XesOneStep(2, 1),    XesOneStep(3, 1),     XesOneStep(4, 1);
                 -XesOneStep(2, 1),    XesOneStep(1, 1),     XesOneStep(4, 1),     -XesOneStep(3, 1);
                 -XesOneStep(3, 1),    -XesOneStep(4, 1),     XesOneStep(1, 1),      XesOneStep(2, 1);
                 -XesOneStep(4, 1),    XesOneStep(3, 1),    -XesOneStep(2, 1),      XesOneStep(1, 1)];
        %MQinv = MQinv / (XesOneStep(1, 1)^2 + XesOneStep(2, 1)^2 + XesOneStep(3, 1)^2 + XesOneStep(4, 1)^2);
        for i = 1 : 2 * sizeX + 1
            deltaXesOneStep(1 : 4, 1) = MQinv * ...
                [XesSigmaOneStep(1, i); XesSigmaOneStep(2, i); XesSigmaOneStep(3, i); XesSigmaOneStep(4, i)];
            
            deltaXesOneStep(5 : sizeX, 1) = XesSigmaOneStep(5 : sizeX, i) - XesOneStep(5 : sizeX, 1);
            
            PesOneStep = PesOneStep + weight_c(i) * deltaXesOneStep(:) * deltaXesOneStep';
        end
        % Process noise transfer matrix
        G = [zeros(4, 3),	zeros(4, 3);
             zeros(3, 3),   zeros(3, 3);
             zeros(3, 3),   zeros(3, 3);
             eye(3),        zeros(3, 3);
             zeros(3, 3),   eye(3)];
        Ka = G * T_kf;
        PesOneStep = PesOneStep + Ka * Q * Ka';
        

        % Sigma points of XesOneStep (Only for UKF with additive noise)
        XesOneStepSigma = zeros(sizeX, 4 * sizeX + 1);
        XesOneStepSigma( : , 1 : 2 * sizeX + 1) = XesSigmaOneStep;
        %{
        for i = 1 : sizeX
            temp = sqrt((sizeX + lamda)) * Ka * Sq * Ka';
            % quaternion part
            MQ = [temp(1, 1),   -temp(2, 1),    -temp(3, 1),     -temp(4, 1);
                     temp(2, 1),    temp(1, 1),     -temp(4, 1),     temp(3, 1);
                     temp(3, 1),    temp(4, 1),     temp(1, 1),      -temp(2, 1);
                     temp(4, 1),    -temp(3, 1),    temp(2, 1),      temp(1, 1)];
                 
            MQinv = [temp(1, 1),   temp(2, 1),    temp(3, 1),     temp(4, 1);
                     -temp(2, 1),    temp(1, 1),     temp(4, 1),     -temp(3, 1);
                     -temp(3, 1),    -temp(4, 1),     temp(1, 1),      temp(2, 1);
                     -temp(4, 1),    temp(3, 1),    -temp(2, 1),      temp(1, 1)];
                 
            XesOneStepSigma(1 : 4, 2 * sizeX + 1 + i) = MQ * XesOneStepSigma(1 : 4, 1);
            XesOneStepSigma(1 : 4, 2 * sizeX + 1 + i + sizeX) = MQinv * XesOneStepSigma(1 : 4, 1);
            XesOneStepSigma(1, 2 * sizeX + 1 + i) = ...
                sqrt(1 - ...
                XesOneStepSigma(2, 2 * sizeX + 1 + i)^2 - ...
                XesOneStepSigma(3, 2 * sizeX + 1 + i)^2 - ...
                XesOneStepSigma(4, 2 * sizeX + 1 + i)^2);
            XesOneStepSigma(1, 2 * sizeX + 1 + i + sizeX) = ...
                sqrt(1 - ...
                XesOneStepSigma(2, 2 * sizeX + 1 + i + sizeX)^2 - ...
                XesOneStepSigma(3, 2 * sizeX + 1 + i + sizeX)^2 - ...
                XesOneStepSigma(4, 2 * sizeX + 1 + i + sizeX)^2);
            
            % un-quaternion part
            XesOneStepSigma(5 : sizeX, 2 * sizeX + 1 + i) = XesOneStepSigma(5 : sizeX, 1) + temp(5 : sizeX, 1);
            XesOneStepSigma(5 : sizeX, 2 * sizeX + 1 + i + sizeX) = XesOneStepSigma(5 : sizeX, 1) - temp(5 : sizeX, 1);
        end
        %}
        
        % One step measurements: ZesOneStep = sum(weight_m * H(XesSigma))
        ZesOneStep = zeros(sizeZ, 1);
        ZesSigmaOneStep = zeros(sizeZ, 2 * sizeX + 1);
        % Observation matrix
        H = [zeros(3, 4),   eye(3),        zeros(3, 3),    zeros(3, 6);
             zeros(3, 4),   zeros(3, 3),    eye(3),          zeros(3, 6)];
        for i = 1 : 2 * sizeX + 1
            ZesSigmaOneStep( : , i) = H * XesOneStepSigma( : , i);
            ZesOneStep( : , 1) = ZesOneStep( : , 1) + weight_m(i) * ZesSigmaOneStep( : , i);
        end


        % Get PzesOneStep and PxzesOneStep
        PzesOneStep = zeros(sizeZ, sizeZ);
        PxzesOneStep = zeros(sizeX, sizeZ); 
        deltaXesOneStep = zeros(sizeX, 1);
        MQinv = [XesOneStep(1, 1),   XesOneStep(2, 1),    XesOneStep(3, 1),     XesOneStep(4, 1);
                 -XesOneStep(2, 1),    XesOneStep(1, 1),     XesOneStep(4, 1),     -XesOneStep(3, 1);
                 -XesOneStep(3, 1),    -XesOneStep(4, 1),     XesOneStep(1, 1),      XesOneStep(2, 1);
                 -XesOneStep(4, 1),    XesOneStep(3, 1),    -XesOneStep(2, 1),      XesOneStep(1, 1)];
        %MQinv = MQinv / (XesOneStep(1, 1)^2 + XesOneStep(2, 1)^2 + XesOneStep(3, 1)^2 + XesOneStep(4, 1)^2);   
        for i = 1 : 2 * sizeX + 1
            deltaXesOneStep(1 : 4, 1) = MQinv * ...
                [XesOneStepSigma(1, i); XesOneStepSigma(2, i); XesOneStepSigma(3, i); XesOneStepSigma(4, i)];
            
            deltaXesOneStep(5 : sizeX, 1) = XesOneStepSigma(5 : sizeX, i) - XesOneStep(5 : sizeX, 1);
            
            PzesOneStep = PzesOneStep + weight_c(i) * (ZesSigmaOneStep( : , i) - ZesOneStep) * (ZesSigmaOneStep( : , i) - ZesOneStep)';
            PxzesOneStep = PxzesOneStep + weight_c(i) * deltaXesOneStep * (ZesSigmaOneStep( : , i) - ZesOneStep)';
        end
        PzesOneStep = PzesOneStep + R;
        
        % Kalman Gain
        K = PxzesOneStep / PzesOneStep;

        % Estimation
        temp = K * (Z - ZesOneStep);
        MQ = [temp(1, 1),   -temp(2, 1),    -temp(3, 1),     -temp(4, 1);
                 temp(2, 1),    temp(1, 1),     -temp(4, 1),     temp(3, 1);
                 temp(3, 1),    temp(4, 1),     temp(1, 1),      -temp(2, 1);
                 temp(4, 1),    -temp(3, 1),    temp(2, 1),      temp(1, 1)];
        Xes(1 : 4, count_es + 1) = MQ * XesOneStep(1 : 4, 1);
        %Xes(1, count_es + 1) = sqrt(1 - Xes(2, count_es + 1)^2 - Xes(3, count_es + 1)^2 - Xes(4, count_es + 1)^2);
        Xes(1 : 4, count_es + 1) = Xes(1 : 4, count_es + 1) / sqrt(Xes(1, count_es + 1)^2 + Xes(2, count_es + 1)^2 + Xes(3, count_es + 1)^2 + Xes(4, count_es + 1)^2);
        
        Xes(5 : sizeX, count_es + 1) = XesOneStep(5 : sizeX, 1) + temp(5 : sizeX);

        if Hinfinity_switch == 0
            P( : , : , count_es + 1) = PesOneStep - K * PzesOneStep * K';
        else
            % Rek
            alphaHinf = 200;
            Hktrans = eye(sizeX) / PesOneStep * PxzesOneStep;
            Hk = Hktrans';
            gammaSquare = alphaHinf * max(eig(eye(sizeX) / (eye(sizeX) / PesOneStep + Hktrans / R * Hk)));
            %disp(num2str(gammaSquare));
            Rek = [PzesOneStep, PxzesOneStep'; PxzesOneStep, PesOneStep - gammaSquare * eye(sizeX)];
            % Estimation Pes
            P( : , : , count_es + 1) = PesOneStep - [PxzesOneStep, PesOneStep] / Rek * [PxzesOneStep, PesOneStep]';
        end
        
        
        % Recover new Ctb
      	Ctb = CtbNew;
        
        % Feedback correction
        if count_es > 0

            % fix Euler matrix
            Qtc = [Xes(1, count_es + 1); Xes(2, count_es + 1); Xes(3, count_es + 1); Xes(4, count_es + 1)];
            Ctc = [Qtc(1)^2 + Qtc(2)^2 - Qtc(3)^2 - Qtc(4)^2,   2 * (Qtc(2) * Qtc(3) + Qtc(1) * Qtc(4)),    2 * (Qtc(2) * Qtc(4) - Qtc(1) * Qtc(3));
                    2 * (Qtc(2) * Qtc(3) - Qtc(1) * Qtc(4)), 	Qtc(1)^2 - Qtc(2)^2 + Qtc(3)^2 - Qtc(4)^2,	2 * (Qtc(3) * Qtc(4) + Qtc(1) * Qtc(2));
                    2 * (Qtc(2) * Qtc(4) + Qtc(1) * Qtc(3)),  	2 * (Qtc(3) * Qtc(4) - Qtc(1) * Qtc(2)),  	Qtc(1)^2 - Qtc(2)^2 - Qtc(3)^2 + Qtc(4)^2];

            Ctb = Ctb * Ctc; % Exclude tilt

            % fix attitude quaternion  
            Qua(1) = sqrt(abs(1 + Ctb(1, 1) + Ctb(2, 2) + Ctb(3, 3))) / 2;
            Qua(2) = sqrt(abs(1 + Ctb(1, 1) - Ctb(2, 2) - Ctb(3, 3))) / 2;
            Qua(3) = sqrt(abs(1 - Ctb(1, 1) + Ctb(2, 2) - Ctb(3, 3))) / 2;
            Qua(4) = sqrt(abs(1 - Ctb(1, 1) - Ctb(2, 2) + Ctb(3, 3))) / 2;

            if ((Ctb(2, 3) - Ctb(3, 2)) / (4 * Qua(1)) < 0)
                Qua(2) = -Qua(2);
            end
            if ((Ctb(3, 1) - Ctb(1, 3)) / (4 * Qua(1)) < 0)
                Qua(3) = -Qua(3);
            end
            if ((Ctb(1, 2) - Ctb(2, 1)) / (4 * Qua(1)) < 0)
                Qua(4) = -Qua(4);
            end
            

            % fix attitude
            pitch_kf(1, count_kf + 1) = asin(Ctb(2, 3)); % -pi/2 to pi/2

            roll_kf(1, count_kf + 1) = atan2(-Ctb(1, 3), Ctb(3, 3)); % -pi to pi

            yaw_kf(1, count_kf + 1) = atan2(Ctb(2, 1), Ctb(2, 2)); % 0 to 2*pi
            if yaw_kf(1, count_kf + 1) < 0
                yaw_kf(1, count_kf + 1) = yaw_kf(1, count_kf + 1) + 2 * pi;
            end
                
            % fix velocity and position
            v_kf(1, count_kf + 1) = ve - Xes(5, count_es + 1);
            v_kf(2, count_kf + 1) = vn - Xes(6, count_es + 1);
            v_kf(3, count_kf + 1) = vu - Xes(7, count_es + 1);

            la_kf(1, count_kf + 1) = la - Xes(8, count_es + 1);
            lon_kf(1, count_kf + 1) = lon - Xes(9, count_es + 1);
            h_kf(1, count_kf + 1) = h - Xes(10, count_es + 1);
        end % Feedback correction

        time_es(count_es) = time(count_kf);
    
    end % Kalman Filter

end

disp(['count_es = ', num2str(count_es)]);


% Extraction of estimation variance
sqrtP = zeros(sizeX, count_es);
[~, ~, len_temp3] = size(P);
for count = 1 : 1 : len_temp3
    sqrtP(1, count) = sqrt(P(1, 1, count));
    sqrtP(2, count) = sqrt(P(2, 2, count));
    sqrtP(3, count) = sqrt(P(3, 3, count));
    sqrtP(4, count) = sqrt(P(4, 4, count));
    
    sqrtP(5, count) = sqrt(P(5, 5, count));
    sqrtP(6, count) = sqrt(P(6, 6, count));
    sqrtP(7, count) = sqrt(P(7, 7, count));
    
    sqrtP(8, count) = sqrt(P(8, 8, count));
    sqrtP(9, count) = sqrt(P(9, 9, count));
    sqrtP(10, count) = sqrt(P(10, 10, count));
    
    sqrtP(11, count) = sqrt(P(11, 11, count));
    sqrtP(12, count) = sqrt(P(12, 12, count));
    sqrtP(13, count) = sqrt(P(13, 13, count));
    
    sqrtP(14, count) = sqrt(P(14, 14, count));
    sqrtP(15, count) = sqrt(P(15, 15, count));    
    sqrtP(16, count) = sqrt(P(16, 16, count)); 
end


end % function

