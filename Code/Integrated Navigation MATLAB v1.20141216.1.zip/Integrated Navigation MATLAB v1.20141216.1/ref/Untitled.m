
dataTemp = importdata('../../../../Integrated Navigation Data/�������� 20130601/�������� ���� 20130601/201306010101 (GPS Real Static)/pulse.txt');
        dataIMU = dataTemp.data(120 * 100 : 240 * 100, :);
        
        
        % Noise
    AR_NOISE_ENABLED = 1;
    noiseGyroPast = zeros(3, 3);
    noiseAccPast = zeros(3, 3);
    if AR_NOISE_ENABLED == 1
        [lenIMU, ~] = size(dataIMU);
        
        noiseGyro = zeros(lenIMU, 3);
        noiseAcc = zeros(lenIMU, 3);
        dataTemp = [dataIMU( : , 8), dataIMU( : , 9), dataIMU( : , 10), dataIMU( : , 11), dataIMU( : , 12), dataIMU( : , 13)];
        
        noiseGyro( : , 1) = awgn(dataTemp( : , 1), 100, 'measured') - dataIMU( : , 8);
        noiseGyro( : , 2) = awgn(dataTemp( : , 2), 100, 'measured') - dataIMU( : , 9);
        noiseGyro( : , 3) = awgn(dataTemp( : , 3), 100, 'measured') - dataIMU( : , 10);
        noiseAcc( : , 1) = awgn(dataTemp( : , 4), 100, 'measured') - dataIMU( : , 11);
        noiseAcc( : , 2) = awgn(dataTemp( : , 5), 100, 'measured') - dataIMU( : , 12);
        noiseAcc( : , 3) = awgn(dataTemp( : , 6), 100, 'measured') - dataIMU( : , 13);
        
        for i = 1 : lenIMU
            
            noiseGyro(i, : ) = noiseGyro(i, : ) - 1.5 * noiseGyroPast(1, :) - 0.75 * noiseGyroPast(2, : ) - 0.125 * noiseGyroPast(3, : );
            noiseAcc(i, : ) = noiseAcc(i, : ) - 1.5 * noiseAccPast(1, :) - 0.75 * noiseAccPast(2, : ) - 0.125 * noiseAccPast(3, : );

            noiseGyroPast(3, : ) = noiseGyroPast(2, : );
            noiseGyroPast(2, : ) = noiseGyroPast(1, : );
            noiseGyroPast(1, : ) = noiseGyro(i, : );

            noiseAccPast(3, : ) = noiseAccPast(2, : );
            noiseAccPast(2, : ) = noiseAccPast(1, : );
            noiseAccPast(1, : ) = noiseAcc(i, : );
            
            dataIMU(i , 8 : 10) = dataIMU(i , 8 : 10) + noiseGyro(i, : );
            dataIMU(i , 11 : 13) = dataIMU(i , 11 : 13) + noiseAcc(i, : );
        end
        
    end
    
   plot(dataIMU( : , 13));