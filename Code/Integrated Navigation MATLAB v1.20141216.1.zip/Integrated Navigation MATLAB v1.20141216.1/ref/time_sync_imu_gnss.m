% Position (rad), altitude (rad), angular velocity (rad/s), acceleration
% (m/s^2), T (s)
% height_switch: 1 -- height on, 0 -- height off
function [time_sync_point_imu, time_sync_point_gnss] = time_sync_imu_gnss(time_imu, time_gnss)

% Relay before using feedback correction
RELAY_BEFORE_FEEDBACK_CORRECTION = 0 * 60 / T_imu;

    if ((count_kf <= len_imu) && (count_gps <= len_gps))
    while (utc_imu(count_kf) > utc_gps(count_gps)) && (count_gps <= len_gps)
        count_gps = count_gps + 1;
        if utc_imu(count_kf) == utc_gps(count_gps)
            disp(['GPS sync head: ', num2str(count_gps)]);
            disp(['IMU sync head: ', num2str(count_kf)]);
            break;
        end
    end
    if (utc_imu(count_kf) == utc_gps(count_gps))

end % function