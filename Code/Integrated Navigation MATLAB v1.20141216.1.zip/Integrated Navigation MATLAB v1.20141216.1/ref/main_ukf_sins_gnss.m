close all;
clear all;

% Read IMU data
DataIMU = importdata('../Data/201312251133/imu.txt');
LengthIMU = length(DataIMU);
TimeIMU = DataIMU( : , 1)'; %ms
Wibb = DataIMU( : , 2 : 4)'; % rad/s
Fb = DataIMU( : , 5 : 7)'; % m/s^2


% Read PPS data
DataPPS = importdata('../Data/201312251133/pps.txt');
LengthPPS = length(DataPPS);
TimePPS = DataPPS( : , 1)'; %ms


% Read GNSS data
DataGNSS = importdata('../Data/201312251133/gnss.txt');
LengthGNSS = length(DataGNSS);

TimeGNSS = DataGNSS( : , 1)'; %ms
RcvTime = DataGNSS( : , 2)'; %ms
Quality = DataGNSS( : , 3)';
SVs = DataGNSS( : , 4)';
LaGNSS = DataGNSS( : , 5)'; %degrees
LonGNSS = DataGNSS( : , 6)'; %degrees
AltGNSS = DataGNSS( : , 7)'; %m
PDOP = DataGNSS( : , 8)';
PxGNSS = DataGNSS( : , 9)';
PyGNSS = DataGNSS( : , 10)';
PzGNSS = DataGNSS( : , 11)';
VxGNSS = DataGNSS( : , 12)';
VyGNSS = DataGNSS( : , 13)';
VzGNSS = DataGNSS( : , 14)';

SVNo = zeros(10, LengthGNSS);
SVPseu = zeros(10, LengthGNSS);
SVPseuRate = zeros(10, LengthGNSS);
SVPx = zeros(10, LengthGNSS);
SVPy = zeros(10, LengthGNSS);
SVPz = zeros(10, LengthGNSS);
SVVx = zeros(10, LengthGNSS);
SVVy = zeros(10, LengthGNSS);
SVVz = zeros(10, LengthGNSS);
for i = 1 : 10
    SVNo(i, : ) = DataGNSS( : , 15 + (i - 1) * 9)';
    SVSNR(i, : ) = DataGNSS( : , 16 + (i - 1) * 9)';
    SVPseu(i, : ) = DataGNSS( : , 17 + (i - 1) * 9)';
    SVPseuRate(i, : ) = DataGNSS( : , 18 + (i - 1) * 9)';
    SVPx(i, : ) = DataGNSS( : , 19 + (i - 1) * 9)';
    SVPy(i, : ) = DataGNSS( : , 20 + (i - 1) * 9)';
    SVPz(i, : ) = DataGNSS( : , 21 + (i - 1) * 9)';
    SVVx(i, : ) = DataGNSS( : , 22 + (i - 1) * 9)';
    SVVy(i, : ) = DataGNSS( : , 23 + (i - 1) * 9)';
    SVVz(i, : ) = DataGNSS( : , 24 + (i - 1) * 9)';
end










