clear;

% Read GNSS data
DataGNSS = importdata('../Data/201312251133/gnss.txt');
LengthGNSS = length(DataGNSS);
TimeGNSS = DataGNSS( : , 1)'; %ms
RcvTime = DataGNSS( : , 2)'; %ms
SVs = DataGNSS( : , 3)'; %ms
LaGNSS = DataGNSS( : , 4)'; %degrees
LonGNSS = DataGNSS( : , 5)'; %degrees
AltGNSS = DataGNSS( : , 6)'; %m
PDOP = DataGNSS( : , 7)';
PxGNSS = DataGNSS( : , 8)';
PyGNSS = DataGNSS( : , 9)';
PzGNSS = DataGNSS( : , 10)';
VxGNSS = DataGNSS( : , 11)';
VyGNSS = DataGNSS( : , 12)';
VzGNSS = DataGNSS( : , 13)';

SVNo = zeros(10, LengthGNSS);
SVPseu = zeros(10, LengthGNSS);
SVPseuRate = zeros(10, LengthGNSS);
SVPx = zeros(10, LengthGNSS);
SVPy = zeros(10, LengthGNSS);
SVPz = zeros(10, LengthGNSS);
SVVx = zeros(10, LengthGNSS);
SVVy = zeros(10, LengthGNSS);
SVVz = zeros(10, LengthGNSS);
for i = 1 : 10
    SVNo(i, : ) = DataGNSS( : , 14 + (i - 1) * 9)';
    SVPseu(i, : ) = DataGNSS( : , 15 + (i - 1) * 9)';
    SVPseuRate(i, : ) = DataGNSS( : , 16 + (i - 1) * 9)';
    SVPx(i, : ) = DataGNSS( : , 17 + (i - 1) * 9)';
    SVPy(i, : ) = DataGNSS( : , 18 + (i - 1) * 9)';
    SVPz(i, : ) = DataGNSS( : , 19 + (i - 1) * 9)';
    SVVx(i, : ) = DataGNSS( : , 20 + (i - 1) * 9)';
    SVVy(i, : ) = DataGNSS( : , 21 + (i - 1) * 9)';
    SVVz(i, : ) = DataGNSS( : , 22 + (i - 1) * 9)';
end



Quality = zeros(1, LengthGNSS);
SVSNR = zeros(10, LengthGNSS);

FileNew = fopen('../Data/201312251133/gnss_new.txt', 'w');
for i = 1 : LengthGNSS
    
    for j = 1 : 10
        if SVPseu(j, i) ~= 0
            SVSNR(j, i) = 45;
        end
    end
    
    if PxGNSS(1, i) ~= 0
        Quality(1, i) = 3;
    end

    
    fprintf(FileNew, '%f\t', TimeGNSS(i));
    fprintf(FileNew, '%f\t', RcvTime(i));
    fprintf(FileNew, '%d\t', Quality(i));
    fprintf(FileNew, '%d\t', SVs(i));
    fprintf(FileNew, '%f\t', LaGNSS(i));
    fprintf(FileNew, '%f\t', LonGNSS(i));
    fprintf(FileNew, '%f\t', AltGNSS(i));
    fprintf(FileNew, '%f\t', PDOP(i));
    fprintf(FileNew, '%f\t', PxGNSS(i));
    fprintf(FileNew, '%f\t', PyGNSS(i));
    fprintf(FileNew, '%f\t', PzGNSS(i));
    fprintf(FileNew, '%f\t', VxGNSS(i));
    fprintf(FileNew, '%f\t', VyGNSS(i));
    fprintf(FileNew, '%f\t', VzGNSS(i));
    for j = 1 : 10
        fprintf(FileNew, '%d\t', SVNo(j, i));
        fprintf(FileNew, '%d\t', SVSNR(j, i));
        fprintf(FileNew, '%f\t', SVPseu(j, i));
        fprintf(FileNew, '%f\t', SVPseuRate(j, i));
        fprintf(FileNew, '%f\t', SVPx(j, i));
        fprintf(FileNew, '%f\t', SVPy(j, i));
        fprintf(FileNew, '%f\t', SVPz(j, i));
        fprintf(FileNew, '%f\t', SVVx(j, i));
        fprintf(FileNew, '%f\t', SVVy(j, i));
        fprintf(FileNew, '%f\t', SVVz(j, i));
    end
    fprintf(FileNew, '\r\n');
end

fclose(FileNew);




