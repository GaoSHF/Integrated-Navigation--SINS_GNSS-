% Position (rad), altitude (rad), angular velocity (rad/s), acceleration
% (m/s^2), T (s)
% height_switch: 1 -- height on, 0 -- height off
function [la_kf, lon_kf, h_kf, v_kf, pitch_kf, roll_kf, yaw_kf, time_kf, time_es, Xes, sqrtP] = ...
    qukf_rk4(la0, lon0, h0, ve0, vn0, vu0, pitch0, roll0, yaw0, ...
    data, ...
    T_ins, T_kf, mx0, Cx0, Q, R0, height_switch, Hinfinity_switch)

% Maximum channel number
RECEIVER_CHANNEL = 10;

% GNSS receiver clock drift Markov correlation time (s)
corrTimeGnssClock = 200;

% Global definition
wie = 7.292115147e-5; % rad/s
Re = 6378245; % Earth radius, m
e = 1 / 298.3; % Earth eccentrity
g0 = 9.7803267714; % m/s^2
gk1 = 0.00193185138639;
gk2 = 0.00669437999013;

%%%%%%%%%%%%%%%%%%%% Import data result
time = data( : , 1);

% Gyroscope data (rad/s)
w_ib_b = data( : , 2 : 4)';
% Accelerometer data (m/s^2)
f_b = data( : , 5 : 7)';

%fixQuality = data( : , 8)';
svNumber = data( : , 9)';

%la_gps = data( : , 10)';
%lon_gps = data( : , 11)';
%h_gps = data( : , 12)';
%v_gps = data( : , 13 : 15)';

channelNo = zeros(length(svNumber), 10)';
channelSNR = zeros(length(svNumber), 10)';
channelPseu = zeros(length(svNumber), 10)';
channelPseuRate = zeros(length(svNumber), 10)';
channelPx = zeros(length(svNumber), 10)';
channelPy = zeros(length(svNumber), 10)';
channelPz = zeros(length(svNumber), 10)';
channelVx = zeros(length(svNumber), 10)';
channelVy = zeros(length(svNumber), 10)';
channelVz = zeros(length(svNumber), 10)';
for i = 1 : RECEIVER_CHANNEL
    channelNo(i, : ) = data( : , 16 + (i - 1) * 10)';
    channelSNR(i, : ) = data( : , 17 + (i - 1) * 10)';
    channelPseu(i, : ) = data( : , 18 + (i - 1) * 10)';
    channelPseuRate(i, : ) = data( : , 19 + (i - 1) * 10)';
    channelPx(i, : ) = data( : , 20 + (i - 1) * 10)';
    channelPy(i, : ) = data( : , 21 + (i - 1) * 10)';
    channelPz(i, : ) = data( : , 22 + (i - 1) * 10)';
    channelVx(i, : ) = data( : , 23 + (i - 1) * 10)';
    channelVy(i, : ) = data( : , 24 + (i - 1) * 10)';
    channelVz(i, : ) = data( : , 25 + (i - 1) * 10)';
end




% GPS data length
len_kf = length(time);
%len_kf = 1000;

%%%%%%%%%%%%%%%%%%%% Declaration of strapdown navigation parameter

% Velocity
v_kf = zeros(3, len_kf);
v_kf(1 : 3, 1) = [ve0; vn0; vu0];

% Geographical position
la_kf = zeros(1, len_kf); la_kf(1, 1) = la0;
lon_kf = zeros(1, len_kf); lon_kf(1, 1) = lon0;
h_kf = zeros(1, len_kf); h_kf(1, 1) = h0;

% Attitude
roll_kf = zeros(1, len_kf); roll_kf(1, 1) = roll0;
pitch_kf = zeros(1, len_kf); pitch_kf(1, 1) = pitch0;
yaw_kf = zeros(1, len_kf); yaw_kf(1, 1) = yaw0;



Qua = [0; 0; 0; 0];
Qua(1) = cos(yaw0 / 2) * cos(pitch0 / 2) * cos(roll0 / 2) + sin(yaw0 / 2) * sin(pitch0 / 2) * sin(roll0 / 2);
Qua(2) = cos(yaw0 / 2) * sin(pitch0 / 2) * cos(roll0 / 2) + sin(yaw0 / 2) * cos(pitch0 / 2) * sin(roll0 / 2);
Qua(3) = cos(yaw0 / 2) * cos(pitch0 / 2) * sin(roll0 / 2) - sin(yaw0 / 2) * sin(pitch0 / 2) * cos(roll0 / 2);
Qua(4) = cos(yaw0 / 2) * sin(pitch0 / 2) * sin(roll0 / 2) - sin(yaw0 / 2) * cos(pitch0 / 2) * cos(roll0 / 2);

Ctb = [Qua(1) ^ 2 + Qua(2) ^ 2 - Qua(3) ^ 2 - Qua(4) ^ 2,   2 * (Qua(2) * Qua(3) + Qua(1) * Qua(4)),    2 * (Qua(2) * Qua(4) - Qua(1) * Qua(3));
        2 * (Qua(2) * Qua(3) - Qua(1) * Qua(4)),            Qua(1)^2-Qua(2)^2+Qua(3)^2-Qua(4)^2,        2*(Qua(3)*Qua(4)+Qua(1)*Qua(2));
        2*(Qua(2)*Qua(4)+Qua(1)*Qua(3)),                    2*(Qua(3)*Qua(4)-Qua(1)*Qua(2)),            Qua(1)^2-Qua(2)^2-Qua(3)^2+Qua(4)^2];

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Quaternion based tightly coupled  UKF parameter
% Xdot = F * X + G * W -->     X(k + 1) = F(X(k)) + Ka * W
% Z = H(X) + V -->     Z(k) = H(X(k)) + V


% Xes: Estimation of system state
% Element : Quaternion element 1 (Ctp, from ideal navigation coordinate to platform coordinate / actual navigation coordinate)
%			Quaternion element 2
%			Quaternion element 3
%			Quaternion element 4
%           Velocity error at east axis(m / s)
%			Velocity error at north axis
%           Velocity error at up axis
%           Latitude error(rad)
%			Longitude error
%           height error(m)
%			Gyroscope accNoise at east axis(rad / s)
%			Gyroscope accNoise at north axis
%           Gyroscope accNoise at up axis
%           Accelerometer accNoise at east axis(m ^ 2 / s)
%			Accelerometer accNoise at north axis
%           Accelerometer accNoise at up axis
%           GNSS receiver timer deviation caused position error (m)
%           GNSS receiver timer frequency drift caused velocity error (m/s)
Xes = zeros(18, 1);
P = zeros(18, 18, 1);


% Q: Variance of System noise W
% Element : Gyroscope noise at x axis (rad/s)
%			Gyroscope noise at y axis
%        	Gyroscope noise at z axis
%       	Acceleration random error at x axis (m/s^2)
%			Acceleration random error at y axis
%        	Acceleration random error at z axis
%        	GNSS receiver timer frequency drift caused velocity error noise (m/s)



% Z: Observation
% Element : Channel 1 Pseudorange error (m)
%			Channel 2 Pseudorange error (m)
%			.
%			.
%			.
%			Channel n Pseudorange error (m)
%           Channel 1 Pseudorange rate error (m/s)
%           Channel 2 Pseudorange rate error (m/s)
%			.
%			.
%			.
%           Channel n Pseudorange rate error (m/s)



% R: Observation noise variance
% Element : Channel 1 Pseudorange noise (m)
%			Channel 2 Pseudorange noise (m)
%			.
%			.
%			.
%			Channel n Pseudorange noise (m)
%           Channel 1 Pseudorange rate noise (m/s)
%           Channel 2 Pseudorange rate noise (m/s)
%			.
%			.
%			.
%           Channel n Pseudorange rate noise (m/s)
 
 
%% Tightly coupled Unscented Kalman Filter using quaternion

% Initial condition
Xes( : , 1) = mx0;
P( : , : , 1) = Cx0;
Sq = chol(Q)';

time_es = zeros(1, 1);
time_kf = zeros(1, 1);
count_es = 0;
for count_kf = 1 : len_kf
    % Record time
    time_kf(count_kf) = time(count_kf);
    
    % Restore old Ctb
    CtbOld = Ctb;
    
    %%%%%%% Strapdown navigation algorithm 
    Rm = Re / (1 + 2 * e - 3 * e * sin(la_kf(1, count_kf))^2); % Radius of meridian plane
    Rn = Re / (1 - e * sin(la_kf(1, count_kf))^2); % Radius of prime vertical plane
    
    w_ie_t = [0; wie * cos(la_kf(1, count_kf)); wie * sin(la_kf(1, count_kf))];
    w_et_t = [-v_kf(2, count_kf) / (Rm + h_kf(1, count_kf)); 
                v_kf(1, count_kf) / (Rn + h_kf(1, count_kf)); 
                v_kf(1, count_kf) / (Rn + h_kf(1, count_kf)) * tan(la_kf(1, count_kf))];

    % Refresh velocity, E-N-U coordinate system
    f_t = Ctb' * f_b(:, count_kf);

    v_kf(1, count_kf + 1) = (f_t(1) + ...
                            (2 * w_ie_t(3) + w_et_t(3)) * v_kf(2, count_kf) - ...
                            (2 * w_ie_t(2) + w_et_t(2)) * v_kf(3, count_kf)) * ...
                            T_ins + v_kf(1, count_kf);
    v_kf(2, count_kf + 1) = (f_t(2) - ...
                            (2 * w_ie_t(3) + w_et_t(3)) * v_kf(1, count_kf) + ...
                            (2 * w_ie_t(1) + w_et_t(1)) * v_kf(3, count_kf)) * ...
                            T_ins + v_kf(2, count_kf);

    if height_switch == 1
        g = g0 * (1 + gk1 * (sin(la_kf(1, count_kf))) ^ 2) * (1 - 2 * h_kf(1, count_kf) / Re) / sqrt(1 - gk2 * (sin(la_kf(1, count_kf))) ^ 2);

        v_kf(3, count_kf + 1) = (f_t(3) + ...
                            (2 * w_ie_t(2) + w_et_t(2)) * v_kf(1, count_kf) - ...
                            (2 * w_ie_t(1) + w_et_t(1)) * v_kf(2, count_kf) - g) * ...
                            T_ins + v_kf(3, count_kf);
    else
        v_kf(3, count_kf + 1) = v_kf(3, count_kf);
    end

    % Location
    la_kf(1, count_kf + 1) = v_kf(2, count_kf + 1) / (Rm + h_kf(1, count_kf)) * T_ins + la_kf(1, count_kf);
    lon_kf(1, count_kf + 1) = v_kf(1, count_kf + 1) / ((Rn + h_kf(1, count_kf)) * cos(la_kf(1, count_kf + 1))) * T_ins + lon_kf(1, count_kf);
    h_kf(1, count_kf + 1) = v_kf(3, count_kf + 1) * T_ins + h_kf(1, count_kf);

    % Refresh quaternion
    w_tb_b = w_ib_b(:, count_kf) - Ctb * (w_ie_t + w_et_t);

    seita_delta = T_ins * ...
                            [0          -w_tb_b(1)           -w_tb_b(2)         -w_tb_b(3);
                            w_tb_b(1)       0               w_tb_b(3)            -w_tb_b(2);
                            w_tb_b(2)    -w_tb_b(3)             0               w_tb_b(1)
                            w_tb_b(3)    w_tb_b(2)          -w_tb_b(1)              0];

    seita_delta_zero = sqrt(seita_delta(1, 2) ^ 2 + seita_delta(1, 3) ^ 2 + seita_delta(1, 4) ^ 2);

    Qua = (cos(seita_delta_zero / 2) * eye(4) + sin(seita_delta_zero / 2) / seita_delta_zero * seita_delta) * Qua;

    % Refresh Ctb
    Ctb = [Qua(1) ^ 2 + Qua(2) ^ 2 - Qua(3) ^ 2 - Qua(4) ^ 2,   2 * (Qua(2) * Qua(3) + Qua(1) * Qua(4)),    2 * (Qua(2) * Qua(4) - Qua(1) * Qua(3));
            2 * (Qua(2) * Qua(3) - Qua(1) * Qua(4)),            Qua(1)^2-Qua(2)^2+Qua(3)^2-Qua(4)^2,        2*(Qua(3)*Qua(4)+Qua(1)*Qua(2));
            2*(Qua(2)*Qua(4)+Qua(1)*Qua(3)),                    2*(Qua(3)*Qua(4)-Qua(1)*Qua(2)),            Qua(1)^2-Qua(2)^2-Qua(3)^2+Qua(4)^2];

        
    % Refresh attitude
    pitch_kf(1, count_kf + 1) = asin(Ctb(2, 3)); % -pi/2 to pi/2

    roll_kf(1, count_kf + 1) = atan2(-Ctb(1, 3), Ctb(3, 3)); % -pi to pi

    yaw_kf(1, count_kf + 1) = atan2(Ctb(2, 1), Ctb(2, 2)); % 0 to 2*pi
    if yaw_kf(1, count_kf + 1) < 0
        yaw_kf(1, count_kf + 1) = yaw_kf(1, count_kf + 1) + 2 * pi;
    end
    
    
    
    
    %%%%%%%% Unscented Kalman Filter  
    if (svNumber(count_kf) ~= 0)
        
        NumberAcquired = svNumber(count_kf);
        
        count_es = count_es + 1;
        %disp(['count_es = ', num2str(count_es), '    ', 'count_kf = ', num2str(count_kf)]);
        
        % Recover new Ctb
        CtbNew = Ctb;
      	Ctb = CtbOld;
        
        
        ve = v_kf(1, count_kf);
        vn = v_kf(2, count_kf);
        vu = v_kf(3, count_kf);
        la = la_kf(1, count_kf);
        lon = lon_kf(1, count_kf);
        h = h_kf(1, count_kf);
        
        

        % Get R
        R = zeros(2 * NumberAcquired, 2 * NumberAcquired);
        for i = 0 : NumberAcquired - 1
            R(2 * NumberAcquired - i, 2 * NumberAcquired - i) = R0(2, 2);
        end
        for i = 0 : NumberAcquired - 1
            R(1 + i, 1 + i) = R0(1, 1);
        end
        

        % Get Z
        Z = zeros(2 * NumberAcquired, 1);
        
        veGetZ = ve;
        vnGetZ = vn;
        vuGetZ = vu;
        laGetZ = la;
        lonGetZ = lon;
        hGetZ = h;

        % Transfer SINS location to earth x-y-z
        ex2 = (2 - e) * e / ((1 - e) * (1 - e));
        N = Re * sqrt(1 + ex2) / sqrt(1 + ex2 * cos(laGetZ) * cos(laGetZ));
        positionSINS = [(N + hGetZ) * cos(laGetZ) * cos(lonGetZ);
                        (N + hGetZ) * cos(laGetZ) * sin(lonGetZ);
                        ((1 - e) * (1 - e) * N + hGetZ) * sin(laGetZ)];


        % Transfer SINS velocity from E-N-U to X-Y-Z
        Cte = [cos(pi / 2 + lonGetZ),      sin(pi / 2 + lonGetZ),      0;
                -cos(pi / 2 - laGetZ) * sin(pi / 2 + lonGetZ),    cos(pi / 2 - laGetZ) * cos(pi / 2 + lonGetZ),    sin(pi / 2 - laGetZ);
                sin(pi / 2 - laGetZ) * sin(pi / 2 + lonGetZ),     -sin(pi / 2 - laGetZ) * cos(pi / 2 + lonGetZ),    cos(pi / 2 - laGetZ)];

        venuSINS = [veGetZ;
                    vnGetZ;
                    vuGetZ];

        vxyzSINS = Cte * venuSINS;


        % Measurements
        for i = 1 : NumberAcquired
            pseudorangeSINS = 0;
            pseudorangeSINS = pseudorangeSINS + (positionSINS(1) - channelPx(i, count_kf)) ^ 2;
            pseudorangeSINS = pseudorangeSINS + (positionSINS(2) - channelPy(i, count_kf)) ^ 2;
            pseudorangeSINS = pseudorangeSINS + (positionSINS(3) - channelPz(i, count_kf)) ^ 2;
            pseudorangeSINS = sqrt(pseudorangeSINS);
            Z(i, 1) = pseudorangeSINS - channelPseu(i, count_kf);

            pseudorangeRateSINS = 0;
            pseudorangeRateSINS = pseudorangeRateSINS + (positionSINS(1) - channelPx(i, count_kf)) * (vxyzSINS(1) - channelVx(i, count_kf));
            pseudorangeRateSINS = pseudorangeRateSINS + (positionSINS(2) - channelPy(i, count_kf)) * (vxyzSINS(2) - channelVy(i, count_kf));
            pseudorangeRateSINS = pseudorangeRateSINS + (positionSINS(3) - channelPz(i, count_kf)) * (vxyzSINS(3) - channelVz(i, count_kf));
            pseudorangeRateSINS = pseudorangeRateSINS / pseudorangeSINS;
            Z(i + NumberAcquired) = pseudorangeRateSINS - channelPseuRate(i, count_kf);
        end
        
        
        % Sigma point
        weight_m = zeros(1, 2 * 18 + 1);
        weight_c = zeros(1, 2 * 18 + 1);
        XesSigma = zeros(18, 2 * 18 + 1);
        
        
        alpha = 0.6; % 1e-4 to 1, 0.518 to 1 will make lamda > 0 for n = 18, beta = 2 and kappa = 0
        beta = 2; % Best for Gauss white noise
        kappa = 0;
        lamda = alpha * alpha * (18 + kappa) - 18;
        weight_m(1) = lamda / (18 + lamda);
        weight_c(1) = lamda / (18 + lamda) + (1 - alpha * alpha + beta);
        
        
        %{
        lamda = 1;
        weight_m(1) = lamda / (18 + lamda);
        weight_c(1) = lamda / (18 + lamda);
        %}
        
        XesSigma( : , 1) = Xes( : , count_es);
        upperTriMatrix = chol(P( :, : , count_es));
        for i = 1 : 18
            weight_m(i + 1) = 1 / (2 * (18 + lamda));
            weight_m(i + 1 + 18) = 1 / (2 * (18 + lamda));
            
            weight_c(i + 1) = weight_m(i + 1);
            weight_c(i + 1 + 18) = weight_m(i + 1 + 18);
            
            temp = sqrt((18 + lamda)) * upperTriMatrix(i, : )';
            % quaternion part
            MQ = [temp(1, 1),   -temp(2, 1),    -temp(3, 1),     -temp(4, 1);
                     temp(2, 1),    temp(1, 1),     -temp(4, 1),     temp(3, 1);
                     temp(3, 1),    temp(4, 1),     temp(1, 1),      -temp(2, 1);
                     temp(4, 1),    -temp(3, 1),    temp(2, 1),      temp(1, 1)];
                 
            MQinv = [temp(1, 1),   temp(2, 1),    temp(3, 1),     temp(4, 1);
                     -temp(2, 1),    temp(1, 1),     temp(4, 1),     -temp(3, 1);
                     -temp(3, 1),    -temp(4, 1),     temp(1, 1),      temp(2, 1);
                     -temp(4, 1),    temp(3, 1),    -temp(2, 1),      temp(1, 1)];
                 
            XesSigma(1 : 4, i + 1) = MQ * XesSigma(1 : 4, 1);
            XesSigma(1 : 4, i + 1 + 18) = MQinv * XesSigma(1 : 4, 1);
            XesSigma(1, i + 1) = sqrt(1 - XesSigma(2, i + 1)^2 - XesSigma(3, i + 1)^2 - XesSigma(4, i + 1)^2);
            XesSigma(1, i + 1 + 18) = sqrt(1 - XesSigma(2, i + 1 + 18)^2 - XesSigma(3, i + 1 + 18)^2 - XesSigma(4, i + 1 + 18)^2);
            
            % un-quaternion part
            XesSigma(5 : 18, i + 1) = XesSigma(5 : 18, 1) + temp(5 : 18, 1);
            XesSigma(5 : 18, i + 1 + 18) = XesSigma(5 : 18, 1) - temp(5 : 18, 1);
        end
        
        Cpb = Ctb;
        

        % One step estimation: XesOneStep = sum(weight_m * F(XesSigma))
        XesOneStep = zeros(18, 1);
        XesSigmaOneStep = zeros(18, 2 * 18 + 1);
        M = zeros(4, 4);
        for i = 1 : 2 * 18 + 1           
            % XesOneStep using RK4
            % Quaternion part
            QuaptRK4 = zeros(4, 1);
            k_Quapt = zeros(4, 4);
            
            % velocity part
            deltaVRK4 = zeros(3, 1);
            k_deltaV = zeros(3, 4);
            
            % latitude
            deltaLaRK4 = 0;
            k_deltaLa = zeros(1, 4);
            
            % longitude
            %deltaLonRK4 = 0;
            k_deltaLon = zeros(1, 4);
            
            % height
            deltaHRK4 = 0;
            k_deltaH = zeros(1, 4);
            
            % GNSS receiver clock caused position error
            %gnssErrorPRK4 = 0;
            k_gnssErrorP = zeros(1, 4);
            
            % GNSS receiver clock drift caused velocity error
            gnssErrorVRK4 = 0;
            k_gnssErrorV = zeros(1, 4);
            
            for j = 1 : 4
                switch j
                    case 1
                        QuaptRK4 = XesSigma(1 : 4, i);
                        deltaVRK4 = XesSigma(5 : 7, i);
                        deltaLaRK4 = XesSigma(8, i);
                        deltaLonRK4 = XesSigma(9, i);
                        deltaHRK4 = XesSigma(10, i);
                        gnssErrorPRK4 = XesSigma(17, i);
                        gnssErrorVRK4 = XesSigma(18, i);
                    case 2
                        temp = 1 / 2 * T_kf * k_Quapt( : , 1);
                        MQ = [temp(1, 1),   -temp(2, 1),    -temp(3, 1),     -temp(4, 1);
                             temp(2, 1),    temp(1, 1),     -temp(4, 1),     temp(3, 1);
                             temp(3, 1),    temp(4, 1),     temp(1, 1),      -temp(2, 1);
                             temp(4, 1),    -temp(3, 1),    temp(2, 1),      temp(1, 1)];
                        QuaptRK4 = MQ * XesSigma(1 : 4, i);
                        QuaptRK4(1, 1) = sqrt(1 - QuaptRK4(2, 1)^2 - QuaptRK4(3, 1)^2 - QuaptRK4(4, 1)^2);
                        
                        deltaVRK4 = XesSigma(5 : 7, i) + 1 / 2 * T_kf * k_deltaV( : , 1);
                        deltaLaRK4 = XesSigma(8, i) + 1 / 2 * T_kf * k_deltaLa(1, 1);
                        deltaLonRK4 = XesSigma(9, i) + 1 / 2 * T_kf * k_deltaLon(1, 1);
                        deltaHRK4 = XesSigma(10, i) + 1 / 2 * T_kf * k_deltaH(1, 1);
                        gnssErrorPRK4 = XesSigma(17, i) + 1 / 2 * T_kf * k_gnssErrorP(1, 1);
                        gnssErrorVRK4 = XesSigma(18, i) + 1 / 2 * T_kf * k_gnssErrorV(1, 1);
                    case 3
                        temp = 1 / 2 * T_kf * k_Quapt( : , 2);
                        MQ = [temp(1, 1),   -temp(2, 1),    -temp(3, 1),     -temp(4, 1);
                             temp(2, 1),    temp(1, 1),     -temp(4, 1),     temp(3, 1);
                             temp(3, 1),    temp(4, 1),     temp(1, 1),      -temp(2, 1);
                             temp(4, 1),    -temp(3, 1),    temp(2, 1),      temp(1, 1)];
                        QuaptRK4 = MQ * XesSigma(1 : 4, i);
                        QuaptRK4(1, 1) = sqrt(1 - QuaptRK4(2, 1)^2 - QuaptRK4(3, 1)^2 - QuaptRK4(4, 1)^2);
                        
                        deltaVRK4 = XesSigma(5 : 7, i) + 1 / 2 * T_kf * k_deltaV( : , 2);
                        deltaLaRK4 = XesSigma(8, i) + 1 / 2 * T_kf * k_deltaLa(1, 2);
                        deltaLonRK4 = XesSigma(9, i) + 1 / 2 * T_kf * k_deltaLon(1, 2);
                        deltaHRK4 = XesSigma(10, i) + 1 / 2 * T_kf * k_deltaH(1, 2);
                        gnssErrorPRK4 = XesSigma(17, i) + 1 / 2 * T_kf * k_gnssErrorP(1, 2);
                        gnssErrorVRK4 = XesSigma(18, i) + 1 / 2 * T_kf * k_gnssErrorV(1, 2);
                    case 4
                        temp = T_kf * k_Quapt( : , 3);
                        MQ = [temp(1, 1),   -temp(2, 1),    -temp(3, 1),     -temp(4, 1);
                             temp(2, 1),    temp(1, 1),     -temp(4, 1),     temp(3, 1);
                             temp(3, 1),    temp(4, 1),     temp(1, 1),      -temp(2, 1);
                             temp(4, 1),    -temp(3, 1),    temp(2, 1),      temp(1, 1)];
                        QuaptRK4 = MQ * XesSigma(1 : 4, i);
                        QuaptRK4(1, 1) = sqrt(1 - QuaptRK4(2, 1)^2 - QuaptRK4(3, 1)^2 - QuaptRK4(4, 1)^2);
                        
                        deltaVRK4 = XesSigma(5 : 7, i) + T_kf * k_deltaV( : , 3);
                        deltaLaRK4 = XesSigma(8, i) + T_kf * k_deltaLa(1, 3);
                        deltaLonRK4 = XesSigma(9, i) + T_kf * k_deltaLon(1, 3);
                        deltaHRK4 = XesSigma(10, i) + T_kf * k_deltaH(1, 3);
                        gnssErrorPRK4 = XesSigma(17, i) + T_kf * k_gnssErrorP(1, 3);
                        gnssErrorVRK4 = XesSigma(18, i) + T_kf * k_gnssErrorV(1, 3);
                end
                
                Ctp = [QuaptRK4(1)^2 + QuaptRK4(2)^2 - QuaptRK4(3)^2 - QuaptRK4(4)^2, ...
                    2 * (QuaptRK4(2) * QuaptRK4(3) + QuaptRK4(1) * QuaptRK4(4)), ...
                    2 * (QuaptRK4(2) * QuaptRK4(4) - QuaptRK4(1) * QuaptRK4(3));
                    2 * (QuaptRK4(2) * QuaptRK4(3) - QuaptRK4(1) * QuaptRK4(4)), ...
                    QuaptRK4(1)^2 - QuaptRK4(2)^2 + QuaptRK4(3)^2 - QuaptRK4(4)^2, ...
                    2 * (QuaptRK4(3) * QuaptRK4(4) + QuaptRK4(1) * QuaptRK4(2));
                    2 * (QuaptRK4(2) * QuaptRK4(4) + QuaptRK4(1) * QuaptRK4(3)), ...
                    2 * (QuaptRK4(3) * QuaptRK4(4) - QuaptRK4(1) * QuaptRK4(2)), ...
                    QuaptRK4(1)^2 - QuaptRK4(2)^2 - QuaptRK4(3)^2 + QuaptRK4(4)^2];

                B = [-QuaptRK4(2) / 2,    -QuaptRK4(3) / 2,     -QuaptRK4(4) / 2;
                     QuaptRK4(1) / 2,     -QuaptRK4(4) / 2,     QuaptRK4(3) / 2;
                     QuaptRK4(4) / 2,     QuaptRK4(1) / 2,      -QuaptRK4(2) / 2;
                     -QuaptRK4(3) / 2,    QuaptRK4(2) / 2,      QuaptRK4(1) / 2];
                
                
                w_ie_t = [0; 
                    wie * cos(la); 
                    wie * sin(la)];
                w_et_t = [-vn / (Rm + h); 
                    ve / (Rn + h); 
                    ve / (Rn + h) * tan(la)];
                 
                
                delta_w_ie_t = [0;
                    -wie * sin(la) * deltaLaRK4;
                    wie * cos(la) * deltaLaRK4];

                delta_w_et_t = [-1 / (Rm + h) * deltaVRK4(2) + 1 / (Rm + h) / (Rm + h) * vn * deltaHRK4;
                    1 / (Rn + h) * deltaVRK4(1) - 1 / (Rn + h) / (Rn + h) * ve * deltaHRK4;
                    1 / (Rn + h) * tan(la) * deltaVRK4(1) + ...
				1 / (Rn + h) / cos(la) / cos(la) * ve * deltaLaRK4 - ...
				1 / (Rn + h) / (Rn + h) * tan(la) * ve * deltaHRK4];
                

                % Qdot = B * (I - Ctp) * witt - B * Cbp * gyroDrift
                k_Quapt( : , j) = B * (eye(3) - Ctp) * (w_ie_t + w_et_t) - B * Cpb' * XesSigma(11 : 13, i);

                % deltaVdot = (I - Cpt) * Cbp * fb - (2 * wiet + wett) X deltaV - (2 * deltawiet + deltawett) X V - (2 * deltawiet + deltawett) X deltaV + Cbp * accBias + deltagt
                k_deltaV( : , j) = (eye(3) - Ctp') * Cpb' * f_b(:, count_kf) - ...
                    cross((2 * w_ie_t + w_et_t), deltaVRK4) - ...
                    cross((2 * delta_w_ie_t + delta_w_et_t), [ve; vn; vu]) - ...
                    cross((2 * delta_w_ie_t + delta_w_et_t), deltaVRK4) + ...
                    Cpb' * XesSigma(14 : 16, i);
                
                % deltaladot = (1 / (Rm + h)) * deltaVn - (Vn / (Rm + h)^2) * deltah
                k_deltaLa(1, j) = (1 / (Rm + h)) * deltaVRK4(2) - (vn / (Rm + h)^2) * deltaHRK4;
                
                % deltalondot = (sec(la) / (Rn + h)) * deltaVe + (Ve * tan(la) * sec(la) / (Rn + h)) * deltala - (Ve * sec(la) / (Rm + h) ^ 2) * deltah
                k_deltaLon(1, j) = (sec(la) / (Rn + h)) * deltaVRK4(1) + (ve * tan(la) * sec(la) / (Rn + h)) * deltaLaRK4 - (ve * sec(la) / (Rm + h) ^ 2) * deltaHRK4;
                
                % deltahdot = deltaVu
                k_deltaH(1, j) = deltaVRK4(3);
                
                % gnssErrorPdot = gnssErrorVdot
                k_gnssErrorP(1, j) = gnssErrorVRK4;
                
                % gnssErrorVdot = -1 / timerDriftCorreTime * gnssErrorVdot
                k_gnssErrorV(1, j) = -1 / corrTimeGnssClock * gnssErrorVRK4;
                
            end % j
            
            temp = T_kf / 6 * (k_Quapt( : , 1) + 2 * k_Quapt( : , 2) + 2 * k_Quapt( : , 3) + k_Quapt( : , 4));
            MQ = [temp(1, 1),   -temp(2, 1),    -temp(3, 1),     -temp(4, 1);
                     temp(2, 1),    temp(1, 1),     -temp(4, 1),     temp(3, 1);
                     temp(3, 1),    temp(4, 1),     temp(1, 1),      -temp(2, 1);
                     temp(4, 1),    -temp(3, 1),    temp(2, 1),      temp(1, 1)];
            XesSigmaOneStep(1 : 4, i) = MQ * QuaptRK4(1 : 4, 1);
            XesSigmaOneStep(1, i) = sqrt(1 - XesSigmaOneStep(2, i)^2 - XesSigmaOneStep(3, i)^2 - XesSigmaOneStep(4, i)^2);
            
            XesSigmaOneStep(5 : 7, i) = deltaVRK4 + T_kf / 6 * (k_deltaV( : , 1) + 2 * k_deltaV( : , 2) + 2 * k_deltaV( : , 3) + k_deltaV( : , 4));

            XesSigmaOneStep(8, i) = deltaLaRK4 + T_kf / 6 * (k_deltaLa(1) + 2 * k_deltaLa(2) + 2 * k_deltaLa(3) + k_deltaLa(4));
            
            XesSigmaOneStep(9, i) = deltaLonRK4 + T_kf / 6 * (k_deltaLon(1) + 2 * k_deltaLon(2) + 2 * k_deltaLon(3) + k_deltaLon(4));
            
            XesSigmaOneStep(10, i) = deltaHRK4 + T_kf / 6 * (k_deltaH(1) + 2 * k_deltaH(2) + 2 * k_deltaH(3) + k_deltaH(4));
            
            XesSigmaOneStep(11, i) = XesSigma(11, i);
            XesSigmaOneStep(12, i) = XesSigma(12, i);
            XesSigmaOneStep(13, i) = XesSigma(13, i);
            
            XesSigmaOneStep(14, i) = XesSigma(14, i);
            XesSigmaOneStep(15, i) = XesSigma(15, i);
            XesSigmaOneStep(16, i) = XesSigma(16, i);
            
            XesSigmaOneStep(17, i) = gnssErrorPRK4 + T_kf / 6 * (k_gnssErrorP(1) + 2 * k_gnssErrorP(2) + 2 * k_gnssErrorP(3) + k_gnssErrorP(4));
            
            XesSigmaOneStep(18, i) = gnssErrorVRK4 + T_kf / 6 * (k_gnssErrorV(1) + 2 * k_gnssErrorV(2) + 2 * k_gnssErrorV(3) + k_gnssErrorV(4));
            
            
            % Get XesOneStep
            % quaternion part
            M = M + weight_m(i) * XesSigmaOneStep(1 : 4, i) * XesSigmaOneStep(1 : 4, i)';
            
            % un-quaternion part
            XesOneStep(5 : 18, 1) = XesOneStep(5 : 18, 1) + weight_m(i) * XesSigmaOneStep(5 : 18, i);

        end % i
        
        % XesOneStep for quaternion part q = argmax(q'Mq) =
        % eigvec(max(eig(M)))
        [eigenvectors, eigenvalues] = eig(M);
        [~, index] = max(max(eigenvalues));
        XesOneStep(1 : 4, 1) = eigenvectors( : , index);
        
        
        % Get PesOneStep
        PesOneStep = zeros(18, 18);
        deltaXesOneStep = zeros(18, 1);
        for i = 1 : 2 * 18 + 1
            MQ = [XesOneStep(1, 1),   XesOneStep(2, 1),    XesOneStep(3, 1),     XesOneStep(4, 1);
                 -XesOneStep(2, 1),    XesOneStep(1, 1),     XesOneStep(4, 1),     -XesOneStep(3, 1);
                 -XesOneStep(3, 1),    -XesOneStep(4, 1),     XesOneStep(1, 1),      XesOneStep(2, 1);
                 -XesOneStep(4, 1),    XesOneStep(3, 1),    -XesOneStep(2, 1),      XesOneStep(1, 1)];
            
            deltaXesOneStep(1 : 4, 1) = MQ * ...
                [XesSigmaOneStep(1, i); XesSigmaOneStep(2, i); XesSigmaOneStep(3, i); XesSigmaOneStep(4, i)];
            
            deltaXesOneStep(5 : 18, 1) = XesSigmaOneStep(5 : 18, i) - XesOneStep(5 : 18, 1);
            
            PesOneStep = PesOneStep + weight_c(i) * deltaXesOneStep(:) * deltaXesOneStep';
        end
        % Process noise transfer matrix
        G = [zeros(4, 3),	zeros(4, 3),    zeros(4, 1);
             zeros(3, 3),   zeros(3, 3),	zeros(3, 1);
             zeros(3, 3),   zeros(3, 3),	zeros(3, 1);
             eye(3),        zeros(3, 3),    zeros(3, 1);
             zeros(3, 3),   eye(3),         zeros(3, 1);
             zeros(1, 3),   zeros(1, 3),    0;
             zeros(1, 3),   zeros(1, 3),    1];
        G(18, 7) = 1;
        Ka = G * T_kf;
        PesOneStep = PesOneStep + Ka * Q * Ka';
        

        % Sigma points of XesOneStep (Only for UKF with additive noise)
        XesOneStepSigma = zeros(18, 4 * 18 + 1);
        XesOneStepSigma( : , 1 : 2 * 18 + 1) = XesSigmaOneStep;
        for i = 1 : 18
            temp = sqrt((18 + lamda)) * Ka * Sq * Ka';
            % quaternion part
            MQ = [temp(1, 1),   -temp(2, 1),    -temp(3, 1),     -temp(4, 1);
                     temp(2, 1),    temp(1, 1),     -temp(4, 1),     temp(3, 1);
                     temp(3, 1),    temp(4, 1),     temp(1, 1),      -temp(2, 1);
                     temp(4, 1),    -temp(3, 1),    temp(2, 1),      temp(1, 1)];
                 
            MQinv = [temp(1, 1),   temp(2, 1),    temp(3, 1),     temp(4, 1);
                     -temp(2, 1),    temp(1, 1),     temp(4, 1),     -temp(3, 1);
                     -temp(3, 1),    -temp(4, 1),     temp(1, 1),      temp(2, 1);
                     -temp(4, 1),    temp(3, 1),    -temp(2, 1),      temp(1, 1)];
                 
            XesOneStepSigma(1 : 4, 2 * 18 + 1 + i) = MQ * XesOneStepSigma(1 : 4, 1);
            XesOneStepSigma(1 : 4, 2 * 18 + 1 + i + 18) = MQinv * XesOneStepSigma(1 : 4, 1);
            XesOneStepSigma(1, 2 * 18 + 1 + i) = ...
                sqrt(1 - ...
                XesOneStepSigma(2, 2 * 18 + 1 + i)^2 - ...
                XesOneStepSigma(3, 2 * 18 + 1 + i)^2 - ...
                XesOneStepSigma(4, 2 * 18 + 1 + i)^2);
            XesOneStepSigma(1, 2 * 18 + 1 + i + 18) = ...
                sqrt(1 - ...
                XesOneStepSigma(2, 2 * 18 + 1 + i + 18)^2 - ...
                XesOneStepSigma(3, 2 * 18 + 1 + i + 18)^2 - ...
                XesOneStepSigma(4, 2 * 18 + 1 + i + 18)^2);
            
            % un-quaternion part
            XesOneStepSigma(5 : 18, 2 * 18 + 1 + i) = XesOneStepSigma(5 : 18, 1) + temp(5 : 18, 1);
            XesOneStepSigma(5 : 18, 2 * 18 + 1 + i + 18) = XesOneStepSigma(5 : 18, 1) - temp(5 : 18, 1);
        end
        
        
        % One step measurements: ZesOneStep = sum(weight_m * H(XesSigma))
        ZesOneStep = zeros(2 * NumberAcquired, 1);
        ZesSigmaOneStep = zeros(2 * NumberAcquired, 2 * 18 + 1);
        for i = 1 : 2 * 18 + 1
            % Prepare to get ZesOneStep
            veGetZ = ve - XesOneStepSigma(5, i);
            vnGetZ = vn - XesOneStepSigma(6, i);
            vuGetZ = vu - XesOneStepSigma(7, i);
            laGetZ = la - XesOneStepSigma(8, i);
            lonGetZ = lon - XesOneStepSigma(9, i);
            hGetZ = h - XesOneStepSigma(10, i);


            % Transfer SINS location to earth x-y-z
            ex2 = (2 - e) * e / ((1 - e) * (1 - e));
            N = Re * sqrt(1 + ex2) / sqrt(1 + ex2 * cos(laGetZ) * cos(laGetZ));
            positionSINS = [(N + hGetZ) * cos(laGetZ) * cos(lonGetZ);
                            (N + hGetZ) * cos(laGetZ) * sin(lonGetZ);
                            ((1 - e) * (1 - e) * N + hGetZ) * sin(laGetZ)];


            % Transfer SINS velocity from E-N-U to X-Y-Z
            Cte = [cos(pi / 2 + lonGetZ),      sin(pi / 2 + lonGetZ),      0;
                    -cos(pi / 2 - laGetZ) * sin(pi / 2 + lonGetZ),    cos(pi / 2 - laGetZ) * cos(pi / 2 + lonGetZ),    sin(pi / 2 - laGetZ);
                    sin(pi / 2 - laGetZ) * sin(pi / 2 + lonGetZ),     -sin(pi / 2 - laGetZ) * cos(pi / 2 + lonGetZ),    cos(pi / 2 - laGetZ)];

            venuSINS = [veGetZ;
                        vnGetZ;
                        vuGetZ];

            vxyzSINS = Cte * venuSINS;


            % Measurements
            for j = 1 : NumberAcquired
                pseudorangeSINS = 0;
                pseudorangeSINS = pseudorangeSINS + (positionSINS(1) - channelPx(j, count_kf)) ^ 2;
                pseudorangeSINS = pseudorangeSINS + (positionSINS(2) - channelPy(j, count_kf)) ^ 2;
                pseudorangeSINS = pseudorangeSINS + (positionSINS(3) - channelPz(j, count_kf)) ^ 2;
                pseudorangeSINS = sqrt(pseudorangeSINS);
                ZesSigmaOneStep(j, i) = pseudorangeSINS - channelPseu(j, count_kf);

                pseudorangeRateSINS = 0;
                pseudorangeRateSINS = pseudorangeRateSINS + (positionSINS(1) - channelPx(j, count_kf)) * (vxyzSINS(1) - channelVx(j, count_kf));
                pseudorangeRateSINS = pseudorangeRateSINS + (positionSINS(2) - channelPy(j, count_kf)) * (vxyzSINS(2) - channelVy(j, count_kf));
                pseudorangeRateSINS = pseudorangeRateSINS + (positionSINS(3) - channelPz(j, count_kf)) * (vxyzSINS(3) - channelVz(j, count_kf));
                pseudorangeRateSINS = pseudorangeRateSINS / pseudorangeSINS;
                ZesSigmaOneStep(j + NumberAcquired, i) = pseudorangeRateSINS - channelPseuRate(j, count_kf);
            end % j
            
            ZesOneStep( : , 1) = ZesOneStep( : , 1) + weight_m(i) * ZesSigmaOneStep( : , i);
        end


        % Get PzesOneStep and PxzesOneStep
        PzesOneStep = zeros(2 * NumberAcquired, 2 * NumberAcquired);
        PxzesOneStep = zeros(18, 2 * NumberAcquired); 
        deltaXesOneStep = zeros(18, 1);
        for i = 1 : 2 * 18 + 1
            MQ = [XesOneStep(1, 1),   XesOneStep(2, 1),    XesOneStep(3, 1),     XesOneStep(4, 1);
                 -XesOneStep(2, 1),    XesOneStep(1, 1),     XesOneStep(4, 1),     -XesOneStep(3, 1);
                 -XesOneStep(3, 1),    -XesOneStep(4, 1),     XesOneStep(1, 1),      XesOneStep(2, 1);
                 -XesOneStep(4, 1),    XesOneStep(3, 1),    -XesOneStep(2, 1),      XesOneStep(1, 1)];
            
            deltaXesOneStep(1 : 4, 1) = MQ * ...
                [XesOneStepSigma(1, i); XesOneStepSigma(2, i); XesOneStepSigma(3, i); XesOneStepSigma(4, i)];
            
            deltaXesOneStep(5 : 18, 1) = XesOneStepSigma(5 : 18, i) - XesOneStep(5 : 18, 1);
            
            PzesOneStep = PzesOneStep + weight_c(i) * (ZesSigmaOneStep( : , i) - ZesOneStep) * (ZesSigmaOneStep( : , i) - ZesOneStep)';
            PxzesOneStep = PxzesOneStep + weight_c(i) * deltaXesOneStep * (ZesSigmaOneStep( : , i) - ZesOneStep)';
        end
        PzesOneStep = PzesOneStep + R;
        
        % Kalman Gain
        K = PxzesOneStep / PzesOneStep;

        % Estimation
        temp = K * (Z(1 : 2 * NumberAcquired) - ZesOneStep);
        MQ = [temp(1, 1),   -temp(2, 1),    -temp(3, 1),     -temp(4, 1);
                 temp(2, 1),    temp(1, 1),     -temp(4, 1),     temp(3, 1);
                 temp(3, 1),    temp(4, 1),     temp(1, 1),      -temp(2, 1);
                 temp(4, 1),    -temp(3, 1),    temp(2, 1),      temp(1, 1)];
        Xes(1 : 4, count_es + 1) = MQ * XesOneStep(1 : 4, 1);
        Xes(1, count_es + 1) = sqrt(1 - Xes(2, count_es + 1)^2 - Xes(3, count_es + 1)^2 - Xes(4, count_es + 1)^2);
        
        Xes(5 : 18, count_es + 1) = XesOneStep(5 : 18, 1) + temp(5 : 18);

        if Hinfinity_switch == 0
            P( : , : , count_es + 1) = PesOneStep - K * PzesOneStep * K';
        else
            % Rek
            alphaHinf = 100;
            Hktrans = eye(18) / PesOneStep * PxzesOneStep;
            Hk = Hktrans';
            gammaSquare = alphaHinf * max(eig(eye(18) / (eye(18) / PesOneStep + Hktrans / R * Hk)));
            disp(num2str(gammaSquare));
            Rek = [PzesOneStep, PxzesOneStep'; PxzesOneStep, PesOneStep - gammaSquare * eye(18)];
            % Estimation Pes
            P( : , : , count_es + 1) = PesOneStep - [PxzesOneStep, PesOneStep] / Rek * [PxzesOneStep, PesOneStep]';
        end
        
        
        % Recover new Ctb
      	Ctb = CtbNew;
        
        % Feedback correction
        
        % fix attitude
        %{
        MQct = [Xes(1, count_es + 1),   -Xes(2, count_es + 1),    -Xes(3, count_es + 1),     -Xes(4, count_es + 1);
                 Xes(2, count_es + 1),    Xes(1, count_es + 1),     -Xes(4, count_es + 1),     Xes(3, count_es + 1);
                 Xes(3, count_es + 1),    Xes(4, count_es + 1),     Xes(1, count_es + 1),      -Xes(2, count_es + 1);
                 Xes(4, count_es + 1),    -Xes(3, count_es + 1),    Xes(2, count_es + 1),      Xes(1, count_es + 1)];

        Qua = MQct * Qua; % Exclude tilt
        %}
            
        
        % fix velocity and position
        
        v_kf(1, count_kf + 1) = ve - Xes(5, count_es + 1);
        v_kf(2, count_kf + 1) = vn - Xes(6, count_es + 1);
        v_kf(3, count_kf + 1) = vu - Xes(7, count_es + 1);

        la_kf(1, count_kf + 1) = la - Xes(8, count_es + 1);
        lon_kf(1, count_kf + 1) = lon - Xes(9, count_es + 1);
        h_kf(1, count_kf + 1) = h - Xes(10, count_es + 1);
        
        time_es(count_es) = time(count_kf);
    
        %disp(['count_es = ', num2str(count_es)]);
    end % Kalman Filter

end




% Extraction of estimation variance
sqrtP = zeros(18, count_es);
[~, ~, len_temp3] = size(P);
for count = 1 : 1 : len_temp3
    sqrtP(1, count) = sqrt(P(1, 1, count));
    sqrtP(2, count) = sqrt(P(2, 2, count));
    sqrtP(3, count) = sqrt(P(3, 3, count));
    sqrtP(4, count) = sqrt(P(4, 4, count));
    
    sqrtP(5, count) = sqrt(P(5, 5, count));
    sqrtP(6, count) = sqrt(P(6, 6, count));
    sqrtP(7, count) = sqrt(P(7, 7, count));
    
    sqrtP(8, count) = sqrt(P(8, 8, count));
    sqrtP(9, count) = sqrt(P(9, 9, count));
    sqrtP(10, count) = sqrt(P(10, 10, count));
    
    sqrtP(11, count) = sqrt(P(11, 11, count));
    sqrtP(12, count) = sqrt(P(12, 12, count));
    sqrtP(13, count) = sqrt(P(13, 13, count));
    
    sqrtP(14, count) = sqrt(P(14, 14, count));
    sqrtP(15, count) = sqrt(P(15, 15, count));    
    sqrtP(16, count) = sqrt(P(16, 16, count)); 
    
    sqrtP(17, count) = sqrt(P(17, 17, count)); 
    sqrtP(18, count) = sqrt(P(18, 18, count)); 
end


end % function

