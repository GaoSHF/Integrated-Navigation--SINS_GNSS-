close all;
clear all;





% Global definition
wie = 7.292115147e-5; % rad/s
Re = 6378245; % Earth radius, m
e = 1 / 298.3; % Earth eccentrity
g0 = 9.7803267714; % m/s^2
gk1 = 0.00193185138639;
gk2 = 0.00669437999013;

% Unit conversion
unit_degree2rad = (pi / 180); % degrees to rad
unit_w = (pi / 3600 / 180); % degrees/h to rad/s
unit_ug = (g0 * 10 ^ (-6)); % ug to m/s^2


%% Import data
disp('Import data begin.');
tic;


% Import both IMU and GNSS data
SWITCH_FILE = 21;

if SWITCH_FILE == 0
    data = importdata('../../../Integrated Navigation Data/201401031452 (GPS L1 Static)/both.dat');
    data_norm = importdata('../../../Integrated Navigation Data/201401031452 (GPS L1 Static)/nav_normal.dat');
    data_gnss = importdata('../../../Integrated Navigation Data/201401031452 (GPS L1 Static)/nav_gnss.dat');
elseif SWITCH_FILE == 1
    data = importdata('../../../Integrated Navigation Data/201401031508 (GPS L1 Vn 1g 300)/both.dat');
    data_norm = importdata('../../../Integrated Navigation Data/201401031508 (GPS L1 Vn 1g 300)/nav_normal.dat');
    data_gnss = importdata('../../../Integrated Navigation Data/201401031508 (GPS L1 Vn 1g 300)/nav_gnss.dat');
elseif SWITCH_FILE == 2
    data = importdata('../../../Integrated Navigation Data/201401031519 (GPS L1 Vn 1g 300 6g 900)/both.dat');
    data_norm = importdata('../../../Integrated Navigation Data/201401031519 (GPS L1 Vn 1g 300 6g 900)/nav_normal.dat');
    data_gnss = importdata('../../../Integrated Navigation Data/201401031519 (GPS L1 Vn 1g 300 6g 900)/nav_gnss.dat');
elseif SWITCH_FILE == 3
    data = importdata('../../../Integrated Navigation Data/201401031548 (GPS L1 Vn 1g 300 6g 1200)/both.dat');
    data_norm = importdata('../../../Integrated Navigation Data/201401031548 (GPS L1 Vn 1g 300 6g 1200)/nav_normal.dat');
    data_gnss = importdata('../../../Integrated Navigation Data/201401031548 (GPS L1 Vn 1g 300 6g 1200)/nav_gnss.dat');
elseif SWITCH_FILE == 4
    data = importdata('../../../Integrated Navigation Data/201401031607 (GPS L1 Vn 1g 300 4g 900)/both.dat');
    data_norm = importdata('../../../Integrated Navigation Data/201401031607 (GPS L1 Vn 1g 300 4g 900)/nav_normal.dat');
    data_gnss = importdata('../../../Integrated Navigation Data/201401031607 (GPS L1 Vn 1g 300 4g 900)/nav_gnss.dat');
elseif SWITCH_FILE == 5
    data = importdata('../../../Integrated Navigation Data/201401031355 (BD B3 Vn 300)/both.dat');
    data_norm = importdata('../../../Integrated Navigation Data/201401031355 (BD B3 Vn 300)/nav_normal.dat');
    data_gnss = importdata('../../../Integrated Navigation Data/201401031355 (BD B3 Vn 300)/nav_gnss.dat');
    
elseif SWITCH_FILE == 11
    data = importdata('../../../Integrated Navigation Data/201405301855 (GPS L1 Vn 60)/both.dat');
    data_norm = importdata('../../../Integrated Navigation Data/201405301855 (GPS L1 Vn 60)/nav_normal.dat');
    data_gnss = importdata('../../../Integrated Navigation Data/201405301855 (GPS L1 Vn 60)/nav_gnss.dat');
elseif SWITCH_FILE == 12
    data = importdata('../../../Integrated Navigation Data/201405301856 (GPS L1 Vn 300)/both.dat');
    data_norm = importdata('../../../Integrated Navigation Data/201405301856 (GPS L1 Vn 300)/nav_normal.dat');
    data_gnss = importdata('../../../Integrated Navigation Data/201405301856 (GPS L1 Vn 300)/nav_gnss.dat');

    
elseif SWITCH_FILE == 21
    data = importdata('../../../Integrated Navigation Data/201306010101 (GPS Real Static)/both.dat');
    data_norm = importdata('../../../Integrated Navigation Data/201306010101 (GPS Real Static)/nav_normal.dat');
    data_gnss = importdata('../../../Integrated Navigation Data/201306010101 (GPS Real Static)/nav_gnss.dat');
    

    
end


% Import normal navigation results
lenNorm = length(data_norm);





t = 0 : 0.001 : (lenNorm - 1) * 0.001;

x = t * 0.1;
y = t .* t * 1;
z = t .* t * 1;

plot3(x, y, z), grid on;








%{
%% Drawing results
disp('Drawing results begin.');
tic;

figure('name', 'Attitude Error');
subplot(3, 1, 1), 
plot(timePlus1(1 : lenError1), pitchError1(1 : lenError1), 'Color', 'k', 'LineStyle', ':'), hold on;
plot(timePlus2(1 : lenError2), pitchError2(1 : lenError2), 'Color', 'k', 'LineStyle', '-'), hold on;
legend('QUKF', 'QUKF Hinf'); xlabel('Time/s'), ylabel('Pitch Error/degree');
subplot(3, 1, 2), 
plot(timePlus1(1 : lenError1), rollError1(1 : lenError1), 'Color', 'k', 'LineStyle', ':'), hold on;
plot(timePlus2(1 : lenError2), rollError2(1 : lenError2), 'Color', 'k', 'LineStyle', '-'), hold on;
legend('QUKF', 'QUKF Hinf'); xlabel('Time/s'), ylabel('Roll Error/degree');
subplot(3, 1, 3), 
plot(timePlus1(1 : lenError1), yawError1(1 : lenError1), 'Color', 'k', 'LineStyle', ':'), hold on;
plot(timePlus2(1 : lenError2), yawError2(1 : lenError2), 'Color', 'k', 'LineStyle', '-'), hold on;
legend('QUKF', 'QUKF Hinf'); xlabel('Time/s'), ylabel('Yaw Error/degree');

figure('name', 'Velocity Error');
subplot(3, 1, 1), 
plot(timePlus1(1 : lenError1), veError1(1 : lenError1), 'Color', 'k', 'LineStyle', ':'), hold on;
plot(timePlus2(1 : lenError2), veError2(1 : lenError2), 'Color', 'k', 'LineStyle', '-'), hold on;
legend('QUKF', 'QUKF Hinf'); xlabel('Time/s'), ylabel('East Velocity Error/m/s');
subplot(3, 1, 2), 
plot(timePlus1(1 : lenError1), vnError1(1 : lenError1), 'Color', 'k', 'LineStyle', ':'), hold on;
plot(timePlus2(1 : lenError2), vnError2(1 : lenError2), 'Color', 'k', 'LineStyle', '-'), hold on;
legend('QUKF', 'QUKF Hinf'); xlabel('Time/s'), ylabel('North Velocity Error/m/s');
subplot(3, 1, 3), 
plot(timePlus1(1 : lenError1), vuError1(1 : lenError1), 'Color', 'k', 'LineStyle', ':'), hold on;
plot(timePlus2(1 : lenError2), vuError2(1 : lenError2), 'Color', 'k', 'LineStyle', '-'), hold on;
legend('QUKF', 'QUKF Hinf'); xlabel('Time/s'), ylabel('Up Velocity Error/m/s');

figure('name', 'Position Error');
subplot(3, 1, 1), 
plot(timePlus1(1 : lenError1), laError1(1 : lenError1) * unit_degree2rad * Re, 'Color', 'k', 'LineStyle', ':'), hold on;
plot(timePlus2(1 : lenError2), laError2(1 : lenError2) * unit_degree2rad * Re, 'Color', 'k', 'LineStyle', '-'), hold on;
legend('QUKF', 'QUKF Hinf'); xlabel('Time/s'), ylabel('North Position Error/m');
subplot(3, 1, 2), 
plot(timePlus1(1 : lenError1), lonError1(1 : lenError1) * unit_degree2rad * Re, 'Color', 'k', 'LineStyle', ':'), hold on;
plot(timePlus2(1 : lenError2), lonError2(1 : lenError2) * unit_degree2rad * Re, 'Color', 'k', 'LineStyle', '-'), hold on;
legend('QUKF', 'QUKF Hinf'); xlabel('Time/s'), ylabel('East Position Error/m');
subplot(3, 1, 3), 
plot(timePlus1(1 : lenError1), altError1(1 : lenError1), 'Color', 'k', 'LineStyle', ':'), hold on;
plot(timePlus2(1 : lenError2), altError2(1 : lenError2), 'Color', 'k', 'LineStyle', '-'), hold on;
legend('QUKF', 'QUKF Hinf'); xlabel('Time/s'), ylabel('Altitude Error/m');





figure('name', 'Attitude');
subplot(3, 1, 1), 
plot(time_gnss(1 : end), pitch_gnss(1 : end), 'Color', 'k', 'LineStyle', ':'), hold on;
plot(time_gnss(1 : end), pitch_gnss(1 : end), 'Color', 'k', 'LineStyle', '-'), hold on;
legend('QUKF', 'QUKF Hinf'); xlabel('Time/s'), ylabel('Pitch Error/degree');
subplot(3, 1, 2), 
plot(time_gnss(1 : end), roll_gnss(1 : end), 'Color', 'k', 'LineStyle', ':'), hold on;
plot(time_gnss(1 : end), roll_gnss(1 : end), 'Color', 'k', 'LineStyle', '-'), hold on;
legend('QUKF', 'QUKF Hinf'); xlabel('Time/s'), ylabel('Roll Error/degree');
subplot(3, 1, 3), 
plot(time_gnss(1 : end), yaw_gnss(1 : end), 'Color', 'k', 'LineStyle', ':'), hold on;
plot(time_gnss(1 : end), yaw_gnss(1 : end), 'Color', 'k', 'LineStyle', '-'), hold on;
legend('QUKF', 'QUKF Hinf'); xlabel('Time/s'), ylabel('Yaw Error/degree');

figure('name', 'Velocity');
subplot(3, 1, 1), 
plot(time_gnss(1 : end), ve_gnss(1 : end), 'Color', 'k', 'LineStyle', ':'), hold on;
plot(time_gnss(1 : end), ve_gnss(1 : end), 'Color', 'k', 'LineStyle', '-'), hold on;
legend('QUKF', 'QUKF Hinf'); xlabel('Time/s'), ylabel('East Velocity Error/m/s');
subplot(3, 1, 2), 
plot(time_gnss(1 : end), vn_gnss(1 : end), 'Color', 'k', 'LineStyle', ':'), hold on;
plot(time_gnss(1 : end), vn_gnss(1 : end), 'Color', 'k', 'LineStyle', '-'), hold on;
legend('QUKF', 'QUKF Hinf'); xlabel('Time/s'), ylabel('North Velocity Error/m/s');
subplot(3, 1, 3), 
plot(time_gnss(1 : end), vu_gnss(1 : end), 'Color', 'k', 'LineStyle', ':'), hold on;
plot(time_gnss(1 : end), vu_gnss(1 : end), 'Color', 'k', 'LineStyle', '-'), hold on;
legend('QUKF', 'QUKF Hinf'); xlabel('Time/s'), ylabel('Up Velocity Error/m/s');

figure('name', 'Position');
subplot(3, 1, 1), 
plot(time_gnss(1 : end), la_gnss(1 : end), 'Color', 'k', 'LineStyle', ':'), hold on;
plot(time_gnss(1 : end), la_gnss(1 : end), 'Color', 'k', 'LineStyle', '-'), hold on;
legend('QUKF', 'QUKF Hinf'); xlabel('Time/s'), ylabel('North Position Error/m');
subplot(3, 1, 2), 
plot(time_gnss(1 : end), lon_gnss(1 : end), 'Color', 'k', 'LineStyle', ':'), hold on;
plot(time_gnss(1 : end), lon_gnss(1 : end), 'Color', 'k', 'LineStyle', '-'), hold on;
legend('QUKF', 'QUKF Hinf'); xlabel('Time/s'), ylabel('East Position Error/m');
subplot(3, 1, 3), 
plot(time_gnss(1 : end), alt_gnss(1 : end), 'Color', 'k', 'LineStyle', ':'), hold on;
plot(time_gnss(1 : end), alt_gnss(1 : end), 'Color', 'k', 'LineStyle', '-'), hold on;
legend('QUKF', 'QUKF Hinf'); xlabel('Time/s'), ylabel('Altitude Error/m');








RuntimeDraw = toc;
disp(['Drawing results running time = ', num2str(RuntimeDraw), 's']);
%}




