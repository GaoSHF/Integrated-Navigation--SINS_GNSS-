close all;
clear all;

SWITCH_FILE = 1; % 0: 1min; 1: 1h
SWITCH_COMPARE_C = 0; % 0: Don't use c programme results

SAMPLING_RATE_IMU = 100; % 100Hz
TIME_INTERVAL_IMU = 0.01; % 0.01s

if SWITCH_FILE == 1
TIME_LENGTH_ALIGNMENT = (5 * 60); % 5min coarse-alignment
else
TIME_LENGTH_ALIGNMENT = 0;  
end; % if SWITCH_FILE == 1

LENGTH_ALIGNMENT = (TIME_LENGTH_ALIGNMENT / TIME_INTERVAL_IMU);

TIME_INTERVAL_GPS = 0.01;

% Global definition
wie = 7.292115147e-5; % rad/s
Re = 6378245; % Earth radius, m
e = 1 / 298.3; % Earth eccentrity
g0 = 9.7803267714; % m/s^2
gk1 = 0.00193185138639;
gk2 = 0.00669437999013;

% Unit conversion
unit_degree2rad = (pi / 180); % degrees to rad
unit_w = (pi / 3600 / 180); % degrees/h_ins_c to rad/s

% Import data
if SWITCH_FILE == 1
data_imu = importdata('../Data/imu_1h.dat');
data_gps = importdata('../Data/gps_1h.dat');
else
data_imu = importdata('../Data/imu_1min.dat');
data_gps = importdata('../Data/gps_1min.dat');
end; % if SWITCH_FILE == 1

% UTC time
utctime_imu = data_imu( : , 2)';
utctime_gps = data_gps( : , 2)';

% gsp data
la_gps = data_gps( : , 3)';
lon_gps = data_gps( : , 4)';
h_gps = data_gps( : , 5)';
v_gps = data_gps( : , 6 : 8)';
v_gps_enu = v_gps;
% v_gps_enu = zeros(3, length(v_gps));
%for count_gps = 1 : length(v_gps)
%    v_gps_enu(1, count_gps) = ...
%         v_gps(1, count_gps) * cos(pi / 2 + lon_gps(count_gps) * unit_degree2rad) + ...
%         v_gps(2, count_gps) * sin(pi / 2 + lon_gps(count_gps) * unit_degree2rad);
%     v_gps_enu(2, count_gps) = ...
%         -v_gps(1, count_gps) * cos(pi / 2 - la_gps(count_gps) * unit_degree2rad) * sin(pi / 2 + lon_gps(count_gps) * unit_degree2rad) + ...
%         v_gps(2, count_gps) * cos(pi / 2 - la_gps(count_gps) * unit_degree2rad) * cos(pi / 2 + lon_gps(count_gps) * unit_degree2rad) + ...
%         v_gps(3, count_gps) * sin(pi / 2 - la_gps(count_gps) * unit_degree2rad);
%     v_gps_enu(3, count_gps) = ...
%         v_gps(1, count_gps) * sin(pi / 2 - la_gps(count_gps) * unit_degree2rad) * sin(pi / 2 + lon_gps(count_gps) * unit_degree2rad) + ...
%         v_gps(2, count_gps) * sin(pi / 2 - la_gps(count_gps) * unit_degree2rad) * cos(pi / 2 + lon_gps(count_gps) * unit_degree2rad) - ...
%         v_gps(3, count_gps) * cos(pi / 2 - la_gps(count_gps) * unit_degree2rad);
% end


% Gyroscope data (degrees/h_ins_c to rad/s)
w_imu(1 : 3, :) = (data_imu( : , 3 : 5) * unit_w)';


% Accelerometer data (g to m/s^2)
f_imu(1 : 3, :) = (data_imu( : , 6 : 8) * g0)';



%% Strapdown algorithm
% Initial value
% 1h
if SWITCH_FILE == 1
ve0 = 0;
vn0 = 0;
vu0 = 0;
la0 = 40.0211142228246 * unit_degree2rad;
lon0 = 116.3703629769560 * unit_degree2rad;
h0 = 43.0674;

% Alignment
w_accum = zeros(3, 1);
acc_accum = zeros(3, 1);
% Accumulate IMU data
for i = 1 : LENGTH_ALIGNMENT
    w_accum(1, 1) = w_accum(1, 1) + w_imu(1, i);
    w_accum(2, 1) = w_accum(2, 1) + w_imu(2, i);
    w_accum(3, 1) = w_accum(3, 1) + w_imu(3, i);
    
    acc_accum(1, 1) = acc_accum(1, 1) + f_imu(1, i);
    acc_accum(2, 1) = acc_accum(2, 1) + f_imu(2, i);
    acc_accum(3, 1) = acc_accum(3, 1) + f_imu(3, i);
end
w_mean = w_accum / LENGTH_ALIGNMENT;
acc_mean = acc_accum / LENGTH_ALIGNMENT;

[Qua, Ctb, pitch0, roll0, yaw0] = coarse_alignment(la0, w_mean, acc_mean);

disp('Alignment Result:');
disp(['    Pitch:', num2str(pitch0 / unit_degree2rad)]);
disp(['    Roll:', num2str(roll0 / unit_degree2rad)]);
disp(['    yaw_ins_c:', num2str(yaw0 / unit_degree2rad)]);

% 1min
else
ve0 = -60.542440167488820;
vn0 = 12.517128987591928;
vu0 = -0.663025961716411;
la0 = 29.146706267977070 * unit_degree2rad;
lon0 = 121.360149909644680 * unit_degree2rad;
h0 = 2418.691384897396300;
roll0 = 14.154302528542125 * unit_degree2rad;
pitch0 = 2.958066786126155 * unit_degree2rad;
yaw0 = ( 360 - 80.386784716753596) * unit_degree2rad;

% Init SINS parameter
[Qua, Ctb] = sins_init(pitch0, roll0, yaw0);
end; % if SWITCH_FILE == 1


len_ins = length(w_imu) - LENGTH_ALIGNMENT + 1;
la_ins = [la0, zeros(1, len_ins - 1)];
lon_ins = [lon0, zeros(1, len_ins - 1)];
h_ins = [h0, zeros(1, len_ins - 1)];
v_ins = [[ve0; vn0; vu0], zeros(3, len_ins - 1)];
pitch_ins = [pitch0, zeros(1, len_ins - 1)];
roll_ins = [roll0, zeros(1, len_ins - 1)];
yaw_ins = [yaw0, zeros(1, len_ins - 1)];
% Strapdown navigation
for count_ins = 1 : (len_ins - 1)
    [Qua, Ctb, ...
        la_ins(count_ins + 1), lon_ins(count_ins + 1), h_ins(count_ins + 1), ...
        v_ins(1 : 3, count_ins + 1), ...
        pitch_ins(count_ins + 1), roll_ins(count_ins + 1), yaw_ins(count_ins + 1)] = strapdown(...
        TIME_INTERVAL_IMU, Qua, Ctb, ...
        la_ins(count_ins), lon_ins(count_ins), h_ins(count_ins), v_ins(1 : 3, count_ins), ...
        w_imu(1 : 3, LENGTH_ALIGNMENT + count_ins), f_imu(1 : 3, LENGTH_ALIGNMENT + count_ins), 0);
end

la_ins = la_ins / unit_degree2rad;
lon_ins = lon_ins / unit_degree2rad;

pitch_ins = pitch_ins / unit_degree2rad;
roll_ins = roll_ins / unit_degree2rad;
yaw_ins = yaw_ins / unit_degree2rad;

% SINS time
time_sins = utctime_imu((LENGTH_ALIGNMENT + 1) : end);
time_sins(1, end + 1) = time_sins(1, end) + 1000 * TIME_INTERVAL_IMU;

% GPS time
time_gps = utctime_gps;
len_gps = length(time_gps);

figure('name', '3D Position');
plot3(lon_ins, la_ins, h_ins, 'Color', 'r'), hold on;
plot3(lon_gps, la_gps, h_gps, 'Color', 'g'), hold on;
legend('INS', 'GPS');
xlabel('Latitude (degrees)'), ylabel('Longitude (degrees)'), 
grid on;

figure('name', 'Position');
subplot(3, 1, 1),
plot(time_sins(1 : len_ins), la_ins(1 : len_ins), 'Color', 'r'), hold on;
plot(time_gps(1 : len_gps), la_gps(1 : len_gps), 'Color', 'g'), hold on;
legend('INS', 'GPS'); title('latitude');
subplot(3, 1, 2),
plot(time_sins(1 : len_ins), lon_ins(1 : len_ins), 'Color', 'r'), hold on;
plot(time_gps(1 : len_gps), lon_gps(1 : len_gps), 'Color', 'g'), hold on;
legend('INS', 'GPS'); title('longitude');
subplot(3, 1, 3),
plot(time_sins(1 : len_ins), h_ins(1 : len_ins), 'Color', 'r'), hold on;
plot(time_gps(1 : len_gps), h_gps(1 : len_gps), 'Color', 'g'), hold on;
legend('INS', 'GPS'); title('Altitude');

figure('name', 'Velocity');
subplot(3, 1, 1),
plot(time_sins(1 : len_ins), v_ins(1, 1 : len_ins), 'Color', 'r'), hold on;
plot(time_gps(1 : len_gps), v_gps_enu(1, 1 : len_gps), 'Color', 'g'), hold on;
legend('INS', 'GPS'); title('east');
subplot(3, 1, 2),
plot(time_sins(1 : len_ins), v_ins(2, 1 : len_ins), 'Color', 'r'), hold on;
plot(time_gps(1 : len_gps), v_gps_enu(2, 1 : len_gps), 'Color', 'g'), hold on;
legend('INS', 'GPS'); title('north');
subplot(3, 1, 3),
plot(time_sins(1 : len_ins), v_ins(3, 1 : len_ins), 'Color', 'r'), hold on;
plot(time_gps(1 : len_gps), v_gps_enu(3, 1 : len_gps), 'Color', 'g'), hold on;
legend('INS', 'GPS'); title('up');

figure('name', 'Attitude');
subplot(3, 1, 1),
plot(time_sins(1 : len_ins), roll_ins(1 : len_ins), 'Color', 'r'), hold on;
legend('INS'); title('roll');
subplot(3, 1, 2),
plot(time_sins(1 : len_ins), pitch_ins(1 : len_ins), 'Color', 'r'), hold on;
legend('INS'); title('pitch');
subplot(3, 1, 3),
plot(time_sins(1 : len_ins), yaw_ins(1 : len_ins), 'Color', 'r'), hold on;
legend('INS'); title('yaw');


%% Result drawing of c programme
if SWITCH_COMPARE_C == 1
% Import data
if SWITCH_FILE == 1
data_imu = importdata('../Data/sins_results_1h.dat');
else
data_imu = importdata('../Data/sins_results_1min.dat');    
end; % if SWITCH_FILE == 1

% time
time_sins_c = data_imu( : , 1)';

% Attitude
pitch_ins_c = data_imu( : , 2)';
roll_ins_c = data_imu( : , 3)';
yaw_ins_c = data_imu( : , 4)';

% Velocity
v_ins_c = data_imu( : , 5 : 7)';

% Location, altitude
la_ins_c = data_imu( : , 8)';
lon_ins_c = data_imu( : ,9)';
h_ins_c = data_imu( : , 10)';

len_ins_c = min(length(time_sins_c), length(la_ins_c));

figure('name', '3D Position (C)');
plot3(lon_ins_c, la_ins_c, h_ins_c, 'Color', 'r'), hold on;
plot3(lon_gps, la_gps, h_gps, 'Color', 'g'), hold on;
legend('INS', 'GPS');
xlabel('Latitude (degrees)'), ylabel('Longitude (degrees)'), 
grid on;

figure('name', 'Position (C)');
subplot(3, 1, 1),
plot(time_sins_c(1 : len_ins), la_ins_c(1 : len_ins), 'Color', 'r'), hold on;
plot(time_gps(1 : len_gps), la_gps(1 : len_gps), 'Color', 'g'), hold on;
legend('INS', 'GPS'); title('latitude');
subplot(3, 1, 2),
plot(time_sins_c(1 : len_ins), lon_ins_c(1 : len_ins), 'Color', 'r'), hold on;
plot(time_gps(1 : len_gps), lon_gps(1 : len_gps), 'Color', 'g'), hold on;
legend('INS', 'GPS'); title('longitude');
subplot(3, 1, 3),
plot(time_sins_c(1 : len_ins), h_ins_c(1 : len_ins), 'Color', 'r'), hold on;
plot(time_gps(1 : len_gps), h_gps(1 : len_gps), 'Color', 'g'), hold on;
legend('INS', 'GPS'); title('Altitude');

figure('name', 'Velocity (C)');
subplot(3, 1, 1),
plot(time_sins_c(1 : len_ins), v_ins_c(1, 1 : len_ins), 'Color', 'r'), hold on;
plot(time_gps(1 : len_gps), v_gps_enu(1, 1 : len_gps), 'Color', 'g'), hold on;
legend('INS', 'GPS'); title('east');
subplot(3, 1, 2),
plot(time_sins_c(1 : len_ins), v_ins_c(2, 1 : len_ins), 'Color', 'r'), hold on;
plot(time_gps(1 : len_gps), v_gps_enu(2, 1 : len_gps), 'Color', 'g'), hold on;
legend('INS', 'GPS'); title('north');
subplot(3, 1, 3),
plot(time_sins_c(1 : len_ins), v_ins_c(3, 1 : len_ins), 'Color', 'r'), hold on;
plot(time_gps(1 : len_gps), v_gps_enu(3, 1 : len_gps), 'Color', 'g'), hold on;
legend('INS', 'GPS'); title('up');

figure('name', 'Attitude (C)');
subplot(3, 1, 1),
plot(time_sins_c(1 : len_ins), roll_ins_c(1 : len_ins), 'Color', 'r'), hold on;
legend('INS'); title('roll');
subplot(3, 1, 2),
plot(time_sins_c(1 : len_ins), pitch_ins_c(1 : len_ins), 'Color', 'r'), hold on;
legend('INS'); title('pitch');
subplot(3, 1, 3),
plot(time_sins_c(1 : len_ins), yaw_ins_c(1 : len_ins), 'Color', 'r'), hold on;
legend('INS'); title('yaw');

end % if SWITCH_COMPARE_C == 1



