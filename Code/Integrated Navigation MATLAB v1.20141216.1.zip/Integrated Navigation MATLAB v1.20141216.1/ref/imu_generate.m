close all;
clear all;

IMU_OUTPUT_FREQUENCY = 100;

wie = 7.292115147e-5;
Re = 6378137;
e = (1 / 298.257223563);
g0 = 9.7803267714; % m/s^2
gk1 = 0.00193185138639;
gk2 = 0.00669437999013;

unit_degree2rad = (pi / 180); % degrees to rad

LA0 = (39 * pi / 180);
LON0 = (116 * pi / 180);
H0 = 100;

PITCH0 = 0;
ROLL0 = 0;
YAW0 = 0;

T = 1 / IMU_OUTPUT_FREQUENCY;

SWITCH_FILE = 4;

if SWITCH_FILE == 0
    data_imu = importdata('../../Data/201401031607 (GPS L1 Vn 1g 300 4g 900)/imu.txt');
    file_imu = fopen('../../Data/201401031607 (GPS L1 Vn 1g 300 4g 900)/imu_fix.txt', 'w');
    file_results = fopen('../../Data/201401031607 (GPS L1 Vn 1g 300 4g 900)/results_simu.dat', 'w');
    VE0 = 0;
    VN0 = 0;
    VU0 = 0;
    AE_STAGE1 = 0;
    AN_STAGE1 = 10;
    AU_STAGE1 = 0;
    AE_STAGE2 = 0;
    AN_STAGE2 = 40;
    AU_STAGE2 = 0;	
    AE_STAGE3 = 0;
    AN_STAGE3 = 0;
    AU_STAGE3 = 0;
    TIME_LEN_STAGE1 = 30 * IMU_OUTPUT_FREQUENCY;
    TIME_LEN_STAGE2 = 15 * IMU_OUTPUT_FREQUENCY;



elseif SWITCH_FILE == 1
    data_imu = importdata('../../Data/201401031548 (GPS L1 Vn 1g 300 6g 1200)/imu.txt');
    file_imu = fopen('../../Data/201401031548 (GPS L1 Vn 1g 300 6g 1200)/imu_fix.txt', 'w');
    file_results = fopen('../../Data/201401031548 (GPS L1 Vn 1g 300 6g 1200)/results_simu.dat', 'w');
    VE0 = 0;
    VN0 = 0;
    VU0 = 0;
    AE_STAGE1 = 0;
    AN_STAGE1 = 10;
    AU_STAGE1 = 0;
    AE_STAGE2 = 0;
    AN_STAGE2 = 60;
    AU_STAGE2 = 0;	
    AE_STAGE3 = 0;
    AN_STAGE3 = 0;
    AU_STAGE3 = 0;
    TIME_LEN_STAGE1 = 30 * IMU_OUTPUT_FREQUENCY;
    TIME_LEN_STAGE2 = 15 * IMU_OUTPUT_FREQUENCY;

elseif SWITCH_FILE == 2
    data_imu = importdata('../../Data/201401031519 (GPS L1 Vn 1g 300 6g 900)/imu.txt');
    file_imu = fopen('../../Data/201401031519 (GPS L1 Vn 1g 300 6g 900)/imu_fix.txt', 'w');
    file_results = fopen('../../Data/201401031519 (GPS L1 Vn 1g 300 6g 900)/results_simu.dat', 'w');
    VE0 = 0;
    VN0 = 0;
    VU0 = 0;
    AE_STAGE1 = 0;
    AN_STAGE1 = 10;
    AU_STAGE1 = 0;
    AE_STAGE2 = 0;
    AN_STAGE2 = 60;
    AU_STAGE2 = 0;	
    AE_STAGE3 = 0;
    AN_STAGE3 = 0;
    AU_STAGE3 = 0;
    TIME_LEN_STAGE1 = 30 * IMU_OUTPUT_FREQUENCY;
    TIME_LEN_STAGE2 = 10 * IMU_OUTPUT_FREQUENCY;

elseif SWITCH_FILE == 3
    data_imu = importdata('../../Data/201401031508 (GPS L1 Vn 1g 300)/imu.txt');
    file_imu = fopen('../../Data/201401031508 (GPS L1 Vn 1g 300)/imu_fix.txt', 'w');
    file_results = fopen('../../Data/201401031508 (GPS L1 Vn 1g 300)/results_simu.dat', 'w');
    VE0 = 0;
    VN0 = 0;
    VU0 = 0;
    AE_STAGE1 = 0;
    AN_STAGE1 = 10;
    AU_STAGE1 = 0;
    AE_STAGE2 = 0;
    AN_STAGE2 = 0;
    AU_STAGE2 = 0;	
    AE_STAGE3 = 0;
    AN_STAGE3 = 0;
    AU_STAGE3 = 0;
    TIME_LEN_STAGE1 = 30 * IMU_OUTPUT_FREQUENCY;
    TIME_LEN_STAGE2 = 10 * IMU_OUTPUT_FREQUENCY;

elseif SWITCH_FILE == 4
    data_imu = importdata('../../Data/201401031452 (GPS L1 Static)/imu.txt');
    file_imu = fopen('../../Data/201401031452 (GPS L1 Static)/imu_fix.txt', 'w');
    file_results = fopen('../../Data/201401031452 (GPS L1 Static)/results_simu.dat', 'w');
    VE0 = 0;
    VN0 = 0;
    VU0 = 0;
    AE_STAGE1 = 0;
    AN_STAGE1 = 0;
    AU_STAGE1 = 0;
    AE_STAGE2 = 0;
    AN_STAGE2 = 0;
    AU_STAGE2 = 0;	
    AE_STAGE3 = 0;
    AN_STAGE3 = 0;
    AU_STAGE3 = 0;
    TIME_LEN_STAGE1 = 30 * IMU_OUTPUT_FREQUENCY;
    TIME_LEN_STAGE2 = 10 * IMU_OUTPUT_FREQUENCY;

elseif SWITCH_FILE == 5
    data_imu = importdata('../../Data/201401031355 (BD B3 Vn 300)/imu.txt');
    file_imu = fopen('../../Data/201401031355 (BD B3 Vn 300)/imu_fix.txt', 'w');
    file_results = fopen('../../Data/201401031355 (BD B3 Vn 300)/results_simu.dat', 'w');
    VE0 = 0;
    VN0 = 300;
    VU0 = 0;
    AE_STAGE1 = 0;
    AN_STAGE1 = 0;
    AU_STAGE1 = 0;
    AE_STAGE2 = 0;
    AN_STAGE2 = 0;
    AU_STAGE2 = 0;	
    AE_STAGE3 = 0;
    AN_STAGE3 = 0;
    AU_STAGE3 = 0;
    TIME_LEN_STAGE1 = 30 * IMU_OUTPUT_FREQUENCY;
    TIME_LEN_STAGE2 = 10 * IMU_OUTPUT_FREQUENCY;

end




% Import time
len_imu = length(data_imu);
time_imu = data_imu( : , 1)';

wibbx_imu = zeros(1, len_imu);
wibby_imu = zeros(1, len_imu);
wibbz_imu = zeros(1, len_imu);
fbx_imu = zeros(1, len_imu);
fby_imu = zeros(1, len_imu);
fbz_imu = zeros(1, len_imu);


ve = VE0;
vn = VN0;
vu = VN0;
la = LA0;
lon = LON0;
h = H0;
for i = 1 : len_imu
    Rm = Re / (1 + 2 * e - 3 * e * sin(la * la)) + h;
	Rn = Re / (1 - e * sin(la * la)) + h;

    
    % Refresh acceleration
    if i <= TIME_LEN_STAGE1
        ae = AE_STAGE1;
        an = AN_STAGE1;
        au = AU_STAGE1;
    else
        if i <= (TIME_LEN_STAGE1 + TIME_LEN_STAGE2)
            ae = AE_STAGE2;
            an = AN_STAGE2;
            au = AU_STAGE2;
        else
            ae = AE_STAGE3;
            an = AN_STAGE3;
            au = AU_STAGE3;
        end
    end
    
    % Refresh velocity
    ve = ve + ae * T;
	vn = vn + an * T;
	vu = vu + au * T;
    
    % Refresh location
    la = vn / Rm * T + la;
    lon = ve / (Rn * cos(la)) * T + lon;
    h = vu * T + h;
    
    % Generate wib
    wibbx_imu(i) = -vn / Rm;
	wibby_imu(i) = wie * cos(la) + ve / Rn;
	wibbz_imu(i) = wie * sin(la) + ve / Rn * tan(la);
    
    % Generate f
    g = g0 * (1 + gk1 * sin(la) * sin(la)) * (1 - 2 * h / Re) / sqrt(1 - gk2 * sin(la) * sin(la));
    fbx_imu(i) = ae - (2 * wie * sin(la) + ve / Rn * tan(la)) * vn + (2 * wie * cos(la) + ve / Rn) * vu;
    fby_imu(i) = an + (2 * wie * sin(la) + ve / Rn * tan(la)) * ve - (-vn / Rm) * vu;
    fbz_imu(i) = au + g - (2 * wie * cos(la) + ve / Rn) * ve + (-vn / Rm) * vn;
	
    % Record IMU data
    fprintf(file_imu, '%f\t', time_imu(i));
    fprintf(file_imu, '%e\t', wibbx_imu(i));
    fprintf(file_imu, '%e\t', wibby_imu(i));
    fprintf(file_imu, '%e\t', wibbz_imu(i));
    fprintf(file_imu, '%e\t', fbx_imu(i));
    fprintf(file_imu, '%e\t', fby_imu(i));
    fprintf(file_imu, '%e\n', fbz_imu(i));
    
    % Record simulation results
    fprintf(file_results, '%f\t', time_imu(i));
    fprintf(file_results, '%e\t', PITCH0);
    fprintf(file_results, '%e\t', ROLL0);
    fprintf(file_results, '%e\t', YAW0);
    fprintf(file_results, '%e\t', ve);
    fprintf(file_results, '%e\t', vn);
    fprintf(file_results, '%e\t', vu);
    fprintf(file_results, '%e\t', la / unit_degree2rad);
    fprintf(file_results, '%e\t', lon / unit_degree2rad);
    fprintf(file_results, '%e\n', h);
    
end


fclose(file_imu);
fclose(file_results);


msgbox('End of Generation.');

