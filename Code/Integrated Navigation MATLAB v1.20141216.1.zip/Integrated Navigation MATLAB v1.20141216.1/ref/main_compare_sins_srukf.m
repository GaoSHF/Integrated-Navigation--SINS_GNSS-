close all;
clear all;


SAMPLING_RATE_IMU = 100; % 100Hz
TIME_INTERVAL_IMU = 0.01; % 0.01s

SAMPLING_RATE_GPS = 10; % 10Hz
TIME_INTERVAL_GPS = 0.1; % 0.1s


% Relay before using feedback correction
RELAY_BEFORE_FEEDBACK_CORRECTION = 0 * 60 / TIME_INTERVAL_IMU;

% Global definition
wie = 7.292115147e-5; % rad/s
Re = 6378245; % Earth radius, m
e = 1 / 298.3; % Earth eccentrity
g0 = 9.7803267714; % m/s^2
gk1 = 0.00193185138639;
gk2 = 0.00669437999013;

% Unit conversion
unit_degree2rad = (pi / 180); % degrees to rad
unit_w = (pi / 3600 / 180); % degrees/h to rad/s
unit_ug = (g0 * 10 ^ (-6)); % ug to m/s^2


%% Import data
disp('Import data begin.');
tic;


% Import both IMU and GNSS data
SWITCH_FILE = 0;

if SWITCH_FILE == 0
    data = importdata('../../../Integrated Navigation Data/201401031452 (GPS L1 Static)/both.dat');
    data_norm = importdata('../../../Integrated Navigation Data/201401031452 (GPS L1 Static)/nav_normal.dat');
    data_gnss = importdata('../../../Integrated Navigation Data/201401031452 (GPS L1 Static)/nav_gnss.dat');
elseif SWITCH_FILE == 1
    data = importdata('../../../Integrated Navigation Data/201401031508 (GPS L1 Vn 1g 300)/both.dat');
    data_norm = importdata('../../../Integrated Navigation Data/201401031508 (GPS L1 Vn 1g 300)/nav_normal.dat');
    data_gnss = importdata('../../../Integrated Navigation Data/201401031508 (GPS L1 Vn 1g 300)/nav_gnss.dat');
elseif SWITCH_FILE == 2
    data = importdata('../../../Integrated Navigation Data/201401031519 (GPS L1 Vn 1g 300 6g 900)/both.dat');
    data_norm = importdata('../../../Integrated Navigation Data/201401031519 (GPS L1 Vn 1g 300 6g 900)/nav_normal.dat');
    data_gnss = importdata('../../../Integrated Navigation Data/201401031519 (GPS L1 Vn 1g 300 6g 900)/nav_gnss.dat');
elseif SWITCH_FILE == 3
    data = importdata('../../../Integrated Navigation Data/201401031548 (GPS L1 Vn 1g 300 6g 1200)/both.dat');
    data_norm = importdata('../../../Integrated Navigation Data/201401031548 (GPS L1 Vn 1g 300 6g 1200)/nav_normal.dat');
    data_gnss = importdata('../../../Integrated Navigation Data/201401031548 (GPS L1 Vn 1g 300 6g 1200)/nav_gnss.dat');
elseif SWITCH_FILE == 4
    data = importdata('../../../Integrated Navigation Data/201401031607 (GPS L1 Vn 1g 300 4g 900)/both.dat');
    data_norm = importdata('../../../Integrated Navigation Data/201401031607 (GPS L1 Vn 1g 300 4g 900)/nav_normal.dat');
    data_gnss = importdata('../../../Integrated Navigation Data/201401031607 (GPS L1 Vn 1g 300 4g 900)/nav_gnss.dat');
elseif SWITCH_FILE == 5
    data = importdata('../../../Integrated Navigation Data/201401031355 (BD B3 Vn 300)/both.dat');
    data_norm = importdata('../../../Integrated Navigation Data/201401031355 (BD B3 Vn 300)/nav_normal.dat');
    data_gnss = importdata('../../../Integrated Navigation Data/201401031355 (BD B3 Vn 300)/nav_gnss.dat');
    
elseif SWITCH_FILE == 11
    data = importdata('../../../Integrated Navigation Data/201405301855 (GPS L1 Vn 60)/both.dat');
    data_norm = importdata('../../../Integrated Navigation Data/201405301855 (GPS L1 Vn 60)/nav_normal.dat');
    data_gnss = importdata('../../../Integrated Navigation Data/201405301855 (GPS L1 Vn 60)/nav_gnss.dat');
elseif SWITCH_FILE == 12
    data = importdata('../../../Integrated Navigation Data/201405301856 (GPS L1 Vn 300)/both.dat');
    data_norm = importdata('../../../Integrated Navigation Data/201405301856 (GPS L1 Vn 300)/nav_normal.dat');
    data_gnss = importdata('../../../Integrated Navigation Data/201405301856 (GPS L1 Vn 300)/nav_gnss.dat');
end


% Import normal navigation results
len_norm = length(data_norm);
time_norm = data_norm( : , 1)';
pitch_norm = data_norm( : , 2)';
roll_norm = data_norm( : , 3)';
yaw_norm = data_norm( : , 4)';
ve_norm = data_norm( : , 5)';
vn_norm = data_norm( : , 6)';
vu_norm = data_norm( : , 7)';
la_norm = data_norm( : , 8)';
lon_norm = data_norm( : , 9)';
alt_norm = data_norm( : , 10)';


% Import GNSS navigation results
len_gnss = length(data_gnss);
time_gnss = data_gnss( : , 1)';
la_gnss = data_gnss( : , 2)';
lon_gnss = data_gnss( : , 3)';
alt_gnss = data_gnss( : , 4)';
ve_gnss = data_gnss( : , 5)';
vn_gnss = data_gnss( : , 6)';
vu_gnss = data_gnss( : , 7)';



RuntimeImport = toc;
disp(['Importing data rnning time = ', num2str(RuntimeImport), 's']);



%% Prepare KF
disp('Kalman filter preparing begin.');
tic;

% KF
la0 = 39 * unit_degree2rad;
lon0 = 116 * unit_degree2rad;
h0 = 100;
ve0 =0;
vn0 = 0;
vu0 = 0;
pitch0 = 0 * unit_degree2rad;
roll0 = 0 * unit_degree2rad;
yaw0 = 0 * unit_degree2rad;

% IMU error1
drift = [0.1; 0.1; 0.1] * unit_w; % rad/s
bias = [30; 30; 30] * unit_ug; % m/s^2
noiseGyroMSE = [0.03; 0.03; 0.03] * unit_w; % rad/s
noiseAccMSE = [10; 10; 10] * unit_ug; % m/s^2

driftReal = [0.2; 0.2; 0.2] * unit_w; % rad/s
biasReal = [50; 50; 50] * unit_ug; % m/s^2
noiseGyroMSEReal = [0.05; 0.05; 0.05] * unit_w; % rad/s
noiseAccMSEReal = [20; 20; 20] * unit_ug; % m/s^2

% Add colored or white Gaussian noise
AR_NOISE_ENABLED = 0;
sizeData = size(data);
lenData = sizeData(1);
noiseGyroPast = zeros(3, 3);
noiseAccPast = zeros(3, 3);
for i = 1 : lenData
    noiseGyro = normrnd(0, noiseGyroMSEReal') * 1;
    noiseAcc = normrnd(0, noiseAccMSEReal') * 1;

    if AR_NOISE_ENABLED == 1
        noiseGyro = noiseGyro - 1.5 * noiseGyroPast(1, :) - 0.75 * noiseGyroPast(2, : ) - 0.125 * noiseGyroPast(3, : );
        noiseAcc = noiseAcc - 1.5 * noiseAccPast(1, :) - 0.75 * noiseAccPast(2, : ) - 0.125 * noiseAccPast(3, : );
        
        noiseGyroPast(3, : ) = noiseGyroPast(2, : );
        noiseGyroPast(2, : ) = noiseGyroPast(1, : );
        noiseGyroPast(1, : ) = noiseGyro;
        
        noiseAccPast(3, : ) = noiseAccPast(2, : );
        noiseAccPast(2, : ) = noiseAccPast(1, : );
        noiseAccPast(1, : ) = noiseAcc;
    end
    %{
    data(i , 2 : 4) = data(i , 2 : 4) + noiseGyro;
    data(i , 5 : 7) = data(i , 5 : 7) + noiseAcc;
    %}
    data(i , 2 : 4) = data(i , 2 : 4) + driftReal' + noiseGyro;
    data(i , 5 : 7) = data(i , 5 : 7) + biasReal' + noiseAcc;
    
end




RuntimePrepare = toc;
disp(['Preparing rnning time = ', num2str(RuntimePrepare), 's']);


%% First KF
mx0 = [0.0 * unit_degree2rad;
       0.0 * unit_degree2rad;
       0.0 * unit_degree2rad;
       
       0;
       0;
       0;
       
       0 / Re;
       0 / Re;
       0;
       
       (0.2 * unit_w) ^ 2;
       (0.2 * unit_w) ^ 2;
       (0.2 * unit_w) ^ 2;
       
       (10 * unit_ug) ^ 2;
       (10 * unit_ug) ^ 2;
       (10 * unit_ug) ^ 2;
       
       100;
       10];


Cx0 = diag([(0.001 * unit_degree2rad) ^ 2;
            (0.001 * unit_degree2rad) ^ 2;
            (0.001 * unit_degree2rad) ^ 2;
            
            (10) ^ 2;
            (10) ^ 2;
            (10) ^ 2;
            
            (100 / Re) ^ 2;
            (100 / Re) ^ 2;
            (100) ^ 2;
            
            (0.2 * unit_w) ^ 2;
            (0.2 * unit_w) ^ 2;
            (0.2 * unit_w) ^ 2;
            
            (10 * unit_ug) ^ 2;
            (10 * unit_ug) ^ 2;
            (10 * unit_ug) ^ 2;
            
            (100) ^ 2;
            (10) ^ 2]);


Q = diag([(0.1 * unit_w) ^ 2, (0.1 * unit_w) ^ 2, (0.1 * unit_w) ^ 2, ...
    (20 * unit_ug) ^ 2, (20 * unit_ug) ^ 2, (20 * unit_ug) ^ 2, ...
    (10) ^ 2]);
R = diag([100 ^ 2, 10 ^ 2]);
        
disp('First Kalman filtering begin.');
tic;

Hinfinity = 0;
[la_kf1, lon_kf1, alt_kf1, v_kf1, pitch_kf1, roll_kf1, yaw_kf1, time_kf1, time_var1, error1, var1] = ...
    srukf(la0, lon0, h0, ve0, vn0, vu0, pitch0, roll0, yaw0, ...
    data, ...
    TIME_INTERVAL_IMU, TIME_INTERVAL_GPS, mx0, Cx0, Q, R, 1, Hinfinity);

RuntimeKF = toc;
disp(['First Kalman filtering rnning time = ', num2str(RuntimeKF), 's']);


la_kf1 = la_kf1 / unit_degree2rad;
lon_kf1 = lon_kf1 / unit_degree2rad;
pitch_kf1 = pitch_kf1 / unit_degree2rad;
roll_kf1 = roll_kf1 / unit_degree2rad;
yaw_kf1 = yaw_kf1 / unit_degree2rad;

ve_kf1 = v_kf1(1, : );
vn_kf1 = v_kf1(2, : );
vu_kf1 = v_kf1(3, : );

time_kf1(1, end + 1) = time_kf1(1, end) + 1000 * TIME_INTERVAL_IMU;
time_var1(1, end + 1) = time_var1(1, end) + 1000 * TIME_INTERVAL_GPS;

% Error of navigation results
len_kf1 = length(time_kf1);
len_error1 = min(len_kf1, len_norm);

time_error1 = time_kf1(1, 1 : len_error1);

pitch_error1 = pitch_kf1(1, 1 : len_error1) - pitch_norm(1, 1 : len_error1);
roll_error1 = roll_kf1(1, 1 : len_error1) - roll_norm(1, 1 : len_error1);
yaw_error1 = yaw_kf1(1, 1 : len_error1) - yaw_norm(1, 1 : len_error1);
for i = 1 : length(yaw_error1)
    if yaw_error1(i) > 180
        yaw_error1(i) = yaw_error1(i) - 360;
    end
end

ve_error1 = ve_kf1(1, 1 : len_error1) - ve_norm(1, 1 : len_error1);
vn_error1 = vn_kf1(1, 1 : len_error1) - vn_norm(1, 1 : len_error1);
vu_error1 = vu_kf1(1, 1 : len_error1) - vu_norm(1, 1 : len_error1);

la_error1 = la_kf1(1, 1 : len_error1) - la_norm(1, 1 : len_error1);
lon_error1 = lon_kf1(1, 1 : len_error1) - lon_norm(1, 1 : len_error1);
alt_error1 = alt_kf1(1, 1 : len_error1) - alt_norm(1, 1 : len_error1);




%% SINS
disp('SINS begin.');
tic;

[la_sins, lon_sins, alt_sins, v_sins, pitch_sins, roll_sins, yaw_sins, time_sins, time_var3, error3, var3] = ...
    sins(la0, lon0, h0, ve0, vn0, vu0, pitch0, roll0, yaw0, ...
    data, ...
    TIME_INTERVAL_IMU, 1);


RuntimeSINS = toc;
disp(['SINS rnning time = ', num2str(RuntimeSINS), 's']);


la_sins = la_sins / unit_degree2rad;
lon_sins = lon_sins / unit_degree2rad;
pitch_sins = pitch_sins / unit_degree2rad;
roll_sins = roll_sins / unit_degree2rad;
yaw_sins = yaw_sins / unit_degree2rad;

ve_sins = v_sins(1, : );
vn_sins = v_sins(2, : );
vu_sins = v_sins(3, : );

time_sins(1, end + 1) = time_sins(1, end) + 1000 * TIME_INTERVAL_IMU;
time_var3(1, end + 1) = time_var3(1, end) + 1000 * TIME_INTERVAL_GPS;

% Error of navigation results
len_sins = length(time_sins);
len_error = min(len_sins, len_norm);

time_error = time_sins(1, 1 : len_error);

pitch_error = pitch_sins(1, 1 : len_error) - pitch_norm(1, 1 : len_error);
roll_error = roll_sins(1, 1 : len_error) - roll_norm(1, 1 : len_error);
yaw_error = yaw_sins(1, 1 : len_error) - yaw_norm(1, 1 : len_error);
for i = 1 : length(yaw_error)
    if yaw_error(i) > 180
        yaw_error(i) = yaw_error(i) - 360;
    end
end

ve_error = ve_sins(1, 1 : len_error) - ve_norm(1, 1 : len_error);
vn_error = vn_sins(1, 1 : len_error) - vn_norm(1, 1 : len_error);
vu_error = vu_sins(1, 1 : len_error) - vu_norm(1, 1 : len_error);

la_error = la_sins(1, 1 : len_error) - la_norm(1, 1 : len_error);
lon_error = lon_sins(1, 1 : len_error) - lon_norm(1, 1 : len_error);
alt_error = alt_sins(1, 1 : len_error) - alt_norm(1, 1 : len_error);




%% Drawing results
disp('Drawing results begin.');
tic;

figure('name', 'Attitude Error');
subplot(3, 1, 1), 
plot(time_error1(1 : end), pitch_error1(1 : end), 'Color', 'r'), hold on;
plot(time_error(1 : end), pitch_error(1 : end), 'Color', 'k'), hold on;
legend('SRUKF', 'SINS'); title('Pitch');
subplot(3, 1, 2), 
plot(time_error1(1 : end), roll_error1(1 : end), 'Color', 'r'), hold on;
plot(time_error(1 : end), roll_error(1 : end), 'Color', 'k'), hold on;
legend('SRUKF', 'SINS'); title('Roll');
subplot(3, 1, 3), 
plot(time_error1(1 : end), yaw_error1(1 : end), 'Color', 'r'), hold on;
plot(time_error(1 : end), yaw_error(1 : end), 'Color', 'k'), hold on;
legend('SRUKF', 'SINS'); title('Yaw');

figure('name', 'Velocity Error');
subplot(3, 1, 1), 
plot(time_error1(1 : end), ve_error1(1 : end), 'Color', 'r'), hold on;
plot(time_error(1 : end), ve_error(1 : end), 'Color', 'k'), hold on;
legend('SRUKF', 'SINS'); title('East');
subplot(3, 1, 2), 
plot(time_error1(1 : end), vn_error1(1 : end), 'Color', 'r'), hold on;
plot(time_error(1 : end), vn_error(1 : end), 'Color', 'k'), hold on;
legend('SRUKF', 'SINS'); title('North');
subplot(3, 1, 3), 
plot(time_error1(1 : end), vu_error1(1 : end), 'Color', 'r'), hold on;
plot(time_error(1 : end), vu_error(1 : end), 'Color', 'k'), hold on;
legend('SRUKF', 'SINS'); title('Up');

figure('name', 'Position Error');
subplot(3, 1, 1), 
plot(time_error1(1 : end), la_error1(1 : end) * Re, 'Color', 'r'), hold on;
plot(time_error(1 : end), la_error(1 : end) * Re, 'Color', 'k'), hold on;
legend('SRUKF', 'SINS'); title('North');
subplot(3, 1, 2), 
plot(time_error1(1 : end), lon_error1(1 : end) * Re, 'Color', 'r'), hold on;
plot(time_error(1 : end), lon_error(1 : end) * Re, 'Color', 'k'), hold on;
legend('SRUKF', 'SINS'); title('East');
subplot(3, 1, 3), 
plot(time_error1(1 : end), alt_error1(1 : end), 'Color', 'r'), hold on;
plot(time_error(1 : end), alt_error(1 : end), 'Color', 'k'), hold on;
legend('SRUKF', 'SINS'); title('Altitude');


figure('name', 'Kalman Filtering Tilt Estimation');
subplot(3, 1, 1), plot(time_var1(1 : end), error1(1, 1 : end)), title('Tilt east');
subplot(3, 1, 2), plot(time_var1(1 : end), error1(2, 1 : end)), title('Tilt north');
subplot(3, 1, 3), plot(time_var1(1 : end), error1(3, 1 : end)), title('Tilt up');

figure('name', 'Kalman Filtering Velocity Estimation');
subplot(3, 1, 1), plot(time_var1(1 : end), error1(4, 1 : end)), title('Velocity error east');
subplot(3, 1, 2), plot(time_var1(1 : end), error1(5, 1 : end)), title('Velocity error north');
subplot(3, 1, 3), plot(time_var1(1 : end), error1(6, 1 : end)), title('Velocity error up');

figure('name', 'Kalman Filtering Position Estimation');
subplot(3, 1, 1), plot(time_var1(1 : end), error1(7, 1 : end)), title('Latitude error');
subplot(3, 1, 2), plot(time_var1(1 : end), error1(8, 1 : end)), title('Longitude error');
subplot(3, 1, 3), plot(time_var1(1 : end), error1(9, 1 : end)), title('Height error');

figure('name', 'Kalman Filtering IMU Error Estimation');
subplot(2, 3, 1), plot(time_var1(1 : end), error1(10, 1 : end)), title('Gyroscope bias east');
subplot(2, 3, 2), plot(time_var1(1 : end), error1(11, 1 : end)), title('Gyroscope bias north');
subplot(2, 3, 3), plot(time_var1(1 : end), error1(12, 1 : end)), title('Gyroscope bias up');
subplot(2, 3, 4), plot(time_var1(1 : end), error1(13, 1 : end)), title('Accelerometer bias east');
subplot(2, 3, 5), plot(time_var1(1 : end), error1(14, 1 : end)), title('Accelerometer bias north');
subplot(2, 3, 6), plot(time_var1(1 : end), error1(15, 1 : end)), title('Accelerometer bias up');

figure('name', 'Mean Square Error of GNSS Receiver Error Estimation');
subplot(2, 1, 1), plot(time_var1(1 : end), error1(16, 1 : end)), title('GNSS receiver clock position error');
subplot(2, 1, 2), plot(time_var1(1 : end), error1(17, 1 : end)), title('GNSS receiver clock velocity error');




figure('name', 'Mean Square Error of Tilt Estimation MSE');
subplot(3, 1, 1), plot(time_var1(1 : end), var1(1, 1 : end)), title('Tilt east');
subplot(3, 1, 2), plot(time_var1(1 : end), var1(2, 1 : end)), title('Tilt north');
subplot(3, 1, 3), plot(time_var1(1 : end), var1(3, 1 : end)), title('Tilt up');

figure('name', 'Mean Square Error of Velocity Estimation MSE');
subplot(3, 1, 1), plot(time_var1(1 : end), var1(4, 1 : end)), title('Velocity error east');
subplot(3, 1, 2), plot(time_var1(1 : end), var1(5, 1 : end)), title('Velocity error north');
subplot(3, 1, 3), plot(time_var1(1 : end), var1(6, 1 : end)), title('Velocity error up');

figure('name', 'Mean Square Error of Position Estimation MSE');
subplot(3, 1, 1), plot(time_var1(1 : end), var1(7, 1 : end)), title('Latitude error');
subplot(3, 1, 2), plot(time_var1(1 : end), var1(8, 1 : end)), title('Longitude error');
subplot(3, 1, 3), plot(time_var1(1 : end), var1(9, 1 : end)), title('Height error');

figure('name', 'Mean Square Error of IMU Error Estimation MSE');
subplot(2, 3, 1), plot(time_var1(1 : end), var1(10, 1 : end)), title('Gyroscope bias east');
subplot(2, 3, 2), plot(time_var1(1 : end), var1(11, 1 : end)), title('Gyroscope bias north');
subplot(2, 3, 3), plot(time_var1(1 : end), var1(12, 1 : end)), title('Gyroscope bias up');
subplot(2, 3, 4), plot(time_var1(1 : end), var1(13, 1 : end)), title('Accelerometer bias east');
subplot(2, 3, 5), plot(time_var1(1 : end), var1(14, 1 : end)), title('Accelerometer bias north');
subplot(2, 3, 6), plot(time_var1(1 : end), var1(15, 1 : end)), title('Accelerometer bias up');

figure('name', 'Mean Square Error of GNSS Receiver Error Estimation MSE');
subplot(2, 1, 1), plot(time_var1(1 : end), var1(16, 1 : end)), title('GNSS receiver clock position error');
subplot(2, 1, 2), plot(time_var1(1 : end), var1(17, 1 : end)), title('GNSS receiver clock velocity error');


RuntimeDraw = toc;
disp(['Drawing results running time = ', num2str(RuntimeDraw), 's']);





