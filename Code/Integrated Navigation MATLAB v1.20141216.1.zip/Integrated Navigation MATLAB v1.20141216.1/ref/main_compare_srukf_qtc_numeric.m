close all;
clear all;


SAMPLING_RATE_IMU = 100; % 100Hz
TIME_INTERVAL_IMU = 0.01; % 0.01s

SAMPLING_RATE_GPS = 10; % 100Hz
TIME_INTERVAL_GPS = 0.1; % 0.1s


% Relay before using feedback correction
RELAY_BEFORE_FEEDBACK_CORRECTION = 0 * 60 / TIME_INTERVAL_IMU;

% Global definition
wie = 7.292115147e-5; % rad/s
Re = 6378245; % Earth radius, m
e = 1 / 298.3; % Earth eccentrity
g0 = 9.7803267714; % m/s^2
gk1 = 0.00193185138639;
gk2 = 0.00669437999013;

% Unit conversion
unit_degree2rad = (pi / 180); % degrees to rad
unit_w = (pi / 3600 / 180); % degrees/h to rad/s
unit_ug = (g0 * 10 ^ (-6)); % ug to m/s^2


%% Import data
disp('Import data begin.');
tic;


% Import both IMU and GNSS data
SWITCH_FILE = 3;

if SWITCH_FILE == 0
    data = importdata('../Data/201401031452 (GPS L1 Static)/both.dat');
    data_norm = importdata('../Data/201401031452 (GPS L1 Static)/nav_normal.dat');
    data_gnss = importdata('../Data/201401031452 (GPS L1 Static)/nav_gnss.dat');
elseif SWITCH_FILE == 1
    data = importdata('../Data/201401031508 (GPS L1 Vn 1g 300)/both.dat');
    data_norm = importdata('../Data/201401031508 (GPS L1 Vn 1g 300)/nav_normal.dat');
    data_gnss = importdata('../Data/201401031508 (GPS L1 Vn 1g 300)/nav_gnss.dat');
elseif SWITCH_FILE == 2
    data = importdata('../Data/201401031519 (GPS L1 Vn 1g 300 6g 900)/both.dat');
    data_norm = importdata('../Data/201401031519 (GPS L1 Vn 1g 300 6g 900)/nav_normal.dat');
    data_gnss = importdata('../Data/201401031519 (GPS L1 Vn 1g 300 6g 900)/nav_gnss.dat');
elseif SWITCH_FILE == 3
    data = importdata('../Data/201401031548 (GPS L1 Vn 1g 300 6g 1200)/both.dat');
    data_norm = importdata('../Data/201401031548 (GPS L1 Vn 1g 300 6g 1200)/nav_normal.dat');
    data_gnss = importdata('../Data/201401031548 (GPS L1 Vn 1g 300 6g 1200)/nav_gnss.dat');
elseif SWITCH_FILE == 4
    data = importdata('../Data/201401031607 (GPS L1 Vn 1g 300 4g 900)/both.dat');
    data_norm = importdata('../Data/201401031607 (GPS L1 Vn 1g 300 4g 900)/nav_normal.dat');
    data_gnss = importdata('../Data/201401031607 (GPS L1 Vn 1g 300 4g 900)/nav_gnss.dat');
elseif SWITCH_FILE == 5
    data = importdata('../Data/201401031355 (BD B3 Vn 300)/both.dat');
    data_norm = importdata('../Data/201401031355 (BD B3 Vn 300)/nav_normal.dat');
    data_gnss = importdata('../Data/201401031355 (BD B3 Vn 300)/nav_gnss.dat');
end


% Import normal navigation results
len_norm = length(data_norm);
time_norm = data_norm( : , 1)';
pitch_norm = data_norm( : , 2)';
roll_norm = data_norm( : , 3)';
yaw_norm = data_norm( : , 4)';
ve_norm = data_norm( : , 5)';
vn_norm = data_norm( : , 6)';
vu_norm = data_norm( : , 7)';
la_norm = data_norm( : , 8)';
lon_norm = data_norm( : , 9)';
alt_norm = data_norm( : , 10)';


% Import GNSS navigation results
len_gnss = length(data_gnss);
time_gnss = data_gnss( : , 1)';
la_gnss = data_gnss( : , 2)';
lon_gnss = data_gnss( : , 3)';
alt_gnss = data_gnss( : , 4)';
ve_gnss = data_gnss( : , 5)';
vn_gnss = data_gnss( : , 6)';
vu_gnss = data_gnss( : , 7)';



RuntimeImport = toc;
disp(['Importing data rnning time = ', num2str(RuntimeImport), 's']);



%% Prepare KF
disp('Kalman filter preparing begin.');
tic;

% KF
la0 = 39 * unit_degree2rad;
lon0 = 116 * unit_degree2rad;
h0 = 100;
ve0 =0;
vn0 = 0;
vu0 = 0;
pitch0 = 0 * unit_degree2rad;
roll0 = 0 * unit_degree2rad;
yaw0 = 0 * unit_degree2rad;

% IMU error
drift = [0.008; 0.008; 0.008] * unit_w; % rad/s
bias = [50; 50; 50] * unit_ug; % m/s^2
noiseGyroMSE = [0.003; 0.003; 0.003] * unit_w; % rad/s
noiseAccMSE = [10; 10; 10] * unit_ug; % m/s^2


% Add colored or white Gaussian noise
AR_NOISE_ENABLED = 1;
sizeData = size(data);
lenData = sizeData(1);
noiseGyroPast = zeros(3, 3);
noiseAccPast = zeros(3, 3);
for i = 1 : lenData
    noiseGyro = normrnd(0, noiseGyroMSE') * 100;
    noiseAcc = normrnd(0, noiseAccMSE') * 100;

    if AR_NOISE_ENABLED == 1
        noiseGyro = noiseGyro - 1.5 * noiseGyroPast(1, :) - 0.75 * noiseGyroPast(2, : ) - 0.125 * noiseGyroPast(3, : );
        noiseAcc = noiseAcc - 1.5 * noiseAccPast(1, :) - 0.75 * noiseAccPast(2, : ) - 0.125 * noiseAccPast(3, : );
        
        noiseGyroPast(3, : ) = noiseGyroPast(2, : );
        noiseGyroPast(2, : ) = noiseGyroPast(1, : );
        noiseGyroPast(1, : ) = noiseGyro;
        
        noiseAccPast(3, : ) = noiseAccPast(2, : );
        noiseAccPast(2, : ) = noiseAccPast(1, : );
        noiseAccPast(1, : ) = noiseAcc;
    end
    
    data(i , 2 : 4) = data(i , 2 : 4) + drift' + noiseGyro;
    data(i , 5 : 7) = data(i , 5 : 7) + bias' + noiseAcc;
end


% GPS measurements error
noisePMSE = [0.1; 0.1; 0.15]; % m 
noiseVMSE = [0.01 / Re; 0.01 / Re; 0.05]; % m/s
noisePseuMSE = 0.1; % Pseudorage measurement white Gauss noise MSE (m)
noisePseuRateMSE = 0.01; % Pseudorage rate measurement white Gauss noise MSE (m/s)
errorPClock = 1; % Timer deviation caused position deviation (m)
errorVClock = 0.1; % Timer frequency drift caused velocity deviation (m/s)
noiseVClockMSE = 0.01; % Timer frequency drift caused velocity deviation white Gauss noise MSE (m/s)

% Initialize tilt
seitaX = 0.001 * unit_degree2rad;
seitaY = 0.001 * unit_degree2rad;
seitaZ = 0.001 * unit_degree2rad;
seitaSum = sqrt(seitaX ^ 2 + seitaY ^ 2 + seitaZ ^ 2);

mx0 = [cos(seitaSum / 2);
       sin(seitaSum / 2) * seitaX / seitaSum;
       sin(seitaSum / 2) * seitaY / seitaSum;
       sin(seitaSum / 2) * seitaZ / seitaSum;
       0;
       0;
       0;
       0 * unit_degree2rad;
       0 * unit_degree2rad;
       0;
       drift(1, 1);
       drift(2, 1);
       drift(3, 1);
       bias(1, 1);
       bias(2, 1);
       bias(3, 1);
       errorPClock;
       errorVClock];

   
Cx0 = diag([(1e-1) ^ 2;
            (1e-1) ^ 2;
            (1e-1) ^ 2;
            (1e-1) ^ 2;
            
            (1e-1) ^ 2;
            (1e-1) ^ 2;
            (1e-1) ^ 2;
            
            (1e-4 * unit_degree2rad) ^ 2;
            (1e-4 * unit_degree2rad) ^ 2;
            (1e-1) ^ 2;
            
            (1e-1) ^ 2;
            (1e-1) ^ 2;
            (1e-1) ^ 2;
            
            (1e-1) ^ 2;
            (1e-1) ^ 2;
            (1e-1) ^ 2;
            
            (1e-1) ^ 2;
            (1e-1) ^ 2]);


Q = diag([noiseGyroMSE(1, 1) ^ 2, noiseGyroMSE(2, 1) ^ 2, noiseGyroMSE(3, 1) ^ 2, ...
    noiseAccMSE(1, 1) ^ 2, noiseAccMSE(2, 1) ^ 2, noiseAccMSE(3, 1) ^ 2, ...
    noiseVClockMSE ^ 2]);

R = zeros(20, 20);
R(1, 1) = noisePseuMSE ^ 2;
R(2, 2) = noisePseuRateMSE ^ 2;

RuntimePrepare = toc;
disp(['Preparing rnning time = ', num2str(RuntimePrepare), 's']);


%% First KF
disp('First Kalman filtering begin.');
tic;

Hinfinity = 0;
[la_kf1, lon_kf1, alt_kf1, v_kf1, pitch_kf1, roll_kf1, yaw_kf1, time_kf1, time_var1, error1, var1] = ...
    srukf_qtc_euler(la0, lon0, h0, ve0, vn0, vu0, pitch0, roll0, yaw0, ...
    data, ...
    TIME_INTERVAL_IMU, TIME_INTERVAL_GPS, mx0, Cx0, Q, R, 1, Hinfinity);

RuntimeKF = toc;
disp(['First Kalman filtering rnning time = ', num2str(RuntimeKF), 's']);


la_kf1 = la_kf1 / unit_degree2rad;
lon_kf1 = lon_kf1 / unit_degree2rad;
pitch_kf1 = pitch_kf1 / unit_degree2rad;
roll_kf1 = roll_kf1 / unit_degree2rad;
yaw_kf1 = yaw_kf1 / unit_degree2rad;

ve_kf1 = v_kf1(1, : );
vn_kf1 = v_kf1(2, : );
vu_kf1 = v_kf1(3, : );

time_kf1(1, end + 1) = time_kf1(1, end) + 1000 * TIME_INTERVAL_IMU;
time_var1(1, end + 1) = time_var1(1, end) + 1000 * TIME_INTERVAL_GPS;

% Error of navigation results
len_kf1 = length(time_kf1);
len_error1 = min(len_kf1, len_norm);

time_error1 = time_kf1(1, 1 : len_error1);

pitch_error1 = pitch_kf1(1, 1 : len_error1) - pitch_norm(1, 1 : len_error1);
roll_error1 = roll_kf1(1, 1 : len_error1) - roll_norm(1, 1 : len_error1);
yaw_error1 = yaw_kf1(1, 1 : len_error1) - yaw_norm(1, 1 : len_error1);
for i = 1 : length(yaw_error1)
    if yaw_error1(i) > 180
        yaw_error1(i) = yaw_error1(i) - 360;
    end
end

ve_error1 = ve_kf1(1, 1 : len_error1) - ve_norm(1, 1 : len_error1);
vn_error1 = vn_kf1(1, 1 : len_error1) - vn_norm(1, 1 : len_error1);
vu_error1 = vu_kf1(1, 1 : len_error1) - vu_norm(1, 1 : len_error1);

la_error1 = la_kf1(1, 1 : len_error1) - la_norm(1, 1 : len_error1);
lon_error1 = lon_kf1(1, 1 : len_error1) - lon_norm(1, 1 : len_error1);
alt_error1 = alt_kf1(1, 1 : len_error1) - alt_norm(1, 1 : len_error1);




%% Second KF
disp('Second Kalman filtering begin.');
tic;

Hinfinity = 0;
[la_kf2, lon_kf2, alt_kf2, v_kf2, pitch_kf2, roll_kf2, yaw_kf2, time_kf2, time_var2, error2, var2] = ...
    srukf_qtc_rk4(la0, lon0, h0, ve0, vn0, vu0, pitch0, roll0, yaw0, ...
    data, ...
    TIME_INTERVAL_IMU, TIME_INTERVAL_GPS, mx0, Cx0, Q, R, 1, Hinfinity);

RuntimeKF = toc;
disp(['Second Kalman filtering rnning time = ', num2str(RuntimeKF), 's']);


la_kf2 = la_kf2 / unit_degree2rad;
lon_kf2 = lon_kf2 / unit_degree2rad;
pitch_kf2 = pitch_kf2 / unit_degree2rad;
roll_kf2 = roll_kf2 / unit_degree2rad;
yaw_kf2 = yaw_kf2 / unit_degree2rad;

ve_kf2 = v_kf2(1, : );
vn_kf2 = v_kf2(2, : );
vu_kf2 = v_kf2(3, : );

time_kf2(1, end + 1) = time_kf2(1, end) + 1000 * TIME_INTERVAL_IMU;
time_var2(1, end + 1) = time_var2(1, end) + 1000 * TIME_INTERVAL_GPS;

% Error of navigation results
len_kf2 = length(time_kf2);
len_error2 = min(len_kf2, len_norm);

time_error2 = time_kf2(1, 1 : len_error2);

pitch_error2 = pitch_kf2(1, 1 : len_error2) - pitch_norm(1, 1 : len_error2);
roll_error2 = roll_kf2(1, 1 : len_error2) - roll_norm(1, 1 : len_error2);
yaw_error2 = yaw_kf2(1, 1 : len_error2) - yaw_norm(1, 1 : len_error2);
for i = 1 : length(yaw_error2)
    if yaw_error2(i) > 180
        yaw_error2(i) = yaw_error2(i) - 360;
    end
end

ve_error2 = ve_kf2(1, 1 : len_error2) - ve_norm(1, 1 : len_error2);
vn_error2 = vn_kf2(1, 1 : len_error2) - vn_norm(1, 1 : len_error2);
vu_error2 = vu_kf2(1, 1 : len_error2) - vu_norm(1, 1 : len_error2);

la_error2 = la_kf2(1, 1 : len_error2) - la_norm(1, 1 : len_error2);
lon_error2 = lon_kf2(1, 1 : len_error2) - lon_norm(1, 1 : len_error2);
alt_error2 = alt_kf2(1, 1 : len_error2) - alt_norm(1, 1 : len_error2);


%% Drawing results
disp('Drawing results begin.');
tic;

figure('name', 'Attitude Error');
subplot(3, 1, 1), 
plot(time_error1(1 : end), pitch_error1(1 : end), 'Color', 'r'), hold on;
plot(time_error2(1 : end), pitch_error2(1 : end), 'Color', 'b'), hold on;
legend('QSRUKF Euler', 'QSRUKF RK4'); title('Pitch');
subplot(3, 1, 2), 
plot(time_error1(1 : end), roll_error1(1 : end), 'Color', 'r'), hold on;
plot(time_error2(1 : end), roll_error2(1 : end), 'Color', 'b'), hold on;
legend('QSRUKF Euler', 'QSRUKF RK4'); title('Roll');
subplot(3, 1, 3), 
plot(time_error1(1 : end), yaw_error1(1 : end), 'Color', 'r'), hold on;
plot(time_error2(1 : end), yaw_error2(1 : end), 'Color', 'b'), hold on;
legend('QSRUKF Euler', 'QSRUKF RK4'); title('Yaw');

figure('name', 'Velocity Error');
subplot(3, 1, 1), 
plot(time_error1(1 : end), ve_error1(1 : end), 'Color', 'r'), hold on;
plot(time_error2(1 : end), ve_error2(1 : end), 'Color', 'b'), hold on;
legend('QSRUKF Euler', 'QSRUKF RK4'); title('East');
subplot(3, 1, 2), 
plot(time_error1(1 : end), vn_error1(1 : end), 'Color', 'r'), hold on;
plot(time_error2(1 : end), vn_error2(1 : end), 'Color', 'b'), hold on;
legend('QSRUKF Euler', 'QSRUKF RK4'); title('North');
subplot(3, 1, 3), 
plot(time_error1(1 : end), vu_error1(1 : end), 'Color', 'r'), hold on;
plot(time_error2(1 : end), vu_error2(1 : end), 'Color', 'b'), hold on;
legend('QSRUKF Euler', 'QSRUKF RK4'); title('Up');

figure('name', 'Position Error');
subplot(3, 1, 1), 
plot(time_error1(1 : end), la_error1(1 : end), 'Color', 'r'), hold on;
plot(time_error2(1 : end), la_error2(1 : end), 'Color', 'b'), hold on;
legend('QSRUKF Euler', 'QSRUKF RK4'); title('Latitude');
subplot(3, 1, 2), 
plot(time_error1(1 : end), lon_error1(1 : end), 'Color', 'r'), hold on;
plot(time_error2(1 : end), lon_error2(1 : end), 'Color', 'b'), hold on;
legend('QSRUKF Euler', 'QSRUKF RK4'); title('Longitude');
subplot(3, 1, 3), 
plot(time_error1(1 : end), alt_error1(1 : end), 'Color', 'r'), hold on;
plot(time_error2(1 : end), alt_error2(1 : end), 'Color', 'b'), hold on;
legend('QSRUKF Euler', 'QSRUKF RK4'); title('Altitude');

figure('name', 'Mean Square Error of Quaternion Estimation');
subplot(4, 1, 1), 
plot(time_var1(1 : end), var1(1, 1 : end), 'Color', 'r'), hold on;
plot(time_var2(1 : end), var2(1, 1 : end), 'Color', 'b'), hold on;
legend('QSRUKF Euler', 'QSRUKF RK4'); title('Q0');
subplot(4, 1, 2), 
plot(time_var1(1 : end), var1(2, 1 : end), 'Color', 'r'), hold on;
plot(time_var2(1 : end), var2(2, 1 : end), 'Color', 'b'), hold on;
legend('QSRUKF Euler', 'QSRUKF RK4'); title('Q1');
subplot(4, 1, 3), 
plot(time_var1(1 : end), var1(3, 1 : end), 'Color', 'r'), hold on;
plot(time_var2(1 : end), var2(3, 1 : end), 'Color', 'b'), hold on;
legend('QSRUKF Euler', 'QSRUKF RK4'); title('Q2');
subplot(4, 1, 4), 
plot(time_var1(1 : end), var1(4, 1 : end), 'Color', 'r'), hold on;
plot(time_var2(1 : end), var2(4, 1 : end), 'Color', 'b'), hold on;
legend('QSRUKF Euler', 'QSRUKF RK4'); title('Q3');

figure('name', 'Mean Square Error of deltaV/deltaP/IMU Estimation');
subplot(4, 3, 1), 
plot(time_var1(1 : end), var1(5, 1 : end), 'Color', 'r'), hold on;
plot(time_var2(1 : end), var2(5, 1 : end), 'Color', 'b'), hold on;
legend('QSRUKF Euler', 'QSRUKF RK4'); title('Velocity east error MSE');
subplot(4, 3, 2), 
plot(time_var1(1 : end), var1(6, 1 : end), 'Color', 'r'), hold on;
plot(time_var2(1 : end), var2(6, 1 : end), 'Color', 'b'), hold on;
legend('QSRUKF Euler', 'QSRUKF RK4'); title('Velocity north error MSE');
subplot(4, 3, 3), 
plot(time_var1(1 : end), var1(7, 1 : end), 'Color', 'r'), hold on;
plot(time_var2(1 : end), var2(7, 1 : end), 'Color', 'b'), hold on;
legend('QSRUKF Euler', 'QSRUKF RK4'); title('Velocity up error MSE');
subplot(4, 3, 4), 
plot(time_var1(1 : end), var1(8, 1 : end), 'Color', 'r'), hold on;
plot(time_var2(1 : end), var2(8, 1 : end), 'Color', 'b'), hold on;
legend('QSRUKF Euler', 'QSRUKF RK4'); title('Latitude error MSE');
subplot(4, 3, 5), 
plot(time_var1(1 : end), var1(9, 1 : end), 'Color', 'r'), hold on;
plot(time_var2(1 : end), var2(9, 1 : end), 'Color', 'b'), hold on;
legend('QSRUKF Euler', 'QSRUKF RK4'); title('Longitude error MSE');
subplot(4, 3, 6), 
plot(time_var1(1 : end), var1(10, 1 : end), 'Color', 'r'), hold on;
plot(time_var2(1 : end), var2(10, 1 : end), 'Color', 'b'), hold on;
legend('QSRUKF Euler', 'QSRUKF RK4'); title('Altitude error MSE');
subplot(4, 3, 7), 
plot(time_var1(1 : end), var1(11, 1 : end), 'Color', 'r'), hold on;
plot(time_var2(1 : end), var2(11, 1 : end), 'Color', 'b'), hold on;
legend('QSRUKF Euler', 'QSRUKF RK4'); title('Gyroscope drift x MSE');
subplot(4, 3, 8),
plot(time_var1(1 : end), var1(12, 1 : end), 'Color', 'r'), hold on;
plot(time_var2(1 : end), var2(12, 1 : end), 'Color', 'b'), hold on;
legend('QSRUKF Euler', 'QSRUKF RK4'); title('Gyroscope drift y MSE');
subplot(4, 3, 9), 
plot(time_var1(1 : end), var1(13, 1 : end), 'Color', 'r'), hold on;
plot(time_var2(1 : end), var2(13, 1 : end), 'Color', 'b'), hold on;
legend('QSRUKF Euler', 'QSRUKF RK4'); title('Gyroscope drift z MSE');
subplot(4, 3, 10),
plot(time_var1(1 : end), var1(14, 1 : end), 'Color', 'r'), hold on;
plot(time_var2(1 : end), var2(14, 1 : end), 'Color', 'b'), hold on;
legend('QSRUKF Euler', 'QSRUKF RK4'); title('Accelerometer bias x MSE');
subplot(4, 3, 11), 
plot(time_var1(1 : end), var1(15, 1 : end), 'Color', 'r'), hold on;
plot(time_var2(1 : end), var2(15, 1 : end), 'Color', 'b'), hold on;
legend('QSRUKF Euler', 'QSRUKF RK4'); title('Accelerometer bias y MSE');
subplot(4, 3, 12), 
plot(time_var1(1 : end), var1(16, 1 : end), 'Color', 'r'), hold on;
plot(time_var2(1 : end), var2(16, 1 : end), 'Color', 'b'), hold on;
legend('QSRUKF Euler', 'QSRUKF RK4'); title('Accelerometer bias z MSE');


figure('name', 'Mean Square Error of GNSS receiver timer Estimation');
subplot(2, 1, 1), 
plot(time_var1(1 : end), var1(17, 1 : end), 'Color', 'r'), hold on;
plot(time_var2(1 : end), var2(17, 1 : end), 'Color', 'b'), hold on;
legend('QSRUKF Euler', 'QSRUKF RK4'); title('GNSS receiver clock position error MSE');
subplot(2, 1, 2), 
plot(time_var1(1 : end), var1(18, 1 : end), 'Color', 'r'), hold on;
plot(time_var2(1 : end), var2(18, 1 : end), 'Color', 'b'), hold on;
legend('QSRUKF Euler', 'QSRUKF RK4'); title('GNSS receiver clock velocity error MSE');


RuntimeDraw = toc;
disp(['Drawing results running time = ', num2str(RuntimeDraw), 's']);





