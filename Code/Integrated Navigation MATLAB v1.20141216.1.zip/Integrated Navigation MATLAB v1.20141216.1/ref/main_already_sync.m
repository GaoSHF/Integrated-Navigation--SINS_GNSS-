close all;
clear all;


SAMPLING_RATE_IMU = 100; % 100Hz
TIME_INTERVAL_IMU = 0.01; % 0.01s

SAMPLING_RATE_GPS = 100; % 100Hz
TIME_INTERVAL_GPS = 0.01; % 0.01s

TIME_LENGTH_ALIGNMENT = (5 * 60); % 5min coarse-alignment
LENGTH_ALIGNMENT = (TIME_LENGTH_ALIGNMENT / TIME_INTERVAL_IMU);

% Relay before using feedback correction
RELAY_BEFORE_FEEDBACK_CORRECTION = 0 * 60 / TIME_INTERVAL_IMU;

% Global definition
wie = 7.292115147e-5; % rad/s
Re = 6378245; % Earth radius, m
e = 1 / 298.3; % Earth eccentrity
g0 = 9.7803267714; % m/s^2
gk1 = 0.00193185138639;
gk2 = 0.00669437999013;

% Unit conversion
unit_degree2rad = (pi / 180); % degrees to rad
unit_rad2degree = (180 / pi);
unit_w = (pi / 3600 / 180); % degrees/h to rad/s
unit_ug = (g0 * 10 ^ (-6)); % ug to m/s^2

%% Import IMU and GPS data
data_imu_temp = importdata('../Data/already sync/imu_1h.dat');
data_gps_temp = importdata('../Data/already sync/gps_1h.dat');

data_imu = data_imu_temp(1 : 50000, : );
data_gps = data_gps_temp(1 : 50000, : );
%data_imu = data_imu_temp( : , : );
%data_gps = data_gps_temp( : , : );

% UTC time
utc_imu = data_imu( : , 2)';
utc_gps = data_gps( : , 2)';

% Gyroscope data (degrees/h to rad/s)
w_imu(1 : 3, :) = (data_imu( : , 3 : 5) * unit_w)';

% Accelerometer data (g to m/s^2)
f_imu(1 : 3, :) = (data_imu( : , 6 : 8) * g0)';

%% Inport strapdown navigation results
len_ins = length(w_imu) - LENGTH_ALIGNMENT + 1;

% Strapdown navigation
data_ins = importdata('../Data/already sync/already_sync_sins.dat');

% time
utc_ins = data_ins( : , 1)';

% Attitude
pitch_ins = data_ins( : , 2)';
roll_ins = data_ins( : , 3)';
yaw_ins = data_ins( : , 4)';

% Velocity
v_ins = data_ins( : , 5 : 7)';

% Location, altitude
la_ins = data_ins( : , 8)';
lon_ins = data_ins( : ,9)';
h_ins = data_ins( : , 10)';



%% Initial value
% 1h
ve0 = 0;
vn0 = 0;
vu0 = 0;
la0 = 40.0211142228246 * unit_degree2rad;
lon0 = 116.3703629769560 * unit_degree2rad;
h0 = 43.0674;
% 1min
%ve0 = -60.542440167488820;
%vn0 = 12.517128987591928;
%vu0 = -0.663025961716411;
%la0 = 29.146706267977070 * unit_degree2rad;
%lon0 = 121.360149909644680 * unit_degree2rad;
%h0 = 2418.691384897396300;
%roll0 = 14.154302528542125 * unit_degree2rad;
%yaw0 = 2.958066786126155 * unit_degree2rad;
%pitch0 = 80.386784716753596 * unit_degree2rad;


%% Alignment
tic;

w_accum = zeros(3, 1);
acc_accum = zeros(3, 1);
% Accumulate IMU data
for i = 1 : LENGTH_ALIGNMENT
    w_accum(1, 1) = w_accum(1, 1) + w_imu(1, i);
    w_accum(2, 1) = w_accum(2, 1) + w_imu(2, i);
    w_accum(3, 1) = w_accum(3, 1) + w_imu(3, i);
    
    acc_accum(1, 1) = acc_accum(1, 1) + f_imu(1, i);
    acc_accum(2, 1) = acc_accum(2, 1) + f_imu(2, i);
    acc_accum(3, 1) = acc_accum(3, 1) + f_imu(3, i);
end
w_mean = w_accum / LENGTH_ALIGNMENT;
acc_mean = acc_accum / LENGTH_ALIGNMENT;

[Qua0, Ctb0, pitch0, roll0, yaw0] = sins_coarse_alignment(la0, w_mean, acc_mean);

disp('Alignment Result:');
disp(['    Pitch:', num2str(pitch0 / unit_degree2rad)]);
disp(['    Roll:', num2str(roll0 / unit_degree2rad)]);
disp(['    yaw:', num2str(yaw0 / unit_degree2rad)]);

RuntimeAlign = toc;

disp(['Coarse alignment rnning time = ', num2str(RuntimeAlign), 's']);




len_imu = length(utc_imu);
len_gnss = length(utc_gps);
len = min(len_imu, len_gnss) - LENGTH_ALIGNMENT;

data = zeros(len, 115);
data( : , 1) = data_imu(LENGTH_ALIGNMENT + 1 : LENGTH_ALIGNMENT + len, 2);
data( : , 2 : 4) = data_imu(LENGTH_ALIGNMENT + 1 : LENGTH_ALIGNMENT + len, 3 : 5) * unit_w;
data( : , 5 : 7) = data_imu(LENGTH_ALIGNMENT + 1 : LENGTH_ALIGNMENT + len, 6 : 8) * g0;
data( : , 8) = ones(len, 1); % fixQuality
data( : , 10) = data_gps(LENGTH_ALIGNMENT + 1 : LENGTH_ALIGNMENT + len, 3) * unit_degree2rad;
data( : , 11) = data_gps(LENGTH_ALIGNMENT + 1 : LENGTH_ALIGNMENT + len, 4) * unit_degree2rad;
data( : , 12) = data_gps(LENGTH_ALIGNMENT + 1 : LENGTH_ALIGNMENT + len, 5);
data( : , 13 : 15) = data_gps(LENGTH_ALIGNMENT + 1 : LENGTH_ALIGNMENT + len, 6 : 8);




%% Loose coupled Kalman Filter for 1h IMU/GPS data
tic;

h_gps = data_gps( : , 5)';
v_gps = data_gps( : , 6 : 8)';
v_gps_enu = v_gps;
%v_gps_enu = zeros(3, length(v_gps));
%for count_gps = 1 : length(v_gps)
%    v_gps_enu(1, count_gps) = ...
%        v_gps(1, count_gps) * cos(pi / 2 + lon_kf(count_imu)) + ...
%        v_gps(2, count_gps) * sin(pi / 2 + lon_kf(count_imu));
%    v_gps_enu(2, count_gps) = ...
%        -v_gps(1, count_gps) * cos(pi / 2 - la_kf(count_imu)) * sin(pi / 2 + lon_kf(count_imu)) + ...
%        v_gps(2, count_gps) * cos(pi / 2 - la_kf(count_imu)) * cos(pi / 2 + lon_kf(count_imu)) + ...
%        v_gps(3, count_gps) * sin(pi / 2 - la_kf(count_imu));
%    v_gps_enu(3, count_gps) = ...
%        v_gps(1, count_gps) * sin(pi / 2 - la_kf(count_imu)) * sin(pi / 2 + lon_kf(count_imu)) + ...
%        v_gps(2, count_gps) * sin(pi / 2 - la_kf(count_imu)) * cos(pi / 2 + lon_kf(count_imu)) - ...
%        v_gps(3, count_gps) * cos(pi / 2 - la_kf(count_imu));
%end

la_gps = data_gps( : , 3)' * unit_degree2rad;
lon_gps = data_gps( : , 4)' * unit_degree2rad;

% IMU error
drift = [0.008; 0.008; 0.008] * unit_w; % rad/s
bias = [50; 50; 50] * unit_ug; % m/s^2
noiseGyro = [0.003; 0.003; 0.003] * unit_w; % rad/s
noiseAcc = [10; 10; 10] * unit_ug; % m/s^2

% GPS measurements error
noiseP = [0.1 / Re; 0.1 / Re; 0.15]; % m 
noiseV = [0.01; 0.01; 0.01]; % m/s

mx0 = [0.003 * unit_degree2rad;
       0.003 * unit_degree2rad;
       0.003 * unit_degree2rad;
       0.1;
       0.1;
       0.1;
       0.01 * unit_degree2rad;
       0.01 * unit_degree2rad;
       0.1;
       drift(1, 1);
       drift(2, 1);
       drift(3, 1);
       bias(1, 1);
       bias(2, 1);
       bias(3, 1)];
Cx0 = diag([0.001,     0.001,     0.001, ...
            0.001,     0.001,     0.001, ...
            0.001,     0.001,     0.001, ...
            0.001,     0.001,     0.001, ...
            0.001,     0.001,     0.001]);

Q = diag([noiseGyro(1, 1) ^ 2, noiseGyro(2, 1) ^ 2, noiseGyro(3, 1) ^ 2, ...
    noiseAcc(1, 1) ^ 2, noiseAcc(2, 1) ^ 2, noiseAcc(3, 1) ^ 2]);
R = diag([noiseV(1, 1) ^ 2, noiseV(2, 1) ^ 2, noiseV(3, 1) ^ 2, noiseP(1, 1) ^ 2, noiseP(2, 1) ^ 2, noiseP(3, 1) ^ 2]);
        
% Loosely coupled INS/GPS Kalman Filter
len_kf = length(w_imu) - LENGTH_ALIGNMENT + 1;



% KF
[la_kf, lon_kf, h_kf, v_kf, pitch_kf, roll_kf, yaw_kf, time_kf, time_es, X_es, var_es] = ...
    kf(la0, lon0, h0, ve0, vn0, vu0, pitch0, roll0, yaw0, ...
    data, ...
    TIME_INTERVAL_IMU, TIME_INTERVAL_GPS, mx0, Cx0, Q, R, 0);
    
 
% Kalman filtering result time
time_kf(1, end + 1) = time_kf(1, end) + 1000 * TIME_INTERVAL_IMU;

% KF estimation time
time_es(1, end + 1) = time_es(1, end) + 1000 * TIME_INTERVAL_GPS;
    



% rad to degree
la_gps = la_gps / unit_degree2rad;
lon_gps = lon_gps / unit_degree2rad;
la_kf = la_kf / unit_degree2rad;
lon_kf = lon_kf / unit_degree2rad;
pitch_kf = pitch_kf / unit_degree2rad;
roll_kf = roll_kf / unit_degree2rad;
yaw_kf = yaw_kf / unit_degree2rad;








% SINS time
time_sins = utc_imu;
time_sins(1, end + 1) = time_sins(1, end) + 1000 * TIME_INTERVAL_IMU;

% GPS time
time_gps = utc_gps;



figure('name', 'Position');
subplot(3, 1, 1),
plot(time_sins(1 : end), la_ins(1 : length(time_sins)), 'Color', 'r'), hold on;
plot(time_gps(1 : end), la_gps(1 : length(time_gps)), 'Color', 'g'), hold on;
plot(time_kf(1 : end), la_kf(1 : end), 'Color', 'b'), hold on;
legend('INS', 'GPS', 'KF'); title('latitude');
subplot(3, 1, 2),
plot(time_sins(1 : end), lon_ins(1 : length(time_sins)), 'Color', 'r'), hold on;
plot(time_gps(1 : end), lon_gps(1 : length(time_gps)), 'Color', 'g'), hold on;
plot(time_kf(1 : end), lon_kf(1 : end), 'Color', 'b'), hold on;
legend('INS', 'GPS', 'KF'); title('longitude');
subplot(3, 1, 3),
plot(time_sins(1 : end), h_ins(1 : length(time_sins)), 'Color', 'r'), hold on;
plot(time_gps(1 : end), h_gps(1 : length(time_gps)), 'Color', 'g'), hold on;
plot(time_kf(1 : end), h_kf(1 : end), 'Color', 'b'), hold on;
legend('INS', 'GPS', 'KF'); title('Altitude');

figure('name', 'Velocity');
subplot(3, 1, 1),
plot(time_sins(1 : end), v_ins(1, 1 : length(time_sins)), 'Color', 'r'), hold on;
plot(time_gps(1 : end), v_gps_enu(1, 1 : length(time_gps)), 'Color', 'g'), hold on;
plot(time_kf(1 : end), v_kf(1, 1 : end), 'Color', 'b'), hold on;
legend('INS', 'GPS', 'KF'); title('east');
subplot(3, 1, 2),
plot(time_sins(1 : end), v_ins(2, 1 : length(time_sins)), 'Color', 'r'), hold on;
plot(time_gps(1 : end), v_gps_enu(2, 1 : length(time_gps)), 'Color', 'g'), hold on;
plot(time_kf(1 : end), v_kf(2, 1 : end), 'Color', 'b'), hold on;
legend('INS', 'GPS', 'KF'); title('north');
subplot(3, 1, 3),
plot(time_sins(1 : end), v_ins(3, 1 : length(time_sins)), 'Color', 'r'), hold on;
plot(time_gps(1 : end), v_gps_enu(3, 1 : length(time_gps)), 'Color', 'g'), hold on;
plot(time_kf(1 : end), v_kf(3, 1 : end), 'Color', 'b'), hold on;
legend('INS', 'GPS', 'KF'); title('up');

figure('name', 'Attitude');
subplot(3, 1, 1),
plot(time_sins(1 : end), roll_ins(1 : length(time_sins)), 'Color', 'r'), hold on;
plot(time_kf(1 : end), roll_kf(1 : end), 'Color', 'b'), hold on;
legend('INS', 'KF'); title('roll');
subplot(3, 1, 2),
plot(time_sins(1 : end), pitch_ins(1 : length(time_sins)), 'Color', 'r'), hold on;
plot(time_kf(1 : end), pitch_kf(1 : end), 'Color', 'b'), hold on;
legend('INS', 'KF'); title('pitch');
subplot(3, 1, 3),
plot(time_sins(1 : end), yaw_ins(1 : length(time_sins)), 'Color', 'r'), hold on;
plot(time_kf(1 : end), yaw_kf(1 : end), 'Color', 'b'), hold on;
legend('INS', 'KF'); title('yaw');

figure('name', 'Mean square error of estimation');
subplot(5, 3, 1), plot(time_es(1 : end), var_es(1, 1 : end) * unit_rad2degree), title('Tilt east');
subplot(5, 3, 2), plot(time_es(1 : end), var_es(2, 1 : end) * unit_rad2degree), title('Tilt north');
subplot(5, 3, 3), plot(time_es(1 : end), var_es(3, 1 : end) * unit_rad2degree), title('Tilt up');
subplot(5, 3, 4), plot(time_es(1 : end), var_es(4, 1 : end)), title('Velocity error east');
subplot(5, 3, 5), plot(time_es(1 : end), var_es(5, 1 : end)), title('Velocity error north');
subplot(5, 3, 6), plot(time_es(1 : end), var_es(6, 1 : end)), title('Velocity error up');
subplot(5, 3, 7), plot(time_es(1 : end), var_es(7, 1 : end) * unit_rad2degree), title('Latitude error');
subplot(5, 3, 8), plot(time_es(1 : end), var_es(8, 1 : end) * unit_rad2degree), title('Longitude error');
subplot(5, 3, 9), plot(time_es(1 : end), var_es(9, 1 : end)), title('Height error');
subplot(5, 3, 10), plot(time_es(1 : end), var_es(10, 1 : end) / unit_w), title('Gyroscope bias east');
subplot(5, 3, 11), plot(time_es(1 : end), var_es(11, 1 : end) / unit_w), title('Gyroscope bias north');
subplot(5, 3, 12), plot(time_es(1 : end), var_es(12, 1 : end) / unit_w), title('Gyroscope bias up');
subplot(5, 3, 13), plot(time_es(1 : end), var_es(13, 1 : end) / unit_ug), title('Accelerometer bias east');
subplot(5, 3, 14), plot(time_es(1 : end), var_es(14, 1 : end) / unit_ug), title('Accelerometer bias north');
subplot(5, 3, 15), plot(time_es(1 : end), var_es(15, 1 : end) / unit_ug), title('Accelerometer bias up');

RuntimeKF = toc;

disp(['Kalman filtering rnning time = ', num2str(RuntimeKF), 's']);






