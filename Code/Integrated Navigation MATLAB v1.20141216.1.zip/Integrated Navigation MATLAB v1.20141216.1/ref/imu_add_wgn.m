close all;
clear all;



wie = 7.292115147e-5;
Re = 6378137;
e = (1 / 298.257223563);

g0 = 9.7803267714;

unit_w = (pi / 3600 / 180);
unit_ug = (g0 * 0.000001);


gyro_drift = [0.008, 0.008, 0.008] * unit_w;
acc_bias = [50, 50, 50] * unit_ug;



data_imu = importdata('../../Data/201401031607 (GPS L1 Vn 1g 300 4g 900)/imu_fix.txt');
file_noise = fopen('../../Data/201401031607 (GPS L1 Vn 1g 300 4g 900)/imu_noise.txt', 'w');


%{
data_imu = importdata('../../Data/201401031548 (GPS L1 Vn 1g 300 6g 1200)/imu_fix.txt');
file_noise = fopen('../../Data/201401031548 (GPS L1 Vn 1g 300 6g 1200)/imu_noise.txt', 'w');
%}

%{
data_imu = importdata('../../Data/201401031519 (GPS L1 Vn 1g 300 6g 900)/imu_fix.txt');
file_noise = fopen('../../Data/201401031519 (GPS L1 Vn 1g 300 6g 900)/imu_noise.txt', 'w');
%}

%{
data_imu = importdata('../../Data/201401031508 (GPS L1 Vn 1g 300)/imu_fix.txt');
file_noise = fopen('../../Data/201401031508 (GPS L1 Vn 1g 300)/imu_noise.txt', 'w');
%}

%{
data_imu = importdata('../../Data/201401031452 (GPS L1 Static)/imu_fix.txt');
file_noise = fopen('../../Data/201401031452 (GPS L1 Static)/imu_noise.txt', 'w');
%}

%{
data_imu = importdata('../../Data/201401031355 (BD B3 Vn 300)/imu_fix.txt');
file_noise = fopen('../../Data/201401031355 (BD B3 Vn 300)/imu_noise.txt', 'w');
%}



% Import IMU simulation data
len_imu = length(data_imu);
time_imu = data_imu( : , 1)';
wibbx_imu = data_imu( : , 2)';
wibby_imu = data_imu( : , 3)';
wibbz_imu = data_imu( : , 4)';
fbx_imu = data_imu( : , 5)';
fby_imu = data_imu( : , 6)';
fbz_imu = data_imu( : , 7)';



% Add white-gauss noise
wibbx_imu_noise = awgn(wibbx_imu, 100, 'measured');
wibby_imu_noise = awgn(wibby_imu, 100, 'measured');
wibbz_imu_noise = awgn(wibbz_imu, 100, 'measured');
fbx_imu_noise = awgn(fbx_imu, 100, 'measured');
fby_imu_noise = awgn(fby_imu, 100, 'measured');
fbz_imu_noise = awgn(fbz_imu, 100, 'measured');

for i = 1 : len_imu

    % Add noise to w
    wibbx_imu_noise(i) = wibbx_imu_noise(i) + gyro_drift(1);
    wibby_imu_noise(i) = wibby_imu_noise(i) + gyro_drift(2);
    wibbz_imu_noise(i) = wibbz_imu_noise(i) + gyro_drift(3);
    
    % Add noise to f
    fbx_imu_noise(i) = fbx_imu_noise(i) + acc_bias(1);
    fby_imu_noise(i) = fby_imu_noise(i) + acc_bias(2);
    fbz_imu_noise(i) = fbz_imu_noise(i) + acc_bias(3);
	
    fprintf(file_noise, '%f\t', time_imu(i));
    fprintf(file_noise, '%e\t', wibbx_imu_noise(i));
    fprintf(file_noise, '%e\t', wibby_imu_noise(i));
    fprintf(file_noise, '%e\t', wibbz_imu_noise(i));
    fprintf(file_noise, '%e\t', fbx_imu_noise(i));
    fprintf(file_noise, '%e\t', fby_imu_noise(i));
    fprintf(file_noise, '%e\n', fbz_imu_noise(i));
    
end


fclose(file_noise);

msgbox('End.');

