% Position (rad), altitude (rad), angular velocity (rad/s), acceleration
% (m/s^2), T (s)
% height_switch: 1 -- height on, 0 -- height off
function [la_kf, lon_kf, h_kf, v_kf, pitch_kf, roll_kf, yaw_kf, time_kf, time_es, Xes, sqrtP] = ...
    ukf(la0, lon0, h0, ve0, vn0, vu0, pitch0, roll0, yaw0, ...
    data, ...
    T_ins, T_kf, mx0, Cx0, Q, R0, height_switch, Hinfinity_switch)

% Maximum channel number
RECEIVER_CHANNEL = 10;

% GNSS receiver clock drift Markov correlation time (s)
corrTimeGnssClock = 1e9;

% Global definition
wie = 7.292115147e-5; % rad/s
Re = 6378245; % Earth radius, m
e = 1 / 298.3; % Earth eccentrity
g0 = 9.7803267714; % m/s^2
gk1 = 0.00193185138639;
gk2 = 0.00669437999013;

%%%%%%%%%%%%%%%%%%%% Import data result
time = data( : , 1);

% Gyroscope data (rad/s)
w_ib_b = data( : , 2 : 4)';
% Accelerometer data (m/s^2)
f_b = data( : , 5 : 7)';

%fixQuality = data( : , 8)';
svNumber = data( : , 9)';

%la_gps = data( : , 10)';
%lon_gps = data( : , 11)';
%h_gps = data( : , 12)';
%v_gps = data( : , 13 : 15)';

channelNo = zeros(length(svNumber), 10)';
channelSNR = zeros(length(svNumber), 10)';
channelPseu = zeros(length(svNumber), 10)';
channelPseuRate = zeros(length(svNumber), 10)';
channelPx = zeros(length(svNumber), 10)';
channelPy = zeros(length(svNumber), 10)';
channelPz = zeros(length(svNumber), 10)';
channelVx = zeros(length(svNumber), 10)';
channelVy = zeros(length(svNumber), 10)';
channelVz = zeros(length(svNumber), 10)';
for i = 1 : RECEIVER_CHANNEL
    channelNo(i, : ) = data( : , 16 + (i - 1) * 10)';
    channelSNR(i, : ) = data( : , 17 + (i - 1) * 10)';
    channelPseu(i, : ) = data( : , 18 + (i - 1) * 10)';
    channelPseuRate(i, : ) = data( : , 19 + (i - 1) * 10)';
    channelPx(i, : ) = data( : , 20 + (i - 1) * 10)';
    channelPy(i, : ) = data( : , 21 + (i - 1) * 10)';
    channelPz(i, : ) = data( : , 22 + (i - 1) * 10)';
    channelVx(i, : ) = data( : , 23 + (i - 1) * 10)';
    channelVy(i, : ) = data( : , 24 + (i - 1) * 10)';
    channelVz(i, : ) = data( : , 25 + (i - 1) * 10)';
end




% GPS data length
len_kf = length(time);
%len_kf = 1000;

%%%%%%%%%%%%%%%%%%%% Declaration of strapdown navigation parameter

% Velocity
v_kf = zeros(3, len_kf);
v_kf(1 : 3, 1) = [ve0; vn0; vu0];

% Geographical position
la_kf = zeros(1, len_kf); la_kf(1, 1) = la0;
lon_kf = zeros(1, len_kf); lon_kf(1, 1) = lon0;
h_kf = zeros(1, len_kf); h_kf(1, 1) = h0;

% Altitude
roll_kf = zeros(1, len_kf); roll_kf(1, 1) = roll0;
pitch_kf = zeros(1, len_kf); pitch_kf(1, 1) = pitch0;
yaw_kf = zeros(1, len_kf); yaw_kf(1, 1) = yaw0;



Qua = [0; 0; 0; 0];
Qua(1) = cos(yaw0 / 2) * cos(pitch0 / 2) * cos(roll0 / 2) + sin(yaw0 / 2) * sin(pitch0 / 2) * sin(roll0 / 2);
Qua(2) = cos(yaw0 / 2) * sin(pitch0 / 2) * cos(roll0 / 2) + sin(yaw0 / 2) * cos(pitch0 / 2) * sin(roll0 / 2);
Qua(3) = cos(yaw0 / 2) * cos(pitch0 / 2) * sin(roll0 / 2) - sin(yaw0 / 2) * sin(pitch0 / 2) * cos(roll0 / 2);
Qua(4) = cos(yaw0 / 2) * sin(pitch0 / 2) * sin(roll0 / 2) - sin(yaw0 / 2) * cos(pitch0 / 2) * cos(roll0 / 2);


Ctb = [Qua(1) ^ 2 + Qua(2) ^ 2 - Qua(3) ^ 2 - Qua(4) ^ 2,   2 * (Qua(2) * Qua(3) + Qua(1) * Qua(4)),    2 * (Qua(2) * Qua(4) - Qua(1) * Qua(3));
        2 * (Qua(2) * Qua(3) - Qua(1) * Qua(4)),            Qua(1)^2-Qua(2)^2+Qua(3)^2-Qua(4)^2,        2*(Qua(3)*Qua(4)+Qua(1)*Qua(2));
        2*(Qua(2)*Qua(4)+Qua(1)*Qua(3)),                    2*(Qua(3)*Qua(4)-Qua(1)*Qua(2)),            Qua(1)^2-Qua(2)^2-Qua(3)^2+Qua(4)^2];


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Nonlinear KF parameter
% Xdot = F * X + G * W -->     X(k + 1) = Phi * X(k) + Ka * W
% Z = H(X) + V -->     Z(k) = H(X(k)) + V


% Xes: Estimation of system state
% Element : Tilt at east axis (rad) (����ϵ��ƽ̨ϵ����)
%			Tilt at north axis
%           Tilt at up axis
%           Velocity error at east axis (m/s)
%			Velocity error at north axis
%           Velocity error at up axis
%           Latitude error (rad)
%			Longitude error
%           height error (m)
%			Gyroscope drift at east axis (rad/s)
%			Gyroscope drift at north axis
%           Gyroscope drift at up axis
%           Accelerometer bias at east axis (m/s^2)
%			Accelerometer bias at north axis
%           Accelerometer bias at up axis
%           GNSS receiver timer deviation caused position error (m)
%           GNSS receiver timer frequency drift caused velocity error (m/s)
Xes = zeros(17, 1);
P = zeros(17, 17, 1);


% Q: Variance of System noise W
% Element : Gyroscope random error at east axis (rad/s)
%			Gyroscope random error at north axis
%        	Gyroscope random error at up axis
%       	Acceleration random error at east axis (m/s^2)
%			Acceleration random error at north axis
%        	Acceleration random error at up axis
%        	GNSS receiver timer frequency drift caused velocity error noise (m/s)



% Z: Observation
% Element : Channel 1 Pseudorange error (m)
%			Channel 2 Pseudorange error (m)
%			.
%			.
%			.
%			Channel n Pseudorange error (m)
%           Channel 1 Pseudorange rate error (m/s)
%           Channel 2 Pseudorange rate error (m/s)
%			.
%			.
%			.
%           Channel n Pseudorange rate error (m/s)



% R: Observation noise variance
% Element : Channel 1 Pseudorange noise (m)
%			Channel 2 Pseudorange noise (m)
%			.
%			.
%			.
%			Channel n Pseudorange noise (m)
%           Channel 1 Pseudorange rate noise (m/s)
%			.
%			.
%			.
%           Channel 2 Pseudorange rate noise (m/s)
%           Channel n Pseudorange rate noise (m/s)
 
 
%% Tightly coupled Unscented Kalman Filter


% Initial condition
Xes( : , 1) = mx0;
P( : , : , 1) = Cx0;
Sq = chol(Q)';

time_es = zeros(1, 1);
time_kf = zeros(1, 1);
count_es = 0;
for count_kf = 1 : len_kf
    % Record time
    time_kf(count_kf) = time(count_kf);
    
    % Restore old Ctb
    CtbOld = Ctb;
    
    %%%%%%% Strapdown navigation algorithm 
    Rm = Re / (1 + 2 * e - 3 * e * sin(la_kf(1, count_kf))^2); % Radius of meridian plane
    Rn = Re / (1 - e * sin(la_kf(1, count_kf))^2); % Radius of prime vertical plane
    
    w_ie_t = [0; wie * cos(la_kf(1, count_kf)); wie * sin(la_kf(1, count_kf))];
    w_et_t = [-v_kf(2, count_kf) / (Rm + h_kf(1, count_kf)); 
                v_kf(1, count_kf) / (Rn + h_kf(1, count_kf)); 
                v_kf(1, count_kf) / (Rn + h_kf(1, count_kf)) * tan(la_kf(1, count_kf))];

    % Refresh velocity, E-N-U coordinate system
    f_t = Ctb' * f_b(:, count_kf);

    v_kf(1, count_kf + 1) = (f_t(1) + ...
                            (2 * w_ie_t(3) + w_et_t(3)) * v_kf(2, count_kf) - ...
                            (2 * w_ie_t(2) + w_et_t(2)) * v_kf(3, count_kf)) * ...
                            T_ins + v_kf(1, count_kf);
    v_kf(2, count_kf + 1) = (f_t(2) - ...
                            (2 * w_ie_t(3) + w_et_t(3)) * v_kf(1, count_kf) + ...
                            (2 * w_ie_t(1) + w_et_t(1)) * v_kf(3, count_kf)) * ...
                            T_ins + v_kf(2, count_kf);

    if height_switch == 1
        g = g0 * (1 + gk1 * (sin(la_kf(1, count_kf))) ^ 2) * (1 - 2 * h_kf(1, count_kf) / Re) / sqrt(1 - gk2 * (sin(la_kf(1, count_kf))) ^ 2);

        v_kf(3, count_kf + 1) = (f_t(3) + ...
                            (2 * w_ie_t(2) + w_et_t(2)) * v_kf(1, count_kf) - ...
                            (2 * w_ie_t(1) + w_et_t(1)) * v_kf(2, count_kf) - g) * ...
                            T_ins + v_kf(3, count_kf);
    else
        v_kf(3, count_kf + 1) = v_kf(3, count_kf);
    end

    % Location
    la_kf(1, count_kf + 1) = v_kf(2, count_kf + 1) / (Rm + h_kf(1, count_kf)) * T_ins + la_kf(1, count_kf);
    lon_kf(1, count_kf + 1) = v_kf(1, count_kf + 1) / ((Rn + h_kf(1, count_kf)) * cos(la_kf(1, count_kf + 1))) * T_ins + lon_kf(1, count_kf);
    h_kf(1, count_kf + 1) = v_kf(3, count_kf + 1) * T_ins + h_kf(1, count_kf);

    % Refresh quaternion
    w_tb_b = w_ib_b(:, count_kf) - Ctb * (w_ie_t + w_et_t);

    seita_delta = T_ins * ...
                            [0          -w_tb_b(1)           -w_tb_b(2)         -w_tb_b(3);
                            w_tb_b(1)       0               w_tb_b(3)            -w_tb_b(2);
                            w_tb_b(2)    -w_tb_b(3)             0               w_tb_b(1)
                            w_tb_b(3)    w_tb_b(2)          -w_tb_b(1)              0];

    seita_delta_zero = sqrt(seita_delta(1, 2) ^ 2 + seita_delta(1, 3) ^ 2 + seita_delta(1, 4) ^ 2);

    %Qua = ((1 - seita_delta_zero^2 / 8 - seita_delta_zero^4 / 384) * eye(4) + (1 / 2 - seita_delta_zero^2 / 48) * seita_delta) * Qua;
    Qua = (cos(seita_delta_zero / 2) * eye(4) + sin(seita_delta_zero / 2) / seita_delta_zero * seita_delta) * Qua;

    % Refresh Ctb
    Ctb = [Qua(1) ^ 2 + Qua(2) ^ 2 - Qua(3) ^ 2 - Qua(4) ^ 2,   2 * (Qua(2) * Qua(3) + Qua(1) * Qua(4)),    2 * (Qua(2) * Qua(4) - Qua(1) * Qua(3));
            2 * (Qua(2) * Qua(3) - Qua(1) * Qua(4)),            Qua(1)^2-Qua(2)^2+Qua(3)^2-Qua(4)^2,        2*(Qua(3)*Qua(4)+Qua(1)*Qua(2));
            2*(Qua(2)*Qua(4)+Qua(1)*Qua(3)),                    2*(Qua(3)*Qua(4)-Qua(1)*Qua(2)),            Qua(1)^2-Qua(2)^2-Qua(3)^2+Qua(4)^2];

        
    % Refresh attitude
    pitch_kf(1, count_kf + 1) = asin(Ctb(2, 3)); % -pi/2 to pi/2

    roll_kf(1, count_kf + 1) = atan2(-Ctb(1, 3), Ctb(3, 3)); % -pi to pi

    yaw_kf(1, count_kf + 1) = atan2(Ctb(2, 1), Ctb(2, 2)); % 0 to 2*pi
    if yaw_kf(1, count_kf + 1) < 0
        yaw_kf(1, count_kf + 1) = yaw_kf(1, count_kf + 1) + 2 * pi;
    end
    
    

    %%%%%%%% Unscented Kalman Filter  
    if (svNumber(count_kf) ~= 0)
        NumberAcquired = svNumber(count_kf);
        
        count_es = count_es + 1;
        
        % Restore new Ctb
        CtbNew = Ctb;
        Ctb = CtbOld;
        
        ve = v_kf(1, count_kf);
        vn = v_kf(2, count_kf);
        vu = v_kf(3, count_kf);
        la = la_kf(1, count_kf);
        lon = lon_kf(1, count_kf);
        h = h_kf(1, count_kf);
        
        
        
        F_NN = [0,      (wie * sin(la) + ve / (Rn + h) * tan(la)),       -(wie * cos(la) + ve / (Rn + h)), ...
                0,	    -(1 / (Rm + h)),	                                                         0, ...
                0,      0,                                                                   0;

               -(wie * sin(la) + ve / (Rn + h) * tan(la)),      0,        -vn / (Rm + h), ...
               1 / (Rn + h),                                                              0,        0, ...
               -wie * sin(la),                                              0,        0;

               (wie * cos(la) + ve / (Rn + h)),                              vn / (Rm + h),        0, ...
               1 / (Rn + h) * tan(la),                                               0,                      0, ...
               (wie * cos(la) + ve / (Rn + h) * sec(la) ^ 2),       0,                      0;


                0,                                                           -f_t(3),                                           f_t(2), ...
                (vn / (Rm + h) * tan(la) - vu / (Rm + h)),     (2 * wie * sin(la) + ve / (Rn + h) * tan(la)),     -(2 * wie * cos(la) + ve / (Rn + h)), ...
                (2 * wie * cos(la) * vn + ve * vn / (Rn + h) * sec(la) ^ 2 + 2 * wie * sin(la) * vu),      0,      ((ve * vu - ve * vn * tan(la)) / (Rn + h) / (Rn + h));

                f_t(3),                                 0,                                      -f_t(1), ...
                -2 * (wie * sin(la) + ve / (Rn + h) * tan(la)),        -vu / (Rm + h),        -vn / (Rm + h), ...
                -(2 * wie * cos(la) + ve / (Rn + h) * sec(la) ^ 2) * ve,        0,          ((ve * ve * tan(la) + ve * vu) / (Rm + h) / (Rn + h));

                -f_t(2),                                f_t(1),                                     0, ...
                -2 * (wie * cos(la) + ve / (Rn + h)),         0,              2 * vn / (Rm + h), ...
                -2 * wie * sin(la) * ve,             0,              -((ve * ve + vn * vn) / (Rm + h) / (Rn + h));


                0,                              0,                          0, ...
                0,                              1 / (Rm + h),                     0, ...
                0,                              0,                          -vn / (Rm + h) / (Rn + h);

                0,                              0,                          0, ...
                sec(la) / (Rn + h),                   0,                          0, ...
                ve / (Rn + h) * sec(la) * tan(la),    0,                          -ve * sec(la) / (Rm + h) / (Rn + h);

                0,                              0,                          0, ...
                0,                              0,                          1, ...
                0,                              0,                          0];


        F_NS = [Ctb', zeros(3, 3);

                zeros(3, 3), Ctb';

                0,      0,      0,      0,      0,      0;
                0,      0,      0,      0,      0,      0;
                0,      0,      0,      0,      0,      0];

        % One step transfer matrix for X
        F = [F_NN, F_NS, zeros(9, 2);
             zeros(8, 17)];
        F(16, 17) = 1;
        F(17, 17) = -1 / corrTimeGnssClock; % Markov correlation time for receiver clock

        Phi = eye(17) + F * T_kf;

        G = [zeros(3, 3),  	zeros(3, 3), 	zeros(3, 1);
             zeros(3, 3),	zeros(3, 3),	zeros(3, 1);
             zeros(3, 3),   zeros(3, 3),    zeros(3, 1);
             eye(3),        zeros(3, 3),    zeros(3, 1);
             zeros(3, 3),   eye(3),         zeros(3, 1);
             zeros(2, 3),	zeros(2, 3),	zeros(2, 1)];
        G(17, 7) = 1;
        
        Ka = (eye(17) * T_kf + F * T_kf ^ 2 / 2) * G;
        
        
        % Get R
        R = zeros(2 * NumberAcquired, 2 * NumberAcquired);
        for i = 0 : NumberAcquired - 1
            R(2 * NumberAcquired - i, 2 * NumberAcquired - i) = R0(2, 2);
        end
        for i = 0 : NumberAcquired - 1
            R(1 + i, 1 + i) = R0(1, 1);
        end
        
        
        % Get Z
        Z = zeros(2 * NumberAcquired, 1);
        
        veGetZ = ve;
        vnGetZ = vn;
        vuGetZ = vu;
        laGetZ = la;
        lonGetZ = lon;
        hGetZ = h;

        % Transfer SINS location to earth x-y-z
        ex2 = (2 - e) * e / ((1 - e) * (1 - e));
        N = Re * sqrt(1 + ex2) / sqrt(1 + ex2 * cos(laGetZ) * cos(laGetZ));
        N = Rn;
        positionSINS = [(N + h) * cos(la) * cos(lon);
                        (N + h) * cos(la) * sin(lon);
                        ((1 - e) * (1 - e) * N + h) * sin(la)];


        % Transfer SINS velocity from E-N-U to X-Y-Z
        Cte = [cos(pi / 2 + lon),      sin(pi / 2 + lon),      0;
                -cos(pi / 2 - la) * sin(pi / 2 + lon),    cos(pi / 2 - la) * cos(pi / 2 + lon),    sin(pi / 2 - la);
                sin(pi / 2 - la) * sin(pi / 2 + lon),     -sin(pi / 2 - la) * cos(pi / 2 + lon),    cos(pi / 2 - la)];

        venuSINS = [ve;
                    vn;
                    vu];

        vxyzSINS = Cte * venuSINS;


        % Measurements
        for i = 1 : NumberAcquired
            pseudorangeSINS = 0;
            pseudorangeSINS = pseudorangeSINS + (positionSINS(1) - channelPx(i, count_kf)) ^ 2;
            pseudorangeSINS = pseudorangeSINS + (positionSINS(2) - channelPy(i, count_kf)) ^ 2;
            pseudorangeSINS = pseudorangeSINS + (positionSINS(3) - channelPz(i, count_kf)) ^ 2;
            pseudorangeSINS = sqrt(pseudorangeSINS) + Xes(16, count_es);
            Z(i, 1) = pseudorangeSINS - channelPseu(i, count_kf);
            
            pseudorangeRateSINS = 0;
            pseudorangeRateSINS = pseudorangeRateSINS + (positionSINS(1) - channelPx(i, count_kf)) * (vxyzSINS(1) - channelVx(i, count_kf));
            pseudorangeRateSINS = pseudorangeRateSINS + (positionSINS(2) - channelPy(i, count_kf)) * (vxyzSINS(2) - channelVy(i, count_kf));
            pseudorangeRateSINS = pseudorangeRateSINS + (positionSINS(3) - channelPz(i, count_kf)) * (vxyzSINS(3) - channelVz(i, count_kf));
            pseudorangeRateSINS = pseudorangeRateSINS / pseudorangeSINS + Xes(17, count_es);
            Z(i + NumberAcquired) = pseudorangeRateSINS - channelPseuRate(i, count_kf);
        end
        
        
        % Sigma point
        weight_m = zeros(1, 2 * 17 + 1);
        weight_c = zeros(1, 2 * 17 + 1);
        XesSigma = zeros(17, 2 * 17 + 1);
        
        
        alpha = 0.6; % 1e-4 to 1
        beta = 2; % Best for Gauss white noise
        kappa = 0;
        lamda = alpha * alpha * (17 + kappa) - 17;
        weight_m(1) = lamda / (17 + lamda);
        weight_c(1) = lamda / (17 + lamda) + (1 - alpha * alpha + beta);
        
        %{
        lamda = 1;
        weight_m(1) = lamda / (17 + lamda);
        weight_c(1) = lamda / (17 + lamda);
        %}
        
        XesSigma( : , 1) = Xes( : , count_es);
        upperTriMatrix = chol(P( :, : , count_es));
        for i = 1 : 17
            weight_m(i + 1) = 1 / (2 * (17 + lamda));
            weight_m(i + 1 + 17) = 1 / (2 * (17 + lamda));
            
            weight_c(i + 1) = weight_m(i + 1);
            weight_c(i + 1 + 17) = weight_m(i + 1 + 17);
            
            XesSigma( : , i + 1) = Xes( : , count_es) + sqrt((17 + lamda)) * upperTriMatrix(i, : )';
            XesSigma( : , i + 1 + 17) = Xes( : , count_es) - sqrt((17 + lamda)) * upperTriMatrix(i, : )';
        end
        
        
        % Get XesOneStep
        XesOneStep = zeros(17, 1);
        XesSigmaOneStep = zeros(17, 2 * 17 + 1);
        for i = 1 : 2 * 17 + 1
            XesSigmaOneStep( : , i) = Phi * XesSigma( : , i);
            XesOneStep( : , 1) = XesOneStep( : , 1) + weight_m(i) * XesSigmaOneStep( : , i);
        end
        
        
        % Sigma points of XesOneStep (Only for UKF with additive noise)
        XesOneStepSigma = zeros(17, 4 * 17 + 1);
        XesOneStepSigma( : , 1 : 2 * 17 + 1) = XesSigmaOneStep;
        for i = 1 : 17
            temp = sqrt((17 + lamda)) * Ka * Sq * Ka';
            XesOneStepSigma( : , 2 * 17 + 1 + i) = XesOneStepSigma( : , 1) + temp( : , 1);
            XesOneStepSigma( : , 2 * 17 + 1 + i + 17) = XesOneStepSigma( : , 1) - temp( : , 1);
        end
        
        
        % Get ZesOneStep
        ZesOneStep = zeros(2 * NumberAcquired, 1);
        ZesSigmaOneStep = zeros(2 * NumberAcquired, 2 * 17 + 1);
        for i = 1 : 2 * 17 + 1
            CteDeltaP = [-(Rn + h) * sin(la) * cos(lon),        -(Rn + h) * cos(la) * sin(lon),     cos(la) * cos(lon);
                            -(Rn + h) * sin(la) * sin(lon),     (Rn + h) * cos(la) * cos(lon),      cos(la) * sin(lon);
                            (Rn * (1 - e^2) + h) * cos(la),     0,                                  sin(la)];
            
            N = [-vn * cos(la) * cos(lon) - vu * sin(la) * cos(lon),        -ve * cos(lon) + vn * sin(la) * sin(lon) - vu * cos(la) * sin(lon),     0;
                    -vn * cos(la) * sin(lon) - vu * sin(la) * sin(lon),     -ve * sin(lon) - vn * sin(la) * cos(lon) + vu * cos(la) * cos(lon),     0;
                    -vn * sin(la) + vu * cos(la),                           0,                                                                      0] * ...  
                [0,                             1 / (Rm + h),       0;
                 1 / (Rm + h) / cos(la),        0,                  0;
                 0,                             0,                  1];
             
            deltaPgeo = [XesOneStepSigma(7, i); XesOneStepSigma(8, i); XesOneStepSigma(9, i)];
            deltaVenu = [XesOneStepSigma(4, i); XesOneStepSigma(5, i); XesOneStepSigma(6, i)];
             
            deltaPxyz = CteDeltaP * deltaPgeo;
            
            %deltaVxyz = CteDeltaP * deltaVenu + N * deltaPxyz;
            deltaVxyz = Cte * deltaVenu;
             
            % Measurements
            for j = 1 : NumberAcquired
                pseudorangeSINS = 0;
                pseudorangeSINS = pseudorangeSINS + deltaPxyz(1, 1) ^ 2;
                pseudorangeSINS = pseudorangeSINS + deltaPxyz(2, 1) ^ 2;
                pseudorangeSINS = pseudorangeSINS + deltaPxyz(3, 1) ^ 2;
                pseudorangeSINS = sqrt(pseudorangeSINS) + Xes(16, count_es);
                ZesSigmaOneStep(j, i) = pseudorangeSINS - channelPseu(j, count_kf);

                pseudorangeRateSINS = 0;
                pseudorangeRateSINS = pseudorangeRateSINS + deltaPxyz(1, 1) * deltaVxyz(1, 1);
                pseudorangeRateSINS = pseudorangeRateSINS + deltaPxyz(2, 1) * deltaVxyz(2, 1);
                pseudorangeRateSINS = pseudorangeRateSINS + deltaPxyz(3, 1) * deltaVxyz(3, 1);
                pseudorangeRateSINS = pseudorangeRateSINS / pseudorangeSINS + Xes(17, count_es);
                ZesSigmaOneStep(j + NumberAcquired, i) = pseudorangeRateSINS - channelPseuRate(j, count_kf);
            end % j
            
            ZesOneStep( : , 1) = ZesOneStep( : , 1) + weight_m(i) * ZesSigmaOneStep( : , i);
            
        end % i
        

        % Get PesOneStep, PzesOneStep and PxzesOneStep
        PesOneStep = zeros(17, 17);
        PzesOneStep = zeros(2 * NumberAcquired, 2 * NumberAcquired);
        PxzesOneStep = zeros(17, 2 * NumberAcquired);
        for i = 1 : 2 * 17 + 1
            PesOneStep = PesOneStep + weight_c(i) * (XesOneStepSigma( : , i) - XesOneStep) * (XesOneStepSigma( : , i) - XesOneStep)';
            PzesOneStep = PzesOneStep + weight_c(i) * (ZesSigmaOneStep( : , i) - ZesOneStep) * (ZesSigmaOneStep( : , i) - ZesOneStep)';
            PxzesOneStep = PxzesOneStep + weight_c(i) * (XesOneStepSigma( : , i) - XesOneStep) * (ZesSigmaOneStep( : , i) - ZesOneStep)';
        end
        PesOneStep = PesOneStep + Ka * Q * Ka';
        PzesOneStep = PzesOneStep + R;
        
        % Kalman Gain
        K = PxzesOneStep / PzesOneStep;
        
        % Estimation
        Xes( : , count_es + 1) = XesOneStep + K * (Z(1 : 2 * NumberAcquired) - ZesOneStep);
        
        if Hinfinity_switch == 0
            P( : , : , count_es + 1) = PesOneStep - K * PzesOneStep * K';
        else
            % Rek
            alphaHinf = 100;
            Hktrans = eye(17) / PesOneStep * PxzesOneStep;
            Hk = Hktrans';
            gammaSquare = alphaHinf * max(eig(eye(17) / (eye(17) / PesOneStep + Hktrans / R * Hk)));
            %disp(['gammaSquare = ', num2str(gammaSquare)]);
            Rek = [PzesOneStep, PxzesOneStep'; PxzesOneStep, PesOneStep - gammaSquare * eye(17)];

            % Estimation Pes
            P( : , : , count_es + 1) = PesOneStep - [PxzesOneStep, PesOneStep] / Rek * [PxzesOneStep, PesOneStep]';
        end
    
        % Recover new Ctb
      	Ctb = CtbNew;
        
        %%%%%%%% Feedback correction
        if count_es > 0
            
            % fix attitude Euler matrix
            Ctc = [1,                               Xes(3, count_es + 1),                  -Xes(2, count_es + 1);
                   -Xes(3, count_es + 1),             1                                    Xes(1, count_es + 1);
                    Xes(2, count_es + 1),          -Xes(1, count_es + 1),                     1];

            Ctb = Ctb * Ctc; % Exclude tilt

            % fix attitude quaternion  
            Qua(1) = sqrt(abs(1 + Ctb(1, 1) + Ctb(2, 2) + Ctb(3, 3))) / 2;
            Qua(2) = sqrt(abs(1 + Ctb(1, 1) - Ctb(2, 2) - Ctb(3, 3))) / 2;
            Qua(3) = sqrt(abs(1 - Ctb(1, 1) + Ctb(2, 2) - Ctb(3, 3))) / 2;
            Qua(4) = sqrt(abs(1 - Ctb(1, 1) - Ctb(2, 2) + Ctb(3, 3))) / 2;

            if ((Ctb(2, 3) - Ctb(3, 2)) / (4 * Qua(1)) < 0)
                Qua(2) = -Qua(2);
            end
            if ((Ctb(3, 1) - Ctb(1, 3)) / (4 * Qua(1)) < 0)
                Qua(3) = -Qua(3);
            end
            if ((Ctb(1, 2) - Ctb(2, 1)) / (4 * Qua(1)) < 0)
                Qua(4) = -Qua(4);
            end
            

            % fix attitude
            pitch_kf(1, count_kf + 1) = asin(Ctb(2, 3)); % -pi/2 to pi/2

            roll_kf(1, count_kf + 1) = atan2(-Ctb(1, 3), Ctb(3, 3)); % -pi to pi

            yaw_kf(1, count_kf + 1) = atan2(Ctb(2, 1), Ctb(2, 2)); % 0 to 2*pi
            if yaw_kf(1, count_kf + 1) < 0
                yaw_kf(1, count_kf + 1) = yaw_kf(1, count_kf + 1) + 2 * pi;
            end
            


            % fix velocity and position
            v_kf(1, count_kf + 1) = ve - Xes(4, count_es + 1);
            v_kf(2, count_kf + 1) = vn - Xes(5, count_es + 1);
            v_kf(3, count_kf + 1) = vu - Xes(6, count_es + 1);

            la_kf(1, count_kf + 1) = la - Xes(7, count_es + 1);
            lon_kf(1, count_kf + 1) = lon - Xes(8, count_es + 1);
            h_kf(1, count_kf + 1) = h - Xes(9, count_es + 1);
        end % Feedback correction

        time_es(count_es) = time(count_kf + 1);
    
    end % Kalman Filter

end

disp(['count_es = ', num2str(count_es)]);


% Extraction of estimation variance
sqrtP = zeros(17, count_es);
[~, ~, len_temp3] = size(P);
for count = 1 : 1 : len_temp3
    sqrtP(1, count) = sqrt(P(1, 1, count));
    sqrtP(2, count) = sqrt(P(2, 2, count));
    sqrtP(3, count) = sqrt(P(3, 3, count));
    
    sqrtP(4, count) = sqrt(P(4, 4, count));
    sqrtP(5, count) = sqrt(P(5, 5, count));
    sqrtP(6, count) = sqrt(P(6, 6, count));
    
    sqrtP(7, count) = sqrt(P(7, 7, count));
    sqrtP(8, count) = sqrt(P(8, 8, count));
    sqrtP(9, count) = sqrt(P(9, 9, count));
    
    sqrtP(10, count) = sqrt(P(10, 10, count));
    sqrtP(11, count) = sqrt(P(11, 11, count));
    sqrtP(12, count) = sqrt(P(12, 12, count));
    
    sqrtP(13, count) = sqrt(P(13, 13, count));
    sqrtP(14, count) = sqrt(P(14, 14, count));
    sqrtP(15, count) = sqrt(P(15, 15, count));    
    
    sqrtP(16, count) = sqrt(P(16, 16, count)); 
    sqrtP(17, count) = sqrt(P(17, 17, count)); 
end


end % function

