% Position (rad), altitude (rad), angular velocity (rad/s), acceleration
% (m/s^2), T (s)
% height_switch: 1 -- height on, 0 -- height off
function [la_kf, lon_kf, h_kf, v_kf, pitch_kf, roll_kf, yaw_kf, X_es, var_es, time_es] = ...
    kf_loosely_coupled_sins_gnss(la0, lon0, h0, ve0, vn0, vu0, pitch0, roll0, yaw0, ...
    la_gps, lon_gps, h_gps, v_gps, ...
    t_imu, t_gps, T_imu, T_gps, w, f, drift, bias, gps_error_p, gps_error_v, mx0, Cx0, Ctb0, Qua0, RELAY_BEFORE_FEEDBACK_CORRECTION, height_switch)

% Global definition
wie = 7.292115147e-5; % rad/s
Re = 6378245; % Earth radius, m
e = 1 / 298.3; % Earth eccentrity
g0 = 9.7803267714; % m/s^2
gk1 = 0.00193185138639;
gk2 = 0.00669437999013;

%%%%%%%%%%%%%%%%%%%% Import GPS result
t_delta_gps = T_gps;

utc_gps = t_gps;

v_e_gps = v_gps(1, : );
v_n_gps = v_gps(2, : );
v_u_gps = v_gps(3, : );

% GPS data length
len_gps = length(utc_gps);

%%%%%%%%%%%%%%%%%%%% Declaration of strapdown navigation parameter
% Import IMU data
t_delta_imu = T_imu;

% UTC time
utc_imu = t_imu;

% Gyroscope data (rad/s)
w_ib_b(1, :) = w(1, : );
w_ib_b(2, :) = w(2, : );
w_ib_b(3, :) = w(3, : );

% Accelerometer data (m/s^2)
f_b(1, :) = f(1, : );
f_b(2, :) = f(2, : );
f_b(3, :) = f(3, : );

% IMU data length
len_imu = length(utc_imu);

t_delta_kf = t_delta_gps;
len_kf = len_imu + 1;

% Velocity
v_kf = zeros(3, len_kf);
v_kf(1 : 3, 1) = [ve0; vn0; vu0];

% Geographical position
la_kf = zeros(1, len_kf); la_kf(1, 1) = la0;
lon_kf = zeros(1, len_kf); lon_kf(1, 1) = lon0;
h_kf = zeros(1, len_kf); h_kf(1, 1) = h0;

% Altitude
roll_kf = zeros(1, len_kf); roll_kf(1, 1) = roll0;
pitch_kf = zeros(1, len_kf); pitch_kf(1, 1) = pitch0;
yaw_kf = zeros(1, len_kf); yaw_kf(1, 1) = yaw0;

Ctb = Ctb0;
Qua = Qua0;

%%%%%%%%%%%%%%%%%%%% Declaration of Kalman Filter parameter
% Xdot = F * X + G * W  -->     X(k+1) = Phi * X(k) + Ka * W
% Z = H * X + V         -->     Z = H * X + V


% X_es: Estimation of system state
% Element:  Tilt at east axis (rad)
%           Tilt at north axis
%           Tilt at up axis
%           Velocity error at east axis (m/s)
%           Velocity error at north axis
%           Velocity error at up axis
%           Latitude error (rad)
%           Longitude error
%           height error (m)
%           Gyroscope bias at east axis (rad/s)
%           Gyroscope bias at north axis
%           Gyroscope bias at up axis
%           Accelerometer bias at east axis (m^2/s)
%           Accelerometer bias at north axis
%           Accelerometer bias at up axis
X_es = zeros(15, len_gps);
P = zeros(15, 15, len_gps);


% Q: Variance of System noise W
% Element:	Gyroscope random error at east axis (rad/s)
%        	Gyroscope random error at north axis
%        	Gyroscope random error at up axis
%       	Acceleration random error at east axis (m/s^2)
%         	Acceleration random error at north axis
%        	Acceleration random error at up axis



% Z: Observation
% Element:  Velocity error at east axis (m/s)
%         	Velocity error at north axis
%           Velocity error at up axis
%           Latitude error (rad)
%         	Longitude error
%           Height error (m)
Z = zeros(6, len_gps);


% R: Observation noise variance
% Element:  Velocity observation noise at east axis (m/s)
%         	Velocity observation noise at north axis
%           Velocity observation noise at up axis
%           Latitude observation noise (rad)
%         	Longitude observation noise
%           Height observation noise (m)
 
 
%% Loose coupled Kalman Filter


Ctc = eye(3);



% Initial condition
X_es( : , 1) = mx0;
P( : , : , 1) = Cx0;

count_gps = 1;
count_es = 1;

time_es = zeros(1, 1);

for count_kf = 1 : len_imu
    
    %%%%%%% Strapdown navigation algorithm 
    Rm = Re / (1 +2 * e - 3 * e * sin(la_kf(1, count_kf))^2) + h_kf(1, count_kf); % Radius of meridian plane
    Rn = Re / (1 - e * sin(la_kf(1, count_kf))^2) + h_kf(1, count_kf); % Radius of prime vertical plane
    
    w_ie_t = [0; wie * cos(la_kf(1, count_kf)); wie * sin(la_kf(1, count_kf))];
    w_et_t = [-v_kf(2, count_kf) / Rm; 
                v_kf(1, count_kf) / Rn; 
                v_kf(1, count_kf) / Rn * tan(la_kf(1, count_kf))];

    % Refresh velocity, E-N-U coordinate system
    f_t = Ctb' * f_b(:, count_kf);

    v_kf(1, count_kf + 1) = (f_t(1) + ...
                            (2 * w_ie_t(3) + w_et_t(3)) * v_kf(2, count_kf) - ...
                            (2 * w_ie_t(2) + w_et_t(2)) * v_kf(3, count_kf)) * ...
                            t_delta_imu + v_kf(1, count_kf);
    v_kf(2, count_kf + 1) = (f_t(2) - ...
                            (2 * w_ie_t(3) + w_et_t(3)) * v_kf(1, count_kf) + ...
                            (2 * w_ie_t(1) + w_et_t(1)) * v_kf(3, count_kf)) * ...
                            t_delta_imu + v_kf(2, count_kf);

    if height_switch == 1
        g = g0 * (1 + gk1 * (sin(la_kf(1, count_kf))) ^ 2) * (1 - 2 * h_kf(1, count_kf) / Re) / sqrt(1 - gk2 * (sin(la_kf(1, count_kf))) ^ 2);

        v_kf(3, count_kf + 1) = (f_t(3) + ...
                            (2 * w_ie_t(2) + w_et_t(2)) * v_kf(1, count_kf) - ...
                            (2 * w_ie_t(1) + w_et_t(1)) * v_kf(2, count_kf) - g) * ...
                            t_delta_imu + v_kf(3, count_kf);
    else
        v_kf(3, count_kf + 1) = v_kf(3, count_kf);
    end

    % Location
    la_kf(1, count_kf + 1) = v_kf(2, count_kf + 1) / Rm * t_delta_imu + la_kf(1, count_kf);
    lon_kf(1, count_kf + 1) = v_kf(1, count_kf + 1) / (Rn * cos(la_kf(1, count_kf + 1))) * t_delta_imu + lon_kf(1, count_kf);
    h_kf(1, count_kf + 1) = v_kf(3, count_kf + 1) * t_delta_imu + h_kf(1, count_kf);

    % Refresh quaternion
    w_tb_b = w_ib_b(:, count_kf) - Ctb * (w_ie_t + w_et_t);

    seita_delta = t_delta_imu * ...
                            [0          -w_tb_b(1)           -w_tb_b(2)         -w_tb_b(3);
                            w_tb_b(1)       0               w_tb_b(3)            -w_tb_b(2);
                            w_tb_b(2)    -w_tb_b(3)             0               w_tb_b(1)
                            w_tb_b(3)    w_tb_b(2)          -w_tb_b(1)              0];

    seita_delta_zero = sqrt(seita_delta(1, 2) ^ 2 + seita_delta(1, 3) ^ 2 + seita_delta(1, 4) ^ 2);

    Qua = (cos(seita_delta_zero / 2) * eye(4) + sin(seita_delta_zero / 2) / seita_delta_zero * seita_delta) * Qua;

    % Refresh Ctb
    Ctb = [Qua(1) ^ 2 + Qua(2) ^ 2 - Qua(3) ^ 2 - Qua(4) ^ 2,   2 * (Qua(2) * Qua(3) + Qua(1) * Qua(4)),    2 * (Qua(2) * Qua(4) - Qua(1) * Qua(3));
            2 * (Qua(2) * Qua(3) - Qua(1) * Qua(4)),            Qua(1)^2-Qua(2)^2+Qua(3)^2-Qua(4)^2,        2*(Qua(3)*Qua(4)+Qua(1)*Qua(2));
            2*(Qua(2)*Qua(4)+Qua(1)*Qua(3)),                    2*(Qua(3)*Qua(4)-Qua(1)*Qua(2)),            Qua(1)^2-Qua(2)^2-Qua(3)^2+Qua(4)^2];

    Ctb = Ctb * Ctc'; % Exclude tilt
        
    % Refresh attitude
    pitch_kf(1, count_kf + 1) = asin(Ctb(2, 3)); % -pi/2 to pi/2

    roll_kf(1, count_kf + 1) = atan2(-Ctb(1, 3), Ctb(3, 3)); % -pi to pi

    yaw_kf(1, count_kf + 1) = atan2(Ctb(2, 1), Ctb(2, 2)); % 0 to 2*pi
    if yaw_kf(1, count_kf + 1) < 0
        yaw_kf(1, count_kf + 1) = yaw_kf(1, count_kf + 1) + 2 * pi;
    end
    
    
    
    
    %%%%%%%% Kalman Filter
    if ((count_kf <= len_imu) && (count_gps <= len_gps))
        
    % Time synchonization
    while utc_imu(count_kf) > utc_gps(count_gps)
        count_gps = count_gps + 1;
    end
    
    if (utc_imu(count_kf) == utc_gps(count_gps))
        
        Z( : , count_es) = [v_e_gps(count_gps) - v_kf(1, count_kf + 1);
                            v_n_gps(count_gps) - v_kf(2, count_kf + 1);
                            v_u_gps(count_gps) - v_kf(3, count_kf + 1);
                            la_gps(count_gps) - la_kf(count_kf + 1);
                            lon_gps(count_gps) - lon_kf(count_kf + 1);
                            h_gps(count_gps) - h_kf(count_kf + 1)];
        
        F_NN = [0,      (wie * sin(la_kf(1, count_kf + 1)) + v_kf(1, count_kf + 1) / Rn * tan(la_kf(1, count_kf + 1))),       -(wie * cos(la_kf(1, count_kf + 1)) + v_kf(1, count_kf + 1) / Rn), ...
                0,	    -(1 / Rm),	                                                         0, ...
                0,      0,                                                                   0;

               -(wie * sin(la_kf(1, count_kf + 1)) + v_kf(1, count_kf + 1) / Rn * tan(la_kf(1, count_kf + 1))),      0,        -v_kf(2, count_kf + 1) / Rm, ...
               1 / Rn,                                                              0,        0, ...
               -wie * sin(la_kf(1, count_kf + 1)),                                              0,        0;

               (wie * cos(la_kf(1, count_kf + 1)) + v_kf(1, count_kf + 1) / Rn),                              v_kf(2, count_kf + 1) / Rm,        0, ...
               1 / Rn * tan(la_kf(1, count_kf + 1)),                                               0,                      0, ...
               (wie * cos(la_kf(1, count_kf + 1)) + v_kf(1, count_kf + 1) / Rn * sec(la_kf(1, count_kf + 1) ^ 2)),       0,                      0;


                0,                                                           -f_t(3),                                           f_t(2), ...
                (v_kf(2, count_kf + 1) / Rm * tan(la_kf(1, count_kf + 1)) - v_kf(3, count_kf + 1) / Rm),     (2 * wie * sin(la_kf(1, count_kf + 1)) + v_kf(1, count_kf + 1) / Rn),     (2 * wie * cos(la_kf(1, count_kf + 1)) + v_kf(1, count_kf + 1) / Rn), ...
                (2 * wie * cos(la_kf(1, count_kf + 1)) * v_kf(2, count_kf + 1) + v_kf(1, count_kf + 1) * v_kf(2, count_kf + 1) / Rn * sec(la_kf(1, count_kf + 1)) ^ 2 + 2 * wie * sin(la_kf(1, count_kf + 1)) * v_kf(3, count_kf + 1)),      0,      0;

                f_t(3),                                 0,                                      -f_t(1), ...
                -2 * (wie * sin(la_kf(1, count_kf + 1)) + v_kf(1, count_kf + 1) / Rn * tan(la_kf(1, count_kf + 1))),        -v_kf(3, count_kf + 1) / Rm,        -v_kf(2, count_kf + 1) / Rm, ...
                -(2 * wie * cos(la_kf(1, count_kf + 1)) + v_kf(1, count_kf + 1) / Rn * sec(la_kf(1, count_kf + 1)) ^ 2) * v_kf(1, count_kf + 1),        0,          0;

                -f_t(2),                                f_t(1),                                     0, ...
                -2 * (wie * cos(la_kf(1, count_kf + 1)) + v_kf(1, count_kf + 1) / Rn),         0,              2 * v_kf(2, count_kf + 1) / Rm, ...
                -2 * wie * sin(la_kf(1, count_kf + 1)) * v_kf(1, count_kf + 1),             0,              0;


                0,                              0,                          0, ...
                0,                              1 / Rm,                     0, ...
                0,                              0,                          0;

                0,                              0,                          0, ...
                sec(la_kf(1, count_kf + 1)) / Rn,   0,                          0, ...
                v_kf(1, count_kf + 1) / Rn * sec(la_kf(1, count_kf + 1)) * tan(la_kf(1, count_kf + 1)),    0,  0;

                0,                              0,                          0, ...
                0,                              0,                          1, ...
                0,                              0,                          0];


        F_NS = [1,      0,      0,      0,      0,      0;
                0,      1,      0,      0,      0,      0;
                0,      0,      1,      0,      0,      0;

                0,      0,      0,      1,      0,      0;
                0,      0,      0,      0,      1,      0;
                0,      0,      0,      0,      0,      1;

                0,      0,      0,      0,      0,      0;
                0,      0,      0,      0,      0,      0;
                0,      0,      0,      0,      0,      0];

        % One step transfer matrix for X
        F = [F_NN, F_NS; zeros(6, 9), zeros(6, 6)];

        Phi = eye(15) + F * t_delta_kf;

        Q = diag([drift(1, 1) ^ 2,      drift(2, 1) ^ 2,        drift(3, 1) ^ 2, ...
                  bias(1, 1) ^ 2,       bias(2, 1) ^ 2,         bias(3, 1) ^ 2]);

        G = [Ctb',          zeros(3, 3);
             zeros(3, 3),   Ctb';
             zeros(9, 3),   zeros(9, 3)];
        
        Ka = (eye(15) * t_delta_kf + F * t_delta_kf ^ 2 / 2) * G;
         
        %H1 = diag([Rm, Rn * cos(la_kf(1, count_kf)), 1]);
        H1 = diag([1, 1, 1]);
        
        % Observation matrix
        H = [zeros(3, 3),   eye(3),        zeros(3, 3),    zeros(3, 6);
             zeros(3, 3),   zeros(3, 3),    H1,             zeros(3, 6)];
         
        R = diag([gps_error_v(1, 1) ^ 2,     gps_error_v(2, 1) ^ 2,       gps_error_v(3, 1) ^ 2, ...
                 (gps_error_p(1, 1) / Rm) ^ 2,     (gps_error_p(2, 1) / Rn) ^ 2,     gps_error_p(3, 1) ^ 2]);
         
         
        % One step estimation
        X_es_one_step = Phi * X_es( : , count_es);
        P_one_step = Phi * P( : , : , count_es) * Phi' + Ka * Q * Ka';

        % Kalman gain
        K = P_one_step * H' / (H * P_one_step * H' + R);

        % Estimation
        X_es( : , count_es + 1) = X_es_one_step + K * (Z( : , count_es) - H * X_es_one_step);
        P( : , : , count_es + 1) = (eye(15) - K * H) * P_one_step * (eye(15) - K * H)' + K * R * K';
        
        

        
        
    
        
    % Correct strapdown result
    % Feedback correction
    if count_kf > RELAY_BEFORE_FEEDBACK_CORRECTION
        Ctc = [1,                               X_es(3, count_es + 1),                  -X_es(2, count_es + 1);
               -X_es(3, count_es + 1),             1                                    X_es(1, count_es + 1);
                X_es(2, count_es + 1),          -X_es(1, count_es + 1),                     1];

        Ctb_temp = Ctb * Ctc'; % Exclude tilt
        Ctb = Ctb_temp;
            
        v_kf(1, count_kf + 1) = v_kf(1, count_kf + 1) + X_es(4, count_es + 1);
        v_kf(2, count_kf + 1) = v_kf(2, count_kf + 1) + X_es(5, count_es + 1);
        v_kf(3, count_kf + 1) = v_kf(3, count_kf + 1) + X_es(6, count_es + 1);

        la_kf(1, count_kf + 1) = la_kf(1, count_kf + 1) + X_es(7, count_es + 1);
        lon_kf(1, count_kf + 1) = lon_kf(1, count_kf + 1) + X_es(8, count_es + 1);
        h_kf(1, count_kf + 1) = h_kf(1, count_kf + 1) + X_es(9, count_es + 1);
    % Output correction
    else    
        Ctc = [1,                               X_es(3, count_es + 1),                  -X_es(2, count_es + 1);
               -X_es(3, count_es + 1),             1                                    X_es(1, count_es + 1);
                X_es(2, count_es + 1),          -X_es(1, count_es + 1),                     1];

        Ctb_temp = Ctb * Ctc'; % Exclude tilt
        pitch_kf(1, count_kf) = asin(Ctb_temp(2, 3)); % -pi/2 to pi/2
        roll_kf(1, count_kf) = -atan2(Ctb_temp(1, 3), Ctb_temp(3, 3)); % -pi to pi
        yaw_kf(1, count_kf) = atan2(Ctb_temp(2, 1), Ctb_temp(2, 2)); % 0 to 2*pi
        if yaw_kf(1, count_kf) < 0
            yaw_kf(1, count_kf) = yaw_kf(1, count_kf) + 2 * pi;
        end
        
        v_kf(1, count_kf) = v_kf(1, count_kf) + X_es(4, count_es + 1);
        v_kf(2, count_kf) = v_kf(2, count_kf) + X_es(5, count_es + 1);
        v_kf(3, count_kf) = v_kf(3, count_kf) + X_es(6, count_es + 1);

        la_kf(1, count_kf) = la_kf(1, count_kf) + X_es(7, count_es + 1);
        lon_kf(1, count_kf) = lon_kf(1, count_kf) + X_es(8, count_es + 1);
        h_kf(1, count_kf) = h_kf(1, count_kf) + X_es(9, count_es + 1);
    end
    end % if
    
    time_es(count_es) = utc_imu(count_kf);
    count_gps = count_gps + 1;
	count_es = count_es + 1;
    
    end
    
    
    
end




% Extraction of estimation variance
var_es = zeros(15, count_es);
for count = 1 : 1 : count_es
    var_es(1, count) = sqrt(P(1, 1, count));
    var_es(2, count) = sqrt(P(2, 2, count));
    var_es(3, count) = sqrt(P(3, 3, count));
    
    var_es(4, count) = sqrt(P(4, 4, count));
    var_es(5, count) = sqrt(P(5, 5, count));
    var_es(6, count) = sqrt(P(6, 6, count));
    
    var_es(7, count) = sqrt(P(7, 7, count));
    var_es(8, count) = sqrt(P(8, 8, count));
    var_es(9, count) = sqrt(P(9, 9, count));
    
    var_es(10, count) = sqrt(P(10, 10, count));
    var_es(11, count) = sqrt(P(11, 11, count));
    var_es(12, count) = sqrt(P(12, 12, count));
    
    var_es(13, count) = sqrt(P(13, 13, count));
    var_es(14, count) = sqrt(P(14, 14, count));
    var_es(15, count) = sqrt(P(15, 15, count));    
    
end



end % function

