time = data( : , 1);

w = data( : , 2 : 4)';
f = data( : , 5 : 7)';

fixQuality = data( : , 8)';
svNumber = data( : , 9)';

la_gps = data( : , 10)';
lon_gps = data( : , 11)';
h_gps = data( : , 12)';
v_gps = data( : , 13 : 15)';

channelNo = zeros(length(svNumber), 10)';
channelSNR = zeros(length(svNumber), 10)';
channelPseu = zeros(length(svNumber), 10)';
channelPseuRate = zeros(length(svNumber), 10)';
channelPx = zeros(length(svNumber), 10)';
channelPy = zeros(length(svNumber), 10)';
channelPz = zeros(length(svNumber), 10)';
channelVx = zeros(length(svNumber), 10)';
channelVy = zeros(length(svNumber), 10)';
channelVz = zeros(length(svNumber), 10)';
for i = 1 : 10
    channelNo(i, : ) = data( : , 16 + (i - 1) * 10)';
    channelSNR(i, : ) = data( : , 17 + (i - 1) * 10)';
    channelPseu(i, : ) = data( : , 18 + (i - 1) * 10)';
    channelPseuRate(i, : ) = data( : , 19 + (i - 1) * 10)';
    channelPx(i, : ) = data( : , 20 + (i - 1) * 10)';
    channelPy(i, : ) = data( : , 21 + (i - 1) * 10)';
    channelPz(i, : ) = data( : , 22 + (i - 1) * 10)';
    channelVx(i, : ) = data( : , 23 + (i - 1) * 10)';
    channelVy(i, : ) = data( : , 24 + (i - 1) * 10)';
    channelVz(i, : ) = data( : , 25 + (i - 1) * 10)';
end


gps_la = zeros(1, 1);
temp = 0;
for count = 1 : 1 : length(fixQuality)
    if fixQuality(count) ~= 0
        temp = temp + 1;
        gps_la(temp) = la_gps(count) * 180 / pi;
    end
end

plot(gps_la);



