close all;
clear all;





% Global definition
wie = 7.292115147e-5; % rad/s
Re = 6378245; % Earth radius, m
e = 1 / 298.3; % Earth eccentrity
g0 = 9.7803267714; % m/s^2
gk1 = 0.00193185138639;
gk2 = 0.00669437999013;

% Unit conversion
unit_degree2rad = (pi / 180); % degrees to rad
unit_w = (pi / 3600 / 180); % degrees/h to rad/s
unit_ug = (g0 * 10 ^ (-6)); % ug to m/s^2


%% Import data
disp('Import data begin.');
tic;


% Import both IMU and GNSS data
SWITCH_FILE = 21;

if SWITCH_FILE == 0
    data = importdata('../../../Integrated Navigation Data/201401031452 (GPS L1 Static)/both.dat');
    data_norm = importdata('../../../Integrated Navigation Data/201401031452 (GPS L1 Static)/nav_normal.dat');
    data_gnss = importdata('../../../Integrated Navigation Data/201401031452 (GPS L1 Static)/nav_gnss.dat');
elseif SWITCH_FILE == 1
    data = importdata('../../../Integrated Navigation Data/201401031508 (GPS L1 Vn 1g 300)/both.dat');
    data_norm = importdata('../../../Integrated Navigation Data/201401031508 (GPS L1 Vn 1g 300)/nav_normal.dat');
    data_gnss = importdata('../../../Integrated Navigation Data/201401031508 (GPS L1 Vn 1g 300)/nav_gnss.dat');
elseif SWITCH_FILE == 2
    data = importdata('../../../Integrated Navigation Data/201401031519 (GPS L1 Vn 1g 300 6g 900)/both.dat');
    data_norm = importdata('../../../Integrated Navigation Data/201401031519 (GPS L1 Vn 1g 300 6g 900)/nav_normal.dat');
    data_gnss = importdata('../../../Integrated Navigation Data/201401031519 (GPS L1 Vn 1g 300 6g 900)/nav_gnss.dat');
elseif SWITCH_FILE == 3
    data = importdata('../../../Integrated Navigation Data/201401031548 (GPS L1 Vn 1g 300 6g 1200)/both.dat');
    data_norm = importdata('../../../Integrated Navigation Data/201401031548 (GPS L1 Vn 1g 300 6g 1200)/nav_normal.dat');
    data_gnss = importdata('../../../Integrated Navigation Data/201401031548 (GPS L1 Vn 1g 300 6g 1200)/nav_gnss.dat');
elseif SWITCH_FILE == 4
    data = importdata('../../../Integrated Navigation Data/201401031607 (GPS L1 Vn 1g 300 4g 900)/both.dat');
    data_norm = importdata('../../../Integrated Navigation Data/201401031607 (GPS L1 Vn 1g 300 4g 900)/nav_normal.dat');
    data_gnss = importdata('../../../Integrated Navigation Data/201401031607 (GPS L1 Vn 1g 300 4g 900)/nav_gnss.dat');
elseif SWITCH_FILE == 5
    data = importdata('../../../Integrated Navigation Data/201401031355 (BD B3 Vn 300)/both.dat');
    data_norm = importdata('../../../Integrated Navigation Data/201401031355 (BD B3 Vn 300)/nav_normal.dat');
    data_gnss = importdata('../../../Integrated Navigation Data/201401031355 (BD B3 Vn 300)/nav_gnss.dat');
    
elseif SWITCH_FILE == 11
    data = importdata('../../../Integrated Navigation Data/201405301855 (GPS L1 Vn 60)/both.dat');
    data_norm = importdata('../../../Integrated Navigation Data/201405301855 (GPS L1 Vn 60)/nav_normal.dat');
    data_gnss = importdata('../../../Integrated Navigation Data/201405301855 (GPS L1 Vn 60)/nav_gnss.dat');
elseif SWITCH_FILE == 12
    data = importdata('../../../Integrated Navigation Data/201405301856 (GPS L1 Vn 300)/both.dat');
    data_norm = importdata('../../../Integrated Navigation Data/201405301856 (GPS L1 Vn 300)/nav_normal.dat');
    data_gnss = importdata('../../../Integrated Navigation Data/201405301856 (GPS L1 Vn 300)/nav_gnss.dat');


elseif SWITCH_FILE == 21
    data = importdata('../../../Integrated Navigation Data/201306010101 (GPS Real Static)/both.dat');
    data_norm = importdata('../../../Integrated Navigation Data/201306010101 (GPS Real Static)/nav_normal.dat');
    data_gnss = importdata('../../../Integrated Navigation Data/201306010101 (GPS Real Static)/nav_gnss.dat');
end


% Import normal navigation results
lenNorm = length(data_norm);
timeNorm = data_norm( : , 1)';
pitchNorm = data_norm( : , 2)';
rollNorm = data_norm( : , 3)';
yawNorm = data_norm( : , 4)';
veNorm = data_norm( : , 5)';
vnNorm = data_norm( : , 6)';
vuNorm = data_norm( : , 7)';
laNorm = data_norm( : , 8)';
lonNorm = data_norm( : , 9)';
altNorm = data_norm( : , 10)';


% Import GNSS navigation results
len_gnss = length(data_gnss);
time_gnss = data_gnss( : , 1)';
la_gnss = data_gnss( : , 2)';
lon_gnss = data_gnss( : , 3)';
alt_gnss = data_gnss( : , 4)';
ve_gnss = data_gnss( : , 5)';
vn_gnss = data_gnss( : , 6)';
vu_gnss = data_gnss( : , 7)';



RuntimeImport = toc;
disp(['Importing data rnning time = ', num2str(RuntimeImport), 's']);



%% Prepare KF
disp('Kalman filter preparing begin.');
tic;

if (SWITCH_FILE == 0) || (SWITCH_FILE == 1) || (SWITCH_FILE == 2) || (SWITCH_FILE == 3) || (SWITCH_FILE == 4) || (SWITCH_FILE == 5) || ...
        (SWITCH_FILE == 11) || (SWITCH_FILE == 12)
    
SAMPLING_RATE_IMU = 100; % 100Hz
TIME_INTERVAL_IMU = 0.01; % 0.01s

SAMPLING_RATE_GPS = 10; % 10Hz
TIME_INTERVAL_GPS = 0.1; % 0.1s
    
% Initialization
la0 = 39 * unit_degree2rad;
lon0 = 116 * unit_degree2rad;
h0 = 100;
ve0 =0;
vn0 = 0;
vu0 = 0;
pitch0 = 0 * unit_degree2rad;
roll0 = 0 * unit_degree2rad;
yaw0 = 0 * unit_degree2rad;

% IMU error
drift = [1.1; 1.1; 1.1] * unit_w; % rad/s
bias = [33; 33; 33] * unit_ug; % m/s^2
noiseGyroMSE = [0.011; 0.011; 0.011] * unit_w; % rad/s
noiseAccMSE = [3.3; 3.3; 3.3] * unit_ug; % m/s^2

% Add colored or white Gaussian noise
AR_NOISE_ENABLED = 0;
sizeData = size(data);
lenData = sizeData(1);
noiseGyroPast = zeros(3, 3);
noiseAccPast = zeros(3, 3);
for i = 1 : lenData
    noiseGyro = normrnd(drift', noiseGyroMSE') * 1;
    noiseAcc = normrnd(bias', noiseAccMSE') * 1;

    if AR_NOISE_ENABLED == 1
        noiseGyro = noiseGyro - 1.5 * noiseGyroPast(1, :) - 0.75 * noiseGyroPast(2, : ) - 0.125 * noiseGyroPast(3, : );
        noiseAcc = noiseAcc - 1.5 * noiseAccPast(1, :) - 0.75 * noiseAccPast(2, : ) - 0.125 * noiseAccPast(3, : );
        
        noiseGyroPast(3, : ) = noiseGyroPast(2, : );
        noiseGyroPast(2, : ) = noiseGyroPast(1, : );
        noiseGyroPast(1, : ) = noiseGyro;
        
        noiseAccPast(3, : ) = noiseAccPast(2, : );
        noiseAccPast(2, : ) = noiseAccPast(1, : );
        noiseAccPast(1, : ) = noiseAcc;
    end
    
    data(i , 2 : 4) = data(i , 2 : 4) + noiseGyro;
    data(i , 5 : 7) = data(i , 5 : 7) + noiseAcc;
end
%}





RuntimePrepare = toc;
disp(['Preparing rnning time = ', num2str(RuntimePrepare), 's']);


%% First KF
% Initialize tilt
seitaX = 0.01 * unit_degree2rad;
seitaY = 0.01 * unit_degree2rad;
seitaZ = 0.01 * unit_degree2rad;
seitaSum = sqrt(seitaX ^ 2 + seitaY ^ 2 + seitaZ ^ 2);


mx0 = [seitaX;
       seitaY;
       seitaZ;
       
       0;
       0;
       0;
       
       0 / Re;
       0 / Re;
       0;
       
       1 * unit_w;
       1 * unit_w;
       1 * unit_w;
       
       30 * unit_ug;
       30 * unit_ug;
       30 * unit_ug];


Cx0 = diag([(1e-4 * unit_degree2rad) ^ 2;
            (1e-4 * unit_degree2rad) ^ 2;
            (1e-4 * unit_degree2rad) ^ 2;
            
            (0.01) ^ 2;
            (0.01) ^ 2;
            (0.01) ^ 2;
            
            (0.1 / Re) ^ 2;
            (0.1 / Re) ^ 2;
            (0.1) ^ 2;
            
            (0.01 * unit_w) ^ 2;
            (0.01 * unit_w) ^ 2;
            (0.01 * unit_w) ^ 2;
            
            (1 * unit_ug) ^ 2;
            (1 * unit_ug) ^ 2;
            (1 * unit_ug) ^ 2]);


        
Q = diag([(0.01 * unit_w) ^ 2, (0.01 * unit_w) ^ 2, (0.01 * unit_w) ^ 2, ...
    (3 * unit_ug) ^ 2, (3 * unit_ug) ^ 2, (3 * unit_ug) ^ 2]);
R = diag([0.1 ^ 2, 0.1 ^ 2, 0.1 ^ 2, ...
    (1 / Re) ^ 2, (1 / Re) ^ 2, 1 ^ 2]);
        



elseif (SWITCH_FILE == 21)
    
SAMPLING_RATE_IMU = 100; % 100Hz
TIME_INTERVAL_IMU = 0.01; % 0.01s

SAMPLING_RATE_GPS = 20; % 100Hz
TIME_INTERVAL_GPS = 0.05; % 0.01s
    
% Initialization
la0 = 34.652160625000000 * unit_degree2rad;
lon0 = 109.2496237170000 * unit_degree2rad;
h0 = 362.2690000000000;
ve0 =0;
vn0 = 0;
vu0 = 0;
pitch0 = 0.25516 * unit_degree2rad;
roll0 = 1.76037 * unit_degree2rad;
yaw0 = 303.10881 * unit_degree2rad;


% Initialize tilt
seitaX = 0.01 * unit_degree2rad;
seitaY = 0.01 * unit_degree2rad;
seitaZ = 0.01 * unit_degree2rad;
seitaSum = sqrt(seitaX ^ 2 + seitaY ^ 2 + seitaZ ^ 2);


mx0 = [seitaX;
       seitaY;
       seitaZ;
       
       0;
       0;
       0;
       
       0 / Re;
       0 / Re;
       0;
       
       0.1 * unit_w;
       0.1 * unit_w;
       0.1 * unit_w;
       
       50 * unit_ug;
       50 * unit_ug;
       50 * unit_ug];


Cx0 = diag([(1e-4 * unit_degree2rad) ^ 2;
            (1e-4 * unit_degree2rad) ^ 2;
            (1e-4 * unit_degree2rad) ^ 2;
            
            (0.01) ^ 2;
            (0.01) ^ 2;
            (0.01) ^ 2;
            
            (0.1 / Re) ^ 2;
            (0.1 / Re) ^ 2;
            (0.1) ^ 2;
            
            (0.01 * unit_w) ^ 2;
            (0.01 * unit_w) ^ 2;
            (0.01 * unit_w) ^ 2;
            
            (1 * unit_ug) ^ 2;
            (1 * unit_ug) ^ 2;
            (1 * unit_ug) ^ 2]);


        
Q = diag([(0.01 * unit_w) ^ 2, (0.01 * unit_w) ^ 2, (0.01 * unit_w) ^ 2, ...
    (3 * unit_ug) ^ 2, (3 * unit_ug) ^ 2, (3 * unit_ug) ^ 2]);
R = diag([0.01 ^ 2, 0.01 ^ 2, 0.01 ^ 2, ...
    (0.1 / Re) ^ 2, (0.1 / Re) ^ 2, 0.15 ^ 2]);
end
        
disp('First Kalman filtering begin.');
tic;

Hinfinity = 0;
[la_kf1, lon_kf1, alt_kf1, v_kf1, pitch_kf1, roll_kf1, yaw_kf1, time_kf1, time_var1, error1, var1] = ...
    kf(la0, lon0, h0, ve0, vn0, vu0, pitch0, roll0, yaw0, ...
    data, ...
    TIME_INTERVAL_IMU, TIME_INTERVAL_GPS, mx0, Cx0, Q, R, 1, Hinfinity);

RuntimeKF = toc;
disp(['First Kalman filtering rnning time = ', num2str(RuntimeKF), 's']);


la_kf1 = la_kf1 / unit_degree2rad;
lon_kf1 = lon_kf1 / unit_degree2rad;
pitch_kf1 = pitch_kf1 / unit_degree2rad;
roll_kf1 = roll_kf1 / unit_degree2rad;
yaw_kf1 = yaw_kf1 / unit_degree2rad;

ve_kf1 = v_kf1(1, : );
vn_kf1 = v_kf1(2, : );
vu_kf1 = v_kf1(3, : );

time_kf1(1, end + 1) = time_kf1(1, end) + 1000 * TIME_INTERVAL_IMU;
time_var1(1, end + 1) = time_var1(1, end) + 1000 * TIME_INTERVAL_GPS;

% Error of navigation results
time = time_kf1;
pitch = pitch_kf1;
roll = roll_kf1;
yaw = yaw_kf1;
ve = ve_kf1;
vn = vn_kf1;
vu = vu_kf1;
la = la_kf1;
lon = lon_kf1;
alt = alt_kf1;

len_kf1 = length(time_kf1);
lenMin1 = min(len_kf1, lenNorm - 1);

timeError1 = zeros(1, lenMin1);
pitchError1 = zeros(1, lenMin1);
rollError1 = zeros(1, lenMin1);
yawError1 = zeros(1, lenMin1);
veError1 = zeros(1, lenMin1);
vnError1 = zeros(1, lenMin1);
vuError1 = zeros(1, lenMin1);
laError1 = zeros(1, lenMin1);
lonError1 = zeros(1, lenMin1);
altError1 = zeros(1, lenMin1);

i = 1;
j = 1;
lenError1 = 0;
while((i <= lenMin1) && (j <= lenMin1))
    if time(i) < timeNorm(j)
        i = i + 1;
    elseif time(i) > timeNorm(j + 1)
        j = j + 1;
    else
        pitchSync = (pitchNorm(j + 1) - pitchNorm(j)) / (timeNorm(j + 1) - timeNorm(j)) * (time(i) - timeNorm(j)) + pitchNorm(i);
        if pitchSync > 90
            pitchSync = pitchSync - 180;
        elseif pitchSync < -90
            pitchSync = pitchSync + 180;
        end
        rollSync = (rollNorm(j + 1) - rollNorm(j)) / (timeNorm(j + 1) - timeNorm(j)) * (time(i) - timeNorm(j)) + rollNorm(i);
        if rollSync > 180
            rollSync = rollSync - 360;
        elseif rollSync < -180
            rollSync = rollSync + 360;
        end
        yawSync = (yawNorm(j + 1) - yawNorm(j)) / (timeNorm(j + 1) - timeNorm(j)) * (time(i) - timeNorm(j)) + yawNorm(i);
        if yawSync > 360
            yawSync = yawSync - 360;
        elseif yawSync < 0
            yawSync = yawSync + 360;
        end
        
        veSync = (veNorm(j + 1) - veNorm(j)) / (timeNorm(j + 1) - timeNorm(j)) * (time(i) - timeNorm(j)) + veNorm(i);
        vnSync = (vnNorm(j + 1) - vnNorm(j)) / (timeNorm(j + 1) - timeNorm(j)) * (time(i) - timeNorm(j)) + vnNorm(i);
        vuSync = (vuNorm(j + 1) - vuNorm(j)) / (timeNorm(j + 1) - timeNorm(j)) * (time(i) - timeNorm(j)) + vuNorm(i);
        
        laSync = (laNorm(j + 1) - laNorm(j)) / (timeNorm(j + 1) - timeNorm(j)) * (time(i) - timeNorm(j)) + laNorm(i);
        lonSync = (lonNorm(j + 1) - lonNorm(j)) / (timeNorm(j + 1) - timeNorm(j)) * (time(i) - timeNorm(j)) + lonNorm(i);
        altSync = (altNorm(j + 1) - altNorm(j)) / (timeNorm(j + 1) - timeNorm(j)) * (time(i) - timeNorm(j)) + altNorm(i);
        
        
        lenError1 = lenError1 + 1;
        
        timeError1(lenError1) = time(i);
        pitchError1(lenError1) = pitch(i) - pitchSync;
        rollError1(lenError1) = roll(i) - rollSync;
        yawError1(lenError1) = yaw(i) - yawSync;
        if yawError1(lenError1) > 180
            yawError1(lenError1) = yawError1(lenError1) - 360;
        end
        veError1(lenError1) = ve(i) - veSync;
        vnError1(lenError1) = vn(i) - vnSync;
        vuError1(lenError1) = vu(i) - vuSync;
        laError1(lenError1) = la(i) - laSync;
        lonError1(lenError1) = lon(i) - lonSync;
        altError1(lenError1) = alt(i) - altSync;
        
        i = i + 1;
        j = j + 1;
    end
end



%% Second KF        
disp('Second Kalman filtering begin.');
tic;

mx0KF = mx0;
mx0 = zeros(16, 1);
for i = 1 : 15 - 3
    mx0(i + 4, 1) = mx0KF(i + 3, 1);
end
mx0(1, 1) = cos(seitaSum / 2);
mx0(2, 1) = sin(seitaSum / 2) * seitaX / seitaSum;
mx0(3, 1) = sin(seitaSum / 2) * seitaY / seitaSum;
mx0(4, 1) = sin(seitaSum / 2) * seitaZ / seitaSum;



   
Cx0KF = Cx0;
Cx0 = zeros(16, 16);
for i = 1 : 15 - 3
    Cx0(i + 4, i + 4) = Cx0KF(i + 3, i + 3);
end
Cx0(1, 1) = (1e-4) ^ 2;
Cx0(2, 2) = (1e-4) ^ 2;
Cx0(3, 3) = (1e-4) ^ 2;
Cx0(4, 4) = (1e-4) ^ 2;


Hinfinity = 0;
[la_kf2, lon_kf2, alt_kf2, v_kf2, pitch_kf2, roll_kf2, yaw_kf2, time_kf2, time_var2, error2, var2] = ...
    qsrukf_pv_euler(la0, lon0, h0, ve0, vn0, vu0, pitch0, roll0, yaw0, ...
    data, ...
    TIME_INTERVAL_IMU, TIME_INTERVAL_GPS, mx0, Cx0, Q, R, 1, Hinfinity);

RuntimeKF = toc;
disp(['Second Kalman filtering rnning time = ', num2str(RuntimeKF), 's']);


la_kf2 = la_kf2 / unit_degree2rad;
lon_kf2 = lon_kf2 / unit_degree2rad;
pitch_kf2 = pitch_kf2 / unit_degree2rad;
roll_kf2 = roll_kf2 / unit_degree2rad;
yaw_kf2 = yaw_kf2 / unit_degree2rad;

ve_kf2 = v_kf2(1, : );
vn_kf2 = v_kf2(2, : );
vu_kf2 = v_kf2(3, : );

time_kf2(1, end + 1) = time_kf2(1, end) + 1000 * TIME_INTERVAL_IMU;
time_var2(1, end + 1) = time_var2(1, end) + 1000 * TIME_INTERVAL_GPS;

% Error of navigation results
time = time_kf2;
pitch = pitch_kf2;
roll = roll_kf2;
yaw = yaw_kf2;
ve = ve_kf2;
vn = vn_kf2;
vu = vu_kf2;
la = la_kf2;
lon = lon_kf2;
alt = alt_kf2;

len_kf2 = length(time_kf2);
lenMin2 = min(len_kf2, lenNorm - 1);

timeError2 = zeros(1, lenMin2);
pitchError2 = zeros(1, lenMin2);
rollError2 = zeros(1, lenMin2);
yawError2 = zeros(1, lenMin2);
veError2 = zeros(1, lenMin2);
vnError2 = zeros(1, lenMin2);
vuError2 = zeros(1, lenMin2);
laError2 = zeros(1, lenMin2);
lonError2 = zeros(1, lenMin2);
altError2 = zeros(1, lenMin2);

i = 1;
j = 1;
lenError2 = 0;
while((i <= lenMin2) && (j <= lenMin2))
    if time(i) < timeNorm(j)
        i = i + 1;
    elseif time(i) > timeNorm(j + 1)
        j = j + 1;
    else
        pitchSync = (pitchNorm(j + 1) - pitchNorm(j)) / (timeNorm(j + 1) - timeNorm(j)) * (time(i) - timeNorm(j)) + pitchNorm(i);
        if pitchSync > 90
            pitchSync = pitchSync - 180;
        elseif pitchSync < -90
            pitchSync = pitchSync + 180;
        end
        rollSync = (rollNorm(j + 1) - rollNorm(j)) / (timeNorm(j + 1) - timeNorm(j)) * (time(i) - timeNorm(j)) + rollNorm(i);
        if rollSync > 180
            rollSync = rollSync - 360;
        elseif rollSync < -180
            rollSync = rollSync + 360;
        end
        yawSync = (yawNorm(j + 1) - yawNorm(j)) / (timeNorm(j + 1) - timeNorm(j)) * (time(i) - timeNorm(j)) + yawNorm(i);
        if yawSync > 360
            yawSync = yawSync - 360;
        elseif yawSync < 0
            yawSync = yawSync + 360;
        end
        
        veSync = (veNorm(j + 1) - veNorm(j)) / (timeNorm(j + 1) - timeNorm(j)) * (time(i) - timeNorm(j)) + veNorm(i);
        vnSync = (vnNorm(j + 1) - vnNorm(j)) / (timeNorm(j + 1) - timeNorm(j)) * (time(i) - timeNorm(j)) + vnNorm(i);
        vuSync = (vuNorm(j + 1) - vuNorm(j)) / (timeNorm(j + 1) - timeNorm(j)) * (time(i) - timeNorm(j)) + vuNorm(i);
        
        laSync = (laNorm(j + 1) - laNorm(j)) / (timeNorm(j + 1) - timeNorm(j)) * (time(i) - timeNorm(j)) + laNorm(i);
        lonSync = (lonNorm(j + 1) - lonNorm(j)) / (timeNorm(j + 1) - timeNorm(j)) * (time(i) - timeNorm(j)) + lonNorm(i);
        altSync = (altNorm(j + 1) - altNorm(j)) / (timeNorm(j + 1) - timeNorm(j)) * (time(i) - timeNorm(j)) + altNorm(i);
        
        
        lenError2 = lenError2 + 1;
        
        timeError2(lenError2) = time(i);
        pitchError2(lenError2) = pitch(i) - pitchSync;
        rollError2(lenError2) = roll(i) - rollSync;
        yawError2(lenError2) = yaw(i) - yawSync;
        if yawError2(lenError2) > 180
            yawError2(lenError2) = yawError2(lenError2) - 360;
        end
        veError2(lenError2) = ve(i) - veSync;
        vnError2(lenError2) = vn(i) - vnSync;
        vuError2(lenError2) = vu(i) - vuSync;
        laError2(lenError2) = la(i) - laSync;
        lonError2(lenError2) = lon(i) - lonSync;
        altError2(lenError2) = alt(i) - altSync;
        
        i = i + 1;
        j = j + 1;
    end
end





timePlus1 = 0 : 0.01 : (lenError1 - 1) * 0.01;
timePlus2 = 0 : 0.01 : (lenError2 - 1) * 0.01;



%% Drawing results
disp('Drawing results begin.');
tic;

figure('name', 'Attitude Error');
subplot(3, 1, 1), 
plot(timePlus1(1 : lenError1), pitchError1(1 : lenError1), 'Color', 'k', 'LineStyle', ':'), hold on;
plot(timePlus2(1 : lenError2), pitchError2(1 : lenError2), 'Color', 'k', 'LineStyle', '-'), hold on;
legend('KF', 'QSRUKF'); xlabel('Time/s'), ylabel('Pitch Error/degree');
subplot(3, 1, 2), 
plot(timePlus1(1 : lenError1), rollError1(1 : lenError1), 'Color', 'k', 'LineStyle', ':'), hold on;
plot(timePlus2(1 : lenError2), rollError2(1 : lenError2), 'Color', 'k', 'LineStyle', '-'), hold on;
legend('KF', 'QSRUKF'); xlabel('Time/s'), ylabel('Roll Error/degree');
subplot(3, 1, 3), 
plot(timePlus1(1 : lenError1), yawError1(1 : lenError1), 'Color', 'k', 'LineStyle', ':'), hold on;
plot(timePlus2(1 : lenError2), yawError2(1 : lenError2), 'Color', 'k', 'LineStyle', '-'), hold on;
legend('KF', 'QSRUKF'); xlabel('Time/s'), ylabel('Yaw Error/degree');

figure('name', 'Velocity Error');
subplot(3, 1, 1), 
plot(timePlus1(1 : lenError1), veError1(1 : lenError1), 'Color', 'k', 'LineStyle', ':'), hold on;
plot(timePlus2(1 : lenError2), veError2(1 : lenError2), 'Color', 'k', 'LineStyle', '-'), hold on;
legend('KF', 'QSRUKF'); xlabel('Time/s'), ylabel('East Velocity Error/m/s');
subplot(3, 1, 2), 
plot(timePlus1(1 : lenError1), vnError1(1 : lenError1), 'Color', 'k', 'LineStyle', ':'), hold on;
plot(timePlus2(1 : lenError2), vnError2(1 : lenError2), 'Color', 'k', 'LineStyle', '-'), hold on;
legend('KF', 'QSRUKF'); xlabel('Time/s'), ylabel('North Velocity Error/m/s');
subplot(3, 1, 3), 
plot(timePlus1(1 : lenError1), vuError1(1 : lenError1), 'Color', 'k', 'LineStyle', ':'), hold on;
plot(timePlus2(1 : lenError2), vuError2(1 : lenError2), 'Color', 'k', 'LineStyle', '-'), hold on;
legend('KF', 'QSRUKF'); xlabel('Time/s'), ylabel('Up Velocity Error/m/s');

figure('name', 'Position Error');
subplot(3, 1, 1), 
plot(timePlus1(1 : lenError1), laError1(1 : lenError1) * unit_degree2rad * Re, 'Color', 'k', 'LineStyle', ':'), hold on;
plot(timePlus2(1 : lenError2), laError2(1 : lenError2) * unit_degree2rad * Re, 'Color', 'k', 'LineStyle', '-'), hold on;
legend('KF', 'QSRUKF'); xlabel('Time/s'), ylabel('North Position Error/m');
subplot(3, 1, 2), 
plot(timePlus1(1 : lenError1), lonError1(1 : lenError1) * unit_degree2rad * Re, 'Color', 'k', 'LineStyle', ':'), hold on;
plot(timePlus2(1 : lenError2), lonError2(1 : lenError2) * unit_degree2rad * Re, 'Color', 'k', 'LineStyle', '-'), hold on;
legend('KF', 'QSRUKF'); xlabel('Time/s'), ylabel('East Position Error/m');
subplot(3, 1, 3), 
plot(timePlus1(1 : lenError1), altError1(1 : lenError1), 'Color', 'k', 'LineStyle', ':'), hold on;
plot(timePlus2(1 : lenError2), altError2(1 : lenError2), 'Color', 'k', 'LineStyle', '-'), hold on;
legend('KF', 'QSRUKF'); xlabel('Time/s'), ylabel('Altitude Error/m');




figure('name', 'Gyroscope Drift Estimation');
subplot(3, 1, 1),
plot(time_var1(1 : end), error1(10, 1 : end) / unit_w, 'Color', 'r'), hold on;
plot(time_var2(1 : end), error2(11, 1 : end) / unit_w, 'Color', 'b'), hold on;
legend('KF', 'QSRUKF'); xlabel('Time/s'), ylabel('X/degree/h');
subplot(3, 1, 2),
plot(time_var1(1 : end), error1(11, 1 : end) / unit_w, 'Color', 'r'), hold on;
plot(time_var2(1 : end), error2(12, 1 : end) / unit_w, 'Color', 'b'), hold on;
legend('KF', 'QSRUKF'); xlabel('Time/s'), ylabel('Y/degree/h');
subplot(3, 1, 3),
plot(time_var1(1 : end), error1(12, 1 : end) / unit_w, 'Color', 'r'), hold on;
plot(time_var2(1 : end), error2(13, 1 : end) / unit_w, 'Color', 'b'), hold on;
legend('KF', 'QSRUKF'); xlabel('Time/s'), ylabel('Z/degree/h');

figure('name', 'Accelerometer Bias Estimation');
subplot(3, 1, 1),
plot(time_var1(1 : end), error1(13, 1 : end) / unit_ug, 'Color', 'r'), hold on;
plot(time_var2(1 : end), error2(14, 1 : end) / unit_ug, 'Color', 'b'), hold on;
legend('KF', 'QSRUKF'); xlabel('Time/s'), ylabel('X/ug');
subplot(3, 1, 2),
plot(time_var1(1 : end), error1(14, 1 : end) / unit_ug, 'Color', 'r'), hold on;
plot(time_var2(1 : end), error2(15, 1 : end) / unit_ug, 'Color', 'b'), hold on;
legend('KF', 'QSRUKF'); xlabel('Time/s'), ylabel('Y/ug');
subplot(3, 1, 3),
plot(time_var1(1 : end), error1(15, 1 : end) / unit_ug, 'Color', 'r'), hold on;
plot(time_var2(1 : end), error2(16, 1 : end) / unit_ug, 'Color', 'b'), hold on;
legend('KF', 'QSRUKF'); xlabel('Time/s'), ylabel('Z/ug');






figure('name', 'Velocity Estimation MSE');
subplot(3, 1, 1), 
plot(time_var1(1 : end), var1(4, 1 : end), 'Color', 'r'), hold on;
plot(time_var2(1 : end), var2(5, 1 : end), 'Color', 'b'), hold on;
legend('KF', 'QSRUKF'); title('Velocity east error MSE');
subplot(3, 1, 2), 
plot(time_var1(1 : end), var1(5, 1 : end), 'Color', 'r'), hold on;
plot(time_var2(1 : end), var2(6, 1 : end), 'Color', 'b'), hold on;
legend('KF', 'QSRUKF'); title('Velocity north error MSE');
subplot(3, 1, 3), 
plot(time_var1(1 : end), var1(6, 1 : end), 'Color', 'r'), hold on;
plot(time_var2(1 : end), var2(7, 1 : end), 'Color', 'b'), hold on;
legend('KF', 'QSRUKF'); title('Velocity up error MSE');

figure('name', 'Position Estimation MSE');
subplot(3, 1, 1), 
plot(time_var1(1 : end), var1(7, 1 : end), 'Color', 'r'), hold on;
plot(time_var2(1 : end), var2(8, 1 : end), 'Color', 'b'), hold on;
legend('KF', 'QSRUKF'); title('Latitude error MSE');
subplot(3, 1, 2), 
plot(time_var1(1 : end), var1(8, 1 : end), 'Color', 'r'), hold on;
plot(time_var2(1 : end), var2(9, 1 : end), 'Color', 'b'), hold on;
legend('KF', 'QSRUKF'); title('Longitude error MSE');
subplot(3, 1, 3), 
plot(time_var1(1 : end), var1(9, 1 : end), 'Color', 'r'), hold on;
plot(time_var2(1 : end), var2(10, 1 : end), 'Color', 'b'), hold on;
legend('KF', 'QSRUKF'); title('Altitude error MSE');

figure('name', 'IMU Error Estimation MSE');
subplot(2, 3, 1), 
plot(time_var1(1 : end), var1(10, 1 : end), 'Color', 'r'), hold on;
plot(time_var2(1 : end), var2(11, 1 : end), 'Color', 'b'), hold on;
legend('KF', 'QSRUKF'); title('Gyroscope drift x MSE');
subplot(2, 3, 2),
plot(time_var1(1 : end), var1(11, 1 : end), 'Color', 'r'), hold on;
plot(time_var2(1 : end), var2(12, 1 : end), 'Color', 'b'), hold on;
legend('KF', 'QSRUKF'); title('Gyroscope drift y MSE');
subplot(2, 3, 3), 
plot(time_var1(1 : end), var1(12, 1 : end), 'Color', 'r'), hold on;
plot(time_var2(1 : end), var2(13, 1 : end), 'Color', 'b'), hold on;
legend('KF', 'QSRUKF'); title('Gyroscope drift z MSE');
subplot(2, 3, 4),
plot(time_var1(1 : end), var1(13, 1 : end), 'Color', 'r'), hold on;
plot(time_var2(1 : end), var2(14, 1 : end), 'Color', 'b'), hold on;
legend('KF', 'QSRUKF'); title('Accelerometer bias x MSE');
subplot(2, 3, 5), 
plot(time_var1(1 : end), var1(14, 1 : end), 'Color', 'r'), hold on;
plot(time_var2(1 : end), var2(15, 1 : end), 'Color', 'b'), hold on;
legend('KF', 'QSRUKF'); title('Accelerometer bias y MSE');
subplot(2, 3, 6), 
plot(time_var1(1 : end), var1(15, 1 : end), 'Color', 'r'), hold on;
plot(time_var2(1 : end), var2(16, 1 : end), 'Color', 'b'), hold on;
legend('KF', 'QSRUKF'); title('Accelerometer bias z MSE');


RuntimeDraw = toc;
disp(['Drawing results running time = ', num2str(RuntimeDraw), 's']);





