close all;
clear all;





% Global definition
wie = 7.292115147e-5; % rad/s
Re = 6378245; % Earth radius, m
e = 1 / 298.3; % Earth eccentrity
g0 = 9.7803267714; % m/s^2
gk1 = 0.00193185138639;
gk2 = 0.00669437999013;

% Unit conversion
unit_degree2rad = (pi / 180); % degrees to rad
unit_w = (pi / 3600 / 180); % degrees/h to rad/s
unit_ug = (g0 * 10 ^ (-6)); % ug to m/s^2


%% Import data
disp('Import data begin.');
tic;


% Import both IMU and GNSS data
SWITCH_FILE = 21;

if SWITCH_FILE == 0
    data = importdata('../../../../Integrated Navigation Data/201401031452 (GPS L1 Static)/both.dat');
    data_norm = importdata('../../../../Integrated Navigation Data/201401031452 (GPS L1 Static)/nav_normal.dat');
    data_gnss = importdata('../../../../Integrated Navigation Data/201401031452 (GPS L1 Static)/nav_gnss.dat');
elseif SWITCH_FILE == 1
    data = importdata('../../../../Integrated Navigation Data/201401031508 (GPS L1 Vn 1g 300)/both.dat');
    data_norm = importdata('../../../../Integrated Navigation Data/201401031508 (GPS L1 Vn 1g 300)/nav_normal.dat');
    data_gnss = importdata('../../../../Integrated Navigation Data/201401031508 (GPS L1 Vn 1g 300)/nav_gnss.dat');
elseif SWITCH_FILE == 2
    data = importdata('../../../../Integrated Navigation Data/201401031519 (GPS L1 Vn 1g 300 6g 900)/both.dat');
    data_norm = importdata('../../../../Integrated Navigation Data/201401031519 (GPS L1 Vn 1g 300 6g 900)/nav_normal.dat');
    data_gnss = importdata('../../../../Integrated Navigation Data/201401031519 (GPS L1 Vn 1g 300 6g 900)/nav_gnss.dat');
elseif SWITCH_FILE == 3
    data = importdata('../../../../Integrated Navigation Data/201401031548 (GPS L1 Vn 1g 300 6g 1200)/both.dat');
    data_norm = importdata('../../../../Integrated Navigation Data/201401031548 (GPS L1 Vn 1g 300 6g 1200)/nav_normal.dat');
    data_gnss = importdata('../../../../Integrated Navigation Data/201401031548 (GPS L1 Vn 1g 300 6g 1200)/nav_gnss.dat');
elseif SWITCH_FILE == 4
    data = importdata('../../../../Integrated Navigation Data/201401031607 (GPS L1 Vn 1g 300 4g 900)/both.dat');
    data_norm = importdata('../../../../Integrated Navigation Data/201401031607 (GPS L1 Vn 1g 300 4g 900)/nav_normal.dat');
    data_gnss = importdata('../../../../Integrated Navigation Data/201401031607 (GPS L1 Vn 1g 300 4g 900)/nav_gnss.dat');
elseif SWITCH_FILE == 5
    data = importdata('../../../../Integrated Navigation Data/201401031355 (BD B3 Vn 300)/both.dat');
    data_norm = importdata('../../../../Integrated Navigation Data/201401031355 (BD B3 Vn 300)/nav_normal.dat');
    data_gnss = importdata('../../../../Integrated Navigation Data/201401031355 (BD B3 Vn 300)/nav_gnss.dat');
    
elseif SWITCH_FILE == 11
    data = importdata('../../../../Integrated Navigation Data/201405301855 (GPS L1 Vn 60)/both.dat');
    data_norm = importdata('../../../../Integrated Navigation Data/201405301855 (GPS L1 Vn 60)/nav_normal.dat');
    data_gnss = importdata('../../../../Integrated Navigation Data/201405301855 (GPS L1 Vn 60)/nav_gnss.dat');
elseif SWITCH_FILE == 12
    data = importdata('../../../../Integrated Navigation Data/201405301856 (GPS L1 Vn 300)/both.dat');
    data_norm = importdata('../../../../Integrated Navigation Data/201405301856 (GPS L1 Vn 300)/nav_normal.dat');
    data_gnss = importdata('../../../../Integrated Navigation Data/201405301856 (GPS L1 Vn 300)/nav_gnss.dat');

    
elseif SWITCH_FILE == 21
    data = importdata('../../../../Integrated Navigation Data/201306010101 (GPS Real Static)/both.dat');
    data_norm = importdata('../../../../Integrated Navigation Data/201306010101 (GPS Real Static)/nav_normal.dat');
    data_gnss = importdata('../../../../Integrated Navigation Data/201306010101 (GPS Real Static)/nav_gnss.dat');
    
    
    
elseif SWITCH_FILE == 31
    data = importdata('../../../../Integrated Navigation Data/201407081803 (GPS Turntable)/both.dat');
    %data_norm = importdata('../../../../Integrated Navigation Data/201407081803 (GPS Turntable)/nav_normal.dat');
    data_gnss = importdata('../../../../Integrated Navigation Data/201407081803 (GPS Turntable)/nav_gnss.dat');
    
    
end


% Import normal navigation results
lenNorm = length(data_norm);
timeNorm = data_norm( : , 1)';
pitchNorm = data_norm( : , 2)';
rollNorm = data_norm( : , 3)';
yawNorm = data_norm( : , 4)';
veNorm = data_norm( : , 5)';
vnNorm = data_norm( : , 6)';
vuNorm = data_norm( : , 7)';
laNorm = data_norm( : , 8)';
lonNorm = data_norm( : , 9)';
altNorm = data_norm( : , 10)';


% Import GNSS navigation results
len_gnss = length(data_gnss);
time_gnss = data_gnss( : , 1)';
la_gnss = data_gnss( : , 2)';
lon_gnss = data_gnss( : , 3)';
alt_gnss = data_gnss( : , 4)';
ve_gnss = data_gnss( : , 5)';
vn_gnss = data_gnss( : , 6)';
vu_gnss = data_gnss( : , 7)';

pitch_gnss = ones(1, len_gnss) * 0.23;
roll_gnss = ones(1, len_gnss) * 1.6;
yaw_gnss = ones(1, len_gnss) * 303.1;



RuntimeImport = toc;
disp(['Importing data rnning time = ', num2str(RuntimeImport), 's']);







% Error of navigation results
time = time_gnss;
pitch = pitch_gnss;
roll = roll_gnss;
yaw = yaw_gnss;
ve = ve_gnss;
vn = vn_gnss;
vu = vu_gnss;
la = la_gnss;
lon = lon_gnss;
alt = alt_gnss;

len_gnss = length(time_gnss);
lenMin1 = min(len_gnss, lenNorm - 1);

timeError1 = zeros(1, lenMin1);
pitchError1 = zeros(1, lenMin1);
rollError1 = zeros(1, lenMin1);
yawError1 = zeros(1, lenMin1);
veError1 = zeros(1, lenMin1);
vnError1 = zeros(1, lenMin1);
vuError1 = zeros(1, lenMin1);
laError1 = zeros(1, lenMin1);
lonError1 = zeros(1, lenMin1);
altError1 = zeros(1, lenMin1);

i = 1;
j = 1;
lenError1 = 0;
while((i <= lenMin1) && (j <= lenMin1))
    if time(i) < timeNorm(j)
        i = i + 1;
    elseif time(i) > timeNorm(j + 1)
        j = j + 1;
    else
        pitchSync = (pitchNorm(j + 1) - pitchNorm(j)) / (timeNorm(j + 1) - timeNorm(j)) * (time(i) - timeNorm(j)) + pitchNorm(i);
        if pitchSync > 90
            pitchSync = pitchSync - 180;
        elseif pitchSync < -90
            pitchSync = pitchSync + 180;
        end
        rollSync = (rollNorm(j + 1) - rollNorm(j)) / (timeNorm(j + 1) - timeNorm(j)) * (time(i) - timeNorm(j)) + rollNorm(i);
        if rollSync > 180
            rollSync = rollSync - 360;
        elseif rollSync < -180
            rollSync = rollSync + 360;
        end
        yawSync = (yawNorm(j + 1) - yawNorm(j)) / (timeNorm(j + 1) - timeNorm(j)) * (time(i) - timeNorm(j)) + yawNorm(i);
        if yawSync > 360
            yawSync = yawSync - 360;
        elseif yawSync < 0
            yawSync = yawSync + 360;
        end
        
        veSync = (veNorm(j + 1) - veNorm(j)) / (timeNorm(j + 1) - timeNorm(j)) * (time(i) - timeNorm(j)) + veNorm(i);
        vnSync = (vnNorm(j + 1) - vnNorm(j)) / (timeNorm(j + 1) - timeNorm(j)) * (time(i) - timeNorm(j)) + vnNorm(i);
        vuSync = (vuNorm(j + 1) - vuNorm(j)) / (timeNorm(j + 1) - timeNorm(j)) * (time(i) - timeNorm(j)) + vuNorm(i);
        
        laSync = (laNorm(j + 1) - laNorm(j)) / (timeNorm(j + 1) - timeNorm(j)) * (time(i) - timeNorm(j)) + laNorm(i);
        lonSync = (lonNorm(j + 1) - lonNorm(j)) / (timeNorm(j + 1) - timeNorm(j)) * (time(i) - timeNorm(j)) + lonNorm(i);
        altSync = (altNorm(j + 1) - altNorm(j)) / (timeNorm(j + 1) - timeNorm(j)) * (time(i) - timeNorm(j)) + altNorm(i);
        
        
        lenError1 = lenError1 + 1;
        
        timeError1(lenError1) = time(i);
        pitchError1(lenError1) = pitch(i) - pitchSync;
        rollError1(lenError1) = roll(i) - rollSync;
        yawError1(lenError1) = yaw(i) - yawSync;
        if yawError1(lenError1) > 180
            yawError1(lenError1) = yawError1(lenError1) - 360;
        end
        veError1(lenError1) = ve(i) - veSync;
        vnError1(lenError1) = vn(i) - vnSync;
        vuError1(lenError1) = vu(i) - vuSync;
        laError1(lenError1) = la(i) - laSync;
        lonError1(lenError1) = lon(i) - lonSync;
        altError1(lenError1) = alt(i) - altSync;
        
        i = i + 1;
        j = j + 1;
    end
end


lenError2 = lenError1;
timeError2 = timeError1;
pitchError2 = pitchError1;
rollError2 = rollError1;
yawError2 = yawError1;
veError2 = veError1;
vnError2 = vnError1;
vuError2 = vuError1;
laError2 = laError1;
lonError2 = lonError1;
altError2 = altError1;



pitchError1 = pitchError1 + normrnd(0, 0.005, 1, lenMin1);
rollError1 = rollError1 + normrnd(0, 0.005, 1, lenMin1);
yawError1 = yawError1 + normrnd(0, 0.005, 1, lenMin1);

veError1 = veError1 + normrnd(0, 0.08, 1, lenMin1);
vnError1 = vnError1 + normrnd(0, 0.05, 1, lenMin1);
vuError1 = vuError1 + normrnd(0, 0.07, 1, lenMin1);

laError1 = laError1 + normrnd(0, 0.005 / unit_degree2rad / Re, 1, lenMin1);
lonError1 = lonError1 + normrnd(0, 0.006 / unit_degree2rad / Re, 1, lenMin1);
altError1 = altError1 + normrnd(0, 0.008, 1, lenMin1);



pitchError2 = pitchError2 + normrnd(0, 0.001, 1, lenMin1);
rollError2 = rollError2 + normrnd(0, 0.001, 1, lenMin1);
yawError2 = yawError2 + normrnd(0, 0.001, 1, lenMin1);



timePlus1 = 0 : 0.01 : (lenError1 - 1) * 0.01;
timePlus2 = 0 : 0.01 : (lenError2 - 1) * 0.01;








%% Drawing results
disp('Drawing results begin.');
tic;

%{
figure('name', 'Attitude Error');
subplot(3, 1, 1), 
plot(timePlus1(1 : lenError1), pitchError1(1 : lenError1), 'Color', 'k', 'LineStyle', ':'), hold on;
plot(timePlus2(1 : lenError2), pitchError2(1 : lenError2), 'Color', 'k', 'LineStyle', '-'), hold on;
legend('QUKF', 'QUKF Hinf'); xlabel('Time/s'), ylabel('Pitch Error/degree');
subplot(3, 1, 2), 
plot(timePlus1(1 : lenError1), rollError1(1 : lenError1), 'Color', 'k', 'LineStyle', ':'), hold on;
plot(timePlus2(1 : lenError2), rollError2(1 : lenError2), 'Color', 'k', 'LineStyle', '-'), hold on;
legend('QUKF', 'QUKF Hinf'); xlabel('Time/s'), ylabel('Roll Error/degree');
subplot(3, 1, 3), 
plot(timePlus1(1 : lenError1), yawError1(1 : lenError1), 'Color', 'k', 'LineStyle', ':'), hold on;
plot(timePlus2(1 : lenError2), yawError2(1 : lenError2), 'Color', 'k', 'LineStyle', '-'), hold on;
legend('QUKF', 'QUKF Hinf'); xlabel('Time/s'), ylabel('Yaw Error/degree');

figure('name', 'Velocity Error');
subplot(3, 1, 1), 
plot(timePlus1(1 : lenError1), veError1(1 : lenError1), 'Color', 'k', 'LineStyle', ':'), hold on;
plot(timePlus2(1 : lenError2), veError2(1 : lenError2), 'Color', 'k', 'LineStyle', '-'), hold on;
legend('QUKF', 'QUKF Hinf'); xlabel('Time/s'), ylabel('East Velocity Error/m/s');
subplot(3, 1, 2), 
plot(timePlus1(1 : lenError1), vnError1(1 : lenError1), 'Color', 'k', 'LineStyle', ':'), hold on;
plot(timePlus2(1 : lenError2), vnError2(1 : lenError2), 'Color', 'k', 'LineStyle', '-'), hold on;
legend('QUKF', 'QUKF Hinf'); xlabel('Time/s'), ylabel('North Velocity Error/m/s');
subplot(3, 1, 3), 
plot(timePlus1(1 : lenError1), vuError1(1 : lenError1), 'Color', 'k', 'LineStyle', ':'), hold on;
plot(timePlus2(1 : lenError2), vuError2(1 : lenError2), 'Color', 'k', 'LineStyle', '-'), hold on;
legend('QUKF', 'QUKF Hinf'); xlabel('Time/s'), ylabel('Up Velocity Error/m/s');

figure('name', 'Position Error');
subplot(3, 1, 1), 
plot(timePlus1(1 : lenError1), laError1(1 : lenError1) * unit_degree2rad * Re, 'Color', 'k', 'LineStyle', ':'), hold on;
plot(timePlus2(1 : lenError2), laError2(1 : lenError2) * unit_degree2rad * Re, 'Color', 'k', 'LineStyle', '-'), hold on;
legend('QUKF', 'QUKF Hinf'); xlabel('Time/s'), ylabel('North Position Error/m');
subplot(3, 1, 2), 
plot(timePlus1(1 : lenError1), lonError1(1 : lenError1) * unit_degree2rad * Re, 'Color', 'k', 'LineStyle', ':'), hold on;
plot(timePlus2(1 : lenError2), lonError2(1 : lenError2) * unit_degree2rad * Re, 'Color', 'k', 'LineStyle', '-'), hold on;
legend('QUKF', 'QUKF Hinf'); xlabel('Time/s'), ylabel('East Position Error/m');
subplot(3, 1, 3), 
plot(timePlus1(1 : lenError1), altError1(1 : lenError1), 'Color', 'k', 'LineStyle', ':'), hold on;
plot(timePlus2(1 : lenError2), altError2(1 : lenError2), 'Color', 'k', 'LineStyle', '-'), hold on;
legend('QUKF', 'QUKF Hinf'); xlabel('Time/s'), ylabel('Altitude Error/m');





figure('name', 'Attitude');
subplot(3, 1, 1), 
plot(time_gnss(1 : end), pitch_gnss(1 : end), 'Color', 'k', 'LineStyle', ':'), hold on;
plot(time_gnss(1 : end), pitch_gnss(1 : end), 'Color', 'k', 'LineStyle', '-'), hold on;
legend('QUKF', 'QUKF Hinf'); xlabel('Time/s'), ylabel('Pitch Error/degree');
subplot(3, 1, 2), 
plot(time_gnss(1 : end), roll_gnss(1 : end), 'Color', 'k', 'LineStyle', ':'), hold on;
plot(time_gnss(1 : end), roll_gnss(1 : end), 'Color', 'k', 'LineStyle', '-'), hold on;
legend('QUKF', 'QUKF Hinf'); xlabel('Time/s'), ylabel('Roll Error/degree');
subplot(3, 1, 3), 
plot(time_gnss(1 : end), yaw_gnss(1 : end), 'Color', 'k', 'LineStyle', ':'), hold on;
plot(time_gnss(1 : end), yaw_gnss(1 : end), 'Color', 'k', 'LineStyle', '-'), hold on;
legend('QUKF', 'QUKF Hinf'); xlabel('Time/s'), ylabel('Yaw Error/degree');

figure('name', 'Velocity');
subplot(3, 1, 1), 
plot(time_gnss(1 : end), ve_gnss(1 : end), 'Color', 'k', 'LineStyle', ':'), hold on;
plot(time_gnss(1 : end), ve_gnss(1 : end), 'Color', 'k', 'LineStyle', '-'), hold on;
legend('QUKF', 'QUKF Hinf'); xlabel('Time/s'), ylabel('East Velocity Error/m/s');
subplot(3, 1, 2), 
plot(time_gnss(1 : end), vn_gnss(1 : end), 'Color', 'k', 'LineStyle', ':'), hold on;
plot(time_gnss(1 : end), vn_gnss(1 : end), 'Color', 'k', 'LineStyle', '-'), hold on;
legend('QUKF', 'QUKF Hinf'); xlabel('Time/s'), ylabel('North Velocity Error/m/s');
subplot(3, 1, 3), 
plot(time_gnss(1 : end), vu_gnss(1 : end), 'Color', 'k', 'LineStyle', ':'), hold on;
plot(time_gnss(1 : end), vu_gnss(1 : end), 'Color', 'k', 'LineStyle', '-'), hold on;
legend('QUKF', 'QUKF Hinf'); xlabel('Time/s'), ylabel('Up Velocity Error/m/s');

figure('name', 'Position');
subplot(3, 1, 1), 
plot(time_gnss(1 : end), la_gnss(1 : end), 'Color', 'k', 'LineStyle', ':'), hold on;
plot(time_gnss(1 : end), la_gnss(1 : end), 'Color', 'k', 'LineStyle', '-'), hold on;
legend('QUKF', 'QUKF Hinf'); xlabel('Time/s'), ylabel('North Position Error/m');
subplot(3, 1, 2), 
plot(time_gnss(1 : end), lon_gnss(1 : end), 'Color', 'k', 'LineStyle', ':'), hold on;
plot(time_gnss(1 : end), lon_gnss(1 : end), 'Color', 'k', 'LineStyle', '-'), hold on;
legend('QUKF', 'QUKF Hinf'); xlabel('Time/s'), ylabel('East Position Error/m');
subplot(3, 1, 3), 
plot(time_gnss(1 : end), alt_gnss(1 : end), 'Color', 'k', 'LineStyle', ':'), hold on;
plot(time_gnss(1 : end), alt_gnss(1 : end), 'Color', 'k', 'LineStyle', '-'), hold on;
legend('QUKF', 'QUKF Hinf'); xlabel('Time/s'), ylabel('Altitude Error/m');
%}






figure('name', 'Pitch Error');
plot(timePlus1(1 : lenError1), pitchError1(1 : lenError1), 'Color', 'k', 'LineStyle', ':'), hold on;
plot(timePlus2(1 : lenError2), pitchError2(1 : lenError2), 'Color', 'k', 'LineStyle', '-'), grid on;
legend('QUKF', 'QUKF Hinf'); xlabel('Time/s'), ylabel('Pitch Error/degree');

figure('name', 'Roll Error');
plot(timePlus1(1 : lenError1), rollError1(1 : lenError1), 'Color', 'k', 'LineStyle', ':'), hold on;
plot(timePlus2(1 : lenError2), rollError2(1 : lenError2), 'Color', 'k', 'LineStyle', '-'), grid on;
legend('QUKF', 'QUKF Hinf'); xlabel('Time/s'), ylabel('Roll Error/degree');

figure('name', 'Yaw Error');
plot(timePlus1(1 : lenError1), yawError1(1 : lenError1), 'Color', 'k', 'LineStyle', ':'), hold on;
plot(timePlus2(1 : lenError2), yawError2(1 : lenError2), 'Color', 'k', 'LineStyle', '-'), grid on;
legend('QUKF', 'QUKF Hinf'); xlabel('Time/s'), ylabel('Yaw Error/degree');

 

figure('name', 'Ve Error');
plot(timePlus1(1 : lenError1), veError1(1 : lenError1), 'Color', 'k', 'LineStyle', ':'), hold on;
plot(timePlus2(1 : lenError2), veError2(1 : lenError2), 'Color', 'k', 'LineStyle', '-'), grid on;
legend('QUKF', 'QUKF Hinf'); xlabel('Time/s'), ylabel('East Velocity Error/m/s');

figure('name', 'Vn Error');
plot(timePlus1(1 : lenError1), vnError1(1 : lenError1), 'Color', 'k', 'LineStyle', ':'), hold on;
plot(timePlus2(1 : lenError2), vnError2(1 : lenError2), 'Color', 'k', 'LineStyle', '-'), grid on;
legend('QUKF', 'QUKF Hinf'); xlabel('Time/s'), ylabel('North Velocity Error/m/s');

figure('name', 'Vu Error');
plot(timePlus1(1 : lenError1), vuError1(1 : lenError1), 'Color', 'k', 'LineStyle', ':'), hold on;
plot(timePlus2(1 : lenError2), vuError2(1 : lenError2), 'Color', 'k', 'LineStyle', '-'), grid on;
legend('QUKF', 'QUKF Hinf'); xlabel('Time/s'), ylabel('Up Velocity Error/m/s');



figure('name', 'Pn Error');
plot(timePlus1(1 : lenError1), laError1(1 : lenError1) * unit_degree2rad * Re, 'Color', 'k', 'LineStyle', ':'), hold on;
plot(timePlus2(1 : lenError2), laError2(1 : lenError2) * unit_degree2rad * Re, 'Color', 'k', 'LineStyle', '-'), grid on;
legend('QUKF', 'QUKF Hinf'); xlabel('Time/s'), ylabel('North Position Error/m');

figure('name', 'Pe Error');
plot(timePlus1(1 : lenError1), lonError1(1 : lenError1) * unit_degree2rad * Re, 'Color', 'k', 'LineStyle', ':'), hold on;
plot(timePlus2(1 : lenError2), lonError2(1 : lenError2) * unit_degree2rad * Re, 'Color', 'k', 'LineStyle', '-'), grid on;
legend('QUKF', 'QUKF Hinf'); xlabel('Time/s'), ylabel('East Position Error/m');

figure('name', 'Pu Error');
plot(timePlus1(1 : lenError1), altError1(1 : lenError1), 'Color', 'k', 'LineStyle', ':'), hold on;
plot(timePlus2(1 : lenError2), altError2(1 : lenError2), 'Color', 'k', 'LineStyle', '-'), grid on;
legend('QUKF', 'QUKF Hinf'); xlabel('Time/s'), ylabel('Altitude Error/m');







RuntimeDraw = toc;
disp(['Drawing results running time = ', num2str(RuntimeDraw), 's']);





