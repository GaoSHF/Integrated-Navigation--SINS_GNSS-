close all;
clear all;

RECEIVER_CHANNEL = 10;

IMU_OUTPUT_FREQUENCY = 200;

wie = 7.292115147e-5;
Re = 6378137;
e = (1 / 298.257223563);
g0 = 9.7803267714; % m/s^2
gk1 = 0.00193185138639;
gk2 = 0.00669437999013;

unit_degree2rad = (pi / 180); % degrees to rad

LA0 = (39 * pi / 180);
LON0 = (116 * pi / 180);
H0 = 100;

PITCH0 = 0;
ROLL0 = 0;
YAW0 = 0;

T = 1 / IMU_OUTPUT_FREQUENCY;


%% Loading data
disp('Loading ...');


SWITCH_FILE = 3;

if SWITCH_FILE == 0
    dataTemp = importdata('../../../../Integrated Navigation Data/�������� 20140729\�������� ���� 20140729\201407292220 �ȽǷ��к�� GPS/gnss429.txt');
    dataGNSS = dataTemp.data;
    
    dataTemp = importdata('../../../../Integrated Navigation Data/�������� 20140729\�������� ���� 20140729\201407292220 �ȽǷ��к�� GPS/pulse.txt');
    dataIMU = dataTemp.data;
    
    dataTemp = importdata('../../../../Integrated Navigation Data/�������� 20140729\�������� ���� 20140729\201407292220 �ȽǷ��к�� GPS/trace.txt');
    dataNorm = dataTemp.data(40 * 100 : end, :);


elseif SWITCH_FILE == 2
    dataTemp = importdata('../../../../Integrated Navigation Data/�������� 20140729\�������� ���� 20140729\201407292216 Э��ת��S���� GPS/gnss429.txt');
    dataGNSS = dataTemp.data;
    
    dataTemp = importdata('../../../../Integrated Navigation Data/�������� 20140729\�������� ���� 20140729\201407292216 Э��ת��S���� GPS/pulse.txt');
    dataIMU = dataTemp.data;
    
    dataTemp = importdata('../../../../Integrated Navigation Data/�������� 20140729\�������� ���� 20140729\201407292216 Э��ת��S���� GPS/trace.txt');
    dataNorm = dataTemp.data(40 * 100 : end, :);
    
elseif SWITCH_FILE == 3
    dataTemp = importdata('../../../../Integrated Navigation Data/�������� 20140729\�������� ���� 20140729\201407292157 Э��ת��S���� BD/gnss429.txt');
    dataGNSS = dataTemp.data;
    
    dataTemp = importdata('../../../../Integrated Navigation Data/�������� 20140729\�������� ���� 20140729\201407292157 Э��ת��S���� BD/pulse.txt');
    dataIMU = dataTemp.data;
    
    dataTemp = importdata('../../../../Integrated Navigation Data/�������� 20140729\�������� ���� 20140729\201407292157 Э��ת��S���� BD/trace.txt');
    dataNorm = dataTemp.data(40 * 100 : end, :);
    
end


disp('Loading over');


%% IMU data
[lenGNSS, ~] = size(dataGNSS);

timePPS = dataGNSS( : , 1)'; % ms
timeGNSS = dataGNSS( : , 2)'; % ms
RcvTime = dataGNSS( : , 3)';
fixQuality = dataGNSS( : , 4)';
svNumber = dataGNSS( : , 5)';

laGNSS = dataGNSS( : , 6)'; % degrees
lonGNSS = dataGNSS( : , 7)';
altGNSS = dataGNSS( : , 8)';
PDOP = dataGNSS( : , 9)';
pGNSS = dataGNSS( : , 10 : 12)';
vGNSS = dataGNSS( : , 13 : 15)';

channelNo = zeros(lenGNSS, 10)';
channelSNR = zeros(lenGNSS, 10)';
channelPseu = zeros(lenGNSS, 10)';
channelPseuRate = zeros(lenGNSS, 10)';
channelPx = zeros(lenGNSS, 10)';
channelPy = zeros(lenGNSS, 10)';
channelPz = zeros(lenGNSS, 10)';
channelVx = zeros(lenGNSS, 10)';
channelVy = zeros(lenGNSS, 10)';
channelVz = zeros(lenGNSS, 10)';
for i = 1 : RECEIVER_CHANNEL
    channelNo(i, : ) = dataGNSS( : , 16 + (i - 1) * 10)';
    channelSNR(i, : ) = dataGNSS( : , 17 + (i - 1) * 10)';
    channelPseu(i, : ) = dataGNSS( : , 18 + (i - 1) * 10)';
    channelPseuRate(i, : ) = dataGNSS( : , 19 + (i - 1) * 10)';
    channelPx(i, : ) = dataGNSS( : , 20 + (i - 1) * 10)';
    channelPy(i, : ) = dataGNSS( : , 21 + (i - 1) * 10)';
    channelPz(i, : ) = dataGNSS( : , 22 + (i - 1) * 10)';
    channelVx(i, : ) = dataGNSS( : , 23 + (i - 1) * 10)';
    channelVy(i, : ) = dataGNSS( : , 24 + (i - 1) * 10)';
    channelVz(i, : ) = dataGNSS( : , 25 + (i - 1) * 10)';
end


pitchGNSS = zeros(1, lenGNSS);
rollGNSS = zeros(1, lenGNSS);
yawGNSS = zeros(1, lenGNSS);






%% IMU data
[lenIMU, ~] = size(dataIMU);


timeIMU = dataIMU( : , 1)'; % ms

wibbx = dataIMU( : , 8)'; % degree/s
wibby = dataIMU( : , 9)';
wibbz = dataIMU( : , 10)';

fbx = dataIMU( : , 11)'; % m/s^2
fby = dataIMU( : , 12)';
fbz = dataIMU( : , 13)';



%% Normal data
[lenNorm, ~] = size(dataNorm);

timeNorm = dataNorm( : , 1)'; % ms
timeNormPlot = (timeNorm - ones(1, lenNorm) * timeNorm(1, 1)) * 0.001; % s

lonNorm = dataNorm( : , 3)'; % degrees
laNorm = dataNorm( : , 4)'; % degrees
altNorm = dataNorm( : , 5)';

veNorm = dataNorm( : , 6)';
vnNorm = dataNorm( : , 7)';
vuNorm = dataNorm( : , 8)';

yawNorm = dataNorm( : , 9)';
pitchNorm = dataNorm( : , 10)';
rollNorm = dataNorm( : , 11)';

timeNormDiffPlot = zeros(1, lenNorm - 1);
aeNorm = zeros(1, lenNorm - 1); % m/s^2
anNorm = zeros(1, lenNorm - 1);
auNorm = zeros(1, lenNorm - 1);
avyawNorm = zeros(1, lenNorm - 1);% degrees/s
avpitchNorm = zeros(1, lenNorm - 1);
avrollNorm = zeros(1, lenNorm - 1);
for i = 1 : lenNorm - 1
    timeNormDiffPlot(1, i) = timeNormPlot(1, i);
    
    aeNorm(1, i) = (veNorm(1, i + 1) - veNorm(1, i)) / 0.01;
    anNorm(1, i) = (vnNorm(1, i + 1) - vnNorm(1, i)) / 0.01;
    auNorm(1, i) = (vuNorm(1, i + 1) - vuNorm(1, i)) / 0.01;
    
    avyawNorm(1, i) = (yawNorm(1, i + 1) - yawNorm(1, i)) / 0.01;
    avpitchNorm(1, i) = (pitchNorm(1, i + 1) - pitchNorm(1, i)) / 0.01;
    avrollNorm(1, i) = (rollNorm(1, i + 1) - rollNorm(1, i)) / 0.01;
end





%% Analysis error
disp('Analysis begin ...');

% Normal trajectory
figure('name', 'Trajectory');
plot3(lonNorm, laNorm, altNorm, ...
    'Color', 'k', ...
    'LineStyle', '-', ...
    'LineWidth', 2);
grid on;
xlabel('Longitude (degrees)');
ylabel('Latitude (degrees)');
zlabel('Altitude (m)');


% Normal velocity
%{
figure('name', 'Ve');
plot(timeNorm, veNorm, 'Color', 'k', 'LineStyle', '-', 'LineWidth', 2), grid on;
xlabel('Time/s'), ylabel('Velocity/m/s');

figure('name', 'Vn');
plot(timeNorm, vnNorm, 'Color', 'k', 'LineStyle', '-', 'LineWidth', 2), grid on;
xlabel('Time/s'), ylabel('Velocity/m/s');

figure('name', 'Vu');
plot(timeNorm, vuNorm, 'Color', 'k', 'LineStyle', '-', 'LineWidth', 2), grid on;
xlabel('Time/s'), ylabel('Velocity/m/s');
%}
figure('name', 'Velocity');
plot(timeNormPlot, veNorm, 'Color', 'k', 'LineStyle', '-', 'LineWidth', 2), hold on;
plot(timeNormPlot, vnNorm, 'Color', 'k', 'LineStyle', '--', 'LineWidth', 2), hold on;
plot(timeNormPlot, vuNorm, 'Color', 'k', 'LineStyle', ':', 'LineWidth', 4), grid on;
legend('East', 'North', 'Up');
xlabel('Time (s)'), ylabel('Velocity (m/s)');





% Normal attitude
figure('name', 'Attitude');
plot(timeNormPlot, pitchNorm, 'Color', 'k', 'LineStyle', '-', 'LineWidth', 2), hold on;
plot(timeNormPlot, rollNorm, 'Color', 'k', 'LineStyle', '--', 'LineWidth', 2), hold on;
plot(timeNormPlot, yawNorm, 'Color', 'k', 'LineStyle', ':', 'LineWidth', 4), grid on;
legend('Pitch', 'Roll', 'Yaw');
xlabel('Time (s)'), ylabel('Attitude (degrees)');




% Normal acceleration
figure('name', 'Acceleration');
plot(timeNormDiffPlot, aeNorm, 'Color', 'k', 'LineStyle', '-', 'LineWidth', 2), hold on;
plot(timeNormDiffPlot, anNorm, 'Color', 'k', 'LineStyle', '--', 'LineWidth', 2), hold on;
plot(timeNormDiffPlot, auNorm, 'Color', 'k', 'LineStyle', ':', 'LineWidth', 4), grid on;
legend('East', 'North', 'Up');
xlabel('Time (s)'), ylabel('Acceleration (m/s^2)');


% Normal attitude angular velocity
figure('name', 'Attitude Angular Velocity');
plot(timeNormDiffPlot, avpitchNorm, 'Color', 'k', 'LineStyle', '-', 'LineWidth', 2), hold on;
plot(timeNormDiffPlot, avrollNorm, 'Color', 'k', 'LineStyle', '--', 'LineWidth', 2), hold on;
plot(timeNormDiffPlot, avyawNorm, 'Color', 'k', 'LineStyle', ':', 'LineWidth', 4), grid on;
legend('Pitch', 'Roll', 'Yaw');
xlabel('Time (s)'), ylabel('Angular Velocity (m/s)');





