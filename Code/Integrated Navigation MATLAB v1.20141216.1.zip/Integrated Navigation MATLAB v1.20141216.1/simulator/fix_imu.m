SWITCH_FILE = 5;

if SWITCH_FILE == 0
    dataIMUWrong = importdata('../../Data/201401031355 (BD B3 Vn 300)/imu_wrong.txt');
    fileIMU = fopen('../../Data/201401031355 (BD B3 Vn 300)/imu.txt', 'w');
elseif SWITCH_FILE == 1
    dataIMUWrong = importdata('../../Data/201401031452 (GPS L1 Static)/imu_wrong.txt');
    fileIMU = fopen('../../Data/201401031452 (GPS L1 Static)/imu.txt', 'w');
elseif SWITCH_FILE == 2
    dataIMUWrong = importdata('../../Data/201401031508 (GPS L1 Vn 1g 300)/imu_wrong.txt');
    fileIMU = fopen('../../Data/201401031508 (GPS L1 Vn 1g 300)/imu.txt', 'w');
elseif SWITCH_FILE == 3
    dataIMUWrong = importdata('../../Data/201401031519 (GPS L1 Vn 1g 300 6g 900)/imu_wrong.txt');
    fileIMU = fopen('../../Data/201401031519 (GPS L1 Vn 1g 300 6g 900)/imu.txt', 'w');
elseif SWITCH_FILE == 4
    dataIMUWrong = importdata('../../Data/201401031548 (GPS L1 Vn 1g 300 6g 1200)/imu_wrong.txt');
    fileIMU = fopen('../../Data/201401031548 (GPS L1 Vn 1g 300 6g 1200)/imu.txt', 'w');
elseif SWITCH_FILE == 5
    dataIMUWrong = importdata('../../Data/201401031607 (GPS L1 Vn 1g 300 4g 900)/imu_wrong.txt');
    fileIMU = fopen('../../Data/201401031607 (GPS L1 Vn 1g 300 4g 900)/imu.txt', 'w');
end

[lenIMUWrong, ~] = size(dataIMUWrong);
timeIMUWrong = dataIMUWrong( : , 1)';
wibbx = dataIMUWrong( : , 2)';
wibby = dataIMUWrong( : , 3)';
wibbz = dataIMUWrong( : , 4)';
fbx = dataIMUWrong( : , 5)';
fby = dataIMUWrong( : , 6)';
fbz = dataIMUWrong( : , 7)';


lenIMU = 0;
for i = 1 : lenIMUWrong - 1
    if timeIMUWrong(i) ~= timeIMUWrong(i + 1);
        lenIMU = lenIMU + 1;
        
        fprintf(fileIMU, '%f\t', timeIMUWrong(i));
        fprintf(fileIMU, '%e\t', wibbx(i)); % rad/s
        fprintf(fileIMU, '%e\t', wibby(i));
        fprintf(fileIMU, '%e\t', wibbz(i));
        fprintf(fileIMU, '%e\t', fbx(i)); % m/s^2
        fprintf(fileIMU, '%e\t', fby(i));
        fprintf(fileIMU, '%e\t', fbz(i));
        fprintf(fileIMU, '\r\n');
    end
end

fclose(fileIMU);

disp(['lenIMUWrong = ', num2str(lenIMUWrong)]);
disp(['lenIMU = ', num2str(lenIMU)]);
msgbox('End of Generation.');

