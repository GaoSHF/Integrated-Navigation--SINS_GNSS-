close all;
clear all;

RECEIVER_CHANNEL = 10;

IMU_OUTPUT_FREQUENCY = 100;
GPS_OUTPUT_FREQUENCY = 20;

wie = 7.292115147e-5;
Re = 6378137;
e = (1 / 298.257223563);
g0 = 9.7803267714; % m/s^2
gk1 = 0.00193185138639;
gk2 = 0.00669437999013;

unit_degree2rad = (pi / 180); % degrees to rad
unit_w = (pi / 3600 / 180); % degrees/h to rad/s


dataTempIMU = importdata('../../../../Integrated Navigation Data/201306010101 (GPS Real Static)/IMU.dat');
dataTempGNSS = importdata('../../../../Integrated Navigation Data/201306010101 (GPS Real Static)/GPS.dat');

fileNavGNSS = fopen('../../../../Integrated Navigation Data/201306010101 (GPS Real Static)/nav_gnss.dat', 'w');
fileNavNormal = fopen('../../../../Integrated Navigation Data/201306010101 (GPS Real Static)/nav_normal.dat', 'w');
fileBoth = fopen('../../../../Integrated Navigation Data/201306010101 (GPS Real Static)/both.dat', 'w');


disp('Data load over');
disp('Recording new files begin ...');






%% IMU data need to record
lenIMU = length(dataTempIMU);

timeIMU = dataTempIMU( : , 2)';

wibbx = dataTempIMU( : , 3)';
wibby = dataTempIMU( : , 4)';
wibbz = dataTempIMU( : , 5)';
fbx = dataTempIMU( : , 6)';
fby = dataTempIMU( : , 7)';
fbz = dataTempIMU( : , 8)';


%% GPS data need to record
[lenGNSS, ~] = size(dataTempGNSS);

timePPS = zeros(1, lenGNSS);
timeGNSS = dataTempGNSS( : , 2)';
RcvTime = zeros(1, lenGNSS);
fixQuality = ones(1, lenGNSS) * 3;
svNumber = zeros(1, lenGNSS);

laGNSS = dataTempGNSS( : , 3)';
lonGNSS = dataTempGNSS( : , 4)';
altGNSS = dataTempGNSS( : , 5)';
PDOP = zeros(1, lenGNSS);
pGNSS = zeros(3, lenGNSS);
vGNSS = zeros(3, lenGNSS);
veGNSS = dataTempGNSS( : , 6)';
vnGNSS = dataTempGNSS( : , 7)';
vuGNSS = dataTempGNSS( : , 8)';

channelNo = zeros(lenGNSS, 10)';
channelSNR = zeros(lenGNSS, 10)';
channelPseu = zeros(lenGNSS, 10)';
channelPseuRate = zeros(lenGNSS, 10)';
channelPx = zeros(lenGNSS, 10)';
channelPy = zeros(lenGNSS, 10)';
channelPz = zeros(lenGNSS, 10)';
channelVx = zeros(lenGNSS, 10)';
channelVy = zeros(lenGNSS, 10)';
channelVz = zeros(lenGNSS, 10)';




%% Sync data
flagSync = 0;
indexGNSS = 1;
channelNoFile = zeros(10, 1);
channelSnrFile = zeros(10, 1);
channelPseuFile = zeros(10, 1);
channelPseuRateFile = zeros(10, 1);
channelPxFile = zeros(10, 1);
channelPyFile = zeros(10, 1);
channelPzFile = zeros(10, 1);
channelVxFile = zeros(10, 1);
channelVyFile = zeros(10, 1);
channelVzFile = zeros(10, 1);
%for i = 1 : lenIMU - 1
for i = 1 : IMU_OUTPUT_FREQUENCY * 300
    if indexGNSS <= lenGNSS
        if timeGNSS(indexGNSS) == timeIMU(i)
            flagSync = 1;
        else
            flagSync = 0;
        end
    end
    
    
    % Record GNSS data
    if flagSync == 1
        fixQualityFile = fixQuality(indexGNSS);
        svNumberFile = svNumber(indexGNSS);
        
        timeFile = timeGNSS(indexGNSS);
        
        laFile = laGNSS(indexGNSS);
        lonFile = lonGNSS(indexGNSS);
        altFile = altGNSS(indexGNSS);
        
        pxFile = pGNSS(1, indexGNSS);
        pyFile = pGNSS(2, indexGNSS);
        pzFile = pGNSS(3, indexGNSS);
        
        vxFile = vGNSS(1, indexGNSS);
        vyFile = vGNSS(2, indexGNSS);
        vzFile = vGNSS(3, indexGNSS);
        
        for j = 1 : RECEIVER_CHANNEL
            channelNoFile(j, 1) = channelNo(j, indexGNSS);
            channelSnrFile(j, 1) = channelSNR(j, indexGNSS);
            channelPseuFile(j, 1) = channelPseu(j, indexGNSS);
            channelPseuRateFile(j, 1) = channelPseuRate(j, indexGNSS);
            channelPxFile(j, 1) = channelPx(j, indexGNSS);
            channelPyFile(j, 1) = channelPy(j, indexGNSS);
            channelPzFile(j, 1) = channelPz(j, indexGNSS);
            channelVxFile(j, 1) = channelVx(j, indexGNSS);
            channelVyFile(j, 1) = channelVy(j, indexGNSS);
            channelVzFile(j, 1) = channelVz(j, indexGNSS);
        end
        %{
        % Transfer GNSS velocity from E-N-U to X-Y-Z
        Cte = [cos(pi / 2 + lonFile),       -cos(pi / 2 - laFile) * sin(pi / 2 + lonFile),      sin(pi / 2 - laFile) * sin(pi / 2 + lonFile);
                sin(pi / 2 + lonFile),      cos(pi / 2 - laFile) * cos(pi / 2 + lonFile),       -sin(pi / 2 - laFile) * cos(pi / 2 + lonFile);
                0,                          sin(pi / 2 - laFile),                               cos(pi / 2 - laFile)];
        
        vgeoGNSS = Cte' * [vxFile; vyFile; vzFile];
        %}
        vgeoGNSS = [veGNSS(indexGNSS); vnGNSS(indexGNSS); vuGNSS(indexGNSS)];
            
        % Record GNSS navigation file
        if fixQualityFile == 3
            fprintf(fileNavGNSS, '%f\t', timeFile); % ms
            fprintf(fileNavGNSS, '%.9f\t', laFile); % degrees
            fprintf(fileNavGNSS, '%.9f\t', lonFile);
            fprintf(fileNavGNSS, '%f\t', altFile);
            fprintf(fileNavGNSS, '%f\t', vgeoGNSS(1, 1));
            fprintf(fileNavGNSS, '%f\t', vgeoGNSS(2, 1));
            fprintf(fileNavGNSS, '%f\n', vgeoGNSS(3, 1));
        end
        
        indexGNSS = indexGNSS + 1;
        
    else
        fixQualityFile = 0;
        svNumberFile = 0;
        
        laFile = 0.0;
        lonFile = 0.0;
        altFile = 0.0;
        
        pxFile = 0.0;
        pyFile = 0.0;
        pzFile = 0.0;
        
        vxFile = 0.0;
        vyFile = 0.0;
        vzFile = 0.0;
        
        for j = 1 : RECEIVER_CHANNEL
            channelNoFile(j, 1) = 0;
            channelSnrFile(j, 1) = 0.0;
            channelPseuFile(j, 1) = 0.0;
            channelPseuRateFile(j, 1) = 0.0;
            channelPxFile(j, 1) = 0.0;
            channelPyFile(j, 1) = 0.0;
            channelPzFile(j, 1) = 0.0;
            channelVxFile(j, 1) = 0.0;
            channelVyFile(j, 1) = 0.0;
            channelVzFile(j, 1) = 0.0;
        end
    end % if else
    
    
    % Sync IMU data
    timeSync = timeIMU(i);
    wibbxSync = wibbx(i) * unit_w; % rad/s
    wibbySync = wibby(i) * unit_w;
    wibbzSync = wibbz(i) * unit_w;
    fbxSync = fbx(i) * g0; % m/s^2
    fbySync = fby(i) * g0;
    fbzSync = fbz(i) * g0;
    
    
    % Record both IMU and GNSS data
    fprintf(fileBoth, '%f\t', timeSync);
    fprintf(fileBoth, '%e\t', wibbxSync); % rad/s
    fprintf(fileBoth, '%e\t', wibbySync);
    fprintf(fileBoth, '%e\t', wibbzSync);
    fprintf(fileBoth, '%e\t', fbxSync); % m/s^2
    fprintf(fileBoth, '%e\t', fbySync);
    fprintf(fileBoth, '%e\t', fbzSync);
    fprintf(fileBoth, '%d\t', fixQualityFile);
    fprintf(fileBoth, '%d\t', svNumberFile);
    fprintf(fileBoth, '%f\t', laFile * unit_degree2rad); % rad
    fprintf(fileBoth, '%f\t', lonFile * unit_degree2rad);
    fprintf(fileBoth, '%f\t', altFile);
    fprintf(fileBoth, '%f\t', pxFile);
    fprintf(fileBoth, '%f\t', pyFile);
    fprintf(fileBoth, '%f\t', pzFile);
    fprintf(fileBoth, '%f\t', vxFile);
    fprintf(fileBoth, '%f\t', vyFile);
    fprintf(fileBoth, '%f\t', vzFile);
    for j = 1 : RECEIVER_CHANNEL
        fprintf(fileBoth, '%d\t', channelNoFile(j, 1));
        fprintf(fileBoth, '%d\t', channelSnrFile(j, 1));
        fprintf(fileBoth, '%e\t', channelPseuFile(j, 1));
        fprintf(fileBoth, '%e\t', channelPseuRateFile(j, 1));
        fprintf(fileBoth, '%e\t', channelPxFile(j, 1));
        fprintf(fileBoth, '%e\t', channelPyFile(j, 1));
        fprintf(fileBoth, '%e\t', channelPzFile(j, 1));
        fprintf(fileBoth, '%e\t', channelVxFile(j, 1));
        fprintf(fileBoth, '%e\t', channelVyFile(j, 1));
        fprintf(fileBoth, '%e\t', channelVzFile(j, 1));
    end
    fprintf(fileBoth, '\n');
    
    
    
    % Record normal navigation file
    fprintf(fileNavNormal, '%f\t', timeSync);
    fprintf(fileNavNormal, '%e\t', 0.25516); % rad
    fprintf(fileNavNormal, '%e\t', 1.76037);
    fprintf(fileNavNormal, '%e\t', 303.10881);
    fprintf(fileNavNormal, '%e\t', 0);
    fprintf(fileNavNormal, '%e\t', 0);
    fprintf(fileNavNormal, '%e\t', 0);
    fprintf(fileNavNormal, '%f\t', 34.652160625000000); % degrees
    fprintf(fileNavNormal, '%f\t', 109.2496237170000);
    fprintf(fileNavNormal, '%f\n', 362.2690000000000);
    
end

fclose(fileNavNormal);
fclose(fileNavGNSS);
fclose(fileBoth);


msgbox('End of Generation.');

