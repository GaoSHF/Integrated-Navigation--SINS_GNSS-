
close all;
clear all;

RECEIVER_CHANNEL = 10;

GNSS_RECEIVER_DELAY = 7; % s
GNSS_REVEIVER_DELAY_THRES_UP = 50; % s

IMU_OUTPUT_FREQUENCY = 100;

wie = 7.292115147e-5;
Re = 6378137;
e = (1 / 298.257223563);
g0 = 9.7803267714; % m/s^2
gk1 = 0.00193185138639;
gk2 = 0.00669437999013;

unit_degree2rad = (pi / 180); % degrees to rad

LA0 = (39 * pi / 180);
LON0 = (116 * pi / 180);
H0 = 100;

PITCH0 = 0;
ROLL0 = 0;
YAW0 = 0;

T = 1 / IMU_OUTPUT_FREQUENCY;

SWITCH_FILE = 5;

if SWITCH_FILE == 0
    dataGNSS = importdata('../../Data/201401031355 (BD B3 Vn 300)/gnss.txt');
    dataPPS = importdata('../../Data/201401031355 (BD B3 Vn 300)/pps.txt');
    
    fileGNSS429 = fopen('../../Data/201401031355 (BD B3 Vn 300)/gnss429.txt', 'w');

elseif SWITCH_FILE == 1
    dataGNSS = importdata('../../Data/201401031452 (GPS L1 Static)/gnss.txt');
    dataPPS = importdata('../../Data/201401031452 (GPS L1 Static)/pps.txt');
    
    fileGNSS429 = fopen('../../Data/201401031452 (GPS L1 Static)/gnss429.txt', 'w');

elseif SWITCH_FILE == 2
    dataGNSS = importdata('../../Data/201401031508 (GPS L1 Vn 1g 300)/gnss.txt');
    dataPPS = importdata('../../Data/201401031508 (GPS L1 Vn 1g 300)/pps.txt');
    
    fileGNSS429 = fopen('../../Data/201401031508 (GPS L1 Vn 1g 300)/gnss429.txt', 'w');

elseif SWITCH_FILE == 3
    dataGNSS = importdata('../../Data/201401031519 (GPS L1 Vn 1g 300 6g 900)/gnss.txt');
    dataPPS = importdata('../../Data/201401031519 (GPS L1 Vn 1g 300 6g 900)/pps.txt');
    
    fileGNSS429 = fopen('../../Data/201401031519 (GPS L1 Vn 1g 300 6g 900)/gnss429.txt', 'w');

elseif SWITCH_FILE == 4
    dataGNSS = importdata('../../Data/201401031548 (GPS L1 Vn 1g 300 6g 1200)/gnss.txt');
    dataPPS = importdata('../../Data/201401031548 (GPS L1 Vn 1g 300 6g 1200)/pps.txt');
    
    fileGNSS429 = fopen('../../Data/201401031548 (GPS L1 Vn 1g 300 6g 1200)/gnss429.txt', 'w');

elseif SWITCH_FILE == 5
    dataGNSS = importdata('../../Data/201401031607 (GPS L1 Vn 1g 300 4g 900)/gnss.txt');
    dataPPS = importdata('../../Data/201401031607 (GPS L1 Vn 1g 300 4g 900)/pps.txt');
    
    fileGNSS429 = fopen('../../Data/201401031607 (GPS L1 Vn 1g 300 4g 900)/gnss429.txt', 'w');

end




disp('Data loading over');
disp('Glue PPS begin');


timePPS = dataPPS( : , 1)';
[lenPPS, ~] = size(dataPPS);

[lenGNSS, ~] = size(dataGNSS);
timeGNSS = dataGNSS( : , 1)';
RcvTime = dataGNSS( : , 2)';
fixQuality = dataGNSS( : , 3)';
svNumber = dataGNSS( : , 4)';

laGNSS = dataGNSS( : , 5)';
lonGNSS = dataGNSS( : , 6)';
altGNSS = dataGNSS( : , 7)';
PDOP = dataGNSS( : , 8)';
pGNSS = dataGNSS( : , 9 : 11)';
vGNSS = dataGNSS( : , 12 : 14)';

channelNo = zeros(lenGNSS, 10)';
channelSNR = zeros(lenGNSS, 10)';
channelPseu = zeros(lenGNSS, 10)';
channelPseuRate = zeros(lenGNSS, 10)';
channelPx = zeros(lenGNSS, 10)';
channelPy = zeros(lenGNSS, 10)';
channelPz = zeros(lenGNSS, 10)';
channelVx = zeros(lenGNSS, 10)';
channelVy = zeros(lenGNSS, 10)';
channelVz = zeros(lenGNSS, 10)';
for i = 1 : RECEIVER_CHANNEL
    channelNo(i, : ) = dataGNSS( : , 15 + (i - 1) * 10)';
    channelSNR(i, : ) = dataGNSS( : , 16 + (i - 1) * 10)';
    channelPseu(i, : ) = dataGNSS( : , 17 + (i - 1) * 10)';
    channelPseuRate(i, : ) = dataGNSS( : , 18 + (i - 1) * 10)';
    channelPx(i, : ) = dataGNSS( : , 19 + (i - 1) * 10)';
    channelPy(i, : ) = dataGNSS( : , 20 + (i - 1) * 10)';
    channelPz(i, : ) = dataGNSS( : , 21 + (i - 1) * 10)';
    channelVx(i, : ) = dataGNSS( : , 22 + (i - 1) * 10)';
    channelVy(i, : ) = dataGNSS( : , 23 + (i - 1) * 10)';
    channelVz(i, : ) = dataGNSS( : , 24 + (i - 1) * 10)';
end


%% Sync PPS with GNSS
timePPSSync = zeros(1, lenGNSS);
indexPPS = 1;
for i = 1 : lenGNSS - 1
    if (timePPS(indexPPS) > timeGNSS(i)) && (timePPS(indexPPS) <= timeGNSS(i + 1)) && (indexPPS + 1 <= lenPPS)
        timePPSSync(i + 1) = timePPS(indexPPS);
        indexPPS = indexPPS + 1;
    elseif timePPS(indexPPS) < timeGNSS(i)
        while (indexPPS + 1 <= lenPPS)
            indexPPS = indexPPS + 1;
            if (timePPS(indexPPS) >= timeGNSS(i))
                break;
            end
        end
    end
end



%% Record fixed data
for i = 1 : lenGNSS
    fprintf(fileGNSS429, '%f\t', timePPSSync(i));
    fprintf(fileGNSS429, '%f\t', timeGNSS(i));
    fprintf(fileGNSS429, '%f\t', RcvTime(i));
    fprintf(fileGNSS429, '%d\t', fixQuality(i));
    fprintf(fileGNSS429, '%d\t', svNumber(i));
    
    fprintf(fileGNSS429, '%f\t', laGNSS(i));
    fprintf(fileGNSS429, '%f\t', lonGNSS(i));
    fprintf(fileGNSS429, '%f\t', altGNSS(i));
    fprintf(fileGNSS429, '%f\t', PDOP(i));
    for j = 1 : 3
        fprintf(fileGNSS429, '%f\t', pGNSS(j, i));
    end
    for j = 1 : 3
        fprintf(fileGNSS429, '%f\t', vGNSS(j, i));
    end
    
    for j = 1 : RECEIVER_CHANNEL
        fprintf(fileGNSS429, '%d\t', channelNo(j, i));
        fprintf(fileGNSS429, '%f\t', channelSNR(j, i));
        fprintf(fileGNSS429, '%f\t', channelPseu(j, i));
        fprintf(fileGNSS429, '%f\t', channelPseuRate(j, i));
        fprintf(fileGNSS429, '%f\t', channelPx(j, i));
        fprintf(fileGNSS429, '%f\t', channelPy(j, i));
        fprintf(fileGNSS429, '%f\t', channelPz(j, i));
        fprintf(fileGNSS429, '%f\t', channelVx(j, i));
        fprintf(fileGNSS429, '%f\t', channelVy(j, i));
        fprintf(fileGNSS429, '%f\t', channelVz(j, i));
    end
    
    fprintf(fileGNSS429, '\r\n');
end

fclose(fileGNSS429);


msgbox('End');

