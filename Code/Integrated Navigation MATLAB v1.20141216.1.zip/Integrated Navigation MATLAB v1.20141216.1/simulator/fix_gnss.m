Re = 6378137e0;
e = (1 / 298.257223563);
unit_rad2degree = (180 / pi);

% Maximum channel number
RECEIVER_CHANNEL = 10;


%% Import GNSS data
SWITCH_FILE = 5;

if SWITCH_FILE == 0
    data_gnss_wrong = importdata('../Data/201401031452 (GPS L1 Static)/gnss_wrong.txt');
    file_gnss_wrong = fopen('../Data/201401031452 (GPS L1 Static)/gnss.txt', 'w');
elseif SWITCH_FILE == 1
    data_gnss_wrong = importdata('../Data/201401031508 (GPS L1 Vn 1g 300)/gnss_wrong.txt');
    file_gnss_wrong = fopen('../Data/201401031508 (GPS L1 Vn 1g 300)/gnss.txt', 'w');
elseif SWITCH_FILE == 2
    data_gnss_wrong = importdata('../Data/201401031519 (GPS L1 Vn 1g 300 6g 900)/gnss_wrong.txt');
    file_gnss_wrong = fopen('../Data/201401031519 (GPS L1 Vn 1g 300 6g 900)/gnss.txt', 'w');
elseif SWITCH_FILE == 3
    data_gnss_wrong = importdata('../Data/201401031548 (GPS L1 Vn 1g 300 6g 1200)/gnss_wrong.txt');
    file_gnss_wrong = fopen('../Data/201401031548 (GPS L1 Vn 1g 300 6g 1200)/gnss.txt', 'w');
elseif SWITCH_FILE == 4
    data_gnss_wrong = importdata('../Data/201401031607 (GPS L1 Vn 1g 300 4g 900)/gnss_wrong.txt');
    file_gnss_wrong = fopen('../Data/201401031607 (GPS L1 Vn 1g 300 4g 900)/gnss.txt', 'w');
elseif SWITCH_FILE == 5
    data_gnss_wrong = importdata('../Data/201401031355 (BD B3 Vn 300)/gnss_wrong.txt');
    file_gnss_wrong = fopen('../Data/201401031355 (BD B3 Vn 300)/gnss.txt', 'w');
end



time = data_gnss_wrong( : , 1)';
RcvTime = data_gnss_wrong( : , 2)';
fixQuality = data_gnss_wrong( : , 3)';
svNumber = data_gnss_wrong( : , 4)';

la_gps = data_gnss_wrong( : , 5)';
lon_gps = data_gnss_wrong( : , 6)';
h_gps = data_gnss_wrong( : , 7)';
PDOP = data_gnss_wrong( : , 8)';
pos_gps = data_gnss_wrong( : , 9 : 11)';
v_gps = data_gnss_wrong( : , 12 : 14)';

channelNo = zeros(length(svNumber), 10)';
channelSNR = zeros(length(svNumber), 10)';
channelPseu = zeros(length(svNumber), 10)';
channelPseuRate = zeros(length(svNumber), 10)';
channelPx = zeros(length(svNumber), 10)';
channelPy = zeros(length(svNumber), 10)';
channelPz = zeros(length(svNumber), 10)';
channelVx = zeros(length(svNumber), 10)';
channelVy = zeros(length(svNumber), 10)';
channelVz = zeros(length(svNumber), 10)';
for i = 1 : RECEIVER_CHANNEL
    channelNo(i, : ) = data_gnss_wrong( : , 15 + (i - 1) * 10)';
    channelSNR(i, : ) = data_gnss_wrong( : , 16 + (i - 1) * 10)';
    channelPseu(i, : ) = data_gnss_wrong( : , 17 + (i - 1) * 10)';
    channelPseuRate(i, : ) = data_gnss_wrong( : , 18 + (i - 1) * 10)';
    channelPx(i, : ) = data_gnss_wrong( : , 19 + (i - 1) * 10)';
    channelPy(i, : ) = data_gnss_wrong( : , 20 + (i - 1) * 10)';
    channelPz(i, : ) = data_gnss_wrong( : , 21 + (i - 1) * 10)';
    channelVx(i, : ) = data_gnss_wrong( : , 22 + (i - 1) * 10)';
    channelVy(i, : ) = data_gnss_wrong( : , 23 + (i - 1) * 10)';
    channelVz(i, : ) = data_gnss_wrong( : , 24 + (i - 1) * 10)';
end

%% Fix GNSS data
temp = size(pos_gps);
for i = 1 : temp(1, 2)
    la = la_gps(i) / unit_rad2degree;
    lon = lon_gps(i) / unit_rad2degree;
    h = h_gps(i);
    ex2 = (2 - e) * e / ((1 - e) * (1 - e));
    N = Re * sqrt(1 + ex2) / sqrt(1 + ex2 * cos(la) * cos(la));
	pos_gps(1, i) = (N + h) * cos(la) * cos(lon);
end

for i = 1 : RECEIVER_CHANNEL
    channelNo(i, : ) = channelNo(i, : ) / 2;
    
    channelPseu(i, : ) = channelPseu(i, : ) * 2;
    
    channelPx(i, : ) = channelPx(i, : ) * 2;
    channelPy(i, : ) = channelPy(i, : ) * 2;
    channelPz(i, : ) = channelPz(i, : ) * 2;
end


%% Record fixed data
for i = 1 : temp(1, 2)
    fprintf(file_gnss_wrong, '%f\t', time(i));
    fprintf(file_gnss_wrong, '%f\t', RcvTime(i));
    fprintf(file_gnss_wrong, '%d\t', fixQuality(i));
    fprintf(file_gnss_wrong, '%d\t', svNumber(i));
    
    fprintf(file_gnss_wrong, '%f\t', la_gps(i));
    fprintf(file_gnss_wrong, '%f\t', lon_gps(i));
    fprintf(file_gnss_wrong, '%f\t', h_gps(i));
    fprintf(file_gnss_wrong, '%f\t', PDOP(i));
    for j = 1 : 3
        fprintf(file_gnss_wrong, '%f\t', pos_gps(j, i));
    end
    for j = 1 : 3
        fprintf(file_gnss_wrong, '%f\t', v_gps(j, i));
    end
    
    for j = 1 : RECEIVER_CHANNEL
        fprintf(file_gnss_wrong, '%d\t', channelNo(j, i));
        fprintf(file_gnss_wrong, '%f\t', channelSNR(j, i));
        fprintf(file_gnss_wrong, '%f\t', channelPseu(j, i));
        fprintf(file_gnss_wrong, '%f\t', channelPseuRate(j, i));
        fprintf(file_gnss_wrong, '%f\t', channelPx(j, i));
        fprintf(file_gnss_wrong, '%f\t', channelPy(j, i));
        fprintf(file_gnss_wrong, '%f\t', channelPz(j, i));
        fprintf(file_gnss_wrong, '%f\t', channelVx(j, i));
        fprintf(file_gnss_wrong, '%f\t', channelVy(j, i));
        fprintf(file_gnss_wrong, '%f\t', channelVz(j, i));
    end
    
    fprintf(file_gnss_wrong, '\r\n');
end


%% Close file
fclose(file_gnss_wrong);
msgbox('Finished.');
