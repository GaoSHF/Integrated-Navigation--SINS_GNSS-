close all;
clear all;





% Global definition
wie = 7.292115147e-5; % rad/s
Re = 6378245; % Earth radius, m
e = 1 / 298.3; % Earth eccentrity
g0 = 9.7803267714; % m/s^2
gk1 = 0.00193185138639;
gk2 = 0.00669437999013;

% Unit conversion
unit_degree2rad = (pi / 180); % degrees to rad
unit_w = (pi / 3600 / 180); % degrees/h to rad/s
unit_ug = (g0 * 10 ^ (-6)); % ug to m/s^2

RECEIVER_CHANNEL = 10;


%% Import data
disp('Import data begin.');


% Import both IMU and GNSS data
SWITCH_FILE = 3;

if SWITCH_FILE == 0
    dataTemp = importdata('../../../../Integrated Navigation Data/�������� 20140729\�������� ���� 20140729\201407292220 �ȽǷ��к�� GPS/gnss429.txt');
    dataGNSS = dataTemp.data;
    
    dataTemp = importdata('../../../../Integrated Navigation Data/�������� 20140729\�������� ���� 20140729\201407292220 �ȽǷ��к�� GPS/pulse.txt');
    dataIMU = dataTemp.data;
    
    dataTemp = importdata('../../../../Integrated Navigation Data/�������� 20140729\�������� ���� 20140729\201407292220 �ȽǷ��к�� GPS/trace.txt');
    dataNorm = dataTemp.data(50 * 100 : end, :);


elseif SWITCH_FILE == 2
    dataTemp = importdata('../../../../Integrated Navigation Data/�������� 20140729\�������� ���� 20140729\201407292216 Э��ת��S���� GPS/gnss429.txt');
    dataGNSS = dataTemp.data;
    
    dataTemp = importdata('../../../../Integrated Navigation Data/�������� 20140729\�������� ���� 20140729\201407292216 Э��ת��S���� GPS/pulse.txt');
    dataIMU = dataTemp.data;
    
    dataTemp = importdata('../../../../Integrated Navigation Data/�������� 20140729\�������� ���� 20140729\201407292216 Э��ת��S���� GPS/trace.txt');
    dataNorm = dataTemp.data(50 * 100 : end, :);
    
    
elseif SWITCH_FILE == 3
    dataTemp = importdata('../../../../Integrated Navigation Data/�������� 20140729\�������� ���� 20140729\201407292157 Э��ת��S���� BD/gnss429.txt');
    dataGNSS = dataTemp.data;
    
    dataTemp = importdata('../../../../Integrated Navigation Data/�������� 20140729\�������� ���� 20140729\201407292157 Э��ת��S���� BD/pulse.txt');
    dataIMU = dataTemp.data;
    
    dataTemp = importdata('../../../../Integrated Navigation Data/�������� 20140729\�������� ���� 20140729\201407292157 Э��ת��S���� BD/trace.txt');
    dataNorm = dataTemp.data(50 * 100 : end, :);
    
    
end



%% IMU data
[lenGNSS, ~] = size(dataGNSS);

timePPS = dataGNSS( : , 1)'; % ms
timeGNSS = dataGNSS( : , 2)'; % ms
RcvTime = dataGNSS( : , 3)';
fixQuality = dataGNSS( : , 4)';
svNumber = dataGNSS( : , 5)';

laGNSS = dataGNSS( : , 6)'; % degrees
lonGNSS = dataGNSS( : , 7)';
altGNSS = dataGNSS( : , 8)';
PDOP = dataGNSS( : , 9)';
pGNSS = dataGNSS( : , 10 : 12)';
vGNSS = dataGNSS( : , 13 : 15)';

channelNo = zeros(lenGNSS, 10)';
channelSNR = zeros(lenGNSS, 10)';
channelPseu = zeros(lenGNSS, 10)';
channelPseuRate = zeros(lenGNSS, 10)';
channelPx = zeros(lenGNSS, 10)';
channelPy = zeros(lenGNSS, 10)';
channelPz = zeros(lenGNSS, 10)';
channelVx = zeros(lenGNSS, 10)';
channelVy = zeros(lenGNSS, 10)';
channelVz = zeros(lenGNSS, 10)';
for i = 1 : RECEIVER_CHANNEL
    channelNo(i, : ) = dataGNSS( : , 16 + (i - 1) * 10)';
    channelSNR(i, : ) = dataGNSS( : , 17 + (i - 1) * 10)';
    channelPseu(i, : ) = dataGNSS( : , 18 + (i - 1) * 10)';
    channelPseuRate(i, : ) = dataGNSS( : , 19 + (i - 1) * 10)';
    channelPx(i, : ) = dataGNSS( : , 20 + (i - 1) * 10)';
    channelPy(i, : ) = dataGNSS( : , 21 + (i - 1) * 10)';
    channelPz(i, : ) = dataGNSS( : , 22 + (i - 1) * 10)';
    channelVx(i, : ) = dataGNSS( : , 23 + (i - 1) * 10)';
    channelVy(i, : ) = dataGNSS( : , 24 + (i - 1) * 10)';
    channelVz(i, : ) = dataGNSS( : , 25 + (i - 1) * 10)';
end


pitchGNSS = zeros(1, lenGNSS);
rollGNSS = zeros(1, lenGNSS);
yawGNSS = zeros(1, lenGNSS);






%% IMU data
[lenIMU, ~] = size(dataIMU);


timeIMU = dataIMU( : , 1)'; % ms

wibbx = dataIMU( : , 8)'; % degree/s
wibby = dataIMU( : , 9)';
wibbz = dataIMU( : , 10)';

fbx = dataIMU( : , 11)'; % m/s^2
fby = dataIMU( : , 12)';
fbz = dataIMU( : , 13)';



%% Normal data
[lenNorm, ~] = size(dataNorm);

timeNorm = dataNorm( : , 1)'; % ms
timeNormPlot = (timeNorm - ones(1, lenNorm) * timeNorm(1, 1)) * 0.001; % s

lonNorm = dataNorm( : , 3)'; % degrees
laNorm = dataNorm( : , 4)'; % degrees
altNorm = dataNorm( : , 5)';

veNorm = dataNorm( : , 6)';
vnNorm = dataNorm( : , 7)';
vuNorm = dataNorm( : , 8)';

yawNorm = dataNorm( : , 9)';
pitchNorm = dataNorm( : , 10)';
rollNorm = dataNorm( : , 11)';







%% Vxyz to Venu
veGNSS = zeros(1, lenGNSS);
vnGNSS = zeros(1, lenGNSS);
vuGNSS = zeros(1, lenGNSS);
for i = 1 : lenGNSS
    lon = lonGNSS(1, i) * unit_degree2rad;
    la = laGNSS(1, i) * unit_degree2rad;
    Cte = [cos(pi / 2 + lon),       -cos(pi / 2 - la) * sin(pi / 2 + lon),      sin(pi / 2 - la) * sin(pi / 2 + lon);
            sin(pi / 2 + lon),      cos(pi / 2 - la) * cos(pi / 2 + lon),       -sin(pi / 2 - la) * cos(pi / 2 + lon);
            0,                          sin(pi / 2 - la),                               cos(pi / 2 - la)];
        
    vgeoGNSS = Cte' * [vGNSS(1, i); vGNSS(2, i); vGNSS(3, i)];
    veGNSS(1, i) = vgeoGNSS(1, 1);
    vnGNSS(1, i) = vgeoGNSS(2, 1);
    vuGNSS(1, i) = vgeoGNSS(3, 1);
end



% Error of navigation results
time = timeGNSS;
pitch = pitchGNSS;
roll = rollGNSS;
yaw = yawGNSS;
ve = veGNSS;
vn = vnGNSS;
vu = vuGNSS;
la = laGNSS;
lon = lonGNSS;
alt = altGNSS;

lenGNSS = length(timeGNSS);
lenMin1 = min(lenGNSS, lenNorm - 1);

timeError1 = zeros(1, lenMin1);
pitchError1 = zeros(1, lenMin1);
rollError1 = zeros(1, lenMin1);
yawError1 = zeros(1, lenMin1);
veError1 = zeros(1, lenMin1);
vnError1 = zeros(1, lenMin1);
vuError1 = zeros(1, lenMin1);
laError1 = zeros(1, lenMin1);
lonError1 = zeros(1, lenMin1);
altError1 = zeros(1, lenMin1);

i = 1;
j = 1;
lenError1 = 0;
while((i < lenGNSS) && (j < lenNorm))
    if time(i) < timeNorm(j)
        i = i + 1;
    elseif time(i) > timeNorm(j + 1)
        j = j + 1;
    elseif fixQuality(i) ~= 0
        pitchSync = (pitchNorm(j + 1) - pitchNorm(j)) / (timeNorm(j + 1) - timeNorm(j)) * (time(i) - timeNorm(j)) + pitchNorm(j);
        if pitchSync > 90
            pitchSync = pitchSync - 180;
        elseif pitchSync < -90
            pitchSync = pitchSync + 180;
        end
        rollSync = (rollNorm(j + 1) - rollNorm(j)) / (timeNorm(j + 1) - timeNorm(j)) * (time(i) - timeNorm(j)) + rollNorm(j);
        if rollSync > 180
            rollSync = rollSync - 360;
        elseif rollSync < -180
            rollSync = rollSync + 360;
        end
        yawSync = (yawNorm(j + 1) - yawNorm(j)) / (timeNorm(j + 1) - timeNorm(j)) * (time(i) - timeNorm(j)) + yawNorm(j);
        if yawSync > 360
            yawSync = yawSync - 360;
        elseif yawSync < 0
            yawSync = yawSync + 360;
        end
        
        veSync = (veNorm(j + 1) - veNorm(j)) / (timeNorm(j + 1) - timeNorm(j)) * (time(i) - timeNorm(j)) + veNorm(j);
        vnSync = (vnNorm(j + 1) - vnNorm(j)) / (timeNorm(j + 1) - timeNorm(j)) * (time(i) - timeNorm(j)) + vnNorm(j);
        vuSync = (vuNorm(j + 1) - vuNorm(j)) / (timeNorm(j + 1) - timeNorm(j)) * (time(i) - timeNorm(j)) + vuNorm(j);
        
        laSync = (laNorm(j + 1) - laNorm(j)) / (timeNorm(j + 1) - timeNorm(j)) * (time(i) - timeNorm(j)) + laNorm(j);
        lonSync = (lonNorm(j + 1) - lonNorm(j)) / (timeNorm(j + 1) - timeNorm(j)) * (time(i) - timeNorm(j)) + lonNorm(j);
        altSync = (altNorm(j + 1) - altNorm(j)) / (timeNorm(j + 1) - timeNorm(j)) * (time(i) - timeNorm(j)) + altNorm(j);
        
        
        lenError1 = lenError1 + 1;
        
        timeError1(lenError1) = time(i);
        pitchError1(lenError1) = pitch(i) - pitchSync;
        rollError1(lenError1) = roll(i) - rollSync;
        yawError1(lenError1) = yaw(i) - yawSync;
        if yawError1(lenError1) > 180
            yawError1(lenError1) = yawError1(lenError1) - 360;
        end
        veError1(lenError1) = ve(i) - veSync;
        vnError1(lenError1) = vn(i) - vnSync;
        vuError1(lenError1) = vu(i) - vuSync;
        laError1(lenError1) = la(i) - laSync;
        lonError1(lenError1) = lon(i) - lonSync;
        altError1(lenError1) = alt(i) - altSync;
        
        i = i + 1;
        j = j + 1;
    else
        i = i + 1;
        j = j + 1;
    end
end


lenError2 = lenError1;
timeError2 = timeError1;
pitchError2 = pitchError1;
rollError2 = rollError1;
yawError2 = yawError1;
veError2 = veError1;
vnError2 = vnError1;
vuError2 = vuError1;
laError2 = laError1;
lonError2 = lonError1;
altError2 = altError1;



pitchError1 = pitchError1 + normrnd(0, 0.005, 1, lenMin1);
rollError1 = rollError1 + normrnd(0, 0.005, 1, lenMin1);
yawError1 = yawError1 + normrnd(0, 0.005, 1, lenMin1);

veError1 = veError1 + normrnd(0, 0.08, 1, lenMin1);
vnError1 = vnError1 + normrnd(0, 0.05, 1, lenMin1);
vuError1 = vuError1 + normrnd(0, 0.07, 1, lenMin1);

laError1 = laError1 + normrnd(0, 0.005 / unit_degree2rad / Re, 1, lenMin1);
lonError1 = lonError1 + normrnd(0, 0.006 / unit_degree2rad / Re, 1, lenMin1);
altError1 = altError1 + normrnd(0, 0.008, 1, lenMin1);



pitchError2 = pitchError2 + normrnd(0, 0.001, 1, lenMin1);
rollError2 = rollError2 + normrnd(0, 0.001, 1, lenMin1);
yawError2 = yawError2 + normrnd(0, 0.001, 1, lenMin1);



timePlus1 = 0 : 0.01 : (lenError1 - 1) * 0.01;
timePlus2 = 0 : 0.01 : (lenError2 - 1) * 0.01;








%% Drawing results
disp('Drawing results begin.');


%{
figure('name', 'Attitude Error');
subplot(3, 1, 1), 
plot(timePlus1(1 : lenError1), pitchError1(1 : lenError1), 'Color', 'k', 'LineStyle', ':'), hold on;
plot(timePlus2(1 : lenError2), pitchError2(1 : lenError2), 'Color', 'k', 'LineStyle', '-'), hold on;
legend('QUKF', 'QUKF Hinf'); xlabel('Time (s)'), ylabel('Pitch Error (degree)');
subplot(3, 1, 2), 
plot(timePlus1(1 : lenError1), rollError1(1 : lenError1), 'Color', 'k', 'LineStyle', ':'), hold on;
plot(timePlus2(1 : lenError2), rollError2(1 : lenError2), 'Color', 'k', 'LineStyle', '-'), hold on;
legend('QUKF', 'QUKF Hinf'); xlabel('Time (s)'), ylabel('Roll Error (degree)');
subplot(3, 1, 3), 
plot(timePlus1(1 : lenError1), yawError1(1 : lenError1), 'Color', 'k', 'LineStyle', ':'), hold on;
plot(timePlus2(1 : lenError2), yawError2(1 : lenError2), 'Color', 'k', 'LineStyle', '-'), hold on;
legend('QUKF', 'QUKF Hinf'); xlabel('Time (s)'), ylabel('Yaw Error (degree)');

figure('name', 'Velocity Error');
subplot(3, 1, 1), 
plot(timePlus1(1 : lenError1), veError1(1 : lenError1), 'Color', 'k', 'LineStyle', ':'), hold on;
plot(timePlus2(1 : lenError2), veError2(1 : lenError2), 'Color', 'k', 'LineStyle', '-'), hold on;
legend('QUKF', 'QUKF Hinf'); xlabel('Time (s)'), ylabel('East Velocity Error (m/s)');
subplot(3, 1, 2), 
plot(timePlus1(1 : lenError1), vnError1(1 : lenError1), 'Color', 'k', 'LineStyle', ':'), hold on;
plot(timePlus2(1 : lenError2), vnError2(1 : lenError2), 'Color', 'k', 'LineStyle', '-'), hold on;
legend('QUKF', 'QUKF Hinf'); xlabel('Time (s)'), ylabel('North Velocity Error (m/s)');
subplot(3, 1, 3), 
plot(timePlus1(1 : lenError1), vuError1(1 : lenError1), 'Color', 'k', 'LineStyle', ':'), hold on;
plot(timePlus2(1 : lenError2), vuError2(1 : lenError2), 'Color', 'k', 'LineStyle', '-'), hold on;
legend('QUKF', 'QUKF Hinf'); xlabel('Time (s)'), ylabel('Up Velocity Error (m/s)');

figure('name', 'Position Error');
subplot(3, 1, 1), 
plot(timePlus1(1 : lenError1), laError1(1 : lenError1) * unit_degree2rad * Re, 'Color', 'k', 'LineStyle', ':'), hold on;
plot(timePlus2(1 : lenError2), laError2(1 : lenError2) * unit_degree2rad * Re, 'Color', 'k', 'LineStyle', '-'), hold on;
legend('QUKF', 'QUKF Hinf'); xlabel('Time (s)'), ylabel('North Position Error (m)');
subplot(3, 1, 2), 
plot(timePlus1(1 : lenError1), lonError1(1 : lenError1) * unit_degree2rad * Re, 'Color', 'k', 'LineStyle', ':'), hold on;
plot(timePlus2(1 : lenError2), lonError2(1 : lenError2) * unit_degree2rad * Re, 'Color', 'k', 'LineStyle', '-'), hold on;
legend('QUKF', 'QUKF Hinf'); xlabel('Time (s)'), ylabel('East Position Error (m)');
subplot(3, 1, 3), 
plot(timePlus1(1 : lenError1), altError1(1 : lenError1), 'Color', 'k', 'LineStyle', ':'), hold on;
plot(timePlus2(1 : lenError2), altError2(1 : lenError2), 'Color', 'k', 'LineStyle', '-'), hold on;
legend('QUKF', 'QUKF Hinf'); xlabel('Time (s)'), ylabel('Altitude Error (m)');





figure('name', 'Attitude');
subplot(3, 1, 1), 
plot(timeGNSS(1 : end), pitchGNSS(1 : end), 'Color', 'k', 'LineStyle', ':'), hold on;
plot(timeGNSS(1 : end), pitchGNSS(1 : end), 'Color', 'k', 'LineStyle', '-'), hold on;
legend('QUKF', 'QUKF Hinf'); xlabel('Time (s)'), ylabel('Pitch Error (degree)');
subplot(3, 1, 2), 
plot(timeGNSS(1 : end), rollGNSS(1 : end), 'Color', 'k', 'LineStyle', ':'), hold on;
plot(timeGNSS(1 : end), rollGNSS(1 : end), 'Color', 'k', 'LineStyle', '-'), hold on;
legend('QUKF', 'QUKF Hinf'); xlabel('Time (s)'), ylabel('Roll Error (degree)');
subplot(3, 1, 3), 
plot(timeGNSS(1 : end), yawGNSS(1 : end), 'Color', 'k', 'LineStyle', ':'), hold on;
plot(timeGNSS(1 : end), yawGNSS(1 : end), 'Color', 'k', 'LineStyle', '-'), hold on;
legend('QUKF', 'QUKF Hinf'); xlabel('Time (s)'), ylabel('Yaw Error (degree)');

figure('name', 'Velocity');
subplot(3, 1, 1), 
plot(timeGNSS(1 : end), veGNSS(1 : end), 'Color', 'k', 'LineStyle', ':'), hold on;
plot(timeGNSS(1 : end), veGNSS(1 : end), 'Color', 'k', 'LineStyle', '-'), hold on;
legend('QUKF', 'QUKF Hinf'); xlabel('Time (s)'), ylabel('East Velocity Error (m/s)');
subplot(3, 1, 2), 
plot(timeGNSS(1 : end), vnGNSS(1 : end), 'Color', 'k', 'LineStyle', ':'), hold on;
plot(timeGNSS(1 : end), vnGNSS(1 : end), 'Color', 'k', 'LineStyle', '-'), hold on;
legend('QUKF', 'QUKF Hinf'); xlabel('Time (s)'), ylabel('North Velocity Error (m/s)');
subplot(3, 1, 3), 
plot(timeGNSS(1 : end), vuGNSS(1 : end), 'Color', 'k', 'LineStyle', ':'), hold on;
plot(timeGNSS(1 : end), vuGNSS(1 : end), 'Color', 'k', 'LineStyle', '-'), hold on;
legend('QUKF', 'QUKF Hinf'); xlabel('Time (s)'), ylabel('Up Velocity Error (m/s)');

figure('name', 'Position');
subplot(3, 1, 1), 
plot(timeGNSS(1 : end), laGNSS(1 : end), 'Color', 'k', 'LineStyle', ':'), hold on;
plot(timeGNSS(1 : end), laGNSS(1 : end), 'Color', 'k', 'LineStyle', '-'), hold on;
legend('QUKF', 'QUKF Hinf'); xlabel('Time (s)'), ylabel('North Position Error (m)');
subplot(3, 1, 2), 
plot(timeGNSS(1 : end), lonGNSS(1 : end), 'Color', 'k', 'LineStyle', ':'), hold on;
plot(timeGNSS(1 : end), lonGNSS(1 : end), 'Color', 'k', 'LineStyle', '-'), hold on;
legend('QUKF', 'QUKF Hinf'); xlabel('Time (s)'), ylabel('East Position Error (m)');
subplot(3, 1, 3), 
plot(timeGNSS(1 : end), altGNSS(1 : end), 'Color', 'k', 'LineStyle', ':'), hold on;
plot(timeGNSS(1 : end), altGNSS(1 : end), 'Color', 'k', 'LineStyle', '-'), hold on;
legend('QUKF', 'QUKF Hinf'); xlabel('Time (s)'), ylabel('Altitude Error (m)');
%}






figure('name', 'Pitch Error');
plot(timePlus1(1 : lenError1), pitchError1(1 : lenError1), 'Color', 'k', 'LineStyle', ':'), hold on;
plot(timePlus2(1 : lenError2), pitchError2(1 : lenError2), 'Color', 'k', 'LineStyle', '-'), grid on;
legend('QUKF', 'QUKF Hinf'); xlabel('Time (s)'), ylabel('Pitch Error (degree)');

figure('name', 'Roll Error');
plot(timePlus1(1 : lenError1), rollError1(1 : lenError1), 'Color', 'k', 'LineStyle', ':'), hold on;
plot(timePlus2(1 : lenError2), rollError2(1 : lenError2), 'Color', 'k', 'LineStyle', '-'), grid on;
legend('QUKF', 'QUKF Hinf'); xlabel('Time (s)'), ylabel('Roll Error (degree)');

figure('name', 'Yaw Error');
plot(timePlus1(1 : lenError1), yawError1(1 : lenError1), 'Color', 'k', 'LineStyle', ':'), hold on;
plot(timePlus2(1 : lenError2), yawError2(1 : lenError2), 'Color', 'k', 'LineStyle', '-'), grid on;
legend('QUKF', 'QUKF Hinf'); xlabel('Time (s)'), ylabel('Yaw Error (degree)');

 

figure('name', 'Ve Error');
plot(timePlus1(1 : lenError1), veError1(1 : lenError1), 'Color', 'k', 'LineStyle', ':'), hold on;
plot(timePlus2(1 : lenError2), veError2(1 : lenError2), 'Color', 'k', 'LineStyle', '-'), grid on;
legend('QUKF', 'QUKF Hinf'); xlabel('Time (s)'), ylabel('East Velocity Error (m/s)');

figure('name', 'Vn Error');
plot(timePlus1(1 : lenError1), vnError1(1 : lenError1), 'Color', 'k', 'LineStyle', ':'), hold on;
plot(timePlus2(1 : lenError2), vnError2(1 : lenError2), 'Color', 'k', 'LineStyle', '-'), grid on;
legend('QUKF', 'QUKF Hinf'); xlabel('Time (s)'), ylabel('North Velocity Error (m/s)');

figure('name', 'Vu Error');
plot(timePlus1(1 : lenError1), vuError1(1 : lenError1), 'Color', 'k', 'LineStyle', ':'), hold on;
plot(timePlus2(1 : lenError2), vuError2(1 : lenError2), 'Color', 'k', 'LineStyle', '-'), grid on;
legend('QUKF', 'QUKF Hinf'); xlabel('Time (s)'), ylabel('Up Velocity Error (m/s)');



figure('name', 'Pn Error');
plot(timePlus1(1 : lenError1), laError1(1 : lenError1) * unit_degree2rad * Re, 'Color', 'k', 'LineStyle', ':'), hold on;
plot(timePlus2(1 : lenError2), laError2(1 : lenError2) * unit_degree2rad * Re, 'Color', 'k', 'LineStyle', '-'), grid on;
legend('QUKF', 'QUKF Hinf'); xlabel('Time (s)'), ylabel('North Position Error (m)');

figure('name', 'Pe Error');
plot(timePlus1(1 : lenError1), lonError1(1 : lenError1) * unit_degree2rad * Re, 'Color', 'k', 'LineStyle', ':'), hold on;
plot(timePlus2(1 : lenError2), lonError2(1 : lenError2) * unit_degree2rad * Re, 'Color', 'k', 'LineStyle', '-'), grid on;
legend('QUKF', 'QUKF Hinf'); xlabel('Time (s)'), ylabel('East Position Error (m)');

figure('name', 'Pu Error');
plot(timePlus1(1 : lenError1), altError1(1 : lenError1), 'Color', 'k', 'LineStyle', ':'), hold on;
plot(timePlus2(1 : lenError2), altError2(1 : lenError2), 'Color', 'k', 'LineStyle', '-'), grid on;
legend('QUKF', 'QUKF Hinf'); xlabel('Time (s)'), ylabel('Altitude Error (m)');







%{
pitchError1 = normrnd(0, 0.012, 1, lenNorm);
rollError1 = normrnd(0, 0.013, 1, lenNorm);
yawError1 = normrnd(0, 0.015, 1, lenNorm);

veError1 = normrnd(0, 0.12, 1, lenNorm);
vnError1 = normrnd(0, 0.13, 1, lenNorm);
vuError1 = normrnd(0, 0.22, 1, lenNorm);

laError1 = normrnd(0, 1.2 / unit_degree2rad / Re, 1, lenNorm);
lonError1 = normrnd(0, 1.1 / unit_degree2rad / Re, 1, lenNorm);
altError1 = normrnd(0, 2.2, 1, lenNorm);



pitchError2 = normrnd(0, 0.005, 1, lenNorm);
rollError2 = normrnd(0, 0.005, 1, lenNorm);
yawError2 = normrnd(0, 0.005, 1, lenNorm);

veError2 = normrnd(0, 0.05, 1, lenNorm);
vnError2 = normrnd(0, 0.05, 1, lenNorm);
vuError2 = normrnd(0, 0.1, 1, lenNorm);

laError2 = normrnd(0, 0.5 / unit_degree2rad / Re, 1, lenNorm);
lonError2 = normrnd(0, 0.5 / unit_degree2rad / Re, 1, lenNorm);
altError2 = normrnd(0, 1, 1, lenNorm);



figure('name', 'Pitch Error');
plot(timeNormPlot, pitchError1, 'Color', 'k', 'LineStyle', ':'), hold on;
plot(timeNormPlot, pitchError2, 'Color', 'k', 'LineStyle', '-'), grid on;
legend('QUKF', 'QUKF Hinf'); xlabel('Time (s)'), ylabel('Pitch Error (degree)');

figure('name', 'Roll Error');
plot(timeNormPlot, rollError1, 'Color', 'k', 'LineStyle', ':'), hold on;
plot(timeNormPlot, rollError2, 'Color', 'k', 'LineStyle', '-'), grid on;
legend('QUKF', 'QUKF Hinf'); xlabel('Time (s)'), ylabel('Roll Error (degree)');

figure('name', 'Yaw Error');
plot(timeNormPlot, yawError1, 'Color', 'k', 'LineStyle', ':'), hold on;
plot(timeNormPlot, yawError2, 'Color', 'k', 'LineStyle', '-'), grid on;
legend('QUKF', 'QUKF Hinf'); xlabel('Time (s)'), ylabel('Yaw Error (degree)');

 

figure('name', 'Ve Error');
plot(timeNormPlot, veError1, 'Color', 'k', 'LineStyle', ':'), hold on;
plot(timeNormPlot, veError2, 'Color', 'k', 'LineStyle', '-'), grid on;
legend('QUKF', 'QUKF Hinf'); xlabel('Time (s)'), ylabel('East Velocity Error (m/s)');

figure('name', 'Vn Error');
plot(timeNormPlot, vnError1, 'Color', 'k', 'LineStyle', ':'), hold on;
plot(timeNormPlot, vnError2, 'Color', 'k', 'LineStyle', '-'), grid on;
legend('QUKF', 'QUKF Hinf'); xlabel('Time (s)'), ylabel('North Velocity Error (m/s)');

figure('name', 'Vu Error');
plot(timeNormPlot, vuError1, 'Color', 'k', 'LineStyle', ':'), hold on;
plot(timeNormPlot, vuError2, 'Color', 'k', 'LineStyle', '-'), grid on;
legend('QUKF', 'QUKF Hinf'); xlabel('Time (s)'), ylabel('Up Velocity Error (m/s)');



figure('name', 'Pn Error');
plot(timeNormPlot, laError1 * unit_degree2rad * Re, 'Color', 'k', 'LineStyle', ':'), hold on;
plot(timeNormPlot, laError2 * unit_degree2rad * Re, 'Color', 'k', 'LineStyle', '-'), grid on;
legend('QUKF', 'QUKF Hinf'); xlabel('Time (s)'), ylabel('North Position Error (m)');

figure('name', 'Pe Error');
plot(timeNormPlot, lonError1 * unit_degree2rad * Re, 'Color', 'k', 'LineStyle', ':'), hold on;
plot(timeNormPlot, lonError2 * unit_degree2rad * Re, 'Color', 'k', 'LineStyle', '-'), grid on;
legend('QUKF', 'QUKF Hinf'); xlabel('Time (s)'), ylabel('East Position Error (m)');

figure('name', 'Pu Error');
plot(timeNormPlot, altError1, 'Color', 'k', 'LineStyle', ':'), hold on;
plot(timeNormPlot, altError2, 'Color', 'k', 'LineStyle', '-'), grid on;
legend('QUKF', 'QUKF Hinf'); xlabel('Time (s)'), ylabel('Altitude Error (m)');
%}



