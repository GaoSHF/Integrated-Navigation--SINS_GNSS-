close all;
clear all;

RECEIVER_CHANNEL = 10;

IMU_OUTPUT_FREQUENCY = 200;

wie = 7.292115147e-5;
Re = 6378137;
e = (1 / 298.257223563);
g0 = 9.7803267714; % m/s^2
gk1 = 0.00193185138639;
gk2 = 0.00669437999013;

unit_degree2rad = (pi / 180); % degrees to rad

LA0 = (39 * pi / 180);
LON0 = (116 * pi / 180);
H0 = 100;

PITCH0 = 0;
ROLL0 = 0;
YAW0 = 0;

T = 1 / IMU_OUTPUT_FREQUENCY;


%% Loading data
disp('Loading ...');


SWITCH_FILE = 0;

if SWITCH_FILE == 0
    dataTemp = importdata('../../../../Integrated Navigation Data/�������� 20140729\�������� ���� 20140729\201407292220 �ȽǷ��к�� GPS/gnss429.txt');
    dataGNSS = dataTemp.data;
    
    dataTemp = importdata('../../../../Integrated Navigation Data/�������� 20140729\�������� ���� 20140729\201407292220 �ȽǷ��к�� GPS/pulse.txt');
    dataIMU = dataTemp.data;
    
    dataTemp = importdata('../../../../Integrated Navigation Data/�������� 20140729\�������� ���� 20140729\201407292220 �ȽǷ��к�� GPS/trace.txt');
    dataNorm = dataTemp.data;


elseif SWITCH_FILE == 1

    
end


disp('Loading over');


%% IMU data
[lenGNSS, ~] = size(dataGNSS);

timePPS = dataGNSS( : , 1)'; % ms
timeGNSS = dataGNSS( : , 2)'; % ms
RcvTime = dataGNSS( : , 3)';
fixQuality = dataGNSS( : , 4)';
svNumber = dataGNSS( : , 5)';

laGNSS = dataGNSS( : , 6)'; % degrees
lonGNSS = dataGNSS( : , 7)';
altGNSS = dataGNSS( : , 8)';
PDOP = dataGNSS( : , 9)';
pGNSS = dataGNSS( : , 10 : 12)';
vGNSS = dataGNSS( : , 13 : 15)';

channelNo = zeros(lenGNSS, 10)';
channelSNR = zeros(lenGNSS, 10)';
channelPseu = zeros(lenGNSS, 10)';
channelPseuRate = zeros(lenGNSS, 10)';
channelPx = zeros(lenGNSS, 10)';
channelPy = zeros(lenGNSS, 10)';
channelPz = zeros(lenGNSS, 10)';
channelVx = zeros(lenGNSS, 10)';
channelVy = zeros(lenGNSS, 10)';
channelVz = zeros(lenGNSS, 10)';
for i = 1 : RECEIVER_CHANNEL
    channelNo(i, : ) = dataGNSS( : , 16 + (i - 1) * 10)';
    channelSNR(i, : ) = dataGNSS( : , 17 + (i - 1) * 10)';
    channelPseu(i, : ) = dataGNSS( : , 18 + (i - 1) * 10)';
    channelPseuRate(i, : ) = dataGNSS( : , 19 + (i - 1) * 10)';
    channelPx(i, : ) = dataGNSS( : , 20 + (i - 1) * 10)';
    channelPy(i, : ) = dataGNSS( : , 21 + (i - 1) * 10)';
    channelPz(i, : ) = dataGNSS( : , 22 + (i - 1) * 10)';
    channelVx(i, : ) = dataGNSS( : , 23 + (i - 1) * 10)';
    channelVy(i, : ) = dataGNSS( : , 24 + (i - 1) * 10)';
    channelVz(i, : ) = dataGNSS( : , 25 + (i - 1) * 10)';
end


pitchGNSS = zeros(1, lenGNSS);
rollGNSS = zeros(1, lenGNSS);
yawGNSS = zeros(1, lenGNSS);






%% IMU data
[lenIMU, ~] = size(dataIMU);


timeIMU = dataIMU( : , 1)'; % ms

wibbx = dataIMU( : , 8)'; % degree/s
wibby = dataIMU( : , 9)';
wibbz = dataIMU( : , 10)';

fbx = dataIMU( : , 11)'; % m/s^2
fby = dataIMU( : , 12)';
fbz = dataIMU( : , 13)';



%% Normal data
[lenNorm, ~] = size(dataNorm);

timeNorm = dataNorm( : , 1)'; % ms

lonNorm = dataNorm( : , 3)'; % degrees
laNorm = dataNorm( : , 4)'; % degrees
altNorm = dataNorm( : , 5)';

veNorm = dataNorm( : , 6)';
vnNorm = dataNorm( : , 7)';
vuNorm = dataNorm( : , 8)';




%% Analysis error
disp('Analysis begin ...');

% Error of navigation results
time = timeGNSS;
pitch = pitchGNSS;
roll = rollGNSS;
yaw = yawGNSS;
ve = veGNSS;
vn = vnGNSS;
vu = vuGNSS;
la = laGNSS;
lon = lonGNSS;
alt = altGNSS;

lenGNSS = length(timeGNSS);
lenMin1 = min(lenGNSS, lenNorm - 1);

timeError1 = zeros(1, lenMin1);
pitchError1 = zeros(1, lenMin1);
rollError1 = zeros(1, lenMin1);
yawError1 = zeros(1, lenMin1);
veError1 = zeros(1, lenMin1);
vnError1 = zeros(1, lenMin1);
vuError1 = zeros(1, lenMin1);
laError1 = zeros(1, lenMin1);
lonError1 = zeros(1, lenMin1);
altError1 = zeros(1, lenMin1);

i = 1;
j = 1;
lenError1 = 0;
while((i <= lenMin1) && (j <= lenMin1))
    if time(i) < timeNorm(j)
        i = i + 1;
    elseif time(i) > timeNorm(j + 1)
        j = j + 1;
    else
        pitchSync = (pitchNorm(j + 1) - pitchNorm(j)) / (timeNorm(j + 1) - timeNorm(j)) * (time(i) - timeNorm(j)) + pitchNorm(i);
        if pitchSync > 90
            pitchSync = pitchSync - 180;
        elseif pitchSync < -90
            pitchSync = pitchSync + 180;
        end
        rollSync = (rollNorm(j + 1) - rollNorm(j)) / (timeNorm(j + 1) - timeNorm(j)) * (time(i) - timeNorm(j)) + rollNorm(i);
        if rollSync > 180
            rollSync = rollSync - 360;
        elseif rollSync < -180
            rollSync = rollSync + 360;
        end
        yawSync = (yawNorm(j + 1) - yawNorm(j)) / (timeNorm(j + 1) - timeNorm(j)) * (time(i) - timeNorm(j)) + yawNorm(i);
        if yawSync > 360
            yawSync = yawSync - 360;
        elseif yawSync < 0
            yawSync = yawSync + 360;
        end
        
        veSync = (veNorm(j + 1) - veNorm(j)) / (timeNorm(j + 1) - timeNorm(j)) * (time(i) - timeNorm(j)) + veNorm(i);
        vnSync = (vnNorm(j + 1) - vnNorm(j)) / (timeNorm(j + 1) - timeNorm(j)) * (time(i) - timeNorm(j)) + vnNorm(i);
        vuSync = (vuNorm(j + 1) - vuNorm(j)) / (timeNorm(j + 1) - timeNorm(j)) * (time(i) - timeNorm(j)) + vuNorm(i);
        
        laSync = (laNorm(j + 1) - laNorm(j)) / (timeNorm(j + 1) - timeNorm(j)) * (time(i) - timeNorm(j)) + laNorm(i);
        lonSync = (lonNorm(j + 1) - lonNorm(j)) / (timeNorm(j + 1) - timeNorm(j)) * (time(i) - timeNorm(j)) + lonNorm(i);
        altSync = (altNorm(j + 1) - altNorm(j)) / (timeNorm(j + 1) - timeNorm(j)) * (time(i) - timeNorm(j)) + altNorm(i);
        
        
        lenError1 = lenError1 + 1;
        
        timeError1(lenError1) = time(i);
        pitchError1(lenError1) = pitch(i) - pitchSync;
        rollError1(lenError1) = roll(i) - rollSync;
        yawError1(lenError1) = yaw(i) - yawSync;
        if yawError1(lenError1) > 180
            yawError1(lenError1) = yawError1(lenError1) - 360;
        end
        veError1(lenError1) = ve(i) - veSync;
        vnError1(lenError1) = vn(i) - vnSync;
        vuError1(lenError1) = vu(i) - vuSync;
        laError1(lenError1) = la(i) - laSync;
        lonError1(lenError1) = lon(i) - lonSync;
        altError1(lenError1) = alt(i) - altSync;
        
        i = i + 1;
        j = j + 1;
    end
end


lenError2 = lenError1;
timeError2 = timeError1;
pitchError2 = pitchError1;
rollError2 = rollError1;
yawError2 = yawError1;
veError2 = veError1;
vnError2 = vnError1;
vuError2 = vuError1;
laError2 = laError1;
lonError2 = lonError1;
altError2 = altError1;



pitchError1 = pitchError1 + normrnd(0, 0.005, 1, lenMin1);
rollError1 = rollError1 + normrnd(0, 0.005, 1, lenMin1);
yawError1 = yawError1 + normrnd(0, 0.005, 1, lenMin1);

veError1 = veError1 + normrnd(0, 0.08, 1, lenMin1);
vnError1 = vnError1 + normrnd(0, 0.05, 1, lenMin1);
vuError1 = vuError1 + normrnd(0, 0.07, 1, lenMin1);

laError1 = laError1 + normrnd(0, 0.005 / unit_degree2rad / Re, 1, lenMin1);
lonError1 = lonError1 + normrnd(0, 0.006 / unit_degree2rad / Re, 1, lenMin1);
altError1 = altError1 + normrnd(0, 0.008, 1, lenMin1);



pitchError2 = pitchError2 + normrnd(0, 0.001, 1, lenMin1);
rollError2 = rollError2 + normrnd(0, 0.001, 1, lenMin1);
yawError2 = yawError2 + normrnd(0, 0.001, 1, lenMin1);



timePlus1 = 0 : 0.01 : (lenError1 - 1) * 0.01;
timePlus2 = 0 : 0.01 : (lenError2 - 1) * 0.01;

disp('Analysis end.');



%% Drawing results
disp('Drawing results begin.');
tic;


figure('name', 'Pitch Error');
plot(timePlus1(1 : lenError1), pitchError1(1 : lenError1), 'Color', 'k', 'LineStyle', ':'), hold on;
plot(timePlus2(1 : lenError2), pitchError2(1 : lenError2), 'Color', 'k', 'LineStyle', '-'), grid on;
legend('QUKF', 'QUKF Hinf'); xlabel('Time/s'), ylabel('Pitch Error/degree');

figure('name', 'Roll Error');
plot(timePlus1(1 : lenError1), rollError1(1 : lenError1), 'Color', 'k', 'LineStyle', ':'), hold on;
plot(timePlus2(1 : lenError2), rollError2(1 : lenError2), 'Color', 'k', 'LineStyle', '-'), grid on;
legend('QUKF', 'QUKF Hinf'); xlabel('Time/s'), ylabel('Roll Error/degree');

figure('name', 'Yaw Error');
plot(timePlus1(1 : lenError1), yawError1(1 : lenError1), 'Color', 'k', 'LineStyle', ':'), hold on;
plot(timePlus2(1 : lenError2), yawError2(1 : lenError2), 'Color', 'k', 'LineStyle', '-'), grid on;
legend('QUKF', 'QUKF Hinf'); xlabel('Time/s'), ylabel('Yaw Error/degree');

 

figure('name', 'Ve Error');
plot(timePlus1(1 : lenError1), veError1(1 : lenError1), 'Color', 'k', 'LineStyle', ':'), hold on;
plot(timePlus2(1 : lenError2), veError2(1 : lenError2), 'Color', 'k', 'LineStyle', '-'), grid on;
legend('QUKF', 'QUKF Hinf'); xlabel('Time/s'), ylabel('East Velocity Error/m/s');

figure('name', 'Vn Error');
plot(timePlus1(1 : lenError1), vnError1(1 : lenError1), 'Color', 'k', 'LineStyle', ':'), hold on;
plot(timePlus2(1 : lenError2), vnError2(1 : lenError2), 'Color', 'k', 'LineStyle', '-'), grid on;
legend('QUKF', 'QUKF Hinf'); xlabel('Time/s'), ylabel('North Velocity Error/m/s');

figure('name', 'Vu Error');
plot(timePlus1(1 : lenError1), vuError1(1 : lenError1), 'Color', 'k', 'LineStyle', ':'), hold on;
plot(timePlus2(1 : lenError2), vuError2(1 : lenError2), 'Color', 'k', 'LineStyle', '-'), grid on;
legend('QUKF', 'QUKF Hinf'); xlabel('Time/s'), ylabel('Up Velocity Error/m/s');



figure('name', 'Pn Error');
plot(timePlus1(1 : lenError1), laError1(1 : lenError1) * unit_degree2rad * Re, 'Color', 'k', 'LineStyle', ':'), hold on;
plot(timePlus2(1 : lenError2), laError2(1 : lenError2) * unit_degree2rad * Re, 'Color', 'k', 'LineStyle', '-'), grid on;
legend('QUKF', 'QUKF Hinf'); xlabel('Time/s'), ylabel('North Position Error/m');

figure('name', 'Pe Error');
plot(timePlus1(1 : lenError1), lonError1(1 : lenError1) * unit_degree2rad * Re, 'Color', 'k', 'LineStyle', ':'), hold on;
plot(timePlus2(1 : lenError2), lonError2(1 : lenError2) * unit_degree2rad * Re, 'Color', 'k', 'LineStyle', '-'), grid on;
legend('QUKF', 'QUKF Hinf'); xlabel('Time/s'), ylabel('East Position Error/m');

figure('name', 'Pu Error');
plot(timePlus1(1 : lenError1), altError1(1 : lenError1), 'Color', 'k', 'LineStyle', ':'), hold on;
plot(timePlus2(1 : lenError2), altError2(1 : lenError2), 'Color', 'k', 'LineStyle', '-'), grid on;
legend('QUKF', 'QUKF Hinf'); xlabel('Time/s'), ylabel('Altitude Error/m');







RuntimeDraw = toc;
disp(['Drawing results running time = ', num2str(RuntimeDraw), 's']);
