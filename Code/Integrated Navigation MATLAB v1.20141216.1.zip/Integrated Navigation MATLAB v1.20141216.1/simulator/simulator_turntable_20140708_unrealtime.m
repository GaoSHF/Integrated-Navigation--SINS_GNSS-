close all;
clear all;

RECEIVER_CHANNEL = 10;

GNSS_RECEIVER_DELAY = 7; % ms

IMU_OUTPUT_FREQUENCY = 200;

wie = 7.292115147e-5;
Re = 6378137;
e = (1 / 298.257223563);
g0 = 9.7803267714; % m/s^2
gk1 = 0.00193185138639;
gk2 = 0.00669437999013;

unit_degree2rad = (pi / 180); % degrees to rad

LA0 = (39 * pi / 180);
LON0 = (116 * pi / 180);
H0 = 100;

PITCH0 = 0;
ROLL0 = 0;
YAW0 = 0;

T = 1 / IMU_OUTPUT_FREQUENCY;


%% Loading data
disp('Loading ...');


SWITCH_FILE = 0;

if SWITCH_FILE == 0
    dataTemp = importdata('../../../../Integrated Navigation Data/201407081803 (GPS Turntable)/gnss429.txt');
    dataGNSS = dataTemp.data;
    
    dataTemp = importdata('../../../../Integrated Navigation Data/201407081803 (GPS Turntable)/pulse.txt');
    dataIMU = dataTemp.data;
    
    %dataTemp = importdata('../../../../Integrated Navigation Data/201407081803 (GPS Turntable)/CraftData.txt');
    %dataNormal = dataTemp.data;
    fileNormOld = fopen('../../../../Integrated Navigation Data/201407081803 (GPS Turntable)/CraftData.txt', 'r');
    
    fileNavGNSS = fopen('../../../../Integrated Navigation Data/201407081803 (GPS Turntable)/nav_gnss.dat', 'w');
    fileNavNormal = fopen('../../../../Integrated Navigation Data/201407081803 (GPS Turntable)/nav_normal.dat', 'w');
    fileBoth = fopen('../../../../Integrated Navigation Data/201407081803 (GPS Turntable)/both.dat', 'w');


elseif SWITCH_FILE == 1

    
end


disp('Loading over');


%% IMU data
[lenGNSS, ~] = size(dataGNSS);

timePPS = dataGNSS( : , 1)'; % ms
timeGNSS = dataGNSS( : , 2)'; % ms
RcvTime = dataGNSS( : , 3)';
fixQuality = dataGNSS( : , 4)';
svNumber = dataGNSS( : , 5)';

laGNSS = dataGNSS( : , 6)';
lonGNSS = dataGNSS( : , 7)';
altGNSS = dataGNSS( : , 8)';
PDOP = dataGNSS( : , 9)';
pGNSS = dataGNSS( : , 10 : 12)';
vGNSS = dataGNSS( : , 13 : 15)';

channelNo = zeros(lenGNSS, 10)';
channelSNR = zeros(lenGNSS, 10)';
channelPseu = zeros(lenGNSS, 10)';
channelPseuRate = zeros(lenGNSS, 10)';
channelPx = zeros(lenGNSS, 10)';
channelPy = zeros(lenGNSS, 10)';
channelPz = zeros(lenGNSS, 10)';
channelVx = zeros(lenGNSS, 10)';
channelVy = zeros(lenGNSS, 10)';
channelVz = zeros(lenGNSS, 10)';
for i = 1 : RECEIVER_CHANNEL
    channelNo(i, : ) = dataGNSS( : , 16 + (i - 1) * 10)';
    channelSNR(i, : ) = dataGNSS( : , 17 + (i - 1) * 10)';
    channelPseu(i, : ) = dataGNSS( : , 18 + (i - 1) * 10)';
    channelPseuRate(i, : ) = dataGNSS( : , 19 + (i - 1) * 10)';
    channelPx(i, : ) = dataGNSS( : , 20 + (i - 1) * 10)';
    channelPy(i, : ) = dataGNSS( : , 21 + (i - 1) * 10)';
    channelPz(i, : ) = dataGNSS( : , 22 + (i - 1) * 10)';
    channelVx(i, : ) = dataGNSS( : , 23 + (i - 1) * 10)';
    channelVy(i, : ) = dataGNSS( : , 24 + (i - 1) * 10)';
    channelVz(i, : ) = dataGNSS( : , 25 + (i - 1) * 10)';
end





%% IMU data
[lenIMU, ~] = size(dataIMU);


timeIMU = dataIMU( : , 1)'; % ms

wibbx = dataIMU( : , 8)'; % degree/s
wibby = dataIMU( : , 9)';
wibbz = dataIMU( : , 10)';

fbx = dataIMU( : , 11)'; % m/s^2
fby = dataIMU( : , 12)';
fbz = dataIMU( : , 13)';



%% Normal data
% Read file header
for i = 1 : 112
    strTemp = fscanf(fileNormOld, '%s', 1);
end

timeNormal = zeros(1, 100);
laNormal = zeros(1, 100);
lonNormal = zeros(1, 100);
altNormal = zeros(1, 100);
veNormal = zeros(1, 100);
vnNormal = zeros(1, 100);
vuNormal = zeros(1, 100);
pitchNormal = zeros(1, 100);
rollNormal = zeros(1, 100);
yawNormal = zeros(1, 100);

lenNormal = 1;
while 1
    
    strTemp = fscanf(fileNormOld, '%s', 1);
    timeNormal(lenNormal) = str2double(strTemp);
    
    strTemp = fscanf(fileNormOld, '%s', 1);
    lonNormal(lenNormal) = str2double(strTemp);
    strTemp = fscanf(fileNormOld, '%s', 1);
    laNormal(lenNormal) = str2double(strTemp);
    strTemp = fscanf(fileNormOld, '%s', 1);
    altNormal(lenNormal) = str2double(strTemp);
    
    strTemp = fscanf(fileNormOld, '%s', 1);
    veNormal(lenNormal) = str2double(strTemp);
    strTemp = fscanf(fileNormOld, '%s', 1);
    vnNormal(lenNormal) = str2double(strTemp);
    strTemp = fscanf(fileNormOld, '%s', 1);
    vuNormal(lenNormal) = str2double(strTemp);
    
    for i = 1 : 3
        strTemp = fscanf(fileNormOld, '%s', 1);
    end
    
    strTemp = fscanf(fileNormOld, '%s', 1);
    yawNormal(lenNormal) = str2double(strTemp);
    strTemp = fscanf(fileNormOld, '%s', 1);
    pitchNormal(lenNormal) = str2double(strTemp);
    strTemp = fscanf(fileNormOld, '%s', 1);
    rollNormal(lenNormal) = str2double(strTemp);
    
    for i = 1 : 112 - 13
        strTemp = fscanf(fileNormOld, '%s', 1);
    end
    
    if feof(fileNormOld) ~= 0
        break;
    else
        % Record normal navigation file
        fprintf(fileNavNormal, '%.9f\t', timeNormal(lenNormal));
        fprintf(fileNavNormal, '%.9f\t', pitchNormal(lenNormal)); % degrees
        fprintf(fileNavNormal, '%.9f\t', rollNormal(lenNormal));
        fprintf(fileNavNormal, '%.9f\t', yawNormal(lenNormal));
        fprintf(fileNavNormal, '%.9f\t', veNormal(lenNormal));
        fprintf(fileNavNormal, '%.9f\t', vnNormal(lenNormal));
        fprintf(fileNavNormal, '%.9f\t', vuNormal(lenNormal));
        fprintf(fileNavNormal, '%.9f\t', laNormal(lenNormal)); % degrees
        fprintf(fileNavNormal, '%.9f\t', lonNormal(lenNormal));
        fprintf(fileNavNormal, '%.9f\n', altNormal(lenNormal));
        
        lenNormal = lenNormal + 1;
    end
    
end




%% Record Normal data

disp('Recording normal data ...');

for i = 1 : lenNormal
    
    
    
    
    
end % for i

disp('Recording normal data over');


%% Sync data

disp('Synchronization ...');

flagSync = 0;

indexGNSS = 1;

timeSync = timeIMU(1);

channelNoFile = zeros(10, 1);
channelSnrFile = zeros(10, 1);
channelPseuFile = zeros(10, 1);
channelPseuRateFile = zeros(10, 1);
channelPxFile = zeros(10, 1);
channelPyFile = zeros(10, 1);
channelPzFile = zeros(10, 1);
channelVxFile = zeros(10, 1);
channelVyFile = zeros(10, 1);
channelVzFile = zeros(10, 1);
for i = 1 : lenIMU - 1
    while indexGNSS + 1 <= lenGNSS
        timePPSNew = timePPS(indexGNSS);
        if timeIMU(i) > timePPSNew
            indexGNSS = indexGNSS + 1;
        else
            break;
        end
    end
    
    % Interpolation of IMU data
    if (timeIMU(i) <= timePPSNew) && (timeIMU(i + 1) >= timePPSNew)
        flagSync = 1;
        timeSync = timePPSNew;
    elseif timeIMU(i) > timePPSNew
        flagSync = 0;
        timeSync = timeSync + 1000 / IMU_OUTPUT_FREQUENCY;
    elseif timeIMU(i + 1) < timePPSNew
        flagSync = 0;
        timeSync = timeSync + 1000 / IMU_OUTPUT_FREQUENCY;
    end
    
    wibbxSync = (wibbx(i + 1) - wibbx(i)) / (timeIMU(i + 1) - timeIMU(i)) * (timeSync - timeIMU(i)) + wibbx(i);
    wibbySync = (wibby(i + 1) - wibby(i)) / (timeIMU(i + 1) - timeIMU(i)) * (timeSync - timeIMU(i)) + wibby(i);
    wibbzSync = (wibbz(i + 1) - wibbz(i)) / (timeIMU(i + 1) - timeIMU(i)) * (timeSync - timeIMU(i)) + wibbz(i);
    fbxSync = (fbx(i + 1) - fbx(i)) / (timeIMU(i + 1) - timeIMU(i)) * (timeSync - timeIMU(i)) + fbx(i);
    fbySync = (fby(i + 1) - fby(i)) / (timeIMU(i + 1) - timeIMU(i)) * (timeSync - timeIMU(i)) + fby(i);
    fbzSync = (fbz(i + 1) - fbz(i)) / (timeIMU(i + 1) - timeIMU(i)) * (timeSync - timeIMU(i)) + fbz(i);
    
    % Record GNSS data
    if flagSync == 1
        fixQualityFile = fixQuality(indexGNSS);
        svNumberFile = svNumber(indexGNSS);
        
        laFile = laGNSS(indexGNSS) * unit_degree2rad;
        lonFile = lonGNSS(indexGNSS) * unit_degree2rad;
        altFile = altGNSS(indexGNSS);
        
        pxFile = pGNSS(1, indexGNSS);
        pyFile = pGNSS(2, indexGNSS);
        pzFile = pGNSS(3, indexGNSS);
        
        vxFile = vGNSS(1, indexGNSS);
        vyFile = vGNSS(2, indexGNSS);
        vzFile = vGNSS(3, indexGNSS);
        
        for j = 1 : RECEIVER_CHANNEL
            channelNoFile(j, 1) = channelNo(j, indexGNSS);
            channelSnrFile(j, 1) = channelSNR(j, indexGNSS);
            channelPseuFile(j, 1) = channelPseu(j, indexGNSS);
            channelPseuRateFile(j, 1) = channelPseuRate(j, indexGNSS);
            channelPxFile(j, 1) = channelPx(j, indexGNSS);
            channelPyFile(j, 1) = channelPy(j, indexGNSS);
            channelPzFile(j, 1) = channelPz(j, indexGNSS);
            channelVxFile(j, 1) = channelVx(j, indexGNSS);
            channelVyFile(j, 1) = channelVy(j, indexGNSS);
            channelVzFile(j, 1) = channelVz(j, indexGNSS);
        end
        
        % Transfer GNSS velocity from E-N-U to X-Y-Z
        Cte = [cos(pi / 2 + lonFile),       -cos(pi / 2 - laFile) * sin(pi / 2 + lonFile),      sin(pi / 2 - laFile) * sin(pi / 2 + lonFile);
                sin(pi / 2 + lonFile),      cos(pi / 2 - laFile) * cos(pi / 2 + lonFile),       -sin(pi / 2 - laFile) * cos(pi / 2 + lonFile);
                0,                          sin(pi / 2 - laFile),                               cos(pi / 2 - laFile)];
        
        vgeoGNSS = Cte' * [vxFile; vyFile; vzFile];
            
        % Record GNSS navigation file
        if fixQualityFile ~= 0
            fprintf(fileNavGNSS, '%f\t', timePPSNew); % ms
            fprintf(fileNavGNSS, '%f\t', laFile / unit_degree2rad); % degrees
            fprintf(fileNavGNSS, '%f\t', lonFile / unit_degree2rad);
            fprintf(fileNavGNSS, '%f\t', altFile);
            fprintf(fileNavGNSS, '%e\t', vgeoGNSS(1, 1));
            fprintf(fileNavGNSS, '%e\t', vgeoGNSS(2, 1));
            fprintf(fileNavGNSS, '%e\n', vgeoGNSS(3, 1));
        end
    else
        fixQualityFile = 0;
        svNumberFile = 0;
        
        laFile = 0.0;
        lonFile = 0.0;
        altFile = 0.0;
        
        pxFile = 0.0;
        pyFile = 0.0;
        pzFile = 0.0;
        
        vxFile = 0.0;
        vyFile = 0.0;
        vzFile = 0.0;
        
        for j = 1 : RECEIVER_CHANNEL
            channelNoFile(j, 1) = 0;
            channelSnrFile(j, 1) = 0.0;
            channelPseuFile(j, 1) = 0.0;
            channelPseuRateFile(j, 1) = 0.0;
            channelPxFile(j, 1) = 0.0;
            channelPyFile(j, 1) = 0.0;
            channelPzFile(j, 1) = 0.0;
            channelVxFile(j, 1) = 0.0;
            channelVyFile(j, 1) = 0.0;
            channelVzFile(j, 1) = 0.0;
        end
    end % if else
    
    
    % Record both IMU and GNSS data
    fprintf(fileBoth, '%f\t', timeSync);
    fprintf(fileBoth, '%e\t', wibbxSync); % rad/s
    fprintf(fileBoth, '%e\t', wibbySync);
    fprintf(fileBoth, '%e\t', wibbzSync);
    fprintf(fileBoth, '%e\t', fbxSync); % m/s^2
    fprintf(fileBoth, '%e\t', fbySync);
    fprintf(fileBoth, '%e\t', fbzSync);
    fprintf(fileBoth, '%d\t', fixQualityFile);
    fprintf(fileBoth, '%d\t', svNumberFile);
    fprintf(fileBoth, '%f\t', laFile); % rad
    fprintf(fileBoth, '%f\t', lonFile);
    fprintf(fileBoth, '%f\t', altFile);
    fprintf(fileBoth, '%f\t', pxFile);
    fprintf(fileBoth, '%f\t', pyFile);
    fprintf(fileBoth, '%f\t', pzFile);
    fprintf(fileBoth, '%f\t', vxFile);
    fprintf(fileBoth, '%f\t', vyFile);
    fprintf(fileBoth, '%f\t', vzFile);
    for j = 1 : RECEIVER_CHANNEL
        fprintf(fileBoth, '%d\t', channelNoFile(j, 1));
        fprintf(fileBoth, '%d\t', channelSnrFile(j, 1));
        fprintf(fileBoth, '%e\t', channelPseuFile(j, 1));
        fprintf(fileBoth, '%e\t', channelPseuRateFile(j, 1));
        fprintf(fileBoth, '%e\t', channelPxFile(j, 1));
        fprintf(fileBoth, '%e\t', channelPyFile(j, 1));
        fprintf(fileBoth, '%e\t', channelPzFile(j, 1));
        fprintf(fileBoth, '%e\t', channelVxFile(j, 1));
        fprintf(fileBoth, '%e\t', channelVyFile(j, 1));
        fprintf(fileBoth, '%e\t', channelVzFile(j, 1));
    end
    fprintf(fileBoth, '\n');
    
end


disp('Synchronization over');

%% Close files

%fclose(fileNavNormal);
fclose(fileNavGNSS);
fclose(fileBoth);


msgbox('End of Generation.');

