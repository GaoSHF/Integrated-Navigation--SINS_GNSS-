
fileNormOld = fopen('../../../../Integrated Navigation Data/�������� 20140729\�������� ���� 20140729\201407292215 Э��ת��S���� GPS/CraftData.txt', 'r');

for i = 1 : 112
    strTemp = fscanf(fileNormOld, '%s', 1);
end

timeNormal = zeros(1, 100);
laNormal = zeros(1, 100);
lonNormal = zeros(1, 100);
altNormal = zeros(1, 100);
veNormal = zeros(1, 100);
vnNormal = zeros(1, 100);
vuNormal = zeros(1, 100);
pitchNormal = zeros(1, 100);
rollNormal = zeros(1, 100);
yawNormal = zeros(1, 100);

lenNormal = 1;

while 1
    
    strTemp = fscanf(fileNormOld, '%s', 1);
    timeNormal(lenNormal) = str2double(strTemp);
    
    strTemp = fscanf(fileNormOld, '%s', 1);
    lonNormal(lenNormal) = str2double(strTemp);
    strTemp = fscanf(fileNormOld, '%s', 1);
    laNormal(lenNormal) = str2double(strTemp);
    strTemp = fscanf(fileNormOld, '%s', 1);
    altNormal(lenNormal) = str2double(strTemp);
    
    strTemp = fscanf(fileNormOld, '%s', 1);
    veNormal(lenNormal) = str2double(strTemp);
    strTemp = fscanf(fileNormOld, '%s', 1);
    vnNormal(lenNormal) = str2double(strTemp);
    strTemp = fscanf(fileNormOld, '%s', 1);
    vuNormal(lenNormal) = str2double(strTemp);
    
    for i = 1 : 3
        strTemp = fscanf(fileNormOld, '%s', 1);
    end
    
    strTemp = fscanf(fileNormOld, '%s', 1);
    yawNormal(lenNormal) = str2double(strTemp);
    strTemp = fscanf(fileNormOld, '%s', 1);
    pitchNormal(lenNormal) = str2double(strTemp);
    strTemp = fscanf(fileNormOld, '%s', 1);
    rollNormal(lenNormal) = str2double(strTemp);
    
    for i = 1 : 112 - 13
        strTemp = fscanf(fileNormOld, '%s', 1);
    end
    
    if feof(fileNormOld) ~= 0
        break;
    else
        % Record normal navigation file
        lenNormal = lenNormal + 1;
    end
    
end



fclose(fileNorm);

