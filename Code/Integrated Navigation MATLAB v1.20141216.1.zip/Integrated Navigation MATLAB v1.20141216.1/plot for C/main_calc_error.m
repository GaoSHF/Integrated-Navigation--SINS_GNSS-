close all;
clear all;


SAMPLING_RATE_IMU = 100; % 100Hz
TIME_INTERVAL_IMU = 0.01; % 0.01s

SAMPLING_RATE_GPS = 10; % 100Hz
TIME_INTERVAL_GPS = 0.1; % 0.1s


% Relay before using feedback correction
RELAY_BEFORE_FEEDBACK_CORRECTION = 0 * 60 / TIME_INTERVAL_IMU;

% Global definition
wie = 7.292115147e-5; % rad/s
Re = 6378245; % Earth radius, m
e = 1 / 298.3; % Earth eccentrity
g0 = 9.7803267714; % m/s^2
gk1 = 0.00193185138639;
gk2 = 0.00669437999013;

% Unit conversion
unit_degree2rad = (pi / 180); % degrees to rad
unit_w = (pi / 3600 / 180); % degrees/h to rad/s
unit_ug = (g0 * 10 ^ (-6)); % ug to m/s^2

SWITCH_DATA = 0;
SWITCH_TYPE = 0;


if SWITCH_DATA == 0
    data_norm = importdata('../../Data/201401031452 (GPS L1 Static)/nav_normal2.dat');
elseif SWITCH_DATA == 1
    data_norm = importdata('../../Data/201401031508 (GPS L1 Vn 1g 300)/nav_normal2.dat');
elseif SWITCH_DATA == 2
    data_norm = importdata('../../Data/201401031519 (GPS L1 Vn 1g 300 6g 900)/nav_normal2.dat');
elseif SWITCH_DATA == 3
    data_norm = importdata('../../Data/201401031548 (GPS L1 Vn 1g 300 6g 1200)/nav_normal2.dat');
elseif SWITCH_DATA == 4
    data_norm = importdata('../../Data/201401031607 (GPS L1 Vn 1g 300 4g 900)/nav_normal2.dat');
elseif SWITCH_DATA == 5
    data_norm = importdata('../../Data/201401031355 (BD B3 Vn 300)/nav_normal2.dat');
end


if SWITCH_TYPE == 0
    data_kf = importdata('../../Data/results_kf.dat');
    %file_error = fopen('../../Data/error_kf.dat', 'w');
elseif SWITCH_TYPE == 1
    data_kf = importdata('../../Data/results_ukf.dat');
    %file_error = fopen('../../Data/error_ukf.dat', 'w');
elseif SWITCH_TYPE == 2
    data_kf = importdata('../../Data/results_hinfukf.dat');
    %file_error = fopen('../../Data/error_hinfukf.dat', 'w');
elseif SWITCH_TYPE == 3
    data_kf = importdata('../../Data/results_qlcukf.dat');
    %file_error = fopen('../../Data/error_qlcukf.dat', 'w');
elseif SWITCH_TYPE == 4
    data_kf = importdata('../../Data/results_qtcukf.dat');
    %file_error = fopen('../../Data/error_qtcukf.dat', 'w');
end




% Import normal navigation results
len_norm = length(data_norm);
time_norm = data_norm( : , 1)';
pitch_norm = data_norm( : , 2)';
roll_norm = data_norm( : , 3)';
yaw_norm = data_norm( : , 4)';
ve_norm = data_norm( : , 5)';
vn_norm = data_norm( : , 6)';
vu_norm = data_norm( : , 7)';
la_norm = data_norm( : , 8)';
lon_norm = data_norm( : , 9)';
alt_norm = data_norm( : , 10)';



% Import KF navigation results
len_kf = length(data_kf);
time_kf = data_kf( : , 1)';
pitch_kf = data_kf( : , 2)';
roll_kf = data_kf( : , 3)';
yaw_kf = data_kf( : , 4)';
ve_kf = data_kf( : , 5)';
vn_kf = data_kf( : , 6)';
vu_kf = data_kf( : , 7)';
la_kf = data_kf( : , 8)';
lon_kf = data_kf( : , 9)';
alt_kf = data_kf( : , 10)';

% Error
time_error = time_kf;
pitch_error = zeros(1, len_kf);
roll_error = zeros(1, len_kf);
yaw_error = zeros(1, len_kf);
ve_error = zeros(1, len_kf);
vn_error = zeros(1, len_kf);
vu_error = zeros(1, len_kf);
la_error = zeros(1, len_kf);
lon_error = zeros(1, len_kf);
alt_error = zeros(1, len_kf);


for i = 1 : len_kf
    
    % Error
    pitch_error(1, i) = pitch_kf(1, i) - pitch_norm(1, i);
    roll_error(1, i) = roll_kf(1, i) - roll_norm(1, i);
    yaw_error(1, i) = yaw_kf(1, i) - yaw_norm(1, i);
    ve_error(1, i) = ve_kf(1, i) - ve_norm(1, i);
    vn_error(1, i) = vn_kf(1, i) - vn_norm(1, i);
    vu_error(1, i) = vu_kf(1, i) - vu_norm(1, i);
    la_error(1, i) = la_kf(1, i) - la_norm(1, i);
    lon_error(1, i) = lon_kf(1, i) - lon_norm(1, i);
    alt_error(1, i) = alt_kf(1, i) - alt_norm(1, i);
    
    % Record error data
    %{
    fprintf(file_error, '%f\t', time_error(1, i));
    fprintf(file_error, '%e\t', pitch_error(1, i));
    fprintf(file_error, '%e\t', roll_error(1, i));
    fprintf(file_error, '%e\t', yaw_error(1, i));
    fprintf(file_error, '%e\t', ve_error(1, i));
    fprintf(file_error, '%e\t', vn_error(1, i));
    fprintf(file_error, '%e\t', vu_error(1, i));
    fprintf(file_error, '%e\t', la_error(1, i));
    fprintf(file_error, '%e\t', lon_error(1, i));
    fprintf(file_error, '%e\n', alt_error(1, i));
    %}
end





figure('name', 'Attitude Error');
subplot(3, 1, 1), plot(time_error(1 : end), pitch_error(1 : end)), title('Pitch');
subplot(3, 1, 2), plot(time_error(1 : end), roll_error(1 : end)), title('Roll');
subplot(3, 1, 3), plot(time_error(1 : end), yaw_error(1 : end)), title('Yaw');

figure('name', 'Velocity Error');
subplot(3, 1, 1), plot(time_error(1 : end), ve_error(1 : end)), title('East');
subplot(3, 1, 2), plot(time_error(1 : end), vn_error(1 : end)), title('North');
subplot(3, 1, 3), plot(time_error(1 : end), vu_error(1 : end)), title('Up');

figure('name', 'Position Error');
subplot(3, 1, 1), plot(time_error(1 : end), la_error(1 : end)), title('Latitude');
subplot(3, 1, 2), plot(time_error(1 : end), lon_error(1 : end)), title('Longitude');
subplot(3, 1, 3), plot(time_error(1 : end), alt_error(1 : end)), title('Altitude');

%fclose(file_error);

