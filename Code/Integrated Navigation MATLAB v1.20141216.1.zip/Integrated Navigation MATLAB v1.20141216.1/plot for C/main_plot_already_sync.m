close all;
clear all;


SAMPLING_RATE_IMU = 100; % 100Hz
TIME_INTERVAL_IMU = 0.01; % 0.01s

SAMPLING_RATE_GPS = 10; % 100Hz
TIME_INTERVAL_GPS = 0.1; % 0.1s


% Relay before using feedback correction
RELAY_BEFORE_FEEDBACK_CORRECTION = 0 * 60 / TIME_INTERVAL_IMU;

% Global definition
wie = 7.292115147e-5; % rad/s
Re = 6378245; % Earth radius, m
e = 1 / 298.3; % Earth eccentrity
g0 = 9.7803267714; % m/s^2
gk1 = 0.00193185138639;
gk2 = 0.00669437999013;

% Unit conversion
unit_degree2rad = (pi / 180); % degrees to rad
unit_w = (pi / 3600 / 180); % degrees/h to rad/s
unit_ug = (g0 * 10 ^ (-6)); % ug to m/s^2





% Import results

data_kf = importdata('../../Data/already sync/already_sync_kf.dat');
len_kf = length(data_kf);
time_kf = data_kf( : , 1)';
pitch_kf = data_kf( : , 2)';
roll_kf = data_kf( : , 3)';
yaw_kf = data_kf( : , 4)';
ve_kf = data_kf( : , 5)';
vn_kf = data_kf( : , 6)';
vu_kf = data_kf( : , 7)';
la_kf = data_kf( : , 8)';
lon_kf = data_kf( : , 9)';
alt_kf = data_kf( : , 10)';


data_es = importdata('../../Data/already sync/already_sync_es.dat');
len_es = length(data_es);
time_es = data_es( : , 1)';
es = zeros(15, len_es);
for i = 1 : 15
    es(i, : ) = data_es( : , i + 1)';
end


data_var = importdata('../../Data/already sync/already_sync_var.dat');
len_var = length(data_var);
time_var = data_var( : , 1)';
var = zeros(15, len_var);
for i = 1 : 15
    var(i, : ) = data_var( : , i + 1)';
end






figure('name', 'Position');
subplot(3, 1, 1),
plot(time_kf(1 : end), la_kf(1 : end), 'Color', 'b'), hold on;
legend('KF'); title('latitude');
subplot(3, 1, 2),
plot(time_kf(1 : end), lon_kf(1 : end), 'Color', 'b'), hold on;
legend('KF'); title('longitude');
subplot(3, 1, 3),
plot(time_kf(1 : end), alt_kf(1 : end), 'Color', 'b'), hold on;
legend('KF'); title('Altitude');

figure('name', 'Velocity');
subplot(3, 1, 1),
plot(time_kf(1 : end), ve_kf(1 : end), 'Color', 'b'), hold on;
legend('KF'); title('east');
subplot(3, 1, 2),
plot(time_kf(1 : end), vn_kf(1 : end), 'Color', 'b'), hold on;
legend('KF'); title('north');
subplot(3, 1, 3),
plot(time_kf(1 : end), vu_kf(1 : end), 'Color', 'b'), hold on;
legend('KF'); title('up');

figure('name', 'Attitude');
subplot(3, 1, 1),
plot(time_kf(1 : end), roll_kf(1 : end), 'Color', 'b'), hold on;
legend('KF'); title('roll');
subplot(3, 1, 2),
plot(time_kf(1 : end), pitch_kf(1 : end), 'Color', 'b'), hold on;
legend('KF'); title('pitch');
subplot(3, 1, 3),
plot(time_kf(1 : end), yaw_kf(1 : end), 'Color', 'b'), hold on;
legend('KF'); title('yaw');



figure('name', 'Kalman Filtering Estimation');
subplot(5, 3, 1), plot(time_es(1 : end), es(1, 1 : end)), title('Tilt east');
subplot(5, 3, 2), plot(time_es(1 : end), es(2, 1 : end)), title('Tilt north');
subplot(5, 3, 3), plot(time_es(1 : end), es(3, 1 : end)), title('Tilt up');
subplot(5, 3, 4), plot(time_es(1 : end), es(4, 1 : end)), title('Velocity es east');
subplot(5, 3, 5), plot(time_es(1 : end), es(5, 1 : end)), title('Velocity es north');
subplot(5, 3, 6), plot(time_es(1 : end), es(6, 1 : end)), title('Velocity es up');
subplot(5, 3, 7), plot(time_es(1 : end), es(7, 1 : end)), title('Latitude es');
subplot(5, 3, 8), plot(time_es(1 : end), es(8, 1 : end)), title('Longitude es');
subplot(5, 3, 9), plot(time_es(1 : end), es(9, 1 : end)), title('Height es');
subplot(5, 3, 10), plot(time_es(1 : end), es(10, 1 : end)), title('Gyroscope bias east');
subplot(5, 3, 11), plot(time_es(1 : end), es(11, 1 : end)), title('Gyroscope bias north');
subplot(5, 3, 12), plot(time_es(1 : end), es(12, 1 : end)), title('Gyroscope bias up');
subplot(5, 3, 13), plot(time_es(1 : end), es(13, 1 : end)), title('Accelerometer bias east');
subplot(5, 3, 14), plot(time_es(1 : end), es(14, 1 : end)), title('Accelerometer bias north');
subplot(5, 3, 15), plot(time_es(1 : end), es(15, 1 : end)), title('Accelerometer bias up');




figure('name', 'Mean Square Error of Estimation');
subplot(5, 3, 1), plot(time_var(1 : end), var(1, 1 : end)), title('Tilt east');
subplot(5, 3, 2), plot(time_var(1 : end), var(2, 1 : end)), title('Tilt north');
subplot(5, 3, 3), plot(time_var(1 : end), var(3, 1 : end)), title('Tilt up');
subplot(5, 3, 4), plot(time_var(1 : end), var(4, 1 : end)), title('Velocity es east');
subplot(5, 3, 5), plot(time_var(1 : end), var(5, 1 : end)), title('Velocity es north');
subplot(5, 3, 6), plot(time_var(1 : end), var(6, 1 : end)), title('Velocity es up');
subplot(5, 3, 7), plot(time_var(1 : end), var(7, 1 : end)), title('Latitude es');
subplot(5, 3, 8), plot(time_var(1 : end), var(8, 1 : end)), title('Longitude es');
subplot(5, 3, 9), plot(time_var(1 : end), var(9, 1 : end)), title('Height es');
subplot(5, 3, 10), plot(time_var(1 : end), var(10, 1 : end)), title('Gyroscope bias east');
subplot(5, 3, 11), plot(time_var(1 : end), var(11, 1 : end)), title('Gyroscope bias north');
subplot(5, 3, 12), plot(time_var(1 : end), var(12, 1 : end)), title('Gyroscope bias up');
subplot(5, 3, 13), plot(time_var(1 : end), var(13, 1 : end)), title('Accelerometer bias east');
subplot(5, 3, 14), plot(time_var(1 : end), var(14, 1 : end)), title('Accelerometer bias north');
subplot(5, 3, 15), plot(time_var(1 : end), var(15, 1 : end)), title('Accelerometer bias up');








