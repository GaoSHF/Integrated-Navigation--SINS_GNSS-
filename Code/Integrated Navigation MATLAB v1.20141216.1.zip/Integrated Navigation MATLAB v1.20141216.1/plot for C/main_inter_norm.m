close all;
clear all;


SAMPLING_RATE_IMU = 100; % 100Hz
TIME_INTERVAL_IMU = 0.01; % 0.01s

SAMPLING_RATE_GPS = 10; % 100Hz
TIME_INTERVAL_GPS = 0.1; % 0.1s


% Relay before using feedback correction
RELAY_BEFORE_FEEDBACK_CORRECTION = 0 * 60 / TIME_INTERVAL_IMU;

% Global definition
wie = 7.292115147e-5; % rad/s
Re = 6378245; % Earth radius, m
e = 1 / 298.3; % Earth eccentrity
g0 = 9.7803267714; % m/s^2
gk1 = 0.00193185138639;
gk2 = 0.00669437999013;

% Unit conversion
unit_degree2rad = (pi / 180); % degrees to rad
unit_w = (pi / 3600 / 180); % degrees/h to rad/s
unit_ug = (g0 * 10 ^ (-6)); % ug to m/s^2

SWITCH_DATA = 0;
SWITCH_TYPE = 0;


if SWITCH_DATA == 0
    data_norm = importdata('../../Data/201401031452 (GPS L1 Static)/nav_normal.dat');
    file_norm2 = fopen('../../Data/201401031452 (GPS L1 Static)/nav_normal2.dat', 'w');
elseif SWITCH_DATA == 1
    data_norm = importdata('../../Data/201401031508 (GPS L1 Vn 1g 300)/nav_normal.dat');
    file_norm2 = fopen('../../Data/201401031508 (GPS L1 Vn 1g 300)/nav_normal2.dat', 'w');
elseif SWITCH_DATA == 2
    data_norm = importdata('../../Data/201401031519 (GPS L1 Vn 1g 300 6g 900)/nav_normal.dat');
    file_norm2 = fopen('../../Data/201401031519 (GPS L1 Vn 1g 300 6g 900)/nav_normal2.dat', 'w');
elseif SWITCH_DATA == 3
    data_norm = importdata('../../Data/201401031548 (GPS L1 Vn 1g 300 6g 1200)/nav_normal.dat');
    file_norm2 = fopen('../../Data/201401031548 (GPS L1 Vn 1g 300 6g 1200)/nav_normal2.dat', 'w');
elseif SWITCH_DATA == 4
    data_norm = importdata('../../Data/201401031607 (GPS L1 Vn 1g 300 4g 900)/nav_normal.dat');
    file_norm2 = fopen('../../Data/201401031607 (GPS L1 Vn 1g 300 4g 900)/nav_normal2.dat', 'w');
elseif SWITCH_DATA == 5
    data_norm = importdata('../../Data/201401031355 (BD B3 Vn 300)/nav_normal.dat');
    file_norm2 = fopen('../../Data/201401031355 (BD B3 Vn 300)/nav_normal2.dat', 'w');
end


if SWITCH_TYPE == 0
    data_kf = importdata('../../Data/results_kf.dat');
elseif SWITCH_TYPE == 1
    data_kf = importdata('../../Data/results_ukf.dat');
elseif SWITCH_TYPE == 2
    data_kf = importdata('../../Data/results_hinfukf.dat');
elseif SWITCH_TYPE == 3
    data_kf = importdata('../../Data/results_qlcukf.dat');
elseif SWITCH_TYPE == 4
    data_kf = importdata('../../Data/results_qtcukf.dat');
end




% Import normal navigation results
len_norm = length(data_norm);
time_norm = data_norm( : , 1)';
pitch_norm = data_norm( : , 2)';
roll_norm = data_norm( : , 3)';
yaw_norm = data_norm( : , 4)';
ve_norm = data_norm( : , 5)';
vn_norm = data_norm( : , 6)';
vu_norm = data_norm( : , 7)';
la_norm = data_norm( : , 8)';
lon_norm = data_norm( : , 9)';
alt_norm = data_norm( : , 10)';



% Import KF navigation results
len_kf = length(data_kf);
time_kf = data_kf( : , 1)';
pitch_kf = data_kf( : , 2)';
roll_kf = data_kf( : , 3)';
yaw_kf = data_kf( : , 4)';
ve_kf = data_kf( : , 5)';
vn_kf = data_kf( : , 6)';
vu_kf = data_kf( : , 7)';
la_kf = data_kf( : , 8)';
lon_kf = data_kf( : , 9)';
alt_kf = data_kf( : , 10)';

% Normal navigation results after interpolation
time_inter = time_kf;
pitch_inter = zeros(1, len_kf);
roll_inter = zeros(1, len_kf);
yaw_inter = zeros(1, len_kf);
ve_inter = zeros(1, len_kf);
vn_inter = zeros(1, len_kf);
vu_inter = zeros(1, len_kf);
la_inter = zeros(1, len_kf);
lon_inter = zeros(1, len_kf);
alt_inter = zeros(1, len_kf);


j = 1;
time_norm_pre = time_norm(1, j);
time_norm_after = time_norm(1, j);
for i = 1 : len_kf
    % Find right time position
    while time_norm_after < time_kf(1, i);
        j = j + 1;
        time_norm_pre = time_norm_after;
        time_norm_after = time_norm(1, j);
    end
    
    % Interpolation
    pitch_inter(1, i) = (pitch_norm(1, j) - pitch_norm(1, j - 1)) / (time_norm(1, j) - time_norm(1, j - 1)) * (time_kf(1, i) - time_norm(1, j - 1)) + pitch_norm(1, j - 1);
    roll_inter(1, i) = (roll_norm(1, j) - roll_norm(1, j - 1)) / (time_norm(1, j) - time_norm(1, j - 1)) * (time_kf(1, i) - time_norm(1, j - 1)) + roll_norm(1, j - 1);
    yaw_inter(1, i) = (yaw_norm(1, j) - yaw_norm(1, j - 1)) / (time_norm(1, j) - time_norm(1, j - 1)) * (time_kf(1, i) - time_norm(1, j - 1)) + yaw_norm(1, j - 1);
    ve_inter(1, i) = (ve_norm(1, j) - ve_norm(1, j - 1)) / (time_norm(1, j) - time_norm(1, j - 1)) * (time_kf(1, i) - time_norm(1, j - 1)) + ve_norm(1, j - 1);
    vn_inter(1, i) = (vn_norm(1, j) - vn_norm(1, j - 1)) / (time_norm(1, j) - time_norm(1, j - 1)) * (time_kf(1, i) - time_norm(1, j - 1)) + vn_norm(1, j - 1);
    vu_inter(1, i) = (vu_norm(1, j) - vu_norm(1, j - 1)) / (time_norm(1, j) - time_norm(1, j - 1)) * (time_kf(1, i) - time_norm(1, j - 1)) + vu_norm(1, j - 1);
    la_inter(1, i) = (la_norm(1, j) - la_norm(1, j - 1)) / (time_norm(1, j) - time_norm(1, j - 1)) * (time_kf(1, i) - time_norm(1, j - 1)) + la_norm(1, j - 1);
    lon_inter(1, i) = (lon_norm(1, j) - lon_norm(1, j - 1)) / (time_norm(1, j) - time_norm(1, j - 1)) * (time_kf(1, i) - time_norm(1, j - 1)) + lon_norm(1, j - 1);
    alt_inter(1, i) = (alt_norm(1, j) - alt_norm(1, j - 1)) / (time_norm(1, j) - time_norm(1, j - 1)) * (time_kf(1, i) - time_norm(1, j - 1)) + alt_norm(1, j - 1);
    
    % Record interpolation data
    fprintf(file_norm2, '%f\t', time_inter(1, i));
    fprintf(file_norm2, '%e\t', pitch_inter(1, i));
    fprintf(file_norm2, '%e\t', roll_inter(1, i));
    fprintf(file_norm2, '%e\t', yaw_inter(1, i));
    fprintf(file_norm2, '%e\t', ve_inter(1, i));
    fprintf(file_norm2, '%e\t', vn_inter(1, i));
    fprintf(file_norm2, '%e\t', vu_inter(1, i));
    fprintf(file_norm2, '%e\t', la_inter(1, i));
    fprintf(file_norm2, '%e\t', lon_inter(1, i));
    fprintf(file_norm2, '%e\n', alt_inter(1, i));

end




figure('name', 'Position');
subplot(3, 1, 1),
plot(time_norm(1 : end), la_norm(1 : end), 'Color', 'r'), hold on;
plot(time_inter(1 : end), la_inter(1 : end), 'Color', 'g'), hold on;
plot(time_kf(1 : end), la_kf(1 : end), 'Color', 'b'), hold on;
legend('Normal', 'Normal2', 'KF'); title('latitude');
subplot(3, 1, 2),
plot(time_norm(1 : end), lon_norm(1 : end), 'Color', 'r'), hold on;
plot(time_inter(1 : end), lon_inter(1 : end), 'Color', 'g'), hold on;
plot(time_kf(1 : end), lon_kf(1 : end), 'Color', 'b'), hold on;
legend('Normal', 'Normal2', 'KF'); title('longitude');
subplot(3, 1, 3),
plot(time_norm(1 : end), alt_norm(1 : end), 'Color', 'r'), hold on;
plot(time_inter(1 : end), alt_inter(1 : end), 'Color', 'g'), hold on;
plot(time_kf(1 : end), alt_kf(1 : end), 'Color', 'b'), hold on;
legend('Normal', 'Normal2', 'KF'); title('Altitude');

figure('name', 'Velocity');
subplot(3, 1, 1),
plot(time_norm(1 : end), ve_norm(1 : end), 'Color', 'r'), hold on;
plot(time_inter(1 : end), ve_inter(1 : end), 'Color', 'g'), hold on;
plot(time_kf(1 : end), ve_kf(1 : end), 'Color', 'b'), hold on;
legend('Normal', 'Normal2', 'KF'); title('east');
subplot(3, 1, 2),
plot(time_norm(1 : end), vn_norm(1 : end), 'Color', 'r'), hold on;
plot(time_inter(1 : end), vn_inter(1 : end), 'Color', 'g'), hold on;
plot(time_kf(1 : end), vn_kf(1 : end), 'Color', 'b'), hold on;
legend('Normal', 'Normal2', 'KF'); title('north');
subplot(3, 1, 3),
plot(time_norm(1 : end), vu_norm(1 : end), 'Color', 'r'), hold on;
plot(time_inter(1 : end), vu_inter(1 : end), 'Color', 'g'), hold on;
plot(time_kf(1 : end), vu_kf(1 : end), 'Color', 'b'), hold on;
legend('Normal', 'Normal2', 'KF'); title('up');

figure('name', 'Attitude');
subplot(3, 1, 1),
plot(time_norm(1 : end), pitch_norm(1 : end), 'Color', 'r'), hold on;
plot(time_inter(1 : end), pitch_inter(1 : end), 'Color', 'r'), hold on;
plot(time_kf(1 : end), pitch_kf(1 : end), 'Color', 'b'), hold on;
legend('Normal', 'KF'); title('pitch');
subplot(3, 1, 2),
plot(time_norm(1 : end), roll_norm(1 : end), 'Color', 'r'), hold on;
plot(time_inter(1 : end), roll_inter(1 : end), 'Color', 'r'), hold on;
plot(time_kf(1 : end), roll_kf(1 : end), 'Color', 'b'), hold on;
legend('Normal', 'KF'); title('roll');
subplot(3, 1, 3),
plot(time_norm(1 : end), yaw_norm(1 : end), 'Color', 'r'), hold on;
plot(time_inter(1 : end), yaw_inter(1 : end), 'Color', 'r'), hold on;
plot(time_kf(1 : end), yaw_kf(1 : end), 'Color', 'b'), hold on;
legend('Normal', 'KF'); title('yaw');


fclose(file_norm2);

