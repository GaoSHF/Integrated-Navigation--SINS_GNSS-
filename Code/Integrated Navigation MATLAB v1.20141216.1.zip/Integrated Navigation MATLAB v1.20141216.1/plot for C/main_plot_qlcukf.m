close all;
clear all;


SAMPLING_RATE_IMU = 100; % 100Hz
TIME_INTERVAL_IMU = 0.01; % 0.01s

SAMPLING_RATE_GPS = 10; % 100Hz
TIME_INTERVAL_GPS = 0.1; % 0.1s


% Relay before using feedback correction
RELAY_BEFORE_FEEDBACK_CORRECTION = 0 * 60 / TIME_INTERVAL_IMU;

% Global definition
wie = 7.292115147e-5; % rad/s
Re = 6378245; % Earth radius, m
e = 1 / 298.3; % Earth eccentrity
g0 = 9.7803267714; % m/s^2
gk1 = 0.00193185138639;
gk2 = 0.00669437999013;

% Unit conversion
unit_degree2rad = (pi / 180); % degrees to rad
unit_w = (pi / 3600 / 180); % degrees/h to rad/s
unit_ug = (g0 * 10 ^ (-6)); % ug to m/s^2



SWITCH_FILE = 3;

if SWITCH_FILE == 0
    data_norm = importdata('../../Data/201401031452 (GPS L1 Static)/nav_normal2.dat');
    data_gnss = importdata('../../Data/201401031452 (GPS L1 Static)/nav_gnss.dat');
elseif SWITCH_FILE == 1
    data_norm = importdata('../../Data/201401031508 (GPS L1 Vn 1g 300)/nav_normal2.dat');
    data_gnss = importdata('../../Data/201401031508 (GPS L1 Vn 1g 300)/nav_gnss.dat');
elseif SWITCH_FILE == 2
    data_norm = importdata('../../Data/201401031519 (GPS L1 Vn 1g 300 6g 900)/nav_normal2.dat');
    data_gnss = importdata('../../Data/201401031519 (GPS L1 Vn 1g 300 6g 900)/nav_gnss.dat');
elseif SWITCH_FILE == 3
    data_norm = importdata('../../Data/201401031548 (GPS L1 Vn 1g 300 6g 1200)/nav_normal2.dat');
    data_gnss = importdata('../../Data/201401031548 (GPS L1 Vn 1g 300 6g 1200)/nav_gnss.dat');
elseif SWITCH_FILE == 4
    data_norm = importdata('../../Data/201401031607 (GPS L1 Vn 1g 300 4g 900)/nav_normal2.dat');
    data_gnss = importdata('../../Data/201401031607 (GPS L1 Vn 1g 300 4g 900)/nav_gnss.dat');
elseif SWITCH_FILE == 5
    data_norm = importdata('../../Data/201401031355 (BD B3 Vn 300)/nav_normal2.dat');
    data_gnss = importdata('../../Data/201401031355 (BD B3 Vn 300)/nav_gnss.dat');
end




% Import normal navigation results
len_norm = length(data_norm);
time_norm = data_norm( : , 1)';
pitch_norm = data_norm( : , 2)';
roll_norm = data_norm( : , 3)';
yaw_norm = data_norm( : , 4)';
ve_norm = data_norm( : , 5)';
vn_norm = data_norm( : , 6)';
vu_norm = data_norm( : , 7)';
la_norm = data_norm( : , 8)';
lon_norm = data_norm( : , 9)';
alt_norm = data_norm( : , 10)';


% Import GNSS navigation results
len_gnss = length(data_gnss);
time_gnss = data_gnss( : , 1)';
la_gnss = data_gnss( : , 2)';
lon_gnss = data_gnss( : , 3)';
alt_gnss = data_gnss( : , 4)';
ve_gnss = data_gnss( : , 5)';
vn_gnss = data_gnss( : , 6)';
vu_gnss = data_gnss( : , 7)';

% Import KF navigation results
data_kf = importdata('../../Data/results_qlcukf.dat');
len_kf = length(data_kf);
time_kf = data_kf( : , 1)';
pitch_kf = data_kf( : , 2)';
roll_kf = data_kf( : , 3)';
yaw_kf = data_kf( : , 4)';
ve_kf = data_kf( : , 5)';
vn_kf = data_kf( : , 6)';
vu_kf = data_kf( : , 7)';
la_kf = data_kf( : , 8)';
lon_kf = data_kf( : , 9)';
alt_kf = data_kf( : , 10)';


data_es = importdata('../../Data/es_qlcukf.dat');
len_es = length(data_es);
time_es = data_es( : , 1)';
es = zeros(16, len_es);
for i = 1 : 16
    es(i, : ) = data_es( : , i + 1)';
end


data_var = importdata('../../Data/var_qlcukf.dat');
len_var = length(data_var);
time_var = data_var( : , 1)';
var = zeros(16, len_var);
for i = 1 : 16
    var(i, : ) = data_var( : , i + 1)';
end



% Error of navigation results
time_error = time_kf;
pitch_error = pitch_kf - pitch_norm;
roll_error = roll_kf - roll_norm;
yaw_error = yaw_kf - yaw_norm;
ve_error = ve_kf - ve_norm;
vn_error = vn_kf - vn_norm;
vu_error = vu_kf - vu_norm;
la_error = la_kf - la_norm;
lon_error = lon_kf - lon_norm;
alt_error = alt_kf - alt_norm;




figure('name', 'Position');
subplot(3, 1, 1),
plot(time_norm(1 : end), la_norm(1 : end), 'Color', 'r'), hold on;
plot(time_gnss(1 : end), la_gnss(1 : end), 'Color', 'g'), hold on;
plot(time_kf(1 : end), la_kf(1 : end), 'Color', 'b'), hold on;
legend('Normal', 'GNSS', 'KF'); title('latitude');
subplot(3, 1, 2),
plot(time_norm(1 : end), lon_norm(1 : end), 'Color', 'r'), hold on;
plot(time_gnss(1 : end), lon_gnss(1 : end), 'Color', 'g'), hold on;
plot(time_kf(1 : end), lon_kf(1 : end), 'Color', 'b'), hold on;
legend('Normal', 'GNSS', 'KF'); title('longitude');
subplot(3, 1, 3),
plot(time_norm(1 : end), alt_norm(1 : end), 'Color', 'r'), hold on;
plot(time_gnss(1 : end), alt_gnss(1 : end), 'Color', 'g'), hold on;
plot(time_kf(1 : end), alt_kf(1 : end), 'Color', 'b'), hold on;
legend('Normal', 'GNSS', 'KF'); title('Altitude');

figure('name', 'Velocity');
subplot(3, 1, 1),
plot(time_norm(1 : end), ve_norm(1 : end), 'Color', 'r'), hold on;
plot(time_gnss(1 : end), ve_gnss(1 : end), 'Color', 'g'), hold on;
plot(time_kf(1 : end), ve_kf(1 : end), 'Color', 'b'), hold on;
legend('Normal', 'GNSS', 'KF'); title('east');
subplot(3, 1, 2),
plot(time_norm(1 : end), vn_norm(1 : end), 'Color', 'r'), hold on;
plot(time_gnss(1 : end), vn_gnss(1 : end), 'Color', 'g'), hold on;
plot(time_kf(1 : end), vn_kf(1 : end), 'Color', 'b'), hold on;
legend('Normal', 'GNSS', 'KF'); title('north');
subplot(3, 1, 3),
plot(time_norm(1 : end), vu_norm(1 : end), 'Color', 'r'), hold on;
plot(time_gnss(1 : end), vu_gnss(1 : end), 'Color', 'g'), hold on;
plot(time_kf(1 : end), vu_kf(1 : end), 'Color', 'b'), hold on;
legend('Normal', 'GNSS', 'KF'); title('up');

figure('name', 'Attitude');
subplot(3, 1, 1),
plot(time_norm(1 : end), pitch_norm(1 : end), 'Color', 'r'), hold on;
plot(time_kf(1 : end), pitch_kf(1 : end), 'Color', 'b'), hold on;
legend('Normal', 'KF'); title('pitch');
subplot(3, 1, 2),
plot(time_norm(1 : end), roll_norm(1 : end), 'Color', 'r'), hold on;
plot(time_kf(1 : end), roll_kf(1 : end), 'Color', 'b'), hold on;
legend('Normal', 'KF'); title('roll');
subplot(3, 1, 3),
plot(time_norm(1 : end), yaw_norm(1 : end), 'Color', 'r'), hold on;
plot(time_kf(1 : end), yaw_kf(1 : end), 'Color', 'b'), hold on;
legend('Normal', 'KF'); title('yaw');




figure('name', 'Attitude Error');
subplot(3, 1, 1), plot(time_error(1 : end), pitch_error(1 : end)), title('Pitch');
subplot(3, 1, 2), plot(time_error(1 : end), roll_error(1 : end)), title('Roll');
subplot(3, 1, 3), plot(time_error(1 : end), yaw_error(1 : end)), title('Yaw');

figure('name', 'Velocity Error');
subplot(3, 1, 1), plot(time_error(1 : end), ve_error(1 : end)), title('East');
subplot(3, 1, 2), plot(time_error(1 : end), vn_error(1 : end)), title('North');
subplot(3, 1, 3), plot(time_error(1 : end), vu_error(1 : end)), title('Up');

figure('name', 'Position Error');
subplot(3, 1, 1), plot(time_error(1 : end), la_error(1 : end)), title('Latitude');
subplot(3, 1, 2), plot(time_error(1 : end), lon_error(1 : end)), title('Longitude');
subplot(3, 1, 3), plot(time_error(1 : end), alt_error(1 : end)), title('Altitude');




figure('name', 'Mean Square Error of Quaternion Estimation');
subplot(4, 1, 1), plot(time_var(1 : end), var(1, 1 : end)), title('Q0');
subplot(4, 1, 2), plot(time_var(1 : end), var(2, 1 : end)), title('Q1');
subplot(4, 1, 3), plot(time_var(1 : end), var(3, 1 : end)), title('Q2');
subplot(4, 1, 4), plot(time_var(1 : end), var(4, 1 : end)), title('Q3');


figure('name', 'Mean Square Error of deltaV/deltaP/IMU Estimation');
subplot(4, 3, 1), plot(time_var(1 : end), var(5, 1 : end)), title('Velocity es east');
subplot(4, 3, 2), plot(time_var(1 : end), var(6, 1 : end)), title('Velocity es north');
subplot(4, 3, 3), plot(time_var(1 : end), var(7, 1 : end)), title('Velocity es up');
subplot(4, 3, 4), plot(time_var(1 : end), var(8, 1 : end)), title('Latitude es');
subplot(4, 3, 5), plot(time_var(1 : end), var(9, 1 : end)), title('Longitude es');
subplot(4, 3, 6), plot(time_var(1 : end), var(10, 1 : end)), title('Height es');
subplot(4, 3, 7), plot(time_var(1 : end), var(11, 1 : end)), title('Gyroscope bias east');
subplot(4, 3, 8), plot(time_var(1 : end), var(12, 1 : end)), title('Gyroscope bias north');
subplot(4, 3, 9), plot(time_var(1 : end), var(13, 1 : end)), title('Gyroscope bias up');
subplot(4, 3, 10), plot(time_var(1 : end), var(14, 1 : end)), title('Accelerometer bias east');
subplot(4, 3, 11), plot(time_var(1 : end), var(15, 1 : end)), title('Accelerometer bias north');
subplot(4, 3, 12), plot(time_var(1 : end), var(16, 1 : end)), title('Accelerometer bias up');








