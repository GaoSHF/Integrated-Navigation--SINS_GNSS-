/**************************************************************************/
/* LabWindows/CVI User Interface Resource (UIR) Include File              */
/* Copyright (c) National Instruments 2014. All Rights Reserved.          */
/*                                                                        */
/* WARNING: Do not add to, delete from, or otherwise modify the contents  */
/*          of this include file.                                         */
/**************************************************************************/

#include <userint.h>

#ifdef __cplusplus
    extern "C" {
#endif

     /* Panels and Controls: */

#define  PSUB_INIT                        1       /* callback function: subInitPanelLoad */
#define  PSUB_INIT_NUMERIC_VU0            2
#define  PSUB_INIT_NUMERIC_VN0            3
#define  PSUB_INIT_NUMERIC_YAW0           4
#define  PSUB_INIT_NUMERIC_ROLL0          5
#define  PSUB_INIT_NUMERIC_PITCH0         6
#define  PSUB_INIT_NUMERIC_VE0            7
#define  PSUB_INIT_NUMERIC_ALT0           8
#define  PSUB_INIT_BUTTON_BACK            9       /* callback function: psubInitButtonBack */
#define  PSUB_INIT_NUMERIC_CORR_TIME      10
#define  PSUB_INIT_BUTTON_LOAD            11      /* callback function: psubInitButtonLoad */
#define  PSUB_INIT_BUTTON_SAVE            12      /* callback function: psubInitButtonSave */
#define  PSUB_INIT_NUMERIC_LON0           13
#define  PSUB_INIT_NUMERIC_T_END          14
#define  PSUB_INIT_NUMERIC_T_BEGIN        15
#define  PSUB_INIT_NUMERIC_F_NORM         16
#define  PSUB_INIT_NUMERIC_F_GNSS         17
#define  PSUB_INIT_NUMERIC_F_IMU          18
#define  PSUB_INIT_NUMERIC_LA0            19
#define  PSUB_INIT_TABLE_R                20
#define  PSUB_INIT_TABLE_Q                21
#define  PSUB_INIT_TABLE_CX0              22
#define  PSUB_INIT_TABLE_MX0              23


     /* Menu Bars, Menus, and Menu Items: */

          /* (no menu bars in the resource file) */


     /* Callback Prototypes: */

int  CVICALLBACK psubInitButtonBack(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK psubInitButtonLoad(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK psubInitButtonSave(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK subInitPanelLoad(int panel, int event, void *callbackData, int eventData1, int eventData2);


#ifdef __cplusplus
    }
#endif
