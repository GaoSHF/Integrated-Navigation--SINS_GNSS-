

% Global definition
wie = 7.292115147e-5; % rad/s
Re = 6378245; % Earth radius, m
e = 1 / 298.3; % Earth eccentrity
g0 = 9.7803267714; % m/s^2
gk1 = 0.00193185138639;
gk2 = 0.00669437999013;

% Unit conversion
unit_degree2rad = (pi / 180); % degrees to rad
unit_w = (pi / 3600 / 180); % degrees/h to rad/s
unit_ug = (g0 * 10 ^ (-6)); % ug to m/s^2



%% Unit refresh
PitchNav = PitchNav / unit_degree2rad;
RollNav = RollNav / unit_degree2rad;
YawNav = YawNav / unit_degree2rad;

LaNav = LaNav / unit_degree2rad;
LonNav = LonNav / unit_degree2rad;


len = length(TimeNav);
time = TimeNav * 0.001;
for i = len : (-1) : 1
    time(1, i) = time(1, i) - time(1, 1);
end


%% Drawing results
disp('Drawing results begin.');
tic;


figure('name', 'Attitude');
subplot(3, 1, 1), 
plot(time(1, 1 : len), PitchNav(1, 1 : len), 'Color', 'k'), hold on;
xlabel('Time/s'), ylabel('Pitch/degree'); grid on;
subplot(3, 1, 2), 
plot(time(1, 1 : len), RollNav(1, 1 : len), 'Color', 'k'), hold on;
xlabel('Time/s'), ylabel('Roll/degree'); grid on;
subplot(3, 1, 3), 
plot(time(1, 1 : len), YawNav(1, 1 : len), 'Color', 'k'), hold on;
xlabel('Time/s'), ylabel('Yaw/degree'); grid on;

figure('name', 'Velocity');
subplot(3, 1, 1), 
plot(time(1, 1 : len), VeNav(1, 1 : len), 'Color', 'k'), hold on;
xlabel('Time/s'), ylabel('East/m/s'); grid on;
subplot(3, 1, 2), 
plot(time(1, 1 : len), VnNav(1, 1 : len), 'Color', 'k'), hold on;
xlabel('Time/s'), ylabel('North/m/s'); grid on;
subplot(3, 1, 3), 
plot(time(1, 1 : len), VuNav(1, 1 : len), 'Color', 'k'), hold on;
xlabel('Time/s'), ylabel('Up/m/s'); grid on;

figure('name', 'Position');
subplot(3, 1, 1), 
plot(time(1, 1 : len), LaNav(1, 1 : len), 'Color', 'k'), hold on;
xlabel('Time/s'), ylabel('Latitude/degree'); grid on;
subplot(3, 1, 2), 
plot(time(1, 1 : len), LonNav(1, 1 : len), 'Color', 'k'), hold on;
xlabel('Time/s'), ylabel('Longitude/degree'); grid on;
subplot(3, 1, 3), 
plot(time(1, 1 : len), AltNav(1, 1 : len), 'Color', 'k'), hold on;
xlabel('Time/s'), ylabel('Altitude/m'); grid on;




RuntimeDraw = toc;
disp(['Drawing results running time = ', num2str(RuntimeDraw), 's']);





