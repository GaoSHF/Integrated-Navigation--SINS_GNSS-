
//==============================================================================
//
// Title:       sins_gnss_compare_main.c
// Purpose:     A short description of the implementation.
//
// Created on:  2013/11/25 at 15:29:17 by ZhaoHengyang.
// Copyright:   Beihang University. All Rights Reserved.
//
//==============================================================================

//==============================================================================
// Include files
// CVI generated .h files
#include "main_entry.h"
#include "sub_init.h"
#include "sub_prog.h"

// CVI library .h files
#include <cviauto.h>
#include <formatio.h>
#include <ansi_c.h> 
#include <userint.h>
#include <toolbox.h>

// Other .h files
#include "matlabUtil.h"
#include "mat_server.h"
#include "sins_gnss.h"
#include "matrix.h"



//==============================================================================
// Constants
#define ALLOC_LENGTH_INTERVAL			10000
#define	ALLOC_LENGTH(count)				((long long)(count / ALLOC_LENGTH_INTERVAL) + 1) * ALLOC_LENGTH_INTERVAL
#define	ALLOC_SIZE						0
#define	ALLOC_LENGTH_OLD				0
#define	ALLOC_NEW_SIZE(x)				0

#define STRING_LENGTH_MAX				5000


#define	pi		3.14159265358979323846
#define	unit_rad2degree			(180 / pi)
		
		
#define	SIZE_X					15
#define	SIZE_Z					6
#define	SIZE_W					6
#define	SIZE_V					6



//==============================================================================
// Types

//==============================================================================
// Static global variables

//==============================================================================
// Static functions

//==============================================================================
// Global variables
// Panel variables
int HandlePmain;
int HandlePsubInit; 
int HandlePsubProg;


static int TextBoxLineIndex = 0; // text box index variable

// Sensor data variables
int ValidData = 0;
int ValidDir = 0;
int ValidFileGnss = 0;
int ValidFileImu = 0;
int ValidFileNorm = 0;

int ValidInitFile = 0;

char PathDir[500];
char PathFileGnss[500];
char PathFileImu[500];
char PathFileNorm[500];
char PathTempInput[MAX_PATHNAME_LEN];
char PathTempOutput[MAX_PATHNAME_LEN];

FILE *FileHandleGnss = NULL;
FILE *FileHandleImu = NULL;
FILE *FileHandleNorm = NULL;
FILE *FileHandleTest = NULL;

int LengthImport = 0;
int LengthGnss = 0;
int LengthImu = 0;
int LengthGnssFixed = 0;
int LengthNorm = 0;
int LengthNav = 0;
int LengthEst = 0;


IMU_MEASUREMENT 	MeasurementIMU;

GNSS_NAV_PARAM		*NavParamGnss;
double *TimePps = NULL;

INS_NAV_PARAM 		NavParamOld, NavParamNew;

KF_PARAM			KfParamOld, KfParamNew;



double *TimeImu = NULL;
double *Wibbx = NULL;
double *Wibby = NULL;
double *Wibbz = NULL;
double *Fbx = NULL;
double *Fby = NULL;
double *Fbz = NULL;

double *TimeGnssFixed = NULL;
double *LaGnssFixed = NULL; // degrees
double *LonGnssFixed = NULL;
double *AltGnssFixed = NULL;
double *VeGnssFixed = NULL;
double *VnGnssFixed = NULL;
double *VuGnssFixed = NULL;

double *TimeNav = NULL;
double *PitchNav = NULL; // degrees
double *RollNav = NULL;
double *YawNav = NULL;
double *VeNav = NULL; // m/s
double *VnNav = NULL;
double *VuNav = NULL;
double *LaNav = NULL; // degrees
double *LonNav = NULL;
double *AltNav = NULL; // m

double *TimeNorm = NULL;
double *PitchNorm = NULL; // degrees
double *RollNorm = NULL;
double *YawNorm = NULL;
double *VeNorm = NULL; // m/s
double *VnNorm = NULL;
double *VuNorm = NULL;
double *LaNorm = NULL; // degrees
double *LonNorm = NULL;
double *AltNorm = NULL; // m

double *TimeEst = NULL;
double *PMSE[SIZE_X];



// External variables
		
// Initialization data variables

FILE *FileHandleInit;
		
INS_INIT_PARAM		InitParamSins;

KF_INIT_PARAM		InitParamKF;



static CAObjHandle  HandleMatlab = 0; // matlab handle

int StatusMatlab = 0; // matlab opened or closed


int FlagInit = 0;
int FlagNavMode = 1;

int StatusButtonSinsOld;
int StatusButtonSinsNew;
int StatusButtonKfOld;
int StatusButtonKfNew;

char PathTemp[300];
char *PieceTemp2 = NULL;
char StringTemp[STRING_LENGTH_MAX];


double TimeSimuBegin = 0; // default 100s
double TimeSimuEnd = 100; // default 100s
double FrequencyNorm = 100; // default 100Hz






//==============================================================================
// Global functions
int ErrFunc(HRESULT errCode, char *errMesg);
int CloseMatlab(CAObjHandle *hMatlabPtr);
int UIRDimming(int state);

int CheckMatlab(void);
int CheckPlot(void);
int CheckMemory(void);

static int GetDataImu(void);
static int GetDataGnss(void);
static int GetDataNorm(void);

static int InitNavParam(void);
static int Nav(void);


int ImportInitData(void);
int ExportInitData(void);

int SelectInitFile(void);
int SelectDataFolder(void);


/*
	main entry
 */
int main (int argc, char *argv[])
{
     
	int error = 0;
	
    /* initialize and load resources */
    nullChk (InitCVIRTE (0, argv, 0));
    errChk (HandlePmain = LoadPanel (0, "main_entry.uir", PANEL));
	
	
    /* display the panel and run the user interface */
    errChk (DisplayPanel (HandlePmain));
    errChk (RunUserInterface ());
	
Error:
    /* clean up */
    DiscardPanel (HandlePmain);
    return 0;
}



//****************************************** main panel callback function ******************************//
/*
	Exit button callback function
 */
int CVICALLBACK buttonExit (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{

	switch (event)
	{
		case EVENT_COMMIT:

			
			CheckMemory();
			
			CheckPlot();
			CheckMatlab();
			
			QuitUserInterface(0);
			
			break;
	}
	return 0;
}



/*
	Select data file folder
*/
int SelectDataFolder(void)
{
	
	ValidDir = DirSelectPopup ("..\\..\\..\\Integrated Navigation Data", 
				"ѡ�����������ļ���", 1, 0, PathDir);
		
	if (ValidDir == VAL_DIRECTORY_SELECTED)
	{
		strcpy(PathFileGnss, PathDir);
		strcat(PathFileGnss, "\\gnss429.txt");
		strcpy(PathFileImu, PathDir);
		strcat(PathFileImu, "\\pulse.txt");
		strcpy(PathFileNorm, PathDir);
		strcat(PathFileNorm, "\\trace.txt");
		
		ValidFileGnss = FileExists (PathFileGnss, 0);
		ValidFileImu = FileExists (PathFileImu, 0);
		ValidFileNorm = FileExists (PathFileNorm, 0);
	}
	
	if ((ValidDir == VAL_DIRECTORY_SELECTED) && (ValidFileGnss == 1) && (ValidFileImu == 1) && (ValidFileNorm == 1))
	{
		ValidData = 1;
		
		SetCtrlVal (HandlePmain, PANEL_STRING_PATH_DATA, PathDir);
	}
	else
	{
		ValidData = 0;
		
		SetCtrlVal (HandlePmain, PANEL_STRING_PATH_DATA, "");
	}
	
	return 0;
}



/*
	Select initialization file
*/
int SelectInitFile(void)
{
	
	ValidInitFile = FileSelectPopup(".\\", "*.txt", "*.txt",
                    "ѡ���ʼ���ļ�", VAL_OK_BUTTON, 0, 1,
                    1, 1, PathTempInput);

	if (ValidInitFile != VAL_NO_FILE_SELECTED)
	{
		SetCtrlVal (HandlePmain, PANEL_STRING_PATH_INIT, PathTempInput);
	
		FlagInit = 1;
	}
	
	return 0;
}



/*
	Select data file folder button callback function
 */
int CVICALLBACK buttonSelectData (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
		  int fileSize;
	switch (event)
	{
		case EVENT_COMMIT:
			
			SelectDataFolder();
							   
			break;
	}
	return 0;
}



/*
	Select initialization file button callback function
 */
int CVICALLBACK buttonSelectInit (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
		  int fileSize;
	switch (event)
	{
		case EVENT_COMMIT:
			
			SelectInitFile();
			
			break;
	}
	return 0;
}



/*
	Initialization (sub panel)
 */
int CVICALLBACK buttonInit (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	
	switch (event)
	{
		case EVENT_COMMIT:
			
			// Install sub panel
			HandlePsubInit = LoadPanel (PANEL, "sub_init.uir", PSUB_INIT);
			
			if (FlagInit == 1)
			{
				ImportInitData();
				
				// Set sensor information
				/*SetCtrlVal (HandlePsubInit, PSUB_INIT_NUMERIC_F_IMU, 1 / InitParamSins.time_interval);
				SetCtrlVal (HandlePsubInit, PSUB_INIT_NUMERIC_F_GNSS, 1 / InitParamKF.T);
			
				// Set initialization data
				SetCtrlVal (HandlePsubInit, PSUB_INIT_NUMERIC_LA0, InitParamSins.la0 * unit_rad2degree);
				SetCtrlVal (HandlePsubInit, PSUB_INIT_NUMERIC_LON0, InitParamSins.lon0 * unit_rad2degree);
				SetCtrlVal (HandlePsubInit, PSUB_INIT_NUMERIC_ALT0, InitParamSins.h0);
	
				SetCtrlVal (HandlePsubInit, PSUB_INIT_NUMERIC_VE0, InitParamSins.ve0);
				SetCtrlVal (HandlePsubInit, PSUB_INIT_NUMERIC_VN0, InitParamSins.vn0);
				SetCtrlVal (HandlePsubInit, PSUB_INIT_NUMERIC_VU0, InitParamSins.vu0);
	
				SetCtrlVal (HandlePsubInit, PSUB_INIT_NUMERIC_PITCH0, InitParamSins.pitch0 * unit_rad2degree);
				SetCtrlVal (HandlePsubInit, PSUB_INIT_NUMERIC_ROLL0, InitParamSins.roll0 * unit_rad2degree);
				SetCtrlVal (HandlePsubInit, PSUB_INIT_NUMERIC_YAW0, InitParamSins.yaw0 * unit_rad2degree);*/
			}
			
			// Wait until quit the sub panel
			InstallPopup (HandlePsubInit);
			
			
			break;
	}
	return 0;
}



/*
	Navigation mode changed button callback function
 */
int CVICALLBACK buttonNavMode (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{

	switch (event)
	{
		case EVENT_COMMIT:
			switch (control)
			{
				case PANEL_RADIOBUTTON_SINS:
			
					GetCtrlVal (HandlePmain, PANEL_RADIOBUTTON_SINS, &StatusButtonSinsNew);
			
					if (StatusButtonSinsNew == 1)
					{
						SetCtrlVal (HandlePmain, PANEL_RADIOBUTTON_KF, 0);	
					}
					else
					{
						if (StatusButtonSinsOld == 1)
						{
							StatusButtonSinsNew = 1;
							SetCtrlVal (HandlePmain, PANEL_RADIOBUTTON_SINS, 1);
						}
					}
			
					FlagNavMode = 0;
			
					break;
			
				case PANEL_RADIOBUTTON_KF:
			
					GetCtrlVal (HandlePmain, PANEL_RADIOBUTTON_KF, &StatusButtonKfNew);
			
					if (StatusButtonKfNew == 1)
					{
						SetCtrlVal (HandlePmain, PANEL_RADIOBUTTON_SINS, 0);	
					}
					else
					{
						if (StatusButtonKfOld == 1)
						{
							StatusButtonKfNew = 1;
							SetCtrlVal (HandlePmain, PANEL_RADIOBUTTON_KF, 1);
						}
					}
			
					FlagNavMode = 1;
			
					break;
			}
			
			StatusButtonSinsOld = StatusButtonSinsNew;
			StatusButtonKfOld = StatusButtonKfNew;
			
			break;
	}
	return 0;
}



/*
	Start Filtering button callback function
 */
int CVICALLBACK buttonFiltering (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	unsigned dim1, dim2;
	unsigned char tempString[50];

	switch (event)
	{
		case EVENT_COMMIT:
			
			// Check initialization file
			if (FlagInit == 0)
			{
				SelectInitFile();
				if (FlagInit == 0)
				{
					MessagePopup ("Error", "����Ч��ʼ���ļ���");
					return 1;
				}
			}
			
			// Check data folder
			if (ValidData == 0)
			{
				SelectDataFolder();
				if (ValidData == 0)
				{
					MessagePopup ("Error", "����Ч���ݣ�");
					return 1;
				}
			}
			
			
			/*if (StatusMatlab == 0)
			{
				MessagePopup ("ERROR", "Open MATLAB first!");	
			}*/
			
			// Initialization for navigation
			InitNavParam();
		
			// Disable button
			UIRDimming(1);
			
			// Open data files
			FileHandleGnss = fopen(PathFileGnss, "r");
			FileHandleImu = fopen(PathFileImu, "r");
			FileHandleNorm = fopen(PathFileNorm, "r");
			
			
			
			// Check memory
			CheckMemory();

			
			// Initialize memory
			TimeImu = (double *) malloc (sizeof(double) * ALLOC_LENGTH(LengthImu));
			Wibbx = (double *) malloc (sizeof(double) * ALLOC_LENGTH(LengthImu));
			Wibby = (double *) malloc (sizeof(double) * ALLOC_LENGTH(LengthImu));
			Wibbz = (double *) malloc (sizeof(double) * ALLOC_LENGTH(LengthImu));
			Fbx = (double *) malloc (sizeof(double) * ALLOC_LENGTH(LengthImu));
			Fby = (double *) malloc (sizeof(double) * ALLOC_LENGTH(LengthImu));
			Fbz = (double *) malloc (sizeof(double) * ALLOC_LENGTH(LengthImu));
			
			TimePps = (double *) malloc (sizeof(double) * ALLOC_LENGTH(LengthGnss));
			NavParamGnss = (GNSS_NAV_PARAM *) malloc (sizeof(GNSS_NAV_PARAM) * ALLOC_LENGTH(LengthGnss));
			
			TimeGnssFixed = (double *) malloc (sizeof(double) * ALLOC_LENGTH(LengthGnssFixed));
			LaGnssFixed = (double *) malloc (sizeof(double) * ALLOC_LENGTH(LengthGnssFixed));
			LonGnssFixed = (double *) malloc (sizeof(double) * ALLOC_LENGTH(LengthGnssFixed));
			AltGnssFixed = (double *) malloc (sizeof(double) * ALLOC_LENGTH(LengthGnssFixed));
			VeGnssFixed = (double *) malloc (sizeof(double) * ALLOC_LENGTH(LengthGnssFixed));
			VnGnssFixed = (double *) malloc (sizeof(double) * ALLOC_LENGTH(LengthGnssFixed));
			VuGnssFixed = (double *) malloc (sizeof(double) * ALLOC_LENGTH(LengthGnssFixed));
			
			TimeNorm = (double *) malloc (sizeof(double) * ALLOC_LENGTH(LengthNorm));
			PitchNorm = (double *) malloc (sizeof(double) * ALLOC_LENGTH(LengthNorm));
			RollNorm = (double *) malloc (sizeof(double) * ALLOC_LENGTH(LengthNorm));
			YawNorm = (double *) malloc (sizeof(double) * ALLOC_LENGTH(LengthNorm));
			VeNorm = (double *) malloc (sizeof(double) * ALLOC_LENGTH(LengthNorm));
			VnNorm = (double *) malloc (sizeof(double) * ALLOC_LENGTH(LengthNorm));
			VuNorm = (double *) malloc (sizeof(double) * ALLOC_LENGTH(LengthNorm));
			LaNorm = (double *) malloc (sizeof(double) * ALLOC_LENGTH(LengthNorm));
			LonNorm = (double *) malloc (sizeof(double) * ALLOC_LENGTH(LengthNorm));
			AltNorm = (double *) malloc (sizeof(double) * ALLOC_LENGTH(LengthNorm));
			
			// Read IMU data
			GetDataImu();
			if (LengthImu == 0)
			{
				InsertTextBoxLine (PANEL, PANEL_TEXTBOX, TextBoxLineIndex ++ , "Data import: No IMU data available!");
				ProcessDrawEvents();
				InsertTextBoxLine (PANEL, PANEL_TEXTBOX, TextBoxLineIndex ++ , "");
				ProcessDrawEvents();
				UIRDimming(0); // Enable button 
				return 1;
			}
			else
			{
				InsertTextBoxLine (PANEL, PANEL_TEXTBOX, TextBoxLineIndex ++ , "Data import: IMU finished!");
				ProcessDrawEvents();
			}
			
			// Read GNSS data
			if (FlagNavMode != 0)
			{
				GetDataGnss();
				if (LengthGnss == 0)
				{
					InsertTextBoxLine (PANEL, PANEL_TEXTBOX, TextBoxLineIndex ++ , "Data import: No GNSS data available!");
					ProcessDrawEvents();
					InsertTextBoxLine (PANEL, PANEL_TEXTBOX, TextBoxLineIndex ++ , "");
					ProcessDrawEvents();
					UIRDimming(0); // Enable button
					return 1;	
				}
				else
				{
					InsertTextBoxLine (PANEL, PANEL_TEXTBOX, TextBoxLineIndex ++ , "Data import: GNSS finished!");
					ProcessDrawEvents();
				}
			}
			
			// Read normal trajectory 
			GetDataNorm();
			if (LengthNorm == 0)
			{
				InsertTextBoxLine (PANEL, PANEL_TEXTBOX, TextBoxLineIndex ++ , "Data import: No normal data available!");
				ProcessDrawEvents();
				InsertTextBoxLine (PANEL, PANEL_TEXTBOX, TextBoxLineIndex ++ , "");
				ProcessDrawEvents();
				UIRDimming(0); // Enable button
				return 1;
			}
			else
			{
				InsertTextBoxLine (PANEL, PANEL_TEXTBOX, TextBoxLineIndex ++, "Data import: Normal trajectory finished!");
				ProcessDrawEvents();
			}
			
			// Close data files
			fclose(FileHandleImu);
			fclose(FileHandleGnss);
			fclose(FileHandleNorm);
			
			
			// IMU data length
			sprintf(StringTemp, "Navigation: LengthImu = %d", LengthImu);
			InsertTextBoxLine (PANEL, PANEL_TEXTBOX, TextBoxLineIndex ++ , StringTemp);
			ProcessDrawEvents();
			
			// GNSS data length 
			sprintf(StringTemp, "Navigation: LengthGnssFixed = %d", LengthGnssFixed);
			InsertTextBoxLine (PANEL, PANEL_TEXTBOX, TextBoxLineIndex ++ , StringTemp);
			ProcessDrawEvents();
			
			// Normal data length 
			sprintf(StringTemp, "Navigation: LengthNorm = %d", LengthNorm);
			InsertTextBoxLine (PANEL, PANEL_TEXTBOX, TextBoxLineIndex ++ , StringTemp);
			ProcessDrawEvents();
			
			
			// Navigation algorithm
			Nav();
			
			
			// Estimation data length 
			sprintf(StringTemp, "Navigation: LengthEst = %d", LengthEst);
			InsertTextBoxLine (PANEL, PANEL_TEXTBOX, TextBoxLineIndex ++ , StringTemp);
			ProcessDrawEvents();
			
			if (FlagNavMode == 0 )
				InsertTextBoxLine (PANEL, PANEL_TEXTBOX, TextBoxLineIndex ++, "Navigation: SINS finished!");
			else
				InsertTextBoxLine (PANEL, PANEL_TEXTBOX, TextBoxLineIndex ++, "Navigation: SINS/GNSS finished!");
			
			InsertTextBoxLine (PANEL, PANEL_TEXTBOX, TextBoxLineIndex ++, "");
			ProcessDrawEvents();
			
			
			// Enable button
			UIRDimming(0);
			
			break;
	}
	return 0;
}


/*
	Save results button callback function
 */
int CVICALLBACK buttonSaveResult (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{

	switch (event)
	{
		case EVENT_COMMIT:

			
			break;
	}
	return 0;
}

/*
	Close plot button callback function
 */
int CVICALLBACK buttonClosePlot (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{

	switch (event)
	{
		case EVENT_COMMIT:

			CheckPlot();
			
			break;
	}
	return 0;
}





/*
	Open or close MATLAB
 */
int CVICALLBACK buttonMATLAB (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{

	int buttonStatus;
	int stateError;
	
	switch (event)
	{
		case EVENT_COMMIT:
			GetCtrlVal(PANEL, PANEL_TOGGLEBUTTON_MAT, &buttonStatus);
			
			// Button pressed
			if (buttonStatus == 1)
			{
				if (StatusMatlab == 0)
				{
					UIRDimming(1);
					
					// Open MATLAB
					stateError = MLApp_NewDIMLApp (NULL, 1, LOCALE_NEUTRAL, 0, &HandleMatlab);
					
					UIRDimming(0);
					
					if (stateError < 0)
					{
						// MATLAB flag
						StatusMatlab = 0;
						ErrFunc(stateError, NULL);
					}
					else
					{
						// MATLAB flag
						StatusMatlab = 1;
						MinMaxMatlab(HandleMatlab, 0);
					}
				}
			}
			
			// button unpressed
			else if (buttonStatus == 0)
			{
				CheckPlot();
				CheckMatlab();
			}
			
			
			break;
	}
	return 0;
}





/*
	Display result
 */
int CVICALLBACK buttonDisplay (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	int statusMatlab;
	int statusCheckBox;
	
	switch (event)
	{
		case EVENT_COMMIT:
			
			if (StatusMatlab == 0)
			{
				MessagePopup ("ERROR", "Open MATLAB first!");
			}
			else if (LengthNav == 0)
			{
				MessagePopup ("ERROR", "No data to plot!");
			}
			else
			{
				// Result
				GetCtrlVal (PANEL, PANEL_CHECKBOX_RESULT, &statusCheckBox);
				if (statusCheckBox == 1)
				{
					SendMatrix(HandleMatlab, "TimeNav", TimeNav, NULL, 1, LengthNav);
					SendMatrix(HandleMatlab, "PitchNav", PitchNav, NULL, 1, LengthNav);
					SendMatrix(HandleMatlab, "RollNav", RollNav, NULL, 1, LengthNav);
					SendMatrix(HandleMatlab, "YawNav", YawNav, NULL, 1, LengthNav);
					SendMatrix(HandleMatlab, "VeNav", VeNav, NULL, 1, LengthNav);
					SendMatrix(HandleMatlab, "VnNav", VnNav, NULL, 1, LengthNav);
					SendMatrix(HandleMatlab, "VuNav", VuNav, NULL, 1, LengthNav);
					SendMatrix(HandleMatlab, "LaNav", LaNav, NULL, 1, LengthNav);
					SendMatrix(HandleMatlab, "LonNav", LonNav, NULL, 1, LengthNav);
					SendMatrix(HandleMatlab, "AltNav", AltNav, NULL, 1, LengthNav);
				
					// Get current folder path
					GetDir (PathTemp);
				
					strcat(PathTemp, "\\plot_result.m");
				
					statusMatlab = RunMatlabScript(HandleMatlab, PathTemp);
		            if (statusMatlab != SUCCESS)
		            {
		                MessagePopup ("ERROR", "Error in sending command to MATLAB");
		                return 1;
		            }
				}
				
				// GNSS result
				GetCtrlVal (PANEL, PANEL_CHECKBOX_GNSS_RESULT, &statusCheckBox);
				if (statusCheckBox == 1)
				{
					SendMatrix(HandleMatlab, "TimeGnssFixed", TimeGnssFixed, NULL, 1, LengthGnssFixed);
					SendMatrix(HandleMatlab, "LaGnssFixed", LaGnssFixed, NULL, 1, LengthGnssFixed);
					SendMatrix(HandleMatlab, "LonGnssFixed", LonGnssFixed, NULL, 1, LengthGnssFixed);
					SendMatrix(HandleMatlab, "AltGnssFixed", AltGnssFixed, NULL, 1, LengthGnssFixed);
					SendMatrix(HandleMatlab, "VeGnssFixed", VeGnssFixed, NULL, 1, LengthGnssFixed);
					SendMatrix(HandleMatlab, "VnGnssFixed", VnGnssFixed, NULL, 1, LengthGnssFixed);
					SendMatrix(HandleMatlab, "VuGnssFixed", VuGnssFixed, NULL, 1, LengthGnssFixed);
					
					// Get current folder path
					GetDir (PathTemp);
				
					strcat(PathTemp, "\\plot_gnss.m");
				
					statusMatlab = RunMatlabScript(HandleMatlab, PathTemp);
		            if (statusMatlab != SUCCESS)
		            {
		                MessagePopup ("ERROR", "Error in sending command to MATLAB");
		                return 1;
		            }
				}
				
				// Normal result
				GetCtrlVal (PANEL, PANEL_CHECKBOX_NORM_RESULT, &statusCheckBox);
				if (statusCheckBox == 1)
				{
					SendMatrix(HandleMatlab, "TimeNorm", TimeNorm, NULL, 1, LengthNorm);
					SendMatrix(HandleMatlab, "PitchNorm", PitchNorm, NULL, 1, LengthNorm);
					SendMatrix(HandleMatlab, "RollNorm", RollNorm, NULL, 1, LengthNorm);
					SendMatrix(HandleMatlab, "YawNorm", YawNorm, NULL, 1, LengthNorm);
					SendMatrix(HandleMatlab, "VeNorm", VeNorm, NULL, 1, LengthNorm);
					SendMatrix(HandleMatlab, "VnNorm", VnNorm, NULL, 1, LengthNorm);
					SendMatrix(HandleMatlab, "VuNorm", VuNorm, NULL, 1, LengthNorm);
					SendMatrix(HandleMatlab, "LaNorm", LaNorm, NULL, 1, LengthNorm);
					SendMatrix(HandleMatlab, "LonNorm", LonNorm, NULL, 1, LengthNorm);
					SendMatrix(HandleMatlab, "AltNorm", AltNorm, NULL, 1, LengthNorm);
				
					// Get current folder path
					GetDir (PathTemp);
				
					strcat(PathTemp, "\\plot_norm.m");
				
					statusMatlab = RunMatlabScript(HandleMatlab, PathTemp);
		            if (statusMatlab != SUCCESS)
		            {
		                MessagePopup ("ERROR", "Error in sending command to MATLAB");
		                return 1;
		            }
				}
				
				// Error
				GetCtrlVal (PANEL, PANEL_CHECKBOX_ERROR, &statusCheckBox);
				if (statusCheckBox == 1)
				{
					SendMatrix(HandleMatlab, "TimeNav", TimeNav, NULL, 1, LengthNav);
					SendMatrix(HandleMatlab, "PitchNav", PitchNav, NULL, 1, LengthNav);
					SendMatrix(HandleMatlab, "RollNav", RollNav, NULL, 1, LengthNav);
					SendMatrix(HandleMatlab, "YawNav", YawNav, NULL, 1, LengthNav);
					SendMatrix(HandleMatlab, "VeNav", VeNav, NULL, 1, LengthNav);
					SendMatrix(HandleMatlab, "VnNav", VnNav, NULL, 1, LengthNav);
					SendMatrix(HandleMatlab, "VuNav", VuNav, NULL, 1, LengthNav);
					SendMatrix(HandleMatlab, "LaNav", LaNav, NULL, 1, LengthNav);
					SendMatrix(HandleMatlab, "LonNav", LonNav, NULL, 1, LengthNav);
					SendMatrix(HandleMatlab, "AltNav", AltNav, NULL, 1, LengthNav);
				
					SendMatrix(HandleMatlab, "TimeNorm", TimeNorm, NULL, 1, LengthNorm);
					SendMatrix(HandleMatlab, "PitchNorm", PitchNorm, NULL, 1, LengthNorm);
					SendMatrix(HandleMatlab, "RollNorm", RollNorm, NULL, 1, LengthNorm);
					SendMatrix(HandleMatlab, "YawNorm", YawNorm, NULL, 1, LengthNorm);
					SendMatrix(HandleMatlab, "VeNorm", VeNorm, NULL, 1, LengthNorm);
					SendMatrix(HandleMatlab, "VnNorm", VnNorm, NULL, 1, LengthNorm);
					SendMatrix(HandleMatlab, "VuNorm", VuNorm, NULL, 1, LengthNorm);
					SendMatrix(HandleMatlab, "LaNorm", LaNorm, NULL, 1, LengthNorm);
					SendMatrix(HandleMatlab, "LonNorm", LonNorm, NULL, 1, LengthNorm);
					SendMatrix(HandleMatlab, "AltNorm", AltNorm, NULL, 1, LengthNorm);
				
					// Get current folder path
					GetDir (PathTemp);
				
					strcat(PathTemp, "\\plot_error.m");
				
					statusMatlab = RunMatlabScript(HandleMatlab, PathTemp);
		            if (statusMatlab != SUCCESS)
		            {
		                MessagePopup ("ERROR", "Error in sending command to MATLAB");
		                return 1;
		            }
				}
				
				// IMU
				GetCtrlVal (PANEL, PANEL_CHECKBOX_IMU, &statusCheckBox);
				if (statusCheckBox == 1)
				{
					SendMatrix(HandleMatlab, "TimeImu", TimeImu, NULL, 1, LengthImu);
					SendMatrix(HandleMatlab, "Wibbx", Wibbx, NULL, 1, LengthImu);
					SendMatrix(HandleMatlab, "Wibby", Wibby, NULL, 1, LengthImu);
					SendMatrix(HandleMatlab, "Wibbz", Wibbz, NULL, 1, LengthImu);
					SendMatrix(HandleMatlab, "Fbx", Fbx, NULL, 1, LengthImu);
					SendMatrix(HandleMatlab, "Fby", Fby, NULL, 1, LengthImu);
					SendMatrix(HandleMatlab, "Fbz", Fbz, NULL, 1, LengthImu);
					
					// Get current folder path
					GetDir (PathTemp);
				
					strcat(PathTemp, "\\plot_imu.m");
				
					statusMatlab = RunMatlabScript(HandleMatlab, PathTemp);
		            if (statusMatlab != SUCCESS)
		            {
		                MessagePopup ("ERROR", "Error in sending command to MATLAB");
		                return 1;
		            }
				}
				
				// MSE
				GetCtrlVal (PANEL, PANEL_CHECKBOX_PMSE, &statusCheckBox);
				if (statusCheckBox == 1)
				{
					SendMatrix(HandleMatlab, "TimeEst", TimeEst, NULL, 1, LengthEst);
					
					SendMatrix(HandleMatlab, "PMSE0", PMSE[0], NULL, 1, LengthEst);
					SendMatrix(HandleMatlab, "PMSE1", PMSE[1], NULL, 1, LengthEst);
					SendMatrix(HandleMatlab, "PMSE2", PMSE[2], NULL, 1, LengthEst);
					
					SendMatrix(HandleMatlab, "PMSE3", PMSE[3], NULL, 1, LengthEst);
					SendMatrix(HandleMatlab, "PMSE4", PMSE[4], NULL, 1, LengthEst);
					SendMatrix(HandleMatlab, "PMSE5", PMSE[5], NULL, 1, LengthEst);
					
					SendMatrix(HandleMatlab, "PMSE6", PMSE[6], NULL, 1, LengthEst);
					SendMatrix(HandleMatlab, "PMSE7", PMSE[7], NULL, 1, LengthEst);
					SendMatrix(HandleMatlab, "PMSE8", PMSE[8], NULL, 1, LengthEst);
					
					SendMatrix(HandleMatlab, "PMSE9", PMSE[9], NULL, 1, LengthEst);
					SendMatrix(HandleMatlab, "PMSE10", PMSE[10], NULL, 1, LengthEst);
					SendMatrix(HandleMatlab, "PMSE11", PMSE[11], NULL, 1, LengthEst);
					
					SendMatrix(HandleMatlab, "PMSE12", PMSE[12], NULL, 1, LengthEst);
					SendMatrix(HandleMatlab, "PMSE13", PMSE[13], NULL, 1, LengthEst);
					SendMatrix(HandleMatlab, "PMSE14", PMSE[14], NULL, 1, LengthEst);
				
					// Get current folder path
					GetDir (PathTemp);
				
					strcat(PathTemp, "\\plot_mse.m");
				
					statusMatlab = RunMatlabScript(HandleMatlab, PathTemp);
		            if (statusMatlab != SUCCESS)
		            {
		                MessagePopup ("ERROR", "Error in sending command to MATLAB");
		                return 1;
		            }
				}
			}
			
			break;
	}
	return 0;
}






//*****************************  Initialization sub-panel *********************************//

/*
	Loading sub-panel
 */
int CVICALLBACK subInitPanelLoad (int panel, int event, void *callbackData,   //���ص�����
        int eventData1, int eventData2)
{
    if (event == EVENT_CLOSE)
	{

		// Quit sub panel
		RemovePopup(0);
			
	}
	
    return 0;
}



/*
	Save button callback function
 */
int CVICALLBACK psubInitButtonLoad (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	int i;
	double frequencyIMU;
	double frequencyGNSS;
	
	double valueTemp;
	
	Point pointTempMx0[13];
	Point pointTempCx0[13];
	Point pointTempQ[6];
	Point pointTempR[4];
	
	
	for (i = 0; i < 13; i ++)
	{
		pointTempMx0[i].x = i + 1;
		pointTempMx0[i].y = 2;
	}
	
	for (i = 0; i < 13; i ++)
	{
		pointTempCx0[i].x = i + 1;
		pointTempCx0[i].y = 2;
	}
	
	for (i = 0; i < 6; i ++)
	{
		pointTempQ[i].x = i + 1;
		pointTempQ[i].y = 2;
	}
	
	for (i = 0; i < 4; i ++)
	{
		pointTempR[i].x = i + 1;
		pointTempR[i].y = 2;
	}
	
	switch (event)
	{
		case EVENT_COMMIT:
			
			
			ValidInitFile = FileSelectPopup(".\\", "*.txt", "*.txt",
                            "��ѡ����Ҫ���صĳ�ʼ���ļ�", VAL_OK_BUTTON, 0, 1,
                            1, 1, PathTempInput);

			ImportInitData();
			
			
			// Get sensor information
			SetCtrlVal (HandlePsubInit, PSUB_INIT_NUMERIC_F_IMU, 1 / InitParamSins.time_interval);
			SetCtrlVal (HandlePsubInit, PSUB_INIT_NUMERIC_F_GNSS, 1 / InitParamKF.T);
			SetCtrlVal (HandlePsubInit, PSUB_INIT_NUMERIC_F_NORM, FrequencyNorm);
			SetCtrlVal (HandlePsubInit, PSUB_INIT_NUMERIC_T_BEGIN, TimeSimuBegin);
			SetCtrlVal (HandlePsubInit, PSUB_INIT_NUMERIC_T_END, TimeSimuEnd);
			
			// Get initialization data
			SetCtrlVal (HandlePsubInit, PSUB_INIT_NUMERIC_LA0, InitParamSins.la0 * unit_rad2degree);
			SetCtrlVal (HandlePsubInit, PSUB_INIT_NUMERIC_LON0, InitParamSins.lon0 * unit_rad2degree);
			SetCtrlVal (HandlePsubInit, PSUB_INIT_NUMERIC_ALT0, InitParamSins.h0);
	
			SetCtrlVal (HandlePsubInit, PSUB_INIT_NUMERIC_VE0, InitParamSins.ve0);
			SetCtrlVal (HandlePsubInit, PSUB_INIT_NUMERIC_VN0, InitParamSins.vn0);
			SetCtrlVal (HandlePsubInit, PSUB_INIT_NUMERIC_VU0, InitParamSins.vu0);
	
			SetCtrlVal (HandlePsubInit, PSUB_INIT_NUMERIC_PITCH0, InitParamSins.pitch0 * unit_rad2degree);
			SetCtrlVal (HandlePsubInit, PSUB_INIT_NUMERIC_ROLL0, InitParamSins.roll0 * unit_rad2degree);
			SetCtrlVal (HandlePsubInit, PSUB_INIT_NUMERIC_YAW0, InitParamSins.yaw0 * unit_rad2degree);
			
			// Get mx0 15
	   		SetTableCellAttribute (HandlePsubInit, PSUB_INIT_TABLE_MX0, pointTempMx0[0], ATTR_CTRL_VAL, InitParamKF.mx0[0] * unit_rad2degree);
			SetTableCellAttribute (HandlePsubInit, PSUB_INIT_TABLE_MX0, pointTempMx0[1], ATTR_CTRL_VAL, InitParamKF.mx0[1] * unit_rad2degree);
			SetTableCellAttribute (HandlePsubInit, PSUB_INIT_TABLE_MX0, pointTempMx0[2], ATTR_CTRL_VAL, InitParamKF.mx0[2] * unit_rad2degree);
			SetTableCellAttribute (HandlePsubInit, PSUB_INIT_TABLE_MX0, pointTempMx0[3], ATTR_CTRL_VAL, InitParamKF.mx0[3]);
			SetTableCellAttribute (HandlePsubInit, PSUB_INIT_TABLE_MX0, pointTempMx0[4], ATTR_CTRL_VAL, InitParamKF.mx0[5]);
			SetTableCellAttribute (HandlePsubInit, PSUB_INIT_TABLE_MX0, pointTempMx0[5], ATTR_CTRL_VAL, InitParamKF.mx0[6] * Re);
			SetTableCellAttribute (HandlePsubInit, PSUB_INIT_TABLE_MX0, pointTempMx0[6], ATTR_CTRL_VAL, InitParamKF.mx0[8]);
			SetTableCellAttribute (HandlePsubInit, PSUB_INIT_TABLE_MX0, pointTempMx0[7], ATTR_CTRL_VAL, InitParamKF.mx0[9] / unit_w);
			SetTableCellAttribute (HandlePsubInit, PSUB_INIT_TABLE_MX0, pointTempMx0[8], ATTR_CTRL_VAL, InitParamKF.mx0[10] / unit_w);
			SetTableCellAttribute (HandlePsubInit, PSUB_INIT_TABLE_MX0, pointTempMx0[9], ATTR_CTRL_VAL, InitParamKF.mx0[11] / unit_w);
			SetTableCellAttribute (HandlePsubInit, PSUB_INIT_TABLE_MX0, pointTempMx0[10], ATTR_CTRL_VAL, InitParamKF.mx0[12] / unit_ug);
			SetTableCellAttribute (HandlePsubInit, PSUB_INIT_TABLE_MX0, pointTempMx0[11], ATTR_CTRL_VAL, InitParamKF.mx0[13] / unit_ug);
			SetTableCellAttribute (HandlePsubInit, PSUB_INIT_TABLE_MX0, pointTempMx0[12], ATTR_CTRL_VAL, InitParamKF.mx0[14] / unit_ug);
			
			
			
			// Get Cx0 15
	   		SetTableCellAttribute (HandlePsubInit, PSUB_INIT_TABLE_CX0, pointTempCx0[0], ATTR_CTRL_VAL, sqrt(*(*(InitParamKF.Cx0) + 0 * SIZE_X + 0)) * unit_rad2degree);
			SetTableCellAttribute (HandlePsubInit, PSUB_INIT_TABLE_CX0, pointTempCx0[1], ATTR_CTRL_VAL, sqrt(*(*(InitParamKF.Cx0) + 1 * SIZE_X + 1)) * unit_rad2degree);
			SetTableCellAttribute (HandlePsubInit, PSUB_INIT_TABLE_CX0, pointTempCx0[2], ATTR_CTRL_VAL, sqrt(*(*(InitParamKF.Cx0) + 2 * SIZE_X + 2)) * unit_rad2degree);
			SetTableCellAttribute (HandlePsubInit, PSUB_INIT_TABLE_CX0, pointTempCx0[3], ATTR_CTRL_VAL, sqrt(*(*(InitParamKF.Cx0) + 3 * SIZE_X + 3)));
			SetTableCellAttribute (HandlePsubInit, PSUB_INIT_TABLE_CX0, pointTempCx0[4], ATTR_CTRL_VAL, sqrt(*(*(InitParamKF.Cx0) + 5 * SIZE_X + 5)));
			SetTableCellAttribute (HandlePsubInit, PSUB_INIT_TABLE_CX0, pointTempCx0[5], ATTR_CTRL_VAL, sqrt(*(*(InitParamKF.Cx0) + 6 * SIZE_X + 6)) * Re);
			SetTableCellAttribute (HandlePsubInit, PSUB_INIT_TABLE_CX0, pointTempCx0[6], ATTR_CTRL_VAL, sqrt(*(*(InitParamKF.Cx0) + 8 * SIZE_X + 8)));
			SetTableCellAttribute (HandlePsubInit, PSUB_INIT_TABLE_CX0, pointTempCx0[7], ATTR_CTRL_VAL, sqrt(*(*(InitParamKF.Cx0) + 9 * SIZE_X + 9)) / unit_w);
			SetTableCellAttribute (HandlePsubInit, PSUB_INIT_TABLE_CX0, pointTempCx0[8], ATTR_CTRL_VAL, sqrt(*(*(InitParamKF.Cx0) + 10 * SIZE_X + 10)) / unit_w);
			SetTableCellAttribute (HandlePsubInit, PSUB_INIT_TABLE_CX0, pointTempCx0[9], ATTR_CTRL_VAL, sqrt(*(*(InitParamKF.Cx0) + 11 * SIZE_X + 11)) / unit_w);
			SetTableCellAttribute (HandlePsubInit, PSUB_INIT_TABLE_CX0, pointTempCx0[10], ATTR_CTRL_VAL, sqrt(*(*(InitParamKF.Cx0) + 12 * SIZE_X + 12)) / unit_ug);
			SetTableCellAttribute (HandlePsubInit, PSUB_INIT_TABLE_CX0, pointTempCx0[11], ATTR_CTRL_VAL, sqrt(*(*(InitParamKF.Cx0) + 13 * SIZE_X + 13)) / unit_ug);
			SetTableCellAttribute (HandlePsubInit, PSUB_INIT_TABLE_CX0, pointTempCx0[12], ATTR_CTRL_VAL, sqrt(*(*(InitParamKF.Cx0) + 14 * SIZE_X + 14)) / unit_ug);

			
			// Get Q 6
	   		SetTableCellAttribute (HandlePsubInit, PSUB_INIT_TABLE_Q, pointTempQ[0], ATTR_CTRL_VAL, sqrt(*(*(InitParamKF.Q) + 0 * SIZE_W + 0)) / unit_w);
			SetTableCellAttribute (HandlePsubInit, PSUB_INIT_TABLE_Q, pointTempQ[1], ATTR_CTRL_VAL, sqrt(*(*(InitParamKF.Q) + 1 * SIZE_W + 1)) / unit_w);
			SetTableCellAttribute (HandlePsubInit, PSUB_INIT_TABLE_Q, pointTempQ[2], ATTR_CTRL_VAL, sqrt(*(*(InitParamKF.Q) + 2 * SIZE_W + 2)) / unit_w);
			SetTableCellAttribute (HandlePsubInit, PSUB_INIT_TABLE_Q, pointTempQ[3], ATTR_CTRL_VAL, sqrt(*(*(InitParamKF.Q) + 3 * SIZE_W + 3)) / unit_ug);
			SetTableCellAttribute (HandlePsubInit, PSUB_INIT_TABLE_Q, pointTempQ[4], ATTR_CTRL_VAL, sqrt(*(*(InitParamKF.Q) + 4 * SIZE_W + 4)) / unit_ug);
			SetTableCellAttribute (HandlePsubInit, PSUB_INIT_TABLE_Q, pointTempQ[5], ATTR_CTRL_VAL, sqrt(*(*(InitParamKF.Q) + 5 * SIZE_W + 5)) / unit_ug);
			
	
			// Get R 6
			SetTableCellAttribute (HandlePsubInit, PSUB_INIT_TABLE_R, pointTempR[0], ATTR_CTRL_VAL, sqrt(*(*(InitParamKF.R) + 0 * SIZE_V + 0)));
			SetTableCellAttribute (HandlePsubInit, PSUB_INIT_TABLE_R, pointTempR[1], ATTR_CTRL_VAL, sqrt(*(*(InitParamKF.R) + 2 * SIZE_V + 2)));
			SetTableCellAttribute (HandlePsubInit, PSUB_INIT_TABLE_R, pointTempR[2], ATTR_CTRL_VAL, sqrt(*(*(InitParamKF.R) + 3 * SIZE_V + 3)) * Re);
			SetTableCellAttribute (HandlePsubInit, PSUB_INIT_TABLE_R, pointTempR[3], ATTR_CTRL_VAL, sqrt(*(*(InitParamKF.R) + 5 * SIZE_V + 5)));
			
			break;
	}
	return 0;
}



/*
	Save button callback function
 */
int CVICALLBACK psubInitButtonSave (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	int i;
	double frequencyIMU;
	double frequencyGNSS;
	
	double valueTemp;
	
	Point pointTempMx0[13];
	Point pointTempCx0[13];
	Point pointTempQ[6];
	Point pointTempR[4];
	
	
	for (i = 0; i < 13; i ++)
	{
		pointTempMx0[i].x = i + 1;
		pointTempMx0[i].y = 2;
	}
	
	for (i = 0; i < 13; i ++)
	{
		pointTempCx0[i].x = i + 1;
		pointTempCx0[i].y = 2;
	}
	
	for (i = 0; i < 6; i ++)
	{
		pointTempQ[i].x = i + 1;
		pointTempQ[i].y = 2;
	}
	
	for (i = 0; i < 4; i ++)
	{
		pointTempR[i].x = i + 1;
		pointTempR[i].y = 2;
	}
	
	switch (event)
	{
		case EVENT_COMMIT:
			
			// Get sensor information
			GetCtrlVal (HandlePsubInit, PSUB_INIT_NUMERIC_F_IMU, &frequencyIMU);
			GetCtrlVal (HandlePsubInit, PSUB_INIT_NUMERIC_F_GNSS, &frequencyGNSS);
			InitParamSins.time_interval = 1 / frequencyIMU;
			InitParamKF.T = 1 / frequencyGNSS;
			
			GetCtrlVal (HandlePsubInit, PSUB_INIT_NUMERIC_F_NORM, &FrequencyNorm);
			GetCtrlVal (HandlePsubInit, PSUB_INIT_NUMERIC_T_BEGIN, &TimeSimuBegin);
			GetCtrlVal (HandlePsubInit, PSUB_INIT_NUMERIC_T_END, &TimeSimuEnd);
			
			// Get initialization data
			GetCtrlVal (HandlePsubInit, PSUB_INIT_NUMERIC_LA0, &(InitParamSins.la0));
			GetCtrlVal (HandlePsubInit, PSUB_INIT_NUMERIC_LON0, &(InitParamSins.lon0));
			GetCtrlVal (HandlePsubInit, PSUB_INIT_NUMERIC_ALT0, &(InitParamSins.h0));
	
			GetCtrlVal (HandlePsubInit, PSUB_INIT_NUMERIC_VE0, &(InitParamSins.ve0));
			GetCtrlVal (HandlePsubInit, PSUB_INIT_NUMERIC_VN0, &(InitParamSins.vn0));
			GetCtrlVal (HandlePsubInit, PSUB_INIT_NUMERIC_VU0, &(InitParamSins.vu0));
	
			GetCtrlVal (HandlePsubInit, PSUB_INIT_NUMERIC_PITCH0, &(InitParamSins.pitch0));
			GetCtrlVal (HandlePsubInit, PSUB_INIT_NUMERIC_ROLL0, &(InitParamSins.roll0));
			GetCtrlVal (HandlePsubInit, PSUB_INIT_NUMERIC_YAW0, &(InitParamSins.yaw0));
			
			InitParamSins.la0 = InitParamSins.la0 / unit_rad2degree;
			InitParamSins.lon0 = InitParamSins.lon0 / unit_rad2degree; 
			InitParamSins.pitch0 = InitParamSins.pitch0 / unit_rad2degree;
			InitParamSins.roll0 = InitParamSins.roll0 / unit_rad2degree;
			InitParamSins.yaw0 = InitParamSins.yaw0 / unit_rad2degree;
			
			// Get mx0 15
	   		GetTableCellAttribute (HandlePsubInit, PSUB_INIT_TABLE_MX0, pointTempMx0[0], ATTR_CTRL_VAL, &valueTemp);
			InitParamKF.mx0[0] = valueTemp / unit_rad2degree;
			GetTableCellAttribute (HandlePsubInit, PSUB_INIT_TABLE_MX0, pointTempMx0[1], ATTR_CTRL_VAL, &valueTemp);
			InitParamKF.mx0[1] = valueTemp / unit_rad2degree;
			GetTableCellAttribute (HandlePsubInit, PSUB_INIT_TABLE_MX0, pointTempMx0[2], ATTR_CTRL_VAL, &valueTemp);
			InitParamKF.mx0[2] = valueTemp / unit_rad2degree;
			GetTableCellAttribute (HandlePsubInit, PSUB_INIT_TABLE_MX0, pointTempMx0[3], ATTR_CTRL_VAL, &valueTemp);
			InitParamKF.mx0[3] = valueTemp;
			InitParamKF.mx0[4] = valueTemp;
			GetTableCellAttribute (HandlePsubInit, PSUB_INIT_TABLE_MX0, pointTempMx0[4], ATTR_CTRL_VAL, &valueTemp);
			InitParamKF.mx0[5] = valueTemp;
			GetTableCellAttribute (HandlePsubInit, PSUB_INIT_TABLE_MX0, pointTempMx0[5], ATTR_CTRL_VAL, &valueTemp);
			InitParamKF.mx0[6] = valueTemp / Re;
			InitParamKF.mx0[7] = valueTemp / Re;
			GetTableCellAttribute (HandlePsubInit, PSUB_INIT_TABLE_MX0, pointTempMx0[6], ATTR_CTRL_VAL, &valueTemp);
			InitParamKF.mx0[8] = valueTemp;
			GetTableCellAttribute (HandlePsubInit, PSUB_INIT_TABLE_MX0, pointTempMx0[7], ATTR_CTRL_VAL, &valueTemp);
			InitParamKF.mx0[9] = valueTemp * unit_w;
			GetTableCellAttribute (HandlePsubInit, PSUB_INIT_TABLE_MX0, pointTempMx0[8], ATTR_CTRL_VAL, &valueTemp);
			InitParamKF.mx0[10] = valueTemp * unit_w;
			GetTableCellAttribute (HandlePsubInit, PSUB_INIT_TABLE_MX0, pointTempMx0[9], ATTR_CTRL_VAL, &valueTemp);
			InitParamKF.mx0[11] = valueTemp * unit_w;
			GetTableCellAttribute (HandlePsubInit, PSUB_INIT_TABLE_MX0, pointTempMx0[10], ATTR_CTRL_VAL, &valueTemp);
			InitParamKF.mx0[12] = valueTemp * unit_ug;
			GetTableCellAttribute (HandlePsubInit, PSUB_INIT_TABLE_MX0, pointTempMx0[11], ATTR_CTRL_VAL, &valueTemp);
			InitParamKF.mx0[13] = valueTemp * unit_ug;
			GetTableCellAttribute (HandlePsubInit, PSUB_INIT_TABLE_MX0, pointTempMx0[12], ATTR_CTRL_VAL, &valueTemp);
			InitParamKF.mx0[14] = valueTemp * unit_ug;
			
			
			
			// Get Cx0 15
	   		GetTableCellAttribute (HandlePsubInit, PSUB_INIT_TABLE_CX0, pointTempCx0[0], ATTR_CTRL_VAL, &valueTemp);
			*(*(InitParamKF.Cx0) + 0 * SIZE_X + 0) = pow(valueTemp / unit_rad2degree, 2);
			GetTableCellAttribute (HandlePsubInit, PSUB_INIT_TABLE_CX0, pointTempCx0[1], ATTR_CTRL_VAL, &valueTemp);
			*(*(InitParamKF.Cx0) + 1 * SIZE_X + 1) = pow(valueTemp / unit_rad2degree, 2);
			GetTableCellAttribute (HandlePsubInit, PSUB_INIT_TABLE_CX0, pointTempCx0[2], ATTR_CTRL_VAL, &valueTemp);
			*(*(InitParamKF.Cx0) + 2 * SIZE_X + 2) = pow(valueTemp / unit_rad2degree, 2);
			GetTableCellAttribute (HandlePsubInit, PSUB_INIT_TABLE_CX0, pointTempCx0[3], ATTR_CTRL_VAL, &valueTemp);
			*(*(InitParamKF.Cx0) + 3 * SIZE_X + 3) = pow(valueTemp, 2);
			*(*(InitParamKF.Cx0) + 4 * SIZE_X + 4) = pow(valueTemp, 2);
			GetTableCellAttribute (HandlePsubInit, PSUB_INIT_TABLE_CX0, pointTempCx0[4], ATTR_CTRL_VAL, &valueTemp);
			*(*(InitParamKF.Cx0) + 5 * SIZE_X + 5) = valueTemp * valueTemp;
			GetTableCellAttribute (HandlePsubInit, PSUB_INIT_TABLE_CX0, pointTempCx0[5], ATTR_CTRL_VAL, &valueTemp);
			*(*(InitParamKF.Cx0) + 6 * SIZE_X + 6) = pow(valueTemp / Re, 2);
			*(*(InitParamKF.Cx0) + 7 * SIZE_X + 7) = pow(valueTemp / Re, 2);
			GetTableCellAttribute (HandlePsubInit, PSUB_INIT_TABLE_CX0, pointTempCx0[6], ATTR_CTRL_VAL, &valueTemp);
			*(*(InitParamKF.Cx0) + 8 * SIZE_X + 8) = pow(valueTemp, 2);
			GetTableCellAttribute (HandlePsubInit, PSUB_INIT_TABLE_CX0, pointTempCx0[7], ATTR_CTRL_VAL, &valueTemp);
			*(*(InitParamKF.Cx0) + 9 * SIZE_X + 9) = pow(valueTemp * unit_w, 2);
			GetTableCellAttribute (HandlePsubInit, PSUB_INIT_TABLE_CX0, pointTempCx0[8], ATTR_CTRL_VAL, &valueTemp);
			*(*(InitParamKF.Cx0) + 10 * SIZE_X + 10) = pow(valueTemp * unit_w, 2);
			GetTableCellAttribute (HandlePsubInit, PSUB_INIT_TABLE_CX0, pointTempCx0[9], ATTR_CTRL_VAL, &valueTemp);
			*(*(InitParamKF.Cx0) + 11 * SIZE_X + 11) = pow(valueTemp * unit_w, 2);
			GetTableCellAttribute (HandlePsubInit, PSUB_INIT_TABLE_CX0, pointTempCx0[10], ATTR_CTRL_VAL, &valueTemp);
			*(*(InitParamKF.Cx0) + 12 * SIZE_X + 12) = pow(valueTemp * unit_ug, 2);
			GetTableCellAttribute (HandlePsubInit, PSUB_INIT_TABLE_CX0, pointTempCx0[11], ATTR_CTRL_VAL, &valueTemp);
			*(*(InitParamKF.Cx0) + 13 * SIZE_X + 13) = pow(valueTemp * unit_ug, 2);
			GetTableCellAttribute (HandlePsubInit, PSUB_INIT_TABLE_CX0, pointTempCx0[12], ATTR_CTRL_VAL, &valueTemp);
			*(*(InitParamKF.Cx0) + 14 * SIZE_X + 14) = pow(valueTemp * unit_ug, 2);

			
			// Get Q 6
	   		GetTableCellAttribute (HandlePsubInit, PSUB_INIT_TABLE_Q, pointTempQ[0], ATTR_CTRL_VAL, &valueTemp);
			*(*(InitParamKF.Q) + 0 * SIZE_W + 0) = pow(valueTemp * unit_w, 2);
			GetTableCellAttribute (HandlePsubInit, PSUB_INIT_TABLE_Q, pointTempQ[1], ATTR_CTRL_VAL, &valueTemp);
			*(*(InitParamKF.Q) + 1 * SIZE_W + 1) = pow(valueTemp * unit_w, 2);
			GetTableCellAttribute (HandlePsubInit, PSUB_INIT_TABLE_Q, pointTempQ[2], ATTR_CTRL_VAL, &valueTemp);
			*(*(InitParamKF.Q) + 2 * SIZE_W + 2) = pow(valueTemp * unit_w, 2);
			GetTableCellAttribute (HandlePsubInit, PSUB_INIT_TABLE_Q, pointTempQ[3], ATTR_CTRL_VAL, &valueTemp);
			*(*(InitParamKF.Q) + 3 * SIZE_W + 3) = pow(valueTemp * unit_ug, 2);
			GetTableCellAttribute (HandlePsubInit, PSUB_INIT_TABLE_Q, pointTempQ[4], ATTR_CTRL_VAL, &valueTemp);
			*(*(InitParamKF.Q) + 4 * SIZE_W + 4) = pow(valueTemp * unit_ug, 2);
			GetTableCellAttribute (HandlePsubInit, PSUB_INIT_TABLE_Q, pointTempQ[5], ATTR_CTRL_VAL, &valueTemp);
			*(*(InitParamKF.Q) + 5 * SIZE_W + 5) = pow(valueTemp * unit_ug, 2);
			
	
			// Get R 6
			GetTableCellAttribute (HandlePsubInit, PSUB_INIT_TABLE_R, pointTempR[0], ATTR_CTRL_VAL, &valueTemp);
			*(*(InitParamKF.R) + 0 * SIZE_V + 0) = pow(valueTemp, 2);
			*(*(InitParamKF.R) + 1 * SIZE_V + 1) = pow(valueTemp, 2);
			GetTableCellAttribute (HandlePsubInit, PSUB_INIT_TABLE_R, pointTempR[1], ATTR_CTRL_VAL, &valueTemp);
			*(*(InitParamKF.R) + 2 * SIZE_V + 2) = pow(valueTemp, 2);
			GetTableCellAttribute (HandlePsubInit, PSUB_INIT_TABLE_R, pointTempR[2], ATTR_CTRL_VAL, &valueTemp);
			*(*(InitParamKF.R) + 3 * SIZE_V + 3) = pow(valueTemp / Re, 2);
			*(*(InitParamKF.R) + 4 * SIZE_V + 4) = pow(valueTemp / Re, 2);
			GetTableCellAttribute (HandlePsubInit, PSUB_INIT_TABLE_R, pointTempR[3], ATTR_CTRL_VAL, &valueTemp);
			*(*(InitParamKF.R) + 5 * SIZE_V + 5) = pow(valueTemp, 2);
			
			
			ValidInitFile = FileSelectPopup(".\\", "*.txt", "*.txt",
                            "��ʼ���ļ�����Ϊ", VAL_OK_BUTTON, 0, 1,
                            1, 1, PathTempOutput);

			ExportInitData();
			
			
			break;
	}
	return 0;
}


/*
	Back button callback function
 */
int CVICALLBACK psubInitButtonBack (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{

	switch (event)
	{
		case EVENT_COMMIT:
			
			// Quit sub panel
			RemovePopup(0);
			
			break;
	}
	return 0;
}





/*
	Import data from initialization file
*/
int ImportInitData(void)
{
	int i;
	double valueTemp;
	
	FileHandleInit = fopen(PathTempInput, "r");

	// Read file header
	fgets(StringTemp, STRING_LENGTH_MAX, FileHandleInit);
		
	
	fgets(StringTemp, STRING_LENGTH_MAX, FileHandleInit);
		
	// ���������� 4
	PieceTemp2 = strtok(StringTemp, "\t");
	InitParamSins.time_interval = 1 / atof(PieceTemp2); // s
	
	PieceTemp2 = strtok(NULL, "\t");
	InitParamKF.T = 1 / atof(PieceTemp2); // s
	
	PieceTemp2 = strtok(NULL, "\t");
	FrequencyNorm = atof(PieceTemp2); // Hz
	
	PieceTemp2 = strtok(NULL, "\t");
	TimeSimuBegin = atof(PieceTemp2); // s
	
	PieceTemp2 = strtok(NULL, "\t");
	TimeSimuEnd = atof(PieceTemp2); // s
	
	
	
	// ��ʼ�������� 9
	PieceTemp2 = strtok(NULL, "\t");
	InitParamSins.pitch0 = atof(PieceTemp2) / unit_rad2degree; // rad
	
	PieceTemp2 = strtok(NULL, "\t");
	InitParamSins.roll0 = atof(PieceTemp2) / unit_rad2degree; // rad
	
	PieceTemp2 = strtok(NULL, "\t");
	InitParamSins.yaw0 = atof(PieceTemp2) / unit_rad2degree; // rad
	
	PieceTemp2 = strtok(NULL, "\t");
	InitParamSins.ve0 = atof(PieceTemp2); // m/s
	
	PieceTemp2 = strtok(NULL, "\t");
	InitParamSins.vn0 = atof(PieceTemp2); // m/s
	
	PieceTemp2 = strtok(NULL, "\t");
	InitParamSins.vu0 = atof(PieceTemp2); // m/s
	
	PieceTemp2 = strtok(NULL, "\t");
	InitParamSins.la0 = atof(PieceTemp2) / unit_rad2degree; // rad
	
	PieceTemp2 = strtok(NULL, "\t");
	InitParamSins.lon0 = atof(PieceTemp2) / unit_rad2degree; // rad
	
	PieceTemp2 = strtok(NULL, "\t");
	InitParamSins.h0 = atof(PieceTemp2); // m
	
	
	
	// mx0 15
	PieceTemp2 = strtok(NULL, "\t");
	*(InitParamKF.mx0 + 0) = atof(PieceTemp2) / unit_rad2degree; // rad
	
	PieceTemp2 = strtok(NULL, "\t");
	*(InitParamKF.mx0 + 1) = atof(PieceTemp2) / unit_rad2degree; // rad
	
	PieceTemp2 = strtok(NULL, "\t");
	*(InitParamKF.mx0 + 2) = atof(PieceTemp2) / unit_rad2degree; // rad
	
	PieceTemp2 = strtok(NULL, "\t");
	*(InitParamKF.mx0 + 3) = atof(PieceTemp2); // m/s
	*(InitParamKF.mx0 + 4) = atof(PieceTemp2); // m/s
	
	PieceTemp2 = strtok(NULL, "\t");
	*(InitParamKF.mx0 + 5) = atof(PieceTemp2); // m/s
	
	PieceTemp2 = strtok(NULL, "\t");
	*(InitParamKF.mx0 + 6) = atof(PieceTemp2) / Re; // rad
	*(InitParamKF.mx0 + 7) = atof(PieceTemp2) / Re; // rad
	
	PieceTemp2 = strtok(NULL, "\t");
	*(InitParamKF.mx0 + 8) = atof(PieceTemp2); // m
	
	PieceTemp2 = strtok(NULL, "\t");
	*(InitParamKF.mx0 + 9) = atof(PieceTemp2) * unit_w; // rad/s
	
	PieceTemp2 = strtok(NULL, "\t");
	*(InitParamKF.mx0 + 10) = atof(PieceTemp2) * unit_w; // rad/s
	
	PieceTemp2 = strtok(NULL, "\t");
	*(InitParamKF.mx0 + 11) = atof(PieceTemp2) * unit_w; // rad/s
	
	PieceTemp2 = strtok(NULL, "\t");
	*(InitParamKF.mx0 + 12) = atof(PieceTemp2) * unit_ug; // m/s^2
	
	PieceTemp2 = strtok(NULL, "\t");
	*(InitParamKF.mx0 + 13) = atof(PieceTemp2) * unit_ug; // m/s^2
	
	PieceTemp2 = strtok(NULL, "\t");
	*(InitParamKF.mx0 + 14) = atof(PieceTemp2) * unit_ug; // m/s^2
	
	PieceTemp2 = strtok(NULL, "\t");
	
	PieceTemp2 = strtok(NULL, "\t");
	
	
	
	// Cx0  15
	PieceTemp2 = strtok(NULL, "\t");
	*(*(InitParamKF.Cx0) + 0 * SIZE_X + 0) = pow(atof(PieceTemp2) / unit_rad2degree, 2); // rad
	
	PieceTemp2 = strtok(NULL, "\t");
	*(*(InitParamKF.Cx0) + 1 * SIZE_X + 1) = pow(atof(PieceTemp2) / unit_rad2degree, 2); // rad
	
	PieceTemp2 = strtok(NULL, "\t");
	*(*(InitParamKF.Cx0) + 2 * SIZE_X + 2) = pow(atof(PieceTemp2) / unit_rad2degree, 2); // rad
	
	PieceTemp2 = strtok(NULL, "\t");
	*(*(InitParamKF.Cx0) + 3 * SIZE_X + 3) = pow(atof(PieceTemp2), 2); // m/s
	*(*(InitParamKF.Cx0) + 4 * SIZE_X + 4) = pow(atof(PieceTemp2), 2); // m/s
	
	PieceTemp2 = strtok(NULL, "\t");
	*(*(InitParamKF.Cx0) + 5 * SIZE_X + 5) = pow(atof(PieceTemp2), 2); // m/s
	
	PieceTemp2 = strtok(NULL, "\t");
	*(*(InitParamKF.Cx0) + 6 * SIZE_X + 6) = pow(atof(PieceTemp2) / Re, 2); // rad
	*(*(InitParamKF.Cx0) + 7 * SIZE_X + 7) = pow(atof(PieceTemp2) / Re, 2); // rad
	
	PieceTemp2 = strtok(NULL, "\t");
	*(*(InitParamKF.Cx0) + 8 * SIZE_X + 8) = pow(atof(PieceTemp2), 2); // m
	
	PieceTemp2 = strtok(NULL, "\t");
	*(*(InitParamKF.Cx0) + 9 * SIZE_X + 9) = pow(atof(PieceTemp2) * unit_w, 2); // rad/s
	
	PieceTemp2 = strtok(NULL, "\t");
	*(*(InitParamKF.Cx0) + 10 * SIZE_X + 10) = pow(atof(PieceTemp2) * unit_w, 2); // rad/s
	
	PieceTemp2 = strtok(NULL, "\t");
	*(*(InitParamKF.Cx0) + 11 * SIZE_X + 11) = pow(atof(PieceTemp2) * unit_w, 2); // rad/s
	
	PieceTemp2 = strtok(NULL, "\t");
	*(*(InitParamKF.Cx0) + 12 * SIZE_X + 12) = pow(atof(PieceTemp2) * unit_ug, 2); // m/s^2
	
	PieceTemp2 = strtok(NULL, "\t");
	*(*(InitParamKF.Cx0) + 13 * SIZE_X + 13) = pow(atof(PieceTemp2) * unit_ug, 2); // m/s^2
	
	PieceTemp2 = strtok(NULL, "\t");
	*(*(InitParamKF.Cx0) + 14 * SIZE_X + 14) = pow(atof(PieceTemp2) * unit_ug, 2); // m/s^2
	
	PieceTemp2 = strtok(NULL, "\t");
	
	PieceTemp2 = strtok(NULL, "\t");
	
	
	// Q 7
	PieceTemp2 = strtok(NULL, "\t");
	valueTemp = atof(PieceTemp2);
	*(*(InitParamKF.Q) + 0 * SIZE_W + 0) = pow(valueTemp * unit_w, 2); // rad/s
	
	PieceTemp2 = strtok(NULL, "\t");
	valueTemp = atof(PieceTemp2);
	*(*(InitParamKF.Q) + 1 * SIZE_W + 1) = pow(valueTemp * unit_w, 2); // rad/s
	
	PieceTemp2 = strtok(NULL, "\t");
	valueTemp = atof(PieceTemp2);
	*(*(InitParamKF.Q) + 2 * SIZE_W + 2) = pow(valueTemp * unit_w, 2); // rad/s
	
	PieceTemp2 = strtok(NULL, "\t");
	valueTemp = atof(PieceTemp2);
	*(*(InitParamKF.Q) + 3 * SIZE_W + 3) = pow(valueTemp * unit_ug, 2); // m/s^2
	
	PieceTemp2 = strtok(NULL, "\t");
	valueTemp = atof(PieceTemp2);
	*(*(InitParamKF.Q) + 4 * SIZE_W + 4) = pow(valueTemp * unit_ug, 2); // m/s^2
	
	PieceTemp2 = strtok(NULL, "\t");
	valueTemp = atof(PieceTemp2);
	*(*(InitParamKF.Q) + 5 * SIZE_W + 5) = pow(valueTemp * unit_ug, 2); // m/s^2
	
	PieceTemp2 = strtok(NULL, "\t");
	valueTemp = atof(PieceTemp2);
	
	
	// R 6
	PieceTemp2 = strtok(NULL, "\t");
	valueTemp = atof(PieceTemp2);
	*(*(InitParamKF.R) + 0 * SIZE_V + 0) = pow(valueTemp, 2); // m/s
	*(*(InitParamKF.R) + 1 * SIZE_V + 1) = pow(valueTemp, 2);
	
	PieceTemp2 = strtok(NULL, "\t");
	valueTemp = atof(PieceTemp2);
	*(*(InitParamKF.R) + 2 * SIZE_V + 2) = pow(valueTemp, 2); // m/s
	
	PieceTemp2 = strtok(NULL, "\t");
	valueTemp = atof(PieceTemp2);
	*(*(InitParamKF.R) + 3 * SIZE_V + 3) = pow(valueTemp / Re, 2); // rad
	*(*(InitParamKF.R) + 4 * SIZE_V + 4) = pow(valueTemp / Re, 2);
	
	PieceTemp2 = strtok(NULL, "\t");
	valueTemp = atof(PieceTemp2);
	*(*(InitParamKF.R) + 5 * SIZE_V + 5) = pow(valueTemp, 2); // m 
	
	PieceTemp2 = strtok(NULL, "\t");
	valueTemp = atof(PieceTemp2);
	
	PieceTemp2 = strtok(NULL, "\t");
	valueTemp = atof(PieceTemp2);
	
	
	// GNSS Markov ���ʱ�� 1
	PieceTemp2 = strtok(NULL, "\t");
	valueTemp = atof(PieceTemp2);

	
	fclose(FileHandleInit);
	
	return 0;
}


/*
	Write initialization data from file
*/
int ExportInitData(void)
{
	FileHandleInit = fopen(PathTempOutput, "wr");
		
	// *************************** File header
	// Sensor information
	fprintf(FileHandleInit, "IMUƵ��\t");
	fprintf(FileHandleInit, "GNSS���ջ�Ƶ��\t");
	fprintf(FileHandleInit, "��׼�켣Ƶ��\t");
	fprintf(FileHandleInit, "���濪ʼʱ��\t");
	fprintf(FileHandleInit, "�������ʱ��\t");
	
	// Initialization 9
	fprintf(FileHandleInit, "��ʼ������\t");
	fprintf(FileHandleInit, "��ʼ��ת��\t");
	fprintf(FileHandleInit, "��ʼƫ����\t");
	fprintf(FileHandleInit, "��ʼ�����ٶ�\t");
	fprintf(FileHandleInit, "��ʼ�����ٶ�\t");
	fprintf(FileHandleInit, "��ʼ�����ٶ�\t");
	fprintf(FileHandleInit, "��ʼγ��\t");
	fprintf(FileHandleInit, "��ʼ����\t");
	fprintf(FileHandleInit, "��ʼ�߶�\t");
	
	// mx0 15
	fprintf(FileHandleInit, "��ʼ���������\t");
	fprintf(FileHandleInit, "��ʼ��ת�����\t");
	fprintf(FileHandleInit, "��ʼƫ�������\t");
	fprintf(FileHandleInit, "��ʼˮƽ�ٶ����\t");
	fprintf(FileHandleInit, "��ʼ�����ٶ����\t");
	fprintf(FileHandleInit, "��ʼˮƽλ�����\t");
	fprintf(FileHandleInit, "��ʼ�߶����\t");
	fprintf(FileHandleInit, "����X�᳣ֵƯ��\t");
	fprintf(FileHandleInit, "����Y�᳣ֵƯ��\t");
	fprintf(FileHandleInit, "����Z�᳣ֵƯ��\t");
	fprintf(FileHandleInit, "�Ӽ�X�᳣ֵ��ƫ\t");
	fprintf(FileHandleInit, "�Ӽ�Y�᳣ֵ��ƫ\t");
	fprintf(FileHandleInit, "�Ӽ�Z�᳣ֵ��ƫ\t");
	fprintf(FileHandleInit, "GNSS�Ӳ������λ�����\t");
	fprintf(FileHandleInit, "GNSS��Ư������ٶ����\t");
	
	// Cx0  15
	fprintf(FileHandleInit, "��ʼ���������MSE\t");
	fprintf(FileHandleInit, "��ʼ��ת�����MSE\t");
	fprintf(FileHandleInit, "��ʼƫ�������MSE\t");
	fprintf(FileHandleInit, "��ʼˮƽ�ٶ����MSE\t");
	fprintf(FileHandleInit, "��ʼ�����ٶ����MSE\t");
	fprintf(FileHandleInit, "��ʼˮƽλ�����MSE\t");
	fprintf(FileHandleInit, "��ʼ�߶����MSE\t");
	fprintf(FileHandleInit, "����X�᳣ֵƯ��MSE\t");
	fprintf(FileHandleInit, "����Y�᳣ֵƯ��MSE\t");
	fprintf(FileHandleInit, "����Z�᳣ֵƯ��MSE\t");
	fprintf(FileHandleInit, "�Ӽ�X�᳣ֵ��ƫMSE\t");
	fprintf(FileHandleInit, "�Ӽ�Y�᳣ֵ��ƫMSE\t");
	fprintf(FileHandleInit, "�Ӽ�Z�᳣ֵ��ƫMSE\t");
	fprintf(FileHandleInit, "GNSS�Ӳ������λ�����MSE\t");
	fprintf(FileHandleInit, "GNSS��Ư������ٶ����MSE\t");
	
	// Q 7
	fprintf(FileHandleInit, "����X��Ư������MSE\t");
	fprintf(FileHandleInit, "����Y��Ư������MSE\t");
	fprintf(FileHandleInit, "����Z��Ư������MSE\t");
	fprintf(FileHandleInit, "�Ӽ�X����ƫ����MSE\t");
	fprintf(FileHandleInit, "�Ӽ�Y����ƫ����MSE\t");
	fprintf(FileHandleInit, "�Ӽ�Z����ƫ����MSE\t");
	fprintf(FileHandleInit, "GNSS��Ư������ٶ��������MSE\t");
	
	// R 6
	fprintf(FileHandleInit, "ˮƽ�ٶȲ����������MSE\t");
	fprintf(FileHandleInit, "�����ٶȲ����������MSE\t");
	fprintf(FileHandleInit, "ˮƽλ�ò����������MSE\t");
	fprintf(FileHandleInit, "�߶Ȳ����������MSE\t");
	fprintf(FileHandleInit, "GNSSα��������MSE\t");
	fprintf(FileHandleInit, "GNSSα���ʲ������MSE\t");
	
	// Markov ���ʱ�� 1
	fprintf(FileHandleInit, "GNSS��ƯMarkov���ʱ��\t");
	fprintf(FileHandleInit, "\n");
	
	
	
	//************************************* data
	// Sensor information							
	fprintf(FileHandleInit, "%.9f\t", 1 / InitParamSins.time_interval);
	fprintf(FileHandleInit, "%.9f\t", 1 / InitParamKF.T);
	fprintf(FileHandleInit, "%.9f\t", FrequencyNorm);
	fprintf(FileHandleInit, "%.9f\t", TimeSimuBegin);
	fprintf(FileHandleInit, "%.9f\t", TimeSimuEnd);
	
	// Initialization 9
	fprintf(FileHandleInit, "%.9f\t", InitParamSins.pitch0 * unit_rad2degree);
	fprintf(FileHandleInit, "%.9f\t", InitParamSins.roll0 * unit_rad2degree);
	fprintf(FileHandleInit, "%.9f\t", InitParamSins.yaw0 * unit_rad2degree);
	fprintf(FileHandleInit, "%.9f\t", InitParamSins.ve0);
	fprintf(FileHandleInit, "%.9f\t", InitParamSins.vn0);
	fprintf(FileHandleInit, "%.9f\t", InitParamSins.vu0);
	fprintf(FileHandleInit, "%.9f\t", InitParamSins.la0 * unit_rad2degree); //degree
	fprintf(FileHandleInit, "%.9f\t", InitParamSins.lon0 * unit_rad2degree);
	fprintf(FileHandleInit, "%.9f\t", InitParamSins.h0);
	
	// mx0 15
	fprintf(FileHandleInit, "%.9f\t", *(InitParamKF.mx0 + 0) * unit_rad2degree);
	fprintf(FileHandleInit, "%.9f\t", *(InitParamKF.mx0 + 1) * unit_rad2degree);
	fprintf(FileHandleInit, "%.9f\t", *(InitParamKF.mx0 + 2) * unit_rad2degree);
	fprintf(FileHandleInit, "%.9f\t", *(InitParamKF.mx0 + 3)); // m/s
	fprintf(FileHandleInit, "%.9f\t", *(InitParamKF.mx0 + 5));
	fprintf(FileHandleInit, "%.9f\t", *(InitParamKF.mx0 + 6) * Re); // m
	fprintf(FileHandleInit, "%.9f\t", *(InitParamKF.mx0 + 8)); // m
	fprintf(FileHandleInit, "%.9f\t", *(InitParamKF.mx0 + 9) / unit_w); // degree/h
	fprintf(FileHandleInit, "%.9f\t", *(InitParamKF.mx0 + 10) / unit_w); // degree/h
	fprintf(FileHandleInit, "%.9f\t", *(InitParamKF.mx0 + 11) / unit_w); // degree/h
	fprintf(FileHandleInit, "%.9f\t", *(InitParamKF.mx0 + 12) / unit_ug); // ug
	fprintf(FileHandleInit, "%.9f\t", *(InitParamKF.mx0 + 13) / unit_ug); // ug
	fprintf(FileHandleInit, "%.9f\t", *(InitParamKF.mx0 + 14) / unit_ug); // ug
	fprintf(FileHandleInit, "%.9f\t", 0.0); // m
	fprintf(FileHandleInit, "%.9f\t", 0.0); // m/s
	
	// Cx0 15
	fprintf(FileHandleInit, "%.9f\t", sqrt(*(*(InitParamKF.Cx0) + 0 * SIZE_X + 0)) * unit_rad2degree);
	fprintf(FileHandleInit, "%.9f\t", sqrt(*(*(InitParamKF.Cx0) + 1 * SIZE_X + 1)) * unit_rad2degree);
	fprintf(FileHandleInit, "%.9f\t", sqrt(*(*(InitParamKF.Cx0) + 2 * SIZE_X + 2)) * unit_rad2degree);
	fprintf(FileHandleInit, "%.9f\t", sqrt(*(*(InitParamKF.Cx0) + 3 * SIZE_X + 3))); // m/s
	fprintf(FileHandleInit, "%.9f\t", sqrt(*(*(InitParamKF.Cx0) + 5 * SIZE_X + 5)));
	fprintf(FileHandleInit, "%.9f\t", sqrt(*(*(InitParamKF.Cx0) + 6 * SIZE_X + 6)) * Re); // m
	fprintf(FileHandleInit, "%.9f\t", sqrt(*(*(InitParamKF.Cx0) + 8 * SIZE_X + 8))); // m
	fprintf(FileHandleInit, "%.9f\t", sqrt(*(*(InitParamKF.Cx0) + 9 * SIZE_X + 9)) / unit_w); // degree/h
	fprintf(FileHandleInit, "%.9f\t", sqrt(*(*(InitParamKF.Cx0) + 10 * SIZE_X + 10)) / unit_w); // degree/h
	fprintf(FileHandleInit, "%.9f\t", sqrt(*(*(InitParamKF.Cx0) + 11 * SIZE_X + 11)) / unit_w); // degree/h
	fprintf(FileHandleInit, "%.9f\t", sqrt(*(*(InitParamKF.Cx0) + 12 * SIZE_X + 12)) / unit_ug); // ug
	fprintf(FileHandleInit, "%.9f\t", sqrt(*(*(InitParamKF.Cx0) + 13 * SIZE_X + 13)) / unit_ug); // ug
	fprintf(FileHandleInit, "%.9f\t", sqrt(*(*(InitParamKF.Cx0) + 14 * SIZE_X + 14)) / unit_ug); // ug
	fprintf(FileHandleInit, "%.9f\t", 0.0); // m
	fprintf(FileHandleInit, "%.9f\t", 0.0); // m/s
	
	// Q 7
	fprintf(FileHandleInit, "%.9f\t", sqrt(*(*(InitParamKF.Q) + 0 * SIZE_W + 0)) / unit_w); //  degree/h
	fprintf(FileHandleInit, "%.9f\t", sqrt(*(*(InitParamKF.Q) + 1 * SIZE_W + 1)) / unit_w);
	fprintf(FileHandleInit, "%.9f\t", sqrt(*(*(InitParamKF.Q) + 2 * SIZE_W + 2)) / unit_w);
	fprintf(FileHandleInit, "%.9f\t", sqrt(*(*(InitParamKF.Q) + 3 * SIZE_W + 3)) / unit_ug); // ug
	fprintf(FileHandleInit, "%.9f\t", sqrt(*(*(InitParamKF.Q) + 4 * SIZE_W + 4)) / unit_ug);
	fprintf(FileHandleInit, "%.9f\t", sqrt(*(*(InitParamKF.Q) + 5 * SIZE_W + 5)) / unit_ug);
	fprintf(FileHandleInit, "%.9f\t", 0.0); // m/s
	
	// R 6
	fprintf(FileHandleInit, "%.9f\t", sqrt(*(*(InitParamKF.R) + 0 * SIZE_V + 0))); // m/s
	fprintf(FileHandleInit, "%.9f\t", sqrt(*(*(InitParamKF.R) + 2 * SIZE_V + 2))); // m/s
	fprintf(FileHandleInit, "%.9f\t", sqrt(*(*(InitParamKF.R) + 3 * SIZE_V + 3)) * Re); // m
	fprintf(FileHandleInit, "%.9f\t", sqrt(*(*(InitParamKF.R) + 5 * SIZE_V + 5))); // m
	fprintf(FileHandleInit, "%.9f\t", 0.0); // m
	fprintf(FileHandleInit, "%.9f\t", 0.0); // m/s
	
	// Markov ���ʱ�� 1
	fprintf(FileHandleInit, "%.9f\t", 0.0); // s
	fprintf(FileHandleInit, "\n");
	
	fclose(FileHandleInit);
	
	return 0;
}







/*
	Error message popup
*/
int ErrFunc(HRESULT errCode, char *errMesg)
{
    char        errStr[200];
    
    CA_GetAutomationErrorString (errCode, errStr, 200);
    MessagePopup ("ERROR MESSAGE", errStr);
    if (errMesg)
    {
        MessagePopup ("MATLAB ERROR MESSAGE", errMesg);
        CA_FreeMemory (errMesg);
    }
	return 0;
}


/*
	Close MATLAB
*/
int CloseMatlab(CAObjHandle *hMatlabPtr)
{
    HRESULT     stat    =   0;
    
    /* Exit MATLAB if it is running */
    if (*hMatlabPtr && hMatlabPtr)
    {
        stat = MLApp_DIMLAppQuit (*hMatlabPtr, NULL);
        if (stat < 0)
        {
            ErrFunc(stat, NULL);
            return (int)stat;
        }
        else
        {
            stat = CA_DiscardObjHandle (*hMatlabPtr);
            if (stat < 0)
            {
                ErrFunc(stat, NULL);
                return (int)stat;
            }
            *hMatlabPtr=0;
            return SUCCESS;
        }
    }
    else
        return ERROR_WRONG_HANDLE;
}



/*
	Check if the memory is allocated
*/
int CheckMemory(void)
{
	int i;
	
	// Check memory
	if (LengthImu != 0)
	{
		LengthImu = 0;
		
		free(TimeImu);
		
		free(Wibbx);
		free(Wibby); 
		free(Wibbz);
		free(Fbx); 
		free(Fby);
		free(Fbz);
	}
	
	if (LengthGnss != 0)
	{
		LengthGnss = 0;
		
		free(TimePps);
		free(NavParamGnss);
	}
	
	if (LengthGnssFixed != 0)
	{
		LengthGnssFixed = 0;
		
		free(TimeGnssFixed);
		
		free(LaGnssFixed);
		free(LonGnssFixed); 
		free(AltGnssFixed);
		free(VeGnssFixed); 
		free(VnGnssFixed);
		free(VuGnssFixed);
	}
	
	if (LengthNorm != 0)
	{
		LengthNorm = 0;
		
		free(TimeNorm);
		
		free(PitchNorm);
		free(RollNorm);
		free(YawNorm);
		free(VeNorm);
		free(VnNorm);
		free(VuNorm);
		free(LaNorm);
		free(LonNorm);
		free(AltNorm);
	}
	
	if (LengthNav != 0)
	{
		LengthNav = 0;

		free(TimeNav);
		free(PitchNav);
		free(RollNav);
		free(YawNav);
		free(VeNav);
		free(VnNav);
		free(VuNav);
		free(LaNav);
		free(LonNav);
		free(AltNav);
	}
	
	if (LengthEst != 0)
	{
		LengthEst = 0;
		
		free(TimeEst);
		
		for (i = 0; i < SIZE_X; i ++)
		{
			free(PMSE[i]);
		}
	}
	
	return 0;
}


/*
	Check if the MATLAB plot is opened
*/
int CheckPlot(void)
{
	if (HandleMatlab)
    {
		// Close all plot
        if (RunMatlabCommand(HandleMatlab, "close all;") != SUCCESS)
        {
            MessagePopup ("ERROR", "Error in sending command to MATLAB");
        }
    }
	
	return 0;
}

/*
	Check if the MATLAB is opened
*/
int CheckMatlab(void)
{
	if (HandleMatlab)
    {
		// Close MATLAB
        if (CloseMatlab(&HandleMatlab) != SUCCESS)
        {
            MessagePopup ("ERROR", "Error in closing MATLAB");
        }
    }
	
	StatusMatlab = 0;
	
	return 0;
}


/*
	UI control dimmed or undimmed
*/
int UIRDimming(int state)
{
	SetCtrlAttribute(PANEL, PANEL_TOGGLEBUTTON_MAT, ATTR_DIMMED, state);
	SetCtrlAttribute(PANEL, PANEL_BUTTON_INIT, ATTR_DIMMED, state);
	SetCtrlAttribute(PANEL, PANEL_BUTTON_FILT, ATTR_DIMMED, state);
	SetCtrlAttribute(PANEL, PANEL_BUTTON_SAVE, ATTR_DIMMED, state);
	SetCtrlAttribute(PANEL, PANEL_BUTTON_DISPLAY, ATTR_DIMMED, state);
	SetCtrlAttribute(PANEL, PANEL_BUTTON_CLOSE_PLOT, ATTR_DIMMED, state);
	SetCtrlAttribute(PANEL, PANEL_BUTTON_EXIT, ATTR_DIMMED, state);
	ProcessDrawEvents();
	
	return 0;
}



/*
	Get IMU data once
*/
static int GetDataImu(void)
{
	int i;

	// Read file header
	fgets(StringTemp, STRING_LENGTH_MAX, FileHandleImu);
	
	LengthImport = 0;
	while(1)
	{
		fgets(StringTemp, STRING_LENGTH_MAX, FileHandleImu);
		LengthImport ++;
		
		
		// Check file end
		if (feof(FileHandleImu))
		{
			break;
		}
		if (LengthImport < TimeSimuBegin * 1 / InitParamSins.time_interval)
			continue;
		if (LengthImport >= TimeSimuEnd * 1 / InitParamSins.time_interval)
			break;
		
		
		PieceTemp2 = strtok(StringTemp, "\t");
		*(TimeImu + LengthImu) = atof(PieceTemp2); // ms
		
		for (i = 0; i < 6; i ++)
			PieceTemp2 = strtok(NULL, "\t");
		
		PieceTemp2 = strtok(NULL, "\t");
		*(Wibbx + LengthImu) = atof(PieceTemp2) / unit_rad2degree; // rad/s
		
		PieceTemp2 = strtok(NULL, "\t");
		*(Wibby + LengthImu) = atof(PieceTemp2) / unit_rad2degree; // rad/s
		
		PieceTemp2 = strtok(NULL, "\t");
		*(Wibbz + LengthImu) = atof(PieceTemp2) / unit_rad2degree; // rad/s
		
		PieceTemp2 = strtok(NULL, "\t");
		*(Fbx + LengthImu) = atof(PieceTemp2); // m/s^2
		
		PieceTemp2 = strtok(NULL, "\t");
		*(Fby + LengthImu) = atof(PieceTemp2); // m/s^2
		
		PieceTemp2 = strtok(NULL, "\t");
		*(Fbz + LengthImu) = atof(PieceTemp2); // m/s^2
		 

		// Counting
		LengthImu ++;
		
		// Memory check
		if (LengthImu % ALLOC_LENGTH_INTERVAL == 0)
		{
			TimeImu = (double *) realloc(TimeImu, sizeof(double) * ALLOC_LENGTH(LengthImu));
			Wibbx = (double *) realloc(Wibbx, sizeof(double) * ALLOC_LENGTH(LengthImu));
			Wibby = (double *) realloc(Wibby, sizeof(double) * ALLOC_LENGTH(LengthImu));
			Wibbz = (double *) realloc(Wibbz, sizeof(double) * ALLOC_LENGTH(LengthImu));
			Fbx = (double *) realloc(Fbx, sizeof(double) * ALLOC_LENGTH(LengthImu));
			Fby = (double *) realloc(Fby, sizeof(double) * ALLOC_LENGTH(LengthImu));
			Fbz = (double *) realloc(Fbz, sizeof(double) * ALLOC_LENGTH(LengthImu));
		}
		
	}


	return 0;
}


/*
	Get GNSS data once
*/
static int GetDataGnss(void)
{
	int i;
	double laTemp;
	double lonTemp;
	double Cet[3][3];
	double venuTemp[3];
	double vxyzTemp[3];

	// Read file header
	fgets(StringTemp, STRING_LENGTH_MAX, FileHandleGnss);
	
	LengthImport = 0;
	while(1)						   
	{
		fgets(StringTemp, STRING_LENGTH_MAX, FileHandleGnss);
		LengthImport ++;
		
		
		// Check file end
		if (feof(FileHandleGnss))
		{
			break;
		}
		if (LengthImport < TimeSimuBegin * 1 / InitParamKF.T)
			continue;
		if (LengthImport >= TimeSimuEnd * 1 / InitParamKF.T)
			break;
		
		
		PieceTemp2 = strtok(StringTemp, "\t");
		*(TimePps + LengthGnss) = atof(PieceTemp2); // ms

		PieceTemp2 = strtok(NULL, "\t");
		(NavParamGnss + LengthGnss)->time = atof(PieceTemp2); // ms

		PieceTemp2 = strtok(NULL, "\t");
		
		PieceTemp2 = strtok(NULL, "\t");
		(NavParamGnss + LengthGnss)->fixQuality = atoi(PieceTemp2);

		PieceTemp2 = strtok(NULL, "\t");
		(NavParamGnss + LengthGnss)->svNumber = atoi(PieceTemp2);

		PieceTemp2 = strtok(NULL, "\t");
		(NavParamGnss + LengthGnss)->la = atof(PieceTemp2) / unit_rad2degree; // rad

		PieceTemp2 = strtok(NULL, "\t");
		(NavParamGnss + LengthGnss)->lon = atof(PieceTemp2) / unit_rad2degree; // rad

		PieceTemp2 = strtok(NULL, "\t");
		(NavParamGnss + LengthGnss)->alt = atof(PieceTemp2); // m
		
		PieceTemp2 = strtok(NULL, "\t");

		PieceTemp2 = strtok(NULL, "\t");
		(NavParamGnss + LengthGnss)->pxyz[0] = atof(PieceTemp2); // m

		PieceTemp2 = strtok(NULL, "\t");
		(NavParamGnss + LengthGnss)->pxyz[1] = atof(PieceTemp2); // m

		PieceTemp2 = strtok(NULL, "\t");
		(NavParamGnss + LengthGnss)->pxyz[2] = atof(PieceTemp2);  // m

		PieceTemp2 = strtok(NULL, "\t");
		(NavParamGnss + LengthGnss)->vxyz[0] = atof(PieceTemp2); // m/s

		PieceTemp2 = strtok(NULL, "\t");
		(NavParamGnss + LengthGnss)->vxyz[1] = atof(PieceTemp2); // m/s

		PieceTemp2 = strtok(NULL, "\t");
		(NavParamGnss + LengthGnss)->vxyz[2] = atof(PieceTemp2); // m/s

		for (i = 0; i < RECEIVER_CHANNEL; i++)
		{
			PieceTemp2 = strtok(NULL, "\t");
			(NavParamGnss + LengthGnss)->channel[i].svNo = atoi(PieceTemp2);

			PieceTemp2 = strtok(NULL, "\t");
			(NavParamGnss + LengthGnss)->channel[i].SNR = atoi(PieceTemp2);

			PieceTemp2 = strtok(NULL, "\t");
			(NavParamGnss + LengthGnss)->channel[i].pseu = atof(PieceTemp2); // m

			PieceTemp2 = strtok(NULL, "\t");
			(NavParamGnss + LengthGnss)->channel[i].pseuRate = atof(PieceTemp2); // m/s

			PieceTemp2 = strtok(NULL, "\t");
			(NavParamGnss + LengthGnss)->channel[i].pxyz[0] = atof(PieceTemp2); // m

			PieceTemp2 = strtok(NULL, "\t");
			(NavParamGnss + LengthGnss)->channel[i].pxyz[1] = atof(PieceTemp2); // m

			PieceTemp2 = strtok(NULL, "\t");
			(NavParamGnss + LengthGnss)->channel[i].pxyz[2] = atof(PieceTemp2); // m

			PieceTemp2 = strtok(NULL, "\t");
			(NavParamGnss + LengthGnss)->channel[i].vxyz[0] = atof(PieceTemp2); // m/s

			PieceTemp2 = strtok(NULL, "\t");
			(NavParamGnss + LengthGnss)->channel[i].vxyz[1] = atof(PieceTemp2); // m/s

			PieceTemp2 = strtok(NULL, "\t");
			(NavParamGnss + LengthGnss)->channel[i].vxyz[2] = atof(PieceTemp2); // m/s
		} 
		
		
		// Counting
		LengthGnss ++;
		
		// Memory check
		if (LengthGnss % ALLOC_LENGTH_INTERVAL == 0)
		{
			TimePps = (double *) realloc(TimePps, sizeof(double) * ALLOC_LENGTH(LengthGnss));
			NavParamGnss = (GNSS_NAV_PARAM *) realloc(NavParamGnss, sizeof(GNSS_NAV_PARAM) * ALLOC_LENGTH(LengthGnss));
		}
		
		
		// Record positioned GNSS data
		if ((NavParamGnss + (LengthGnss - 1))->fixQuality != 0)
		{
			
			laTemp = (NavParamGnss + (LengthGnss - 1))->la;
			lonTemp = (NavParamGnss + (LengthGnss - 1))->lon;
			vxyzTemp[0] = (NavParamGnss + (LengthGnss - 1))->vxyz[0];
			vxyzTemp[1] = (NavParamGnss + (LengthGnss - 1))->vxyz[1];
			vxyzTemp[2] = (NavParamGnss + (LengthGnss - 1))->vxyz[2];
			
			Cet[0][0] = cos(pi / 2 + lonTemp);
			Cet[0][1] = sin(pi / 2 + lonTemp);
			Cet[0][2] = 0;
			Cet[1][0] = -cos(pi / 2 - laTemp) * sin(pi / 2 + lonTemp);
			Cet[1][1] = cos(pi / 2 - laTemp) * cos(pi / 2 + lonTemp);
			Cet[1][2] = sin(pi / 2 - laTemp);
			Cet[2][0] = sin(pi / 2 - laTemp) * sin(pi / 2 + lonTemp);
			Cet[2][1] = -sin(pi / 2 - laTemp) * cos(pi / 2 + lonTemp);
			Cet[2][2] = cos(pi / 2 - laTemp);
			
			matMul(venuTemp, 3, 1, *Cet, 3, 3, vxyzTemp, 3, 1);
			
			
			*(TimeGnssFixed + LengthGnssFixed) = (NavParamGnss + LengthGnss - 1)->time;
			*(LaGnssFixed + LengthGnssFixed) = (NavParamGnss + (LengthGnss - 1))->la * unit_rad2degree;
			*(LonGnssFixed + LengthGnssFixed) = (NavParamGnss + (LengthGnss - 1))->lon * unit_rad2degree;
			*(AltGnssFixed + LengthGnssFixed) = (NavParamGnss + (LengthGnss - 1))->alt;
			*(VeGnssFixed + LengthGnssFixed) = venuTemp[0];
			*(VnGnssFixed + LengthGnssFixed) = venuTemp[1];
			*(VuGnssFixed + LengthGnssFixed) = venuTemp[2];
			
			
			LengthGnssFixed ++;
			
			if (LengthGnssFixed % ALLOC_LENGTH_INTERVAL == 0)
			{
				TimeGnssFixed = (double *) realloc(TimeGnssFixed, sizeof(double) * ALLOC_LENGTH(LengthGnssFixed));
				LaGnssFixed = (double *) realloc(LaGnssFixed, sizeof(double) * ALLOC_LENGTH(LengthGnssFixed));
				LonGnssFixed = (double *) realloc(LonGnssFixed, sizeof(double) * ALLOC_LENGTH(LengthGnssFixed));
				AltGnssFixed = (double *) realloc(AltGnssFixed, sizeof(double) * ALLOC_LENGTH(LengthGnssFixed));
				VeGnssFixed = (double *) realloc(VeGnssFixed, sizeof(double) * ALLOC_LENGTH(LengthGnssFixed));
				VnGnssFixed = (double *) realloc(VnGnssFixed, sizeof(double) * ALLOC_LENGTH(LengthGnssFixed));
				VuGnssFixed = (double *) realloc(VuGnssFixed, sizeof(double) * ALLOC_LENGTH(LengthGnssFixed));
			}
		}
		
	}


	return 0;
}



/*
	Get normal data once
*/
static int GetDataNorm(void)
{
	int i;
	
	// Read file header
	fgets(StringTemp, STRING_LENGTH_MAX, FileHandleNorm);
	
	LengthImport = 0;
	while(1)
	{
		fgets(StringTemp, STRING_LENGTH_MAX, FileHandleNorm);
		LengthImport ++;
		
		// Check file end
		if (feof(FileHandleNorm))
		{
			break;
		}
		if (LengthImport < TimeSimuBegin * FrequencyNorm)
			continue;
		if (LengthImport >= TimeSimuEnd * FrequencyNorm)
			break;
		
		PieceTemp2 = strtok(StringTemp, "\t");
		*(TimeNorm + LengthNorm) = atof(PieceTemp2); // ms
		
		PieceTemp2 = strtok(NULL, "\t");
		
		PieceTemp2 = strtok(NULL, "\t");
		*(LonNorm + LengthNorm) = atof(PieceTemp2); // degrees
		
		PieceTemp2 = strtok(NULL, "\t");
		*(LaNorm + LengthNorm) = atof(PieceTemp2); // degrees
		
		PieceTemp2 = strtok(NULL, "\t");
		*(AltNorm + LengthNorm) = atof(PieceTemp2); // m
		
		PieceTemp2 = strtok(NULL, "\t");
		*(VeNorm + LengthNorm) = atof(PieceTemp2); // m/s
		
		PieceTemp2 = strtok(NULL, "\t");
		*(VnNorm + LengthNorm) = atof(PieceTemp2); // m/s
		
		PieceTemp2 = strtok(NULL, "\t");
		*(VuNorm + LengthNorm) = atof(PieceTemp2); // m/s
		
		PieceTemp2 = strtok(NULL, "\t");
		*(YawNorm + LengthNorm) = atof(PieceTemp2); // degrees
		
		PieceTemp2 = strtok(NULL, "\t");
		*(PitchNorm + LengthNorm) = atof(PieceTemp2); // degrees
		
		PieceTemp2 = strtok(NULL, "\t");
		*(RollNorm + LengthNorm) = atof(PieceTemp2); // degrees

		
		// Counting
		LengthNorm ++;
		
		// Memory check
		if (LengthNorm % ALLOC_LENGTH_INTERVAL == 0)
		{
			TimeNorm = (double *) realloc(TimeNorm, sizeof(double) * ALLOC_LENGTH(LengthNorm));
			PitchNorm = (double *) realloc(PitchNorm, sizeof(double) * ALLOC_LENGTH(LengthNorm));
			RollNorm = (double *) realloc(RollNorm, sizeof(double) * ALLOC_LENGTH(LengthNorm));
			YawNorm = (double *) realloc(YawNorm, sizeof(double) * ALLOC_LENGTH(LengthNorm));
			VeNorm = (double *) realloc(VeNorm, sizeof(double) * ALLOC_LENGTH(LengthNorm));
			VnNorm = (double *) realloc(VnNorm, sizeof(double) * ALLOC_LENGTH(LengthNorm));
			VuNorm = (double *) realloc(VuNorm, sizeof(double) * ALLOC_LENGTH(LengthNorm));
			LaNorm = (double *) realloc(LaNorm, sizeof(double) * ALLOC_LENGTH(LengthNorm));
			LonNorm = (double *) realloc(LonNorm, sizeof(double) * ALLOC_LENGTH(LengthNorm));
			AltNorm = (double *) realloc(AltNorm, sizeof(double) * ALLOC_LENGTH(LengthNorm));
		}
		
	}

	return 0;
}


/*
	Initialize parameters
*/
static int InitNavParam(void)
{
	
	int fileExist = 0;
	int fileSize = 0;
	int i;
	
	if (FlagInit == 0)
	{
		// ���������� 2
		InitParamSins.time_interval = 1 / 100.0;
		InitParamKF.T = 1 / 10.0;
		
		// ��ʼ�������� 9
		InitParamSins.pitch0 = (0. / unit_rad2degree);
		InitParamSins.roll0 = (0. / unit_rad2degree);
		InitParamSins.yaw0 = (0. / unit_rad2degree);
		InitParamSins.ve0 = 0.;
		InitParamSins.vn0 = 0.;
		InitParamSins.vu0 = 0.;
		InitParamSins.la0 = (39. / unit_rad2degree);
		InitParamSins.lon0 = (116. / unit_rad2degree);
		InitParamSins.h0 = 100;
	
		// ��ʼ��� mx0 17
		*(InitParamKF.mx0 + 0) = 0.01 / unit_rad2degree; // rad
		*(InitParamKF.mx0 + 1) = 0.01 / unit_rad2degree; // rad
		*(InitParamKF.mx0 + 2) = 0.01 / unit_rad2degree; // rad
	
		*(InitParamKF.mx0 + 3) = 0; // m/s
		*(InitParamKF.mx0 + 4) = 0; // m/s
		*(InitParamKF.mx0 + 5) = 0; // m/s
	
		*(InitParamKF.mx0 + 6) = 0 / Re; // rad
		*(InitParamKF.mx0 + 7) = 0 / Re; // rad
		*(InitParamKF.mx0 + 8) = 0; // m
	
		*(InitParamKF.mx0 + 9) = 1.1 * unit_w; // rad/s
		*(InitParamKF.mx0 + 10) = 1.1 * unit_w; // rad/s
		*(InitParamKF.mx0 + 11) = 1.1 * unit_w; // rad/s
	
		*(InitParamKF.mx0 + 12) = 31 * unit_ug; // m/s^2
		*(InitParamKF.mx0 + 13) = 31 * unit_ug; // m/s^2
		*(InitParamKF.mx0 + 14) = 31 * unit_ug; // m/s^2
	
		*(InitParamKF.mx0 + 15) = 1; // m
		*(InitParamKF.mx0 + 16) = 0.1; // m/s
	
	
		// ���MSE Cx0 17
		*(*(InitParamKF.Cx0) + 0 * SIZE_X + 0) = pow(1e-4 / unit_rad2degree, 2); // rad
		*(*(InitParamKF.Cx0) + 1 * SIZE_X + 1) = pow(1e-4 / unit_rad2degree, 2); // rad
		*(*(InitParamKF.Cx0) + 2 * SIZE_X + 2) = pow(1e-4 / unit_rad2degree, 2); // rad
	
		*(*(InitParamKF.Cx0) + 3 * SIZE_X + 3) = pow(0.01, 2); // m/s
		*(*(InitParamKF.Cx0) + 4 * SIZE_X + 4) = pow(0.01, 2); // m/s
		*(*(InitParamKF.Cx0) + 5 * SIZE_X + 5) = pow(0.01, 2); // m/s
	
		*(*(InitParamKF.Cx0) + 6 * SIZE_X + 6) = pow(0.1 / Re, 2); // rad
		*(*(InitParamKF.Cx0) + 7 * SIZE_X + 7) = pow(0.1 / Re, 2); // rad
		*(*(InitParamKF.Cx0) + 8 * SIZE_X + 8) = pow(0.1, 2); // m
	
		*(*(InitParamKF.Cx0) + 9 * SIZE_X + 9) = pow(0.01 * unit_w, 2); // rad/s
		*(*(InitParamKF.Cx0) + 10 * SIZE_X + 10) = pow(0.01 * unit_w, 2); // rad/s
		*(*(InitParamKF.Cx0) + 11 * SIZE_X + 11) = pow(0.01 * unit_w, 2); // rad/s
	
		*(*(InitParamKF.Cx0) + 12 * SIZE_X + 12) = pow(1 * unit_ug, 2); // m/s^2
		*(*(InitParamKF.Cx0) + 13 * SIZE_X + 13) = pow(1 * unit_ug, 2); // m/s^2
		*(*(InitParamKF.Cx0) + 14 * SIZE_X + 14) = pow(1 * unit_ug, 2); // m/s^2
	
		*(*(InitParamKF.Cx0) + 15 * SIZE_X + 14) = pow(1, 2); // m
		*(*(InitParamKF.Cx0) + 6 * SIZE_X + 14) = pow(0.1, 2); // m/s^2
	
	
		// Q  7
		*(*(InitParamKF.Q) + 0 * SIZE_W + 0) = 0.01 * unit_w; // rad/s
		*(*(InitParamKF.Q) + 1 * SIZE_W + 1) = 0.01 * unit_w; // rad/s
		*(*(InitParamKF.Q) + 2 * SIZE_W + 2) = 0.01 * unit_w; // rad/s
		*(*(InitParamKF.Q) + 3 * SIZE_W + 3) = 1 * unit_ug; // m/s^2
		*(*(InitParamKF.Q) + 4 * SIZE_W + 4) = 1 * unit_ug; // m/s^2
		*(*(InitParamKF.Q) + 5 * SIZE_W + 5) = 1 * unit_ug; // m/s^2
	
	
		// R 6
		*(*(InitParamKF.R) + 0 * SIZE_V + 0) = 0.1; // m/s
		*(*(InitParamKF.R) + 1 * SIZE_V + 1) = 0.1; // m/s
		*(*(InitParamKF.R) + 2 * SIZE_V + 2) = 0.1; // m/s
		*(*(InitParamKF.R) + 3 * SIZE_V + 3) = 1; // m
		*(*(InitParamKF.R) + 4 * SIZE_V + 4) = 1; // m
		*(*(InitParamKF.R) + 5 * SIZE_V + 5) = 1; // m
		
		
		InsertTextBoxLine (PANEL, PANEL_TEXTBOX, TextBoxLineIndex ++ , "Navigation: Initialization with default parameters!");
		ProcessDrawEvents();
	}
	else
	{
		ImportInitData();
		
		InsertTextBoxLine (PANEL, PANEL_TEXTBOX, TextBoxLineIndex ++ , "Navigation: Initialization success!");
		ProcessDrawEvents();
	}
	
	return 0;
}


/*
	Navigation algorithm
*/
static int Nav(void)
{
	int i, j;
	int indexGnss;
	
	int flagSync;
	double timeSync;
	double laSync, lonSync, altSync;
	double veSync, vnSync, vuSync;
	double laError, lonError, altError;
	double veError, vnError, vuError;
	double Ctc[3][3];
	double Cet[3][3];
	double Ctb[3][3];
	double Qtb[4];
	double laTemp, lonTemp;
	double venuTemp[3], vxyzTemp[3];
	
	
	// Install progress bar panel
	HandlePsubProg = LoadPanel (PANEL, "sub_prog.uir", PSUB_INIT);
	
	SetCtrlAttribute (HandlePsubProg, PSUB_PROG_NUMERICSLIDE_PROG, ATTR_MAX_VALUE, (double) LengthImu);
		  
	// Wait until quit the sub panel
	InstallPopup (HandlePsubProg);
	
	
	// Memory to record navigation results
	LengthNav = LengthImu + 1;
	
	TimeNav = (double *) malloc (sizeof(double) * (LengthNav));
	PitchNav = (double *) malloc (sizeof(double) * (LengthNav));
	RollNav = (double *) malloc (sizeof(double) * (LengthNav));
	YawNav = (double *) malloc (sizeof(double) * (LengthNav));
	VeNav = (double *) malloc (sizeof(double) * (LengthNav));
	VnNav = (double *) malloc (sizeof(double) * (LengthNav));
	VuNav = (double *) malloc (sizeof(double) * (LengthNav));
	LaNav = (double *) malloc (sizeof(double) * (LengthNav));
	LonNav = (double *) malloc (sizeof(double) * (LengthNav));
	AltNav = (double *) malloc (sizeof(double) * (LengthNav));
	
	
	// Memory to record estimation results
	LengthEst = 0;
	
	TimeEst = (double *) malloc (sizeof(double) * (LengthGnssFixed));
	for (i = 0; i < SIZE_X; i ++)
		PMSE[i] = (double *) malloc (sizeof(double) * (LengthGnssFixed));
	
	
	// Initialization for SINS
	NavParamOld = sinsInit(InitParamSins);
	KfParamOld = kfInit(InitParamKF, SIZE_X, SIZE_W, SIZE_V);
	
	indexGnss = 0;
	flagSync = 0;
	
	for (i = 0; i < LengthImu; i ++)
	{
		MeasurementIMU.w[0] = *(Wibbx + i);
		MeasurementIMU.w[1] = *(Wibby + i);
		MeasurementIMU.w[2] = *(Wibbz + i);
		MeasurementIMU.f[0] = *(Fbx + i);
		MeasurementIMU.f[1] = *(Fby + i);
		MeasurementIMU.f[2] = *(Fbz + i);
		
		// SINS
		NavParamNew = sinsStrapdown(MeasurementIMU, NavParamOld, HEIGHT_USED);
		
		if (FlagNavMode == 1)
		{
			// Time synchronization
			if (indexGnss > LengthGnss)
				flagSync = -1;
			else
			{
				if (flagSync == 0)
				{
					while (*(TimePps + indexGnss) < *(TimeImu + i))
					{
						indexGnss ++;
						if (indexGnss > LengthGnss)
						{
							flagSync = -1;
							break;
						}
					}
					if (flagSync != -1)
						flagSync = 1;
				}
			
				// Seek one PPS
				if (flagSync == 1)
				{
					if ((*(TimePps + indexGnss) >= *(TimeImu + i)) && (*(TimePps + indexGnss) <= *(TimeImu + i + 1)))
					{
						flagSync = 2;
				
						timeSync = *(TimePps + indexGnss);
				
						laSync = (NavParamNew.la - NavParamOld.la) / (*(TimeImu + i + 1) - *(TimeImu + i)) * (timeSync - *(TimeImu + i)) + NavParamOld.la;
						lonSync = (NavParamNew.lon - NavParamOld.lon) / (*(TimeImu + i + 1) - *(TimeImu + i)) * (timeSync - *(TimeImu + i)) + NavParamOld.lon;
						altSync = (NavParamNew.alt - NavParamOld.alt) / (*(TimeImu + i + 1) - *(TimeImu + i)) * (timeSync - *(TimeImu + i)) + NavParamOld.alt;
						veSync = (NavParamNew.v[0] - NavParamOld.v[0]) / (*(TimeImu + i + 1) - *(TimeImu + i)) * (timeSync - *(TimeImu + i)) + NavParamOld.v[0];
						vnSync = (NavParamNew.v[1] - NavParamOld.v[1]) / (*(TimeImu + i + 1) - *(TimeImu + i)) * (timeSync - *(TimeImu + i)) + NavParamOld.v[1];
						vuSync = (NavParamNew.v[2] - NavParamOld.v[2]) / (*(TimeImu + i + 1) - *(TimeImu + i)) * (timeSync - *(TimeImu + i)) + NavParamOld.v[2];
					}
					else
						flagSync = 0;
				}
			
				// Seek Gnss
				if (flagSync == 2)
				{
					if (((NavParamGnss + indexGnss)->time >= *(TimeImu + i)) && ((NavParamGnss + indexGnss)->time <= *(TimeImu + i + 1)))
					{
						flagSync = 3;
				
						laError = NavParamNew.la - laSync;
						lonError = NavParamNew.lon - lonSync;
						altError = NavParamNew.alt - altSync;
						veError = NavParamNew.v[0] - veSync;
						vnError = NavParamNew.v[1] - vnSync;
						vuError = NavParamNew.v[2] - vuSync;
					}
				}
			}
		
			// KF
			if (flagSync == 3)
			{
				if ((NavParamGnss + indexGnss)->fixQuality != 0)
				{
					// Transfer vxyz to venu
					laTemp = (NavParamGnss + indexGnss)->la;
					lonTemp = (NavParamGnss + indexGnss)->lon;
					vxyzTemp[0] = (NavParamGnss + indexGnss)->vxyz[0];
					vxyzTemp[1] = (NavParamGnss + indexGnss)->vxyz[1];
					vxyzTemp[2] = (NavParamGnss + indexGnss)->vxyz[2];
			
					Cet[0][0] = cos(pi / 2 + lonTemp);
					Cet[0][1] = sin(pi / 2 + lonTemp);
					Cet[0][2] = 0;
					Cet[1][0] = -cos(pi / 2 - laTemp) * sin(pi / 2 + lonTemp);
					Cet[1][1] = cos(pi / 2 - laTemp) * cos(pi / 2 + lonTemp);
					Cet[1][2] = sin(pi / 2 - laTemp);
					Cet[2][0] = sin(pi / 2 - laTemp) * sin(pi / 2 + lonTemp);
					Cet[2][1] = -sin(pi / 2 - laTemp) * cos(pi / 2 + lonTemp);
					Cet[2][2] = cos(pi / 2 - laTemp);
			
					matMul(venuTemp, 3, 1, *Cet, 3, 3, vxyzTemp, 3, 1);
				
					(NavParamGnss + indexGnss)->vgeo[0] = venuTemp[0];
					(NavParamGnss + indexGnss)->vgeo[1] = venuTemp[1];
					(NavParamGnss + indexGnss)->vgeo[2] = venuTemp[2];
				
				
					// Fix GNSS data
					(NavParamGnss + indexGnss)->vgeo[0] += veError;
					(NavParamGnss + indexGnss)->vgeo[1] += vnError;
					(NavParamGnss + indexGnss)->vgeo[2] += vuError;
					(NavParamGnss + indexGnss)->la += laError;
					(NavParamGnss + indexGnss)->lon += lonError;
					(NavParamGnss + indexGnss)->alt += altError;
				
				
					// KF
					KfParamNew = kf(KfParamOld, NavParamNew, *(NavParamGnss + indexGnss), MeasurementIMU);
					
					Ctc[0][0] = 1;
					Ctc[0][1] = *(KfParamNew.Xes + 2);
					Ctc[0][2] = -*(KfParamNew.Xes + 1);
					Ctc[1][0] = -*(KfParamNew.Xes + 2);
					Ctc[1][1] = 1;
					Ctc[1][2] = *(KfParamNew.Xes + 0);
					Ctc[2][0] = *(KfParamNew.Xes + 1);
					Ctc[2][1] = -*(KfParamNew.Xes + 0);
					Ctc[2][2] = 1;
					
		
					// Fix Euler matrix
					matMul((double *) Ctb, 3, 3, (double *) NavParamNew.Ctb, 3, 3, (double *) Ctc, 3, 3);
					
					Qtb[0] = sqrt(abs(1 + Ctb[0][0] + Ctb[1][1] + Ctb[2][2])) / 2;
					Qtb[1] = sqrt(abs(1 + Ctb[0][0] - Ctb[1][1] - Ctb[2][2])) / 2;
					Qtb[2] = sqrt(abs(1 - Ctb[0][0] + Ctb[1][1] - Ctb[2][2])) / 2;
					Qtb[3] = sqrt(abs(1 - Ctb[0][0] - Ctb[1][1] + Ctb[2][2])) / 2;
					
					if ((Ctb[1][2] - Ctb[2][1]) / (4 * Qtb[0]) < 0)
						Qtb[1] = -Qtb[1];
					if ((Ctb[2][0] - Ctb[0][2]) / (4 * Qtb[0]) < 0)
						Qtb[2] = -Qtb[2];
					if ((Ctb[0][1] - Ctb[1][0]) / (4 * Qtb[0]) < 0)
						Qtb[3] = -Qtb[3];
					
					NavParamNew.pitch = asin(Ctb[1][2]);
					NavParamNew.roll = atan2(-Ctb[0][2], Ctb[2][2]);
					NavParamNew.yaw = atan2(Ctb[1][0], Ctb[1][1]);
					if (NavParamNew.yaw < 0)
						NavParamNew.yaw = NavParamNew.yaw + 2 * pi;
					
		
					// Fix velocity and position
					NavParamNew.v[0] -= *(KfParamNew.Xes + 3);
					NavParamNew.v[1] -= *(KfParamNew.Xes + 4);
					NavParamNew.v[2] -= *(KfParamNew.Xes + 5);
					NavParamNew.la -= *(KfParamNew.Xes + 6);
					NavParamNew.lon -= *(KfParamNew.Xes + 7);
					NavParamNew.alt -= *(KfParamNew.Xes + 8);
			
					// Record estimation results
					*(TimeEst + LengthEst) = *(TimeImu + i);
					for (j = 0; j < SIZE_X; j ++)
						*(PMSE[j] + LengthEst) = sqrt(*(*KfParamOld.Pes + j * SIZE_X + j));
					LengthEst ++;
					
					// Refresh KF parameters
					KfParamOld = KfParamNew;
					
					indexGnss ++;
					flagSync = 0;
					
				} // if fixQuality != 0
				
				else
				{
					indexGnss ++;
					flagSync = 0;
				}
				
			} // if (flagSync == 3)
			
		} // if (FlagNavMode == 1)
		
		
		*(TimeNav + i) = *(TimeImu + i);
		*(PitchNav + i) = NavParamOld.pitch; // rad
		*(RollNav + i) = NavParamOld.roll;
		*(YawNav + i) = NavParamOld.yaw;
		*(VeNav + i) = NavParamOld.v[0];
		*(VnNav + i) = NavParamOld.v[1];
		*(VuNav + i) = NavParamOld.v[2];
		*(LaNav + i) = NavParamOld.la; // rad
		*(LonNav + i) = NavParamOld.lon;
		*(AltNav + i) = NavParamOld.alt;
		
		// Refresh navigation results
		NavParamOld = NavParamNew;
		
		// Set progress bar value
		SetCtrlVal (HandlePsubProg, PSUB_PROG_NUMERICSLIDE_PROG, (double) i);
		
	}
	*(TimeNav + i) = *(TimeNav + i - 1) + NavParamOld.T;
	*(PitchNav + i) = NavParamOld.pitch;
	*(RollNav + i) = NavParamOld.roll;
	*(YawNav + i) = NavParamOld.yaw;
	*(VeNav + i) = NavParamOld.v[0];
	*(VnNav + i) = NavParamOld.v[1];
	*(VuNav + i) = NavParamOld.v[2];
	*(LaNav + i) = NavParamOld.la;
	*(LonNav + i) = NavParamOld.lon;
	*(AltNav + i) = NavParamOld.alt;
	
	// Quit sub panel
	RemovePopup(0);
	
	return 0;
}












