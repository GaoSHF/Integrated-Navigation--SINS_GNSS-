

% Global definition
wie = 7.292115147e-5; % rad/s
Re = 6378245; % Earth radius, m
e = 1 / 298.3; % Earth eccentrity
g0 = 9.7803267714; % m/s^2
gk1 = 0.00193185138639;
gk2 = 0.00669437999013;

% Unit conversion
unit_degree2rad = (pi / 180); % degrees to rad
unit_w = (pi / 3600 / 180); % degrees/h to rad/s
unit_ug = (g0 * 10 ^ (-6)); % ug to m/s^2



len = length(TimeGnssFixed);
time = TimeGnssFixed * 0.001;
for i = len : (-1) : 1
    time(1, i) = time(1, i) - time(1, 1);
end


%% Drawing results
disp('Drawing GNSS begin.');
tic;

figure('name', 'GNSS Position');
subplot(3, 1, 1), 
plot(time(1, 1 : len), LaGnssFixed(1, 1 : len), 'Color', 'k'), hold on;
xlabel('Time/s'), ylabel('Latitude/degree'); grid on;
subplot(3, 1, 2), 
plot(time(1, 1 : len), LonGnssFixed(1, 1 : len), 'Color', 'k'), hold on;
xlabel('Time/s'), ylabel('Longitude/degree'); grid on;
subplot(3, 1, 3), 
plot(time(1, 1 : len), AltGnssFixed(1, 1 : len), 'Color', 'k'), hold on;
xlabel('Time/s'), ylabel('Altitude/m'); grid on;

figure('name', 'GNSS Velocity');
subplot(3, 1, 1), 
plot(time(1, 1 : len), VeGnssFixed(1, 1 : len), 'Color', 'k'), hold on;
xlabel('Time/s'), ylabel('East/m/s'); grid on;
subplot(3, 1, 2), 
plot(time(1, 1 : len), VnGnssFixed(1, 1 : len), 'Color', 'k'), hold on;
xlabel('Time/s'), ylabel('North/m/s'); grid on;
subplot(3, 1, 3), 
plot(time(1, 1 : len), VuGnssFixed(1, 1 : len), 'Color', 'k'), hold on;
xlabel('Time/s'), ylabel('Up/m/s'); grid on;



RuntimeDraw = toc;
disp(['Drawing results running time = ', num2str(RuntimeDraw), 's']);





