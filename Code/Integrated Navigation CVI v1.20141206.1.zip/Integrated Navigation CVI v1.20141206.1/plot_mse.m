

% Global definition
wie = 7.292115147e-5; % rad/s
Re = 6378245; % Earth radius, m
e = 1 / 298.3; % Earth eccentrity
g0 = 9.7803267714; % m/s^2
gk1 = 0.00193185138639;
gk2 = 0.00669437999013;

% Unit conversion
unit_degree2rad = (pi / 180); % degrees to rad
unit_w = (pi / 3600 / 180); % degrees/h to rad/s
unit_ug = (g0 * 10 ^ (-6)); % ug to m/s^2



%% Unit refresh
PMSE0 = PMSE0 / unit_degree2rad;
PMSE1 = PMSE1 / unit_degree2rad;
PMSE2 = PMSE2 / unit_degree2rad;

PMSE6 = PMSE6 * Re;
PMSE7 = PMSE7 * Re;

PMSE9 = PMSE9 / unit_w;
PMSE10 = PMSE10 / unit_w;
PMSE11 = PMSE11 / unit_w;

PMSE12 = PMSE12 / unit_ug;
PMSE13 = PMSE13 / unit_ug;
PMSE14 = PMSE14 / unit_ug;


len = length(TimeEst);
time = TimeEst * 0.001;
for i = len : (-1) : 1
    time(1, i) = time(1, i) - time(1, 1);
end


%% Drawing results
disp('Drawing results begin.');
tic;


figure('name', 'Alignment Estimation MSE');
subplot(3, 1, 1), 
plot(time(1, 1 : len), PMSE0(1, 1 : len), 'Color', 'k'), hold on;
xlabel('Time/s'), ylabel('East/degree'); grid on;
subplot(3, 1, 2), 
plot(time(1, 1 : len), PMSE1(1, 1 : len), 'Color', 'k'), hold on;
xlabel('Time/s'), ylabel('North/degree'); grid on;
subplot(3, 1, 3), 
plot(time(1, 1 : len), PMSE2(1, 1 : len), 'Color', 'k'), hold on;
xlabel('Time/s'), ylabel('Up/degree'); grid on;

figure('name', 'Velocity Error Estimation MSE');
subplot(3, 1, 1), 
plot(time(1, 1 : len), PMSE3(1, 1 : len), 'Color', 'k'), hold on;
xlabel('Time/s'), ylabel('East/m/s'); grid on;
subplot(3, 1, 2), 
plot(time(1, 1 : len), PMSE4(1, 1 : len), 'Color', 'k'), hold on;
xlabel('Time/s'), ylabel('North/m/s'); grid on;
subplot(3, 1, 3), 
plot(time(1, 1 : len), PMSE5(1, 1 : len), 'Color', 'k'), hold on;
xlabel('Time/s'), ylabel('Up/m/s'); grid on;



figure('name', 'Location Error Estimation MSE');
subplot(3, 1, 1), 
plot(time(1, 1 : len), PMSE7(1, 1 : len), 'Color', 'k'), hold on;
xlabel('Time/s'), ylabel('East/m'); grid on;
subplot(3, 1, 2), 
plot(time(1, 1 : len), PMSE6(1, 1 : len), 'Color', 'k'), hold on;
xlabel('Time/s'), ylabel('North/m'); grid on;
subplot(3, 1, 3), 
plot(time(1, 1 : len), PMSE8(1, 1 : len), 'Color', 'k'), hold on;
xlabel('Time/s'), ylabel('Up/m'); grid on;


figure('name', 'Gyroscope Drift Estimation MSE');
subplot(3, 1, 1), 
plot(time(1, 1 : len), PMSE9(1, 1 : len), 'Color', 'k'), hold on;
xlabel('Time/s'), ylabel('X/degree/h'); grid on;
subplot(3, 1, 2), 
plot(time(1, 1 : len), PMSE10(1, 1 : len), 'Color', 'k'), hold on;
xlabel('Time/s'), ylabel('Y/degree/h'); grid on;
subplot(3, 1, 3), 
plot(time(1, 1 : len), PMSE11(1, 1 : len), 'Color', 'k'), hold on;
xlabel('Time/s'), ylabel('Z/degree/h'); grid on;


figure('name', 'Accelerometer Bias Estimation MSE');
subplot(3, 1, 1), 
plot(time(1, 1 : len), PMSE12(1, 1 : len), 'Color', 'k'), hold on;
xlabel('Time/s'), ylabel('X/ug'); grid on;
subplot(3, 1, 2), 
plot(time(1, 1 : len), PMSE13(1, 1 : len), 'Color', 'k'), hold on;
xlabel('Time/s'), ylabel('Y/ug'); grid on;
subplot(3, 1, 3), 
plot(time(1, 1 : len), PMSE14(1, 1 : len), 'Color', 'k'), hold on;
xlabel('Time/s'), ylabel('Z/ug'); grid on;



RuntimeDraw = toc;
disp(['Drawing results running time = ', num2str(RuntimeDraw), 's']);





