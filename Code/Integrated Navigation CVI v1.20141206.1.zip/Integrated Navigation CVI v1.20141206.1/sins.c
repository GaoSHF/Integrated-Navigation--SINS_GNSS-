/* 
	ENU Coordinate rotation, 3-1-2, z-x-y, (-yaw)-pitch-roll
	1.Euler angle is coordinate rotate angle, not vector rotate.
	2.Clockwise from north to east is positive direction for yaw(converse to right hand rule).
*/

#include <math.h>

#include "sins.h"
#include "matrix.h"



// *****************  Local variables  ******************* //
// Radius of meridian plane and prime plane
double Rm, Rn;

// Angular velocity in navigation coordinate
double wiet[3], wett[3], wtbb[3], wTemp3x1[3];

// Euler matrix from carrier coordinate to navigation coordinate
double Cbt[3][3];
double Ctb[3][3];

// Accelerometer measurements in navigation coordinate
double ft[3];

// Gravity
double g;

double seitaDelta[16];
double seitaDeltaZero;
double eye4[16] = { 1, 0, 0, 0,
					0, 1, 0, 0,
					0, 0, 1, 0,
					0, 0, 0, 1 };
double mat4x4_1[16], mat4x4_2[16];

double quaternionNorm = 0;

double veTemp, vnTemp, vuTemp;
double laTemp, lonTemp, altTemp;


INS_NAV_PARAM		navParamTemp;



/*
	Set navigation parameters
*/
int sinsSetNavParam(INS_NAV_PARAM navParam)
{
	int i, j;

	// Return value
	T = navParam.T;
	la = navParam.la;
	lon = navParam.lon;
	alt = navParam.alt;
	pitch = navParam.pitch;
	roll = navParam.roll;
	yaw = navParam.yaw;
	for (i = 0; i < 3; i++)
	{
		v[i] = navParam.v[i];
	}
	for (i = 0; i < 4; i++)
	{
		Qtb[i] = navParam.Qtb[i];
	}
	for (i = 0; i < 3; i++)
	{
		for (j = 0; j < 3; j++)
		{
			Ctb[i][j] = navParam.Ctb[i][j];
		}
	}

	return 0;
}

/*
	Get navigation parameters
 */
INS_NAV_PARAM sinsGetNavParam()
{

	int i, j;

	// Return value
	navParamTemp.T = T;
	navParamTemp.la = la;
	navParamTemp.lon = lon;
	navParamTemp.alt = alt;
	navParamTemp.pitch = pitch;
	navParamTemp.roll = roll;
	navParamTemp.yaw = yaw;
	for (i = 0; i < 3; i++)
	{
		navParamTemp.v[i] = v[i];
	}
	for (i = 0; i < 4; i++)
	{
		navParamTemp.Qtb[i] = Qtb[i];
	}
	for (i = 0; i < 3; i++)
	{
		for (j = 0; j < 3; j++)
		{
			navParamTemp.Ctb[i][j] = Ctb[i][j];
		}
	}

	return navParamTemp;
}




/**
  *	Strapdown navigation coarse-alignment
  */
INS_NAV_PARAM sinsCoarseAlignment(IMU_MEASUREMENT measurements, INS_INIT_PARAM initParam) 
{

	T = initParam.time_interval;

	wibb[0] = measurements.w[0];
	wibb[1] = measurements.w[1];
	wibb[2] = measurements.w[2];

	fb[0] = measurements.f[0];
	fb[1] = measurements.f[1];
	fb[2] = measurements.f[2];

	v[0] = initParam.ve0;
	v[1] = initParam.vn0;
	v[2] = initParam.vu0;

	la = initParam.la0;
	lon = initParam.lon0;
	alt = initParam.h0;

	Ctb[0][2] = fb[0] / g0;
	Ctb[1][2] = fb[1] / g0;
	Ctb[2][2] = fb[2] / g0;

	Ctb[0][1] = (wibb[0] - wie * sin(la0) * Ctb[0][2]) / (wie * cos(la0));
	Ctb[1][1] = (wibb[1] - wie * sin(la0) * Ctb[1][2]) / (wie * cos(la0));
	Ctb[2][1] = (wibb[2] - wie * sin(la0) * Ctb[2][2]) / (wie * cos(la0));

	Ctb[0][0] = -Ctb[2][1] * Ctb[1][2] + Ctb[1][1] * Ctb[2][2];
	Ctb[1][0] = Ctb[2][1] * Ctb[0][2] - Ctb[0][1] * Ctb[2][2];
	Ctb[2][0] = -Ctb[1][1] * Ctb[0][2] + Ctb[0][1] * Ctb[1][2];

	pitch = asin(Ctb[1][2]); // -pi/2 to pi/2
    
    roll = atan2(-Ctb[0][2], Ctb[2][2]); // -pi to pi
    
    yaw = atan2(Ctb[1][0], Ctb[1][1]); // 0 to 2*pi
    if(yaw < 0)
        yaw += 2 * pi;


	Qtb[0] = sqrt(1 + Ctb[0][0] + Ctb[1][1] + Ctb[2][2]) / 2;
	Qtb[1] = sqrt(1 + Ctb[0][0] - Ctb[1][1] - Ctb[2][2]) / 2;
	Qtb[2] = sqrt(1 - Ctb[0][0] + Ctb[1][1] - Ctb[2][2]) / 2;
	Qtb[3] = sqrt(1 - Ctb[0][0] - Ctb[1][1] + Ctb[2][2]) / 2;
	
	if ((Ctb[1][2] - Ctb[2][1]) / (4 * Qtb[0]) < 0)
		Qtb[1] = -Qtb[1];
	if ((Ctb[2][0] - Ctb[0][2]) / (4 * Qtb[0]) < 0)
		Qtb[2] = -Qtb[2];
	if ((Ctb[0][1] - Ctb[1][0]) / (4 * Qtb[0]) < 0)
		Qtb[3] = -Qtb[3];
	
	return sinsGetNavParam();
}



/**
  *	Initiate navigation parameter (x: pitch; y: roll; z: yaw)
  */
INS_NAV_PARAM sinsInit(INS_INIT_PARAM initParam) {

	T = initParam.time_interval;

	pitch = initParam.pitch0;
	roll = initParam.roll0;
	yaw = initParam.yaw0;

	v[0] = initParam.ve0;
	v[1] = initParam.vn0;
	v[2] = initParam.vu0;

	la = initParam.la0;
	lon = initParam.lon0;
	alt = initParam.h0;

	// Method 1: Euler matrix to quaternion
	/*Ctb[0][0] = cos(roll) * cos(yaw) + sin(roll) * sin(yaw) * sin(pitch);
	Ctb[0][1] = -cos(roll) * sin(yaw) + sin(roll) * cos(yaw) * sin(pitch);
	Ctb[0][2] = -sin(roll) * cos(pitch);

	Ctb[1][0] = sin(yaw) * cos(pitch);
	Ctb[1][1] = cos(yaw) * cos(pitch);
	Ctb[1][2] = sin(pitch);

	Ctb[2][0] = sin(roll) * cos(yaw) - cos(roll) * sin(yaw) * sin(pitch);
	Ctb[2][1] = -sin(roll) * sin(yaw) - cos(roll) * cos(yaw) * sin(pitch);
	Ctb[2][2] = cos(roll) * cos(pitch);

	Qtb[0] = sqrt(1 + Ctb[0][0] + Ctb[1][1] + Ctb[2][2]) / 2;
	Qtb[1] = sqrt(1 + Ctb[0][0] - Ctb[1][1] - Ctb[2][2]) / 2;
	Qtb[2] = sqrt(1 - Ctb[0][0] + Ctb[1][1] - Ctb[2][2]) / 2;
	Qtb[3] = sqrt(1 - Ctb[0][0] - Ctb[1][1] + Ctb[2][2]) / 2;
	
	if ((Ctb[1][2] - Ctb[2][1]) / (4 * Qtb[0]) < 0)
		Qtb[1] = -Qtb[1];
	if ((Ctb[2][0] - Ctb[0][2]) / (4 * Qtb[0]) < 0)
		Qtb[2] = -Qtb[2];
	if ((Ctb[0][1] - Ctb[1][0]) / (4 * Qtb[0]) < 0)
		Qtb[3] = -Qtb[3];*/


	// Method 2: Quaternion to Euler matrix
	Qtb[0] = cos(yaw / 2) * cos(pitch / 2) * cos(roll / 2) + sin(yaw / 2) * sin(pitch / 2) * sin(roll / 2);
	Qtb[1] = cos(yaw / 2) * sin(pitch / 2) * cos(roll / 2) + sin(yaw / 2) * cos(pitch / 2) * sin(roll / 2);
	Qtb[2] = cos(yaw / 2) * cos(pitch / 2) * sin(roll / 2) - sin(yaw / 2) * sin(pitch / 2) * cos(roll / 2);
	Qtb[3] = cos(yaw / 2) * sin(pitch / 2) * sin(roll / 2) - sin(yaw / 2) * cos(pitch / 2) * cos(roll / 2);

	Ctb[0][0] = Qtb[0] * Qtb[0] + Qtb[1] * Qtb[1] - Qtb[2] * Qtb[2] - Qtb[3] * Qtb[3];
	Ctb[0][1] = 2 * (Qtb[1] * Qtb[2] + Qtb[0] * Qtb[3]);
	Ctb[0][2] = 2 * (Qtb[1] * Qtb[3] - Qtb[0] * Qtb[2]);

	Ctb[1][0] = 2 * (Qtb[1] * Qtb[2] - Qtb[0] * Qtb[3]);
	Ctb[1][1] = Qtb[0] * Qtb[0] - Qtb[1] * Qtb[1] + Qtb[2] * Qtb[2] - Qtb[3] * Qtb[3];
	Ctb[1][2] = 2 * (Qtb[2] * Qtb[3] + Qtb[0] * Qtb[1]);

	Ctb[2][0] = 2 * (Qtb[1] * Qtb[3] + Qtb[0] * Qtb[2]);
	Ctb[2][1] = 2 * (Qtb[2] * Qtb[3] - Qtb[0] * Qtb[1]);
	Ctb[2][2] = Qtb[0] * Qtb[0] - Qtb[1] * Qtb[1] - Qtb[2] * Qtb[2] + Qtb[3] * Qtb[3];

	return sinsGetNavParam();
}


/**
  *	1 step strapdown algorithm (Quaternion refresh, E-N-U coordinate)
  */
INS_NAV_PARAM sinsStrapdown(IMU_MEASUREMENT measurements, INS_NAV_PARAM nav_param_before, int height_switch) {

	int i;

	wibb[0] = measurements.w[0];
	wibb[1] = measurements.w[1];
	wibb[2] = measurements.w[2];

	fb[0] = measurements.f[0];
	fb[1] = measurements.f[1];
	fb[2] = measurements.f[2];

	// Set navigation paremeters
	sinsSetNavParam(nav_param_before);


	Rm = Re / (1 + 2 * e - 3 * e * sin(la * la));
	Rn = Re / (1 - e * sin(la * la));

	wiet[0] = 0;
	wiet[1] = wie * cos(la);
	wiet[2] = wie * sin(la);


	wett[0] = -v[1] / (Rm + alt);
	wett[1] = v[0] / (Rn + alt);
	wett[2] = v[0] / (Rn + alt) * tan(la);


	// Quaternion to Euler matrix
	Ctb[0][0] = Qtb[0] * Qtb[0] + Qtb[1] * Qtb[1] - Qtb[2] * Qtb[2] - Qtb[3] * Qtb[3];
	Ctb[0][1] = 2 * (Qtb[1] * Qtb[2] + Qtb[0] * Qtb[3]);
	Ctb[0][2] = 2 * (Qtb[1] * Qtb[3] - Qtb[0] * Qtb[2]);

	Ctb[1][0] = 2 * (Qtb[1] * Qtb[2] - Qtb[0] * Qtb[3]);
	Ctb[1][1] = Qtb[0] * Qtb[0] - Qtb[1] * Qtb[1] + Qtb[2] * Qtb[2] - Qtb[3] * Qtb[3];
	Ctb[1][2] = 2 * (Qtb[2] * Qtb[3] + Qtb[0] * Qtb[1]);

	Ctb[2][0] = 2 * (Qtb[1] * Qtb[3] + Qtb[0] * Qtb[2]);
	Ctb[2][1] = 2 * (Qtb[2] * Qtb[3] - Qtb[0] * Qtb[1]);
	Ctb[2][2] = Qtb[0] * Qtb[0] - Qtb[1] * Qtb[1] - Qtb[2] * Qtb[2] + Qtb[3] * Qtb[3];


	// Cbt = Ctb'
	matTranspose((double *) Cbt, (double *) Ctb, 3, 3);

	// ft = Cbt * fb
	matMul(ft, 3, 1, (double *) Cbt, 3, 3, fb, 3, 1);

	// Speed reckon: v_t(k + 1) = v_t(k) + a_t(k) * T
	veTemp = (ft[0] + (2 * wiet[2] + wett[2]) * v[1] - (2 * wiet[1] + wett[1]) * v[2]) * T + v[0];
    vnTemp = (ft[1] - (2 * wiet[2] + wett[2]) * v[0] + (2 * wiet[0] + wett[0]) * v[2]) * T + v[1];
	if(height_switch == HEIGHT_USED) {
		g = g0 * (1 + gk1 * sin(la) * sin(la)) * (1 - 2 * alt / Re) / sqrt(1 - gk2 * sin(la) * sin(la));
        
		vuTemp = (ft[2] + (2 * wiet[1] + wett[1]) * v[0] - (2 * wiet[0] + wett[0]) * v[1] - g) * T + v[2];
	}
	else
	{
		vuTemp = v[2];
	}

	// Location reckon
	laTemp = v[1] / (Rm + alt) * T + la;
	lonTemp = v[0] / ((Rn + alt) * cos(la)) * T + lon;
    altTemp = v[2] * T + alt;

	// Refresh velocity and location
	v[0] = veTemp;
	v[1] = vnTemp;
	v[2] = vuTemp;
	la = laTemp;
	lon = lonTemp;
	alt = altTemp;

	// Angular velocity from navigation coordinate to carrier coordinate
	// wtbb = wibb(:, count) - Ctb * (wiet + wett);
	matPlus(wTemp3x1, wiet, wett, 3, 1);
	matMul(wTemp3x1, 3, 1, (double *) Ctb, 3, 3, wTemp3x1, 3, 1);
	matMinus(wtbb, wibb, wTemp3x1, 3, 1);


	// Quaternion refresh
	seitaDelta[0] = 0;
	seitaDelta[1] = -wtbb[0] * T;
	seitaDelta[2] = -wtbb[1] * T;
	seitaDelta[3] = -wtbb[2] * T;

	seitaDelta[4] = wtbb[0] * T;
	seitaDelta[5] = 0;
	seitaDelta[6] = wtbb[2] * T;
	seitaDelta[7] = -wtbb[1] * T;

	seitaDelta[8] = wtbb[1] * T;
	seitaDelta[9] = -wtbb[2] * T;
	seitaDelta[10] = 0;
	seitaDelta[11] = wtbb[0] * T;

	seitaDelta[12] = wtbb[2] * T;
	seitaDelta[13] = wtbb[1] * T;
	seitaDelta[14] = -wtbb[0] * T;
	seitaDelta[15] = 0;

	seitaDeltaZero = sqrt(seitaDelta[1] * seitaDelta[1] + seitaDelta[2] * seitaDelta[2] + seitaDelta[3] * seitaDelta[3]);

	//Qtb = (cos(seitaDeltaZero / 2) * eye(4) + sin(seitaDeltaZero / 2) / seitaDeltaZero * seitaDelta) * Qtb;
	matConstantMul(mat4x4_1, cos(seitaDeltaZero / 2), eye4, 4, 4);
	matConstantMul(mat4x4_2, sin(seitaDeltaZero / 2) / seitaDeltaZero, seitaDelta, 4, 4);
	matPlus(mat4x4_1, mat4x4_1, mat4x4_2, 4, 4);
	matMul(Qtb, 4, 1, mat4x4_1, 4, 4, Qtb, 4, 1);
	
	// Normalization of quaternion
	quaternionNorm = 0;
	for (i = 0; i < 4; i++)
	{
		quaternionNorm += Qtb[i] * Qtb[i];
	}
	quaternionNorm = sqrt(quaternionNorm);
	for (i = 0; i < 4; i++)
	{
		Qtb[i] /= quaternionNorm;
	}
	
	
	// Quaternion to Euler matrix
	Ctb[0][0] = Qtb[0] * Qtb[0] + Qtb[1] * Qtb[1] - Qtb[2] * Qtb[2] - Qtb[3] * Qtb[3];
	Ctb[0][1] = 2 * (Qtb[1] * Qtb[2] + Qtb[0] * Qtb[3]);
	Ctb[0][2] = 2 * (Qtb[1] * Qtb[3] - Qtb[0] * Qtb[2]);

	Ctb[1][0] = 2 * (Qtb[1] * Qtb[2] - Qtb[0] * Qtb[3]);
	Ctb[1][1] = Qtb[0] * Qtb[0] - Qtb[1] * Qtb[1] + Qtb[2] * Qtb[2] - Qtb[3] * Qtb[3];
	Ctb[1][2] = 2 * (Qtb[2] * Qtb[3] + Qtb[0] * Qtb[1]);

	Ctb[2][0] = 2 * (Qtb[1] * Qtb[3] + Qtb[0] * Qtb[2]);
	Ctb[2][1] = 2 * (Qtb[2] * Qtb[3] - Qtb[0] * Qtb[1]);
	Ctb[2][2] = Qtb[0] * Qtb[0] - Qtb[1] * Qtb[1] - Qtb[2] * Qtb[2] + Qtb[3] * Qtb[3];
	
	// Refresh attitude
	pitch = asin(Ctb[1][2]); // -pi/2 to pi/2
    
    roll = atan2(-Ctb[0][2], Ctb[2][2]); // -pi to pi
    
    yaw = atan2(Ctb[1][0], Ctb[1][1]); // 0 to 2*pi
    if(yaw < 0)
        yaw += 2 * pi;

	return sinsGetNavParam();
}

