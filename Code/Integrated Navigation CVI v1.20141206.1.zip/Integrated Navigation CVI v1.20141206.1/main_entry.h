/**************************************************************************/
/* LabWindows/CVI User Interface Resource (UIR) Include File              */
/* Copyright (c) National Instruments 2014. All Rights Reserved.          */
/*                                                                        */
/* WARNING: Do not add to, delete from, or otherwise modify the contents  */
/*          of this include file.                                         */
/**************************************************************************/

#include <userint.h>

#ifdef __cplusplus
    extern "C" {
#endif

     /* Panels and Controls: */

#define  PANEL                            1
#define  PANEL_BUTTON_INIT                2       /* callback function: buttonInit */
#define  PANEL_BUTTON_SELECT_DATA         3       /* callback function: buttonSelectData */
#define  PANEL_BUTTON_SELECT_INIT         4       /* callback function: buttonSelectInit */
#define  PANEL_BUTTON_FILT                5       /* callback function: buttonFiltering */
#define  PANEL_BUTTON_EXIT                6       /* callback function: buttonExit */
#define  PANEL_BUTTON_CLOSE_PLOT          7       /* callback function: buttonClosePlot */
#define  PANEL_BUTTON_SAVE                8       /* callback function: buttonSaveResult */
#define  PANEL_BUTTON_DISPLAY             9       /* callback function: buttonDisplay */
#define  PANEL_TEXTBOX                    10
#define  PANEL_TOGGLEBUTTON_MAT           11      /* callback function: buttonMATLAB */
#define  PANEL_STRING_PATH_DATA           12
#define  PANEL_STRING_PATH_INIT           13
#define  PANEL_CHECKBOX_NORM_RESULT       14
#define  PANEL_CHECKBOX_GNSS_RESULT       15
#define  PANEL_CHECKBOX_PMSE              16
#define  PANEL_CHECKBOX_IMU               17
#define  PANEL_CHECKBOX_ERROR             18
#define  PANEL_CHECKBOX_RESULT            19
#define  PANEL_RADIOBUTTON_KF             20      /* callback function: buttonNavMode */
#define  PANEL_RADIOBUTTON_SINS           21      /* callback function: buttonNavMode */


     /* Menu Bars, Menus, and Menu Items: */

          /* (no menu bars in the resource file) */


     /* Callback Prototypes: */

int  CVICALLBACK buttonClosePlot(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK buttonDisplay(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK buttonExit(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK buttonFiltering(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK buttonInit(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK buttonMATLAB(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK buttonNavMode(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK buttonSaveResult(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK buttonSelectData(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK buttonSelectInit(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);


#ifdef __cplusplus
    }
#endif
