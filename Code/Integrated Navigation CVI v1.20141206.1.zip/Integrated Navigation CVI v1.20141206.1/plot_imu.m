

% Global definition
wie = 7.292115147e-5; % rad/s
Re = 6378245; % Earth radius, m
e = 1 / 298.3; % Earth eccentrity
g0 = 9.7803267714; % m/s^2
gk1 = 0.00193185138639;
gk2 = 0.00669437999013;

% Unit conversion
unit_degree2rad = (pi / 180); % degrees to rad
unit_w = (pi / 3600 / 180); % degrees/h to rad/s
unit_ug = (g0 * 10 ^ (-6)); % ug to m/s^2



%% Unit refresh
Wibbx = Wibbx / unit_degree2rad;    % rad/s to degrees/s
Wibby = Wibby / unit_degree2rad;
Wibbz = Wibbz / unit_degree2rad;



len = length(TimeImu);
time = TimeImu * 0.001;
for i = len : (-1) : 1
    time(1, i) = time(1, i) - time(1, 1);
end


%% Drawing results
disp('Drawing IMU begin.');
tic;


figure('name', 'Gyroscope');
subplot(3, 1, 1), 
plot(time(1, 1 : len), Wibbx(1, 1 : len), 'Color', 'k'), hold on;
xlabel('Time/s'), ylabel('X/degree/h'); grid on;
subplot(3, 1, 2), 
plot(time(1, 1 : len), Wibby(1, 1 : len), 'Color', 'k'), hold on;
xlabel('Time/s'), ylabel('Y/degree/h'); grid on;
subplot(3, 1, 3), 
plot(time(1, 1 : len), Wibbz(1, 1 : len), 'Color', 'k'), hold on;
xlabel('Time/s'), ylabel('Z/degree/h'); grid on;

figure('name', 'Accelerometer');
subplot(3, 1, 1), 
plot(time(1, 1 : len), Fbx(1, 1 : len), 'Color', 'k'), hold on;
xlabel('Time/s'), ylabel('X/ug'); grid on;
subplot(3, 1, 2), 
plot(time(1, 1 : len), Fby(1, 1 : len), 'Color', 'k'), hold on;
xlabel('Time/s'), ylabel('Y/ug'); grid on;
subplot(3, 1, 3), 
plot(time(1, 1 : len), Fbz(1, 1 : len), 'Color', 'k'), hold on;
xlabel('Time/s'), ylabel('Z/ug'); grid on;




RuntimeDraw = toc;
disp(['Drawing results running time = ', num2str(RuntimeDraw), 's']);





