//==============================================================================
//
// Title:       sins_gnss.h
// Purpose:     A short description of the interface.
//
// Created on:  2014/9/28 at 13:59:16 by ZhaoHengyang.
// Copyright:   Beihang University. All Rights Reserved.
//
//==============================================================================

#ifndef __sins_gnss_H__
#define __sins_gnss_H__

#ifdef __cplusplus
    extern "C" {
#endif

//==============================================================================
// Include files


//==============================================================================
// Constants
#define	pi		3.14159265358979323846

// INS algorithm constant
#define	wie		7.292115147e-5	// rad/s
#define	Re		6378137e0		// m
#define	e		(1 / 298.257223563)
#define	g0		9.7803267714	// m/s^2
#define	gk1		0.00193185138639
#define	gk2		0.00669437999013

// Unit transfer constant
#define	unit_rad2degree			(180 / pi)
#define	unit_w					(pi / 3600 / 180)	//degrees/h to rad/s
#define	unit_ug					(g0 * 0.000001)	// ug to m/s^2

// Height channel control
#define	HEIGHT_USED				1
#define	HEIGHT_UNUSED			0
		
// GNSS receiver parameters		
#define	SATELLITE_NUMBER		32
#define	RECEIVER_CHANNEL		10

// Kalman Filter parameters
#define	MAX_TEMP				50
#define	MAX_X					50
#define	MAX_Z					50
#define	MAX_W					50
#define	MAX_V					50
#define	MAX_SIGMA_NUM			50
#define	MAX_SIGMA_NUM2			100
		
		
//==============================================================================
// Types
// Initial value struct
typedef struct
{
	// Hz, s
	double sampling_rate;
	double time_interval;

	// Attitude (rad)
	double pitch0;
	double roll0;
	double yaw0;

	// Velocity (m/s)
	double ve0;
	double vn0;
	double vu0;

	// Geographical location, altitude (rad, m)
	double la0;
	double lon0;
	double h0;
	
} INS_INIT_PARAM;

// INS measurements struct
typedef struct
{
	// Data received time
	double time;
	
	double w[3]; // Rotation rate (rad/s)
	
	double f[3]; // Acceleration (m/s^2)
	
} IMU_MEASUREMENT;

// Navigation parameter struct
typedef struct
{
	// Time interval (s)
	double T;

	// INS time
	double time;

	// Attitude (rad)
	double pitch;
	double roll;
	double yaw;

	// Velocity (m/s)
	double v[3];

	// Location, altitude (rad, m)
	double la;
	double lon;
	double alt;

	// Euler matrix
	double Ctb[3][3];

	// Quaternion
	double Qtb[4];

} INS_NAV_PARAM;


// GNSS navigation parameter struct
typedef struct
{
	// Time interval (s)
	double T;

	// GNSS data receive time
	double time;

	// UTC time
	double utc_time;

	int fixQuality;

	int svNumber;

	// Location, altitude (rad, m)
	double la;
	double lon;
	double alt;

	double PDOP;

	// Position (x-y-z)
	double pxyz[3];

	// Velocity (x-y-z)
	double vxyz[3];

	// Velocity (E-N-U, m/s)
	double vgeo[3];

	// All GNSS receiver channels (32 at most)
	struct
	{
		int svNo;
		int SNR;
		double pseu;
		double pseuRate;
		double vxyz[3];
		double pxyz[3];
	}channel[SATELLITE_NUMBER];

} GNSS_NAV_PARAM;


// Kalman filter initiate parameter struct
typedef struct
{
	// Time interval (s)
	double T;

	// Estimation of system state
	double mx0[MAX_X];

	// Variance matrix of estimation error
	double Cx0[MAX_X][MAX_X];
	
	// matrix Q
	double Q[MAX_W][MAX_W];
	
	// matrix R
	double R[MAX_V][MAX_V];

} KF_INIT_PARAM;



// Kalman filter parameter struct
typedef struct
{
	// Time interval (s)
	double T;

	// Estimation of system state
	double Xes[MAX_X];

	// Variance matrix of estimation error
	double Pes[MAX_X][MAX_X];
	
	// matrix Q
	double Q[MAX_W][MAX_W];
	
	// matrix R
	double R[MAX_V][MAX_V];

} KF_PARAM;




		
//==============================================================================
// External variables

//==============================================================================
// Global functions
// Coarse-alignment
INS_NAV_PARAM sinsCoarseAlignment(IMU_MEASUREMENT measurements, INS_INIT_PARAM init_param);

// Initiate navigation parameter
INS_NAV_PARAM sinsInit(INS_INIT_PARAM initParam);

// 1 step strapdown algorithm
INS_NAV_PARAM sinsStrapdown(IMU_MEASUREMENT measurements, INS_NAV_PARAM navParam, int switchHeight);



// Kalman filter initialization
KF_PARAM kfInit(KF_INIT_PARAM kfInitParam, int sizeX, int sizeW, int sizeV);

// Kalman filtering
KF_PARAM kf(KF_PARAM kfParamOld, INS_NAV_PARAM sinsNavParam, GNSS_NAV_PARAM gnssNavParam, IMU_MEASUREMENT measurements);

#ifdef __cplusplus
    }
#endif

#endif  /* ndef __sins_gnss_H__ */
