//==============================================================================
//
// Title:       sins_gnss.c
// Purpose:     A short description of the implementation.
//
// Created on:  2014/9/28 at 13:59:16 by ZhaoHengyang.
// Copyright:   Beihang University. All Rights Reserved.
//
//==============================================================================

//==============================================================================
// Include files
#include <math.h>

#include "sins_gnss.h"
#include "matrix.h"

//==============================================================================
// Constants

//==============================================================================
// Types

//==============================================================================
// Static global variables

//==============================================================================
// Static functions

//==============================================================================
// Global variables
double fb[3];
double wibb[3];
double la0, lon0, alt0;
double v[3];
double pitch0, roll0, yaw0;
double T;
double la, lon, alt;
double v[3];
double Qtb[4], Ctb[3][3], pitch, roll, yaw;


// Radius of meridian plane and prime plane
double Rm, Rn;

// Angular velocity in navigation coordinate
double wiet[3], wett[3], wtbb[3], wTemp3x1[3];

// Euler matrix from carrier coordinate to navigation coordinate
double Cbt[3][3];
double Ctb[3][3];

// Accelerometer measurements in navigation coordinate
double ft[3];

// Gravity
double g;

double seitaDelta[16];
double seitaDeltaZero;
double eye4[16] = { 1, 0, 0, 0,
					0, 1, 0, 0,
					0, 0, 1, 0,
					0, 0, 0, 1 };
double mat4x4_1[16], mat4x4_2[16];

double quaternionNorm = 0;

double veTemp, vnTemp, vuTemp;
double laTemp, lonTemp, altTemp;

INS_NAV_PARAM		navParamTemp;


// Size of estimators, measurements, process noise and measurement noise
int sizeX;
int sizeZ;
int sizeW;
int sizeV;

// Radius of meridian plane and prime plane
double Rm, Rn;

// Kalman Filter parameters
double Z[MAX_Z] = { 0 };// Measurement matrix
double F[MAX_X][MAX_X] = { 0 };// State transfer matrix (Continus)
double Phi[MAX_X][MAX_X] = { 0 };// State transfer matrix (Descrete)
double G[MAX_X][MAX_W] = { 0 };// Error variance transfer matrix (Continus)
double Ka[MAX_X][MAX_W] = { 0 };// Error variance transfer matrix (Descrete)
double Q[MAX_W][MAX_W] = { 0 };// Process covariance matrix 
double H[MAX_Z][MAX_X] = { 0 };// Measurement matrix
double R[MAX_V][MAX_V] = { 0 };// Measurement error covariance matrix
double XesOneStep[MAX_X] = { 0 };// One step estimation
double PesOneStep[MAX_X][MAX_X] = { 0 };// One step estimation variance
double K[MAX_X][MAX_Z] = { 0 };// Kalman gain


// UKF parameters
int svNumber;
double alpha;
double beta;
double ka;
double lamda;
double weightM[MAX_SIGMA_NUM] = { 0 };
double weightC[MAX_SIGMA_NUM] = { 0 };
double XesSigma[MAX_SIGMA_NUM][MAX_X] = { 0 };
double upperTriMatrix[MAX_X][MAX_X] = { 0 };
double ZesOneStep[MAX_Z] = { 0 };
double XesSigmaOneStep[MAX_SIGMA_NUM][MAX_X] = { 0 };
double XesOneStepSigma[MAX_SIGMA_NUM2][MAX_X] = { 0 };
double ZesSigmaOneStep[MAX_SIGMA_NUM][MAX_Z] = { 0 };
double PzesOneStep[MAX_Z][MAX_Z] = { 0 };
double PxzesOneStep[MAX_X][MAX_Z] = { 0 };


// Pseudorange error and pseudorange rate error calculation parameters
double positionSINS[3] = { 0 };// SINS position in earth x-y-z coordinate
double Cte[3][3] = { 0 };// Transfer matrix from e-n-u to x-y-z
double vxyzSINS[3] = { 0 };// SINS velocity in earth x-y-z coordinate
double venuSINS[3] = { 0 };// SINS velocity in E-N-U coordinate
double pseudorangeSINS = 0;
double pseudorangeRateSINS = 0;
double ex2, N;


// H-infinity parameters
double alphaHinf = 0;
double gamma = 0;
double PesOneStepInv[MAX_X][MAX_X] = { 0 };
double Pxzxx[MAX_X][MAX_X + MAX_Z] = { 0 };
double Rek[MAX_X + MAX_Z][MAX_X + MAX_Z] = { 0 };

// Angular rate
double wiet[3] = { 0 };
double wett[3] = { 0 };
double witt[3] = { 0 };
double wiet_witt[3] = { 0 };
double delta_wiet[3] = { 0 };
double delta_wett[3] = { 0 };
double delta_wiet_witt[3] = { 0 };

// Eular matrix
double Ctp[3][3] = { 0 };
double Cpt[3][3] = { 0 };
double Cpb[3][3] = { 0 };
double Cbp[3][3] = { 0 };

// Quaternion related variables
double QuaNorm = 0;
double B[4][3] = { 0 };

// Runge-Kutta variables
double k_Qua[4][4] = { 0 };
double k_deltaV[4][3] = { 0 };
double k_deltaLa[4] = { 0 };
double k_deltaLon[4] = { 0 };
double k_deltaH[4] = { 0 };
double k_gnssErrorP[4] = { 0 };
double k_gnssErrorV[4] = { 0 };

// Temperary variables for RK4
double deltaV[3] = { 0 };
double deltaLa = 0;
double deltaLon = 0;
double deltaH = 0;
double Qtp[4] = { 0 };
double gnssErrorP = 0;
double gnssErrorV = 0;

// Temporary matrix
double eye3[3][3] = { { 1, 0, 0 }, { 0, 1, 0 }, { 0, 0, 1 } };
double eye[MAX_TEMP][MAX_TEMP] = { 0 };
double matTemp1[MAX_TEMP][MAX_TEMP] = { 0 };
double matTemp2[MAX_TEMP][MAX_TEMP] = { 0 };
double matTemp3[MAX_TEMP][MAX_TEMP] = { 0 };
double matTemp4[MAX_TEMP][MAX_TEMP] = { 0 };
double matTemp5[MAX_TEMP][MAX_TEMP] = { 0 };

// Temporary vectors
double vecTemp1[MAX_TEMP] = { 0 };



//==============================================================================
// Global functions

/*
	Set navigation parameters
*/
int sinsSetNavParam(INS_NAV_PARAM navParam)
{
	int i, j;

	// Return value
	T = navParam.T;
	la = navParam.la;
	lon = navParam.lon;
	alt = navParam.alt;
	pitch = navParam.pitch;
	roll = navParam.roll;
	yaw = navParam.yaw;
	for (i = 0; i < 3; i++)
	{
		v[i] = navParam.v[i];
	}
	for (i = 0; i < 4; i++)
	{
		Qtb[i] = navParam.Qtb[i];
	}
	for (i = 0; i < 3; i++)
	{
		for (j = 0; j < 3; j++)
		{
			Ctb[i][j] = navParam.Ctb[i][j];
		}
	}

	return 0;
}

/*
	Get navigation parameters
 */
INS_NAV_PARAM sinsGetNavParam()
{

	int i, j;

	// Return value
	navParamTemp.T = T;
	navParamTemp.la = la;
	navParamTemp.lon = lon;
	navParamTemp.alt = alt;
	navParamTemp.pitch = pitch;
	navParamTemp.roll = roll;
	navParamTemp.yaw = yaw;
	for (i = 0; i < 3; i++)
	{
		navParamTemp.v[i] = v[i];
	}
	for (i = 0; i < 4; i++)
	{
		navParamTemp.Qtb[i] = Qtb[i];
	}
	for (i = 0; i < 3; i++)
	{
		for (j = 0; j < 3; j++)
		{
			navParamTemp.Ctb[i][j] = Ctb[i][j];
		}
	}

	return navParamTemp;
}


/*
	Initialize matrix of KF
 */
int kfInitMatrix()
{
	int i, j;

	for (i = 0; i < sizeX; i++)
	{
		for (j = 0; j < sizeX; j++)
		{
			*(*F + i * sizeX + j) = 0;
		}
	}
	for (i = 0; i < sizeW; i++)
	{
		for (j = 0; j < sizeW; j++)
		{
			*(*Q + i * sizeW + j) = 0;
		}
	}
	for (i = 0; i < sizeV; i++)
	{
		for (j = 0; j < sizeV; j++)
		{
			*(*R + i * sizeV + j) = 0;
		}
	}
	for (i = 0; i < sizeX; i++)
	{
		for (j = 0; j < sizeW; j++)
		{
			*(*G + i * sizeW + j) = 0;
		}
	}
	for (i = 0; i < sizeZ; i++)
	{
		for (j = 0; j < sizeX; j++)
		{
			*(*H + i * sizeX + j) = 0;
		}
	}
	for (i = 0; i < sizeX; i++)
	{
		for (j = 0; j < sizeX; j++)
		{
			*(*eye + i * sizeX + j) = (i == j) ? 1 : 0;
		}
	}

	return 0;
}






// ************************************ SINS ************************************* //

/**
  *	Strapdown navigation coarse-alignment
  */
INS_NAV_PARAM sinsCoarseAlignment(IMU_MEASUREMENT measurements, INS_INIT_PARAM initParam) 
{

	T = initParam.time_interval;

	wibb[0] = measurements.w[0];
	wibb[1] = measurements.w[1];
	wibb[2] = measurements.w[2];

	fb[0] = measurements.f[0];
	fb[1] = measurements.f[1];
	fb[2] = measurements.f[2];

	v[0] = initParam.ve0;
	v[1] = initParam.vn0;
	v[2] = initParam.vu0;

	la = initParam.la0;
	lon = initParam.lon0;
	alt = initParam.h0;

	Ctb[0][2] = fb[0] / g0;
	Ctb[1][2] = fb[1] / g0;
	Ctb[2][2] = fb[2] / g0;

	Ctb[0][1] = (wibb[0] - wie * sin(la0) * Ctb[0][2]) / (wie * cos(la0));
	Ctb[1][1] = (wibb[1] - wie * sin(la0) * Ctb[1][2]) / (wie * cos(la0));
	Ctb[2][1] = (wibb[2] - wie * sin(la0) * Ctb[2][2]) / (wie * cos(la0));

	Ctb[0][0] = -Ctb[2][1] * Ctb[1][2] + Ctb[1][1] * Ctb[2][2];
	Ctb[1][0] = Ctb[2][1] * Ctb[0][2] - Ctb[0][1] * Ctb[2][2];
	Ctb[2][0] = -Ctb[1][1] * Ctb[0][2] + Ctb[0][1] * Ctb[1][2];

	pitch = asin(Ctb[1][2]); // -pi/2 to pi/2
    
    roll = atan2(-Ctb[0][2], Ctb[2][2]); // -pi to pi
    
    yaw = atan2(Ctb[1][0], Ctb[1][1]); // 0 to 2*pi
    if(yaw < 0)
        yaw += 2 * pi;


	Qtb[0] = sqrt(1 + Ctb[0][0] + Ctb[1][1] + Ctb[2][2]) / 2;
	Qtb[1] = sqrt(1 + Ctb[0][0] - Ctb[1][1] - Ctb[2][2]) / 2;
	Qtb[2] = sqrt(1 - Ctb[0][0] + Ctb[1][1] - Ctb[2][2]) / 2;
	Qtb[3] = sqrt(1 - Ctb[0][0] - Ctb[1][1] + Ctb[2][2]) / 2;
	
	if ((Ctb[1][2] - Ctb[2][1]) / (4 * Qtb[0]) < 0)
		Qtb[1] = -Qtb[1];
	if ((Ctb[2][0] - Ctb[0][2]) / (4 * Qtb[0]) < 0)
		Qtb[2] = -Qtb[2];
	if ((Ctb[0][1] - Ctb[1][0]) / (4 * Qtb[0]) < 0)
		Qtb[3] = -Qtb[3];
	
	return sinsGetNavParam();
}



/**
  *	Initiate navigation parameter (x: pitch; y: roll; z: yaw)
  */
INS_NAV_PARAM sinsInit(INS_INIT_PARAM initParam) {

	T = initParam.time_interval;

	pitch = initParam.pitch0;
	roll = initParam.roll0;
	yaw = initParam.yaw0;

	v[0] = initParam.ve0;
	v[1] = initParam.vn0;
	v[2] = initParam.vu0;

	la = initParam.la0;
	lon = initParam.lon0;
	alt = initParam.h0;

	// Method 1: Euler matrix to quaternion
	/*Ctb[0][0] = cos(roll) * cos(yaw) + sin(roll) * sin(yaw) * sin(pitch);
	Ctb[0][1] = -cos(roll) * sin(yaw) + sin(roll) * cos(yaw) * sin(pitch);
	Ctb[0][2] = -sin(roll) * cos(pitch);

	Ctb[1][0] = sin(yaw) * cos(pitch);
	Ctb[1][1] = cos(yaw) * cos(pitch);
	Ctb[1][2] = sin(pitch);

	Ctb[2][0] = sin(roll) * cos(yaw) - cos(roll) * sin(yaw) * sin(pitch);
	Ctb[2][1] = -sin(roll) * sin(yaw) - cos(roll) * cos(yaw) * sin(pitch);
	Ctb[2][2] = cos(roll) * cos(pitch);

	Qtb[0] = sqrt(1 + Ctb[0][0] + Ctb[1][1] + Ctb[2][2]) / 2;
	Qtb[1] = sqrt(1 + Ctb[0][0] - Ctb[1][1] - Ctb[2][2]) / 2;
	Qtb[2] = sqrt(1 - Ctb[0][0] + Ctb[1][1] - Ctb[2][2]) / 2;
	Qtb[3] = sqrt(1 - Ctb[0][0] - Ctb[1][1] + Ctb[2][2]) / 2;
	
	if ((Ctb[1][2] - Ctb[2][1]) / (4 * Qtb[0]) < 0)
		Qtb[1] = -Qtb[1];
	if ((Ctb[2][0] - Ctb[0][2]) / (4 * Qtb[0]) < 0)
		Qtb[2] = -Qtb[2];
	if ((Ctb[0][1] - Ctb[1][0]) / (4 * Qtb[0]) < 0)
		Qtb[3] = -Qtb[3];*/


	// Method 2: Quaternion to Euler matrix
	Qtb[0] = cos(yaw / 2) * cos(pitch / 2) * cos(roll / 2) + sin(yaw / 2) * sin(pitch / 2) * sin(roll / 2);
	Qtb[1] = cos(yaw / 2) * sin(pitch / 2) * cos(roll / 2) + sin(yaw / 2) * cos(pitch / 2) * sin(roll / 2);
	Qtb[2] = cos(yaw / 2) * cos(pitch / 2) * sin(roll / 2) - sin(yaw / 2) * sin(pitch / 2) * cos(roll / 2);
	Qtb[3] = cos(yaw / 2) * sin(pitch / 2) * sin(roll / 2) - sin(yaw / 2) * cos(pitch / 2) * cos(roll / 2);

	Ctb[0][0] = Qtb[0] * Qtb[0] + Qtb[1] * Qtb[1] - Qtb[2] * Qtb[2] - Qtb[3] * Qtb[3];
	Ctb[0][1] = 2 * (Qtb[1] * Qtb[2] + Qtb[0] * Qtb[3]);
	Ctb[0][2] = 2 * (Qtb[1] * Qtb[3] - Qtb[0] * Qtb[2]);

	Ctb[1][0] = 2 * (Qtb[1] * Qtb[2] - Qtb[0] * Qtb[3]);
	Ctb[1][1] = Qtb[0] * Qtb[0] - Qtb[1] * Qtb[1] + Qtb[2] * Qtb[2] - Qtb[3] * Qtb[3];
	Ctb[1][2] = 2 * (Qtb[2] * Qtb[3] + Qtb[0] * Qtb[1]);

	Ctb[2][0] = 2 * (Qtb[1] * Qtb[3] + Qtb[0] * Qtb[2]);
	Ctb[2][1] = 2 * (Qtb[2] * Qtb[3] - Qtb[0] * Qtb[1]);
	Ctb[2][2] = Qtb[0] * Qtb[0] - Qtb[1] * Qtb[1] - Qtb[2] * Qtb[2] + Qtb[3] * Qtb[3];

	return sinsGetNavParam();
}


/**
  *	1 step strapdown algorithm (Quaternion refresh, E-N-U coordinate)
  */
INS_NAV_PARAM sinsStrapdown(IMU_MEASUREMENT measurements, INS_NAV_PARAM nav_param_before, int height_switch) {

	int i;

	wibb[0] = measurements.w[0];
	wibb[1] = measurements.w[1];
	wibb[2] = measurements.w[2];

	fb[0] = measurements.f[0];
	fb[1] = measurements.f[1];
	fb[2] = measurements.f[2];

	// Set navigation paremeters
	sinsSetNavParam(nav_param_before);


	Rm = Re / (1 + 2 * e - 3 * e * sin(la * la));
	Rn = Re / (1 - e * sin(la * la));

	wiet[0] = 0;
	wiet[1] = wie * cos(la);
	wiet[2] = wie * sin(la);


	wett[0] = -v[1] / (Rm + alt);
	wett[1] = v[0] / (Rn + alt);
	wett[2] = v[0] / (Rn + alt) * tan(la);

	// Qtb
	Qtb[0] = cos(yaw / 2) * cos(pitch / 2) * cos(roll / 2) + sin(yaw / 2) * sin(pitch / 2) * sin(roll / 2);
	Qtb[1] = cos(yaw / 2) * sin(pitch / 2) * cos(roll / 2) + sin(yaw / 2) * cos(pitch / 2) * sin(roll / 2);
	Qtb[2] = cos(yaw / 2) * cos(pitch / 2) * sin(roll / 2) - sin(yaw / 2) * sin(pitch / 2) * cos(roll / 2);
	Qtb[3] = cos(yaw / 2) * sin(pitch / 2) * sin(roll / 2) - sin(yaw / 2) * cos(pitch / 2) * cos(roll / 2);

	// Ctb
	Ctb[0][0] = Qtb[0] * Qtb[0] + Qtb[1] * Qtb[1] - Qtb[2] * Qtb[2] - Qtb[3] * Qtb[3];
	Ctb[0][1] = 2 * (Qtb[1] * Qtb[2] + Qtb[0] * Qtb[3]);
	Ctb[0][2] = 2 * (Qtb[1] * Qtb[3] - Qtb[0] * Qtb[2]);

	Ctb[1][0] = 2 * (Qtb[1] * Qtb[2] - Qtb[0] * Qtb[3]);
	Ctb[1][1] = Qtb[0] * Qtb[0] - Qtb[1] * Qtb[1] + Qtb[2] * Qtb[2] - Qtb[3] * Qtb[3];
	Ctb[1][2] = 2 * (Qtb[2] * Qtb[3] + Qtb[0] * Qtb[1]);

	Ctb[2][0] = 2 * (Qtb[1] * Qtb[3] + Qtb[0] * Qtb[2]);
	Ctb[2][1] = 2 * (Qtb[2] * Qtb[3] - Qtb[0] * Qtb[1]);
	Ctb[2][2] = Qtb[0] * Qtb[0] - Qtb[1] * Qtb[1] - Qtb[2] * Qtb[2] + Qtb[3] * Qtb[3];
	
	
	// Cbt = Ctb'
	matTranspose((double *) Cbt, (double *) Ctb, 3, 3);

	// ft = Cbt * fb
	matMul(ft, 3, 1, (double *) Cbt, 3, 3, fb, 3, 1);

	// Speed reckon: v_t(k + 1) = v_t(k) + a_t(k) * T
	veTemp = (ft[0] + (2 * wiet[2] + wett[2]) * v[1] - (2 * wiet[1] + wett[1]) * v[2]) * T + v[0];
    vnTemp = (ft[1] - (2 * wiet[2] + wett[2]) * v[0] + (2 * wiet[0] + wett[0]) * v[2]) * T + v[1];
	if(height_switch == HEIGHT_USED) {
		g = g0 * (1 + gk1 * sin(la) * sin(la)) * (1 - 2 * alt / Re) / sqrt(1 - gk2 * sin(la) * sin(la));
        
		vuTemp = (ft[2] + (2 * wiet[1] + wett[1]) * v[0] - (2 * wiet[0] + wett[0]) * v[1] - g) * T + v[2];
	}
	else
	{
		vuTemp = v[2];
	}

	// Location reckon
	laTemp = v[1] / (Rm + alt) * T + la;
	lonTemp = v[0] / ((Rn + alt) * cos(la)) * T + lon;
    altTemp = v[2] * T + alt;

	// Refresh velocity and location
	v[0] = veTemp;
	v[1] = vnTemp;
	v[2] = vuTemp;
	la = laTemp;
	lon = lonTemp;
	alt = altTemp;

	// Angular velocity from navigation coordinate to carrier coordinate
	// wtbb = wibb(:, count) - Ctb * (wiet + wett);
	matPlus(wTemp3x1, wiet, wett, 3, 1);
	matMul(wTemp3x1, 3, 1, (double *) Ctb, 3, 3, wTemp3x1, 3, 1);
	matMinus(wtbb, wibb, wTemp3x1, 3, 1);


	// Quaternion refresh
	seitaDelta[0] = 0;
	seitaDelta[1] = -wtbb[0] * T;
	seitaDelta[2] = -wtbb[1] * T;
	seitaDelta[3] = -wtbb[2] * T;

	seitaDelta[4] = wtbb[0] * T;
	seitaDelta[5] = 0;
	seitaDelta[6] = wtbb[2] * T;
	seitaDelta[7] = -wtbb[1] * T;

	seitaDelta[8] = wtbb[1] * T;
	seitaDelta[9] = -wtbb[2] * T;
	seitaDelta[10] = 0;
	seitaDelta[11] = wtbb[0] * T;

	seitaDelta[12] = wtbb[2] * T;
	seitaDelta[13] = wtbb[1] * T;
	seitaDelta[14] = -wtbb[0] * T;
	seitaDelta[15] = 0;

	seitaDeltaZero = sqrt(seitaDelta[1] * seitaDelta[1] + seitaDelta[2] * seitaDelta[2] + seitaDelta[3] * seitaDelta[3]);

	//Qtb = (cos(seitaDeltaZero / 2) * eye(4) + sin(seitaDeltaZero / 2) / seitaDeltaZero * seitaDelta) * Qtb;
	matConstantMul(mat4x4_1, cos(seitaDeltaZero / 2), eye4, 4, 4);
	matConstantMul(mat4x4_2, sin(seitaDeltaZero / 2) / seitaDeltaZero, seitaDelta, 4, 4);
	matPlus(mat4x4_1, mat4x4_1, mat4x4_2, 4, 4);
	matMul(Qtb, 4, 1, mat4x4_1, 4, 4, Qtb, 4, 1);
	
	// Normalization of quaternion
	quaternionNorm = 0;
	for (i = 0; i < 4; i++)
	{
		quaternionNorm += Qtb[i] * Qtb[i];
	}
	quaternionNorm = sqrt(quaternionNorm);
	for (i = 0; i < 4; i++)
	{
		Qtb[i] /= quaternionNorm;
	}
	
	
	// Quaternion to Euler matrix
	Ctb[0][0] = Qtb[0] * Qtb[0] + Qtb[1] * Qtb[1] - Qtb[2] * Qtb[2] - Qtb[3] * Qtb[3];
	Ctb[0][1] = 2 * (Qtb[1] * Qtb[2] + Qtb[0] * Qtb[3]);
	Ctb[0][2] = 2 * (Qtb[1] * Qtb[3] - Qtb[0] * Qtb[2]);

	Ctb[1][0] = 2 * (Qtb[1] * Qtb[2] - Qtb[0] * Qtb[3]);
	Ctb[1][1] = Qtb[0] * Qtb[0] - Qtb[1] * Qtb[1] + Qtb[2] * Qtb[2] - Qtb[3] * Qtb[3];
	Ctb[1][2] = 2 * (Qtb[2] * Qtb[3] + Qtb[0] * Qtb[1]);

	Ctb[2][0] = 2 * (Qtb[1] * Qtb[3] + Qtb[0] * Qtb[2]);
	Ctb[2][1] = 2 * (Qtb[2] * Qtb[3] - Qtb[0] * Qtb[1]);
	Ctb[2][2] = Qtb[0] * Qtb[0] - Qtb[1] * Qtb[1] - Qtb[2] * Qtb[2] + Qtb[3] * Qtb[3];
	
	// Refresh attitude
	pitch = asin(Ctb[1][2]); // -pi/2 to pi/2
    
    roll = atan2(-Ctb[0][2], Ctb[2][2]); // -pi to pi
    
    yaw = atan2(Ctb[1][0], Ctb[1][1]); // 0 to 2*pi
    if(yaw < 0)
        yaw += 2 * pi;

	return sinsGetNavParam();
}








// ****************************************** KF ************************************ //

/* Kalman Filter parameter
% Xdot = F * X + G * W-->     X(k + 1) = Phi * X(k) + Ka * W
% Z = H * X + V-->     Z = H * X + V


% Xes: Estimation of system state
% Element : Tilt at east axis (Ctp, rad, from ideal navigation coordinate to platform coordinate / actual navigation coordinate)
%			Tilt at north axis
%           Tilt at up axis
%           Velocity error at east axis(m / s)
%			Velocity error at north axis
%           Velocity error at up axis
%           Latitude error(rad)
%			Longitude error
%           height error(m)
%			Gyroscope accNoise at east axis(rad / s)
%			Gyroscope accNoise at north axis
%           Gyroscope accNoise at up axis
%           Accelerometer accNoise at east axis(m ^ 2 / s)
%			Accelerometer accNoise at north axis
%           Accelerometer accNoise at up axis


% Q: Variance of System noise W
% Element : Gyroscope random error at east axis(rad / s)
%			Gyroscope random error at north axis
%        	Gyroscope random error at up axis
%       	Acceleration random error at east axis(m / s ^ 2)
%			Acceleration random error at north axis
%        	Acceleration random error at up axis



% Z: Observation
% Element : Velocity error at east axis(m / s)
%			Velocity error at north axis
%           Velocity error at up axis
%           Latitude error(rad)
%			Longitude error
%           Height error(m)


% R: Observation noise variance
% Element : Velocity observation noise at east axis(m / s)
%			Velocity observation noise at north axis
%           Velocity observation noise at up axis
%           Latitude observation noise(rad)
%			Longitude observation noise
%           Height observation noise(m)
*/

/*
	Kalman filter initialization
*/
KF_PARAM kfInit(KF_INIT_PARAM kfInitParam, int sizeX, int sizeW, int sizeV)
{
	int i, j;

	KF_PARAM kfParam = 
	{
		0,
		{0},
		{0}
	};

	for (i = 0; i < sizeX; i++)
	{
		kfParam.Xes[i] = kfInitParam.mx0[i];
		for (j = 0; j < sizeX; j++)
		{
			*(*(kfParam.Pes) + i * sizeX + j) = *(*(kfInitParam.Cx0) + i * sizeX + j);
		}
	}
	
	for (i = 0; i < sizeW; i ++)
		for (j = 0; j < sizeW; j ++)
			*(*(kfParam.Q) + i * sizeW + j) = *(*(kfInitParam.Q) + i * sizeW + j);
	
	for (i = 0; i < sizeV; i ++)
		for (j = 0; j < sizeV; j ++)
			*(*(kfParam.R) + i * sizeV + j) = *(*(kfInitParam.R) + i * sizeV + j);

	kfParam.T = kfInitParam.T;

	return kfParam;
}





/*
	SINS GNSS loosely coupled Kalman filtering
 */
KF_PARAM kf(KF_PARAM kfParamOld,
			INS_NAV_PARAM sinsNavParam, 
			GNSS_NAV_PARAM gnssNavParam, 
			IMU_MEASUREMENT measurements)
{
	int i;
	
	KF_PARAM kfParamNew = kfParamOld;


	// Get navigation parameters
	sinsSetNavParam(sinsNavParam);
	
	// Cbt = Ctb'
	matTranspose((double *) Cbt, (double *) Ctb, 3, 3);

	// ft = Cbt * fb
	matMul(ft, 3, 1, (double *) Cbt, 3, 3, measurements.f, 3, 1);

	// Initialize some matrixs
	sizeX = 15;
	sizeW = 6;
	sizeZ = 6;
	sizeV = 6;

	// initialize matrix
	kfInitMatrix();

	Rm = Re / (1 + 2 * e - 3 * e * sin(la * la));
	Rn = Re / (1 - e * sin(la * la));

	Z[0] = v[0] - gnssNavParam.vgeo[0];
	Z[1] = v[1] - gnssNavParam.vgeo[1];
	Z[2] = v[2] - gnssNavParam.vgeo[2];
	Z[3] = la - gnssNavParam.la;
	Z[4] = lon - gnssNavParam.lon;
	Z[5] = alt - gnssNavParam.alt;

	// Error transfer: From nav error to nav error
	*(*F + 0 * sizeX + 1) = (wie * sin(la) + v[0] / (Rn + alt) * tan(la));
	*(*F + 0 * sizeX + 2) = -(wie * cos(la) + v[0] / (Rn + alt));
	*(*F + 0 * sizeX + 4) = -(1 / (Rm + alt));
	
	*(*F + 1 * sizeX + 0) = -(wie * sin(la) + v[0] / (Rn + alt) * tan(la));
	*(*F + 1 * sizeX + 2) = -v[1] / (Rm + alt);
	*(*F + 1 * sizeX + 3) = 1 / (Rn + alt);
	*(*F + 1 * sizeX + 6) = -wie * sin(la);

	*(*F + 2 * sizeX + 0) = (wie * cos(la) + v[0] / (Rn + alt));
	*(*F + 2 * sizeX + 1) = v[1] / (Rm + alt);
	*(*F + 2 * sizeX + 3) = 1 / (Rn + alt) * tan(la);
	*(*F + 2 * sizeX + 6) = (wie * cos(la) + v[0] / ((Rn + alt) * cos(la) * cos(la)));

	*(*F + 3 * sizeX + 1) = -ft[2];
	*(*F + 3 * sizeX + 2) = ft[1];
	*(*F + 3 * sizeX + 3) = (v[1] / (Rm + alt) * tan(la) - v[2] / (Rm + alt));
	*(*F + 3 * sizeX + 4) = (2 * wie * sin(la) + v[0] / (Rn + alt) * tan(la));
	*(*F + 3 * sizeX + 5) = -(2 * wie * cos(la) + v[0] / (Rn + alt));
	*(*F + 3 * sizeX + 6) = (2 * wie * cos(la) * v[1] + v[0] * v[1] / ((Rn + alt) * cos(la) * cos(la)) + 2 * wie * sin(la) * v[2]);
	*(*F + 3 * sizeX + 8) = (v[0] * v[2] - v[0] * v[1] * tan(la)) / (Rn + alt) / (Rn + alt);
	
	*(*F + 4 * sizeX + 0) = ft[2];
	*(*F + 4 * sizeX + 2) = -ft[0];
	*(*F + 4 * sizeX + 3) = -2 * (wie * sin(la) + v[0] / (Rn + alt) * tan(la));
	*(*F + 4 * sizeX + 4) = -v[2] / (Rm + alt);
	*(*F + 4 * sizeX + 5) = -v[1] / (Rm + alt);
	*(*F + 4 * sizeX + 6) = -(2 * wie * cos(la) + v[0] / ((Rn + alt) * cos(la) * cos(la))) * v[0];
	*(*F + 4 * sizeX + 8) = (v[0] * v[0] * tan(la) + v[0] * v[2]) / (Rm + alt) / (Rn + alt);	
	
	*(*F + 5 * sizeX + 0) = -ft[1];
	*(*F + 5 * sizeX + 1) = ft[0];
	*(*F + 5 * sizeX + 3) = -2 * (wie * cos(la) + v[0] / (Rn + alt));
	*(*F + 5 * sizeX + 5) = 2 * v[1] / (Rm + alt);
	*(*F + 5 * sizeX + 6) = -2 * wie * sin(la) * v[0];
	*(*F + 5 * sizeX + 8) = -(v[0] * v[0] + v[1] * v[1]) / (Rm + alt) / (Rn + alt);
	
	*(*F + 6 * sizeX + 4) = 1 / (Rm + alt);
	*(*F + 6 * sizeX + 8) = -v[1] / (Rm + alt) / (Rn + alt);
	
	*(*F + 7 * sizeX + 3) = 1 / ((Rn + alt) * cos(la));
	*(*F + 7 * sizeX + 6) = v[0] / ((Rn + alt) * cos(la)) * tan(la);
	*(*F + 7 * sizeX + 8) = -v[0] / cos(la) / (Rm + alt) / (Rn + alt);	
	
	*(*F + 8 * sizeX + 5) = 1;


	// Error transfer: From IMU error to nav error
	*(*F + 0 * sizeX + 9) = Ctb[0][0];
	*(*F + 0 * sizeX + 10) = Ctb[1][0];
	*(*F + 0 * sizeX + 11) = Ctb[2][0];
	*(*F + 1 * sizeX + 9) = Ctb[0][1];
	*(*F + 1 * sizeX + 10) = Ctb[1][1];
	*(*F + 1 * sizeX + 11) = Ctb[2][1];
	*(*F + 2 * sizeX + 9) = Ctb[0][2];
	*(*F + 2 * sizeX + 10) = Ctb[1][2];
	*(*F + 2 * sizeX + 11) = Ctb[2][2];

	*(*F + 3 * sizeX + 12) = Ctb[0][0];
	*(*F + 3 * sizeX + 13) = Ctb[1][0];
	*(*F + 3 * sizeX + 14) = Ctb[2][0];
	*(*F + 4 * sizeX + 12) = Ctb[0][1];
	*(*F + 4 * sizeX + 13) = Ctb[1][1];
	*(*F + 4 * sizeX + 14) = Ctb[2][1];
	*(*F + 5 * sizeX + 12) = Ctb[0][2];
	*(*F + 5 * sizeX + 13) = Ctb[1][2];
	*(*F + 5 * sizeX + 14) = Ctb[2][2];

	
	// Descrete the transfer matrix   Phi = eye(15) + F * T
	matConstantMul((double *) Phi, kfParamOld.T, (double *) F, sizeX, sizeX);
	matPlus((double *) Phi, (double *) eye, (double *) Phi, sizeX, sizeX);
	
	// Error variance transfer 
	*(*G + 9 * sizeW + 0) = 1;
	*(*G + 10 * sizeW + 1) = 1;
	*(*G + 11 * sizeW + 2) = 1;
	*(*G + 12 * sizeW + 3) = 1;
	*(*G + 13 * sizeW + 4) = 1;
	*(*G + 14 * sizeW + 5) = 1;

	
	// Descrete matrix G     Ka = (eye(15) * T + F * T ^ 2 / 2) * G
	matConstantMul((double *) matTemp1, (kfParamOld.T / 2), (double *) F, sizeX, sizeX);
	matPlus((double *) matTemp1, (double *) eye, (double *) matTemp1, sizeX, sizeX);
	matConstantMul((double *) matTemp1, kfParamOld.T, (double *) matTemp1, sizeX, sizeX);
	matMul((double *) Ka, sizeX, 6, (double *) matTemp1, sizeX, sizeX, (double *) G, sizeX, 6);
	
	// System error variance
	*(*Q + 0 * sizeW + 0) = *(*(kfParamOld.Q) + 0 * sizeW + 0);
	*(*Q + 1 * sizeW + 1) = *(*(kfParamOld.Q) + 1 * sizeW + 1);
	*(*Q + 2 * sizeW + 2) = *(*(kfParamOld.Q) + 2 * sizeW + 2);
	*(*Q + 3 * sizeW + 3) = *(*(kfParamOld.Q) + 3 * sizeW + 3);
	*(*Q + 4 * sizeW + 4) = *(*(kfParamOld.Q) + 4 * sizeW + 4);
	*(*Q + 5 * sizeW + 5) = *(*(kfParamOld.Q) + 5 * sizeW + 5);
	
	// Measurement matrix
	*(*H + 0 * sizeX + 3) = 1;
	*(*H + 1 * sizeX + 4) = 1;
	*(*H + 2 * sizeX + 5) = 1;

	*(*H + 3 * sizeX + 6) = 1;
	*(*H + 4 * sizeX + 7) = 1;
	*(*H + 5 * sizeX + 8) = 1;
	
	// Measurement error variance
	*(*R + 0 * sizeV + 0) = *(*(kfParamOld.R) + 0 * sizeV + 0);
	*(*R + 1 * sizeV + 1) = *(*(kfParamOld.R) + 1 * sizeV + 1);
	*(*R + 2 * sizeV + 2) = *(*(kfParamOld.R) + 2 * sizeV + 2);
	*(*R + 3 * sizeV + 3) = *(*(kfParamOld.R) + 3 * sizeV + 3);
	*(*R + 4 * sizeV + 4) = *(*(kfParamOld.R) + 4 * sizeV + 4);
	*(*R + 5 * sizeV + 5) = *(*(kfParamOld.R) + 5 * sizeV + 5);
	
	// One step estimation XesOneStep = Phi * Xes
	matMul(XesOneStep, sizeX, 1, (double *) Phi, sizeX, sizeX, kfParamOld.Xes, sizeX, 1);
	
	// One step estimation variance PesOneStep = Phi * Pes * Phi' + Ka * Q * Ka'
	matTranspose((double *) matTemp1, (double *) Phi, sizeX, sizeX);
	matMul((double *) matTemp2, sizeX, sizeX, (double *) kfParamOld.Pes, sizeX, sizeX, (double *) matTemp1, sizeX, sizeX);
	matMul((double *) matTemp1, sizeX, sizeX, (double *) Phi, sizeX, sizeX, (double *) matTemp2, sizeX, sizeX);

	matTranspose((double *) matTemp2, (double *) Ka, sizeW, sizeX);
	matMul((double *) matTemp3, sizeW, sizeX, (double *) Q, sizeW, sizeW, (double *) matTemp2, sizeW, sizeX);
	matMul((double *) matTemp2, sizeX, sizeX, (double *) Ka, sizeX, sizeW, (double *) matTemp3, sizeW, sizeX);

	matPlus((double *) PesOneStep, (double *) matTemp1, (double *) matTemp2, sizeX, sizeX);
	
	// Kalman gain K = PesOneStep * H' / (H * PesOneStep * H' + R)
	matTranspose((double *) matTemp1, (double *) H, sizeX, sizeZ);

	matMul((double *) matTemp2, sizeX, sizeZ, (double *) PesOneStep, sizeX, sizeX, (double *) matTemp1, sizeX, sizeZ);
	matMul((double *) matTemp3, sizeZ, sizeZ, (double *) H, sizeZ, sizeX, (double *) matTemp2, sizeX, sizeZ);
	matPlus((double *) matTemp3, (double *) R, (double *) matTemp3, sizeV, sizeV);
	matInv((double *) matTemp1, (double *) matTemp3, sizeV);
	matMul((double *) K, sizeX, sizeV, (double *) matTemp2, sizeX, sizeZ, (double *) matTemp1, sizeV, sizeV);
	
	// Estimation Xes = XesOneStep + K * (Z - H * XesOneStep)
	matMul((double *) matTemp1, sizeZ, 1, (double *) H, sizeZ, sizeX, XesOneStep, sizeX, 1);
	matMinus((double *) matTemp1, Z, (double *) matTemp1, sizeZ, 1);
	matMul((double *) matTemp2, sizeX, 1, (double *) K, sizeX, sizeV, (double *) matTemp1, sizeZ, 1);
	matPlus(kfParamNew.Xes, XesOneStep, (double *) matTemp2, sizeX, 1);

	// Estimation variance Pes = (eye(15) - K * H) * PesOneStep * (eye(15) - K * H)' + K * R * K'
	matTranspose((double *) matTemp1, (double *) K, sizeV, sizeX);
	matMul((double *) matTemp2, sizeV, sizeX, (double *) R, sizeV, sizeV, (double *) matTemp1, sizeV, sizeX);
	matMul((double *) matTemp1, sizeX, sizeX, (double *) K, sizeX, sizeV, (double *) matTemp2, sizeV, sizeX);

	matMul((double *) matTemp2, sizeX, sizeX, (double *) K, sizeX, sizeV, (double *) H, sizeZ, sizeX);
	matMinus((double *) matTemp2, (double *) eye, (double *) matTemp2, sizeX, sizeX);
	matTranspose((double *) matTemp3, (double *) matTemp2, sizeX, sizeX);
	matMul((double *) matTemp4, sizeX, sizeX, (double *) PesOneStep, sizeX, sizeX, (double *) matTemp3, sizeX, sizeX);
	matMul((double *) matTemp3, sizeX, sizeX, (double *) matTemp2, sizeX, sizeX, (double *) matTemp4, sizeX, sizeX);

	matPlus((double *) kfParamNew.Pes, (double *) matTemp3, (double *) matTemp1, sizeX, sizeX);

	return kfParamNew;
}


