#ifndef MATRIX_H_
#define MATRIX_H_


int matPlus(double *C, double *A, double *B, int rowC, int columC);

int matMinus(double *C, double *A, double *B, int rowC, int columC);

int matTranspose(double *C, double *A, int rowC, int columC);

int matConstantMul(double *C, double k, double *A, int rowC, int columC);

int matMul(double *C, int rowC, int columC,
			double *A, int rowA, int columA,
			double *B, int rowB, int columB);

int matPower(double *C, double *A, int n, int m);

double matDet(double *A, int n);

int matInv(double *C, double *A, int n);

int matQR(double *Q, double *R, double *A, int m, int n);

int matCholesky(double *U, double *A, int n);

int matCholupdate(double *S, double *U, double *x, int weight, int n, int columX);

double matEigenvalueMaxNorm(double *A, int n);

double matEigenvalueMax(double *A, int n);

int matVecCross(double *vector3, double *vector1, double *vector2);



#endif // !MATRIX_H_
