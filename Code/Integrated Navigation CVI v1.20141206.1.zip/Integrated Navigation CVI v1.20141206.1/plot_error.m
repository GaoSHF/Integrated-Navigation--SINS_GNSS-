

% Global definition
wie = 7.292115147e-5; % rad/s
Re = 6378245; % Earth radius, m
e = 1 / 298.3; % Earth eccentrity
g0 = 9.7803267714; % m/s^2
gk1 = 0.00193185138639;
gk2 = 0.00669437999013;

% Unit conVersion
unit_degree2rad = (pi / 180); % degrees to rad
unit_w = (pi / 3600 / 180); % degrees/h to rad/s
unit_ug = (g0 * 10 ^ (-6)); % ug to m/s^2



%% Unit refresh
PitchNav = PitchNav / unit_degree2rad;
RollNav = RollNav / unit_degree2rad;
YawNav = YawNav / unit_degree2rad;

LaNav = LaNav / unit_degree2rad;
LonNav = LonNav / unit_degree2rad;


%% Error calculation
lenNav = length(TimeNav);
lenNorm = length(TimeNorm);
%lenMin = min(lenNav, lenNorm);
lenMax = max(lenNav, lenNorm);

timeError = zeros(1, lenMax);
pitchError = zeros(1, lenMax);
rollError = zeros(1, lenMax);
yawError = zeros(1, lenMax);
veError = zeros(1, lenMax);
vnError = zeros(1, lenMax);
vuError = zeros(1, lenMax);
laError = zeros(1, lenMax);
lonError = zeros(1, lenMax);
altError = zeros(1, lenMax);

i = 1;
j = 1;
lenError = 0;
while((i <= lenNav) && (j < lenNorm))
    if TimeNav(i) < TimeNorm(j)
        i = i + 1;
    elseif TimeNav(i) > TimeNorm(j + 1)
        j = j + 1;
    else
        pitchSync = (PitchNorm(j + 1) - PitchNorm(j)) / (TimeNorm(j + 1) - TimeNorm(j)) * (TimeNav(i) - TimeNorm(j)) + PitchNorm(j);
        if pitchSync > 90
            pitchSync = pitchSync - 180;
        elseif pitchSync < -90
            pitchSync = pitchSync + 180;
        end
        rollSync = (RollNorm(j + 1) - RollNorm(j)) / (TimeNorm(j + 1) - TimeNorm(j)) * (TimeNav(i) - TimeNorm(j)) + RollNorm(j);
        if rollSync > 180
            rollSync = rollSync - 360;
        elseif rollSync < -180
            rollSync = rollSync + 360;
        end
        yawSync = (YawNorm(j + 1) - YawNorm(j)) / (TimeNorm(j + 1) - TimeNorm(j)) * (TimeNav(i) - TimeNorm(j)) + YawNorm(j);
        if yawSync > 360
            yawSync = yawSync - 360;
        elseif yawSync < 0
            yawSync = yawSync + 360;
        end
        
        veSync = (VeNorm(j + 1) - VeNorm(j)) / (TimeNorm(j + 1) - TimeNorm(j)) * (TimeNav(i) - TimeNorm(j)) + VeNorm(j);
        vnSync = (VnNorm(j + 1) - VnNorm(j)) / (TimeNorm(j + 1) - TimeNorm(j)) * (TimeNav(i) - TimeNorm(j)) + VnNorm(j);
        vuSync = (VuNorm(j + 1) - VuNorm(j)) / (TimeNorm(j + 1) - TimeNorm(j)) * (TimeNav(i) - TimeNorm(j)) + VuNorm(j);
        
        laSync = (LaNorm(j + 1) - LaNorm(j)) / (TimeNorm(j + 1) - TimeNorm(j)) * (TimeNav(i) - TimeNorm(j)) + LaNorm(j);
        lonSync = (LonNorm(j + 1) - LonNorm(j)) / (TimeNorm(j + 1) - TimeNorm(j)) * (TimeNav(i) - TimeNorm(j)) + LonNorm(j);
        altSync = (AltNorm(j + 1) - AltNorm(j)) / (TimeNorm(j + 1) - TimeNorm(j)) * (TimeNav(i) - TimeNorm(j)) + AltNorm(j);
        
        
        lenError = lenError + 1;
        
        timeError(lenError) = TimeNav(i);
        pitchError(lenError) = PitchNav(i) - pitchSync;
        rollError(lenError) = RollNav(i) - rollSync;
        yawError(lenError) = YawNav(i) - yawSync;
        if yawError(lenError) > 180
            yawError(lenError) = yawError(lenError) - 360;
        elseif yawError(lenError) < -180
            yawError(lenError) = yawError(lenError) + 360;
        end
        veError(lenError) = VeNav(i) - veSync;
        vnError(lenError) = VnNav(i) - vnSync;
        vuError(lenError) = VuNav(i) - vuSync;
        laError(lenError) = LaNav(i) - laSync;
        lonError(lenError) = LonNav(i) - lonSync;
        altError(lenError) = AltNav(i) - altSync;
        
        i = i + 1;
        j = j + 1;
    end
end


time = timeError * 0.001;
for i = lenError : (-1) : 1
    time(1, i) = time(1, i) - time(1, 1);
end


%% Drawing results
disp('Drawing error begin.');
tic;


figure('name', 'Attitude Error');
subplot(3, 1, 1), 
plot(time(1, 1 : lenError), pitchError(1, 1 : lenError), 'Color', 'k'), hold on;
xlabel('Time/s'), ylabel('Pitch/degree'); grid on;
subplot(3, 1, 2), 
plot(time(1, 1 : lenError), rollError(1, 1 : lenError), 'Color', 'k'), hold on;
xlabel('Time/s'), ylabel('Roll/degree'); grid on;
subplot(3, 1, 3), 
plot(time(1, 1 : lenError), yawError(1, 1 : lenError), 'Color', 'k'), hold on;
xlabel('Time/s'), ylabel('Yaw/degree'); grid on;

figure('name', 'Velocity Error');
subplot(3, 1, 1), 
plot(time(1, 1 : lenError), veError(1, 1 : lenError), 'Color', 'k'), hold on;
xlabel('Time/s'), ylabel('East/m/s'); grid on;
subplot(3, 1, 2), 
plot(time(1, 1 : lenError), vnError(1, 1 : lenError), 'Color', 'k'), hold on;
xlabel('Time/s'), ylabel('North/m/s'); grid on;
subplot(3, 1, 3), 
plot(time(1, 1 : lenError), vuError(1, 1 : lenError), 'Color', 'k'), hold on;
xlabel('Time/s'), ylabel('Up/m/s'); grid on;

figure('name', 'Position Error');
subplot(3, 1, 1), 
plot(time(1, 1 : lenError), lonError(1, 1 : lenError) * unit_degree2rad * Re, 'Color', 'k'), hold on;
xlabel('Time/s'), ylabel('East/m'); grid on;
subplot(3, 1, 2), 
plot(time(1, 1 : lenError), laError(1, 1 : lenError) * unit_degree2rad * Re, 'Color', 'k'), hold on;
xlabel('Time/s'), ylabel('North/m'); grid on;
subplot(3, 1, 3), 
plot(time(1, 1 : lenError), altError(1, 1 : lenError), 'Color', 'k'), hold on;
xlabel('Time/s'), ylabel('Up/m'); grid on;




RuntimeDraw = toc;
disp(['Drawing results running time = ', num2str(RuntimeDraw), 's']);





