#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>

#include "kf_main.h"
#include "../sins_gnss_kf.h"




#define	SINS_SAMPLING_RATE		100
#define	GNSS_SAMPLING_RATE		10

#define	THRESHOLD_ERROR			5e+32


//#define	FUSION_TYPE				0 // SINS
//#define	FUSION_TYPE				1 // KF
#define	FUSION_TYPE				2 // UKF
//#define	FUSION_TYPE				4 // H-infinity UKF
//#define	FUSION_TYPE				5 // Quaternion based loosely coupled UKF
//#define	FUSION_TYPE				6 // Quaternion based tightly coupled UKF




#define LENGTH_ACCUM_TIME	(0 * 60)
#define	RELAY_BEFORE_FEEDBACK_CORRECTION	(0 * 60)


#define	INTERPOLATION(x0, fx0, x1, fx1, x)		((fx1 - fx0) / (x1 - x0) * (x - x0) + fx0)



// File switch
#define FILE_NAME	 3
#if FILE_NAME == 0
#define FILE_NAME_IMU	"../../Data/201401031452 (GPS L1 Static)/imu.txt"
#define FILE_NAME_GNSS	"../../Data/201401031452 (GPS L1 Static)/gnss.txt"
#define FILE_NAME_PPS	"../../Data/201401031452 (GPS L1 Static)/pps.txt"
#define	FILE_DATA_BOTH	"../../Data/201401031452 (GPS L1 Static)/both.dat"
#endif
#if FILE_NAME == 1
#define FILE_NAME_IMU	"../../Data/201401031508 (GPS L1 Vn 1g 300)/imu.txt"
#define FILE_NAME_GNSS	"../../Data/201401031508 (GPS L1 Vn 1g 300)/gnss.txt"
#define FILE_NAME_PPS	"../../Data/201401031508 (GPS L1 Vn 1g 300)/pps.txt"
#define	FILE_DATA_BOTH	"../../Data/201401031508 (GPS L1 Vn 1g 300)/both.dat"
#endif
#if FILE_NAME == 2
#define FILE_NAME_IMU	"../../Data/201401031519 (GPS L1 Vn 1g 300 6g 900)/imu.txt"
#define FILE_NAME_GNSS	"../../Data/201401031519 (GPS L1 Vn 1g 300 6g 900)/gnss.txt"
#define FILE_NAME_PPS	"../../Data/201401031519 (GPS L1 Vn 1g 300 6g 900)/pps.txt"
#define	FILE_DATA_BOTH	"../../Data/201401031519 (GPS L1 Vn 1g 300 6g 900)/both.dat"
#endif
#if FILE_NAME == 3
#define FILE_NAME_IMU	"../../Data/201401031548 (GPS L1 Vn 1g 300 6g 1200)/imu.txt"
#define FILE_NAME_GNSS	"../../Data/201401031548 (GPS L1 Vn 1g 300 6g 1200)/gnss.txt"
#define FILE_NAME_PPS	"../../Data/201401031548 (GPS L1 Vn 1g 300 6g 1200)/pps.txt"
#define	FILE_DATA_BOTH	"../../Data/201401031548 (GPS L1 Vn 1g 300 6g 1200)/both.dat"
#endif
#if FILE_NAME == 4
#define FILE_NAME_IMU	"../../Data/201401031607 (GPS L1 Vn 1g 300 4g 900)/imu.txt"
#define FILE_NAME_GNSS	"../../Data/201401031607 (GPS L1 Vn 1g 300 4g 900)/gnss.txt"
#define FILE_NAME_PPS	"../../Data/201401031607 (GPS L1 Vn 1g 300 4g 900)/pps.txt"
#define	FILE_DATA_BOTH	"../../Data/201401031607 (GPS L1 Vn 1g 300 4g 900)/both.dat"
#endif
#if FILE_NAME == 5
#define FILE_NAME_IMU	"../../Data/201401031355 (BD B3 Vn 300)/imu.txt"
#define FILE_NAME_GNSS	"../../Data/201401031355 (BD B3 Vn 300)/gnss.txt"
#define FILE_NAME_PPS	"../../Data/201401031355 (BD B3 Vn 300)/pps.txt"
#define	FILE_DATA_BOTH	"../../Data/201401031355 (BD B3 Vn 300)/both.dat"
#endif

// Both IMU and GNSS data record switch
#define	DATA_BOTH_ENABLE	0

// GNSS navigation data record switch
#define	GNSS_RECORD_ENABLE		0









IMU_ERROR_PARAM imuErrorParam =
{
	// Gyroscope drift (rad/s)
	0.08 * unit_w,
	0.08 * unit_w,
	0.08 * unit_w,

	// Gyroscope white Gauss noise MSE (rad/s)
	0.03 * unit_w,
	0.03 * unit_w,
	0.03 * unit_w,

	// Accelerometer bias (m/s^2)
	50 * unit_ug,
	50 * unit_ug,
	50 * unit_ug,

	// Accelerometer white Gauss noise MSE (rad/s)
	10 * unit_ug,
	10 * unit_ug,
	10 * unit_ug
};

GNSS_ERROR_PARAM gnssErrorParam =
{
	// GNSS position noise variance MSE (m)
	0.10,
	0.10,
	0.15,

	// GNSS velocity noise variance MSE (m/s)
	0.01,
	0.01,
	0.05,

	// Pseudorage noise variance MSE (m)
	10,

	// Pseudorage rate noise variance MSE (m/s)
	0.1,

	// Timer drift caused velocity noise variance MSE (m/s)
	0.1,

	// Timer drift caused position error (m)
	1,

	// Timer frequency drift caused velocity error (m/s)
	0.1,

	// Timer drift correlation time
	200
};

INS_INIT_PARAM insInitParam = 
{
	SINS_SAMPLING_RATE,
	1. / SINS_SAMPLING_RATE,

	(0 / unit_rad2degree),
	(0 / unit_rad2degree),
	(0 / unit_rad2degree), 

	0,
	0,
	0,

	(39. / unit_rad2degree),
	(116. / unit_rad2degree),
	100.
};

KF_INIT_PARAM kfInitParam =
{
	1. / GNSS_SAMPLING_RATE,
	{ 0 },
	{ 0 }
};

KF_INIT_PARAM ukfInitParam =
{
	1. / GNSS_SAMPLING_RATE,
	{ 0 },
	{ 0 }
};

KF_INIT_PARAM hinfukfInitParam =
{
	1. / GNSS_SAMPLING_RATE,
	{ 0 },
	{ 0 }
};

KF_INIT_PARAM qlcukfInitParam =
{
	1. / GNSS_SAMPLING_RATE,
	{ 0 },
	{ 0 }
};

KF_INIT_PARAM qtcukfInitParam =
{
	1. / GNSS_SAMPLING_RATE,
	{ 0 },
	{ 0 }
};


// File handle
FILE *FileHandleIMU = NULL;
FILE *FileHandleGNSS = NULL;
FILE *FileHandlePPS = NULL;

FILE *FileHandleResultsSINS = NULL;

FILE *FileHandleBoth = NULL;

FILE *FileHandleResultsGNSS = NULL;

FILE *FileHandleResultsKF = NULL;
FILE *FileHandleErrorKF = NULL;
FILE *FileHandleVarKF = NULL;

FILE *FileHandleResultsUKF = NULL;
FILE *FileHandleErrorUKF = NULL;
FILE *FileHandleVarUKF = NULL;

FILE *FileHandleResultsHinfUKF = NULL;
FILE *FileHandleErrorHinfUKF = NULL;
FILE *FileHandleVarHinfUKF = NULL;

FILE *FileHandleResultsQLCUKF = NULL;
FILE *FileHandleErrorQLCUKF = NULL;
FILE *FileHandleVarQLCUKF = NULL;

FILE *FileHandleResultsQTCUKF = NULL;
FILE *FileHandleErrorQTCUKF = NULL;
FILE *FileHandleVarQTCUKF = NULL;

// PPS, GNSS, IMU time
double TimePPS = 0;
double TimeGNSS = 0;
double TimeIMU[2] = { 0 };
double TimePPSFirst = 0;
double TimeNow = 0;
double TimeNext = 0;


// IMU Measurements
double wibb[3][2] = { 0 };
double fb[3][2] = { 0 };


// Sync flag
int FlagSyncGNSS = 0;
int FlagSyncIMU = 0;

char TempChar[30] = { 0 };

// File over flag
int FlagEndPPS = 0;
int FlagEndGNSS = 0;
int FlagEndIMU = 0;


// 10 IMU data with 1 GNSS data
int CountIMU = 0;

// Start time and stop time
double timeStart = 0;
double timeStop = 0;

// Size of estimator
int sizeX = 0;


// Transfer matrix from real geo-coordination to geo-coordination in computer
double Cct[3][3] = { 0 };

INS_MEASUREMENT Measurements;

INS_NAV_PARAM NavParamOld, NavParamNew;

GNSS_NAV_PARAM GnssNavParam, GnssNavParamNone;

KF_PARAM KfParamTemp;

KF_PARAM UkfParamTemp;

KF_PARAM HinfukfParamTemp;

KF_PARAM QlcukfParamTemp;

KF_PARAM QtcukfParamTemp;


// Correction method
enum{ CORRECTION_FEEDBACK, CORRECTION_OUTPUT, CORRECTION_HYBRID };
int CorrectionMethod = CORRECTION_FEEDBACK;
//int CorrectionMethod = CORRECTION_OUTPUT;








/*
	Get IMU data once
 */
int GetDataIMU()
{
	do
	{
		fscanf(FileHandleIMU, "%s", TempChar);
		TimeIMU[1] = atof(TempChar);

		fscanf(FileHandleIMU, "%s", TempChar);
		wibb[0][1] = atof(TempChar);

		fscanf(FileHandleIMU, "%s", TempChar);
		wibb[1][1] = atof(TempChar);

		fscanf(FileHandleIMU, "%s", TempChar);
		wibb[2][1] = atof(TempChar);

		fscanf(FileHandleIMU, "%s", TempChar);
		fb[0][1] = atof(TempChar);

		fscanf(FileHandleIMU, "%s", TempChar);
		fb[1][1] = atof(TempChar);

		fscanf(FileHandleIMU, "%s", TempChar);
		fb[2][1] = atof(TempChar);

		if (feof(FileHandleIMU))
		{
			FlagEndIMU = 1;
			break;
		}
	} while (TimeIMU[1] <= TimeIMU[0]);

	return 0;
}

/*
	Get GNSS data once
*/
int GetDataGNSS()
{
	int i;

	fscanf(FileHandleGNSS, "%s", TempChar);
	TimeGNSS = atof(TempChar);

	fscanf(FileHandleGNSS, "%s", TempChar);
	GnssNavParam.utc_time = atof(TempChar);

	fscanf(FileHandleGNSS, "%s", TempChar);
	GnssNavParam.fixQuality = atoi(TempChar);

	fscanf(FileHandleGNSS, "%s", TempChar);
	GnssNavParam.svNumber = atoi(TempChar);

	fscanf(FileHandleGNSS, "%s", TempChar);
	GnssNavParam.la = atof(TempChar) / unit_rad2degree;

	fscanf(FileHandleGNSS, "%s", TempChar);
	GnssNavParam.lon = atof(TempChar) / unit_rad2degree;

	fscanf(FileHandleGNSS, "%s", TempChar);
	GnssNavParam.alt = atof(TempChar);

	fscanf(FileHandleGNSS, "%s", TempChar);
	GnssNavParam.PDOP = atof(TempChar);

	fscanf(FileHandleGNSS, "%s", TempChar);
	GnssNavParam.p_xyz[0] = atof(TempChar);

	fscanf(FileHandleGNSS, "%s", TempChar);
	GnssNavParam.p_xyz[1] = atof(TempChar);

	fscanf(FileHandleGNSS, "%s", TempChar);
	GnssNavParam.p_xyz[2] = atof(TempChar);

	fscanf(FileHandleGNSS, "%s", TempChar);
	GnssNavParam.v_xyz[0] = atof(TempChar);

	fscanf(FileHandleGNSS, "%s", TempChar);
	GnssNavParam.v_xyz[1] = atof(TempChar);

	fscanf(FileHandleGNSS, "%s", TempChar);
	GnssNavParam.v_xyz[2] = atof(TempChar);

	for (i = 0; i < RECEIVER_CHANNEL; i++)
	{
		fscanf(FileHandleGNSS, "%s", TempChar);
		GnssNavParam.channel[i].svNo = atoi(TempChar);

		fscanf(FileHandleGNSS, "%s", TempChar);
		GnssNavParam.channel[i].SNR = atoi(TempChar);

		fscanf(FileHandleGNSS, "%s", TempChar);
		GnssNavParam.channel[i].pseu = atof(TempChar);

		fscanf(FileHandleGNSS, "%s", TempChar);
		GnssNavParam.channel[i].pseuRate = atof(TempChar);

		fscanf(FileHandleGNSS, "%s", TempChar);
		GnssNavParam.channel[i].p_xyz[0] = atof(TempChar);

		fscanf(FileHandleGNSS, "%s", TempChar);
		GnssNavParam.channel[i].p_xyz[1] = atof(TempChar);

		fscanf(FileHandleGNSS, "%s", TempChar);
		GnssNavParam.channel[i].p_xyz[2] = atof(TempChar);

		fscanf(FileHandleGNSS, "%s", TempChar);
		GnssNavParam.channel[i].v_xyz[0] = atof(TempChar);

		fscanf(FileHandleGNSS, "%s", TempChar);
		GnssNavParam.channel[i].v_xyz[1] = atof(TempChar);

		fscanf(FileHandleGNSS, "%s", TempChar);
		GnssNavParam.channel[i].v_xyz[2] = atof(TempChar);
	}

	if (feof(FileHandleGNSS))
	{
		FlagEndGNSS = 1;
	}

	return 0;
}

/*
	Get PPS data once
*/
int GetDataPPS()
{
	fscanf(FileHandlePPS, "%s", TempChar);
	TimePPS = atof(TempChar);

	if (feof(FileHandlePPS))
	{
		FlagEndPPS = 1;
	}

	return 0;
}






/*
	Feedback correction
*/
int FeedbackCorrection()
{
	int i, j;
	double Ctb[3][3] = { 0 };
	double Ctp[3][3] = { 0 };
	double quaternionNorm = 0;
	double Qtb[4] = { 0 };
	double pitch, roll, yaw;


	// ************************* Fix velocity location *************************** //
#if FUSION_TYPE == 1
	// Tilt from navigation coordinate to platform coordinate
	Ctp[0][0] = 1;
	Ctp[1][0] = KfParamTemp.Xes[2];
	Ctp[2][0] = -KfParamTemp.Xes[1];

	Ctp[0][1] = -KfParamTemp.Xes[2];
	Ctp[1][1] = 1;
	Ctp[2][1] = KfParamTemp.Xes[0];

	Ctp[0][2] = KfParamTemp.Xes[1];
	Ctp[1][2] = -KfParamTemp.Xes[0];
	Ctp[2][2] = 1;

	// Correct velocity
	NavParamNew.v[0] = NavParamNew.v[0] - KfParamTemp.Xes[3];
	NavParamNew.v[1] = NavParamNew.v[1] - KfParamTemp.Xes[4];
	NavParamNew.v[2] = NavParamNew.v[2] - KfParamTemp.Xes[5];
	// Correct position
	NavParamNew.la = NavParamNew.la - KfParamTemp.Xes[6];
	NavParamNew.lon = NavParamNew.lon - KfParamTemp.Xes[7];
	NavParamNew.alt = NavParamNew.alt - KfParamTemp.Xes[8];
#endif
#if FUSION_TYPE == 2
	// Tilt from navigation coordinate to platform coordinate
	Ctp[0][0] = 1;
	Ctp[1][0] = UkfParamTemp.Xes[2];
	Ctp[2][0] = -UkfParamTemp.Xes[1];

	Ctp[0][1] = -UkfParamTemp.Xes[2];
	Ctp[1][1] = 1;
	Ctp[2][1] = UkfParamTemp.Xes[0];

	Ctp[0][2] = UkfParamTemp.Xes[1];
	Ctp[1][2] = -UkfParamTemp.Xes[0];
	Ctp[2][2] = 1;
	// Correct velocity
	NavParamNew.v[0] = (fabs(UkfParamTemp.Xes[3]) > THRESHOLD_ERROR) ? NavParamNew.v[0] : (NavParamNew.v[0] - UkfParamTemp.Xes[3]);
	NavParamNew.v[1] = (fabs(UkfParamTemp.Xes[4]) > THRESHOLD_ERROR) ? NavParamNew.v[1] : (NavParamNew.v[1] - UkfParamTemp.Xes[4]);
	NavParamNew.v[2] = (fabs(UkfParamTemp.Xes[5]) > THRESHOLD_ERROR) ? NavParamNew.v[2] : (NavParamNew.v[2] - UkfParamTemp.Xes[5]);
	// Correct position
	NavParamNew.la = (fabs(UkfParamTemp.Xes[6]) > THRESHOLD_ERROR) ? NavParamNew.la : (NavParamNew.la - UkfParamTemp.Xes[6]);
	NavParamNew.lon = (fabs(UkfParamTemp.Xes[7]) > THRESHOLD_ERROR) ? NavParamNew.lon : (NavParamNew.lon - UkfParamTemp.Xes[7]);
	NavParamNew.alt = (fabs(UkfParamTemp.Xes[8]) > THRESHOLD_ERROR) ? NavParamNew.alt : (NavParamNew.alt - UkfParamTemp.Xes[8]);
#endif
#if FUSION_TYPE == 4
	// Tilt from navigation coordinate to computer coordinate
	Ctp[0][0] = 1;
	Ctp[1][0] = HinfukfParamTemp.Xes[2];
	Ctp[2][0] = -HinfukfParamTemp.Xes[1];

	Ctp[0][1] = -HinfukfParamTemp.Xes[2];
	Ctp[1][1] = 1;
	Ctp[2][1] = HinfukfParamTemp.Xes[0];

	Ctp[0][2] = HinfukfParamTemp.Xes[1];
	Ctp[1][2] = -HinfukfParamTemp.Xes[0];
	Ctp[2][2] = 1;
	// Correct velocity
	NavParamNew.v[0] = (fabs(HinfukfParamTemp.Xes[3]) > THRESHOLD_ERROR) ? NavParamNew.v[0] : (NavParamNew.v[0] - HinfukfParamTemp.Xes[3]);
	NavParamNew.v[1] = (fabs(HinfukfParamTemp.Xes[4]) > THRESHOLD_ERROR) ? NavParamNew.v[1] : (NavParamNew.v[1] - HinfukfParamTemp.Xes[4]);
	NavParamNew.v[2] = (fabs(HinfukfParamTemp.Xes[5]) > THRESHOLD_ERROR) ? NavParamNew.v[2] : (NavParamNew.v[2] - HinfukfParamTemp.Xes[5]);
	// Correct position
	NavParamNew.la = (fabs(HinfukfParamTemp.Xes[6]) > THRESHOLD_ERROR) ? NavParamNew.la : (NavParamNew.la - HinfukfParamTemp.Xes[6]);
	NavParamNew.lon = (fabs(HinfukfParamTemp.Xes[7]) > THRESHOLD_ERROR) ? NavParamNew.lon : (NavParamNew.lon - HinfukfParamTemp.Xes[7]);
	NavParamNew.alt = (fabs(HinfukfParamTemp.Xes[8]) > THRESHOLD_ERROR) ? NavParamNew.alt : (NavParamNew.alt - HinfukfParamTemp.Xes[8]);
#endif
#if FUSION_TYPE == 5
	// Correct velocity
	NavParamNew.v[0] = (fabs(QlcukfParamTemp.Xes[4]) > THRESHOLD_ERROR) ? NavParamNew.v[0] : (NavParamNew.v[0] - QlcukfParamTemp.Xes[4]);
	NavParamNew.v[1] = (fabs(QlcukfParamTemp.Xes[5]) > THRESHOLD_ERROR) ? NavParamNew.v[1] : (NavParamNew.v[1] - QlcukfParamTemp.Xes[5]);
	NavParamNew.v[2] = (fabs(QlcukfParamTemp.Xes[6]) > THRESHOLD_ERROR) ? NavParamNew.v[2] : (NavParamNew.v[2] - QlcukfParamTemp.Xes[6]);
	// Correct position
	NavParamNew.la = (fabs(QlcukfParamTemp.Xes[7]) > THRESHOLD_ERROR) ? NavParamNew.la : (NavParamNew.la - QlcukfParamTemp.Xes[7]);
	NavParamNew.lon = (fabs(QlcukfParamTemp.Xes[8]) > THRESHOLD_ERROR) ? NavParamNew.lon : (NavParamNew.lon - QlcukfParamTemp.Xes[8]);
	NavParamNew.alt = (fabs(QlcukfParamTemp.Xes[9]) > THRESHOLD_ERROR) ? NavParamNew.alt : (NavParamNew.alt - QlcukfParamTemp.Xes[9]);
#endif
#if FUSION_TYPE == 6
	// Correct velocity
	NavParamNew.v[0] = (fabs(QtcukfParamTemp.Xes[4]) > THRESHOLD_ERROR) ? NavParamNew.v[0] : (NavParamNew.v[0] - QtcukfParamTemp.Xes[4]);
	NavParamNew.v[1] = (fabs(QtcukfParamTemp.Xes[5]) > THRESHOLD_ERROR) ? NavParamNew.v[1] : (NavParamNew.v[1] - QtcukfParamTemp.Xes[5]);
	NavParamNew.v[2] = (fabs(QtcukfParamTemp.Xes[6]) > THRESHOLD_ERROR) ? NavParamNew.v[2] : (NavParamNew.v[2] - QtcukfParamTemp.Xes[6]);
	// Correct position
	NavParamNew.la = (fabs(QtcukfParamTemp.Xes[7]) > THRESHOLD_ERROR) ? NavParamNew.la : (NavParamNew.la - QtcukfParamTemp.Xes[7]);
	NavParamNew.lon = (fabs(QtcukfParamTemp.Xes[8]) > THRESHOLD_ERROR) ? NavParamNew.lon : (NavParamNew.lon - QtcukfParamTemp.Xes[8]);
	NavParamNew.alt = (fabs(QtcukfParamTemp.Xes[9]) > THRESHOLD_ERROR) ? NavParamNew.alt : (NavParamNew.alt - QtcukfParamTemp.Xes[9]);
#endif



	// ********************************** Fix attitude ******************************** //
#if ((FUSION_TYPE == 1) || (FUSION_TYPE == 2) || (FUSION_TYPE == 4))
	// Ctb = Cpb * Ctp
	matMul(Ctb, 3, 3, NavParamNew.Ctb, 3, 3, Ctp, 3, 3);
	for (i = 0; i < 3; i ++)
	for (j = 0; j < 3; j++)
	Ctb[i][j] = NavParamNew.Ctb[i][j];

	NavParamNew.Qtb[0] = sqrt(1 + Ctb[0][0] + Ctb[1][1] + Ctb[2][2]) / 2;
	NavParamNew.Qtb[1] = (Ctb[1][2] - Ctb[2][1]) / (4 * NavParamNew.Qtb[0]);
	NavParamNew.Qtb[2] = (Ctb[2][0] - Ctb[0][2]) / (4 * NavParamNew.Qtb[0]);
	NavParamNew.Qtb[3] = (Ctb[0][1] - Ctb[1][0]) / (4 * NavParamNew.Qtb[0]);

	quaternionNorm = 0;
	for (i = 0; i < 4; i++)
	{
		quaternionNorm += NavParamNew.Qtb[i] * NavParamNew.Qtb[i];
	}
	quaternionNorm = sqrt(quaternionNorm);
	for (i = 0; i < 4; i++)
	{
		NavParamNew.Qtb[i] /= quaternionNorm;
	}
#endif
#if FUSION_TYPE == 5
	Qtb[0] = QlcukfParamTemp.Xes[0];
	Qtb[1] = QlcukfParamTemp.Xes[1];
	Qtb[2] = QlcukfParamTemp.Xes[2];
	Qtb[3] = QlcukfParamTemp.Xes[3];

	Ctp[0][0] = Qtb[0] * Qtb[0] + Qtb[1] * Qtb[1] - Qtb[2] * Qtb[2] - Qtb[3] * Qtb[3];
	Ctp[0][1] = 2 * (Qtb[1] * Qtb[2] + Qtb[0] * Qtb[3]);
	Ctp[0][2] = 2 * (Qtb[1] * Qtb[3] - Qtb[0] * Qtb[2]);

	Ctp[1][0] = 2 * (Qtb[1] * Qtb[2] - Qtb[0] * Qtb[3]);
	Ctp[1][1] = Qtb[0] * Qtb[0] - Qtb[1] * Qtb[1] + Qtb[2] * Qtb[2] - Qtb[3] * Qtb[3];
	Ctp[1][2] = 2 * (Qtb[2] * Qtb[3] + Qtb[0] * Qtb[1]);

	Ctp[2][0] = 2 * (Qtb[1] * Qtb[3] + Qtb[0] * Qtb[2]);
	Ctp[2][1] = 2 * (Qtb[2] * Qtb[3] - Qtb[0] * Qtb[1]);
	Ctp[2][2] = Qtb[0] * Qtb[0] - Qtb[1] * Qtb[1] - Qtb[2] * Qtb[2] + Qtb[3] * Qtb[3];

	/*matMul(Ctb, 3, 3, NavParamNew.Ctb, 3, 3, Ctp, 3, 3);

	NavParamNew.Qtb[0] = sqrt(1 + Ctb[0][0] + Ctb[1][1] + Ctb[2][2]) / 2;
	NavParamNew.Qtb[1] = (Ctb[1][2] - Ctb[2][1]) / (4 * NavParamNew.Qtb[0]);
	NavParamNew.Qtb[2] = (Ctb[2][0] - Ctb[0][2]) / (4 * NavParamNew.Qtb[0]);
	NavParamNew.Qtb[3] = (Ctb[0][1] - Ctb[1][0]) / (4 * NavParamNew.Qtb[0]);

	quaternionNorm = 0;
	for (i = 0; i < 4; i++)
	{
		quaternionNorm += NavParamNew.Qtb[i] * NavParamNew.Qtb[i];
	}
	quaternionNorm = sqrt(quaternionNorm);
	for (i = 0; i < 4; i++)
	{
		NavParamNew.Qtb[i] /= quaternionNorm;
	}*/
#endif
#if FUSION_TYPE == 6
	Qtb[0] = QtcukfParamTemp.Xes[0];
	Qtb[1] = QtcukfParamTemp.Xes[1];
	Qtb[2] = QtcukfParamTemp.Xes[2];
	Qtb[3] = QtcukfParamTemp.Xes[3];

	Ctp[0][0] = Qtb[0] * Qtb[0] + Qtb[1] * Qtb[1] - Qtb[2] * Qtb[2] - Qtb[3] * Qtb[3];
	Ctp[0][1] = 2 * (Qtb[1] * Qtb[2] + Qtb[0] * Qtb[3]);
	Ctp[0][2] = 2 * (Qtb[1] * Qtb[3] - Qtb[0] * Qtb[2]);

	Ctp[1][0] = 2 * (Qtb[1] * Qtb[2] - Qtb[0] * Qtb[3]);
	Ctp[1][1] = Qtb[0] * Qtb[0] - Qtb[1] * Qtb[1] + Qtb[2] * Qtb[2] - Qtb[3] * Qtb[3];
	Ctp[1][2] = 2 * (Qtb[2] * Qtb[3] + Qtb[0] * Qtb[1]);

	Ctp[2][0] = 2 * (Qtb[1] * Qtb[3] + Qtb[0] * Qtb[2]);
	Ctp[2][1] = 2 * (Qtb[2] * Qtb[3] - Qtb[0] * Qtb[1]);
	Ctp[2][2] = Qtb[0] * Qtb[0] - Qtb[1] * Qtb[1] - Qtb[2] * Qtb[2] + Qtb[3] * Qtb[3];

	/*matMul(Ctb, 3, 3, NavParamNew.Ctb, 3, 3, Ctp, 3, 3);

	NavParamNew.Qtb[0] = sqrt(1 + Ctb[0][0] + Ctb[1][1] + Ctb[2][2]) / 2;
	NavParamNew.Qtb[1] = (Ctb[1][2] - Ctb[2][1]) / (4 * NavParamNew.Qtb[0]);
	NavParamNew.Qtb[2] = (Ctb[2][0] - Ctb[0][2]) / (4 * NavParamNew.Qtb[0]);
	NavParamNew.Qtb[3] = (Ctb[0][1] - Ctb[1][0]) / (4 * NavParamNew.Qtb[0]);

	quaternionNorm = 0;
	for (i = 0; i < 4; i++)
	{
	quaternionNorm += NavParamNew.Qtb[i] * NavParamNew.Qtb[i];
	}
	quaternionNorm = sqrt(quaternionNorm);
	for (i = 0; i < 4; i++)
	{
	NavParamNew.Qtb[i] /= quaternionNorm;
	}*/
#endif


	return 0;
}







/*
	Output correction
*/
int OutputCorrection()
{
	double CtbTemp[3][3] = { 0 };

#if FUSION_TYPE != 5
	matMul(CtbTemp, 3, 3, NavParamNew.Ctb, 3, 3, Cct, 3, 3);

	// Correct attitude
	NavParamOld.pitch = asin(CtbTemp[1][2]); // -pi/2 to pi/2

	NavParamOld.roll = atan2(-CtbTemp[0][2], CtbTemp[2][2]); // -pi to pi

	NavParamOld.yaw = atan2(CtbTemp[1][0], CtbTemp[1][1]); // 0 to 2*pi
	if (NavParamOld.yaw < 0)
		NavParamOld.yaw += 2 * pi;
#else
	//NavParamOld.Qtb[0];
#endif

#if FUSION_TYPE == 1
	// Correct velocity
	NavParamOld.v[0] = NavParamOld.v[0] - KfParamTemp.Xes[3];
	NavParamOld.v[1] = NavParamOld.v[1] - KfParamTemp.Xes[4];
	NavParamOld.v[2] = NavParamOld.v[2] - KfParamTemp.Xes[5];
	// Correct position
	NavParamOld.la = NavParamOld.la - KfParamTemp.Xes[6];
	NavParamOld.lon = NavParamOld.lon - KfParamTemp.Xes[7];
	NavParamOld.alt = NavParamOld.alt - KfParamTemp.Xes[8];
#endif
#if FUSION_TYPE == 2
	// Correct velocity
	NavParamOld.v[0] = (fabs(UkfParamTemp.Xes[3]) > THRESHOLD_ERROR) ? NavParamOld.v[0] : (NavParamOld.v[0] + UkfParamTemp.Xes[3]);
	NavParamOld.v[1] = (fabs(UkfParamTemp.Xes[4]) > THRESHOLD_ERROR) ? NavParamOld.v[1] : (NavParamOld.v[1] + UkfParamTemp.Xes[4]);
	NavParamOld.v[2] = (fabs(UkfParamTemp.Xes[5]) > THRESHOLD_ERROR) ? NavParamOld.v[2] : (NavParamOld.v[2] + UkfParamTemp.Xes[5]);
	// Correct position
	NavParamOld.la = (fabs(UkfParamTemp.Xes[6]) > THRESHOLD_ERROR) ? NavParamOld.la : (NavParamOld.la + UkfParamTemp.Xes[6]);
	NavParamOld.lon = (fabs(UkfParamTemp.Xes[7]) > THRESHOLD_ERROR) ? NavParamOld.lon : (NavParamOld.lon + UkfParamTemp.Xes[7]);
	NavParamOld.alt = (fabs(UkfParamTemp.Xes[8]) > THRESHOLD_ERROR) ? NavParamOld.alt : (NavParamOld.alt + UkfParamTemp.Xes[8]);
#endif

	return 0;
}





/**
  *	main entrance
  */
int main() {
	int i, j;

	int countLength = 0;
	int countKF = 0;



	//*****************************  Get file handle ************************************//

	// Measurements IMU
	if ((FileHandleIMU = fopen(FILE_NAME_IMU, "r")) == NULL) {
		printf("IMU Measurements fopen error!\n");
		getchar();
		return 1;
	}

	// Measurements GNSS
	if ((FileHandleGNSS = fopen(FILE_NAME_GNSS, "r")) == NULL) {
		printf("GNSS Measurements fopen error!\n");
		getchar();
		return 1;
	}

	// Measurements PPS
	if ((FileHandlePPS = fopen(FILE_NAME_PPS, "r")) == NULL) {
		printf("PPS Measurements fopen error!\n");
		getchar();
		return 1;
	}


#if FUSION_TYPE == 0
	// SINS results
	if ((FileHandleResultsSINS = fopen("../../Data/results_sins.dat", "w")) == NULL) {
		printf("SINS results fopen error!\n");
		getchar();
		return 1;
	}
#endif
#if FUSION_TYPE == 1
	// KF results
	if ((FileHandleResultsKF = fopen("../../Data/results_kf.dat", "w")) == NULL) {
		printf("KF results fopen error!\n");
		getchar();
		return 1;
	}

	// Kalman filter error record
	if ((FileHandleErrorKF = fopen("../../Data/es_kf.dat", "w")) == NULL) {
		printf("Error record fopen error!\n");
		getchar();
		return 1;
	}

	// Kalman filter square root of error variance
	if ((FileHandleVarKF = fopen("../../Data/var_kf.dat", "w")) == NULL) {
		printf("Error record fopen error!\n");
		getchar();
		return 1;
	}
#endif
#if FUSION_TYPE == 2
	// UKF results
	if ((FileHandleResultsUKF = fopen("../../Data/results_ukf.dat", "w")) == NULL) {
		printf("UKF results fopen error!\n");
		getchar();
		return 1;
	}

	// UKF error record
	if ((FileHandleErrorUKF = fopen("../../Data/es_ukf.dat", "w")) == NULL) {
		printf("Error record fopen error!\n");
		getchar();
		return 1;
	}

	// UKF square root of error variance
	if ((FileHandleVarUKF = fopen("../../Data/var_ukf.dat", "w")) == NULL) {
		printf("Error record fopen error!\n");
		getchar();
		return 1;
	}
#endif
#if FUSION_TYPE == 4
	// UKF results
	if ((FileHandleResultsHinfUKF = fopen("../../Data/results_hinfukf.dat", "w")) == NULL) {
		printf("H-infinity UKF results fopen error!\n");
		getchar();
		return 1;
	}

	// UKF error record
	if ((FileHandleErrorHinfUKF = fopen("../../Data/es_hinfukf.dat", "w")) == NULL) {
		printf("Error record fopen error!\n");
		getchar();
		return 1;
	}

	// UKF square root of error variance
	if ((FileHandleVarHinfUKF = fopen("../../Data/var_hinfukf.dat", "w")) == NULL) {
		printf("Error record fopen error!\n");
		getchar();
		return 1;
	}
#endif
#if FUSION_TYPE == 5
	// Quaternion based loosely coupled UKF results
	if ((FileHandleResultsQLCUKF = fopen("../../Data/results_qlcukf.dat", "w")) == NULL) {
		printf("Quaternion based loosely coupled UKF results fopen error!\n");
		getchar();
		return 1;
	}

	// QUKF error record
	if ((FileHandleErrorQLCUKF = fopen("../../Data/es_qlcukf.dat", "w")) == NULL) {
		printf("Error record fopen error!\n");
		getchar();
		return 1;
	}

	// QUKF square root of error variance
	if ((FileHandleVarQLCUKF = fopen("../../Data/var_qlcukf.dat", "w")) == NULL) {
		printf("Error record fopen error!\n");
		getchar();
		return 1;
	}
#endif
#if FUSION_TYPE == 6
	// Quaternion based tightly coupled UKF results
	if ((FileHandleResultsQTCUKF = fopen("../../Data/results_qtcukf.dat", "w")) == NULL) {
		printf("Quaternion based tightly coupled UKF results fopen error!\n");
		getchar();
		return 1;
	}

	// QUKF error record
	if ((FileHandleErrorQTCUKF = fopen("../../Data/es_qtcukf.dat", "w")) == NULL) {
		printf("Error record fopen error!\n");
		getchar();
		return 1;
	}

	// QUKF square root of error variance
	if ((FileHandleVarQTCUKF = fopen("../../Data/var_qtcukf.dat", "w")) == NULL) {
		printf("Error record fopen error!\n");
		getchar();
		return 1;
	}
#endif


#if	DATA_BOTH_ENABLE == 1
	// Both IMU and GNSS information
	if ((FileHandleBoth = fopen(FILE_DATA_BOTH, "w")) == NULL) {
		printf("Both information fopen error!\n");
		getchar();
		return 1;
	}
#endif

#if GNSS_RECORD_ENABLE == 1
	// GNSS results
	if ((FileHandleResultsGNSS = fopen("../../Data/results_gnss.dat", "w")) == NULL) {
		printf("GNSS results fopen error!\n");
		getchar();
		return 1;
	}
#endif








	//*****************************  Initialization ********************************//
	NavParamOld = sinsInit(insInitParam);
#if FUSION_TYPE == 1
	// Initialize KF estimaters
	sizeX = 15;
	kfInitParam.T = 0.1;

	kfInitParam.mx0[0] = 0 / unit_rad2degree;
	kfInitParam.mx0[1] = 0 / unit_rad2degree;
	kfInitParam.mx0[2] = 0 / unit_rad2degree;

	kfInitParam.mx0[3] = 0;
	kfInitParam.mx0[4] = 0;
	kfInitParam.mx0[5] = 0;

	kfInitParam.mx0[6] = 0 / unit_rad2degree;
	kfInitParam.mx0[7] = 0 / unit_rad2degree;
	kfInitParam.mx0[8] = 0;

	kfInitParam.mx0[9] = imuErrorParam.gyroDrift[0];
	kfInitParam.mx0[10] = imuErrorParam.gyroDrift[1];
	kfInitParam.mx0[11] = imuErrorParam.gyroDrift[2];

	kfInitParam.mx0[12] = imuErrorParam.accBias[0];
	kfInitParam.mx0[13] = imuErrorParam.accBias[1];
	kfInitParam.mx0[14] = imuErrorParam.accBias[2];

	// Initialize KF covariance
	for (i = 0; i < sizeX; i++)
		*(*(kfInitParam.Cx0) + i * sizeX + i) = 1e-2;
	/*kfInitParam.Cx0[0][0] = (0.02 / unit_rad2degree) * (0.02 / unit_rad2degree);
	kfInitParam.Cx0[1][1] = (0.02 / unit_rad2degree) * (0.02 / unit_rad2degree);
	kfInitParam.Cx0[2][2] = (0.02 / unit_rad2degree) * (0.02 / unit_rad2degree);

	kfInitParam.Cx0[3][3] = 0.1 * 0.1;
	//kfInitParam.Cx0[4][4] = 0.1 * 0.1;
	kfInitParam.Cx0[5][5] = 0.1 * 0.1;

	kfInitParam.Cx0[6][6] = (0.1 / unit_rad2degree) * (0.1 / unit_rad2degree);
	kfInitParam.Cx0[7][7] = (0.1 / unit_rad2degree) * (0.1 / unit_rad2degree);
	kfInitParam.Cx0[8][8] = 0.1 * 0.1;

	kfInitParam.Cx0[9][9] = imuErrorParam.gyroDrift[0] * imuErrorParam.gyroDrift[0];
	kfInitParam.Cx0[10][10] = imuErrorParam.gyroDrift[1] * imuErrorParam.gyroDrift[1];
	kfInitParam.Cx0[11][11] = imuErrorParam.gyroDrift[2] * imuErrorParam.gyroDrift[2];

	kfInitParam.Cx0[12][12] = imuErrorParam.accBias[0] * imuErrorParam.accBias[0];
	kfInitParam.Cx0[13][13] = imuErrorParam.accBias[1] * imuErrorParam.accBias[1];
	kfInitParam.Cx0[14][14] = imuErrorParam.accBias[2] * imuErrorParam.accBias[2];*/
	

	KfParamTemp = kfInit(kfInitParam, sizeX);
#endif
#if FUSION_TYPE == 2
	sizeX = 17;
	ukfInitParam.T = 0.1;
	// Initialize UKF estimaters
	for (i = 0; i < sizeX; i++)
		ukfInitParam.mx0[i] = 0;
	ukfInitParam.mx0[0] = 0 / unit_rad2degree;
	ukfInitParam.mx0[1] = 0 / unit_rad2degree;
	ukfInitParam.mx0[2] = 0 / unit_rad2degree;

	ukfInitParam.mx0[3] = 0;
	ukfInitParam.mx0[4] = 0;
	ukfInitParam.mx0[5] = 0;

	ukfInitParam.mx0[6] = 0 / unit_rad2degree;
	ukfInitParam.mx0[7] = 0 / unit_rad2degree;
	ukfInitParam.mx0[8] = 0;

	ukfInitParam.mx0[9] = imuErrorParam.gyroDrift[0];
	ukfInitParam.mx0[10] = imuErrorParam.gyroDrift[1];
	ukfInitParam.mx0[11] = imuErrorParam.gyroDrift[2];

	ukfInitParam.mx0[12] = imuErrorParam.accBias[0];
	ukfInitParam.mx0[13] = imuErrorParam.accBias[1];
	ukfInitParam.mx0[14] = imuErrorParam.accBias[2];

	ukfInitParam.mx0[15] = gnssErrorParam.timerDriftError;
	ukfInitParam.mx0[16] = gnssErrorParam.timerFrequencyDriftError;

	// Initialize UKF covariance 
	for (i = 0; i < sizeX; i++)
		*(*(ukfInitParam.Cx0) + i * sizeX + i) = 1e-2;



	UkfParamTemp = kfInit(ukfInitParam, sizeX);
#endif
#if FUSION_TYPE == 4
	sizeX = 17;
	hinfukfInitParam.T = 0.1;
	// Initialize UKF estimaters
	for (i = 0; i < sizeX; i++)
		hinfukfInitParam.mx0[i] = 0;
	hinfukfInitParam.mx0[0] = 0 / unit_rad2degree;
	hinfukfInitParam.mx0[1] = 0 / unit_rad2degree;
	hinfukfInitParam.mx0[2] = 0 / unit_rad2degree;

	hinfukfInitParam.mx0[3] = 0;
	hinfukfInitParam.mx0[4] = 0;
	hinfukfInitParam.mx0[5] = 0;

	hinfukfInitParam.mx0[6] = 0 / unit_rad2degree;
	hinfukfInitParam.mx0[7] = 0 / unit_rad2degree;
	hinfukfInitParam.mx0[8] = 0;

	hinfukfInitParam.mx0[9] = imuErrorParam.gyroDrift[0];
	hinfukfInitParam.mx0[10] = imuErrorParam.gyroDrift[1];
	hinfukfInitParam.mx0[11] = imuErrorParam.gyroDrift[2];

	hinfukfInitParam.mx0[12] = imuErrorParam.accBias[0];
	hinfukfInitParam.mx0[13] = imuErrorParam.accBias[1];
	hinfukfInitParam.mx0[14] = imuErrorParam.accBias[2];

	hinfukfInitParam.mx0[15] = gnssErrorParam.timerDriftError;
	hinfukfInitParam.mx0[16] = gnssErrorParam.timerFrequencyDriftError;

	// Initialize UKF covariance 
	for (i = 0; i < sizeX; i++)
		*(*(hinfukfInitParam.Cx0) + i * sizeX + i) = 1e-2;


	HinfukfParamTemp = kfInit(hinfukfInitParam, sizeX);

#endif
#if FUSION_TYPE == 5
	sizeX = 16;
	qlcukfInitParam.T = 0.1;
	// Initialize UKF estimaters
	for (i = 0; i < sizeX; i++)
		qlcukfInitParam.mx0[i] = 0;
	qlcukfInitParam.mx0[0] = 1;
	qlcukfInitParam.mx0[1] = 0;
	qlcukfInitParam.mx0[2] = 0;
	qlcukfInitParam.mx0[3] = 0;

	qlcukfInitParam.mx0[4] = 0;
	qlcukfInitParam.mx0[5] = 0;
	qlcukfInitParam.mx0[6] = 0;

	qlcukfInitParam.mx0[7] = 0 / unit_rad2degree;
	qlcukfInitParam.mx0[8] = 0 / unit_rad2degree;
	qlcukfInitParam.mx0[9] = 0;

	qlcukfInitParam.mx0[10] = imuErrorParam.gyroDrift[0];
	qlcukfInitParam.mx0[11] = imuErrorParam.gyroDrift[1];
	qlcukfInitParam.mx0[12] = imuErrorParam.gyroDrift[2];

	qlcukfInitParam.mx0[13] = imuErrorParam.accBias[0];
	qlcukfInitParam.mx0[14] = imuErrorParam.accBias[1];
	qlcukfInitParam.mx0[15] = imuErrorParam.accBias[2];

	// Initialize UKF covariance 
	for (i = 0; i < sizeX; i++)
		*(*(qlcukfInitParam.Cx0) + i * sizeX + i) = 1e-2;



	QlcukfParamTemp = kfInit(qlcukfInitParam, sizeX);

#endif
#if FUSION_TYPE == 6
	sizeX = 18;
	qtcukfInitParam.T = 0.1;
	// Initialize UKF estimaters
	for (i = 0; i < sizeX; i++)
		qtcukfInitParam.mx0[i] = 0;
	qtcukfInitParam.mx0[0] = 1;
	qtcukfInitParam.mx0[1] = 0;
	qtcukfInitParam.mx0[2] = 0;
	qtcukfInitParam.mx0[3] = 0;

	qtcukfInitParam.mx0[4] = 0;
	qtcukfInitParam.mx0[5] = 0;
	qtcukfInitParam.mx0[6] = 0;

	qtcukfInitParam.mx0[7] = 0 / unit_rad2degree;
	qtcukfInitParam.mx0[8] = 0 / unit_rad2degree;
	qtcukfInitParam.mx0[9] = 0;

	qtcukfInitParam.mx0[10] = imuErrorParam.gyroDrift[0];
	qtcukfInitParam.mx0[11] = imuErrorParam.gyroDrift[1];
	qtcukfInitParam.mx0[12] = imuErrorParam.gyroDrift[2];

	qtcukfInitParam.mx0[13] = imuErrorParam.accBias[0];
	qtcukfInitParam.mx0[14] = imuErrorParam.accBias[1];
	qtcukfInitParam.mx0[15] = imuErrorParam.accBias[2];

	qtcukfInitParam.mx0[16] = gnssErrorParam.timerDriftError;
	qtcukfInitParam.mx0[17] = gnssErrorParam.timerFrequencyDriftError;

	// Initialize UKF covariance 
	for (i = 0; i < sizeX; i++)
		*(*(qtcukfInitParam.Cx0) + i * sizeX + i) = 1e-2;

	QtcukfParamTemp = kfInit(qtcukfInitParam, sizeX);

#endif






	//*****************************  Sync at first PPS  ********************************//
#if FUSION_TYPE != 0
	// Sync IMU and GNSS data at first PPS time
	do
	{
		FlagSyncGNSS = 0;
		FlagSyncIMU = 0;

		// Get PPS time at first
		GetDataPPS();

		// Find GNSS results at first PPS time
		do
		{
			GetDataGNSS();

			// GNSS data end
			if (FlagEndGNSS == 1)
			{
				printf("Error: Cannot sync GNSS data at first PPS time!\n");
				getchar();
				return 1;
			}
		} while (TimeGNSS <= TimePPS);

		
		if ((FlagEndGNSS == 0) && (TimeGNSS > TimePPS))
		{
			// First PPS data has no GNSS output
			if (GnssNavParam.svNumber == 0)
			{
				FlagSyncGNSS = 0;
				continue;
			}
			// GNSS receiver has been positioned
			else
				FlagSyncGNSS = 2;

			// GNSS receiver has got satellites
			if (GnssNavParam.fixQuality > 0)
				FlagSyncGNSS = 1;
		}
			



		// Calculate IMU results at first PPS time
		if ((TimeIMU[0] <= TimePPS) && (TimeIMU[1] <= TimePPS))
		{
			GetDataIMU();

			do
			{
				TimeIMU[0] = TimeIMU[1];
				wibb[0][0] = wibb[0][1];
				wibb[1][0] = wibb[1][1];
				wibb[2][0] = wibb[2][1];
				fb[0][0] = fb[0][1];
				fb[1][0] = fb[1][1];
				fb[2][0] = fb[2][1];

				GetDataIMU();

				// IMU data end
				if (FlagEndIMU == 1)
				{
					printf("Error: Cannot sync IMU data at first PPS time!\n");
					getchar();
					return 1;
				}
			} while (TimeIMU[1] <= TimePPS);
		} // if ((TimeIMU[0] <= TimePPS) && (TimeIMU[1] <= TimePPS))


		// First PPS data has no IMU output
		if (TimeIMU[0] > TimePPS)
		{
			FlagSyncIMU = 0;
			continue;
		}
		else
			FlagSyncIMU = 1;


		// PPS time is too large
		if (FlagEndPPS == 1)
		{
			printf("Error: PPS first time is too large to sync!\n");
			getchar();
			return 1;
		}

	} while ((FlagSyncGNSS == 0) || (FlagSyncIMU == 0));

	printf("******** Time sync success! ********\n");
	printf("TimeIMU[0] = %f\n", TimeIMU[0]);
	printf("TimeIMU[1] = %f\n", TimeIMU[1]);
	printf("TimePPS = %f\n", TimePPS);
	printf("TimeGNSS = %f\n\n", TimeGNSS);
#else
	GetDataIMU();
#endif








	//*****************************  Navigation algorithm  ********************************//
	// Start time
	timeStart = (double)clock() / 1000;

	countLength = 0;
	countKF = 0;
	TimePPSFirst = TimePPS;
	while (FlagEndIMU == 0)
	{

		TimeNow = TimePPSFirst + countLength * NavParamOld.T * 1000;
		TimeNext = TimePPSFirst + (countLength + 1) * NavParamOld.T * 1000;


#if FUSION_TYPE != 0
		if ((TimeNow > TimeIMU[1]) || (TimeNow < TimeIMU[0]))
		{
			printf("\n******** Error sync! ********\n");
			printf("TimeNow = %f\n", TimeNow);
			printf("TimeIMU[0] = %f\n", TimeIMU[0]);
			printf("TimeIMU[1] = %f\n\n", TimeIMU[1]);
			getchar();
			return 1;
		}

		Measurements.time = TimeNow;

		Measurements.w[0] = INTERPOLATION(TimeIMU[0], wibb[0][0], TimeIMU[1], wibb[0][1], Measurements.time);
		Measurements.w[1] = INTERPOLATION(TimeIMU[0], wibb[1][0], TimeIMU[1], wibb[1][1], Measurements.time);
		Measurements.w[2] = INTERPOLATION(TimeIMU[0], wibb[2][0], TimeIMU[1], wibb[2][1], Measurements.time);

		Measurements.f[0] = INTERPOLATION(TimeIMU[0], fb[0][0], TimeIMU[1], fb[0][1], Measurements.time);
		Measurements.f[1] = INTERPOLATION(TimeIMU[0], fb[1][0], TimeIMU[1], fb[1][1], Measurements.time);
		Measurements.f[2] = INTERPOLATION(TimeIMU[0], fb[2][0], TimeIMU[1], fb[2][1], Measurements.time);
#else
		Measurements.time = TimeIMU[1];

		Measurements.w[0] = wibb[0][1];
		Measurements.w[1] = wibb[1][1];
		Measurements.w[2] = wibb[2][1];

		Measurements.f[0] = fb[0][1];
		Measurements.f[1] = fb[1][1];
		Measurements.f[2] = fb[2][1];
#endif

		




		// Strapdown refresh
		NavParamNew = sinsStrapdown(Measurements, NavParamOld, HEIGHT_USED);






#if FUSION_TYPE == 0
		// Record SINS results
		fprintf(FileHandleResultsSINS, "%f\t", Measurements.time);
		fprintf(FileHandleResultsSINS, "%f\t", NavParamOld.pitch * unit_rad2degree);
		fprintf(FileHandleResultsSINS, "%f\t", NavParamOld.roll * unit_rad2degree);
		fprintf(FileHandleResultsSINS, "%f\t", NavParamOld.yaw * unit_rad2degree);
		fprintf(FileHandleResultsSINS, "%f\t", NavParamOld.v[0]);
		fprintf(FileHandleResultsSINS, "%f\t", NavParamOld.v[1]);
		fprintf(FileHandleResultsSINS, "%f\t", NavParamOld.v[2]);
		fprintf(FileHandleResultsSINS, "%f\t", NavParamOld.la * unit_rad2degree);
		fprintf(FileHandleResultsSINS, "%f\t", NavParamOld.lon * unit_rad2degree);
		fprintf(FileHandleResultsSINS, "%f\n", NavParamOld.alt);
#endif
#if FUSION_TYPE == 1
		// Kalman Filter
		if (FlagSyncGNSS == 1)
		{

			// Record GNSS results
			GnssNavParam.time = TimeGNSS;
			GnssNavParam.T = 1. / GNSS_SAMPLING_RATE;

			GnssNavParam.v_enu[0] = \
				GnssNavParam.v_xyz[0] * cos(pi / 2 + GnssNavParam.lon) \
				+ GnssNavParam.v_xyz[1] * sin(pi / 2 + GnssNavParam.lon);
			GnssNavParam.v_enu[1] = \
				- GnssNavParam.v_xyz[0] * cos(pi / 2 - GnssNavParam.la) * sin(pi / 2 + GnssNavParam.lon) \
				+ GnssNavParam.v_xyz[1] * cos(pi / 2 - GnssNavParam.la) * cos(pi / 2 + GnssNavParam.lon) \
				+ GnssNavParam.v_xyz[2] * sin(pi / 2 - GnssNavParam.la);
			GnssNavParam.v_enu[2] = \
				GnssNavParam.v_xyz[0] * sin(pi / 2 - GnssNavParam.la) * sin(pi / 2 + GnssNavParam.lon) \
				+ GnssNavParam.v_xyz[1] * sin(pi / 2 - GnssNavParam.la) * cos(pi / 2 + GnssNavParam.lon) \
				- GnssNavParam.v_xyz[2] * cos(pi / 2 - GnssNavParam.la);

			



			// Kalman Filtering
			KfParamTemp = kf(KfParamTemp, NavParamOld, GnssNavParam, Measurements, imuErrorParam, gnssErrorParam);


			// Results correction
			if (CorrectionMethod == CORRECTION_FEEDBACK)
			{
				FeedbackCorrection();
			}
			else if (CorrectionMethod == CORRECTION_OUTPUT)
			{
				OutputCorrection();
			}
			else if (CorrectionMethod == CORRECTION_HYBRID)
			{
			}




			// Record error
			fprintf(FileHandleErrorKF, "%f\t", Measurements.time);
			// tilt
			for (i = 0; i < 3; i++)
				fprintf(FileHandleErrorKF, "%e\t", KfParamTemp.Xes[i] * unit_rad2degree);
			// velocity error
			for (i = 3; i < 6; i++)
				fprintf(FileHandleErrorKF, "%e\t", KfParamTemp.Xes[i]);
			// latitude and longitude error
			for (i = 6; i < 8; i++)
				fprintf(FileHandleErrorKF, "%e\t", KfParamTemp.Xes[i] * unit_rad2degree);
			// altitude error
			fprintf(FileHandleErrorKF, "%e\t", KfParamTemp.Xes[8]);
			// gyroscope drift
			for (i = 9; i < 12; i++)
				fprintf(FileHandleErrorKF, "%e\t", KfParamTemp.Xes[i] / unit_w); // degrees/h
			// accelerometer bias
			for (i = 12; i < 15; i++)
				fprintf(FileHandleErrorKF, "%e\t", KfParamTemp.Xes[i] / unit_ug); // ug
			fprintf(FileHandleErrorKF, "\n");



			// Record square root of error variance
			fprintf(FileHandleVarKF, "%f\t", Measurements.time);
			// tilt
			for (i = 0; i < 3; i++)
				fprintf(FileHandleVarKF, "%e\t", sqrt(*(*(KfParamTemp.Pes) + i * sizeX + i)) * unit_rad2degree);
			// velocity error
			for (i = 3; i < 6; i++)
				fprintf(FileHandleVarKF, "%e\t", sqrt(*(*(KfParamTemp.Pes) + i * sizeX + i)));
			// latitude and longitude error
			for (i = 6; i < 8; i++)
				fprintf(FileHandleVarKF, "%e\t", sqrt(*(*(KfParamTemp.Pes) + i * sizeX + i)) * unit_rad2degree);
			// altitude error
			fprintf(FileHandleVarKF, "%e\t", sqrt(*(*(KfParamTemp.Pes) + 8 * sizeX + 8)));
			// gyroscope drift
			for (i = 9; i < 12; i++)
				fprintf(FileHandleVarKF, "%e\t", sqrt(*(*(KfParamTemp.Pes) + i * sizeX + i)) / unit_w); // degrees/h
			// accelerometer bias
			for (i = 12; i < 15; i++)
				fprintf(FileHandleVarKF, "%e\t", sqrt(*(*(KfParamTemp.Pes) + i * sizeX + i)) / unit_ug); // ug
			fprintf(FileHandleVarKF, "\n");



			FlagSyncIMU = 0;
			FlagSyncGNSS = 0;

			// Filter time length
			countKF++;

		} // Kalman Filter



		// Record KF results
		fprintf(FileHandleResultsKF, "%f\t", Measurements.time);
		fprintf(FileHandleResultsKF, "%f\t", NavParamOld.pitch * unit_rad2degree);
		fprintf(FileHandleResultsKF, "%f\t", NavParamOld.roll * unit_rad2degree);
		fprintf(FileHandleResultsKF, "%f\t", NavParamOld.yaw * unit_rad2degree);
		fprintf(FileHandleResultsKF, "%f\t", NavParamOld.v[0]);
		fprintf(FileHandleResultsKF, "%f\t", NavParamOld.v[1]);
		fprintf(FileHandleResultsKF, "%f\t", NavParamOld.v[2]);
		fprintf(FileHandleResultsKF, "%f\t", NavParamOld.la * unit_rad2degree);
		fprintf(FileHandleResultsKF, "%f\t", NavParamOld.lon * unit_rad2degree);
		fprintf(FileHandleResultsKF, "%f\n", NavParamOld.alt);
#endif
#if FUSION_TYPE == 2
		// Unscented Kalman Filter
		if (FlagSyncGNSS != 0)
		//if (FlagSyncGNSS == 1)
		{

			// Record GNSS results
			GnssNavParam.time = TimeGNSS;
			GnssNavParam.T = 1. / GNSS_SAMPLING_RATE;

			GnssNavParam.v_enu[0] = \
				GnssNavParam.v_xyz[0] * cos(pi / 2 + GnssNavParam.lon) \
				+ GnssNavParam.v_xyz[1] * sin(pi / 2 + GnssNavParam.lon);
			GnssNavParam.v_enu[1] = \
				- GnssNavParam.v_xyz[0] * cos(pi / 2 - GnssNavParam.la) * sin(pi / 2 + GnssNavParam.lon) \
				+ GnssNavParam.v_xyz[1] * cos(pi / 2 - GnssNavParam.la) * cos(pi / 2 + GnssNavParam.lon) \
				+ GnssNavParam.v_xyz[2] * sin(pi / 2 - GnssNavParam.la);
			GnssNavParam.v_enu[2] = \
				GnssNavParam.v_xyz[0] * sin(pi / 2 - GnssNavParam.la) * sin(pi / 2 + GnssNavParam.lon) \
				+ GnssNavParam.v_xyz[1] * sin(pi / 2 - GnssNavParam.la) * cos(pi / 2 + GnssNavParam.lon) \
				- GnssNavParam.v_xyz[2] * cos(pi / 2 - GnssNavParam.la);






			// UKF
			//GnssNavParam.svNumber = 1;
			UkfParamTemp = ukf(UkfParamTemp, NavParamNew, GnssNavParam, Measurements, imuErrorParam, gnssErrorParam);


			// Results correction
			if (CorrectionMethod == CORRECTION_FEEDBACK)
			{
				FeedbackCorrection();
			}
			else if (CorrectionMethod == CORRECTION_OUTPUT)
			{
				OutputCorrection();
			}
			else if (CorrectionMethod == CORRECTION_HYBRID)
			{
			}




			// Record error
			fprintf(FileHandleErrorUKF, "%f\t", Measurements.time);
			// tilt
			for (i = 0; i < 3; i++)
				fprintf(FileHandleErrorUKF, "%e\t", UkfParamTemp.Xes[i] * unit_rad2degree);
			// velocity error
			for (i = 3; i < 6; i++)
				fprintf(FileHandleErrorUKF, "%e\t", UkfParamTemp.Xes[i]);
			// latitude and longitude error
			for (i = 6; i < 8; i++)
				fprintf(FileHandleErrorUKF, "%e\t", UkfParamTemp.Xes[i] * unit_rad2degree);
			// altitude error
			fprintf(FileHandleErrorUKF, "%e\t", UkfParamTemp.Xes[8]);
			// gyroscope drift
			for (i = 9; i < 12; i++)
				fprintf(FileHandleErrorUKF, "%e\t", UkfParamTemp.Xes[i] / unit_w); // degrees/h
			// accelerometer bias
			for (i = 12; i < 15; i++)
				fprintf(FileHandleErrorUKF, "%e\t", UkfParamTemp.Xes[i] / unit_ug); // ug
			// GNSS receiver timer error caused position error
			fprintf(FileHandleErrorUKF, "%e\t", UkfParamTemp.Xes[15]); // m
			// GNSS receiver timer frequency error caused velocity error
			fprintf(FileHandleErrorUKF, "%e\t", UkfParamTemp.Xes[16]); // m/s
			fprintf(FileHandleErrorUKF, "\n");



			// Record square root of error variance
			fprintf(FileHandleVarUKF, "%f\t", Measurements.time);
			// tilt
			for (i = 0; i < 3; i++)
				fprintf(FileHandleVarUKF, "%e\t", sqrt(*(*(UkfParamTemp.Pes) + i * sizeX + i)) * unit_rad2degree);
			// velocity error
			for (i = 3; i < 6; i++)
				fprintf(FileHandleVarUKF, "%e\t", sqrt(*(*(UkfParamTemp.Pes) + i * sizeX + i)));
			// latitude and longitude error
			for (i = 6; i < 8; i++)
				fprintf(FileHandleVarUKF, "%e\t", sqrt(*(*(UkfParamTemp.Pes) + i * sizeX + i)) * unit_rad2degree);
			// altitude error
			fprintf(FileHandleVarUKF, "%e\t", sqrt(*(*(UkfParamTemp.Pes) + 8 * sizeX + 8)));
			// gyroscope drift
			for (i = 9; i < 12; i++)
				fprintf(FileHandleVarUKF, "%e\t", sqrt(*(*(UkfParamTemp.Pes) + i * sizeX + i)) / unit_w); // degrees/h
			// accelerometer bias
			for (i = 12; i < 15; i++)
				fprintf(FileHandleVarUKF, "%e\t", sqrt(*(*(UkfParamTemp.Pes) + i * sizeX + i)) / unit_ug); // ug
			// GNSS receiver timer error caused position error
			fprintf(FileHandleVarUKF, "%e\t", sqrt(*(*(UkfParamTemp.Pes) + 15 * sizeX + 15))); // m
			// GNSS receiver timer frequency error caused velocity error
			fprintf(FileHandleVarUKF, "%e\t", sqrt(*(*(UkfParamTemp.Pes) + 16 * sizeX + 16))); // m/s
			fprintf(FileHandleVarUKF, "\n");



			FlagSyncIMU = 0;
			FlagSyncGNSS = 0;

			// Filter time length
			countKF++;

		} // Kalman Filter



		// Record KF results
		fprintf(FileHandleResultsUKF, "%f\t", Measurements.time);
		fprintf(FileHandleResultsUKF, "%f\t", NavParamOld.pitch * unit_rad2degree);
		fprintf(FileHandleResultsUKF, "%f\t", NavParamOld.roll * unit_rad2degree);
		fprintf(FileHandleResultsUKF, "%f\t", NavParamOld.yaw * unit_rad2degree);
		fprintf(FileHandleResultsUKF, "%f\t", NavParamOld.v[0]);
		fprintf(FileHandleResultsUKF, "%f\t", NavParamOld.v[1]);
		fprintf(FileHandleResultsUKF, "%f\t", NavParamOld.v[2]);
		fprintf(FileHandleResultsUKF, "%f\t", NavParamOld.la * unit_rad2degree);
		fprintf(FileHandleResultsUKF, "%f\t", NavParamOld.lon * unit_rad2degree);
		fprintf(FileHandleResultsUKF, "%f\n", NavParamOld.alt);

		
#endif
#if FUSION_TYPE == 4
		// Unscented Kalman Filter
		if (FlagSyncGNSS != 0)
			//if (FlagSyncGNSS == 1)
		{

			// Record GNSS results
			GnssNavParam.time = TimeGNSS;
			GnssNavParam.T = 1. / GNSS_SAMPLING_RATE;

			GnssNavParam.v_enu[0] = \
				GnssNavParam.v_xyz[0] * cos(pi / 2 + GnssNavParam.lon) \
				+ GnssNavParam.v_xyz[1] * sin(pi / 2 + GnssNavParam.lon);
			GnssNavParam.v_enu[1] = \
				- GnssNavParam.v_xyz[0] * cos(pi / 2 - GnssNavParam.la) * sin(pi / 2 + GnssNavParam.lon) \
				+ GnssNavParam.v_xyz[1] * cos(pi / 2 - GnssNavParam.la) * cos(pi / 2 + GnssNavParam.lon) \
				+ GnssNavParam.v_xyz[2] * sin(pi / 2 - GnssNavParam.la);
			GnssNavParam.v_enu[2] = \
				GnssNavParam.v_xyz[0] * sin(pi / 2 - GnssNavParam.la) * sin(pi / 2 + GnssNavParam.lon) \
				+ GnssNavParam.v_xyz[1] * sin(pi / 2 - GnssNavParam.la) * cos(pi / 2 + GnssNavParam.lon) \
				- GnssNavParam.v_xyz[2] * cos(pi / 2 - GnssNavParam.la);





			// H-infinity UKF
			//GnssNavParam.svNumber = 1;
			HinfukfParamTemp = hinfukf(HinfukfParamTemp, NavParamOld, GnssNavParam, Measurements, imuErrorParam, gnssErrorParam);


			// Results correction
			if (CorrectionMethod == CORRECTION_FEEDBACK)
			{
				FeedbackCorrection();
			}
			else if (CorrectionMethod == CORRECTION_OUTPUT)
			{
				OutputCorrection();
			}
			else if (CorrectionMethod == CORRECTION_HYBRID)
			{
			}




			// Record error
			fprintf(FileHandleErrorHinfUKF, "%f\t", Measurements.time);
			// tilt
			for (i = 0; i < 3; i++)
				fprintf(FileHandleErrorHinfUKF, "%e\t", HinfukfParamTemp.Xes[i] * unit_rad2degree);
			// velocity error
			for (i = 3; i < 6; i++)
				fprintf(FileHandleErrorHinfUKF, "%e\t", HinfukfParamTemp.Xes[i]);
			// latitude and longitude error
			for (i = 6; i < 8; i++)
				fprintf(FileHandleErrorHinfUKF, "%e\t", HinfukfParamTemp.Xes[i] * unit_rad2degree);
			// altitude error
			fprintf(FileHandleErrorHinfUKF, "%e\t", HinfukfParamTemp.Xes[8]);
			// gyroscope drift
			for (i = 9; i < 12; i++)
				fprintf(FileHandleErrorHinfUKF, "%e\t", HinfukfParamTemp.Xes[i] / unit_w); // degrees/h
			// accelerometer bias
			for (i = 12; i < 15; i++)
				fprintf(FileHandleErrorHinfUKF, "%e\t", HinfukfParamTemp.Xes[i] / unit_ug); // ug
			// GNSS receiver timer error caused position error
			fprintf(FileHandleErrorHinfUKF, "%e\t", HinfukfParamTemp.Xes[15]); // m
			// GNSS receiver timer frequency error caused velocity error
			fprintf(FileHandleErrorHinfUKF, "%e\t", HinfukfParamTemp.Xes[16]); // m/s
			fprintf(FileHandleErrorHinfUKF, "\n");



			// Record square root of error variance
			fprintf(FileHandleVarHinfUKF, "%f\t", Measurements.time);
			// tilt
			for (i = 0; i < 3; i++)
				fprintf(FileHandleVarHinfUKF, "%e\t", sqrt(*(*(HinfukfParamTemp.Pes) + i * sizeX + i)) * unit_rad2degree);
			// velocity error
			for (i = 3; i < 6; i++)
				fprintf(FileHandleVarHinfUKF, "%e\t", sqrt(*(*(HinfukfParamTemp.Pes) + i * sizeX + i)));
			// latitude and longitude error
			for (i = 6; i < 8; i++)
				fprintf(FileHandleVarHinfUKF, "%e\t", sqrt(*(*(HinfukfParamTemp.Pes) + i * sizeX + i)) * unit_rad2degree);
			// altitude error
			fprintf(FileHandleVarHinfUKF, "%e\t", sqrt(*(*(HinfukfParamTemp.Pes) + 8 * sizeX + 8)));
			// gyroscope drift
			for (i = 9; i < 12; i++)
				fprintf(FileHandleVarHinfUKF, "%e\t", sqrt(*(*(HinfukfParamTemp.Pes) + i * sizeX + i)) / unit_w); // degrees/h
			// accelerometer bias
			for (i = 12; i < 15; i++)
				fprintf(FileHandleVarHinfUKF, "%e\t", sqrt(*(*(HinfukfParamTemp.Pes) + i * sizeX + i)) / unit_ug); // ug
			// GNSS receiver timer error caused position error
			fprintf(FileHandleVarHinfUKF, "%e\t", sqrt(*(*(HinfukfParamTemp.Pes) + 15 * sizeX + 15))); // m
			// GNSS receiver timer frequency error caused velocity error
			fprintf(FileHandleVarHinfUKF, "%e\t", sqrt(*(*(HinfukfParamTemp.Pes) + 16 * sizeX + 16))); // m/s
			fprintf(FileHandleVarHinfUKF, "\n");



			FlagSyncIMU = 0;
			FlagSyncGNSS = 0;

			// Filter time length
			countKF++;

		} // Kalman Filter



		// Record Hinf KF results
		fprintf(FileHandleResultsHinfUKF, "%f\t", Measurements.time);
		fprintf(FileHandleResultsHinfUKF, "%f\t", NavParamOld.pitch * unit_rad2degree);
		fprintf(FileHandleResultsHinfUKF, "%f\t", NavParamOld.roll * unit_rad2degree);
		fprintf(FileHandleResultsHinfUKF, "%f\t", NavParamOld.yaw * unit_rad2degree);
		fprintf(FileHandleResultsHinfUKF, "%f\t", NavParamOld.v[0]);
		fprintf(FileHandleResultsHinfUKF, "%f\t", NavParamOld.v[1]);
		fprintf(FileHandleResultsHinfUKF, "%f\t", NavParamOld.v[2]);
		fprintf(FileHandleResultsHinfUKF, "%f\t", NavParamOld.la * unit_rad2degree);
		fprintf(FileHandleResultsHinfUKF, "%f\t", NavParamOld.lon * unit_rad2degree);
		fprintf(FileHandleResultsHinfUKF, "%f\n", NavParamOld.alt);
#endif
#if FUSION_TYPE == 5
		// Quaternion based loosely coupled unscented Kalman Filter
		if (FlagSyncGNSS == 1)
			//if (FlagSyncGNSS == 1)
		{

			// Record GNSS results
			GnssNavParam.time = TimeGNSS;
			GnssNavParam.T = 1. / GNSS_SAMPLING_RATE;

			GnssNavParam.v_enu[0] = \
				GnssNavParam.v_xyz[0] * cos(pi / 2 + GnssNavParam.lon) \
				+ GnssNavParam.v_xyz[1] * sin(pi / 2 + GnssNavParam.lon);
			GnssNavParam.v_enu[1] = \
				- GnssNavParam.v_xyz[0] * cos(pi / 2 - GnssNavParam.la) * sin(pi / 2 + GnssNavParam.lon) \
				+ GnssNavParam.v_xyz[1] * cos(pi / 2 - GnssNavParam.la) * cos(pi / 2 + GnssNavParam.lon) \
				+ GnssNavParam.v_xyz[2] * sin(pi / 2 - GnssNavParam.la);
			GnssNavParam.v_enu[2] = \
				GnssNavParam.v_xyz[0] * sin(pi / 2 - GnssNavParam.la) * sin(pi / 2 + GnssNavParam.lon) \
				+ GnssNavParam.v_xyz[1] * sin(pi / 2 - GnssNavParam.la) * cos(pi / 2 + GnssNavParam.lon) \
				- GnssNavParam.v_xyz[2] * cos(pi / 2 - GnssNavParam.la);





			// Quaternion based KF
			QlcukfParamTemp = qlcukf(QlcukfParamTemp, NavParamOld, GnssNavParam, Measurements, imuErrorParam, gnssErrorParam);


			// Results correction
			if (CorrectionMethod == CORRECTION_FEEDBACK)
			{
				FeedbackCorrection();
			}
			else if (CorrectionMethod == CORRECTION_OUTPUT)
			{
				OutputCorrection();
			}
			else if (CorrectionMethod == CORRECTION_HYBRID)
			{
			}




			// Record error
			fprintf(FileHandleErrorQLCUKF, "%f\t", Measurements.time);
			// quaternion
			for (i = 0; i < 4; i++)
				fprintf(FileHandleErrorQLCUKF, "%e\t", QlcukfParamTemp.Xes[i]);
			// velocity error
			for (i = 4; i < 7; i++)
				fprintf(FileHandleErrorQLCUKF, "%e\t", QlcukfParamTemp.Xes[i]);
			// latitude and longitude error
			for (i = 7; i < 9; i++)
				fprintf(FileHandleErrorQLCUKF, "%e\t", QlcukfParamTemp.Xes[i] * unit_rad2degree);
			// altitude error
			fprintf(FileHandleErrorQLCUKF, "%e\t", QlcukfParamTemp.Xes[9]);
			// gyroscope drift
			for (i = 10; i < 13; i++)
				fprintf(FileHandleErrorQLCUKF, "%e\t", QlcukfParamTemp.Xes[i] / unit_w); // degrees/h
			// accelerometer bias
			for (i = 13; i < 16; i++)
				fprintf(FileHandleErrorQLCUKF, "%e\t", QlcukfParamTemp.Xes[i] / unit_ug); // ug
			fprintf(FileHandleErrorQLCUKF, "\n");



			// Record square root of error variance
			fprintf(FileHandleVarQLCUKF, "%f\t", Measurements.time);
			// quaternion
			for (i = 0; i < 4; i++)
				fprintf(FileHandleVarQLCUKF, "%e\t", sqrt(*(*(QlcukfParamTemp.Pes) + i * sizeX + i)));
			// velocity error
			for (i = 4; i < 7; i++)
				fprintf(FileHandleVarQLCUKF, "%e\t", sqrt(*(*(QlcukfParamTemp.Pes) + i * sizeX + i)));
			// latitude and longitude error
			for (i = 7; i < 9; i++)
				fprintf(FileHandleVarQLCUKF, "%e\t", sqrt(*(*(QlcukfParamTemp.Pes) + i * sizeX + i)) * unit_rad2degree);
			// altitude error
			fprintf(FileHandleVarQLCUKF, "%e\t", sqrt(*(*(QlcukfParamTemp.Pes) + 9 * sizeX + 9)));
			// gyroscope drift
			for (i = 10; i < 13; i++)
				fprintf(FileHandleVarQLCUKF, "%e\t", sqrt(*(*(QlcukfParamTemp.Pes) + i * sizeX + i)) / unit_w); // degrees/h
			// accelerometer bias
			for (i = 13; i < 16; i++)
				fprintf(FileHandleVarQLCUKF, "%e\t", sqrt(*(*(QlcukfParamTemp.Pes) + i * sizeX + i)) / unit_ug); // ug
			fprintf(FileHandleVarQLCUKF, "\n");



			FlagSyncIMU = 0;
			FlagSyncGNSS = 0;

			// Filter time length
			countKF++;

		} // Kalman Filter



		// Record Quaternion KF results
		fprintf(FileHandleResultsQLCUKF, "%f\t", Measurements.time);
		fprintf(FileHandleResultsQLCUKF, "%f\t", NavParamOld.pitch * unit_rad2degree);
		fprintf(FileHandleResultsQLCUKF, "%f\t", NavParamOld.roll * unit_rad2degree);
		fprintf(FileHandleResultsQLCUKF, "%f\t", NavParamOld.yaw * unit_rad2degree);
		fprintf(FileHandleResultsQLCUKF, "%f\t", NavParamOld.v[0]);
		fprintf(FileHandleResultsQLCUKF, "%f\t", NavParamOld.v[1]);
		fprintf(FileHandleResultsQLCUKF, "%f\t", NavParamOld.v[2]);
		fprintf(FileHandleResultsQLCUKF, "%f\t", NavParamOld.la * unit_rad2degree);
		fprintf(FileHandleResultsQLCUKF, "%f\t", NavParamOld.lon * unit_rad2degree);
		fprintf(FileHandleResultsQLCUKF, "%f\n", NavParamOld.alt);
#endif
#if FUSION_TYPE == 6
		// Quaternion based tightly coupled unscented Kalman Filter
		if (FlagSyncGNSS != 0)
			//if (FlagSyncGNSS == 1)
		{

			// Record GNSS results
			GnssNavParam.time = TimeGNSS;
			GnssNavParam.T = 1. / GNSS_SAMPLING_RATE;

			GnssNavParam.v_enu[0] = \
				GnssNavParam.v_xyz[0] * cos(pi / 2 + GnssNavParam.lon) \
				+ GnssNavParam.v_xyz[1] * sin(pi / 2 + GnssNavParam.lon);
			GnssNavParam.v_enu[1] = \
				- GnssNavParam.v_xyz[0] * cos(pi / 2 - GnssNavParam.la) * sin(pi / 2 + GnssNavParam.lon) \
				+ GnssNavParam.v_xyz[1] * cos(pi / 2 - GnssNavParam.la) * cos(pi / 2 + GnssNavParam.lon) \
				+ GnssNavParam.v_xyz[2] * sin(pi / 2 - GnssNavParam.la);
			GnssNavParam.v_enu[2] = \
				GnssNavParam.v_xyz[0] * sin(pi / 2 - GnssNavParam.la) * sin(pi / 2 + GnssNavParam.lon) \
				+ GnssNavParam.v_xyz[1] * sin(pi / 2 - GnssNavParam.la) * cos(pi / 2 + GnssNavParam.lon) \
				- GnssNavParam.v_xyz[2] * cos(pi / 2 - GnssNavParam.la);





			// Quaternion based tightly coupled UKF
			QtcukfParamTemp = qtcukf(QtcukfParamTemp, NavParamOld, GnssNavParam, Measurements, imuErrorParam, gnssErrorParam);


			// Results correction
			if (CorrectionMethod == CORRECTION_FEEDBACK)
			{
				FeedbackCorrection();
			}
			else if (CorrectionMethod == CORRECTION_OUTPUT)
			{
				OutputCorrection();
			}
			else if (CorrectionMethod == CORRECTION_HYBRID)
			{
			}




			// Record error
			fprintf(FileHandleErrorQTCUKF, "%f\t", Measurements.time);
			// quaternion
			for (i = 0; i < 4; i++)
				fprintf(FileHandleErrorQTCUKF, "%e\t", QtcukfParamTemp.Xes[i]);
			// velocity error
			for (i = 4; i < 7; i++)
				fprintf(FileHandleErrorQTCUKF, "%e\t", QtcukfParamTemp.Xes[i]);
			// latitude and longitude error
			for (i = 7; i < 9; i++)
				fprintf(FileHandleErrorQTCUKF, "%e\t", QtcukfParamTemp.Xes[i] * unit_rad2degree);
			// altitude error
			fprintf(FileHandleErrorQTCUKF, "%e\t", QtcukfParamTemp.Xes[9]);
			// gyroscope drift
			for (i = 10; i < 13; i++)
				fprintf(FileHandleErrorQTCUKF, "%e\t", QtcukfParamTemp.Xes[i] / unit_w); // degrees/h
			// accelerometer bias
			for (i = 13; i < 16; i++)
				fprintf(FileHandleErrorQTCUKF, "%e\t", QtcukfParamTemp.Xes[i] / unit_ug); // ug
			// GNSS receiver timer error caused position error
			fprintf(FileHandleErrorQTCUKF, "%e\t", QtcukfParamTemp.Xes[16]); // m
			// GNSS receiver timer frequency error caused velocity error
			fprintf(FileHandleErrorQTCUKF, "%e\t", QtcukfParamTemp.Xes[17]); // m/s
			fprintf(FileHandleErrorQTCUKF, "\n");



			// Record square root of error variance
			fprintf(FileHandleVarQTCUKF, "%f\t", Measurements.time);
			// quaternion
			for (i = 0; i < 4; i++)
				fprintf(FileHandleVarQTCUKF, "%e\t", sqrt(*(*(QtcukfParamTemp.Pes) + i * sizeX + i)));
			// velocity error
			for (i = 4; i < 7; i++)
				fprintf(FileHandleVarQTCUKF, "%e\t", sqrt(*(*(QtcukfParamTemp.Pes) + i * sizeX + i)));
			// latitude and longitude error
			for (i = 7; i < 9; i++)
				fprintf(FileHandleVarQTCUKF, "%e\t", sqrt(*(*(QtcukfParamTemp.Pes) + i * sizeX + i)) * unit_rad2degree);
			// altitude error
			fprintf(FileHandleVarQTCUKF, "%e\t", sqrt(*(*(QtcukfParamTemp.Pes) + 9 * sizeX + 9)));
			// gyroscope drift
			for (i = 10; i < 13; i++)
				fprintf(FileHandleVarQTCUKF, "%e\t", sqrt(*(*(QtcukfParamTemp.Pes) + i * sizeX + i)) / unit_w); // degrees/h
			// accelerometer bias
			for (i = 13; i < 16; i++)
				fprintf(FileHandleVarQTCUKF, "%e\t", sqrt(*(*(QtcukfParamTemp.Pes) + i * sizeX + i)) / unit_ug); // ug
			// GNSS receiver timer error caused position error
			fprintf(FileHandleVarQTCUKF, "%e\t", sqrt(*(*(QtcukfParamTemp.Pes) + 16 * sizeX + 16))); // m
			// GNSS receiver timer frequency error caused velocity error
			fprintf(FileHandleVarQTCUKF, "%e\t", sqrt(*(*(QtcukfParamTemp.Pes) + 17 * sizeX + 17))); // m/s
			fprintf(FileHandleVarQTCUKF, "\n");



			FlagSyncIMU = 0;
			FlagSyncGNSS = 0;

			// Filter time length
			countKF++;

		} // Kalman Filter



		// Record Quaternion KF results
		fprintf(FileHandleResultsQTCUKF, "%f\t", Measurements.time);
		fprintf(FileHandleResultsQTCUKF, "%f\t", NavParamOld.pitch * unit_rad2degree);
		fprintf(FileHandleResultsQTCUKF, "%f\t", NavParamOld.roll * unit_rad2degree);
		fprintf(FileHandleResultsQTCUKF, "%f\t", NavParamOld.yaw * unit_rad2degree);
		fprintf(FileHandleResultsQTCUKF, "%f\t", NavParamOld.v[0]);
		fprintf(FileHandleResultsQTCUKF, "%f\t", NavParamOld.v[1]);
		fprintf(FileHandleResultsQTCUKF, "%f\t", NavParamOld.v[2]);
		fprintf(FileHandleResultsQTCUKF, "%f\t", NavParamOld.la * unit_rad2degree);
		fprintf(FileHandleResultsQTCUKF, "%f\t", NavParamOld.lon * unit_rad2degree);
		fprintf(FileHandleResultsQTCUKF, "%f\n", NavParamOld.alt);
#endif




#if GNSS_RECORD_ENABLE == 1
		fprintf(FileHandleResultsGNSS, "%.6f\t", TimeGNSS);
		fprintf(FileHandleResultsGNSS, "%.6f\t", GnssNavParam.la * unit_rad2degree);
		fprintf(FileHandleResultsGNSS, "%.6f\t", GnssNavParam.lon * unit_rad2degree);
		fprintf(FileHandleResultsGNSS, "%.6f\t", GnssNavParam.alt);
		fprintf(FileHandleResultsGNSS, "%.6f\t", GnssNavParam.v_enu[0]);
		fprintf(FileHandleResultsGNSS, "%.6f\t", GnssNavParam.v_enu[1]);
		fprintf(FileHandleResultsGNSS, "%.6f\n", GnssNavParam.v_enu[2]);
#endif

#if	DATA_BOTH_ENABLE == 1
		// Record both IMU and GNSS information
		fprintf(FileHandleBoth, "%f\t", Measurements.time);
		fprintf(FileHandleBoth, "%e\t", Measurements.w[0]);
		fprintf(FileHandleBoth, "%e\t", Measurements.w[1]);
		fprintf(FileHandleBoth, "%e\t", Measurements.w[2]);
		fprintf(FileHandleBoth, "%e\t", Measurements.f[0]);
		fprintf(FileHandleBoth, "%e\t", Measurements.f[1]);
		fprintf(FileHandleBoth, "%e\t", Measurements.f[2]);

		fprintf(FileHandleBoth, "%d\t", GnssNavParam.fixQuality);
		fprintf(FileHandleBoth, "%d\t", GnssNavParam.svNumber);
		fprintf(FileHandleBoth, "%e\t", GnssNavParam.la);
		fprintf(FileHandleBoth, "%e\t", GnssNavParam.lon);
		fprintf(FileHandleBoth, "%e\t", GnssNavParam.alt);
		fprintf(FileHandleBoth, "%e\t", GnssNavParam.v_enu[0]);
		fprintf(FileHandleBoth, "%e\t", GnssNavParam.v_enu[1]);
		fprintf(FileHandleBoth, "%e\t", GnssNavParam.v_enu[2]);
		for (i = 0; i < RECEIVER_CHANNEL; i++)
		{
			fprintf(FileHandleBoth, "%d\t", GnssNavParam.channel[i].svNo);

			fprintf(FileHandleBoth, "%d\t", GnssNavParam.channel[i].SNR);

			fprintf(FileHandleBoth, "%e\t", GnssNavParam.channel[i].pseu);

			fprintf(FileHandleBoth, "%e\t", GnssNavParam.channel[i].pseuRate);

			fprintf(FileHandleBoth, "%e\t", GnssNavParam.channel[i].p_xyz[0]);

			fprintf(FileHandleBoth, "%e\t", GnssNavParam.channel[i].p_xyz[1]);

			fprintf(FileHandleBoth, "%e\t", GnssNavParam.channel[i].p_xyz[2]);

			fprintf(FileHandleBoth, "%e\t", GnssNavParam.channel[i].v_xyz[0]);

			fprintf(FileHandleBoth, "%e\t", GnssNavParam.channel[i].v_xyz[1]);

			fprintf(FileHandleBoth, "%e\t", GnssNavParam.channel[i].v_xyz[2]);
		}
		fprintf(FileHandleBoth, "\n");
#endif




#if FUSION_TYPE != 0
		// Get new IMU data
		if (TimeNext > TimeIMU[1])
		{
			TimeIMU[0] = TimeIMU[1];
			wibb[0][0] = wibb[0][1];
			wibb[1][0] = wibb[1][1];
			wibb[2][0] = wibb[2][1];
			fb[0][0] = fb[0][1];
			fb[1][0] = fb[1][1];
			fb[2][0] = fb[2][1];

			GetDataIMU();
		}
		


		// Get new GNSS data
		if ((FlagEndGNSS == 0) && (CountIMU == 10 - 1))
		{
			GetDataGNSS();
			CountIMU = 0;

			FlagSyncGNSS = 0;

			// GNSS receiver has got satellite
			if (GnssNavParam.svNumber > 0)
				FlagSyncGNSS = 2;

			// GNSS receiver has been positioned
			if (GnssNavParam.fixQuality > 0)
				FlagSyncGNSS = 1;	
		}
		else if (FlagEndGNSS == 0)
		{
			CountIMU++;
			GnssNavParam = GnssNavParamNone;
		}
		if (FlagEndGNSS != 0)
		{
			GnssNavParam = GnssNavParamNone;
		}

#else
		GetDataIMU();
#endif

		// Total time length
		countLength++;

		// Data refresh
		NavParamOld = NavParamNew;
		

	} // while (FlagEndIMU == 0)

	// Stop time
	timeStop = (double)clock() / 1000;




	

	//*****************************  Close file handle  ********************************//
	fclose(FileHandleIMU);
	fclose(FileHandleGNSS);
	fclose(FileHandlePPS);
#if FUSION_TYPE == 0
	fclose(FileHandleResultsSINS);
#endif
#if FUSION_TYPE == 1
	fclose(FileHandleResultsKF);
	fclose(FileHandleErrorKF);
	fclose(FileHandleVarKF);
#endif
#if FUSION_TYPE == 2
	fclose(FileHandleResultsUKF);
	fclose(FileHandleErrorUKF);
	fclose(FileHandleVarUKF);
#endif
#if FUSION_TYPE == 4
	fclose(FileHandleResultsHinfUKF);
	fclose(FileHandleErrorHinfUKF);
	fclose(FileHandleVarHinfUKF);
#endif
#if FUSION_TYPE == 5
	fclose(FileHandleResultsQLCUKF);
	fclose(FileHandleErrorQLCUKF);
	fclose(FileHandleVarQLCUKF);
#endif
#if FUSION_TYPE == 6
	fclose(FileHandleResultsQTCUKF);
	fclose(FileHandleErrorQTCUKF);
	fclose(FileHandleVarQTCUKF);
#endif

#if	GNSS_RECORD_ENABLE == 1
	fclose(FileHandleResultsGNSS);
#endif

#if	DATA_BOTH_ENABLE == 1
	fclose(FileHandleBoth);
#endif
	
	

	printf("\n******** End. ********\n");
	printf("Total data length: %d\n", countLength);
	printf("Filter data length: %d\n", countKF);
	printf("Time consumed: %fs\n", timeStop - timeStart);
	getchar();

	return 0;
}




