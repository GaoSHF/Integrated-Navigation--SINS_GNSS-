#ifndef SINS_GNSS_KF_H_
#define SINS_GNSS_KF_H_

#include "sins.h"


#define	SATELLITE_NUMBER		32
#define	RECEIVER_CHANNEL		10

#define	MAX_TEMP				50
#define	MAX_X					50
#define	MAX_Z					50
#define	MAX_W					50
#define	MAX_SIGMA_NUM			50
#define	MAX_SIGMA_NUM2			100



//******** IMU parameter ********//

// IMU error parameter struct
typedef struct
{
	// Gyroscope drift
	double gyroDrift[3];

	// Gyroscope white gauss noise MSE
	double gyroNoise[3];

	// Accelerometer bias
	double accBias[3];

	// Accelerometer white gauss noise MSE
	double accNoise[3];

} IMU_ERROR_PARAM;






//******** GNSS parameter ********//

// GNSS navigation parameter struct
typedef struct
{
	// Time interval (s)
	double T;

	// GNSS data receive time
	double time;

	// UTC time
	double utc_time;

	int fixQuality;

	int svNumber;

	// Location, altitude (rad, m)
	double la;
	double lon;
	double alt;

	double PDOP;

	// Position (x-y-z)
	double p_xyz[3];

	// Velocity (x-y-z)
	double v_xyz[3];

	// Velocity (E-N-U, m/s)
	double v_enu[3];

	// All GNSS receiver channels (32 at most)
	struct
	{
		int svNo;
		int SNR;
		double pseu;
		double pseuRate;
		double v_xyz[3];
		double p_xyz[3];
	}channel[SATELLITE_NUMBER];

} GNSS_NAV_PARAM;

// GNSS error parameter struct
typedef struct
{
	// GNSS position measurement white Gauss noise MSE (m)
	double pNoise[3];

	// GNSS velocity measurement white Gauss noise MSE (m/s)
	double vNoise[3];

	// Pseudorage measurement white Gauss noise MSE (m)
	double pseuNoise;

	// Pseudorage rate measurement white Gauss noise MSE (m/s)
	double pseuRateNoise;

	// Timer frequency drift caused velocity deviation white Gauss noise MSE (m/s)
	double timerFrequencyDriftNoise;

	// Timer deviation caused position deviation (m)
	double timerDriftError;

	// Timer frequency drift caused velocity deviation (m/s)
	double timerFrequencyDriftError;

	// Timer drift correlation time
	double timerDriftCorreTime;

} GNSS_ERROR_PARAM;








//******** KF parameter ********//

// Kalman filter initiate parameter struct
typedef struct
{
	// Time interval (s)
	double T;

	// Estimation of system state
	double mx0[MAX_X];

	// Variance matrix of estimation error
	double Cx0[MAX_X][MAX_X];

} KF_INIT_PARAM;



// Kalman filter parameter struct
typedef struct
{
	// Time interval (s)
	double T;

	// Estimation of system state
	double Xes[MAX_X];

	// Variance matrix of estimation error
	double Pes[MAX_X][MAX_X];

} KF_PARAM;





// Kalman filter initialization
KF_PARAM kfInit(KF_INIT_PARAM kfInitParam, int sizeX);

// Kalman filtering
KF_PARAM kf(KF_PARAM kfParamOld, INS_NAV_PARAM sinsNavParam, GNSS_NAV_PARAM gnssNavParam, INS_MEASUREMENT measurements, IMU_ERROR_PARAM imuErrorParam, GNSS_ERROR_PARAM gnssErrorParam);

// Quaternion based Kalman filtering
KF_PARAM qlcukf(KF_PARAM qkfParamOld, INS_NAV_PARAM sinsNavParam, GNSS_NAV_PARAM gnssNavParam, INS_MEASUREMENT measurements, IMU_ERROR_PARAM imuErrorParam, GNSS_ERROR_PARAM gnssErrorParam);

// Unscented Kalman filtering
KF_PARAM ukf(KF_PARAM ukfParamOld, INS_NAV_PARAM sinsNavParam, GNSS_NAV_PARAM gnssNavParam, INS_MEASUREMENT measurements, IMU_ERROR_PARAM imuErrorParam, GNSS_ERROR_PARAM gnssErrorParam);

// H-infinity Unscented Kalman filtering
KF_PARAM hinfukf(KF_PARAM ukfParamOld, INS_NAV_PARAM sinsNavParam, GNSS_NAV_PARAM gnssNavParam, INS_MEASUREMENT measurements, IMU_ERROR_PARAM imuErrorParam, GNSS_ERROR_PARAM gnssErrorParam);

// Quaternion based tightly coupled Kalman filtering
KF_PARAM qtcukf(KF_PARAM qtcukfParamOld, INS_NAV_PARAM sinsNavParam, GNSS_NAV_PARAM gnssNavParam, INS_MEASUREMENT measurements, IMU_ERROR_PARAM imuErrorParam, GNSS_ERROR_PARAM gnssErrorParam);



#endif