#include <stdio.h>
#include <stdlib.h>

#include "sins_main.h"
#include "../sins.h"

#define LENGTH_ACCUM_TIME	(5 * 60)


INS_INIT_PARAM init_param_1min = 
{
	100,
	0.01,

	(2.958066786126155 / unit_rad2degree),
	(14.154302528542125 / unit_rad2degree),
	((360 - 80.386784716753596) / unit_rad2degree),

	-60.542440167488820,
	12.517128987591928,
	-0.663025961716411,

	(29.146706267977070 / unit_rad2degree),
	(121.360149909644680 / unit_rad2degree),
	2418.691384897396300
};

INS_INIT_PARAM init_param_1h = 
{
	100,
	0.01,

	(0 / unit_rad2degree),
	(0 / unit_rad2degree),
	(0 / unit_rad2degree), 

	0,
	0,
	0,

	(40.0211142228246 / unit_rad2degree),
	(116.3703629769560 / unit_rad2degree),
	43.0674
};

/**
  *	main entrance
  */
int main() {

	mainFor1h();

	return 0;
}


/**
  *	1min SINS
  */
int mainFor1min() {

	int i;

	int countLength;

	char temp_char[30] = {0};

	INS_MEASUREMENT measurements;

	INS_NAV_PARAM nav_param_1min, nav_param_1h;

	FILE *fp_in = NULL, *fp_out = NULL;
	
	// Measurements
	if((fp_in = fopen("../../Data/already sync/imu_1min.dat", "r")) == NULL) {
		printf("Measurements fopen error!\n");
		getchar();
		return 1;
	}

	// Results
	if((fp_out = fopen("../../Data/already sync/sins_results_1min.dat", "w")) == NULL) {
		printf("Results fopen error!\n");
		getchar();
		return 1;
	}


	// Get initial navigation parameters
	nav_param_1min = sinsInit(init_param_1min);

	// Strapdown algorithm
	countLength = 0;
	while(1) {
		fscanf(fp_in, "%s", temp_char);

		// UTC time of INS 
		fscanf(fp_in, "%s", temp_char);
		measurements.time = (feof(fp_in) != 0) ? (measurements.time + 1000 * init_param_1min.time_interval) : atof(temp_char);

		// Rotation rate (degrees/h to rad/s)
		for(i = 0; i < 3; i ++) {
			fscanf(fp_in, "%s", temp_char);
			measurements.w[i] = atof(temp_char) * unit_w;
		}

		// Acceleration (g to m/s^2)
		for(i = 0; i < 3; i ++) {
			fscanf(fp_in, "%s", temp_char);
			measurements.f[i] = atof(temp_char) * g0;
		}

		// Record result
		fprintf(fp_out, "%f\t", measurements.time);

		fprintf(fp_out, "%f\t", nav_param_1min.pitch * unit_rad2degree);
		fprintf(fp_out, "%f\t", nav_param_1min.roll * unit_rad2degree);
		fprintf(fp_out, "%f\t", nav_param_1min.yaw * unit_rad2degree);

		fprintf(fp_out, "%f\t", nav_param_1min.v[0]);
		fprintf(fp_out, "%f\t", nav_param_1min.v[1]);
		fprintf(fp_out, "%f\t", nav_param_1min.v[2]);

		fprintf(fp_out, "%f\t", nav_param_1min.la * unit_rad2degree);
		fprintf(fp_out, "%f\t", nav_param_1min.lon * unit_rad2degree);
		fprintf(fp_out, "%f\n", nav_param_1min.h);

		// break condition
		countLength++;
		if (feof(fp_in))
			break;

		// Strapdown refresh
		nav_param_1min = sinsStrapdown(measurements, nav_param_1min, HEIGHT_UNUSED);
	}


	fclose(fp_in);
	fclose(fp_out);
	
	printf("Data length: %d\n", countLength);
	printf("End of SINS navigation calculation.\n");
	getchar();

	return 0;
}


/**
  *	1h SINS
  */
int mainFor1h() {

	int i, j;

	int countLength;

	double accum_w[3] = {0, 0, 0};
	double accum_f[3] = {0, 0, 0};

	char temp_char[30] = {0};

	INS_MEASUREMENT measurements;

	INS_NAV_PARAM nav_param_1h;

	FILE *fp_in = NULL, *fp_out = NULL;
	
	// Measurements
	if((fp_in = fopen("../../Data/already sync/imu_1h.dat", "r")) == NULL) {
		printf("Measurements fopen error!\n");
		getchar();
		return 1;
	}

	// Results
	if((fp_out = fopen("../../Data/already sync/already_sync_sins.dat", "w")) == NULL) {
		printf("Results fopen error!\n");
		getchar();
		return 1;
	}


	// Accumulate 5 min IMU data
	for(j = 0; j < (int)(LENGTH_ACCUM_TIME * init_param_1h.sampling_rate); j ++) {
		fscanf(fp_in, "%s", temp_char);
		if(feof(fp_in))
			break;

		// UTC time of INS 
		fscanf(fp_in, "%s", temp_char);
		measurements.time = atof(temp_char);

		// Rotation rate (degrees/h to rad/s)
		for(i = 0; i < 3; i ++) {
			fscanf(fp_in, "%s", temp_char);
			measurements.w[i] = atof(temp_char) * unit_w;
		}

		// Acceleration (g to m/s^2)
		for(i = 0; i < 3; i ++) {
			fscanf(fp_in, "%s", temp_char);
			measurements.f[i] = atof(temp_char) * g0;
		}
		accum_w[0] += measurements.w[0];
		accum_w[1] += measurements.w[1];
		accum_w[2] += measurements.w[2];
		accum_f[0] += measurements.f[0];
		accum_f[1] += measurements.f[1];
		accum_f[2] += measurements.f[2];
	}
	measurements.w[0] = accum_w[0] / (LENGTH_ACCUM_TIME * init_param_1h.sampling_rate);
	measurements.w[1] = accum_w[1] / (LENGTH_ACCUM_TIME * init_param_1h.sampling_rate);
	measurements.w[2] = accum_w[2] / (LENGTH_ACCUM_TIME * init_param_1h.sampling_rate);
	measurements.f[0] = accum_f[0] / (LENGTH_ACCUM_TIME * init_param_1h.sampling_rate);
	measurements.f[1] = accum_f[1] / (LENGTH_ACCUM_TIME * init_param_1h.sampling_rate);
	measurements.f[2] = accum_f[2] / (LENGTH_ACCUM_TIME * init_param_1h.sampling_rate);

	// Get initial navigation parameters by coarse-alignment
	nav_param_1h = sinsCoarseAlignment(measurements, init_param_1h);

	printf("Coarse alignment result:\n");
	printf("\tpitch_align = %f\n", nav_param_1h.pitch * unit_rad2degree);
	printf("\troll_align = %f\n", nav_param_1h.roll * unit_rad2degree);
	printf("\tyaw_align = %f\n", nav_param_1h.yaw * unit_rad2degree);

	// Strapdown algorithm
	i = 0;
	countLength = 0;
	while (1) {
		fscanf(fp_in, "%s", temp_char);

		// UTC time of INS 
		fscanf(fp_in, "%s", temp_char);
		measurements.time = (feof(fp_in) != 0) ? (measurements.time + 1000 * init_param_1h.time_interval) : atof(temp_char);

		// Rotation rate (degrees/h to rad/s)
		for(i = 0; i < 3; i ++) {
			fscanf(fp_in, "%s", temp_char);
			measurements.w[i] = atof(temp_char) * unit_w;
		}

		// Acceleration (g to m/s^2)
		for(i = 0; i < 3; i ++) {
			fscanf(fp_in, "%s", temp_char);
			measurements.f[i] = atof(temp_char) * g0;
		}

		// Record result
		fprintf(fp_out, "%f\t", measurements.time);

		fprintf(fp_out, "%f\t", nav_param_1h.pitch * unit_rad2degree);
		fprintf(fp_out, "%f\t", nav_param_1h.roll * unit_rad2degree);
		fprintf(fp_out, "%f\t", nav_param_1h.yaw * unit_rad2degree);

		fprintf(fp_out, "%f\t", nav_param_1h.v[0]);
		fprintf(fp_out, "%f\t", nav_param_1h.v[1]);
		fprintf(fp_out, "%f\t", nav_param_1h.v[2]);

		fprintf(fp_out, "%f\t", nav_param_1h.la * unit_rad2degree);
		fprintf(fp_out, "%f\t", nav_param_1h.lon * unit_rad2degree);
		fprintf(fp_out, "%f\n", nav_param_1h.h);

		// break condition
		countLength++;
		if (feof(fp_in))
			break;

		// Strapdown refresh
		nav_param_1h = sinsStrapdown(measurements, nav_param_1h, HEIGHT_UNUSED);
	}

	fclose(fp_in);
	fclose(fp_out);
	
	printf("Data length: %d\n", countLength);
	printf("End of SINS navigation calculation.\n");
	getchar();

	return 0;
}