#ifndef SINS_H_
#define SINS_H_


#define	pi		3.14159265358979323846

// INS algorithm constant
#define	wie		7.292115147e-5	// rad/s
#define	Re		6378137e0		// m
#define	e		(1 / 298.257223563)
#define	g0		9.7803267714	// m/s^2
#define	gk1		0.00193185138639
#define	gk2		0.00669437999013

// Unit transfer constant
#define	unit_rad2degree			(180 / pi)
#define	unit_w					(pi / 3600 / 180)	//degrees/h to rad/s
#define	unit_ug					(g0 * 0.000001)	// ug to m/s^2

// Height channel control
#define	HEIGHT_USED				1
#define	HEIGHT_UNUSED			0




// Initial value struct
typedef struct
{
	// Hz, s
	double sampling_rate;
	double time_interval;

	// Attitude (rad)
	double pitch0;
	double roll0;
	double yaw0;

	// Velocity (m/s)
	double ve0;
	double vn0;
	double vu0;

	// Geographical location, altitude (rad, m)
	double la0;
	double lon0;
	double h0;
} INS_INIT_PARAM;

// INS measurements struct
typedef struct
{
	double time;
	double w[3]; // Rotation rate (rad/s)
	double f[3]; // Acceleration (m/s^2)
} INS_MEASUREMENT;

// Navigation parameter struct
typedef struct
{
	// Time interval (s)
	double T;

	// INS time
	double time;

	// Attitude (rad)
	double pitch;
	double roll;
	double yaw;

	// Velocity (m/s)
	double v[3];

	// Location, altitude (rad, m)
	double la;
	double lon;
	double alt;

	// Euler matrix
	double Ctb[3][3];

	// Quaternion
	double Qtb[4];
} INS_NAV_PARAM;



// **************************** Extern variables ******************************//
double f_b[3];
double w_ib_b[3];
double la0, lon0, alt0;
double ve0, vn0, vu0;
double pitch0, roll0, yaw0;
double T;
double la, lon, alt;
double v[3];
double Qtb[4], Ctb[3][3], pitch, roll, yaw;



// **************************** Extern functions ******************************//
// Set navigation parameters
int sinsSetNavParam(INS_NAV_PARAM nav_param);

// Get navigation parameters
INS_NAV_PARAM sinsGetNavParam();

// Coarse-alignment
INS_NAV_PARAM sinsCoarseAlignment(INS_MEASUREMENT measurements, INS_INIT_PARAM init_param);

// Initiate navigation parameter
INS_NAV_PARAM sinsInit(INS_INIT_PARAM);

// 1 step strapdown algorithm
INS_NAV_PARAM sinsStrapdown(INS_MEASUREMENT, INS_NAV_PARAM, int);



#endif