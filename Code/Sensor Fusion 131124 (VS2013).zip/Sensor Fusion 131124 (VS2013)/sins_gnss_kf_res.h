#ifndef SINS_GNSS_KF_RES_H_
#define SINS_GNSS_KF_RES_H_

#include "sins_gnss_kf.h"




// Extended Kalman filtering
KF_PARAM ekf(KF_PARAM ukfParamOld, INS_NAV_PARAM sinsNavParam, GNSS_NAV_PARAM gnssNavParam, INS_MEASUREMENT measurements, IMU_ERROR_PARAM imuErrorParam, GNSS_ERROR_PARAM gnssErrorParam);


// Square root Unscented Kalman filtering
KF_PARAM srukf(KF_PARAM ukfParamOld, INS_NAV_PARAM sinsNavParam, GNSS_NAV_PARAM gnssNavParam, INS_MEASUREMENT measurements, IMU_ERROR_PARAM imuErrorParam, GNSS_ERROR_PARAM gnssErrorParam);






#endif