#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#include "kf_main.h"
#include "../sins_gnss_kf.h"



#define	RECEIVER_CHANNEL_MAX		10

#define	SINS_SAMPLING_RATE		100
#define	GNSS_SAMPLING_RATE		10


//#define	FUSION_TYPE				0 // SINS
#define	FUSION_TYPE				1 // KF
//#define	FUSION_TYPE				2 // UKF




#define LENGTH_ACCUM_TIME	(0 * 60)
#define	RELAY_BEFORE_FEEDBACK_CORRECTION	(0 * 60)


#define	INTERPOLATION(x0, fx0, x1, fx1, x)		((fx1 - fx0) / (x1 - x0) * (x - x0) + fx0)








IMU_ERROR_PARAM imuErrorParam =
{
	// Gyroscope drift (rad/s)
	0.008 * unit_w,
	0.008 * unit_w,
	0.008 * unit_w,

	// Accelerometer bias (m/s^2)
	50 * unit_ug,
	50 * unit_ug,
	50 * unit_ug
};

GNSS_ERROR_PARAM gnssErrorParam =
{
	// GNSS position error (m)
	{ 0.1, 0.1, 0.1 },

	// GNSS velocity error (m/s)
	{ 0.01, 0.01, 0.01 },

	// Pseudorage error (m)
	{ 0 },

	// Pseudorage rate error (m/s)
	{ 0 },

	// Timer drift caused velocity error (m/s)
	0.01
};

INS_INIT_PARAM insInitParam = 
{
	SINS_SAMPLING_RATE,
	1. / SINS_SAMPLING_RATE,

	(0 / unit_rad2degree),
	(0 / unit_rad2degree),
	(0 / unit_rad2degree), 

	0,
	0,
	0,

	(39. / unit_rad2degree),
	(116. / unit_rad2degree),
	100.
};

KF_INIT_PARAM kfInitParam =
{
	1. / SINS_SAMPLING_RATE,
	{0},
	{0}
};

UKF_INIT_PARAM ukfInitParam =
{
	1. / SINS_SAMPLING_RATE,
	{ 0 },
	{ 0 }
};


// File handle
FILE *FileHandleIMU = NULL;
FILE *FileHandleGNSS = NULL;
FILE *FileHandlePPS = NULL;
FILE *FileHandleResultsSINS = NULL;
FILE *FileHandleResultsGNSS = NULL;
FILE *FileHandleResultsGNSS2 = NULL;
FILE *FileHandleResultsKF = NULL;
FILE *FileHandleErrorKF = NULL;
FILE *FileHandleVarKF = NULL;
FILE *FileHandleResultsUKF = NULL;
FILE *FileHandleErrorUKF = NULL;
FILE *FileHandleVarUKF = NULL;

// PPS, GNSS, IMU time
double TimePPS = 0;
double TimeGNSS = 0;
double TimeIMU[2] = { 0 };
double TimePPSFirst = 0;
double TimeNow = 0;
double TimeNext = 0;


// IMU Measurements
double wibb[3][2] = { 0 };
double fb[3][2] = { 0 };


// Sync flag
int FlagSyncGNSS = 0;
int FlagSyncIMU = 0;

char TempChar[30] = { 0 };

// File over flag
int FlagEndPPS = 0;
int FlagEndGNSS = 0;
int FlagEndIMU = 0;

// Transfer matrix from real geo-coordination to geo-coordination in computer
double Cct[3][3] = { 0 };

INS_MEASUREMENT Measurements;

INS_NAV_PARAM NavParam, NavParamTemp;

GNSS_NAV_PARAM GnssNavParam;

KF_PARAM KfParam, KfParamTemp;

UKF_PARAM uKfParam, uKfParamTemp;


// Correction method
enum{ CORRECTION_FEEDBACK, CORRECTION_OUTPUT, CORRECTION_HYBRID };
int CorrectionMethod = CORRECTION_FEEDBACK;
//int CorrectionMethod = CORRECTION_OUTPUT;








/*
	Get IMU data once
 */
int GetDataIMU()
{
	do
	{
		fscanf(FileHandleIMU, "%s", TempChar);
		TimeIMU[1] = atof(TempChar);

		fscanf(FileHandleIMU, "%s", TempChar);
		wibb[0][1] = atof(TempChar);

		fscanf(FileHandleIMU, "%s", TempChar);
		wibb[1][1] = atof(TempChar);

		fscanf(FileHandleIMU, "%s", TempChar);
		wibb[2][1] = atof(TempChar);

		fscanf(FileHandleIMU, "%s", TempChar);
		fb[0][1] = atof(TempChar);

		fscanf(FileHandleIMU, "%s", TempChar);
		fb[1][1] = atof(TempChar);

		fscanf(FileHandleIMU, "%s", TempChar);
		fb[2][1] = atof(TempChar);

		if (feof(FileHandleIMU))
		{
			FlagEndIMU = 1;
			break;
		}
	} while (TimeIMU[1] <= TimeIMU[0]);

	return 0;
}

/*
	Get GNSS data once
*/
int GetDataGNSS()
{
	int i;

	fscanf(FileHandleGNSS, "%s", TempChar);
	TimeGNSS = atof(TempChar);

	fscanf(FileHandleGNSS, "%s", TempChar);
	GnssNavParam.utc_time = atof(TempChar);

	fscanf(FileHandleGNSS, "%s", TempChar);
	GnssNavParam.fixQuality = atoi(TempChar);

	fscanf(FileHandleGNSS, "%s", TempChar);
	GnssNavParam.svNumber = atoi(TempChar);

	fscanf(FileHandleGNSS, "%s", TempChar);
	GnssNavParam.la = atof(TempChar) / unit_rad2degree;

	fscanf(FileHandleGNSS, "%s", TempChar);
	GnssNavParam.lon = atof(TempChar) / unit_rad2degree;

	fscanf(FileHandleGNSS, "%s", TempChar);
	GnssNavParam.h = atof(TempChar);

	fscanf(FileHandleGNSS, "%s", TempChar);
	GnssNavParam.PDOP = atof(TempChar);

	fscanf(FileHandleGNSS, "%s", TempChar);
	GnssNavParam.p_xyz[0] = atof(TempChar);

	fscanf(FileHandleGNSS, "%s", TempChar);
	GnssNavParam.p_xyz[1] = atof(TempChar);

	fscanf(FileHandleGNSS, "%s", TempChar);
	GnssNavParam.p_xyz[2] = atof(TempChar);

	fscanf(FileHandleGNSS, "%s", TempChar);
	GnssNavParam.v_xyz[0] = atof(TempChar);

	fscanf(FileHandleGNSS, "%s", TempChar);
	GnssNavParam.v_xyz[1] = atof(TempChar);

	fscanf(FileHandleGNSS, "%s", TempChar);
	GnssNavParam.v_xyz[2] = atof(TempChar);

	for (i = 0; i < RECEIVER_CHANNEL_MAX; i++)
	{
		fscanf(FileHandleGNSS, "%s", TempChar);
		GnssNavParam.channel[i].svNo = atoi(TempChar);

		fscanf(FileHandleGNSS, "%s", TempChar);
		GnssNavParam.channel[i].SNR = atoi(TempChar);

		fscanf(FileHandleGNSS, "%s", TempChar);
		GnssNavParam.channel[i].pseu = atof(TempChar);

		fscanf(FileHandleGNSS, "%s", TempChar);
		GnssNavParam.channel[i].pseuRate = atof(TempChar);

		fscanf(FileHandleGNSS, "%s", TempChar);
		GnssNavParam.channel[i].p_xyz[0] = atof(TempChar);

		fscanf(FileHandleGNSS, "%s", TempChar);
		GnssNavParam.channel[i].p_xyz[1] = atof(TempChar);

		fscanf(FileHandleGNSS, "%s", TempChar);
		GnssNavParam.channel[i].p_xyz[2] = atof(TempChar);

		fscanf(FileHandleGNSS, "%s", TempChar);
		GnssNavParam.channel[i].v_xyz[0] = atof(TempChar);

		fscanf(FileHandleGNSS, "%s", TempChar);
		GnssNavParam.channel[i].v_xyz[1] = atof(TempChar);

		fscanf(FileHandleGNSS, "%s", TempChar);
		GnssNavParam.channel[i].v_xyz[2] = atof(TempChar);
	}

	if (feof(FileHandleGNSS))
	{
		FlagEndGNSS = 1;
	}

	return 0;
}

/*
	Get PPS data once
*/
int GetDataPPS()
{
	fscanf(FileHandlePPS, "%s", TempChar);
	TimePPS = atof(TempChar);

	if (feof(FileHandlePPS))
	{
		FlagEndPPS = 1;
	}

	return 0;
}






/*
	Feedback correction
*/
int FeedbackCorrection()
{
	// Ctb = Ctb * Cct
	matMul(NavParamTemp.Ctb, 3, 3, NavParamTemp.Ctb, 3, 3, Cct, 3, 3);

#if FUSION_TYPE == 1
	// Correct velocity
	NavParamTemp.v[0] = NavParamTemp.v[0] + KfParamTemp.Xes[3];
	NavParamTemp.v[1] = NavParamTemp.v[1] + KfParamTemp.Xes[4];
	NavParamTemp.v[2] = NavParamTemp.v[2] + KfParamTemp.Xes[5];
	// Correct position
	NavParamTemp.la = NavParamTemp.la + KfParamTemp.Xes[6];
	NavParamTemp.lon = NavParamTemp.lon + KfParamTemp.Xes[7];
	NavParamTemp.h = NavParamTemp.h + KfParamTemp.Xes[8];
#endif
#if FUSION_TYPE == 2
	// Correct velocity
	NavParamTemp.v[0] = NavParamTemp.v[0] + uKfParamTemp.Xes[3];
	NavParamTemp.v[1] = NavParamTemp.v[1] + uKfParamTemp.Xes[4];
	NavParamTemp.v[2] = NavParamTemp.v[2] + uKfParamTemp.Xes[5];
	// Correct position
	NavParamTemp.la = NavParamTemp.la + uKfParamTemp.Xes[6];
	NavParamTemp.lon = NavParamTemp.lon + uKfParamTemp.Xes[7];
	NavParamTemp.h = NavParamTemp.h + uKfParamTemp.Xes[8];
#endif

	return 0;
}

/*
	Output correction
*/
int OutputCorrection()
{
	double CtbTemp[3][3] = { 0 };

	matMul(CtbTemp, 3, 3, NavParamTemp.Ctb, 3, 3, Cct, 3, 3);

	// Correct attitude
	NavParam.pitch = asin(CtbTemp[1][2]); // -pi/2 to pi/2

	NavParam.roll = atan2(-CtbTemp[0][2], CtbTemp[2][2]); // -pi to pi

	NavParam.yaw = atan2(CtbTemp[1][0], CtbTemp[1][1]); // 0 to 2*pi
	if (NavParam.yaw < 0)
		NavParam.yaw += 2 * pi;

#if FUSION_TYPE == 1
	// Correct velocity
	NavParam.v[0] = NavParam.v[0] + KfParamTemp.Xes[3];
	NavParam.v[1] = NavParam.v[1] + KfParamTemp.Xes[4];
	NavParam.v[2] = NavParam.v[2] + KfParamTemp.Xes[5];
	// Correct position
	NavParam.la = NavParam.la + KfParamTemp.Xes[6];
	NavParam.lon = NavParam.lon + KfParamTemp.Xes[7];
	NavParam.h = NavParam.h + KfParamTemp.Xes[8];
#endif
#if FUSION_TYPE == 2
	// Correct velocity
	NavParam.v[0] = NavParam.v[0] + uKfParamTemp.Xes[3];
	NavParam.v[1] = NavParam.v[1] + uKfParamTemp.Xes[4];
	NavParam.v[2] = NavParam.v[2] + uKfParamTemp.Xes[5];
	// Correct position
	NavParam.la = NavParam.la + uKfParamTemp.Xes[6];
	NavParam.lon = NavParam.lon + uKfParamTemp.Xes[7];
	NavParam.h = NavParam.h + uKfParamTemp.Xes[8];
#endif

	return 0;
}





/**
  *	main entrance
  */
int main() {
	int i, j;

	int countLength = 0;



	//*****************************  Get file handle ************************************//

	// Measurements IMU
	if ((FileHandleIMU = fopen("../../Data/201401031607 (GPS L1 Vn 1g 300 4g 900)/imu_noise.txt", "r")) == NULL) {
		printf("IMU Measurements fopen error!\n");
		getchar();
		return 1;
	}

	// Measurements GNSS
	if ((FileHandleGNSS = fopen("../../Data/201401031607 (GPS L1 Vn 1g 300 4g 900)/gnss.txt", "r")) == NULL) {
		printf("GNSS Measurements fopen error!\n");
		getchar();
		return 1;
	}

	// Measurements PPS
	if ((FileHandlePPS = fopen("../../Data/201401031607 (GPS L1 Vn 1g 300 4g 900)/pps.txt", "r")) == NULL) {
		printf("PPS Measurements fopen error!\n");
		getchar();
		return 1;
	}


#if FUSION_TYPE == 0
	// SINS results
	if ((FileHandleResultsSINS = fopen("../../Data/results_sins.dat", "w")) == NULL) {
		printf("SINS results fopen error!\n");
		getchar();
		return 1;
	}
#endif
#if FUSION_TYPE == 1
	// KF results
	if ((FileHandleResultsKF = fopen("../../Data/results_kf.dat", "w")) == NULL) {
		printf("KF results fopen error!\n");
		getchar();
		return 1;
	}

	// Kalman filter error record
	if ((FileHandleErrorKF = fopen("../../Data/error_kf.dat", "w")) == NULL) {
		printf("Error record fopen error!\n");
		getchar();
		return 1;
	}

	// Kalman filter square root of error variance
	if ((FileHandleVarKF = fopen("../../Data/var_kf.dat", "w")) == NULL) {
		printf("Error record fopen error!\n");
		getchar();
		return 1;
	}

	// GNSS results
	if ((FileHandleResultsGNSS = fopen("../../Data/results_gnss.dat", "w")) == NULL) {
		printf("GNSS results fopen error!\n");
		getchar();
		return 1;
	}
#endif
#if FUSION_TYPE == 2
	// UKF results
	if ((FileHandleResultsUKF = fopen("../../Data/results_ukf.dat", "w")) == NULL) {
		printf("UKF results fopen error!\n");
		getchar();
		return 1;
	}

	// UKF error record
	if ((FileHandleErrorUKF = fopen("../../Data/error_ukf.dat", "w")) == NULL) {
		printf("Error record fopen error!\n");
		getchar();
		return 1;
	}

	// UKF square root of error variance
	if ((FileHandleVarUKF = fopen("../../Data/var_ukf.dat", "w")) == NULL) {
		printf("Error record fopen error!\n");
		getchar();
		return 1;
	}

	// GNSS results
	if ((FileHandleResultsGNSS2 = fopen("../../Data/results_gnss2.dat", "w")) == NULL) {
		printf("GNSS results fopen error!\n");
		getchar();
		return 1;
	}
#endif









	//*****************************  Initialization ********************************//
	NavParam = sinsInit(insInitParam);
#if FUSION_TYPE == 1
	// Initialize KF parameter
	kfInitParam.T = 0.1;
	kfInitParam.mx0[0] = 0.00;
	kfInitParam.mx0[1] = 0.00;
	kfInitParam.mx0[2] = 0.00;

	kfInitParam.mx0[9] = imuErrorParam.drift[0];
	kfInitParam.mx0[10] = imuErrorParam.drift[1];
	kfInitParam.mx0[11] = imuErrorParam.drift[2];

	kfInitParam.mx0[12] = imuErrorParam.bias[0];
	kfInitParam.mx0[13] = imuErrorParam.bias[1];
	kfInitParam.mx0[14] = imuErrorParam.bias[2];

	for (i = 0; i < 15; i++)
		kfInitParam.Cx0[i][i] = 0.001;

	KfParam = kfInit(kfInitParam);
#endif
#if FUSION_TYPE == 2
	// Initialize UKF parameter
	ukfInitParam.T = 0.1;
	ukfInitParam.mx0[0] = 0.003;
	ukfInitParam.mx0[1] = 0.003;
	ukfInitParam.mx0[2] = 0.003;

	ukfInitParam.mx0[9] = imuErrorParam.drift[0];
	ukfInitParam.mx0[10] = imuErrorParam.drift[1];
	ukfInitParam.mx0[11] = imuErrorParam.drift[2];

	ukfInitParam.mx0[12] = imuErrorParam.bias[0];
	ukfInitParam.mx0[13] = imuErrorParam.bias[1];
	ukfInitParam.mx0[14] = imuErrorParam.bias[2];

	ukfInitParam.mx0[15] = 0.1;

	ukfInitParam.mx0[16] = 0.01;

	for (i = 0; i < 17; i++)
		ukfInitParam.Cx0[i][i] = 0.001;



	// Initiate GNSS receiver pseudorage error
	for (i = 0; i < RECEIVER_CHANNEL_MAX; i++)
	{
		gnssErrorParam.gnssNoisePseu[i] = 0.1;
		gnssErrorParam.gnssNoisePseuRate[i] = 0.01;
	}


	uKfParam = ukfInit(ukfInitParam);
#endif






	//*****************************  Sync at first PPS  ********************************//
#if FUSION_TYPE != 0
	// Sync IMU and GNSS data at first PPS time
	do
	{
		FlagSyncGNSS = 0;
		FlagSyncIMU = 0;

		// Get PPS time at first
		GetDataPPS();

		// Find GNSS results at first PPS time
		do
		{
			GetDataGNSS();

			// GNSS data end
			if (FlagEndGNSS == 1)
			{
				printf("Error: Cannot sync GNSS data at first PPS time!\n");
				getchar();
				return 1;
			}
		} while (TimeGNSS <= TimePPS);

		
		if ((FlagEndGNSS == 0) && (TimeGNSS > TimePPS))
		{
			// First PPS data has no GNSS output
			if (GnssNavParam.svNumber == 0)
			{
				FlagSyncGNSS = 0;
				continue;
			}
			// GNSS receiver has been positioned
			else
				FlagSyncGNSS = 2;

			// GNSS receiver has got satellites
			if (GnssNavParam.fixQuality > 0)
				FlagSyncGNSS = 1;
		}
			



		// Calculate IMU results at first PPS time
		if ((TimeIMU[0] <= TimePPS) && (TimeIMU[1] <= TimePPS))
		{
			GetDataIMU();

			do
			{
				TimeIMU[0] = TimeIMU[1];
				wibb[0][0] = wibb[0][1];
				wibb[1][0] = wibb[1][1];
				wibb[2][0] = wibb[2][1];
				fb[0][0] = fb[0][1];
				fb[1][0] = fb[1][1];
				fb[2][0] = fb[2][1];

				GetDataIMU();

				// IMU data end
				if (FlagEndIMU == 1)
				{
					printf("Error: Cannot sync IMU data at first PPS time!\n");
					getchar();
					return 1;
				}
			} while (TimeIMU[1] <= TimePPS);
		} // if ((TimeIMU[0] <= TimePPS) && (TimeIMU[1] <= TimePPS))


		// First PPS data has no IMU output
		if (TimeIMU[0] > TimePPS)
		{
			FlagSyncIMU = 0;
			continue;
		}
		else
			FlagSyncIMU = 1;


		// PPS time is too large
		if (FlagEndPPS == 1)
		{
			printf("Error: PPS first time is too large to sync!\n");
			getchar();
			return 1;
		}

	} while ((FlagSyncGNSS == 0) || (FlagSyncIMU == 0));

	printf("******** Time sync success! ********\n");
	printf("TimeIMU[0] = %f\n", TimeIMU[0]);
	printf("TimeIMU[1] = %f\n", TimeIMU[1]);
	printf("TimePPS = %f\n", TimePPS);
	printf("TimeGNSS = %f\n\n", TimeGNSS);
#else
	GetDataIMU();
#endif








	//*****************************  Navigation algorithm  ********************************//
	countLength = 0;
	TimePPSFirst = TimePPS;
	while (FlagEndIMU == 0)
	{

		TimeNow = TimePPSFirst + countLength * NavParam.T * 1000;
		TimeNext = TimePPSFirst + (countLength + 1) * NavParam.T * 1000;


#if FUSION_TYPE != 0
		if ((TimeNow > TimeIMU[1]) || (TimeNow < TimeIMU[0]))
		{
			printf("\n******** Error sync! ********\n");
			printf("TimeNow = %f\n", TimeNow);
			printf("TimeIMU[0] = %f\n", TimeIMU[0]);
			printf("TimeIMU[1] = %f\n\n", TimeIMU[1]);
			getchar();
			return 1;
		}

		Measurements.time = ((FlagSyncIMU == 1) && (FlagSyncGNSS == 1)) ? TimePPS : TimeNow;

		Measurements.w[0] = INTERPOLATION(TimeIMU[0], wibb[0][0], TimeIMU[1], wibb[0][1], Measurements.time);
		Measurements.w[1] = INTERPOLATION(TimeIMU[0], wibb[1][0], TimeIMU[1], wibb[1][1], Measurements.time);
		Measurements.w[2] = INTERPOLATION(TimeIMU[0], wibb[2][0], TimeIMU[1], wibb[2][1], Measurements.time);

		Measurements.f[0] = INTERPOLATION(TimeIMU[0], fb[0][0], TimeIMU[1], fb[0][1], Measurements.time);
		Measurements.f[1] = INTERPOLATION(TimeIMU[0], fb[1][0], TimeIMU[1], fb[1][1], Measurements.time);
		Measurements.f[2] = INTERPOLATION(TimeIMU[0], fb[2][0], TimeIMU[1], fb[2][1], Measurements.time);
#else
		Measurements.time = TimeIMU[1];

		Measurements.w[0] = wibb[0][1];
		Measurements.w[1] = wibb[1][1];
		Measurements.w[2] = wibb[2][1];

		Measurements.f[0] = fb[0][1];
		Measurements.f[1] = fb[1][1];
		Measurements.f[2] = fb[2][1];
#endif

		




		// Strapdown refresh
		NavParamTemp = sinsStrapdown(Measurements, NavParam, HEIGHT_USED);






#if FUSION_TYPE == 0
		// Record SINS results
		fprintf(FileHandleResultsSINS, "%f\t", Measurements.time);
		fprintf(FileHandleResultsSINS, "%f\t", NavParam.pitch * unit_rad2degree);
		fprintf(FileHandleResultsSINS, "%f\t", NavParam.roll * unit_rad2degree);
		fprintf(FileHandleResultsSINS, "%f\t", NavParam.yaw * unit_rad2degree);
		fprintf(FileHandleResultsSINS, "%f\t", NavParam.v[0]);
		fprintf(FileHandleResultsSINS, "%f\t", NavParam.v[1]);
		fprintf(FileHandleResultsSINS, "%f\t", NavParam.v[2]);
		fprintf(FileHandleResultsSINS, "%f\t", NavParam.la * unit_rad2degree);
		fprintf(FileHandleResultsSINS, "%f\t", NavParam.lon * unit_rad2degree);
		fprintf(FileHandleResultsSINS, "%f\n", NavParam.h);
#endif
#if FUSION_TYPE == 1
		// Kalman Filter
		if ((FlagSyncIMU == 1) && (FlagSyncGNSS == 1))
		{

			// Record GNSS results
			GnssNavParam.time = TimeGNSS;
			GnssNavParam.T = 1. / GNSS_SAMPLING_RATE;

			GnssNavParam.v_enu[0] = \
				GnssNavParam.v_xyz[0] * cos(pi / 2 + GnssNavParam.lon) \
				+ GnssNavParam.v_xyz[1] * sin(pi / 2 + GnssNavParam.lon);
			GnssNavParam.v_enu[1] = \
				- GnssNavParam.v_xyz[0] * cos(pi / 2 - GnssNavParam.la) * sin(pi / 2 + GnssNavParam.lon) \
				+ GnssNavParam.v_xyz[1] * cos(pi / 2 - GnssNavParam.la) * cos(pi / 2 + GnssNavParam.lon) \
				+ GnssNavParam.v_xyz[2] * sin(pi / 2 - GnssNavParam.la);
			GnssNavParam.v_enu[2] = \
				GnssNavParam.v_xyz[0] * sin(pi / 2 - GnssNavParam.la) * sin(pi / 2 + GnssNavParam.lon) \
				+ GnssNavParam.v_xyz[1] * sin(pi / 2 - GnssNavParam.la) * cos(pi / 2 + GnssNavParam.lon) \
				- GnssNavParam.v_xyz[2] * cos(pi / 2 - GnssNavParam.la);

			fprintf(FileHandleResultsGNSS, "%.6f\t", TimePPS);
			fprintf(FileHandleResultsGNSS, "%.6f\t", GnssNavParam.la * unit_rad2degree);
			fprintf(FileHandleResultsGNSS, "%.6f\t", GnssNavParam.lon * unit_rad2degree);
			fprintf(FileHandleResultsGNSS, "%.6f\t", GnssNavParam.h);
			fprintf(FileHandleResultsGNSS, "%.6f\t", GnssNavParam.v_enu[0]);
			fprintf(FileHandleResultsGNSS, "%.6f\t", GnssNavParam.v_enu[1]);
			fprintf(FileHandleResultsGNSS, "%.6f\n", GnssNavParam.v_enu[2]);

			



			// Kalman Filtering
			KfParamTemp = kf(KfParam, NavParam, GnssNavParam, Measurements, imuErrorParam, gnssErrorParam);





			// Tilt correct matrix
			Cct[0][0] = 1;
			Cct[1][0] = KfParamTemp.Xes[2];
			Cct[2][0] = -KfParamTemp.Xes[1];

			Cct[0][1] = -KfParamTemp.Xes[2];
			Cct[1][1] = 1;
			Cct[2][1] = KfParamTemp.Xes[0];

			Cct[0][2] = KfParamTemp.Xes[1];
			Cct[1][2] = -KfParamTemp.Xes[0];
			Cct[2][2] = 1;


			// Results correction
			if (CorrectionMethod == CORRECTION_FEEDBACK)
			{
				FeedbackCorrection();
			}
			else if (CorrectionMethod == CORRECTION_OUTPUT)
			{
				OutputCorrection();
			}
			else if (CorrectionMethod == CORRECTION_HYBRID)
			{
			}




			// Record error
			fprintf(FileHandleErrorKF, "%f\t", Measurements.time);
			// tilt
			for (i = 0; i < 3; i++)
				fprintf(FileHandleErrorKF, "%f\t", KfParamTemp.Xes[i] * unit_rad2degree);
			// velocity error
			for (i = 3; i < 6; i++)
				fprintf(FileHandleErrorKF, "%f\t", KfParamTemp.Xes[i]);
			// latitude and longitude error
			for (i = 6; i < 8; i++)
				fprintf(FileHandleErrorKF, "%f\t", KfParamTemp.Xes[i] * unit_rad2degree);
			// altitude error
			fprintf(FileHandleErrorKF, "%f\t", KfParamTemp.Xes[8]);
			// gyroscope drift
			for (i = 9; i < 12; i++)
				fprintf(FileHandleErrorKF, "%f\t", KfParamTemp.Xes[i] / unit_w); // degrees/h
			// accelerometer bias
			for (i = 12; i < 15; i++)
				fprintf(FileHandleErrorKF, "%f\t", KfParamTemp.Xes[i] / unit_ug); // ug
			fprintf(FileHandleErrorKF, "\n");



			// Record square root of error variance
			fprintf(FileHandleVarKF, "%f\t", Measurements.time);
			// tilt
			for (i = 0; i < 3; i++)
				fprintf(FileHandleVarKF, "%f\t", KfParamTemp.var_es[i] * unit_rad2degree);
			// velocity error
			for (i = 3; i < 6; i++)
				fprintf(FileHandleVarKF, "%f\t", KfParamTemp.var_es[i]);
			// latitude and longitude error
			for (i = 6; i < 8; i++)
				fprintf(FileHandleVarKF, "%f\t", KfParamTemp.var_es[i] * unit_rad2degree);
			// altitude error
			fprintf(FileHandleVarKF, "%f\t", KfParamTemp.var_es[8]);
			// gyroscope drift
			for (i = 9; i < 12; i++)
				fprintf(FileHandleVarKF, "%f\t", KfParamTemp.var_es[i] / unit_w); // degrees/h
			// accelerometer bias
			for (i = 12; i < 15; i++)
				fprintf(FileHandleVarKF, "%f\t", KfParamTemp.var_es[i] / unit_ug); // ug
			fprintf(FileHandleVarKF, "\n");



			FlagSyncIMU = 0;
			FlagSyncGNSS = 0;
		} // Kalman Filter



		// Record KF results
		fprintf(FileHandleResultsKF, "%f\t", Measurements.time);
		fprintf(FileHandleResultsKF, "%f\t", NavParam.pitch * unit_rad2degree);
		fprintf(FileHandleResultsKF, "%f\t", NavParam.roll * unit_rad2degree);
		fprintf(FileHandleResultsKF, "%f\t", NavParam.yaw * unit_rad2degree);
		fprintf(FileHandleResultsKF, "%f\t", NavParam.v[0]);
		fprintf(FileHandleResultsKF, "%f\t", NavParam.v[1]);
		fprintf(FileHandleResultsKF, "%f\t", NavParam.v[2]);
		fprintf(FileHandleResultsKF, "%f\t", NavParam.la * unit_rad2degree);
		fprintf(FileHandleResultsKF, "%f\t", NavParam.lon * unit_rad2degree);
		fprintf(FileHandleResultsKF, "%f\n", NavParam.h);
#endif
#if FUSION_TYPE == 2
		// Kalman Filter
		if ((FlagSyncIMU == 1) && (FlagSyncGNSS != 0))
		{

			// Record GNSS results
			GnssNavParam.time = TimeGNSS;
			GnssNavParam.T = 1. / GNSS_SAMPLING_RATE;

			GnssNavParam.v_enu[0] = \
				GnssNavParam.v_xyz[0] * cos(pi / 2 + GnssNavParam.lon) \
				+ GnssNavParam.v_xyz[1] * sin(pi / 2 + GnssNavParam.lon);
			GnssNavParam.v_enu[1] = \
				- GnssNavParam.v_xyz[0] * cos(pi / 2 - GnssNavParam.la) * sin(pi / 2 + GnssNavParam.lon) \
				+ GnssNavParam.v_xyz[1] * cos(pi / 2 - GnssNavParam.la) * cos(pi / 2 + GnssNavParam.lon) \
				+ GnssNavParam.v_xyz[2] * sin(pi / 2 - GnssNavParam.la);
			GnssNavParam.v_enu[2] = \
				GnssNavParam.v_xyz[0] * sin(pi / 2 - GnssNavParam.la) * sin(pi / 2 + GnssNavParam.lon) \
				+ GnssNavParam.v_xyz[1] * sin(pi / 2 - GnssNavParam.la) * cos(pi / 2 + GnssNavParam.lon) \
				- GnssNavParam.v_xyz[2] * cos(pi / 2 - GnssNavParam.la);

			fprintf(FileHandleResultsGNSS2, "%.6f\t", TimePPS);
			fprintf(FileHandleResultsGNSS2, "%.6f\t", GnssNavParam.la * unit_rad2degree);
			fprintf(FileHandleResultsGNSS2, "%.6f\t", GnssNavParam.lon * unit_rad2degree);
			fprintf(FileHandleResultsGNSS2, "%.6f\t", GnssNavParam.h);
			fprintf(FileHandleResultsGNSS2, "%.6f\t", GnssNavParam.v_enu[0]);
			fprintf(FileHandleResultsGNSS2, "%.6f\t", GnssNavParam.v_enu[1]);
			fprintf(FileHandleResultsGNSS2, "%.6f\n", GnssNavParam.v_enu[2]);





			// UKF
			uKfParamTemp = ukf(uKfParam, NavParam, GnssNavParam, Measurements, imuErrorParam, gnssErrorParam);





			// Tilt correct matrix
			Cct[0][0] = 1;
			Cct[1][0] = uKfParamTemp.Xes[2];
			Cct[2][0] = -uKfParamTemp.Xes[1];

			Cct[0][1] = -uKfParamTemp.Xes[2];
			Cct[1][1] = 1;
			Cct[2][1] = uKfParamTemp.Xes[0];

			Cct[0][2] = uKfParamTemp.Xes[1];
			Cct[1][2] = -uKfParamTemp.Xes[0];
			Cct[2][2] = 1;


			// Results correction
			if (CorrectionMethod == CORRECTION_FEEDBACK)
			{
				FeedbackCorrection();
			}
			else if (CorrectionMethod == CORRECTION_OUTPUT)
			{
				OutputCorrection();
			}
			else if (CorrectionMethod == CORRECTION_HYBRID)
			{
			}




			// Record error
			fprintf(FileHandleErrorUKF, "%f\t", Measurements.time);
			// tilt
			for (i = 0; i < 3; i++)
				fprintf(FileHandleErrorUKF, "%f\t", uKfParamTemp.Xes[i] * unit_rad2degree);
			// velocity error
			for (i = 3; i < 6; i++)
				fprintf(FileHandleErrorUKF, "%f\t", uKfParamTemp.Xes[i]);
			// latitude and longitude error
			for (i = 6; i < 8; i++)
				fprintf(FileHandleErrorUKF, "%f\t", uKfParamTemp.Xes[i] * unit_rad2degree);
			// altitude error
			fprintf(FileHandleErrorUKF, "%f\t", uKfParamTemp.Xes[8]);
			// gyroscope drift
			for (i = 9; i < 12; i++)
				fprintf(FileHandleErrorUKF, "%f\t", uKfParamTemp.Xes[i] / unit_w); // degrees/h
			// accelerometer bias
			for (i = 12; i < 15; i++)
				fprintf(FileHandleErrorUKF, "%f\t", uKfParamTemp.Xes[i] / unit_ug); // ug
			fprintf(FileHandleErrorUKF, "\n");



			// Record square root of error variance
			fprintf(FileHandleVarUKF, "%f\t", Measurements.time);
			// tilt
			for (i = 0; i < 3; i++)
				fprintf(FileHandleVarUKF, "%f\t", uKfParamTemp.var_es[i] * unit_rad2degree);
			// velocity error
			for (i = 3; i < 6; i++)
				fprintf(FileHandleVarUKF, "%f\t", uKfParamTemp.var_es[i]);
			// latitude and longitude error
			for (i = 6; i < 8; i++)
				fprintf(FileHandleVarUKF, "%f\t", uKfParamTemp.var_es[i] * unit_rad2degree);
			// altitude error
			fprintf(FileHandleVarUKF, "%f\t", uKfParamTemp.var_es[8]);
			// gyroscope drift
			for (i = 9; i < 12; i++)
				fprintf(FileHandleVarUKF, "%f\t", uKfParamTemp.var_es[i] / unit_w); // degrees/h
			// accelerometer bias
			for (i = 12; i < 15; i++)
				fprintf(FileHandleVarUKF, "%f\t", uKfParamTemp.var_es[i] / unit_ug); // ug
			fprintf(FileHandleVarUKF, "\n");



			FlagSyncIMU = 0;
			FlagSyncGNSS = 0;
		} // Kalman Filter



		// Record KF results
		fprintf(FileHandleResultsUKF, "%f\t", Measurements.time);
		fprintf(FileHandleResultsUKF, "%f\t", NavParam.pitch * unit_rad2degree);
		fprintf(FileHandleResultsUKF, "%f\t", NavParam.roll * unit_rad2degree);
		fprintf(FileHandleResultsUKF, "%f\t", NavParam.yaw * unit_rad2degree);
		fprintf(FileHandleResultsUKF, "%f\t", NavParam.v[0]);
		fprintf(FileHandleResultsUKF, "%f\t", NavParam.v[1]);
		fprintf(FileHandleResultsUKF, "%f\t", NavParam.v[2]);
		fprintf(FileHandleResultsUKF, "%f\t", NavParam.la * unit_rad2degree);
		fprintf(FileHandleResultsUKF, "%f\t", NavParam.lon * unit_rad2degree);
		fprintf(FileHandleResultsUKF, "%f\n", NavParam.h);
#endif






#if FUSION_TYPE != 0
		// Get new IMU data
		if (TimeNext > TimeIMU[1])
		{
			TimeIMU[0] = TimeIMU[1];
			wibb[0][0] = wibb[0][1];
			wibb[1][0] = wibb[1][1];
			wibb[2][0] = wibb[2][1];
			fb[0][0] = fb[0][1];
			fb[1][0] = fb[1][1];
			fb[2][0] = fb[2][1];

			GetDataIMU();
		}
		


		// Get new PPS time
		if (FlagEndPPS == 0)
		{
			while ((FlagEndPPS == 0) && (TimePPS < TimeIMU[0]))
			{
				GetDataPPS();
			}

			if ((FlagEndPPS == 0) && (TimePPS > TimeIMU[0]) && (TimePPS < TimeIMU[1]))
			{
				FlagSyncIMU = 1;
			}
			else
			{
				FlagSyncIMU = 0;
			}

		}


		// Get new GNSS data
		if (FlagEndGNSS == 0)
		{
			while ((FlagEndGNSS == 0) && (TimeGNSS <= TimePPS))
			{
				GetDataGNSS();
			}
			if ((FlagEndGNSS == 0) && (TimeGNSS > TimePPS))
			{
				FlagSyncGNSS = 0;

				// GNSS receiver has got satellite
				if (GnssNavParam.svNumber > 0)
					FlagSyncGNSS = 2;

				// GNSS receiver has been positioned
				if (GnssNavParam.fixQuality > 0)
					FlagSyncGNSS = 1;
			}
		}
#else
		GetDataIMU();
#endif




		// Data refresh
		NavParam = NavParamTemp;
		countLength++;

	} // while (FlagEndIMU == 0)

	




	

	//*****************************  Close file handle  ********************************//
	fclose(FileHandleIMU);
	fclose(FileHandleGNSS);
	fclose(FileHandlePPS);
#if FUSION_TYPE == 0
	fclose(FileHandleResultsSINS);
#endif
#if FUSION_TYPE == 1
	fclose(FileHandleResultsKF);
	fclose(FileHandleErrorKF);
	fclose(FileHandleVarKF);
	fclose(FileHandleResultsGNSS);
#endif
#if FUSION_TYPE == 2
	fclose(FileHandleResultsUKF);
	fclose(FileHandleErrorUKF);
	fclose(FileHandleVarUKF);
	fclose(FileHandleResultsGNSS2);
#endif

	
	

	printf("\n******** End. ********\n");
	printf("Data length: %d\n", countLength);
	getchar();

	return 0;
}




