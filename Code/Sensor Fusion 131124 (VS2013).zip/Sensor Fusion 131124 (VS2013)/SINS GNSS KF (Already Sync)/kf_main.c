#include <stdio.h>
#include <stdlib.h>

#include "kf_main.h"
#include "../sins_gnss_kf.h"

#define LENGTH_ACCUM_TIME	(5 * 60)
#define	RELAY_BEFORE_FEEDBACK_CORRECTION	(0 * 60)

IMU_ERROR_PARAM imuErrorParam =
{
	// Gyroscope drift (rad/s)
	0.008 * unit_w,
	0.008 * unit_w,
	0.008 * unit_w,

	// Gyroscope white Gauss noise MSE (rad/s)
	0.01 * unit_w,
	0.01 * unit_w,
	0.01 * unit_w,

	// Accelerometer bias (m/s^2)
	50 * unit_ug,
	50 * unit_ug,
	50 * unit_ug,

	// Accelerometer white Gauss noise MSE (rad/s)
	100 * unit_ug,
	100 * unit_ug,
	100 * unit_ug
};

GNSS_ERROR_PARAM gnssErrorParam =
{
	// GNSS position error (m)
	0.1,
	0.1,
	0.1,

	// GNSS velocity error (m/s)
	0.01,
	0.01,
	0.01,

	// Pseudorage noise variance MSE (m)
	10,

	// Pseudorage rate noise variance MSE (m/s)
	0.1,

	// Timer drift caused velocity noise variance MSE (m/s)
	0.1,

	// Timer drift caused position error (m)
	100,

	// Timer frequency drift caused velocity error (m/s)
	300,

	// Timer drift correlation time
	1e+9
};

INS_INIT_PARAM insInitParam = 
{
	100,
	0.01,

	(0 / unit_rad2degree),
	(0 / unit_rad2degree),
	(0 / unit_rad2degree), 

	0,
	0,
	0,

	(40.0211142228246 / unit_rad2degree),
	(116.3703629769560 / unit_rad2degree),
	43.0674
};

KF_INIT_PARAM kfInitParam =
{
	0,
	{0},
	{0}
};


/**
  *	main entrance
  */
int main() {
	int i, j;

	int countLength;

	int flagGNSSEnd = 0;

	double accum_w[3] = { 0, 0, 0 };
	double accum_f[3] = { 0, 0, 0 };

	char temp_char[30] = { 0 };

	double Ctp[3][3] = { 0 };

	double CtbTemp[3][3] = { 0 };

	double Ctb[3][3] = { 0 };

	double quaternionNorm = 0;

	INS_MEASUREMENT measurements;

	INS_NAV_PARAM NavParamOld, NavParamNew;

	GNSS_NAV_PARAM gnssNavParam;

	KF_PARAM kfParam, kfParamTemp;

	FILE *fpIMU = NULL, *fpGNSS = NULL, *fpResults = NULL, *fpError = NULL, *fpVar = NULL;


	kfInitParam.T = 0.01;
	kfInitParam.mx0[0] = 0.003 / unit_rad2degree;
	kfInitParam.mx0[1] = 0.003 / unit_rad2degree;
	kfInitParam.mx0[2] = 0.003 / unit_rad2degree;

	kfInitParam.mx0[9] = imuErrorParam.gyroDrift[0];
	kfInitParam.mx0[10] = imuErrorParam.gyroDrift[1];
	kfInitParam.mx0[11] = imuErrorParam.gyroDrift[2];

	kfInitParam.mx0[12] = imuErrorParam.accBias[0];
	kfInitParam.mx0[13] = imuErrorParam.accBias[1];
	kfInitParam.mx0[14] = imuErrorParam.accBias[2];

	for (i = 0; i < 15; i++)
		kfInitParam.Cx0[i][i] = 1e-2;


	// Measurements IMU
	if ((fpIMU = fopen("../../Data/already sync/imu_1h.dat", "r")) == NULL) {
		printf("IMU measurements fopen error!\n");
		getchar();
		return 1;
	}

	// Measurements GNSS
	if ((fpGNSS = fopen("../../Data/already sync/gps_1h.dat", "r")) == NULL) {
		printf("GNSS measurements fopen error!\n");
		getchar();
		return 1;
	}

	// Results
	if ((fpResults = fopen("../../Data/already sync/already_sync_kf.dat", "w")) == NULL) {
		printf("Results fopen error!\n");
		getchar();
		return 1;
	}

	// Kalman filter error record
	if ((fpError = fopen("../../Data/already sync/already_sync_es.dat", "w")) == NULL) {
		printf("Error record fopen error!\n");
		getchar();
		return 1;
	}

	// Kalman filter square root of error variance
	if ((fpVar = fopen("../../Data/already sync/already_sync_var.dat", "w")) == NULL) {
		printf("Error record fopen error!\n");
		getchar();
		return 1;
	}


	// Accumulate 5 min IMU data
	for (j = 0; j < (int)(LENGTH_ACCUM_TIME * insInitParam.sampling_rate); j++) {
		fscanf(fpIMU, "%s", temp_char);
		if (feof(fpIMU))
		{
			printf("Data length is not enough!\n");
			getchar();
			return 1;
		}
			

		// UTC time of INS 
		fscanf(fpIMU, "%s", temp_char);
		measurements.time = atof(temp_char);

		// Rotation rate (degrees/h to rad/s)
		for (i = 0; i < 3; i++) {
			fscanf(fpIMU, "%s", temp_char);
			measurements.w[i] = atof(temp_char) * unit_w;
		}

		// Acceleration (g to m/s^2)
		for (i = 0; i < 3; i++) {
			fscanf(fpIMU, "%s", temp_char);
			measurements.f[i] = atof(temp_char) * g0;
		}
		accum_w[0] += measurements.w[0];
		accum_w[1] += measurements.w[1];
		accum_w[2] += measurements.w[2];
		accum_f[0] += measurements.f[0];
		accum_f[1] += measurements.f[1];
		accum_f[2] += measurements.f[2];
	}
	measurements.w[0] = accum_w[0] / (LENGTH_ACCUM_TIME * insInitParam.sampling_rate);
	measurements.w[1] = accum_w[1] / (LENGTH_ACCUM_TIME * insInitParam.sampling_rate);
	measurements.w[2] = accum_w[2] / (LENGTH_ACCUM_TIME * insInitParam.sampling_rate);
	measurements.f[0] = accum_f[0] / (LENGTH_ACCUM_TIME * insInitParam.sampling_rate);
	measurements.f[1] = accum_f[1] / (LENGTH_ACCUM_TIME * insInitParam.sampling_rate);
	measurements.f[2] = accum_f[2] / (LENGTH_ACCUM_TIME * insInitParam.sampling_rate);

	// Get initial navigation parameters by coarse-alignment
	NavParamOld = sinsCoarseAlignment(measurements, insInitParam);

	printf("Coarse alignment result:\n");
	printf("\tpitch_align = %f\n", NavParamOld.pitch * unit_rad2degree);
	printf("\troll_align = %f\n", NavParamOld.roll * unit_rad2degree);
	printf("\tyaw_align = %f\n", NavParamOld.yaw * unit_rad2degree);


	// Kalman filter initialization
	kfParamTemp = kfInit(kfInitParam);


	// Strapdown algorithm
	i = 0;
	countLength = 0;
	while (1) {
		// ******** IMU data ******** //
		fscanf(fpIMU, "%s", temp_char);
		measurements.time = atof(temp_char);

		// UTC time of INS 
		fscanf(fpIMU, "%s", temp_char);
		measurements.time = (feof(fpIMU) != 0) ? (measurements.time + 1000 * insInitParam.time_interval) : atof(temp_char);


		// Rotation rate (degrees/h to rad/s)
		for (i = 0; i < 3; i++) {
			fscanf(fpIMU, "%s", temp_char);
			measurements.w[i] = atof(temp_char) * unit_w;
		}

		// Acceleration (g to m/s^2)
		for (i = 0; i < 3; i++) {
			fscanf(fpIMU, "%s", temp_char);
			measurements.f[i] = atof(temp_char) * g0;
		}

		// break condition
		countLength ++;
		//if ((feof(fpIMU)) || (countLength == 5))
		if (feof(fpIMU))
			break;

		// Strapdown refresh
		NavParamNew = sinsStrapdown(measurements, NavParamOld, HEIGHT_UNUSED);


		if (flagGNSSEnd == 0)
		{
			// Time synchronize of IMU and GNSS data
			do
			{
				// ******** GNSS data ******** //
				fscanf(fpGNSS, "%s", temp_char);

				// UTC time of GNSS 
				fscanf(fpGNSS, "%s", temp_char);
				gnssNavParam.time = atof(temp_char);

				// Latitude (rad)
				fscanf(fpGNSS, "%s", temp_char);
				gnssNavParam.la = atof(temp_char) / unit_rad2degree;

				// Longitude
				fscanf(fpGNSS, "%s", temp_char);
				gnssNavParam.lon = atof(temp_char) / unit_rad2degree;

				// Altitude
				fscanf(fpGNSS, "%s", temp_char);
				gnssNavParam.alt = atof(temp_char);

				// Velocity (E-N-U)
				for (i = 0; i < 3; i++) {
					fscanf(fpGNSS, "%s", temp_char);
					gnssNavParam.v_enu[i] = atof(temp_char);
				}

				// GNSS data end flag
				if (feof(fpGNSS))
				{
					flagGNSSEnd = 1;
					break;
				}
			} while (gnssNavParam.time < measurements.time);



			// Kalman filtering and result correct
			if (gnssNavParam.time == measurements.time)
			{
				// Kalman filtering
				kfParamTemp = kf(kfParamTemp, NavParamOld, gnssNavParam, measurements, imuErrorParam, gnssErrorParam);

				// Tilt correct matrix
				Ctp[0][0] = 1;
				Ctp[1][0] = kfParamTemp.Xes[2];
				Ctp[2][0] = -kfParamTemp.Xes[1];

				Ctp[0][1] = -kfParamTemp.Xes[2];
				Ctp[1][1] = 1;
				Ctp[2][1] = kfParamTemp.Xes[0];

				Ctp[0][2] = kfParamTemp.Xes[1];
				Ctp[1][2] = -kfParamTemp.Xes[0];
				Ctp[2][2] = 1;

				// Feedback correction
				if (countLength > RELAY_BEFORE_FEEDBACK_CORRECTION * insInitParam.sampling_rate)
				{
					// Ctb = Ctb * Cct
					//matMul(Ctb, 3, 3, NavParamNew.Ctb, 3, 3, Ctp, 3, 3);
					for (i = 0; i < 3; i ++)
					for (j = 0; j < 3; j++)
					Ctb[i][j] = NavParamNew.Ctb[i][j];


					/*NavParamNew.Qua[0] = sqrt(1 + Ctb[0][0] + Ctb[1][1] + Ctb[2][2]) / 2;
					NavParamNew.Qua[1] = (Ctb[1][2] - Ctb[2][1]) / (4 * NavParamNew.Qua[0]);
					NavParamNew.Qua[2] = (Ctb[2][0] - Ctb[0][2]) / (4 * NavParamNew.Qua[0]);
					NavParamNew.Qua[3] = (Ctb[0][1] - Ctb[1][0]) / (4 * NavParamNew.Qua[0]);

					quaternionNorm = 0;
					for (i = 0; i < 4; i++)
					{
						quaternionNorm += NavParamNew.Qua[i] * NavParamNew.Qua[i];
					}
					quaternionNorm = sqrt(quaternionNorm);
					for (i = 0; i < 4; i++)
					{
						NavParamNew.Qua[i] /= quaternionNorm;
					}*/



					// Correct velocity
					NavParamNew.v[0] = NavParamNew.v[0] - kfParamTemp.Xes[3];
					NavParamNew.v[1] = NavParamNew.v[1] - kfParamTemp.Xes[4];
					NavParamNew.v[2] = NavParamNew.v[2] - kfParamTemp.Xes[5];

					// Correct position
					NavParamNew.la = NavParamNew.la - kfParamTemp.Xes[6];
					NavParamNew.lon = NavParamNew.lon - kfParamTemp.Xes[7];
					NavParamNew.alt = NavParamNew.alt - kfParamTemp.Xes[8];
				}
				// Output correction
				else
				{
					printf("Output correct...\n");

					matMul(CtbTemp, 3, 3, NavParamNew.Ctb, 3, 3, Ctp, 3, 3);

					// Correct attitude
					NavParamOld.pitch = asin(CtbTemp[1][2]); // -pi/2 to pi/2

					NavParamOld.roll = atan2(-CtbTemp[0][2], CtbTemp[2][2]); // -pi to pi

					NavParamOld.yaw = atan2(CtbTemp[1][0], CtbTemp[1][1]); // 0 to 2*pi
					if (NavParamOld.yaw < 0)
						NavParamOld.yaw += 2 * pi;

					// Correct velocity
					NavParamOld.v[0] = NavParamOld.v[0] - kfParamTemp.Xes[3];
					NavParamOld.v[1] = NavParamOld.v[1] - kfParamTemp.Xes[4];
					NavParamOld.v[2] = NavParamOld.v[2] - kfParamTemp.Xes[5];

					// Correct position
					NavParamOld.la = NavParamOld.la - kfParamTemp.Xes[6];
					NavParamOld.lon = NavParamOld.lon - kfParamTemp.Xes[7];
					NavParamOld.alt = NavParamOld.alt - kfParamTemp.Xes[8];
				}
			

				// Record error
				fprintf(fpError, "%f\t", measurements.time);
				// tilt
				for (i = 0; i < 3; i ++)
					fprintf(fpError, "%f\t", kfParamTemp.Xes[i] * unit_rad2degree);
				// velocity error
				for (i = 3; i < 6; i++)
					fprintf(fpError, "%f\t", kfParamTemp.Xes[i]);
				// latitude and longitude error
				for (i = 6; i < 8; i++)
					fprintf(fpError, "%f\t", kfParamTemp.Xes[i] * unit_rad2degree);
				// altitude error
				fprintf(fpError, "%f\t", kfParamTemp.Xes[8]);
				// gyroscope drift
				for (i = 9; i < 12; i++)
					fprintf(fpError, "%f\t", kfParamTemp.Xes[i] / unit_w); // degrees/h
				// accelerometer bias
				for (i = 12; i < 15; i++)
					fprintf(fpError, "%f\t", kfParamTemp.Xes[i] / unit_ug); // ug
				fprintf(fpError, "\n");



				// Record square root of error variance
				fprintf(fpVar, "%f\t", measurements.time);
				// tilt
				for (i = 0; i < 3; i++)
					fprintf(fpVar, "%f\t", sqrt(kfParamTemp.Pes[i][i]) * unit_rad2degree);
				// velocity error
				for (i = 3; i < 6; i++)
					fprintf(fpVar, "%f\t", sqrt(kfParamTemp.Pes[i][i]));
				// latitude and longitude error
				for (i = 6; i < 8; i++)
					fprintf(fpVar, "%f\t", sqrt(kfParamTemp.Pes[i][i]) * unit_rad2degree);
				// altitude error
				fprintf(fpVar, "%f\t", sqrt(kfParamTemp.Pes[8][8]));
				// gyroscope drift
				for (i = 9; i < 12; i++)
					fprintf(fpVar, "%f\t", sqrt(kfParamTemp.Pes[i][i]) / unit_w); // degrees/h
				// accelerometer bias
				for (i = 12; i < 15; i++)
					fprintf(fpVar, "%f\t", sqrt(kfParamTemp.Pes[i][i]) / unit_ug); // ug
				fprintf(fpVar, "\n");
			}


		} // if (gnssNavParam.time == measurements.time)



		// Record result
		fprintf(fpResults, "%f\t", measurements.time);

		fprintf(fpResults, "%f\t", NavParamOld.pitch * unit_rad2degree);
		fprintf(fpResults, "%f\t", NavParamOld.roll * unit_rad2degree);
		fprintf(fpResults, "%f\t", NavParamOld.yaw * unit_rad2degree);

		fprintf(fpResults, "%f\t", NavParamOld.v[0]);
		fprintf(fpResults, "%f\t", NavParamOld.v[1]);
		fprintf(fpResults, "%f\t", NavParamOld.v[2]);

		fprintf(fpResults, "%f\t", NavParamOld.la * unit_rad2degree);
		fprintf(fpResults, "%f\t", NavParamOld.lon * unit_rad2degree);
		fprintf(fpResults, "%f\t", NavParamOld.alt);
		fprintf(fpResults, "\n");

		// Data refresh
		NavParamOld = NavParamNew;
	} // while

	fclose(fpIMU);
	fclose(fpGNSS);
	fclose(fpResults);
	fclose(fpError);
	fclose(fpVar);

	printf("Data length: %d\n", countLength);
	printf("End of SINS/GNSS KF calculation.\n");
	getchar();

	return 0;
}

