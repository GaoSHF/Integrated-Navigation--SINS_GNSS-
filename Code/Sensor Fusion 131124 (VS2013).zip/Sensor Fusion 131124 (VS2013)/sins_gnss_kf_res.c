#include "sins_gnss_kf_res.h"



/*
SINS GNSS tightly coupled EKF
*/
KF_PARAM ekf(KF_PARAM ekfParamOld,
	INS_NAV_PARAM sinsNavParam,
	GNSS_NAV_PARAM gnssNavParam,
	INS_MEASUREMENT measurements,
	IMU_ERROR_PARAM imuErrorParam,
	GNSS_ERROR_PARAM gnssErrorParam)
{
	KF_PARAM ekfParamNew = ekfParamOld;

	int i, j;

	double eye17[17][17] = { 0 };
	for (i = 0; i < 17; i++)
		eye17[i][i] = 1;

	double temp17x17_1[17][17] = { 0 };
	double temp17x17_2[17][17] = { 0 };
	double temp17x17_3[17][17] = { 0 };

	double temp17x2n_Htrans[17][2 * RECEIVER_CHANNEL] = { 0 };
	double temp17x2n[17][2 * RECEIVER_CHANNEL] = { 0 };

	double temp7x17[7][17] = { 0 };
	double temp2nx17[2 * RECEIVER_CHANNEL][17] = { 0 };

	double temp2nx2n[2 * RECEIVER_CHANNEL][2 * RECEIVER_CHANNEL] = { 0 };

	double temp2nx1[2 * RECEIVER_CHANNEL] = { 0 };

	double temp17x1[17] = { 0 };


	// Radius of meridian plane and prime plane
	double Rm, Rn;

	// Measurement matrix
	double Z[2 * RECEIVER_CHANNEL] = { 0 };

	// State transfer matrix (Continus)
	double F[17][17] = { 0 };

	// State transfer matrix (Descrete)
	double Phi[17][17] = { 0 };

	// Error variance transfer matrix (Continus)
	double G[17][7] = { 0 };

	// Error variance transfer matrix (Descrete)
	double Ka[17][7] = { 0 };

	// System error variance
	double Q[7][7] = { 0 };

	// Measurement matrix
	double H[2 * RECEIVER_CHANNEL][17] = { 0 };

	// Measurement error variance
	double R[2 * RECEIVER_CHANNEL][2 * RECEIVER_CHANNEL] = { 0 };

	// One step estimation
	double XesOneStep[17] = { 0 };

	// One step estimation variance
	double PesOneStep[17][17] = { 0 };

	// Kalman gain
	double K[17][2 * RECEIVER_CHANNEL] = { 0 };



	int svNumber = 0;



	// From la-lon-h to x-y-z
	double Cne[3][3] = { 0 };
	double Cet[3][3] = { 0 };
	double Cte[3][3] = { 0 };

	double E[RECEIVER_CHANNEL][3] = { 0 };
	double M[RECEIVER_CHANNEL][3] = { 0 };
	double N[3][3] = { 0 };
	double N1[3][3] = { 0 };
	double N2[3][3] = { 0 };

	double pseudorangeSINS = 0;
	double pseudorangeRateSINS = 0;

	double positionSINS[3] = { 0 };
	double vxyzSINS[3] = { 0 };
	double venuSINS[3] = { 0 };

	double ex2 = 0;
	double RN = 0;

	double ECne[RECEIVER_CHANNEL][3] = { 0 };
	double EN[RECEIVER_CHANNEL][3] = { 0 };
	double MCne[RECEIVER_CHANNEL][3] = { 0 };
	double MCne_EN[RECEIVER_CHANNEL][3] = { 0 };
	double ECte[RECEIVER_CHANNEL][3] = { 0 };

	double tempZ[2 * RECEIVER_CHANNEL] = { 0 };




	svNumber = gnssNavParam.svNumber;


	Rm = Re / (1 + 2 * e - 3 * e * sin(sinsNavParam.la * sinsNavParam.la)) + sinsNavParam.alt;
	Rn = Re / (1 - e * sin(sinsNavParam.la * sinsNavParam.la)) + sinsNavParam.alt;





	// Error transfer: From nav error to nav error
	F[0][1] = (wie * sin(sinsNavParam.la) + sinsNavParam.v[0] / Rn * tan(sinsNavParam.la));
	F[0][2] = -(wie * cos(sinsNavParam.la) + sinsNavParam.v[0] / Rn);
	F[0][4] = -(1 / Rm);

	F[1][0] = -(wie * sin(sinsNavParam.la) + sinsNavParam.v[0] / Rn * tan(sinsNavParam.la));
	F[1][2] = -sinsNavParam.v[1] / Rm;
	F[1][3] = 1 / Rn;
	F[1][6] = -wie * sin(sinsNavParam.la);

	F[2][0] = (wie * cos(sinsNavParam.la) + sinsNavParam.v[0] / Rn);
	F[2][1] = sinsNavParam.v[1] / Rm;
	F[2][3] = 1 / Rn * tan(sinsNavParam.la);
	F[2][6] = (wie * cos(sinsNavParam.la) + sinsNavParam.v[0] / (Rn * cos(sinsNavParam.la) * cos(sinsNavParam.la)));

	F[3][1] = -measurements.f[2];
	F[3][2] = measurements.f[1];
	F[3][3] = (sinsNavParam.v[1] / Rm * tan(sinsNavParam.la) - sinsNavParam.v[2] / Rm);
	F[3][4] = (2 * wie * sin(sinsNavParam.la) + sinsNavParam.v[0] / Rn);
	F[3][5] = (2 * wie * cos(sinsNavParam.la) + sinsNavParam.v[0] / Rn);
	F[3][6] = (2 * wie * cos(sinsNavParam.la) * sinsNavParam.v[1] + sinsNavParam.v[0] * sinsNavParam.v[1] / (Rn * cos(sinsNavParam.la) * cos(sinsNavParam.la)) + 2 * wie * sin(sinsNavParam.la) * sinsNavParam.v[2]);

	F[4][0] = measurements.f[2];
	F[4][2] = -measurements.f[0];
	F[4][3] = -2 * (wie * sin(sinsNavParam.la) + sinsNavParam.v[0] / Rn * tan(sinsNavParam.la));
	F[4][4] = -sinsNavParam.v[2] / Rm;
	F[4][5] = -sinsNavParam.v[1] / Rm;
	F[4][6] = -(2 * wie * cos(sinsNavParam.la) + sinsNavParam.v[0] / (Rn * cos(sinsNavParam.la) * cos(sinsNavParam.la))) * sinsNavParam.v[0];

	F[5][0] = -measurements.f[1];
	F[5][1] = measurements.f[0];
	F[5][3] = -2 * (wie * cos(sinsNavParam.la) + sinsNavParam.v[0] / Rn);
	F[5][5] = 2 * sinsNavParam.v[1] / Rm;
	F[5][6] = -2 * wie * sin(sinsNavParam.la) * sinsNavParam.v[0];

	F[6][4] = 1 / Rm;

	F[7][3] = 1 / (Rn * cos(sinsNavParam.la));
	F[7][6] = sinsNavParam.v[0] / (Rn * cos(sinsNavParam.la)) * tan(sinsNavParam.la);

	F[8][5] = 1;


	// Error transfer: From IMU error to nav error
	F[0][9] = 1;

	F[1][10] = 1;

	F[2][11] = 1;

	F[3][12] = 1;

	F[4][13] = 1;

	F[5][14] = 1;


	// Error transfer: From GNSS receiver error to GNSS receiver error
	F[15][16] = 1;
	F[16][16] = -1 / gnssErrorParam.timerDriftCorreTime;



	// Descrete the transfer matrix   Phi = eye(17) + F * T
	matConstantMul(Phi, ekfParamOld.T, F, 17, 17);
	matPlus(Phi, eye17, Phi, 17, 17);




	// System error variance
	Q[0][0] = imuErrorParam.gyroNoise[0] * imuErrorParam.gyroNoise[0];
	Q[1][1] = imuErrorParam.gyroNoise[1] * imuErrorParam.gyroNoise[1];
	Q[2][2] = imuErrorParam.gyroNoise[2] * imuErrorParam.gyroNoise[2];
	Q[3][3] = imuErrorParam.accNoise[0] * imuErrorParam.accNoise[0];
	Q[4][4] = imuErrorParam.accNoise[1] * imuErrorParam.accNoise[1];
	Q[5][5] = imuErrorParam.accNoise[2] * imuErrorParam.accNoise[2];
	Q[6][6] = gnssErrorParam.timerFrequencyDriftNoise * gnssErrorParam.timerFrequencyDriftNoise;

	// Error variance transfer 
	G[0][0] = sinsNavParam.Ctb[0][0];
	G[0][1] = sinsNavParam.Ctb[1][0];
	G[0][2] = sinsNavParam.Ctb[2][0];
	G[1][0] = sinsNavParam.Ctb[0][1];
	G[1][1] = sinsNavParam.Ctb[1][1];
	G[1][2] = sinsNavParam.Ctb[2][1];
	G[2][0] = sinsNavParam.Ctb[0][2];
	G[2][1] = sinsNavParam.Ctb[1][2];
	G[2][2] = sinsNavParam.Ctb[2][2];

	G[3][3] = sinsNavParam.Ctb[0][0];
	G[3][4] = sinsNavParam.Ctb[1][0];
	G[3][5] = sinsNavParam.Ctb[2][0];
	G[4][3] = sinsNavParam.Ctb[0][1];
	G[4][4] = sinsNavParam.Ctb[1][1];
	G[4][5] = sinsNavParam.Ctb[2][1];
	G[5][3] = sinsNavParam.Ctb[0][2];
	G[5][4] = sinsNavParam.Ctb[1][2];
	G[5][5] = sinsNavParam.Ctb[2][2];

	G[16][6] = 1;

	// Descrete matrix G     Ka = (eye(17) * T + F * T ^ 2 / 2) * G
	matConstantMul(temp17x17_1, (ekfParamOld.T / 2), F, 17, 17);
	matPlus(temp17x17_1, eye17, temp17x17_1, 17, 17);
	matConstantMul(temp17x17_1, ekfParamOld.T, temp17x17_1, 17, 17);
	matMul(Ka, 17, 7, temp17x17_1, 17, 17, G, 17, 7);





	// Transfer SINS delta la-lon-h to delta x-y-z
	Cne[0][0] = -(Rn + sinsNavParam.alt) * sin(sinsNavParam.la) * cos(sinsNavParam.lon);
	Cne[0][1] = -(Rn + sinsNavParam.alt) * cos(sinsNavParam.la) * sin(sinsNavParam.lon);
	Cne[0][2] = cos(sinsNavParam.la) * cos(sinsNavParam.lon);
	Cne[1][0] = -(Rn + sinsNavParam.alt) * sin(sinsNavParam.la) * sin(sinsNavParam.lon);
	Cne[1][1] = (Rn + sinsNavParam.alt) * cos(sinsNavParam.la) * cos(sinsNavParam.lon);
	Cne[1][2] = cos(sinsNavParam.la) * sin(sinsNavParam.lon);
	Cne[2][0] = (Rn * (1 - e * e) + sinsNavParam.alt) * cos(sinsNavParam.la);
	Cne[2][1] = 0;
	Cne[2][2] = sin(sinsNavParam.la);

	// Transfer SINS location to earth x-y-z
	ex2 = (2 - e) * e / ((1 - e) * (1 - e));
	RN = Re * sqrt(1 + ex2) / sqrt(1 + ex2 * cos(sinsNavParam.la) * cos(sinsNavParam.la));
	positionSINS[0] = (RN + sinsNavParam.alt) * cos(sinsNavParam.la) * cos(sinsNavParam.lon);
	positionSINS[1] = (RN + sinsNavParam.alt) * cos(sinsNavParam.la) * sin(sinsNavParam.lon);
	positionSINS[2] = ((1 - e) * (1 - e) * RN + sinsNavParam.alt) * sin(sinsNavParam.la);


	// Transfer SINS velocity from E-N-U to X-Y-Z
	/*Cte[0][0] = -sin(pi / 2 + sinsNavParam.lon);
	Cte[0][1] = -sin(pi / 2 - sinsNavParam.la) * cos(pi / 2 + sinsNavParam.lon);
	Cte[0][2] = cos(pi / 2 - sinsNavParam.la) * cos(pi / 2 + sinsNavParam.lon);
	Cte[1][0] = cos(pi / 2 + sinsNavParam.lon);
	Cte[1][1] = -sin(pi / 2 - sinsNavParam.la) * sin(pi / 2 + sinsNavParam.lon);
	Cte[1][2] = cos(pi / 2 - sinsNavParam.la) * sin(pi / 2 + sinsNavParam.lon);
	Cte[2][0] = 0;
	Cte[2][1] = cos(pi / 2 - sinsNavParam.la);
	Cte[2][2] = sin(pi / 2 - sinsNavParam.la);*/

	Cte[0][0] = cos(pi / 2 + sinsNavParam.lon);
	Cte[0][1] = sin(pi / 2 + sinsNavParam.lon);
	Cte[0][2] = 0;
	Cte[1][0] = -cos(pi / 2 - sinsNavParam.la) * sin(pi / 2 + sinsNavParam.lon);
	Cte[1][1] = cos(pi / 2 - sinsNavParam.la) * cos(pi / 2 + sinsNavParam.lon);
	Cte[1][2] = sin(pi / 2 - sinsNavParam.la);
	Cte[2][0] = sin(pi / 2 - sinsNavParam.la) * sin(pi / 2 + sinsNavParam.lon);
	Cte[2][1] = -sin(pi / 2 - sinsNavParam.la) * cos(pi / 2 + sinsNavParam.lon);
	Cte[2][2] = cos(pi / 2 - sinsNavParam.la);

	venuSINS[0] = sinsNavParam.v[0];
	venuSINS[1] = sinsNavParam.v[1];
	venuSINS[2] = sinsNavParam.v[2];

	matMul(vxyzSINS, 3, 1, Cte, 3, 3, venuSINS, 3, 1);

	for (i = 0; i < svNumber; i++)
	{

		// Measurements
		pseudorangeSINS = 0;
		pseudorangeSINS += (positionSINS[0] - gnssNavParam.channel[i].p_xyz[0]) * (positionSINS[0] - gnssNavParam.channel[i].p_xyz[0]);
		pseudorangeSINS += (positionSINS[1] - gnssNavParam.channel[i].p_xyz[1]) * (positionSINS[1] - gnssNavParam.channel[i].p_xyz[1]);
		pseudorangeSINS += (positionSINS[2] - gnssNavParam.channel[i].p_xyz[2]) * (positionSINS[2] - gnssNavParam.channel[i].p_xyz[2]);
		pseudorangeSINS = sqrt(pseudorangeSINS);
		Z[i] = pseudorangeSINS - gnssNavParam.channel[i].pseu;

		pseudorangeRateSINS = 0;
		pseudorangeRateSINS += (positionSINS[0] - gnssNavParam.channel[i].p_xyz[0]) * (vxyzSINS[0] - gnssNavParam.channel[i].v_xyz[0]);
		pseudorangeRateSINS += (positionSINS[1] - gnssNavParam.channel[i].p_xyz[1]) * (vxyzSINS[1] - gnssNavParam.channel[i].v_xyz[1]);
		pseudorangeRateSINS += (positionSINS[2] - gnssNavParam.channel[i].p_xyz[2]) * (vxyzSINS[2] - gnssNavParam.channel[i].v_xyz[2]);
		pseudorangeRateSINS /= pseudorangeSINS;
		Z[i + svNumber] = pseudorangeRateSINS - gnssNavParam.channel[i].pseuRate;


		E[i][0] = (positionSINS[0] - gnssNavParam.channel[i].p_xyz[0]) / pseudorangeSINS;
		E[i][1] = (positionSINS[1] - gnssNavParam.channel[i].p_xyz[1]) / pseudorangeSINS;
		E[i][2] = (positionSINS[2] - gnssNavParam.channel[i].p_xyz[2]) / pseudorangeSINS;

		M[i][0] = (vxyzSINS[0] - gnssNavParam.channel[i].v_xyz[0]) / pseudorangeSINS - pseudorangeRateSINS / (pseudorangeSINS * pseudorangeSINS) * (positionSINS[0] - gnssNavParam.channel[i].p_xyz[0]);
		M[i][1] = (vxyzSINS[1] - gnssNavParam.channel[i].v_xyz[1]) / pseudorangeSINS - pseudorangeRateSINS / (pseudorangeSINS * pseudorangeSINS) * (positionSINS[1] - gnssNavParam.channel[i].p_xyz[1]);
		M[i][2] = (vxyzSINS[2] - gnssNavParam.channel[i].v_xyz[2]) / pseudorangeSINS - pseudorangeRateSINS / (pseudorangeSINS * pseudorangeSINS) * (positionSINS[2] - gnssNavParam.channel[i].p_xyz[2]);

	}


	N1[0][0] = -sinsNavParam.v[1] * cos(sinsNavParam.la) * cos(sinsNavParam.lon) - sinsNavParam.v[2] * sin(sinsNavParam.la) * cos(sinsNavParam.lon);
	N1[0][1] = -sinsNavParam.v[0] * cos(sinsNavParam.lon) + sinsNavParam.v[1] * sin(sinsNavParam.la) * sin(sinsNavParam.lon) - sinsNavParam.v[2] * cos(sinsNavParam.la) * sin(sinsNavParam.lon);
	N1[0][2] = 0;
	N1[1][0] = -sinsNavParam.v[1] * cos(sinsNavParam.la) * sin(sinsNavParam.lon) - sinsNavParam.v[2] * sin(sinsNavParam.la) * sin(sinsNavParam.lon);
	N1[2][1] = -sinsNavParam.v[0] * sin(sinsNavParam.lon) - sinsNavParam.v[1] * sin(sinsNavParam.la) * cos(sinsNavParam.lon) + sinsNavParam.v[2] * cos(sinsNavParam.la) * cos(sinsNavParam.lon);
	N1[1][2] = 0;
	N1[2][0] = -sinsNavParam.v[1] * sin(sinsNavParam.la) + sinsNavParam.v[2] * cos(sinsNavParam.la);
	N1[2][1] = 0;
	N1[2][2] = 0;

	N2[0][0] = 0;
	N2[0][1] = 1 / (Rm + sinsNavParam.alt);
	N2[0][2] = 0;
	N2[1][0] = 1 / ((Rm + sinsNavParam.alt) * cos(sinsNavParam.la));
	N2[1][1] = 0;
	N2[1][2] = 0;
	N2[2][0] = 0;
	N2[2][1] = 0;
	N2[2][2] = 1;

	matMul(N, 3, 3, N1, 3, 3, N2, 3, 3);
	matMul(EN, svNumber, 3, E, svNumber, 3, N, 3, 3);

	matMul(MCne, svNumber, 3, M, svNumber, 3, Cne, 3, 3);

	matPlus(MCne_EN, MCne, EN, svNumber, 3);

	matMul(ECne, svNumber, 3, E, svNumber, 3, Cne, 3, 3);
	matMul(ECte, svNumber, 3, E, svNumber, 3, Cte, 3, 3);

	// Measurement matrix
	for (i = 0; i < svNumber; i++)
	{
		H[i][6] = ECne[i][0];
		H[i][7] = ECne[i][1];
		H[i][8] = ECne[i][2];
		H[i][15] = 1;

		H[i + svNumber][3] = ECte[i][0];
		H[i + svNumber][4] = ECte[i][1];
		H[i + svNumber][5] = ECte[i][2];
		//H[i + svNumber][6] = MCne[i][0];
		//H[i + svNumber][7] = MCne[i][1];
		//H[i + svNumber][8] = MCne[i][2];
		H[i + svNumber][16] = 1;
	}





	// Measurement error covariance
	for (i = 0; i < svNumber; i++)
	{
		*(*(R)+i * 2 * svNumber + i) = gnssErrorParam.pseuNoise * gnssErrorParam.pseuNoise;
		*(*(R)+(i + svNumber) * 2 * svNumber + i + svNumber) = gnssErrorParam.pseuRateNoise * gnssErrorParam.pseuRateNoise;
	}





	//******** EKF algorithm ********//
	// One step estimation XesOneStep = Phi * Xes
	matMul(XesOneStep, 17, 1, Phi, 17, 17, ekfParamOld.Xes, 17, 1);

	// One step estimation variance PesOneStep = Phi * Pes * Phi' + Ka * Q * Ka'
	matTranspose(temp17x17_1, Phi, 17, 17);
	matMul(temp17x17_1, 17, 17, ekfParamOld.Pes, 17, 17, temp17x17_1, 17, 17);
	matMul(temp17x17_1, 17, 17, Phi, 17, 17, temp17x17_1, 17, 17);

	matTranspose(temp7x17, Ka, 7, 17);
	matMul(temp7x17, 7, 17, Q, 7, 7, temp7x17, 7, 17);
	matMul(temp17x17_2, 17, 17, Ka, 17, 7, temp7x17, 7, 17);

	matPlus(PesOneStep, temp17x17_1, temp17x17_2, 17, 17);

	// Kalman gain K = PesOneStep * H' / (H * PesOneStep * H' + R)
	matTranspose(temp17x2n_Htrans, H, 17, (2 * svNumber));

	matMul(temp17x2n, 17, (2 * svNumber), PesOneStep, 17, 17, temp17x2n_Htrans, 17, (2 * svNumber));
	matMul(temp2nx2n, (2 * svNumber), (2 * svNumber), H, (2 * svNumber), 17, temp17x2n, 17, (2 * svNumber));
	matPlus(temp2nx2n, R, temp2nx2n, (2 * svNumber), (2 * svNumber));
	matInv(temp2nx2n, temp2nx2n, (2 * svNumber));

	matMul(K, 17, (2 * svNumber), temp17x2n, 17, (2 * svNumber), temp2nx2n, (2 * svNumber), (2 * svNumber));

	// Estimation Xes = XesOneStep + K * (Z - H * XesOneStep)
	matMul(temp2nx1, (2 * svNumber), 1, H, (2 * svNumber), 17, XesOneStep, 17, 1);

	matMinus(temp2nx1, Z, temp2nx1, (2 * svNumber), 1);

	matMul(temp17x1, 17, 1, K, 17, (2 * svNumber), temp2nx1, (2 * svNumber), 1);

	matPlus(ekfParamNew.Xes, XesOneStep, temp17x1, 17, 1);


	// Estimation variance Pes = (eye(17) - K * H) * PesOneStep * (eye(17) - K * H)' + K * R * K'
	matTranspose(temp2nx17, K, (2 * svNumber), 17);
	matMul(temp2nx17, (2 * svNumber), 17, R, (2 * svNumber), (2 * svNumber), temp2nx17, (2 * svNumber), 17);
	matMul(temp17x17_1, 17, 17, K, 17, (2 * svNumber), temp2nx17, (2 * svNumber), 17);

	matMul(temp17x17_2, 17, 17, K, 17, (2 * svNumber), H, (2 * svNumber), 17);
	matMinus(temp17x17_2, eye17, temp17x17_2, 17, 17);
	matTranspose(temp17x17_3, temp17x17_2, 17, 17);
	matMul(temp17x17_3, 17, 17, PesOneStep, 17, 17, temp17x17_3, 17, 17);
	matMul(temp17x17_2, 17, 17, temp17x17_2, 17, 17, temp17x17_3, 17, 17);

	matPlus(ekfParamNew.Pes, temp17x17_2, temp17x17_1, 17, 17);




	return ekfParamNew;
}





/*
SINS GNSS tightly coupled Square Root UKF
*/
KF_PARAM srukf(KF_PARAM ukfParamOld,
	INS_NAV_PARAM sinsNavParam,
	GNSS_NAV_PARAM gnssNavParam,
	INS_MEASUREMENT measurements,
	IMU_ERROR_PARAM imuErrorParam,
	GNSS_ERROR_PARAM gnssErrorParam)
{
	KF_PARAM ukfParamNew = ukfParamOld;

	INS_NAV_PARAM sinsNavParamTemp;

	int svNumber = gnssNavParam.svNumber;

	int i, j;

	double eye17[17][17] = { 0 };
	for (i = 0; i < 17; i++)
		eye17[i][i] = 1;

	double temp17x17[17][17] = { 0 };

	double temp17x7[17][7] = { 0 };
	double temp7x17[7][17] = { 0 };

	double temp17x1[17] = { 0 };

	double temp1x17[17] = { 0 };

	double tempZ[2 * RECEIVER_CHANNEL] = { 0 };
	double tempZtrans[2 * RECEIVER_CHANNEL] = { 0 };
	double tempZZtrans[2 * RECEIVER_CHANNEL][2 * RECEIVER_CHANNEL] = { 0 };

	double tempXZtrans[17][2 * RECEIVER_CHANNEL] = { 0 };







	// Radius of meridian plane and prime plane
	double Rm, Rn;

	// Measurement matrix
	double Z[2 * RECEIVER_CHANNEL] = { 0 };

	// State transfer matrix (Continus)
	double F[17][17] = { 0 };

	// State transfer matrix (Descrete)
	double Phi[17][17] = { 0 };

	// Error variance transfer matrix (Continus)
	double G[17][7] = { 0 };

	// Error variance transfer matrix (Descrete)
	double Ka[17][7] = { 0 };

	// System error variance
	double Q[7][7] = { 0 };

	// Measurement error variance
	double R[2 * RECEIVER_CHANNEL][2 * RECEIVER_CHANNEL] = { 0 };

	// One step estimation
	double XesOneStep[17] = { 0 };

	// One step estimation variance
	double PesOneStep[17][17] = { 0 };

	// Kalman gain
	double K[17][2 * RECEIVER_CHANNEL] = { 0 };

	double Ktrans[2 * RECEIVER_CHANNEL][17] = { 0 };


	//******** UKF parameters ********//
	double lamda = 0;
	double alpha = 0;
	double beta = 0;
	double ka = 0;

	double weight[2 * 17 + 1] = { 0 };

	double XesSigma[(2 * 17 + 1) * 17] = { 0 };

	double XesOneStepSigma[(2 * 17 + 1) * 17] = { 0 };

	double ZesOneStepSigma[(2 * 17 + 1) * 2 * RECEIVER_CHANNEL] = { 0 };

	double ZesOneStep[2 * RECEIVER_CHANNEL] = { 0 };

	double PzesOneStep[2 * RECEIVER_CHANNEL][2 * RECEIVER_CHANNEL] = { 0 };

	double PxzesOneStep[17][2 * RECEIVER_CHANNEL] = { 0 };

	double PzInv[2 * RECEIVER_CHANNEL][2 * RECEIVER_CHANNEL] = { 0 };


	double upperTriMatrix[17][17] = { 0 };


	// Square root parameter
	double SesOneStep[17][17] = { 0 };
	double SzesOneStep[2 * RECEIVER_CHANNEL][2 * RECEIVER_CHANNEL] = { 0 };
	double SzesOneStepInv[2 * RECEIVER_CHANNEL][2 * RECEIVER_CHANNEL] = { 0 };
	double SzesOneStepTrans[2 * RECEIVER_CHANNEL][2 * RECEIVER_CHANNEL] = { 0 };
	double SzesOneStepTransInv[2 * RECEIVER_CHANNEL][2 * RECEIVER_CHANNEL] = { 0 };
	double Ses[17][17] = { 0 };
	double SesTrans[17][17] = { 0 };
	double KSzes[17][2 * RECEIVER_CHANNEL] = { 0 };

	double SQ[7][7] = { 0 };
	double SR[2 * RECEIVER_CHANNEL][2 * RECEIVER_CHANNEL] = { 0 };

	double Bk[2 * 17 + 7][17] = { 0 };
	double Ck[2 * 17 + 2 * RECEIVER_CHANNEL][2 * RECEIVER_CHANNEL] = { 0 };

	double cholupdateX[17] = { 0 };
	double cholupdateZ[2 * RECEIVER_CHANNEL] = { 0 };




	Rm = Re / (1 + 2 * e - 3 * e * sin(sinsNavParam.la * sinsNavParam.la)) + sinsNavParam.alt;
	Rn = Re / (1 - e * sin(sinsNavParam.la * sinsNavParam.la)) + sinsNavParam.alt;





	// Error transfer: From nav error to nav error
	F[0][1] = (wie * sin(sinsNavParam.la) + sinsNavParam.v[0] / Rn * tan(sinsNavParam.la));
	F[0][2] = -(wie * cos(sinsNavParam.la) + sinsNavParam.v[0] / Rn);
	F[0][4] = -(1 / Rm);

	F[1][0] = -(wie * sin(sinsNavParam.la) + sinsNavParam.v[0] / Rn * tan(sinsNavParam.la));
	F[1][2] = -sinsNavParam.v[1] / Rm;
	F[1][3] = 1 / Rn;
	F[1][6] = -wie * sin(sinsNavParam.la);

	F[2][0] = (wie * cos(sinsNavParam.la) + sinsNavParam.v[0] / Rn);
	F[2][1] = sinsNavParam.v[1] / Rm;
	F[2][3] = 1 / Rn * tan(sinsNavParam.la);
	F[2][6] = (wie * cos(sinsNavParam.la) + sinsNavParam.v[0] / (Rn * cos(sinsNavParam.la) * cos(sinsNavParam.la)));

	F[3][1] = -measurements.f[2];
	F[3][2] = measurements.f[1];
	F[3][3] = (sinsNavParam.v[1] / Rm * tan(sinsNavParam.la) - sinsNavParam.v[2] / Rm);
	F[3][4] = (2 * wie * sin(sinsNavParam.la) + sinsNavParam.v[0] / Rn);
	F[3][5] = (2 * wie * cos(sinsNavParam.la) + sinsNavParam.v[0] / Rn);
	F[3][6] = (2 * wie * cos(sinsNavParam.la) * sinsNavParam.v[1] + sinsNavParam.v[0] * sinsNavParam.v[1] / (Rn * cos(sinsNavParam.la) * cos(sinsNavParam.la)) + 2 * wie * sin(sinsNavParam.la) * sinsNavParam.v[2]);

	F[4][0] = measurements.f[2];
	F[4][2] = -measurements.f[0];
	F[4][3] = -2 * (wie * sin(sinsNavParam.la) + sinsNavParam.v[0] / Rn * tan(sinsNavParam.la));
	F[4][4] = -sinsNavParam.v[2] / Rm;
	F[4][5] = -sinsNavParam.v[1] / Rm;
	F[4][6] = -(2 * wie * cos(sinsNavParam.la) + sinsNavParam.v[0] / (Rn * cos(sinsNavParam.la) * cos(sinsNavParam.la))) * sinsNavParam.v[0];

	F[5][0] = -measurements.f[1];
	F[5][1] = measurements.f[0];
	F[5][3] = -2 * (wie * cos(sinsNavParam.la) + sinsNavParam.v[0] / Rn);
	F[5][5] = 2 * sinsNavParam.v[1] / Rm;
	F[5][6] = -2 * wie * sin(sinsNavParam.la) * sinsNavParam.v[0];

	F[6][4] = 1 / Rm;

	F[7][3] = 1 / (Rn * cos(sinsNavParam.la));
	F[7][6] = sinsNavParam.v[0] / (Rn * cos(sinsNavParam.la)) * tan(sinsNavParam.la);

	F[8][5] = 1;


	// Error transfer: From IMU error to nav error
	F[0][9] = 1;

	F[1][10] = 1;

	F[2][11] = 1;

	F[3][12] = 1;

	F[4][13] = 1;

	F[5][14] = 1;


	// Error transfer: From GNSS receiver error to GNSS receiver error
	F[15][16] = 1;
	F[16][16] = -1 / gnssErrorParam.timerDriftCorreTime;



	// Descrete the transfer matrix   Phi = eye(17) + F * T
	matConstantMul(Phi, ukfParamOld.T, F, 17, 17);
	matPlus(Phi, eye17, Phi, 17, 17);




	// System error variance
	Q[0][0] = imuErrorParam.gyroNoise[0] * imuErrorParam.gyroNoise[0];
	Q[1][1] = imuErrorParam.gyroNoise[1] * imuErrorParam.gyroNoise[1];
	Q[2][2] = imuErrorParam.gyroNoise[2] * imuErrorParam.gyroNoise[2];
	Q[3][3] = imuErrorParam.accNoise[0] * imuErrorParam.accNoise[0];
	Q[4][4] = imuErrorParam.accNoise[1] * imuErrorParam.accNoise[1];
	Q[5][5] = imuErrorParam.accNoise[2] * imuErrorParam.accNoise[2];
	Q[6][6] = gnssErrorParam.timerFrequencyDriftNoise * gnssErrorParam.timerFrequencyDriftNoise;

	// Error variance transfer 
	G[0][0] = sinsNavParam.Ctb[0][0];
	G[0][1] = sinsNavParam.Ctb[1][0];
	G[0][2] = sinsNavParam.Ctb[2][0];
	G[1][0] = sinsNavParam.Ctb[0][1];
	G[1][1] = sinsNavParam.Ctb[1][1];
	G[1][2] = sinsNavParam.Ctb[2][1];
	G[2][0] = sinsNavParam.Ctb[0][2];
	G[2][1] = sinsNavParam.Ctb[1][2];
	G[2][2] = sinsNavParam.Ctb[2][2];

	G[3][3] = sinsNavParam.Ctb[0][0];
	G[3][4] = sinsNavParam.Ctb[1][0];
	G[3][5] = sinsNavParam.Ctb[2][0];
	G[4][3] = sinsNavParam.Ctb[0][1];
	G[4][4] = sinsNavParam.Ctb[1][1];
	G[4][5] = sinsNavParam.Ctb[2][1];
	G[5][3] = sinsNavParam.Ctb[0][2];
	G[5][4] = sinsNavParam.Ctb[1][2];
	G[5][5] = sinsNavParam.Ctb[2][2];

	G[16][6] = 1;



	// Descrete matrix G     Ka = (eye(17) * T + F * T ^ 2 / 2) * G
	matConstantMul(temp17x17, (ukfParamOld.T / 2), F, 17, 17);
	matPlus(temp17x17, eye17, temp17x17, 17, 17);
	matConstantMul(temp17x17, ukfParamOld.T, temp17x17, 17, 17);
	matMul(Ka, 17, 7, temp17x17, 17, 17, G, 17, 7);




	// Measurement error variance
	for (i = 0; i < svNumber; i++)
	{
		*(*(R)+i * 2 * svNumber + i) = gnssErrorParam.pseuNoise * gnssErrorParam.pseuNoise;
		*(*(R)+(i + svNumber) * 2 * svNumber + i + svNumber) = gnssErrorParam.pseuRateNoise * gnssErrorParam.pseuRateNoise;
	}





	//******** UKF algorithm ********//
	// Get real measurements
	for (i = 0; i < svNumber; i++)
	{
		ukfGetZ(tempZ, sinsNavParam, gnssNavParam, i);
		Z[i] = tempZ[0];
		Z[i + svNumber] = tempZ[1];
	}




	// Get square root
	matCholesky(Ses, ukfParamOld.Pes, 17);
	matCholesky(SQ, Q, 7);
	matCholesky(SR, R, (2 * svNumber));






	// Sigma point
	alpha = 1e-1; // 1e-4 to 1
	beta = 2;
	ka = 0;
	lamda = alpha * alpha * (17 + ka) - 17;

	weight[0] = lamda / (17 + lamda) + (1 - alpha * alpha + beta);

	//lamda = 1;
	//weight[0] = lamda / (17 + lamda);
	for (i = 0; i < 17; i++)
	{
		XesSigma[i] = ukfParamOld.Xes[i];
	}

	matCholesky(upperTriMatrix, ukfParamOld.Pes, 17);

	for (i = 0; i < 17; i++)
	{
		weight[i + 1] = 1 / (2 * (17 + lamda));
		weight[i + 1 + 17] = 1 / (2 * (17 + lamda));
		for (j = 0; j < 17; j++)
		{
			XesSigma[(i + 1) * 17 + j] = ukfParamOld.Xes[j] + sqrt((17 + lamda)) * upperTriMatrix[i][j];
			XesSigma[(i + 1 + 17) * 17 + j] = ukfParamOld.Xes[j] - sqrt((17 + lamda)) * upperTriMatrix[i][j];
		}

	}







	// One step estimation: XesOneStep = sum(weight * Phi * XesSigma)
	// One step measurements: ZesOneStep = sum(weight * H(XesSigma))
	for (i = 0; i < 2 * 17 + 1; i++)
	{
		// XesOneStep
		matMul(&XesOneStepSigma[i * 17], 17, 1, Phi, 17, 17, &XesSigma[i * 17], 17, 1);

		matConstantMul(temp17x1, weight[i], &XesOneStepSigma[i * 17], 17, 1);

		matPlus(XesOneStep, XesOneStep, temp17x1, 17, 1);


		// ZesOneStep
		sinsNavParamTemp.v[0] = sinsNavParam.v[0] - XesSigma[i * 17 + 3];
		sinsNavParamTemp.v[1] = sinsNavParam.v[1] - XesSigma[i * 17 + 4];
		sinsNavParamTemp.v[2] = sinsNavParam.v[2] - XesSigma[i * 17 + 5];
		sinsNavParamTemp.la = sinsNavParam.la - XesSigma[i * 17 + 6];
		sinsNavParamTemp.lon = sinsNavParam.lon - XesSigma[i * 17 + 7];
		sinsNavParamTemp.alt = sinsNavParam.alt - XesSigma[i * 17 + 8];
		for (j = 0; j < svNumber; j++)
		{
			ukfGetZ(tempZ, sinsNavParamTemp, gnssNavParam, j);
			ZesOneStepSigma[i * 2 * svNumber + j] = tempZ[0];
			ZesOneStepSigma[i * 2 * svNumber + j + svNumber] = tempZ[1];
		}

		matConstantMul(tempZ, weight[i], &ZesOneStepSigma[i * 2 * svNumber], (2 * svNumber), 1);
		matPlus(ZesOneStep, ZesOneStep, tempZ, (2 * svNumber), 1);
	}




	// SesOneStep
	for (i = 1; i <= 2 * 17; i++)
	{
		for (j = 0; j < 17; j++)
		{
			Bk[i - 1][j] = sqrt(weight[i]) * (XesOneStepSigma[i * 17 + j] - XesOneStep[j]);
		}
	}
	for (i = 0; i < 17; i++)
	{
		for (j = 0; j < 17; j++)
		{
			Bk[2 * 17 + i][j] = SQ[i][j];
		}
	}

	matQR(Bk, SesOneStep, Bk, (2 * 17 + 17), 17);

	for (i = 0; i < 17; i++)
	{
		cholupdateX[i] = XesOneStepSigma[i] - XesOneStep[i];
	}
	matCholupdate(SesOneStep, SesOneStep, cholupdateX, weight[0], 17, 1);



	// SzesOneStep
	for (i = 1; i <= 2 * 17; i++)
	{
		for (j = 0; j < 2 * svNumber; j++)
		{
			*(*(Ck)+(i - 1) * 2 * svNumber + j) = sqrt(weight[i]) * (ZesOneStepSigma[i * (2 * svNumber) + j] - ZesOneStep[j]);
		}
	}
	for (i = 0; i < 2 * svNumber; i++)
	{
		for (j = 0; j < 2 * svNumber; j++)
		{
			*(*(Ck)+(2 * 17 + i) * 2 * svNumber + j) = *(*(SR)+i * 2 * svNumber + j);
		}
	}

	matQR(Ck, SzesOneStep, Ck, (2 * 17 + 2 * svNumber), 2 * svNumber);

	for (i = 0; i < 2 * svNumber; i++)
	{
		cholupdateZ[i] = ZesOneStepSigma[i] - ZesOneStep[i];
	}

	matCholupdate(SzesOneStep, SzesOneStep, cholupdateZ, weight[0], 2 * svNumber, 1);





	// One step estimation variance: PesOneStep = sum(weight * (XesSigma - XesOneStep) * trans(XesSigma - XesOneStep)) + Ka * Q * Ka'
	// One step measurement variance: PzesOneStep = sum(weight * (ZesSigma - ZesOneStep) * trans(ZesSigma - ZesOneStep)) + R
	// One step measurement variance: PxzesOneStep = sum(weight * (XesSigma - XesOneStep) * trans(ZesSigma - ZesOneStep))
	for (i = 0; i < 2 * 17 + 1; i++)
	{
		// PesOneStep accumulation
		matMinus(temp17x1, &XesOneStepSigma[i * 17], XesOneStep, 17, 1);
		matTranspose(temp1x17, temp17x1, 1, 17);
		matMul(temp17x17, 17, 17, temp17x1, 17, 1, temp1x17, 1, 17);


		// PzesOneStep accumulation
		matMinus(tempZ, &ZesOneStepSigma[i * 2 * svNumber], ZesOneStep, (2 * svNumber), 1);
		matTranspose(tempZtrans, tempZ, 1, (2 * svNumber));
		matMul(tempZZtrans, (2 * svNumber), (2 * svNumber), tempZ, (2 * svNumber), 1, tempZtrans, 1, (2 * svNumber));


		// PxzesOneStep accumulation
		matMul(tempXZtrans, 17, (2 * svNumber), temp17x1, 17, 1, tempZtrans, 1, (2 * svNumber));
		matConstantMul(tempXZtrans, weight[i], tempXZtrans, 17, (2 * svNumber));
		matPlus(PxzesOneStep, PxzesOneStep, tempXZtrans, 17, (2 * svNumber));

	}


	// K = PxzesOneStep * inv(SzesOneStep) * inv(SzesOneStep')
	matTranspose(SzesOneStepTrans, SzesOneStep, (2 * svNumber), (2 * svNumber));
	matInv(SzesOneStepInv, SzesOneStep, (2 * svNumber));
	matInv(SzesOneStepTransInv, SzesOneStepTrans, (2 * svNumber));
	matMul(SzesOneStepInv, (2 * svNumber), (2 * svNumber), SzesOneStepInv, (2 * svNumber), (2 * svNumber), SzesOneStepTransInv, (2 * svNumber), (2 * svNumber));
	matMul(K, 17, (2 * svNumber), PxzesOneStep, 17, (2 * svNumber), SzesOneStepInv, (2 * svNumber), (2 * svNumber));



	// Estimation Xes = XesOneStep + K * (Z - ZesOneStep)
	matMinus(tempZ, Z, ZesOneStep, (2 * svNumber), 1);
	matMul(temp17x1, 17, 1, K, 17, (2 * svNumber), tempZ, (2 * svNumber), 1);
	matPlus(ukfParamNew.Xes, XesOneStep, temp17x1, 17, 1);


	// Ses = chol(Ses' * Ses - (K * Szes) * (K * Szes)')
	// Pes = Ses' * Ses
	matMul(KSzes, 17, (2 * svNumber), K, 17, (2 * svNumber), SzesOneStep, (2 * svNumber), (2 * svNumber));
	matCholupdate(Ses, SesOneStep, KSzes, -1, 17, (2 * svNumber));

	matTranspose(SesTrans, Ses, 17, 17);
	matMul(ukfParamNew.Pes, 17, 17, SesTrans, 17, 17, Ses, 17, 17);





	return ukfParamNew;
}