
#include <math.h>

#include "sins_gnss_kf.h"
#include "matrix.h"



// ***************************  Local variables *************************** //
// Size of estimators, measurements, process noise and measurement noise
int sizeX;
int sizeZ;
int sizeW;
int sizeV;

// Radius of meridian plane and prime plane
double Rm, Rn;

// Kalman Filter parameters
double Z[MAX_Z] = { 0 };// Measurement matrix
double F[MAX_X][MAX_X] = { 0 };// State transfer matrix (Continus)
double Phi[MAX_X][MAX_X] = { 0 };// State transfer matrix (Descrete)
double G[MAX_X][MAX_W] = { 0 };// Error variance transfer matrix (Continus)
double Ka[MAX_X][MAX_W] = { 0 };// Error variance transfer matrix (Descrete)
double Q[MAX_W][MAX_W] = { 0 };// System error variance
double H[MAX_Z][MAX_X] = { 0 };// Measurement matrix
double R[MAX_Z][MAX_Z] = { 0 };// Measurement error variance
double XesOneStep[MAX_X] = { 0 };// One step estimation
double PesOneStep[MAX_X][MAX_X] = { 0 };// One step estimation variance
double K[MAX_X][MAX_Z] = { 0 };// Kalman gain


// UKF parameters
int svNumber;
double alpha;
double beta;
double ka;
double lamda;
double weightM[MAX_SIGMA_NUM] = { 0 };
double weightC[MAX_SIGMA_NUM] = { 0 };
double XesSigma[MAX_SIGMA_NUM][MAX_X] = { 0 };
double upperTriMatrix[MAX_X][MAX_X] = { 0 };
double ZesOneStep[MAX_Z] = { 0 };
double XesSigmaOneStep[MAX_SIGMA_NUM][MAX_X] = { 0 };
double XesOneStepSigma[MAX_SIGMA_NUM2][MAX_X] = { 0 };
double ZesSigmaOneStep[MAX_SIGMA_NUM][MAX_Z] = { 0 };
double PzesOneStep[MAX_Z][MAX_Z] = { 0 };
double PxzesOneStep[MAX_X][MAX_Z] = { 0 };


// Pseudorange error and pseudorange rate error calculation parameters
double positionSINS[3] = { 0 };// SINS position in earth x-y-z coordinate
double Cte[3][3] = { 0 };// Transfer matrix from e-n-u to x-y-z
double vxyzSINS[3] = { 0 };// SINS velocity in earth x-y-z coordinate
double venuSINS[3] = { 0 };// SINS velocity in E-N-U coordinate
double pseudorangeSINS = 0;
double pseudorangeRateSINS = 0;
double ex2, N;


// H-infinity parameters
double alphaHinf = 0;
double gamma = 0;
double PesOneStepInv[MAX_X][MAX_X] = { 0 };
double Pxzxx[MAX_X][MAX_X + MAX_Z] = { 0 };
double Rek[MAX_X + MAX_Z][MAX_X + MAX_Z] = { 0 };

// Angular rate
double wiet[3] = { 0 };
double wett[3] = { 0 };
double witt[3] = { 0 };
double wiet_witt[3] = { 0 };
double delta_wiet[3] = { 0 };
double delta_wett[3] = { 0 };
double delta_wiet_witt[3] = { 0 };

// Eular matrix
double Ctp[3][3] = { 0 };
double Cpt[3][3] = { 0 };
double Cpb[3][3] = { 0 };
double Cbp[3][3] = { 0 };

// Quaternion related variables
double QuaNorm = 0;
double B[4][3] = { 0 };

// Runge-Kutta variables
double k_Qua[4][4] = { 0 };
double k_deltaV[4][3] = { 0 };
double k_deltaLa[4] = { 0 };
double k_deltaLon[4] = { 0 };
double k_deltaH[4] = { 0 };
double k_gnssErrorP[4] = { 0 };
double k_gnssErrorV[4] = { 0 };

// Temperary variables for RK4
double deltaV[3] = { 0 };
double deltaLa = 0;
double deltaLon = 0;
double deltaH = 0;
double Qtp[4] = { 0 };
double gnssErrorP = 0;
double gnssErrorV = 0;

// Temporary matrix
double eye3[3][3] = { { 1, 0, 0 }, { 0, 1, 0 }, { 0, 0, 1 } };
double eye[MAX_TEMP][MAX_TEMP] = { 0 };
double matTemp1[MAX_TEMP][MAX_TEMP] = { 0 };
double matTemp2[MAX_TEMP][MAX_TEMP] = { 0 };
double matTemp3[MAX_TEMP][MAX_TEMP] = { 0 };
double matTemp4[MAX_TEMP][MAX_TEMP] = { 0 };
double matTemp5[MAX_TEMP][MAX_TEMP] = { 0 };

// Temporary vectors
double vecTemp1[MAX_TEMP] = { 0 };



/*
	Initialize matrix of KF
 */
int kfInitMatrix()
{
	int i, j;

	for (i = 0; i < sizeX; i++)
	{
		for (j = 0; j < sizeX; j++)
		{
			*(*F + i * sizeX + j) = 0;
		}
	}
	for (i = 0; i < sizeW; i++)
	{
		for (j = 0; j < sizeW; j++)
		{
			*(*Q + i * sizeW + j) = 0;
		}
	}
	for (i = 0; i < sizeV; i++)
	{
		for (j = 0; j < sizeV; j++)
		{
			*(*R + i * sizeV + j) = 0;
		}
	}
	for (i = 0; i < sizeX; i++)
	{
		for (j = 0; j < sizeW; j++)
		{
			*(*G + i * sizeW + j) = 0;
		}
	}
	for (i = 0; i < sizeZ; i++)
	{
		for (j = 0; j < sizeX; j++)
		{
			*(*H + i * sizeX + j) = 0;
		}
	}
	for (i = 0; i < sizeX; i++)
	{
		for (j = 0; j < sizeX; j++)
		{
			*(*eye + i * sizeX + j) = (i == j) ? 1 : 0;
		}
	}

	return 0;
}

/*
	Initialize matrix of UKF
*/
int ukfInitMatrix()
{
	int i, j;

	kfInitMatrix();

	for (i = 0; i < sizeX; i++)
	{
		XesOneStep[i] = 0;
	}
	for (i = 0; i < sizeZ; i++)
	{
		ZesOneStep[i] = 0;
	}
	for (i = 0; i < sizeX; i++)
	{
		for (j = 0; j < sizeX; j++)
		{
			*(*PesOneStep + i * sizeX + j) = 0;
		}
	}
	for (i = 0; i < sizeZ; i++)
	{
		for (j = 0; j < sizeZ; j++)
		{
			*(*PzesOneStep + i * sizeZ + j) = 0;
		}
	}
	for (i = 0; i < sizeX; i++)
	{
		for (j = 0; j < sizeZ; j++)
		{
			*(*PxzesOneStep + i * sizeZ + j) = 0;
		}
	}

	return 0;
}






// ***************************  KF *************************** //

/* Kalman Filter parameter
% Xdot = F * X + G * W-->     X(k + 1) = Phi * X(k) + Ka * W
% Z = H * X + V-->     Z = H * X + V


% Xes: Estimation of system state
% Element : Tilt at east axis (Ctp, rad, from ideal navigation coordinate to platform coordinate / actual navigation coordinate)
%			Tilt at north axis
%           Tilt at up axis
%           Velocity error at east axis(m / s)
%			Velocity error at north axis
%           Velocity error at up axis
%           Latitude error(rad)
%			Longitude error
%           height error(m)
%			Gyroscope accNoise at east axis(rad / s)
%			Gyroscope accNoise at north axis
%           Gyroscope accNoise at up axis
%           Accelerometer accNoise at east axis(m ^ 2 / s)
%			Accelerometer accNoise at north axis
%           Accelerometer accNoise at up axis


% Q: Variance of System noise W
% Element : Gyroscope random error at east axis(rad / s)
%			Gyroscope random error at north axis
%        	Gyroscope random error at up axis
%       	Acceleration random error at east axis(m / s ^ 2)
%			Acceleration random error at north axis
%        	Acceleration random error at up axis



% Z: Observation
% Element : Velocity error at east axis(m / s)
%			Velocity error at north axis
%           Velocity error at up axis
%           Latitude error(rad)
%			Longitude error
%           Height error(m)


% R: Observation noise variance
% Element : Velocity observation noise at east axis(m / s)
%			Velocity observation noise at north axis
%           Velocity observation noise at up axis
%           Latitude observation noise(rad)
%			Longitude observation noise
%           Height observation noise(m)
*/

/*
	Kalman filter initialization
*/
KF_PARAM kfInit(KF_INIT_PARAM kfInitParam, int sizeX)
{
	int i, j;

	KF_PARAM kfParam = 
	{
		0,
		{0},
		{0}
	};

	for (i = 0; i < sizeX; i++)
	{
		kfParam.Xes[i] = kfInitParam.mx0[i];
		for (j = 0; j < sizeX; j++)
		{
			*(*(kfParam.Pes) + i * sizeX + j) = *(*(kfInitParam.Cx0) + i * sizeX + j);
		}
	}

	kfParam.T = kfInitParam.T;

	return kfParam;
}





/*
	SINS GNSS loosely coupled Kalman filtering
 */
KF_PARAM kf(KF_PARAM kfParamOld,
			INS_NAV_PARAM sinsNavParam, 
			GNSS_NAV_PARAM gnssNavParam,
			INS_MEASUREMENT measurements,
			IMU_ERROR_PARAM imuErrorParam, 
			GNSS_ERROR_PARAM gnssErrorParam)
{
	KF_PARAM kfParamNew = kfParamOld;


	// Get navigation parameters
	sinsSetNavParam(sinsNavParam);

	// Initialize some matrixs
	sizeX = 15;
	sizeW = 6;
	sizeZ = 6;
	sizeV = 6;

	// initialize matrix
	kfInitMatrix();

	Rm = Re / (1 + 2 * e - 3 * e * sin(la * la));
	Rn = Re / (1 - e * sin(la * la));

	Z[0] = v[0] - gnssNavParam.v_enu[0];
	Z[1] = v[1] - gnssNavParam.v_enu[1];
	Z[2] = v[2] - gnssNavParam.v_enu[2];
	Z[3] = la - gnssNavParam.la;
	Z[4] = lon - gnssNavParam.lon;
	Z[5] = alt - gnssNavParam.alt;

	// Error transfer: From nav error to nav error
	*(*F + 0 * sizeX + 1) = (wie * sin(la) + v[0] / (Rn + alt) * tan(la));
	*(*F + 0 * sizeX + 2) = -(wie * cos(la) + v[0] / (Rn + alt));
	*(*F + 0 * sizeX + 4) = -(1 / (Rm + alt));
	
	*(*F + 1 * sizeX + 0) = -(wie * sin(la) + v[0] / (Rn + alt) * tan(la));
	*(*F + 1 * sizeX + 2) = -v[1] / (Rm + alt);
	*(*F + 1 * sizeX + 3) = 1 / (Rn + alt);
	*(*F + 1 * sizeX + 6) = -wie * sin(la);

	*(*F + 2 * sizeX + 0) = (wie * cos(la) + v[0] / (Rn + alt));
	*(*F + 2 * sizeX + 1) = v[1] / (Rm + alt);
	*(*F + 2 * sizeX + 3) = 1 / (Rn + alt) * tan(la);
	*(*F + 2 * sizeX + 6) = (wie * cos(la) + v[0] / ((Rn + alt) * cos(la) * cos(la)));

	*(*F + 3 * sizeX + 1) = -measurements.f[2];
	*(*F + 3 * sizeX + 2) = measurements.f[1];
	*(*F + 3 * sizeX + 3) = (v[1] / (Rm + alt) * tan(la) - v[2] / (Rm + alt));
	*(*F + 3 * sizeX + 4) = (2 * wie * sin(la) + v[0] / (Rn + alt));
	*(*F + 3 * sizeX + 5) = (2 * wie * cos(la) + v[0] / (Rn + alt));
	*(*F + 3 * sizeX + 6) = (2 * wie * cos(la) * v[1] + v[0] * v[1] / ((Rn + alt) * cos(la) * cos(la)) + 2 * wie * sin(la) * v[2]);
		
	*(*F + 4 * sizeX + 0) = measurements.f[2];
	*(*F + 4 * sizeX + 2) = -measurements.f[0];
	*(*F + 4 * sizeX + 3) = -2 * (wie * sin(la) + v[0] / (Rn + alt) * tan(la));
	*(*F + 4 * sizeX + 4) = -v[2] / (Rm + alt);
	*(*F + 4 * sizeX + 5) = -v[1] / (Rm + alt);
	*(*F + 4 * sizeX + 6) = -(2 * wie * cos(la) + v[0] / ((Rn + alt) * cos(la) * cos(la))) * v[0];
		
	*(*F + 5 * sizeX + 0) = -measurements.f[1];
	*(*F + 5 * sizeX + 1) = measurements.f[0];
	*(*F + 5 * sizeX + 3) = -2 * (wie * cos(la) + v[0] / (Rn + alt));
	*(*F + 5 * sizeX + 5) = 2 * v[1] / (Rm + alt);
	*(*F + 5 * sizeX + 6) = -2 * wie * sin(la) * v[0];
		
	*(*F + 6 * sizeX + 4) = 1 / (Rm + alt);
		
	*(*F + 7 * sizeX + 3) = 1 / ((Rn + alt) * cos(la));
	*(*F + 7 * sizeX + 6) = v[0] / ((Rn + alt) * cos(la)) * tan(la);
		
	*(*F + 8 * sizeX + 5) = 1;


	// Error transfer: From IMU error to nav error
	*(*F + 0 * sizeX + 9) = 1;

	*(*F + 1 * sizeX + 10) = 1;

	*(*F + 2 * sizeX + 11) = 1;

	*(*F + 3 * sizeX + 12) = 1;

	*(*F + 4 * sizeX + 13) = 1;

	*(*F + 5 * sizeX + 14) = 1;

	
	// Descrete the transfer matrix   Phi = eye(15) + F * T
	matConstantMul(Phi, kfParamOld.T, F, sizeX, sizeX);
	matPlus(Phi, eye, Phi, sizeX, sizeX);
	
	
	// System error variance
	*(*Q + 0 * sizeW + 0) = imuErrorParam.gyroNoise[0] * imuErrorParam.gyroNoise[0];
	*(*Q + 1 * sizeW + 1) = imuErrorParam.gyroNoise[1] * imuErrorParam.gyroNoise[1];
	*(*Q + 2 * sizeW + 2) = imuErrorParam.gyroNoise[2] * imuErrorParam.gyroNoise[2];
	*(*Q + 3 * sizeW + 3) = imuErrorParam.accNoise[0] * imuErrorParam.accNoise[0];
	*(*Q + 4 * sizeW + 4) = imuErrorParam.accNoise[1] * imuErrorParam.accNoise[1];
	*(*Q + 5 * sizeW + 5) = imuErrorParam.accNoise[2] * imuErrorParam.accNoise[2];
	
	// Error variance transfer 
	*(*G + 0 * sizeW + 0) = Ctb[0][0];
	*(*G + 0 * sizeW + 1) = Ctb[1][0];
	*(*G + 0 * sizeW + 2) = Ctb[2][0];
	*(*G + 1 * sizeW + 0) = Ctb[0][1];
	*(*G + 1 * sizeW + 1) = Ctb[1][1];
	*(*G + 1 * sizeW + 2) = Ctb[2][1];
	*(*G + 2 * sizeW + 0) = Ctb[0][2];
	*(*G + 2 * sizeW + 1) = Ctb[1][2];
	*(*G + 2 * sizeW + 2) = Ctb[2][2];

	*(*G + 3 * sizeW + 3) = Ctb[0][0];
	*(*G + 3 * sizeW + 4) = Ctb[1][0];
	*(*G + 3 * sizeW + 5) = Ctb[2][0];
	*(*G + 4 * sizeW + 3) = Ctb[0][1];
	*(*G + 4 * sizeW + 4) = Ctb[1][1];
	*(*G + 4 * sizeW + 5) = Ctb[2][1];
	*(*G + 5 * sizeW + 3) = Ctb[0][2];
	*(*G + 5 * sizeW + 4) = Ctb[1][2];
	*(*G + 5 * sizeW + 5) = Ctb[2][2];

	
	// Descrete matrix G     Ka = (eye(15) * T + F * T ^ 2 / 2) * G
	matConstantMul(matTemp1, (kfParamOld.T / 2), F, sizeX, sizeX);
	matPlus(matTemp1, eye, matTemp1, sizeX, sizeX);
	matConstantMul(matTemp1, kfParamOld.T, matTemp1, sizeX, sizeX);
	matMul(Ka, sizeX, 6, matTemp1, sizeX, sizeX, G, sizeX, 6);
	

	// Measurement matrix
	*(*H + 0 * sizeX + 3) = 1;
	*(*H + 1 * sizeX + 4) = 1;
	*(*H + 2 * sizeX + 5) = 1;

	*(*H + 3 * sizeX + 6) = 1;
	*(*H + 4 * sizeX + 7) = 1;
	*(*H + 5 * sizeX + 8) = 1;
	
	// Measurement error variance
	*(*R + 0 * sizeV + 0) = gnssErrorParam.vNoise[0] * gnssErrorParam.vNoise[0];
	*(*R + 1 * sizeV + 1) = gnssErrorParam.vNoise[1] * gnssErrorParam.vNoise[1];
	*(*R + 2 * sizeV + 2) = gnssErrorParam.vNoise[2] * gnssErrorParam.vNoise[2];

	*(*R + 3 * sizeV + 3) = (gnssErrorParam.pNoise[0] / (Rm + alt)) * (gnssErrorParam.pNoise[0] / (Rm + alt));
	*(*R + 4 * sizeV + 4) = (gnssErrorParam.pNoise[1] / (Rn + alt)) * (gnssErrorParam.pNoise[1] / (Rn + alt));
	*(*R + 5 * sizeV + 5) = gnssErrorParam.pNoise[2] * gnssErrorParam.pNoise[2];
	
	// One step estimation XesOneStep = Phi * Xes
	matMul(XesOneStep, sizeX, 1, Phi, sizeX, sizeX, kfParamOld.Xes, sizeX, 1);
	
	// One step estimation variance PesOneStep = Phi * Pes * Phi' + Ka * Q * Ka'
	matTranspose(matTemp1, Phi, sizeX, sizeX);
	matMul(matTemp2, sizeX, sizeX, kfParamOld.Pes, sizeX, sizeX, matTemp1, sizeX, sizeX);
	matMul(matTemp1, sizeX, sizeX, Phi, sizeX, sizeX, matTemp2, sizeX, sizeX);

	matTranspose(matTemp2, Ka, sizeW, sizeX);
	matMul(matTemp3, sizeW, sizeX, Q, sizeW, sizeW, matTemp2, sizeW, sizeX);
	matMul(matTemp2, sizeX, sizeX, Ka, sizeX, sizeW, matTemp3, sizeW, sizeX);

	matPlus(PesOneStep, matTemp1, matTemp2, sizeX, sizeX);
	
	// Kalman gain K = PesOneStep * H' / (H * PesOneStep * H' + R)
	matTranspose(matTemp1, H, sizeX, sizeZ);

	matMul(matTemp2, sizeX, sizeZ, PesOneStep, sizeX, sizeX, matTemp1, sizeX, sizeZ);
	matMul(matTemp3, sizeZ, sizeZ, H, sizeZ, sizeX, matTemp2, sizeX, sizeZ);
	matPlus(matTemp3, R, matTemp3, sizeV, sizeV);
	matInv(matTemp1, matTemp3, sizeV);
	matMul(K, sizeX, sizeV, matTemp2, sizeX, sizeZ, matTemp1, sizeV, sizeV);
	
	// Estimation Xes = XesOneStep + K * (Z - H * XesOneStep)
	matMul(matTemp1, sizeZ, 1, H, sizeZ, sizeX, XesOneStep, sizeX, 1);
	matMinus(matTemp1, Z, matTemp1, sizeZ, 1);
	matMul(matTemp2, sizeX, 1, K, sizeX, sizeV, matTemp1, sizeZ, 1);
	matPlus(kfParamNew.Xes, XesOneStep, matTemp2, sizeX, 1);

	// Estimation variance Pes = (eye(15) - K * H) * PesOneStep * (eye(15) - K * H)' + K * R * K'
	matTranspose(matTemp1, K, sizeV, sizeX);
	matMul(matTemp2, sizeV, sizeX, R, sizeV, sizeV, matTemp1, sizeV, sizeX);
	matMul(matTemp1, sizeX, sizeX, K, sizeX, sizeV, matTemp2, sizeV, sizeX);

	matMul(matTemp2, sizeX, sizeX, K, sizeX, sizeV, H, sizeZ, sizeX);
	matMinus(matTemp2, eye, matTemp2, sizeX, sizeX);
	matTranspose(matTemp3, matTemp2, sizeX, sizeX);
	matMul(matTemp4, sizeX, sizeX, PesOneStep, sizeX, sizeX, matTemp3, sizeX, sizeX);
	matMul(matTemp3, sizeX, sizeX, matTemp2, sizeX, sizeX, matTemp4, sizeX, sizeX);

	matPlus(kfParamNew.Pes, matTemp3, matTemp1, sizeX, sizeX);

	return kfParamNew;
}













// *************************** Quaternion based lossely coupled UKF *************************** //

/* Kalman Filter parameter
% Xdot = F * X + G * W-->     X(k + 1) = F(X(k)) + Ka * W
% Z = H * X + V-->     Z = H * X + V


% Xes: Estimation of system state
% Element : Quaternion element 1 (Ctp, from ideal navigation coordinate to platform coordinate / actual navigation coordinate)
%			Quaternion element 2
%			Quaternion element 3
%			Quaternion element 4
%           Velocity error at east axis(m / s)
%			Velocity error at north axis
%           Velocity error at up axis
%           Latitude error(rad)
%			Longitude error
%           height error(m)
%			Gyroscope accNoise at east axis(rad / s)
%			Gyroscope accNoise at north axis
%           Gyroscope accNoise at up axis
%           Accelerometer accNoise at east axis(m ^ 2 / s)
%			Accelerometer accNoise at north axis
%           Accelerometer accNoise at up axis


% Q: Variance of System noise W
% Element : Quaternion element 1 noise
%			Quaternion element 2 noise
%        	Quaternion element 3 noise
%        	Quaternion element 4 noise
%       	Acceleration random error at east axis(m / s ^ 2)
%			Acceleration random error at north axis
%        	Acceleration random error at up axis



% Z: Observation
% Element : Velocity error at east axis(m / s)
%			Velocity error at north axis
%           Velocity error at up axis
%           Latitude error(rad)
%			Longitude error
%           Height error(m)


% R: Observation noise variance
% Element : Velocity observation noise at east axis(m / s)
%			Velocity observation noise at north axis
%           Velocity observation noise at up axis
%           Latitude observation noise(rad)
%			Longitude observation noise
%           Height observation noise(m)
*/


/*
	Get matrix B, Ctp from Qtp
*/
int qlcukfGetBCtp(double B[4][3], double Ctp[3][3], double Qtp[4])
{

	Ctp[0][0] = Qtp[0] * Qtp[0] + Qtp[1] * Qtp[1] - Qtp[2] * Qtp[2] - Qtp[3] * Qtp[3];
	Ctp[0][1] = 2 * (Qtp[1] * Qtp[2] + Qtp[0] * Qtp[3]);
	Ctp[0][2] = 2 * (Qtp[1] * Qtp[3] - Qtp[0] * Qtp[2]);
	Ctp[1][0] = 2 * (Qtp[1] * Qtp[2] - Qtp[0] * Qtp[3]);
	Ctp[1][1] = Qtp[0] * Qtp[0] - Qtp[1] * Qtp[1] + Qtp[2] * Qtp[2] - Qtp[3] * Qtp[3];
	Ctp[1][2] = 2 * (Qtp[2] * Qtp[3] + Qtp[0] * Qtp[1]);
	Ctp[2][0] = 2 * (Qtp[1] * Qtp[3] + Qtp[0] * Qtp[2]);
	Ctp[2][1] = 2 * (Qtp[2] * Qtp[3] - Qtp[0] * Qtp[1]);
	Ctp[2][2] = Qtp[0] * Qtp[0] - Qtp[1] * Qtp[1] - Qtp[2] * Qtp[2] + Qtp[3] * Qtp[3];


	B[0][0] = -Qtp[1] / 2;
	B[0][1] = -Qtp[2] / 2;
	B[0][2] = -Qtp[3] / 2;
	B[1][0] = Qtp[0] / 2;
	B[1][1] = -Qtp[3] / 2;
	B[1][2] = Qtp[2] / 2;
	B[2][0] = Qtp[3] / 2;
	B[2][1] = Qtp[0] / 2;
	B[2][2] = -Qtp[1] / 2;
	B[3][0] = -Qtp[2] / 2;
	B[3][1] = Qtp[1] / 2;
	B[3][2] = Qtp[0] / 2;

	return 0;
}



/*
	Quaternion based unscented Kalman filtering
*/
KF_PARAM qlcukf(KF_PARAM qlcukfParamOld,
	INS_NAV_PARAM sinsNavParam,
	GNSS_NAV_PARAM gnssNavParam,
	INS_MEASUREMENT measurements,
	IMU_ERROR_PARAM imuErrorParam,
	GNSS_ERROR_PARAM gnssErrorParam)
{
	KF_PARAM qlcukfParamNew = qlcukfParamOld;

	int i, j, k;

	// Set navigation parameters
	sinsSetNavParam(sinsNavParam);

	// Initialize some matrixs
	sizeX = 16;
	sizeW = 7;
	sizeZ = 6;
	sizeV = 6;

	// initialize matrix
	ukfInitMatrix();

	Rm = Re / (1 + 2 * e - 3 * e * sin(la * la));
	Rn = Re / (1 - e * sin(la * la));

	// Basic angular rate
	wiet[0] = 0;
	wiet[1] = wie * cos(la);
	wiet[2] = wie * sin(la);

	wett[0] = -v[1] / (Rm + alt);
	wett[1] = v[0] / (Rn + alt);
	wett[2] = v[0] / (Rn + alt) * tan(la);

	matPlus(witt, wiet, wett, 3, 1);

	matPlus(wiet_witt, wiet, witt, 3, 1);

	// Get matrix from platform coordinate to craft coordinate
	for (i = 0; i < 3; i++)
	{
		for (j = 0; j < 3; j++)
		{
			Cpb[i][j] = Ctb[i][j];
		}
	}

	// Get matrix from craft coordinate to platform coordinate
	matTranspose(Cbp, Cpb, 3, 3);


	// System error variance
	*(*Q + 0 * sizeW + 0) = 1e-12;
	*(*Q + 1 * sizeW + 1) = 1e-12;
	*(*Q + 2 * sizeW + 2) = 1e-12;
	*(*Q + 3 * sizeW + 3) = 1e-12;
	*(*Q + 4 * sizeW + 4) = imuErrorParam.accNoise[0] * imuErrorParam.accNoise[0];
	*(*Q + 5 * sizeW + 5) = imuErrorParam.accNoise[1] * imuErrorParam.accNoise[1];
	*(*Q + 6 * sizeW + 6) = imuErrorParam.accNoise[2] * imuErrorParam.accNoise[2];

	// Error variance transfer 
	*(*G + 0 * sizeW + 0) = 1;
	*(*G + 1 * sizeW + 1) = 1;
	*(*G + 2 * sizeW + 2) = 1;
	*(*G + 3 * sizeW + 3) = 1;
	*(*G + 4 * sizeW + 4) = Ctb[0][0];
	*(*G + 4 * sizeW + 5) = Ctb[1][0];
	*(*G + 4 * sizeW + 6) = Ctb[2][0];
	*(*G + 5 * sizeW + 4) = Ctb[0][1];
	*(*G + 5 * sizeW + 5) = Ctb[1][1];
	*(*G + 5 * sizeW + 6) = Ctb[2][1];
	*(*G + 6 * sizeW + 4) = Ctb[0][2];
	*(*G + 6 * sizeW + 5) = Ctb[1][2];
	*(*G + 6 * sizeW + 6) = Ctb[2][2];

	// Descrete matrix G     Ka = G * T
	matConstantMul(Ka, sizeX, sizeW, qlcukfParamOld.T, G, sizeX, sizeW);


	// Measurement matrix
	*(*H + 0 * sizeX + 4) = 1;
	*(*H + 1 * sizeX + 5) = 1;
	*(*H + 2 * sizeX + 6) = 1;
	*(*H + 3 * sizeX + 7) = 1;
	*(*H + 4 * sizeX + 8) = 1;
	*(*H + 5 * sizeX + 9) = 1;

	// Measurement error variance
	*(*R + 0 * sizeV + 0) = gnssErrorParam.vNoise[0] * gnssErrorParam.vNoise[0];
	*(*R + 1 * sizeV + 1) = gnssErrorParam.vNoise[1] * gnssErrorParam.vNoise[1];
	*(*R + 2 * sizeV + 2) = gnssErrorParam.vNoise[2] * gnssErrorParam.vNoise[2];
	*(*R + 3 * sizeV + 3) = (gnssErrorParam.pNoise[0] / (Rm + alt)) * (gnssErrorParam.pNoise[0] / (Rm + alt));
	*(*R + 4 * sizeV + 4) = (gnssErrorParam.pNoise[1] / (Rn + alt)) * (gnssErrorParam.pNoise[1] / (Rn + alt));
	*(*R + 5 * sizeV + 5) = gnssErrorParam.pNoise[2] * gnssErrorParam.pNoise[2];


	// Measurements matrix
	Z[0] = v[0] - gnssNavParam.v_enu[0];
	Z[1] = v[1] - gnssNavParam.v_enu[1];
	Z[2] = v[2] - gnssNavParam.v_enu[2];
	Z[3] = la -gnssNavParam.la;
	Z[4] = lon - gnssNavParam.lon;
	Z[5] = alt - gnssNavParam.alt;


	// Sigma point
	/*alpha = 0.5; // 1e-4 to 1
	beta = 2;
	ka = 0;
	lamda = alpha * alpha * (sizeX + ka) - sizeX;

	weightM[0] = lamda / (sizeX + lamda) + (1 - alpha * alpha + beta);
	weightC[0] = lamda / (sizeX + lamda);*/

	lamda = 1;
	weightM[0] = lamda / (sizeX + lamda);
	weightC[0] = lamda / (sizeX + lamda);
	for (i = 0; i < sizeX; i++)
	{
		XesSigma[0][i] = qlcukfParamOld.Xes[i];
	}

	matCholesky(upperTriMatrix, qlcukfParamOld.Pes, sizeX);

	for (i = 0; i < sizeX; i++)
	{
		weightM[i + 1] = 1 / (2 * (sizeX + lamda));
		weightM[i + 1 + sizeX] = 1 / (2 * (sizeX + lamda));

		weightC[i + 1] = weightM[i + 1];
		weightC[i + 1 + sizeX] = weightM[i + 1 + sizeX];

		for (j = 0; j < sizeX; j++)
		{
			XesSigma[i + 1][j] = qlcukfParamOld.Xes[j] + sqrt((sizeX + lamda)) * *(*upperTriMatrix + i * sizeX + j);
			XesSigma[i + 1 + sizeX][j] = qlcukfParamOld.Xes[j] - sqrt((sizeX + lamda)) * *(*upperTriMatrix + i * sizeX + j);
		}
	}


	// One step estimation: XesOneStep = sum(weightM * F(XesSigma))
	// One step measurements: ZesOneStep = sum(weightM * H(XesSigma))
	for (i = 0; i < 2 * sizeX + 1; i++)
	{
		// XesOneStep
		// RK4
		for (j = 0; j < 4; j++)
		{
			// Get Qtp
			for (k = 0; k < 4; k++)
			{
				if (j == 0)
				{
					Qtp[k] = XesSigma[i][k];
				}
				else if (j == 1)
				{
					Qtp[k] = XesSigma[i][k] + 1 / 2 * qlcukfParamOld.T * k_Qua[0][k];
				}
				else if (j == 2)
				{
					Qtp[k] = XesSigma[i][k] + 1 / 2 * qlcukfParamOld.T * k_Qua[1][k];
				}
				else
				{
					Qtp[k] = XesSigma[i][k] + qlcukfParamOld.T * k_Qua[2][k];
				}
			}
			QuaNorm = 0;
			for (k = 0; k < 4; k++)
			{
				QuaNorm += Qtp[k] * Qtp[k];
			}
			QuaNorm = sqrt(QuaNorm);
			for (k = 0; k < 4; k++)
			{
				Qtp[k] /= QuaNorm;
			}

			// Get deltaV
			for (k = 0; k < 3; k++)
			{
				if (j == 0)
				{
					deltaV[k] = XesSigma[i][k + 4];
				}
				else if (j == 1)
				{
					deltaV[k] = XesSigma[i][k + 4] + 1 / 2 * qlcukfParamOld.T * k_deltaV[0][k];
				}
				else if (j == 2)
				{
					deltaV[k] = XesSigma[i][k + 4] + 1 / 2 * qlcukfParamOld.T * k_deltaV[1][k];
				}
				else
				{
					deltaV[k] = XesSigma[i][k + 4] + qlcukfParamOld.T * k_deltaV[2][k];
				}
			}

			// Get deltaLa
			if (j == 0)
			{
				deltaLa = XesSigma[i][7];
			}
			else if (j == 1)
			{
				deltaLa = XesSigma[i][7] + 1 / 2 * qlcukfParamOld.T * k_deltaLa[0];
			}
			else if (j == 2)
			{
				deltaLa = XesSigma[i][7] + 1 / 2 * qlcukfParamOld.T * k_deltaLa[1];
			}
			else
			{
				deltaLa = XesSigma[i][7] + qlcukfParamOld.T * k_deltaLa[2];
			}

			// Get deltaLon
			if (j == 0)
			{
				deltaLon = XesSigma[i][8];
			}
			else if (j == 1)
			{
				deltaLon = XesSigma[i][8] + 1 / 2 * qlcukfParamOld.T * k_deltaLon[0];
			}
			else if (j == 2)
			{
				deltaLon = XesSigma[i][8] + 1 / 2 * qlcukfParamOld.T * k_deltaLon[1];
			}
			else
			{
				deltaLon = XesSigma[i][8] + qlcukfParamOld.T * k_deltaLon[2];
			}

			// Get deltaH
			if (j == 0)
			{
				deltaH = XesSigma[i][9];
			}
			else if (j == 1)
			{
				deltaH = XesSigma[i][9] + 1 / 2 * qlcukfParamOld.T * k_deltaH[0];
			}
			else if (j == 2)
			{
				deltaH = XesSigma[i][9] + 1 / 2 * qlcukfParamOld.T * k_deltaH[1];
			}
			else
			{
				deltaH = XesSigma[i][9] + qlcukfParamOld.T * k_deltaH[2];
			}



			// Qdot = B * (I - Ctp) * witt - B * Cbp * gyroDrift
			qlcukfGetBCtp(B, Ctp, Qtp);

			matMinus(matTemp1, eye3, Ctp, 3, 3);
			matMul(matTemp2, 4, 3, B, 4, 3, matTemp1, 3, 3);

			matMul(matTemp3, 4, 3, B, 4, 3, Cbp, 3, 3);

			matMul(matTemp1, 4, 1, matTemp2, 4, 3, witt, 3, 1);
			matMul(matTemp2, 4, 1, matTemp3, 4, 3, &XesSigma[i][10], 3, 1);
			matMinus(&k_Qua[j][0], matTemp1, matTemp2, 4, 1);



			// deltaVdot = (I - Cpt) * Cbp * fb - (2 * wiet + wett) X deltaV - (2 * deltawiet + deltawett) X V - (2 * deltawiet + deltawett) X deltaV + Cbp * accBias + deltagt
			delta_wiet[0] = 0;
			delta_wiet[1] = -wie * sin(la) * deltaLa;
			delta_wiet[2] = wie * cos(la) * deltaLa;

			delta_wett[0] = -1 / (Rm + alt) * deltaV[1] + \
				1 / (Rm + alt) / (Rm + alt) * v[1] * deltaH;
			delta_wett[1] = 1 / (Rn + alt) * deltaV[0] - \
				1 / (Rn + alt) / (Rn + alt) * v[0] * deltaH;
			delta_wett[2] = 1 / (Rn + alt) * tan(la) * deltaV[0] + \
				1 / (Rn + alt) / cos(la) / cos(la) * v[0] * deltaLa - \
				1 / (Rn + alt) / (Rn + alt) * tan(la) * v[0] * deltaH;

			matConstantMul(delta_wiet_witt, 2, delta_wiet, 3, 1);
			matPlus(delta_wiet_witt, delta_wiet_witt, delta_wett, 3, 1);
			// (I - Cpt) * Cbp * fb
			matTranspose(Cpt, Ctp, 3, 3);
			matMinus(matTemp1, eye3, Cpt, 3, 3);
			matMul(matTemp2, 3, 3, matTemp1, 3, 3, Cbp, 3, 3);
			matMul(matTemp1, 3, 1, matTemp2, 3, 3, measurements.f, 3, 1);
			// (2 * wiet + wett) X deltaV
			matVecCross(matTemp2, wiet_witt, deltaV);
			// (2 * deltawiet + deltawett) X V
			matVecCross(matTemp3, delta_wiet_witt, v);
			// (2 * deltawiet + deltawett) X deltaV
			matVecCross(matTemp4, delta_wiet_witt, deltaV);
			// Cbp * accBias
			matMul(matTemp5, 3, 1, Cbp, 3, 3, &XesSigma[i][13], 3, 1);

			matMinus(matTemp1, matTemp1, matTemp2, 3, 1);
			matMinus(matTemp1, matTemp1, matTemp3, 3, 1);
			matMinus(matTemp1, matTemp1, matTemp4, 3, 1);
			matPlus(&k_deltaV[j][0], matTemp1, matTemp5, 3, 1);


			// deltaladot = (1 / (Rm + h)) * deltaVn - (Vn / (Rm + h)^2) * deltah
			k_deltaLa[j] = (1 / (Rm + alt)) * deltaV[1] - \
				(v[1] / (Rm + alt) / (Rm + alt)) * deltaH;


			// deltalondot = (sec(la) / (Rn + h)) * deltaVe + (Ve * tan(la) * sec(la) / (Rn + h)) * deltala - (Ve * sec(la) / (Rm + h) ^ 2) * deltah
			k_deltaLon[j] = (1 / cos(la) / (Rn + alt)) * deltaV[0] + \
				(v[0] * tan(la) / cos(la) / (Rn + alt)) * deltaLa - \
				(v[0] / cos(la) / (Rm + alt) / (Rm + alt)) * deltaH;

			// deltahdot = deltaVu
			k_deltaH[j] = deltaV[2];

		} // for j, RK4


		XesSigmaOneStep[i][0] = XesSigma[i][0] + qlcukfParamOld.T / 6 * (k_Qua[0][0] + 2 * k_Qua[1][0] + 2 * k_Qua[2][0] + k_Qua[3][0]);
		XesSigmaOneStep[i][1] = XesSigma[i][1] + qlcukfParamOld.T / 6 * (k_Qua[0][1] + 2 * k_Qua[1][1] + 2 * k_Qua[2][1] + k_Qua[3][1]);
		XesSigmaOneStep[i][2] = XesSigma[i][2] + qlcukfParamOld.T / 6 * (k_Qua[0][2] + 2 * k_Qua[1][2] + 2 * k_Qua[2][2] + k_Qua[3][2]);
		XesSigmaOneStep[i][3] = XesSigma[i][3] + qlcukfParamOld.T / 6 * (k_Qua[0][3] + 2 * k_Qua[1][3] + 2 * k_Qua[2][3] + k_Qua[3][3]);
		QuaNorm = 0;
		for (k = 0; k < 4; k++)
		{
			QuaNorm += XesSigmaOneStep[i][k] * XesSigmaOneStep[i][k];
		}
		QuaNorm = sqrt(QuaNorm);
		for (k = 0; k < 4; k++)
		{
			XesSigmaOneStep[i][k] /= QuaNorm;
		}

		XesSigmaOneStep[i][4] = XesSigma[i][4] + qlcukfParamOld.T / 6 * (k_deltaV[0][0] + 2 * k_deltaV[1][0] + 2 * k_deltaV[2][0] + k_deltaV[3][0]);
		XesSigmaOneStep[i][5] = XesSigma[i][5] + qlcukfParamOld.T / 6 * (k_deltaV[0][1] + 2 * k_deltaV[1][1] + 2 * k_deltaV[2][1] + k_deltaV[3][1]);
		XesSigmaOneStep[i][6] = XesSigma[i][6] + qlcukfParamOld.T / 6 * (k_deltaV[0][2] + 2 * k_deltaV[1][2] + 2 * k_deltaV[2][2] + k_deltaV[3][2]);

		XesSigmaOneStep[i][7] = XesSigma[i][7] + qlcukfParamOld.T / 6 * (k_deltaLa[0] + 2 * k_deltaLa[1] + 2 * k_deltaLa[2] + k_deltaLa[3]);
		XesSigmaOneStep[i][8] = XesSigma[i][8] + qlcukfParamOld.T / 6 * (k_deltaLon[0] + 2 * k_deltaLon[1] + 2 * k_deltaLon[2] + k_deltaLon[3]);
		XesSigmaOneStep[i][9] = XesSigma[i][9] + qlcukfParamOld.T / 6 * (k_deltaH[0] + 2 * k_deltaH[1] + 2 * k_deltaH[2] + k_deltaH[3]);

		XesSigmaOneStep[i][10] = XesSigma[i][10];
		XesSigmaOneStep[i][11] = XesSigma[i][11];
		XesSigmaOneStep[i][12] = XesSigma[i][12];
		XesSigmaOneStep[i][13] = XesSigma[i][13];
		XesSigmaOneStep[i][14] = XesSigma[i][14];
		XesSigmaOneStep[i][15] = XesSigma[i][15];

		matConstantMul(matTemp1, weightM[i], &XesSigmaOneStep[i][0], sizeX, 1);

		matPlus(XesOneStep, XesOneStep, matTemp1, sizeX, 1);


		// ZesOneStep
		matMul(&ZesSigmaOneStep[i][0], sizeZ, 1, H, sizeZ, sizeX, &XesSigma[i][0], sizeX, 1);

		matConstantMul(matTemp1, weightM[i], &ZesSigmaOneStep[i][0], sizeZ, 1);
		matPlus(ZesOneStep, ZesOneStep, matTemp1, sizeZ, 1);

	} // Sigma points



	// One step estimation variance: PesOneStep = sum(weightC * (XesSigma - XesOneStep) * trans(XesSigma - XesOneStep)) + Ka * Q * Ka'
	// One step measurement variance: PzesOneStep = sum(weightC * (ZesSigma - ZesOneStep) * trans(ZesSigma - ZesOneStep)) + R
	// One step measurement variance: PxzesOneStep = sum(weightC * (XesSigma - XesOneStep) * trans(ZesSigma - ZesOneStep))
	for (i = 0; i < 2 * sizeX + 1; i++)
	{
		// PesOneStep accumulation
		matMinus(matTemp1, &XesSigmaOneStep[i][0], XesOneStep, sizeX, 1);
		matTranspose(matTemp2, matTemp1, 1, sizeX);
		matMul(matTemp3, sizeX, sizeX, matTemp1, sizeX, 1, matTemp2, 1, sizeX);
		matConstantMul(matTemp3, weightC[i], matTemp3, sizeX, sizeX);
		matPlus(PesOneStep, PesOneStep, matTemp3, sizeX, sizeX);


		// PzesOneStep accumulation
		matMinus(matTemp2, &ZesSigmaOneStep[i][0], ZesOneStep, sizeZ, 1);
		matTranspose(matTemp3, matTemp2, 1, sizeZ);
		matMul(matTemp4, sizeZ, sizeZ, matTemp2, sizeZ, 1, matTemp3, 1, sizeZ);
		matConstantMul(matTemp4, weightC[i], matTemp4, sizeZ, sizeZ);
		matPlus(PzesOneStep, PzesOneStep, matTemp4, sizeZ, sizeZ);


		// PxzesOneStep accumulation
		matMul(matTemp2, sizeX, sizeZ, matTemp1, sizeX, 1, matTemp3, 1, sizeZ);
		matConstantMul(matTemp2, weightC[i], matTemp2, sizeX, sizeZ);
		matPlus(PxzesOneStep, PxzesOneStep, matTemp2, sizeX, sizeZ);

	}
	// Calc PesOneStep
	matTranspose(matTemp1, Ka, sizeW, sizeX);
	matMul(matTemp2, sizeX, sizeW, Ka, sizeX, sizeW, Q, sizeW, sizeW);
	matMul(matTemp3, sizeX, sizeX, matTemp2, sizeX, sizeW, matTemp1, sizeW, sizeX);
	matPlus(PesOneStep, PesOneStep, matTemp3, sizeX, sizeX);
	// Calc PzesOneStep
	matPlus(PzesOneStep, PzesOneStep, R, sizeV, sizeV);


	// UKF gain K = PxzesOneStep * inv(PzesOneStep)
	matInv(matTemp1, PzesOneStep, sizeZ);
	matMul(K, sizeX, sizeZ, PxzesOneStep, sizeX, sizeZ, matTemp1, sizeZ, sizeZ);


	// Estimation Xes = XesOneStep + K * (Z - ZesOneStep)
	matMinus(matTemp1, Z, ZesOneStep, sizeZ, 1);
	matMul(matTemp2, sizeX, 1, K, sizeX, sizeZ, matTemp1, sizeZ, 1);
	matPlus(qlcukfParamNew.Xes, XesOneStep, matTemp2, sizeX, 1);


	// Estimation covariance Pes = PesOneStep - K * PzesOneStep * K'
	matTranspose(matTemp1, K, sizeZ, sizeX);
	matMul(matTemp2, sizeZ, sizeX, PzesOneStep, sizeZ, sizeZ, matTemp1, sizeZ, sizeX);
	matMul(matTemp1, sizeX, sizeX, K, sizeX, sizeZ, matTemp2, sizeZ, sizeX);
	matMinus(qlcukfParamNew.Pes, PesOneStep, matTemp1, sizeX, sizeX);


	return qlcukfParamNew;
}






// ***************************  Nonlinear KF *************************** //



/* Nonlinear KF parameter
% Xdot = F * X + G * W-->     X(k + 1) = Phi * X(k) + Ka * W
% Z = H(X) + V-->     Z(k) = H(X(k)) + V


% Xes: Estimation of system state
% Element : Tilt at east axis (rad)
%			Tilt at north axis
%           Tilt at up axis
%           Velocity error at east axis (m/s)
%			Velocity error at north axis
%           Velocity error at up axis
%           Latitude error (rad)
%			Longitude error
%           height error (m)
%			Gyroscope accNoise at east axis (rad/s)
%			Gyroscope accNoise at north axis
%           Gyroscope accNoise at up axis
%           Accelerometer accNoise at east axis (m/s^2)
%			Accelerometer accNoise at north axis
%           Accelerometer accNoise at up axis
%           GNSS receiver timer deviation caused position error (m)
%           GNSS receiver timer frequency drift caused velocity error (m/s)


% Q: Variance of System noise W
% Element : Gyroscope random error at east axis (rad/s)
%			Gyroscope random error at north axis
%        	Gyroscope random error at up axis
%       	Acceleration random error at east axis (m/s^2)
%			Acceleration random error at north axis
%        	Acceleration random error at up axis
%        	GNSS receiver timer frequency drift caused velocity error noise (m/s)


% Z: Observation
% Element : Channel 1 Pseudorange error (m)
%			Channel 2 Pseudorange error (m)
%			.
%			.
%			.
%			Channel n Pseudorange error (m)
%           Channel 1 Pseudorange rate error (m/s)
%           Channel 2 Pseudorange rate error (m/s)
%			.
%			.
%			.
%           Channel n Pseudorange rate error (m/s)



% R: Observation noise variance
% Element : Channel 1 Pseudorange noise (m)
%			Channel 2 Pseudorange noise (m)
%			.
%			.
%			.
%			Channel n Pseudorange noise (m)
%           Channel 1 Pseudorange rate noise (m/s)
%			.
%			.
%			.
%           Channel 2 Pseudorange rate noise (m/s)
%           Channel n Pseudorange rate noise (m/s)
*/

/*
	UKF Mesaurements
*/
int ukfGetZ(double Z[2], GNSS_NAV_PARAM gnssNavParam, int channelIndex)
{
	if ((channelIndex < 0) || (channelIndex > gnssNavParam.svNumber))
		return 1;

	// Transfer SINS location to earth x-y-z
	ex2 = (2 - e) * e / ((1 - e) * (1 - e));
	N = Re * sqrt(1 + ex2) / sqrt(1 + ex2 * cos(la) * cos(la));
	positionSINS[0] = (N + alt) * cos(la) * cos(lon);
	positionSINS[1] = (N + alt) * cos(la) * sin(lon);
	positionSINS[2] = ((1 - e) * (1 - e) * N + alt) * sin(la);


	// Transfer SINS velocity from E-N-U to X-Y-Z
	/*Cte[0][0] = -sin(pi / 2 + lon);
	Cte[0][1] = -sin(pi / 2 - la) * cos(pi / 2 + lon);
	Cte[0][2] = cos(pi / 2 - la) * cos(pi / 2 + lon);
	Cte[1][0] = cos(pi / 2 + lon);
	Cte[1][1] = -sin(pi / 2 - la) * sin(pi / 2 + lon);
	Cte[1][2] = cos(pi / 2 - la) * sin(pi / 2 + lon);
	Cte[2][0] = 0;
	Cte[2][1] = cos(pi / 2 - la);
	Cte[2][2] = sin(pi / 2 - la);*/

	Cte[0][0] = cos(pi / 2 + lon);
	Cte[0][1] = sin(pi / 2 + lon);
	Cte[0][2] = 0;
	Cte[1][0] = -cos(pi / 2 - la) * sin(pi / 2 + lon);
	Cte[1][1] = cos(pi / 2 - la) * cos(pi / 2 + lon);
	Cte[1][2] = sin(pi / 2 - la);
	Cte[2][0] = sin(pi / 2 - la) * sin(pi / 2 + lon);
	Cte[2][1] = -sin(pi / 2 - la) * cos(pi / 2 + lon);
	Cte[2][2] = cos(pi / 2 - la);

	venuSINS[0] = v[0];
	venuSINS[1] = v[1];
	venuSINS[2] = v[2];

	matMul(vxyzSINS, 3, 1, Cte, 3, 3, venuSINS, 3, 1);


	// Measurements
	pseudorangeSINS = 0;
	pseudorangeSINS += (positionSINS[0] - gnssNavParam.channel[channelIndex].p_xyz[0]) * (positionSINS[0] - gnssNavParam.channel[channelIndex].p_xyz[0]);
	pseudorangeSINS += (positionSINS[1] - gnssNavParam.channel[channelIndex].p_xyz[1]) * (positionSINS[1] - gnssNavParam.channel[channelIndex].p_xyz[1]);
	pseudorangeSINS += (positionSINS[2] - gnssNavParam.channel[channelIndex].p_xyz[2]) * (positionSINS[2] - gnssNavParam.channel[channelIndex].p_xyz[2]);
	pseudorangeSINS = sqrt(pseudorangeSINS);
	Z[0] = pseudorangeSINS - gnssNavParam.channel[channelIndex].pseu;

	pseudorangeRateSINS = 0;
	pseudorangeRateSINS += (positionSINS[0] - gnssNavParam.channel[channelIndex].p_xyz[0]) * (vxyzSINS[0] - gnssNavParam.channel[channelIndex].v_xyz[0]);
	pseudorangeRateSINS += (positionSINS[1] - gnssNavParam.channel[channelIndex].p_xyz[1]) * (vxyzSINS[1] - gnssNavParam.channel[channelIndex].v_xyz[1]);
	pseudorangeRateSINS += (positionSINS[2] - gnssNavParam.channel[channelIndex].p_xyz[2]) * (vxyzSINS[2] - gnssNavParam.channel[channelIndex].v_xyz[2]);
	pseudorangeRateSINS /= pseudorangeSINS;
	Z[1] = pseudorangeRateSINS - gnssNavParam.channel[channelIndex].pseuRate;

	return 0;
}



/*
	SINS GNSS tightly coupled UKF
*/
KF_PARAM ukf(KF_PARAM ukfParamOld,
	INS_NAV_PARAM sinsNavParam,
	GNSS_NAV_PARAM gnssNavParam,
	INS_MEASUREMENT measurements,
	IMU_ERROR_PARAM imuErrorParam,
	GNSS_ERROR_PARAM gnssErrorParam)
{
	KF_PARAM ukfParamNew = ukfParamOld;

	int i, j, k;

	svNumber = gnssNavParam.svNumber;

	// Initialize some matrixs
	sizeX = 17;
	sizeW = 7;
	sizeZ = 2 * svNumber;
	sizeV = 2 * svNumber;

	// initialize matrix
	ukfInitMatrix();

	// Get navigation parameters
	sinsSetNavParam(sinsNavParam);

	Rm = Re / (1 + 2 * e - 3 * e * sin(la * la));
	Rn = Re / (1 - e * sin(la * la));

	// Error transfer: From nav error to nav error
	*(*F + 0 * sizeX + 1) = (wie * sin(la) + v[0] / (Rn + alt) * tan(la));
	*(*F + 0 * sizeX + 2) = -(wie * cos(la) + v[0] / (Rn + alt));
	*(*F + 0 * sizeX + 4) = -(1 / (Rm + alt));

	*(*F + 1 * sizeX + 0) = -(wie * sin(la) + v[0] / (Rn + alt) * tan(la));
	*(*F + 1 * sizeX + 2) = -v[1] / (Rm + alt);
	*(*F + 1 * sizeX + 3) = 1 / (Rn + alt);
	*(*F + 1 * sizeX + 6) = -wie * sin(la);

	*(*F + 2 * sizeX + 0) = (wie * cos(la) + v[0] / (Rn + alt));
	*(*F + 2 * sizeX + 1) = v[1] / (Rm + alt);
	*(*F + 2 * sizeX + 3) = 1 / (Rn + alt) * tan(la);
	*(*F + 2 * sizeX + 6) = (wie * cos(la) + v[0] / ((Rn + alt) * cos(la) * cos(la)));

	*(*F + 3 * sizeX + 1) = -measurements.f[2];
	*(*F + 3 * sizeX + 2) = measurements.f[1];
	*(*F + 3 * sizeX + 3) = (v[1] / (Rm + alt) * tan(la) - v[2] / (Rm + alt));
	*(*F + 3 * sizeX + 4) = (2 * wie * sin(la) + v[0] / (Rn + alt));
	*(*F + 3 * sizeX + 5) = (2 * wie * cos(la) + v[0] / (Rn + alt));
	*(*F + 3 * sizeX + 6) = (2 * wie * cos(la) * v[1] + v[0] * v[1] / ((Rn + alt) * cos(la) * cos(la)) + 2 * wie * sin(la) * v[2]);

	*(*F + 4 * sizeX + 0) = measurements.f[2];
	*(*F + 4 * sizeX + 2) = -measurements.f[0];
	*(*F + 4 * sizeX + 3) = -2 * (wie * sin(la) + v[0] / (Rn + alt) * tan(la));
	*(*F + 4 * sizeX + 4) = -v[2] / (Rm + alt);
	*(*F + 4 * sizeX + 5) = -v[1] / (Rm + alt);
	*(*F + 4 * sizeX + 6) = -(2 * wie * cos(la) + v[0] / ((Rn + alt) * cos(la) * cos(la))) * v[0];

	*(*F + 5 * sizeX + 0) = -measurements.f[1];
	*(*F + 5 * sizeX + 1) = measurements.f[0];
	*(*F + 5 * sizeX + 3) = -2 * (wie * cos(la) + v[0] / (Rn + alt));
	*(*F + 5 * sizeX + 5) = 2 * v[1] / (Rm + alt);
	*(*F + 5 * sizeX + 6) = -2 * wie * sin(la) * v[0];

	*(*F + 6 * sizeX + 4) = 1 / (Rm + alt);

	*(*F + 7 * sizeX + 3) = 1 / ((Rn + alt) * cos(la));
	*(*F + 7 * sizeX + 6) = v[0] / ((Rn + alt) * cos(la)) * tan(la);

	*(*F + 8 * sizeX + 5) = 1;


	// Error transfer: From IMU error to nav error
	*(*F + 0 * sizeX + 9) = 1;

	*(*F + 1 * sizeX + 10) = 1;

	*(*F + 2 * sizeX + 11) = 1;

	*(*F + 3 * sizeX + 12) = 1;

	*(*F + 4 * sizeX + 13) = 1;

	*(*F + 5 * sizeX + 14) = 1;


	// Error transfer: From GNSS receiver error to GNSS receiver error
	*(*F + 15 * sizeX + 16) = 1;
	*(*F + 16 * sizeX + 16) = -1 / gnssErrorParam.timerDriftCorreTime;


	// Descrete the transfer matrix   Phi = eye(17) + F * T
	matConstantMul(Phi, ukfParamOld.T, F, sizeX, sizeX);
	matPlus(Phi, eye, Phi, sizeX, sizeX);


	// System error variance
	*(*Q + 0 * sizeW + 0) = imuErrorParam.gyroNoise[0] * imuErrorParam.gyroNoise[0];
	*(*Q + 1 * sizeW + 1) = imuErrorParam.gyroNoise[1] * imuErrorParam.gyroNoise[1];
	*(*Q + 2 * sizeW + 2) = imuErrorParam.gyroNoise[2] * imuErrorParam.gyroNoise[2];
	*(*Q + 3 * sizeW + 3) = imuErrorParam.accNoise[0] * imuErrorParam.accNoise[0];
	*(*Q + 4 * sizeW + 4) = imuErrorParam.accNoise[1] * imuErrorParam.accNoise[1];
	*(*Q + 5 * sizeW + 5) = imuErrorParam.accNoise[2] * imuErrorParam.accNoise[2];
	*(*Q + 6 * sizeW + 6) = gnssErrorParam.timerFrequencyDriftNoise * gnssErrorParam.timerFrequencyDriftNoise;

	// Error variance transfer 
	*(*G + 0 * sizeW + 0) = Ctb[0][0];
	*(*G + 0 * sizeW + 1) = Ctb[1][0];
	*(*G + 0 * sizeW + 2) = Ctb[2][0];
	*(*G + 1 * sizeW + 0) = Ctb[0][1];
	*(*G + 1 * sizeW + 1) = Ctb[1][1];
	*(*G + 1 * sizeW + 2) = Ctb[2][1];
	*(*G + 2 * sizeW + 0) = Ctb[0][2];
	*(*G + 2 * sizeW + 1) = Ctb[1][2];
	*(*G + 2 * sizeW + 2) = Ctb[2][2];

	*(*G + 3 * sizeW + 3) = Ctb[0][0];
	*(*G + 3 * sizeW + 4) = Ctb[1][0];
	*(*G + 3 * sizeW + 5) = Ctb[2][0];
	*(*G + 4 * sizeW + 3) = Ctb[0][1];
	*(*G + 4 * sizeW + 4) = Ctb[1][1];
	*(*G + 4 * sizeW + 5) = Ctb[2][1];
	*(*G + 5 * sizeW + 3) = Ctb[0][2];
	*(*G + 5 * sizeW + 4) = Ctb[1][2];
	*(*G + 5 * sizeW + 5) = Ctb[2][2];

	*(*G + 16 * sizeW + 6) = 1;

	

	// Descrete matrix G     Ka = (eye(17) * T + F * T ^ 2 / 2) * G
	matConstantMul(matTemp1, (ukfParamOld.T / 2), F, sizeX, sizeX);
	matPlus(matTemp1, eye, matTemp1, sizeX, sizeX);
	matConstantMul(matTemp1, ukfParamOld.T, matTemp1, sizeX, sizeX);
	matMul(Ka, sizeX, sizeW, matTemp1, sizeX, sizeX, G, sizeX, sizeW);



	// Measurement error variance
	for (i = 0; i < svNumber; i++)
	{
		*(*R + i * sizeV + i) = gnssErrorParam.pseuNoise * gnssErrorParam.pseuNoise;
		*(*R + (i + svNumber) * sizeV + i + svNumber) = gnssErrorParam.pseuRateNoise * gnssErrorParam.pseuRateNoise;
	}


	//******** UKF algorithm ********//
	// Get real measurements
	for (i = 0; i < svNumber; i++)
	{
		ukfGetZ(vecTemp1, gnssNavParam, i);
		Z[i] = vecTemp1[0];
		Z[i + svNumber] = vecTemp1[1];
	}
	

	// Sigma point
	/*alpha = 0.5; // 1e-4 to 1
	beta = 2;
	ka = 0;
	lamda = alpha * alpha * (sizeX + ka) - sizeX;

	weightM[0] = lamda / (sizeX + lamda) + (1 - alpha * alpha + beta);
	weightC[0] = lamda / (sizeX + lamda);*/

	lamda = 1;
	weightM[0] = lamda / (sizeX + lamda);
	weightC[0] = lamda / (sizeX + lamda);
	for (i = 0; i < sizeX; i++)
	{
		XesSigma[0][i] = ukfParamOld.Xes[i];
	}

	matCholesky(upperTriMatrix, ukfParamOld.Pes, sizeX);

	for (i = 0; i < sizeX; i++)
	{
		weightM[i + 1] = 1 / (2 * (sizeX + lamda));
		weightM[i + 1 + sizeX] = 1 / (2 * (sizeX + lamda));

		weightC[i + 1] = weightM[i + 1];
		weightC[i + 1 + sizeX] = weightM[i + 1 + sizeX];

		for (j = 0; j < sizeX; j++)
		{
			XesSigma[i + 1][j] = ukfParamOld.Xes[j] + sqrt((sizeX + lamda)) * *(*upperTriMatrix + i * sizeX + j);
			XesSigma[i + 1 + sizeX][j] = ukfParamOld.Xes[j] - sqrt((sizeX + lamda)) * *(*upperTriMatrix + i * sizeX + j);
		}
	}
	


	// One step estimation: XesOneStep = sum(weightM * Phi * XesSigma)
	for (i = 0; i < 2 * sizeX + 1; i++)
	{
		matMul(&XesSigmaOneStep[i][0], sizeX, 1, Phi, sizeX, sizeX, &XesSigma[i][0], sizeX, 1);

		matConstantMul(matTemp1, weightM[i], &XesSigmaOneStep[i][0], sizeX, 1);

		matPlus(XesOneStep, XesOneStep, matTemp1, sizeX, 1);
	}


	// Get sigma point of the XesOneStep (Only for UKF with additive noise)
	for (i = 0; i < 2 * sizeX + 1; i++)
	{
		for (j = 0; j < sizeX; j ++)
		{
			XesOneStepSigma[i][j] = XesSigmaOneStep[i][j];
		}
	}


	// One step measurements: ZesOneStep = sum(weightM * H(XesSigma))
	for (i = 0; i < 2 * sizeX + 1; i++)
	{
		// ZesOneStep
		v[0] = sinsNavParam.v[0] - XesOneStepSigma[i][3];
		v[1] = sinsNavParam.v[1] - XesOneStepSigma[i][4];
		v[2] = sinsNavParam.v[2] - XesOneStepSigma[i][5];
		la = sinsNavParam.la - XesOneStepSigma[i][6];
		lon = sinsNavParam.lon - XesOneStepSigma[i][7];
		alt = sinsNavParam.alt - XesOneStepSigma[i][8];

		for (j = 0; j < svNumber; j++)
		{
			ukfGetZ(vecTemp1, gnssNavParam, j);
			ZesSigmaOneStep[i][j] = vecTemp1[0];
			ZesSigmaOneStep[i][j + svNumber] = vecTemp1[1];
		}
		
		matConstantMul(matTemp1, weightM[i], &ZesSigmaOneStep[i][0], sizeZ, 1);
		matPlus(ZesOneStep, ZesOneStep, matTemp1, sizeZ, 1);
	}
	


	// One step estimation variance: PesOneStep = sum(weightC * (XesSigma - XesOneStep) * trans(XesSigma - XesOneStep)) + Ka * Q * Ka'
	// One step measurement variance: PzesOneStep = sum(weightC * (ZesSigma - ZesOneStep) * trans(ZesSigma - ZesOneStep)) + R
	// One step measurement variance: PxzesOneStep = sum(weightC * (XesSigma - XesOneStep) * trans(ZesSigma - ZesOneStep))
	for (i = 0; i < 2 * sizeX + 1; i++)
	{
		// PesOneStep accumulation
		matMinus(matTemp1, &XesSigmaOneStep[i][0], XesOneStep, sizeX, 1);
		matTranspose(matTemp2, matTemp1, 1, sizeX);
		matMul(matTemp3, sizeX, sizeX, matTemp1, sizeX, 1, matTemp2, 1, sizeX);
		matConstantMul(matTemp3, weightC[i], matTemp3, sizeX, sizeX);
		matPlus(PesOneStep, PesOneStep, matTemp3, sizeX, sizeX);


		// PzesOneStep accumulation
		matMinus(matTemp2, &ZesSigmaOneStep[i][0], ZesOneStep, sizeZ, 1);
		matTranspose(matTemp3, matTemp2, 1, sizeZ);
		matMul(matTemp4, sizeZ, sizeZ, matTemp2, sizeZ, 1, matTemp3, 1, sizeZ);
		matConstantMul(matTemp4, weightC[i], matTemp4, sizeZ, sizeZ);
		matPlus(PzesOneStep, PzesOneStep, matTemp4, sizeZ, sizeZ);


		// PxzesOneStep accumulation
		matMul(matTemp2, sizeX, sizeZ, matTemp1, sizeX, 1, matTemp3, 1, sizeZ);
		matConstantMul(matTemp2, weightC[i], matTemp2, sizeX, sizeZ);
		matPlus(PxzesOneStep, PxzesOneStep, matTemp2, sizeX, sizeZ);

	}
	// Calc PesOneStep
	matTranspose(matTemp1, Ka, sizeW, sizeX);
	matMul(matTemp2, sizeX, sizeW, Ka, sizeX, sizeW, Q, sizeW, sizeW);
	matMul(matTemp3, sizeX, sizeX, matTemp2, sizeX, sizeW, matTemp1, sizeW, sizeX);
	matPlus(PesOneStep, PesOneStep, matTemp3, sizeX, sizeX);
	// Calc PzesOneStep
	matPlus(PzesOneStep, PzesOneStep, R, sizeV, sizeV);
	

	// UKF gain K = PxzesOneStep * inv(PzesOneStep)
	matInv(matTemp1, PzesOneStep, sizeZ);
	matMul(K, sizeX, sizeZ, PxzesOneStep, sizeX, sizeZ, matTemp1, sizeZ, sizeZ);

	
	// Estimation Xes = XesOneStep + K * (Z - ZesOneStep)
	matMinus(matTemp1, Z, ZesOneStep, sizeZ, 1);
	matMul(matTemp2, sizeX, 1, K, sizeX, sizeZ, matTemp1, sizeZ, 1);
	matPlus(ukfParamNew.Xes, XesOneStep, matTemp2, sizeX, 1);
	

	// Estimation covariance Pes = PesOneStep - K * PzesOneStep * K'
	matTranspose(matTemp1, K, sizeZ, sizeX);
	matMul(matTemp2, sizeZ, sizeX, PzesOneStep, sizeZ, sizeZ, matTemp1, sizeZ, sizeX);
	matMul(matTemp3, sizeX, sizeX, K, sizeX, sizeZ, matTemp2, sizeZ, sizeX);
	matMinus(ukfParamNew.Pes, PesOneStep, matTemp3, sizeX, sizeX);

	return ukfParamNew;
}




// ***************************  H-infinity UKF *************************** //
/*
	SINS GNSS tightly coupled H-infinity UKF
*/
KF_PARAM hinfukf(KF_PARAM hinfukfParamOld,
	INS_NAV_PARAM sinsNavParam,
	GNSS_NAV_PARAM gnssNavParam,
	INS_MEASUREMENT measurements,
	IMU_ERROR_PARAM imuErrorParam,
	GNSS_ERROR_PARAM gnssErrorParam)
{
	KF_PARAM hinfukfParamNew = hinfukfParamOld;

	int i, j, k, l;

	svNumber = gnssNavParam.svNumber;

	// Initialize some matrixs
	sizeX = 17;
	sizeW = 7;
	sizeZ = 2 * svNumber;
	sizeV = 2 * svNumber;

	// initialize matrix
	ukfInitMatrix();

	// Get navigation parameters
	sinsSetNavParam(sinsNavParam);

	Rm = Re / (1 + 2 * e - 3 * e * sin(la * la));
	Rn = Re / (1 - e * sin(la * la));

	// Error transfer: From nav error to nav error
	*(*F + 0 * sizeX + 1) = (wie * sin(la) + v[0] / (Rn + alt) * tan(la));
	*(*F + 0 * sizeX + 2) = -(wie * cos(la) + v[0] / (Rn + alt));
	*(*F + 0 * sizeX + 4) = -(1 / (Rm + alt));

	*(*F + 1 * sizeX + 0) = -(wie * sin(la) + v[0] / (Rn + alt) * tan(la));
	*(*F + 1 * sizeX + 2) = -v[1] / (Rm + alt);
	*(*F + 1 * sizeX + 3) = 1 / (Rn + alt);
	*(*F + 1 * sizeX + 6) = -wie * sin(la);

	*(*F + 2 * sizeX + 0) = (wie * cos(la) + v[0] / (Rn + alt));
	*(*F + 2 * sizeX + 1) = v[1] / (Rm + alt);
	*(*F + 2 * sizeX + 3) = 1 / (Rn + alt) * tan(la);
	*(*F + 2 * sizeX + 6) = (wie * cos(la) + v[0] / ((Rn + alt) * cos(la) * cos(la)));

	*(*F + 3 * sizeX + 1) = -measurements.f[2];
	*(*F + 3 * sizeX + 2) = measurements.f[1];
	*(*F + 3 * sizeX + 3) = (v[1] / (Rm + alt) * tan(la) - v[2] / (Rm + alt));
	*(*F + 3 * sizeX + 4) = (2 * wie * sin(la) + v[0] / (Rn + alt));
	*(*F + 3 * sizeX + 5) = (2 * wie * cos(la) + v[0] / (Rn + alt));
	*(*F + 3 * sizeX + 6) = (2 * wie * cos(la) * v[1] + v[0] * v[1] / ((Rn + alt) * cos(la) * cos(la)) + 2 * wie * sin(la) * v[2]);

	*(*F + 4 * sizeX + 0) = measurements.f[2];
	*(*F + 4 * sizeX + 2) = -measurements.f[0];
	*(*F + 4 * sizeX + 3) = -2 * (wie * sin(la) + v[0] / (Rn + alt) * tan(la));
	*(*F + 4 * sizeX + 4) = -v[2] / (Rm + alt);
	*(*F + 4 * sizeX + 5) = -v[1] / (Rm + alt);
	*(*F + 4 * sizeX + 6) = -(2 * wie * cos(la) + v[0] / ((Rn + alt) * cos(la) * cos(la))) * v[0];

	*(*F + 5 * sizeX + 0) = -measurements.f[1];
	*(*F + 5 * sizeX + 1) = measurements.f[0];
	*(*F + 5 * sizeX + 3) = -2 * (wie * cos(la) + v[0] / (Rn + alt));
	*(*F + 5 * sizeX + 5) = 2 * v[1] / (Rm + alt);
	*(*F + 5 * sizeX + 6) = -2 * wie * sin(la) * v[0];

	*(*F + 6 * sizeX + 4) = 1 / (Rm + alt);

	*(*F + 7 * sizeX + 3) = 1 / ((Rn + alt) * cos(la));
	*(*F + 7 * sizeX + 6) = v[0] / ((Rn + alt) * cos(la)) * tan(la);

	*(*F + 8 * sizeX + 5) = 1;


	// Error transfer: From IMU error to nav error
	*(*F + 0 * sizeX + 9) = 1;

	*(*F + 1 * sizeX + 10) = 1;

	*(*F + 2 * sizeX + 11) = 1;

	*(*F + 3 * sizeX + 12) = 1;

	*(*F + 4 * sizeX + 13) = 1;

	*(*F + 5 * sizeX + 14) = 1;


	// Error transfer: From GNSS receiver error to GNSS receiver error
	*(*F + 15 * sizeX + 16) = 1;
	*(*F + 16 * sizeX + 16) = -1 / gnssErrorParam.timerDriftCorreTime;


	// Descrete the transfer matrix   Phi = eye(17) + F * T
	matConstantMul(Phi, hinfukfParamOld.T, F, sizeX, sizeX);
	matPlus(Phi, eye, Phi, sizeX, sizeX);


	// System error variance
	*(*Q + 0 * sizeW + 0) = imuErrorParam.gyroNoise[0] * imuErrorParam.gyroNoise[0];
	*(*Q + 1 * sizeW + 1) = imuErrorParam.gyroNoise[1] * imuErrorParam.gyroNoise[1];
	*(*Q + 2 * sizeW + 2) = imuErrorParam.gyroNoise[2] * imuErrorParam.gyroNoise[2];
	*(*Q + 3 * sizeW + 3) = imuErrorParam.accNoise[0] * imuErrorParam.accNoise[0];
	*(*Q + 4 * sizeW + 4) = imuErrorParam.accNoise[1] * imuErrorParam.accNoise[1];
	*(*Q + 5 * sizeW + 5) = imuErrorParam.accNoise[2] * imuErrorParam.accNoise[2];
	*(*Q + 6 * sizeW + 6) = gnssErrorParam.timerFrequencyDriftNoise * gnssErrorParam.timerFrequencyDriftNoise;

	// Error variance transfer 
	*(*G + 0 * sizeW + 0) = Ctb[0][0];
	*(*G + 0 * sizeW + 1) = Ctb[1][0];
	*(*G + 0 * sizeW + 2) = Ctb[2][0];
	*(*G + 1 * sizeW + 0) = Ctb[0][1];
	*(*G + 1 * sizeW + 1) = Ctb[1][1];
	*(*G + 1 * sizeW + 2) = Ctb[2][1];
	*(*G + 2 * sizeW + 0) = Ctb[0][2];
	*(*G + 2 * sizeW + 1) = Ctb[1][2];
	*(*G + 2 * sizeW + 2) = Ctb[2][2];

	*(*G + 3 * sizeW + 3) = Ctb[0][0];
	*(*G + 3 * sizeW + 4) = Ctb[1][0];
	*(*G + 3 * sizeW + 5) = Ctb[2][0];
	*(*G + 4 * sizeW + 3) = Ctb[0][1];
	*(*G + 4 * sizeW + 4) = Ctb[1][1];
	*(*G + 4 * sizeW + 5) = Ctb[2][1];
	*(*G + 5 * sizeW + 3) = Ctb[0][2];
	*(*G + 5 * sizeW + 4) = Ctb[1][2];
	*(*G + 5 * sizeW + 5) = Ctb[2][2];

	*(*G + 16 * sizeW + 6) = 1;



	// Descrete matrix G     Ka = (eye(17) * T + F * T ^ 2 / 2) * G
	matConstantMul(matTemp1, (hinfukfParamOld.T / 2), F, sizeX, sizeX);
	matPlus(matTemp1, eye, matTemp1, sizeX, sizeX);
	matConstantMul(matTemp1, hinfukfParamOld.T, matTemp1, sizeX, sizeX);
	matMul(Ka, sizeX, sizeW, matTemp1, sizeX, sizeX, G, sizeX, sizeW);



	// Measurement error variance
	for (i = 0; i < svNumber; i++)
	{
		*(*R + i * sizeV + i) = gnssErrorParam.pseuNoise * gnssErrorParam.pseuNoise;
		*(*R + (i + svNumber) * sizeV + i + svNumber) = gnssErrorParam.pseuRateNoise * gnssErrorParam.pseuRateNoise;
	}


	//******** UKF algorithm ********//
	// Get real measurements
	for (i = 0; i < svNumber; i++)
	{
		ukfGetZ(vecTemp1, gnssNavParam, i);
		Z[i] = vecTemp1[0];
		Z[i + svNumber] = vecTemp1[1];
	}


	// Sigma point
	/*alpha = 0.5; // 1e-4 to 1
	beta = 2;
	ka = 0;
	lamda = alpha * alpha * (sizeX + ka) - sizeX;

	weightM[0] = lamda / (sizeX + lamda) + (1 - alpha * alpha + beta);
	weightC[0] = lamda / (sizeX + lamda);*/

	lamda = 1;
	weightM[0] = lamda / (sizeX + lamda);
	weightC[0] = lamda / (sizeX + lamda);
	for (i = 0; i < sizeX; i++)
	{
		XesSigma[0][i] = hinfukfParamOld.Xes[i];
	}

	matCholesky(upperTriMatrix, hinfukfParamOld.Pes, sizeX);

	for (i = 0; i < sizeX; i++)
	{
		weightM[i + 1] = 1 / (2 * (sizeX + lamda));
		weightM[i + 1 + sizeX] = 1 / (2 * (sizeX + lamda));

		weightC[i + 1] = weightM[i + 1];
		weightC[i + 1 + sizeX] = weightM[i + 1 + sizeX];

		for (j = 0; j < sizeX; j++)
		{
			XesSigma[i + 1][j] = hinfukfParamOld.Xes[j] + sqrt((sizeX + lamda)) * *(*upperTriMatrix + i * sizeX + j);
			XesSigma[i + 1 + sizeX][j] = hinfukfParamOld.Xes[j] - sqrt((sizeX + lamda)) * *(*upperTriMatrix + i * sizeX + j);
		}
	}




	// One step estimation: XesOneStep = sum(weightM * Phi * XesSigma)
	// One step measurements: ZesOneStep = sum(weightM * H(XesSigma))
	for (i = 0; i < 2 * sizeX + 1; i++)
	{
		// XesOneStep
		matMul(&XesSigmaOneStep[i][0], sizeX, 1, Phi, sizeX, sizeX, &XesSigma[i][0], sizeX, 1);

		matConstantMul(matTemp1, weightM[i], &XesSigmaOneStep[i][0], sizeX, 1);

		matPlus(XesOneStep, XesOneStep, matTemp1, sizeX, 1);


		// ZesOneStep
		v[0] = sinsNavParam.v[0] - XesSigma[i][3];
		v[1] = sinsNavParam.v[1] - XesSigma[i][4];
		v[2] = sinsNavParam.v[2] - XesSigma[i][5];
		la = sinsNavParam.la - XesSigma[i][6];
		lon = sinsNavParam.lon - XesSigma[i][7];
		alt = sinsNavParam.alt - XesSigma[i][8];

		for (j = 0; j < svNumber; j++)
		{
			ukfGetZ(vecTemp1, gnssNavParam, j);
			ZesSigmaOneStep[i][j] = vecTemp1[0];
			ZesSigmaOneStep[i][j + svNumber] = vecTemp1[1];
		}

		matConstantMul(matTemp1, weightM[i], &ZesSigmaOneStep[i][0], sizeZ, 1);
		matPlus(ZesOneStep, ZesOneStep, matTemp1, sizeZ, 1);
	}



	// One step estimation variance: PesOneStep = sum(weightC * (XesSigma - XesOneStep) * trans(XesSigma - XesOneStep)) + Ka * Q * Ka'
	// One step measurement variance: PzesOneStep = sum(weightC * (ZesSigma - ZesOneStep) * trans(ZesSigma - ZesOneStep)) + R
	// One step measurement variance: PxzesOneStep = sum(weightC * (XesSigma - XesOneStep) * trans(ZesSigma - ZesOneStep))
	for (i = 0; i < 2 * sizeX + 1; i++)
	{
		// PesOneStep accumulation
		matMinus(matTemp1, &XesSigmaOneStep[i][0], XesOneStep, sizeX, 1);
		matTranspose(matTemp2, matTemp1, 1, sizeX);
		matMul(matTemp3, sizeX, sizeX, matTemp1, sizeX, 1, matTemp2, 1, sizeX);
		matConstantMul(matTemp3, weightC[i], matTemp3, sizeX, sizeX);
		matPlus(PesOneStep, PesOneStep, matTemp3, sizeX, sizeX);


		// PzesOneStep accumulation
		matMinus(matTemp2, &ZesSigmaOneStep[i][0], ZesOneStep, sizeZ, 1);
		matTranspose(matTemp3, matTemp2, 1, sizeZ);
		matMul(matTemp4, sizeZ, sizeZ, matTemp2, sizeZ, 1, matTemp3, 1, sizeZ);
		matConstantMul(matTemp4, weightC[i], matTemp4, sizeZ, sizeZ);
		matPlus(PzesOneStep, PzesOneStep, matTemp4, sizeZ, sizeZ);


		// PxzesOneStep accumulation
		matMul(matTemp2, sizeX, sizeZ, matTemp1, sizeX, 1, matTemp3, 1, sizeZ);
		matConstantMul(matTemp2, weightC[i], matTemp2, sizeX, sizeZ);
		matPlus(PxzesOneStep, PxzesOneStep, matTemp2, sizeX, sizeZ);

	}
	// Calc PesOneStep
	matTranspose(matTemp1, Ka, sizeW, sizeX);
	matMul(matTemp2, sizeX, sizeW, Ka, sizeX, sizeW, Q, sizeW, sizeW);
	matMul(matTemp3, sizeX, sizeX, matTemp2, sizeX, sizeW, matTemp1, sizeW, sizeX);
	matPlus(PesOneStep, PesOneStep, matTemp3, sizeX, sizeX);
	// Calc PzesOneStep
	matPlus(PzesOneStep, PzesOneStep, R, sizeV, sizeV);


	// UKF gain K = PxzesOneStep * inv(PzesOneStep)
	matInv(matTemp1, PzesOneStep, sizeZ);
	matMul(K, sizeX, sizeZ, PxzesOneStep, sizeX, sizeZ, matTemp1, sizeZ, sizeZ);


	// Estimation Xes = XesOneStep + K * (Z - ZesOneStep)
	matMinus(matTemp1, Z, ZesOneStep, sizeZ, 1);
	matMul(matTemp2, sizeX, 1, K, sizeX, sizeZ, matTemp1, sizeZ, 1);
	matPlus(hinfukfParamNew.Xes, XesOneStep, matTemp2, sizeX, 1);


	
	// Hktrans = inv(PesOneStep) * PxzesOneStep
	// gamma^2 = alphaHinf * max(eig(inv(inv(PesOneStep) + Hktrans * inv(R) * Hk)))
	matInv(PesOneStepInv, PesOneStep, sizeX);
	matMul(matTemp1, sizeX, sizeZ, PesOneStepInv, sizeX, sizeX, PxzesOneStep, sizeX, sizeZ);
	matTranspose(matTemp2, matTemp1, sizeZ, sizeX);
	matInv(matTemp3, R, sizeZ);
	matMul(matTemp4, sizeZ, sizeX, matTemp3, sizeZ, sizeZ, matTemp2, sizeZ, sizeX);
	matMul(matTemp2, sizeX, sizeX, matTemp1, sizeX, sizeZ, matTemp4, sizeZ, sizeX);
	matPlus(matTemp2, PesOneStepInv, matTemp2, sizeX, sizeX);
	matInv(matTemp1, matTemp2, sizeX);

	gamma = matEigenvalueMax(matTemp1, sizeX);
	alphaHinf = 200;
	gamma = gamma * alphaHinf;
	gamma = sqrt(gamma);

	// Get Pxzxx = [PxzesOneStep, PesOneStep]
	for (i = 0; i < sizeX; i++)
	{
		for (j = 0; j < sizeZ + sizeX; j++)
		{
			if (j < sizeZ)
			{
				*(*Pxzxx + i * (sizeZ + sizeX) + j) = *(*PxzesOneStep + i * sizeZ + j);
			}
			else
			{
				k = j - sizeZ;
				*(*Pxzxx + i * (sizeZ + sizeX) + j) = *(*PesOneStep + i * sizeX + k);
			}
		}
	}

	// Get Rek = [PzesOneStep, PxzesOneStep'; PxzesOneStep, PesOneStep - gamma^2 * I]
	matTranspose(matTemp1, PxzesOneStep, sizeZ, sizeX);
	for (i = 0; i < sizeZ + sizeX; i++)
	{
		for (j = 0; j < sizeZ + sizeX; j++)
		{
			if ((i < sizeZ) && (j < sizeZ))
			{
				*(*Rek + i * (sizeZ + sizeX) + j) = *(*PzesOneStep + i * sizeZ + j);
			}
			else if (i < sizeZ)
			{
				k = j - sizeZ;
				*(*Rek + i * (sizeZ + sizeX) + j) = *(*matTemp1 + i * sizeX + k);
			}
			else if (j < sizeZ)
			{
				k = i - sizeZ;
				*(*Rek + i * (sizeZ + sizeX) + j) = *(*PxzesOneStep + k * sizeZ + j);
			}
			else
			{
				k = i - sizeZ;
				l = j - sizeZ;
				*(*Rek + i * (sizeZ + sizeX) + j) = *(*PesOneStep + k * sizeX + l);
				if (i == j)
				{
					*(*Rek + i * (sizeZ + sizeX) + j) = *(*Rek + i * (sizeZ + sizeX) + j) - gamma * gamma;
				}
			}
		}
	}

	// Estimation covariance Pes = PesOneStep - Pxzxx * inv(Rek) * PxzxxTrans
	matInv(matTemp1, Rek, (sizeX + sizeZ));
	matTranspose(matTemp2, Pxzxx, (sizeX + sizeZ), sizeX);
	matMul(matTemp3, (sizeX + sizeZ), sizeX, matTemp1, (sizeX + sizeZ), (sizeX + sizeZ), matTemp2, (sizeX + sizeZ), sizeX);
	matMul(matTemp1, sizeX, sizeX, Pxzxx, sizeX, (sizeX + sizeZ), matTemp3, (sizeX + sizeZ), sizeX);
	matMinus(hinfukfParamNew.Pes, PesOneStep, matTemp1, sizeX, sizeX);

	return hinfukfParamNew;
}








// *************************** Quaternion based tightly coupled UKF *************************** //

/* Kalman Filter parameter
% Xdot = F(X) + G * W-->     X(k + 1) = F(X(k)) + Ka * W
% Z = H(X) + V-->     Z = H(X(k)) + V


% Xes: Estimation of system state
% Element : Quaternion element 1 (Ctp, from ideal navigation coordinate to platform coordinate / actual navigation coordinate)
%			Quaternion element 2
%			Quaternion element 3
%			Quaternion element 4
%           Velocity error at east axis(m / s)
%			Velocity error at north axis
%           Velocity error at up axis
%           Latitude error(rad)
%			Longitude error
%           height error(m)
%			Gyroscope accNoise at east axis(rad / s)
%			Gyroscope accNoise at north axis
%           Gyroscope accNoise at up axis
%           Accelerometer accNoise at east axis(m ^ 2 / s)
%			Accelerometer accNoise at north axis
%           Accelerometer accNoise at up axis
%           GNSS receiver timer deviation caused position error (m)
%           GNSS receiver timer frequency drift caused velocity error (m/s)


% Q: Variance of System noise W
% Element : Quaternion element 1 noise
%			Quaternion element 2 noise
%        	Quaternion element 3 noise
%        	Quaternion element 4 noise
%       	Acceleration random error at east axis(m / s ^ 2)
%			Acceleration random error at north axis
%        	Acceleration random error at up axis
%        	GNSS receiver timer frequency drift caused velocity error noise (m/s)


% Z: Observation
% Element : Pseudorange error (m)
%           Pseudorange rate error (m/s)



% R: Observation noise variance
% Element : Pseudorange noise (m)
%           Pseudorange rate noise (m/s)
*/

/*
	Quaternion based tightly coupled unscented Kalman filtering
*/
KF_PARAM qtcukf(KF_PARAM qtcukfParamOld,
	INS_NAV_PARAM sinsNavParam,
	GNSS_NAV_PARAM gnssNavParam,
	INS_MEASUREMENT measurements,
	IMU_ERROR_PARAM imuErrorParam,
	GNSS_ERROR_PARAM gnssErrorParam)
{
	KF_PARAM qtcukfParamNew = qtcukfParamOld;

	int i, j, k;

	svNumber = gnssNavParam.svNumber;

	// Initialize some matrixs
	sizeX = 18;
	sizeW = 8;
	sizeZ = 2 * svNumber;
	sizeV = 2 * svNumber;

	// initialize matrix
	ukfInitMatrix();

	// Set navigation parameters
	sinsSetNavParam(sinsNavParam);

	Rm = Re / (1 + 2 * e - 3 * e * sin(la * la));
	Rn = Re / (1 - e * sin(la * la));


	// Basic angular rate
	wiet[0] = 0;
	wiet[1] = wie * cos(la);
	wiet[2] = wie * sin(la);

	wett[0] = -v[1] / (Rm + alt);
	wett[1] = v[0] / (Rn + alt);
	wett[2] = v[0] / (Rn + alt) * tan(la);

	matPlus(witt, wiet, wett, 3, 1);

	matPlus(wiet_witt, wiet, witt, 3, 1);

	// Get matrix from platform coordinate to craft coordinate
	for (i = 0; i < 3; i++)
	{
		for (j = 0; j < 3; j++)
		{
			Cpb[i][j] = Ctb[i][j];
		}
	}

	// Get matrix from craft coordinate to platform coordinate
	matTranspose(Cbp, Cpb, 3, 3);


	// System error variance
	*(*Q + 0 * sizeW + 0) = 1e-12;
	*(*Q + 1 * sizeW + 1) = 1e-12;
	*(*Q + 2 * sizeW + 2) = 1e-12;
	*(*Q + 3 * sizeW + 3) = 1e-12;
	*(*Q + 4 * sizeW + 4) = imuErrorParam.accNoise[0] * imuErrorParam.accNoise[0];
	*(*Q + 5 * sizeW + 5) = imuErrorParam.accNoise[1] * imuErrorParam.accNoise[1];
	*(*Q + 6 * sizeW + 6) = imuErrorParam.accNoise[2] * imuErrorParam.accNoise[2];
	*(*Q + 7 * sizeW + 7) = gnssErrorParam.timerFrequencyDriftNoise * gnssErrorParam.timerFrequencyDriftNoise;

	// Error variance transfer 
	*(*G + 0 * sizeW + 0) = 1;
	*(*G + 1 * sizeW + 1) = 1;
	*(*G + 2 * sizeW + 2) = 1;
	*(*G + 3 * sizeW + 3) = 1;
	*(*G + 4 * sizeW + 4) = Ctb[0][0];
	*(*G + 4 * sizeW + 5) = Ctb[1][0];
	*(*G + 4 * sizeW + 6) = Ctb[2][0];
	*(*G + 5 * sizeW + 4) = Ctb[0][1];
	*(*G + 5 * sizeW + 5) = Ctb[1][1];
	*(*G + 5 * sizeW + 6) = Ctb[2][1];
	*(*G + 6 * sizeW + 4) = Ctb[0][2];
	*(*G + 6 * sizeW + 5) = Ctb[1][2];
	*(*G + 6 * sizeW + 6) = Ctb[2][2];
	*(*G + 17 * sizeW + 7) = 1;


	// Descrete matrix G     Ka = G * T
	matConstantMul(Ka, sizeX, sizeW, qtcukfParamOld.T, G, sizeX, sizeW);




	// Measurement error variance
	for (i = 0; i < svNumber; i++)
	{
		*(*R + i * sizeV + i) = gnssErrorParam.pseuNoise * gnssErrorParam.pseuNoise;
		*(*R + (i + svNumber) * sizeV + i + svNumber) = gnssErrorParam.pseuRateNoise * gnssErrorParam.pseuRateNoise;
	}


	//******** UKF algorithm ********//
	// Get real measurements
	for (i = 0; i < svNumber; i++)
	{
		ukfGetZ(vecTemp1, gnssNavParam, i);
		Z[i] = vecTemp1[0];
		Z[i + svNumber] = vecTemp1[1];
	}


	// Sigma point
	/*alpha = 0.5; // 1e-4 to 1
	beta = 2;
	ka = 0;
	lamda = alpha * alpha * (sizeX + ka) - sizeX;

	weightM[0] = lamda / (sizeX + lamda) + (1 - alpha * alpha + beta);
	weightC[0] = lamda / (sizeX + lamda);*/

	lamda = 1;
	weightM[0] = lamda / (sizeX + lamda);
	weightC[0] = lamda / (sizeX + lamda);
	for (i = 0; i < sizeX; i++)
	{
		XesSigma[0][i] = qtcukfParamOld.Xes[i];
	}

	matCholesky(upperTriMatrix, qtcukfParamOld.Pes, sizeX);

	for (i = 0; i < sizeX; i++)
	{
		weightM[i + 1] = 1 / (2 * (sizeX + lamda));
		weightM[i + 1 + sizeX] = 1 / (2 * (sizeX + lamda));
		for (j = 0; j < sizeX; j++)
		{
			XesSigma[i + 1][j] = qtcukfParamOld.Xes[j] + sqrt((sizeX + lamda)) * *(*upperTriMatrix + i * sizeX + j);
			XesSigma[i + 1 + sizeX][j] = qtcukfParamOld.Xes[j] - sqrt((sizeX + lamda)) * *(*upperTriMatrix + i * sizeX + j);
		}
	}




	// One step estimation: XesOneStep = sum(weightM * F(XesSigma))
	// One step measurements: ZesOneStep = sum(weightM * H(XesSigma))
	for (i = 0; i < 2 * sizeX + 1; i++)
	{
		// XesOneStep
		// RK4
		for (j = 0; j < 4; j++)
		{
			// Get Qtp
			for (k = 0; k < 4; k++)
			{
				if (j == 0)
				{
					Qtp[k] = XesSigma[i][k];
				}
				else if (j == 1)
				{
					Qtp[k] = XesSigma[i][k] + 1 / 2 * qtcukfParamOld.T * k_Qua[0][k];
				}
				else if (j == 2)
				{
					Qtp[k] = XesSigma[i][k] + 1 / 2 * qtcukfParamOld.T * k_Qua[1][k];
				}
				else
				{
					Qtp[k] = XesSigma[i][k] + qtcukfParamOld.T * k_Qua[2][k];
				}
			}
			QuaNorm = 0;
			for (k = 0; k < 4; k++)
			{
				QuaNorm += Qtp[k] * Qtp[k];
			}
			QuaNorm = sqrt(QuaNorm);
			for (k = 0; k < 4; k++)
			{
				Qtp[k] /= QuaNorm;
			}

			// Get deltaV
			for (k = 0; k < 3; k++)
			{
				if (j == 0)
				{
					deltaV[k] = XesSigma[i][k + 4];
				}
				else if (j == 1)
				{
					deltaV[k] = XesSigma[i][k + 4] + 1 / 2 * qtcukfParamOld.T * k_deltaV[0][k];
				}
				else if (j == 2)
				{
					deltaV[k] = XesSigma[i][k + 4] + 1 / 2 * qtcukfParamOld.T * k_deltaV[1][k];
				}
				else
				{
					deltaV[k] = XesSigma[i][k + 4] + qtcukfParamOld.T * k_deltaV[2][k];
				}
			}

			// Get deltaLa
			if (j == 0)
			{
				deltaLa = XesSigma[i][7];
			}
			else if (j == 1)
			{
				deltaLa = XesSigma[i][7] + 1 / 2 * qtcukfParamOld.T * k_deltaLa[0];
			}
			else if (j == 2)
			{
				deltaLa = XesSigma[i][7] + 1 / 2 * qtcukfParamOld.T * k_deltaLa[1];
			}
			else
			{
				deltaLa = XesSigma[i][7] + qtcukfParamOld.T * k_deltaLa[2];
			}

			// Get deltaLon
			if (j == 0)
			{
				deltaLon = XesSigma[i][8];
			}
			else if (j == 1)
			{
				deltaLon = XesSigma[i][8] + 1 / 2 * qtcukfParamOld.T * k_deltaLon[0];
			}
			else if (j == 2)
			{
				deltaLon = XesSigma[i][8] + 1 / 2 * qtcukfParamOld.T * k_deltaLon[1];
			}
			else
			{
				deltaLon = XesSigma[i][8] + qtcukfParamOld.T * k_deltaLon[2];
			}

			// Get deltaH
			if (j == 0)
			{
				deltaH = XesSigma[i][9];
			}
			else if (j == 1)
			{
				deltaH = XesSigma[i][9] + 1 / 2 * qtcukfParamOld.T * k_deltaH[0];
			}
			else if (j == 2)
			{
				deltaH = XesSigma[i][9] + 1 / 2 * qtcukfParamOld.T * k_deltaH[1];
			}
			else
			{
				deltaH = XesSigma[i][9] + qtcukfParamOld.T * k_deltaH[2];
			}

			// Get gnssErrorP
			if (j == 0)
			{
				gnssErrorP = XesSigma[i][16];
			}
			else if (j == 1)
			{
				gnssErrorP = XesSigma[i][16] + 1 / 2 * qtcukfParamOld.T * k_gnssErrorP[0];
			}
			else if (j == 2)
			{
				gnssErrorP = XesSigma[i][16] + 1 / 2 * qtcukfParamOld.T * k_gnssErrorP[1];
			}
			else
			{
				gnssErrorP = XesSigma[i][16] + qtcukfParamOld.T * k_gnssErrorP[2];
			}

			// Get gnssErrorV
			if (j == 0)
			{
				gnssErrorV = XesSigma[i][17];
			}
			else if (j == 1)
			{
				gnssErrorV = XesSigma[i][17] + 1 / 2 * qtcukfParamOld.T * k_gnssErrorV[0];
			}
			else if (j == 2)
			{
				gnssErrorV = XesSigma[i][17] + 1 / 2 * qtcukfParamOld.T * k_gnssErrorV[1];
			}
			else
			{
				gnssErrorV = XesSigma[i][17] + qtcukfParamOld.T * k_gnssErrorV[2];
			}



			// Qdot = B * (I - Ctp) * witt - B * Cbp * gyroDrift
			qlcukfGetBCtp(B, Ctp, Qtp);

			matMinus(matTemp1, eye3, Ctp, 3, 3);
			matMul(matTemp2, 4, 3, B, 4, 3, matTemp1, 3, 3);

			matMul(matTemp3, 4, 3, B, 4, 3, Cbp, 3, 3);

			matMul(matTemp1, 4, 1, matTemp2, 4, 3, witt, 3, 1);
			matMul(matTemp2, 4, 1, matTemp3, 4, 3, &XesSigma[i][10], 3, 1);
			matMinus(&k_Qua[j][0], matTemp1, matTemp2, 4, 1);



			// deltaVdot = (I - Cpt) * Cbp * fb - (2 * wiet + wett) X deltaV - (2 * deltawiet + deltawett) X V - (2 * deltawiet + deltawett) X deltaV + Cbp * accBias + deltagt
			delta_wiet[0] = 0;
			delta_wiet[1] = -wie * sin(la) * deltaLa;
			delta_wiet[2] = wie * cos(la) * deltaLa;

			delta_wett[0] = -1 / (Rm + alt) * deltaV[1] + \
				1 / (Rm + alt) / (Rm + alt) * v[1] * deltaH;
			delta_wett[1] = 1 / (Rn + alt) * deltaV[0] - \
				1 / (Rn + alt) / (Rn + alt) * v[0] * deltaH;
			delta_wett[2] = 1 / (Rn + alt) * tan(la) * deltaV[0] + \
				1 / (Rn + alt) / cos(la) / cos(la) * v[0] * deltaLa - \
				1 / (Rn + alt) / (Rn + alt) * tan(la) * v[0] * deltaH;

			matConstantMul(delta_wiet_witt, 2, delta_wiet, 3, 1);
			matPlus(delta_wiet_witt, delta_wiet_witt, delta_wett, 3, 1);
			// (I - Cpt) * Cbp * fb
			matTranspose(Cpt, Ctp, 3, 3);
			matMinus(matTemp1, eye3, Cpt, 3, 3);
			matMul(matTemp2, 3, 3, matTemp1, 3, 3, Cbp, 3, 3);
			matMul(matTemp1, 3, 1, matTemp2, 3, 3, measurements.f, 3, 1);
			// (2 * wiet + wett) X deltaV
			matVecCross(matTemp2, wiet_witt, deltaV);
			// (2 * deltawiet + deltawett) X V
			matVecCross(matTemp3, delta_wiet_witt, v);
			// (2 * deltawiet + deltawett) X deltaV
			matVecCross(matTemp4, delta_wiet_witt, deltaV);
			// Cbp * accBias
			matMul(matTemp5, 3, 1, Cbp, 3, 3, &XesSigma[i][13], 3, 1);

			matMinus(matTemp1, matTemp1, matTemp2, 3, 1);
			matMinus(matTemp1, matTemp1, matTemp3, 3, 1);
			matMinus(matTemp1, matTemp1, matTemp4, 3, 1);
			matPlus(&k_deltaV[j][0], matTemp1, matTemp5, 3, 1);


			// deltaladot = (1 / (Rm + h)) * deltaVn - (Vn / (Rm + h)^2) * deltah
			k_deltaLa[j] = (1 / (Rm + alt)) * deltaV[1] - \
				(v[1] / (Rm + alt) / (Rm + alt)) * deltaH;


			// deltalondot = (sec(la) / (Rn + h)) * deltaVe + (Ve * tan(la) * sec(la) / (Rn + h)) * deltala - (Ve * sec(la) / (Rm + h) ^ 2) * deltah
			k_deltaLon[j] = (1 / cos(la) / (Rn + alt)) * deltaV[0] + \
				(v[0] * tan(la) / cos(la) / (Rn + alt)) * deltaLa - \
				(v[0] / cos(la) / (Rm + alt) / (Rm + alt)) * deltaH;

			// deltahdot = deltaVu
			k_deltaH[j] = deltaV[2];

			// gnssErrorPdot = gnssErrorVdot
			k_gnssErrorP[j] = gnssErrorV;

			// gnssErrorVdot = -1 / timerDriftCorreTime * gnssErrorVdot
			k_gnssErrorV[j] = -1 / gnssErrorParam.timerDriftCorreTime * gnssErrorV;

		} // for j, RK4


		XesSigmaOneStep[i][0] = XesSigma[i][0] + qtcukfParamOld.T / 6 * (k_Qua[0][0] + 2 * k_Qua[1][0] + 2 * k_Qua[2][0] + k_Qua[3][0]);
		XesSigmaOneStep[i][1] = XesSigma[i][1] + qtcukfParamOld.T / 6 * (k_Qua[0][1] + 2 * k_Qua[1][1] + 2 * k_Qua[2][1] + k_Qua[3][1]);
		XesSigmaOneStep[i][2] = XesSigma[i][2] + qtcukfParamOld.T / 6 * (k_Qua[0][2] + 2 * k_Qua[1][2] + 2 * k_Qua[2][2] + k_Qua[3][2]);
		XesSigmaOneStep[i][3] = XesSigma[i][3] + qtcukfParamOld.T / 6 * (k_Qua[0][3] + 2 * k_Qua[1][3] + 2 * k_Qua[2][3] + k_Qua[3][3]);
		QuaNorm = 0;
		for (k = 0; k < 4; k++)
		{
			QuaNorm += XesSigmaOneStep[i][k] * XesSigmaOneStep[i][k];
		}
		QuaNorm = sqrt(QuaNorm);
		for (k = 0; k < 4; k++)
		{
			XesSigmaOneStep[i][k] /= QuaNorm;
		}

		XesSigmaOneStep[i][4] = XesSigma[i][4] + qtcukfParamOld.T / 6 * (k_deltaV[0][0] + 2 * k_deltaV[1][0] + 2 * k_deltaV[2][0] + k_deltaV[3][0]);
		XesSigmaOneStep[i][5] = XesSigma[i][5] + qtcukfParamOld.T / 6 * (k_deltaV[0][1] + 2 * k_deltaV[1][1] + 2 * k_deltaV[2][1] + k_deltaV[3][1]);
		XesSigmaOneStep[i][6] = XesSigma[i][6] + qtcukfParamOld.T / 6 * (k_deltaV[0][2] + 2 * k_deltaV[1][2] + 2 * k_deltaV[2][2] + k_deltaV[3][2]);

		XesSigmaOneStep[i][7] = XesSigma[i][7] + qtcukfParamOld.T / 6 * (k_deltaLa[0] + 2 * k_deltaLa[1] + 2 * k_deltaLa[2] + k_deltaLa[3]);
		XesSigmaOneStep[i][8] = XesSigma[i][8] + qtcukfParamOld.T / 6 * (k_deltaLon[0] + 2 * k_deltaLon[1] + 2 * k_deltaLon[2] + k_deltaLon[3]);
		XesSigmaOneStep[i][9] = XesSigma[i][9] + qtcukfParamOld.T / 6 * (k_deltaH[0] + 2 * k_deltaH[1] + 2 * k_deltaH[2] + k_deltaH[3]);

		XesSigmaOneStep[i][10] = XesSigma[i][10];
		XesSigmaOneStep[i][11] = XesSigma[i][11];
		XesSigmaOneStep[i][12] = XesSigma[i][12];
		XesSigmaOneStep[i][13] = XesSigma[i][13];
		XesSigmaOneStep[i][14] = XesSigma[i][14];
		XesSigmaOneStep[i][15] = XesSigma[i][15];

		XesSigmaOneStep[i][16] = XesSigma[i][16] + qtcukfParamOld.T / 6 * (k_gnssErrorP[0] + 2 * k_gnssErrorP[1] + 2 * k_gnssErrorP[2] + k_gnssErrorP[3]);
		XesSigmaOneStep[i][17] = XesSigma[i][17] + qtcukfParamOld.T / 6 * (k_gnssErrorV[0] + 2 * k_gnssErrorV[1] + 2 * k_gnssErrorV[2] + k_gnssErrorV[3]);

		matConstantMul(matTemp1, weightM[i], &XesSigmaOneStep[i][0], sizeX, 1);

		matPlus(XesOneStep, XesOneStep, matTemp1, sizeX, 1);


	} // Sigma points


	// Get sigma point of the XesOneStep (Only for UKF with additive noise)
	for (i = 0; i < 2 * sizeX + 1; i++)
	{
		for (j = 0; j < sizeX; j++)
		{
			XesOneStepSigma[i][j] = XesSigmaOneStep[i][j];
		}
	}


	// One step estimation: XesOneStep = sum(weightM * Phi * XesSigma)
	for (i = 0; i < 2 * sizeX + 1; i++)
	{
		// ZesOneStep
		v[0] = sinsNavParam.v[0] - XesOneStepSigma[i][4];
		v[1] = sinsNavParam.v[1] - XesOneStepSigma[i][5];
		v[2] = sinsNavParam.v[2] - XesOneStepSigma[i][6];
		la = sinsNavParam.la - XesOneStepSigma[i][7];
		lon = sinsNavParam.lon - XesOneStepSigma[i][8];
		alt = sinsNavParam.alt - XesOneStepSigma[i][9];

		for (j = 0; j < svNumber; j++)
		{
			ukfGetZ(vecTemp1, gnssNavParam, j);
			ZesSigmaOneStep[i][j] = vecTemp1[0];
			ZesSigmaOneStep[i][j + svNumber] = vecTemp1[1];
		}

		matConstantMul(matTemp1, weightM[i], &ZesSigmaOneStep[i][0], sizeZ, 1);
		matPlus(ZesOneStep, ZesOneStep, matTemp1, sizeZ, 1);
	}


	// One step estimation variance: PesOneStep = sum(weightC * (XesSigma - XesOneStep) * trans(XesSigma - XesOneStep)) + Ka * Q * Ka'
	// One step measurement variance: PzesOneStep = sum(weightC * (ZesSigma - ZesOneStep) * trans(ZesSigma - ZesOneStep)) + R
	// One step measurement variance: PxzesOneStep = sum(weightC * (XesSigma - XesOneStep) * trans(ZesSigma - ZesOneStep))
	for (i = 0; i < 2 * sizeX + 1; i++)
	{
		// PesOneStep accumulation
		matMinus(matTemp1, &XesSigmaOneStep[i][0], XesOneStep, sizeX, 1);
		matTranspose(matTemp2, matTemp1, 1, sizeX);
		matMul(matTemp3, sizeX, sizeX, matTemp1, sizeX, 1, matTemp2, 1, sizeX);
		matConstantMul(matTemp3, weightC[i], matTemp3, sizeX, sizeX);
		matPlus(PesOneStep, PesOneStep, matTemp3, sizeX, sizeX);


		// PzesOneStep accumulation
		matMinus(matTemp2, &ZesSigmaOneStep[i][0], ZesOneStep, sizeZ, 1);
		matTranspose(matTemp3, matTemp2, 1, sizeZ);
		matMul(matTemp4, sizeZ, sizeZ, matTemp2, sizeZ, 1, matTemp3, 1, sizeZ);
		matConstantMul(matTemp4, weightC[i], matTemp4, sizeZ, sizeZ);
		matPlus(PzesOneStep, PzesOneStep, matTemp4, sizeZ, sizeZ);


		// PxzesOneStep accumulation
		matMul(matTemp2, sizeX, sizeZ, matTemp1, sizeX, 1, matTemp3, 1, sizeZ);
		matConstantMul(matTemp2, weightC[i], matTemp2, sizeX, sizeZ);
		matPlus(PxzesOneStep, PxzesOneStep, matTemp2, sizeX, sizeZ);

	}
	// Calc PesOneStep
	matTranspose(matTemp1, Ka, sizeW, sizeX);
	matMul(matTemp2, sizeX, sizeW, Ka, sizeX, sizeW, Q, sizeW, sizeW);
	matMul(matTemp3, sizeX, sizeX, matTemp2, sizeX, sizeW, matTemp1, sizeW, sizeX);
	matPlus(PesOneStep, PesOneStep, matTemp3, sizeX, sizeX);
	// Calc PzesOneStep
	matPlus(PzesOneStep, PzesOneStep, R, sizeV, sizeV);


	// UKF gain K = PxzesOneStep * inv(PzesOneStep)
	matInv(matTemp1, PzesOneStep, sizeZ);
	matMul(K, sizeX, sizeZ, PxzesOneStep, sizeX, sizeZ, matTemp1, sizeZ, sizeZ);


	// Estimation Xes = XesOneStep + K * (Z - ZesOneStep)
	matMinus(matTemp1, Z, ZesOneStep, sizeZ, 1);
	matMul(matTemp2, sizeX, 1, K, sizeX, sizeZ, matTemp1, sizeZ, 1);
	matPlus(qtcukfParamNew.Xes, XesOneStep, matTemp2, sizeX, 1);


	// Estimation covariance Pes = PesOneStep - K * PzesOneStep * K'
	matTranspose(matTemp1, K, sizeZ, sizeX);
	matMul(matTemp2, sizeZ, sizeX, PzesOneStep, sizeZ, sizeZ, matTemp1, sizeZ, sizeX);
	matMul(matTemp3, sizeX, sizeX, K, sizeX, sizeZ, matTemp2, sizeZ, sizeX);
	matMinus(qtcukfParamNew.Pes, PesOneStep, matTemp3, sizeX, sizeX);


	return qtcukfParamNew;
}