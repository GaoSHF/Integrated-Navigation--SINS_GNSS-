#include <stdlib.h>
#include <math.h>
#include "matrix.h"

#include <stdio.h>

/**
 ** Matrix C = A + B
 **/
int matPlus(double *C, double *A, double *B, int rowC, int columC){
	int i, j;
	// Return 0 when there is problem in row or colum
	if((rowC <= 0) || (columC <= 0))
		return 1;

	for(i = 0; i < rowC; i ++)
		for(j = 0; j < columC; j ++)
			*(C + i * columC + j) = *(A + i * columC + j) + *(B + i * columC + j);
	return 0;
}

/**
 ** Matrix C = A - B
 **/
int matMinus(double *C, double *A, double *B, int rowC, int columC){
	int i, j;
	// Return 0 when there is problem in row or colum
	if((rowC <= 0) || (columC <= 0))
		return 1;

	for(i = 0; i < rowC; i ++)
		for(j = 0; j < columC; j ++)
			*(C + i * columC + j) = *(A + i * columC + j) - *(B + i * columC + j);
	return 0;
}

/**
 ** Matrix C equals the transposition of matrix A
 **/
int matTranspose(double *C, double *A, int rowC, int columC){
	int i, j;

	double *temp = NULL;

	// Return 0 when there is problem in row or colum
	if((rowC <= 0) || (columC <= 0))
		return 1;

	if(C != A) {
		for(i = 0; i < rowC; i ++)
			for(j = 0; j < columC; j ++)
				*(C + i * columC + j) = *(A + j * rowC + i);
	}
	else {
		temp = (double *)malloc((rowC * columC) * sizeof(double));

		for(i = 0; i < rowC; i ++)
			for(j = 0; j < columC; j ++)
				*(temp + i * columC + j) = *(A + j * rowC + i);

		for(i = 0; i < rowC; i ++)
			for (j = 0; j < columC; j++)
				*(C + i * columC + j) = *(temp + i * columC + j);

		free(temp);
	}

	return 0;
}

/**
 ** Matrix C equals constant k mutiplies matrix A
 **/
int matConstantMul(double *C, double k, double *A, int rowC, int columC)
{
	int i, j;
	// Return 0 when there is problem in row or colum
	if((rowC <= 0) || (columC <= 0))
		return 1;

	for(i = 0; i < rowC; i ++)
		for(j = 0; j < columC; j ++)
			*(C + i * columC + j) = k * *(A + i * columC + j);
	return 0;
}

/**
 ** Matrix C equals matrix A mutiplies matrix B
 **/
int matMul(double *C, int rowC, int columC,
			double *A, int rowA, int columA,
			double *B, int rowB, int columB)
{
	int i, j, k;
	double *temp = NULL;
	// Return 0 when there is problem in row or colum
	if((rowC <= 0) || (columC <= 0) ||\
		(rowA <=0) || (columA <= 0) ||\
		(rowB <=0) || (columB <= 0) ||\
		(columA != rowB) ||\
		(rowA != rowC) || (columB != columC))
		return 1;

	if((C == A) || (C == B)){
		temp = (double *)malloc((rowC * columC) * sizeof(double));
		for(i = 0; i < rowC; i ++)
		for(j = 0; j < columC; j ++){
			*(temp + i * columC +j) = 0;
			for(k = 0; k < columA; k ++)
				*(temp + i * columC + j) += \
				*(A + i * columA + k) * *(B + k * columB + j);
		}
		for(i = 0; i < rowC; i ++)
			for(j = 0; j < columC; j ++)
				*(C + i * columC + j) = *(temp + i * columC + j);
		free(temp);
	}
	else{
		for(i = 0; i < rowC; i ++)
		for(j = 0; j < columC; j ++){
			*(C + i * columC +j) = 0;
			for(k = 0; k < columA; k ++)
				*(C + i * columC + j) += \
				*(A + i * columA + k) * *(B + k * columB + j);
		}
	}
	return 0;
}

/**
 ** Square matrix C(n x n) equals A(n x n) ^ m
 **/
int matPower(double *C, double *A, int n, int m)
{
	int i, j;
	double *temp = NULL;
	// Return 0 when there is problem in row or colum
	if(n <= 0)
		return 1;

	temp = (double *)malloc((n * n) * sizeof(double));
	for(i = 0; i < n; i ++)
		for(j = 0; j < n; j ++)
			*(temp + i * n + j) = *(A + i * n + j);
	for(i = 0; i < m - 1; i ++)
		matMul(temp, n, n, temp, n, n, A, n, n);
	for(i = 0; i < n; i ++)
		for(j = 0; j < n; j ++)
			*(C + i * n + j) = *(temp + i * n + j);
	free(temp);
	return 0;
}

/**
 ** Calculate determinant of square matrix A(n x n)
 **/
double matDet(double *A, int n)
{
	double det;
	int i, j, k, temp_i, counter = 0, zero = 0;
	double temp_a;
	double *temp = NULL;
	// Return 0 when there is problem in row or colum
	if(n <= 0)
		return 1;

	temp = (double *)malloc((n * n) * sizeof(double));
	for(i = 0; i < n; i ++)
		for(j = 0; j < n; j ++)
			*(temp + i * n + j) = *(A + i * n + j);

	// Gauss method
	for(k = 0; k < n - 1; k ++){
		// Find the maximum a(i, k), i = k, k + 1, ... , n-1
		temp_a = *(temp + k * n + k);
		temp_i = k;
		for(i = k + 1; i < n; i ++){
			if(fabs(*(temp + i * n + k)) > fabs(temp_a)){
				temp_a = *(temp + i * n + k);
				temp_i = i;
			}
		}
		// Break if all element is zero
		if(temp_a == 0){
			zero = 1;
			break;
		}
		// Exchange a(k,k) and a(temp_i, k)
		if(temp_i != k){
			for(j = k; j < n; j ++){
				temp_a = *(temp + temp_i * n + j);
				*(temp + temp_i * n + j) = *(temp + k * n + j);
				*(temp + k * n + j) = temp_a;
			}
			counter ++;
		}
		// Eliminate row i by row k
		for(i = k + 1; i < n; i ++){
			for(j = k + 1; j < n; j ++){
				*(temp + i * n + j) = *(temp + i * n + j) - \
					*(temp + i * n + k) / *(temp + k * n + k) * *(temp + k * n + j);
			}
		}
	}

	if((*(temp + k * n + k) == 0) || (zero == 1))
		det = 0;
	else{
		// Multiply diagonal elements
		det = 1.0;
		for(k = 0; k < n; k ++)
			det *= *(temp + k * n + k);
		// Multiply -1 ^ counter, counter is the exchange numbers
		det *= (((counter % 2) == 0) ? 1 : (- 1));
	}
	free(temp);
	return det;
}

/**
 ** Calculate inversion of square matrix A(n x n)
 **/
int matInv(double *C, double *A, int n)
{
	int i, j, k, temp_i, zero = 0;
	double temp_a;
	double *temp = NULL;
	// Return 0 when there is problem in n
	if(n <= 0)
		return 1;

	temp = (double *)malloc((2 * n * n) * sizeof(double));
	// Make matrix (A|I)
	for(i = 0; i < n; i ++)
		for(j = 0; j < n; j ++)
			*(temp + i * 2 * n + j) = *(A + i * n + j);
	for(i = 0; i < n; i ++)
		for(j = n; j < 2 * n; j ++){
			if((j - i) == n)
				*(temp + i * 2 * n + j) = 1;
			else
				*(temp + i * 2 * n + j) = 0;
		}
	// Gauss-Jordan method
	// Make the left side of (A|I) to be a tri-matrix
	for(k = 0; k < n - 1; k ++){
		// Find the maximum a(i, k), i = k, k + 1, ... , n-1
		temp_a = *(temp + k * 2 * n + k);
		temp_i = k;
		for(i = k + 1; i < n; i ++){
			if(fabs(*(temp + i * 2 * n + k)) > fabs(temp_a)){
				temp_a = *(temp + i * 2 * n + k);
				temp_i = i;
			}
		}
		// Break if all element in a colum is zero (The matrix has no inversion)
		if(temp_a == 0){
			zero = 1;
			break;
		}
		// Exchange a(k,k) and a(temp_i, k)
		if(temp_i != k){
			for(j = k; j < 2 * n; j ++){
				temp_a = *(temp + temp_i * 2 * n + j);
				*(temp + temp_i * 2 * n + j) = *(temp + k * 2 * n + j);
				*(temp + k * 2 * n + j) = temp_a;
			}
		}
		// Eliminate row i by row k
		for(i = k + 1; i < n; i ++){
			for(j = k + 1; j < 2 * n; j ++){
				*(temp + i * 2 * n + j) = *(temp + i * 2 * n + j) - \
					*(temp + i * 2 * n + k) / *(temp + k * 2 * n + k) * *(temp + k * 2 * n + j);
			}
		}
		// Make element a(k, k) = 1, k = 0, 1, ... , n-2 (Need another operation at n-1)
		for(j = 2 * n - 1; j >= k; j --)
			*(temp + k * 2 * n + j) /= *(temp + k * 2 * n + k);
	}
	// return 2 if the input matrix has no inversion
	if((*(temp + k * 2 * n + k) == 0) || (zero == 1)){
		free(temp);
		return 2;
	}
	else{
		// Make element a(n-1, n-1) = 1
		for(j = 2 * n - 1; j >= n - 1; j --)
			*(temp + (n - 1) * 2 * n + j) /= *(temp + (n - 1) * 2 * n + k);
		// Make the left side to be matrix I, then the right is the answer
		for(k = n - 1; k > 0; k --){
			for(i = k - 1; i >= 0; i --){
				for(j = 2 * n - 1; j >= k; j --){
					*(temp + i * 2 * n + j) -= *(temp + k * 2 * n + j) * *(temp + i * 2 * n + k);
				}
			}
		}
		// Get the right side
		for(i = 0; i < n; i ++)
			for(j = 0; j < n; j ++)
				*(C + i * n + j) = *(temp + i * 2 * n + j + n);
	}
	free(temp);
	return 0;
}


/*
	Orthogonal triangle Decomposition (QR decomposition) of matrix A: 
	A(m x n) = Q(m x m) * [R(n x n), zeros(m-1, n)]'   (m >= n)
	A has rank of n
	Q is a orthogonal matrix
	R is a upper triangular matrix
 */
int matQR(double *Q, double *R, double *A, int m, int n)
{
	int i, j, k;

	double *orth = NULL;
	double *orthUnit = NULL;

	double innerProduct1;
	double innerProduct2;

	double sum;
	double mod;


	
	orth = (double *)malloc(m * n * sizeof(double));
	orthUnit = (double *)malloc(m * n * sizeof(double));

	// Vector orthogonal
	for (k = 0; k < n; k++)
	{
		for (i = 0; i < m; i++)
		{
			*(orth + i * n + k) = *(A + i * n + k);
		}
		
		for (j = 0; j <= k - 1; j++)
		{
			innerProduct1 = 0;
			innerProduct2 = 0;
			for (i = 0; i < m; i++)
			{
				innerProduct1 += *(A + i * n + k) * *(orth + i * n + j);
				innerProduct2 += *(orth + i * n + j) * *(orth + i * n + j);
			}
			for (i = 0; i < m; i++)
			{
				*(orth + i * n + k) -= innerProduct1 / innerProduct2 * *(orth + i * n + j);
			}
		}
	}
	// Vector unit
	for (j = 0; j < n; j++)
	{
		sum = 0;
		for (i = 0; i < m; i++)
		{
			sum += *(orth + i * n + j) * *(orth + i * n + j);
		}
		mod = sqrt(sum);
		for (i = 0; i < m; i++)
		{
			*(orthUnit + i * n + j) = *(orth + i * n + j) / mod;
		}
	}



	// Q
	for (j = 0; j < n; j++)
	{
		for (i = 0; i < m; i++)
		{
			*(Q + i * n + j) = *(orthUnit + i * n + j);
		}
	}

	// R
	for (j = 0; j < n; j++)
	{
		for (i = 0; i < n; i++)
		{
			// Diagonal elements
			if (i == j)
			{
				sum = 0;
				for (k = 0; k < n; k++)
				{
					sum += *(orth + k * n + j) * *(orth + k * n + j);
				}
				mod = sqrt(sum);
				*(R + i * n + j) = mod;
			}
			// Upper triangle elements
			else if (i < j)
			{
				sum = 0;
				for (k = 0; k < n; k++)
				{
					sum += *(A + k * n + j) * *(orthUnit + k * n + i);
				}
				*(R + i * n + j) = sum;
			}
			// Lower triangle elements
			else
			{
				*(R + i * n + j) = 0;
			}
		}
	}



	free(orth);
	free(orthUnit);

	return 0;
}

/*
	Cholesky Decomposition of matrix A:
	U' * U = A
	A is Asymmetrical half orthogonal matrix
	U is a upper triangular matrix
*/
int matCholesky(double *U, double *A, int n)
{
	int i, j, k;

	double sum;


	if (U == A)
		return 1;

	for (i = 0; i < n; i++)
	{
		for (j = 0; j < n; j++)
		{
			// Diagonal elements
			if (i == j)
			{
				sum = 0;
				for (k = 0; k <= i - 1; k++)
				{
					sum += *(U + k * n + i) * *(U + k * n + i);
				}
				*(U + i * n + i) = sqrt(*(A + i * n + i) - sum);
			}
			// Upper triangle elements
			else if (i < j)
			{
				sum = 0;
				for (k = 0; k <= i - 1; k++)
				{
					sum += *(U + k * n + i) * *(U + k * n + j);
				}
				sum = *(A + i * n + j) - sum;
				*(U + i * n + j) = sum / *(U + i * n + i);
			}
			// Lower triangle elements
			else
			{
				*(U + i * n + j) = 0;
			}
		}
	}


	return 0;
}


/*
	Cholesky update
	S = chol(U' * U + weight * x * x')
	x(n x columX)
*/
int matCholupdate(double *S, double *U, double *x, int weight, int n, int columX)
{

	int i, j;

	double *L = (double *)malloc(n * n * sizeof(double));
	double *xtrans = (double *)malloc(columX * n * sizeof(double));

	double *A = (double *)malloc(n * n * sizeof(double));
	double *X = (double *)malloc(n * n * sizeof(double));

	double *StransS = (double *)malloc(n * n * sizeof(double));

	// A = U' * U
	matTranspose(L, U, n, n);
	matMul(A, n, n, L, n, n, U, n, n);

	// X = x * x'
	matTranspose(xtrans, x, columX, n);
	matMul(X, n, n, x, n, columX, xtrans, columX, n);

	// weight * X
	matConstantMul(X, weight, X, n, n);

	// S' * S = A + weight * X
	matPlus(StransS, A, X, n, n);

	matCholesky(S, StransS, n);

	free(L);
	free(xtrans);
	free(A);
	free(X);
	free(StransS);

	return 0;
}


/*
	Calculate the eigenvalue which has maximum norm of matrix A
*/
double matEigenvalueMaxNorm(double *A, int n)
{
	double eigenMaxNorm;

	int i, j;

	double *vector = NULL;
	double *vectorUnit = NULL;

	double vectorNorm = 0;

	double eigenTempOld = 0;
	double eigenTempNew = 0;

	vector = (double *)malloc(n * sizeof(double));
	vectorUnit = (double *)malloc(n * sizeof(double));

	// Initialize vector with un-zero value
	for (i = 0; i < n; i++)
		*(vector + i) = 1;

	do
	{
		// Get unit vector
		vectorNorm = 0;
		for (i = 0; i < n; i++)
		{
			vectorNorm += *(vector + i) * *(vector + i);
		}
		vectorNorm = sqrt(vectorNorm);
		for (i = 0; i < n; i++)
		{
			*(vectorUnit + i) = *(vector + i) / vectorNorm;
		}

		// Get new vector
		for (i = 0; i < n; i++)
		{
			*(vector + i) = 0;
			for (j = 0; j < n; j++)
			{
				*(vector + i) += *(A + i * n + j) * *(vectorUnit + j);
			}	
		}

		// Get new temporary eigenvalue
		eigenTempOld = eigenTempNew;
		eigenTempNew = 0;
		for (i = 0; i < n; i++)
		{
			eigenTempNew += *(vectorUnit + i) * *(vector + i);
		}

	} while (fabs(eigenTempNew - eigenTempOld) / fabs(eigenTempNew) > 1e-15);

	free(vector);
	free(vectorUnit);

	eigenMaxNorm = eigenTempNew;
	return eigenMaxNorm;
}

/*
	Calculate the maximum eigenvalue of matrix A
*/
double matEigenvalueMax(double *A, int n)
{
	double eigenMax;
	int i, j;

	double eigenMaxNorm;

	double *B = NULL;

	eigenMaxNorm = matEigenvalueMaxNorm(A, n);

	if (eigenMaxNorm > 0)
	{
		eigenMax = eigenMaxNorm;
	}
	else
	{
		B = (double *) malloc(n * n * sizeof(double));

		for (i = 0; i < n; i++)
		{
			for (j = 0; j < n; j++)
			{
				*(B + i * n + j) = *(A + i * n + j) - eigenMaxNorm;
			}
		}
		eigenMaxNorm = matEigenvalueMaxNorm(B, n);
		eigenMax = eigenMaxNorm;

		free(B);
	}

	return eigenMax;
}


/*
	vector3 = vector1 X vector2
 */
int matVecCross(double *vector3, double *vector1, double *vector2)
{

	double matrix[3][3] = { 0 };

	matrix[0][0] = 0;
	matrix[0][1] = -*(vector1 + 2);
	matrix[0][2] = *(vector1 + 1);

	matrix[1][0] = *(vector1 + 2);
	matrix[1][1] = 0;
	matrix[1][2] = -*(vector1 + 0);

	matrix[2][0] = -*(vector1 + 1);
	matrix[2][1] = *(vector1 + 0);
	matrix[2][2] = 0;

	matMul(vector3, 3, 1, matrix, 3, 3, vector2, 3, 1);

	return 0;
}

