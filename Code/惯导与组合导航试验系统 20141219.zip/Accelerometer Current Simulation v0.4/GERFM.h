#ifndef _GERFM_H_
#define _GERFM_H_

#include <visa.h>

#define LED_ON    1
#define LED_OFF   0

#define OPERATE_READ 1
#define OPERATE_WRITE 0 


#define ADD_OFFSET(addr,offs) ((ViPByte)(addr) + (offs))//

/* Definition of the rfm2g_nic (Network Interrupt Command) register         */
#define RFM2G_NIC_RSTREQ    (0x00)   /* Reset Node Request Command          */
#define RFM2G_NIC_INT1      (0x01)   /* Net Int 1                           */
#define RFM2G_NIC_INT2      (0x02)   /* Net Int 2                           */
#define RFM2G_NIC_INT3      (0x03)   /* Net Int 3                           */
#define RFM2G_NIC_RSVD      (0x04)   /* Reserved, used for OWN test         */
#define RFM2G_NIC_INITINT   (0x07)   /* Net Initialized Int                 */
#define RFM2G_NIC_GLOBAL    (0x08)   /* Global Command bit                  */


/* Offsets of Runtime Registers                                              */
#define  rfmor_intcsr      0x68         /* Interrupt control and status      */
#define  rfmor_cntrl       0x6c         /* Control                           */
#define  rfmor_revision    0x74         /* RFM2g Revision                    */
#define  rfmor_DmaMode0    0x80         /* DMA Channel 0 Mode                */
#define  rfmor_DmaPciAddr0 0x84         /* DMA Channel 0 PCI Address         */
#define  rfmor_DmaLocAddr0 0x88         /* DMA Channel 0 Local Address       */
#define  rfmor_DmaCount0   0x8c         /* DMA Channel 0 Transfer Byte Count */
#define  rfmor_DmaPtr0     0x90         /* DMA Channel 0 Descriptor Pointer  */
#define  rfmor_Dma0Csr     0xa8         /* DMA Command / Status Register     */
#define  rfmor_Dma1Csr     0xa9         /* DMA Command / Status Register     */
#define  rfmor_DmaArb      0xac         /* Mode / DMA Arbitration            */
#define  rfmor_DmaThresh   0xb0         /* DMA Threshold                     */
#define  rfmor_DmaDac0     0xb4         /* DMA Channel 0 PCI Dual Access Cyc */
#define  rfmor_lbrd0       0x18         /* Local Address Space 0             */
#define  rfmor_endian_desc 0x0C         /* Endian                            */
#define  rfmor_las1rr      0xf0         /* Local Addr Space 1 Range Register */
#define  rfmor_las1ba      0xf4         /* Local Addr Space 1 Base Address   */


/* Offsets of memory space registers that are common to all supported boards */
#define  rfm2g_brv         0x00      /* Board Revision / Model               */
#define  rfm2g_bid         0x01      /* Board ID register (ro)               */
#define  rfm2g_build_id    0x02      /* Build ID register (ro)               */
#define  rfm2g_nid         0x04      /* Node ID register (ro)                */
#define  rfm2g_lcsr        0x08      /* Local control and status register    */
#define  rfm2g_lisr        0x10      /* Local interrupt status register      */
#define  rfm2g_lier        0x14      /* Local interrupt enable register      */
#define  rfm2g_ntd         0x18      /* Network Target Data                  */
#define  rfm2g_ntn         0x1c      /* Network Target Node                  */
#define  rfm2g_nic         0x1d      /* Network Interrupt Command            */
#define  rfm2g_isd1        0x20      /* INT1 Sender Data                     */
#define  rfm2g_sid1        0x24      /* INT1 Sender ID                       */
#define  rfm2g_isd2        0x28      /* INT2 Sender Data                     */
#define  rfm2g_sid2        0x2c      /* INT2 Sender ID                       */
#define  rfm2g_isd3        0x30      /* INT3 Sender Data                     */
#define  rfm2g_sid3        0x34      /* INT3 Sender ID                       */
#define  rfm2g_initd       0x38      /* Initialized Node Data                */
#define  rfm2g_initn       0x3c      /* Initialized Node ID                  */

#define  RFM2G_REGSIZE     0x40      /* Space reserved for registers         */

/* Definition of the rfm2g_bid (board ID) register for supported boards      */
#define  RFM2G_BID_5565    0x65      /* VMIPMC-5565                          */

/* Provide Type Definitions for basic portable types*/
typedef unsigned char           GERFM_UINT8;
typedef unsigned short		    GERFM_UINT16;
typedef unsigned long           GERFM_UINT32;

typedef signed char             GERFM_INT8;
typedef signed short	        GERFM_INT16;
typedef signed long             GERFM_INT32;

typedef unsigned char           GERFM_BOOL;



typedef struct 
{
	ViSession GERFM_defaultRM;
	ViSession GERFM_instr;
	
	ViSession MEMACC_defaultRM;
	ViSession MEMACC_instr;	
	ViSession MEMACC_bytecount;
	ViSession MEMACC_memoffset;
	ViAddr 	  Map_addr;

}GERFM_DevHandle;

int GERFM_OpenDevice(GERFM_DevHandle *phDev);
int GERFM_CloseDevice(GERFM_DevHandle *phDev);
int GERFM_ReadModWrite32(GERFM_DevHandle hDev,ViUInt16 pxi_space,GERFM_UINT32 offset,GERFM_UINT32 bit_mask,GERFM_UINT32 value);
int GERFM_SetLED(GERFM_DevHandle hDev,GERFM_BOOL state);
int GERFM_GetLED(GERFM_DevHandle hDev,GERFM_BOOL* pState);
int GERFM_GetNodeID(GERFM_DevHandle hDev,ViUInt8* NodeID);
int GERFM_EnableDMA(GERFM_DevHandle *phDev,GERFM_UINT32 transize,GERFM_BOOL operatestate);
int GERFM_DisableDMA(GERFM_DevHandle *phDev);
int GERFM_DMA_Write(GERFM_DevHandle hDev,GERFM_UINT32 offset,ViUInt8 buffer[]);
int GERFM_DMA_Read(GERFM_DevHandle hDev,GERFM_UINT32 offset,ViUInt8 buffer[]);
int GERFM_SendEvent(GERFM_DevHandle hDev,ViUInt8 target_node,ViUInt32 user_data,ViUInt8 event_type);
int GERFM_EnableEventCallback(GERFM_DevHandle *phDev,ViUInt8 event_type,ViHndlr pEventFunc);
int GERFM_DisableEventCallback(GERFM_DevHandle hDev,ViUInt8 event_type);


#endif
