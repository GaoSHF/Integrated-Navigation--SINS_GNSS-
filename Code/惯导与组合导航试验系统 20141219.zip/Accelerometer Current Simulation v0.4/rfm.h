//==============================================================================
//
// Title:       rfm.h
// Purpose:     A short description of the interface.
//
// Created on:  2013/12/16 at 10:06:34 by ZhaoHengyang.
// Copyright:   Beihang University. All Rights Reserved.
//
//==============================================================================

#ifndef __rfm_H__
#define __rfm_H__

#ifdef __cplusplus
    extern "C" {
#endif

//==============================================================================
// Include files

#include "cvidef.h"
#include "GERFM.h"

//==============================================================================
// Constants
#define	RFM_NODE_MC	8
#define	RFM_NODE_ROTARY	3
		
		
#define	RFM_CMD_MC_NULL		-1
#define	RFM_CMD_MC_START	8
#define	RFM_CMD_MC_STOP		4
#define	RFM_CMD_MC_IMU		3

#define	RFM_DATA_DOUBLE_SIZE	6
#define	RFM_DATA_UINT8_SIZE		(sizeof(double) * RFM_DATA_DOUBLE_SIZE)
		
		
#define	RFM_ROTARY_CMD_SIZE	32
#define	RFM_ROTARY_STATUS_SIZE	32
		
		
//==============================================================================
// Types
typedef struct
{
	unsigned char cmdFlag;
	unsigned char cmdCode;
	unsigned char cmdParamLength;
	unsigned char cmdParamCheck;
	unsigned char cmdParam[RFM_ROTARY_CMD_SIZE - 4];
}RFM_ROTARY_CMD;

typedef struct
{
	unsigned char statusFlag;
	unsigned char statusCode;
	unsigned char statusParamLength;
	unsigned char statusParamCheck;
	unsigned char statusParam[RFM_ROTARY_STATUS_SIZE - 4];
}RFM_ROTARY_STATUS;
		
		
//==============================================================================
// External variables
extern int RFMMCThreadEnd;

extern int RFMMCIntRcv;


extern double DataDoubleTx[RFM_DATA_DOUBLE_SIZE];
extern double DataDoubleRx[RFM_DATA_DOUBLE_SIZE];
extern char DataUInt8Tx[RFM_DATA_UINT8_SIZE];
extern char DataUInt8Rx[RFM_DATA_UINT8_SIZE];



extern RFM_ROTARY_CMD		RFMStructCmd;
extern RFM_ROTARY_STATUS 	RFMStructStatus;


extern GERFM_DevHandle GERFM_hDev;


//==============================================================================
// Global functions
int rfmOpenDev(void);
int rfmCloseDev(void);

int rfmEnableDMA(void); 
int rfmDisableDMA(void); 


int rfmStartMC (void);
int rfmStopMC (void);



int rfmInitMC(void);
int rfmCloseMC(void);
int rfmInitDS(void);
int rfmCloseDS(void);


int rfmIMU(double *w, double *f);

int rfmRotaryClimb(float *initAngle, float *initRate, float *initAngleGet, float *initRateGet, int step);
int rfmRotaryTrack(float *angle, float *rate, float *angleGet, float *rateGet);





#ifdef __cplusplus
    }
#endif

#endif  /* ndef __rfm_H__ */
