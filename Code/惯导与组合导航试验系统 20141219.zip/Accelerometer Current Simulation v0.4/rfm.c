//==============================================================================
//
// Title:       rfm.c
// Purpose:     A short description of the implementation.
//
// Created on:  2013/12/16 at 10:06:34 by ZhaoHengyang.
// Copyright:   Beihang University. All Rights Reserved.
//
//==============================================================================

//==============================================================================
// Include files

#include <utility.h>
#include <ansi_c.h>
#include <visa.h>

#include "rfm.h"
#include "common.h"

//==============================================================================
// Constants

//==============================================================================
// Types

//==============================================================================
// Static global variables

//==============================================================================
// Static functions

//==============================================================================
// Global variables
int RFMMCThreadEnd = 0;

int RFMMCIntRcv = RFM_CMD_MC_NULL;



double DataDoubleTx[RFM_DATA_DOUBLE_SIZE];
double DataDoubleRx[RFM_DATA_DOUBLE_SIZE];
char DataUInt8Tx[RFM_DATA_UINT8_SIZE] = {2,4,2,3,4,5,6,7,8,9};
char DataUInt8Rx[RFM_DATA_UINT8_SIZE];




RFM_ROTARY_CMD		RFMStructCmd;
RFM_ROTARY_STATUS 	RFMStructStatus;



GERFM_DevHandle GERFM_hDev;



//==============================================================================
// Global functions

/// HIFN  What does your function do?
/// HIPAR x/What inputs does your function expect?
/// HIRET What does your function return?








/*
	��ʼ���ز���
 */
int rfmStartMC(void)
{
	int status;
	
	//if (GERFM_hDev == NULL)
	//	status = GERFM_OpenDevice(&GERFM_hDev);     
	
	//status = GERFM_EnableDMA(&GERFM_hDev, RFM_DATA_UINT8_SIZE, OPERATE_WRITE);  
		
	status = GERFM_DMA_Write(GERFM_hDev, RFM_CMD_MC_START, DataUInt8Tx);  
	
	status = GERFM_SendEvent(GERFM_hDev, RFM_NODE_MC, RFM_CMD_MC_START, RFM2G_NIC_INT3);
	
	
	return 0;
}




/*
	ֹͣ���ز���
 */
int rfmStopMC(void)
{
	int status;
	
	//if (GERFM_hDev == NULL)
	//	status = GERFM_OpenDevice(&GERFM_hDev);     
	
	//status = GERFM_EnableDMA(&GERFM_hDev, RFM_DATA_UINT8_SIZE, OPERATE_WRITE);  
		
	status = GERFM_DMA_Write(GERFM_hDev, RFM_CMD_MC_STOP, DataUInt8Tx);  
	
	status = GERFM_SendEvent(GERFM_hDev, RFM_NODE_MC, RFM_CMD_MC_STOP, RFM2G_NIC_INT3);
	
	
	return 0;
}



/* 
 * Open device
 */
int rfmOpenDev(void)
{
	GERFM_OpenDevice(&GERFM_hDev);
	return 0;
}


/* 
 * Close device
 */
int rfmCloseDev(void)
{
	GERFM_CloseDevice(&GERFM_hDev);
	return 0;
}

/*
	Enable DMA
 */
int rfmEnableDMA(void)
{
	GERFM_EnableDMA(&GERFM_hDev, RFM_DATA_UINT8_SIZE, OPERATE_WRITE);
	return 0;
}


/*
	Disable DMA
 */
int rfmDisableDMA(void)
{
	GERFM_DisableDMA(&GERFM_hDev);
	return 0;
}


/*
	���¼���������ؼ��������IMU����
 */
int rfmIMU(double *w, double *f)
{
	int status;
	
	DataDoubleTx[0] = *(w + 0);
	DataDoubleTx[1] = *(w + 1);
	DataDoubleTx[2] = *(w + 2);
	
	DataDoubleTx[3] = *(f + 0);
	DataDoubleTx[4] = *(f + 1);
	DataDoubleTx[5] = *(f + 2);
	

		
	status = GERFM_DMA_Write(GERFM_hDev, RFM_CMD_MC_IMU, (char *)DataDoubleTx);  
	
	status = GERFM_SendEvent(GERFM_hDev, RFM_NODE_MC, RFM_CMD_MC_IMU, RFM2G_NIC_INT3);
	
	
	return 0;
}



/*
	���˷����ڴ濨INT3�жϻص�����
 */
ViStatus _VI_FUNCH GERFM_interrupt(ViSession vi , ViEventType eventType ,ViEvent ctx ,ViAddr userHdlr)
{
	ViUInt8 Sender_id;
	ViUInt32 Sender_data;
	ViUInt32 Sender_lisr;
	
	viPeek32 (vi,ADD_OFFSET(GERFM_hDev.Map_addr,rfm2g_isd3), &Sender_data);
	viPeek8 (vi, ADD_OFFSET(GERFM_hDev.Map_addr,rfm2g_sid3), &Sender_id); 
	viMoveIn8 (GERFM_hDev.GERFM_instr, VI_PXI_BAR3_SPACE, Sender_data, RFM_DATA_UINT8_SIZE, (char *)DataDoubleRx);
	viOut32(GERFM_hDev.GERFM_instr, VI_PXI_BAR2_SPACE, rfm2g_lisr, 0x4000);
	
	RFMMCIntRcv = Sender_data;
	
	return VI_SUCCESS;
}




/*
	���ع��˷����ڴ濨��ʼ��
 */					
int rfmInitMC(void)
{
	int status;
	
	status = GERFM_OpenDevice(&GERFM_hDev);     
	status = GERFM_EnableEventCallback(&GERFM_hDev, RFM2G_NIC_INT3, GERFM_interrupt);
	
	printf("RFM opened with interrupt callback.\n");   

	return 0;
}



/*
	���عرչ��˷����ڴ濨
 */
int rfmCloseMC(void)
{
	int status;
	
	status = GERFM_DisableEventCallback(GERFM_hDev, RFM2G_NIC_INT3);
	status = GERFM_CloseDevice(&GERFM_hDev);     
	 
	printf("RFM closed.\n");   

	return 0;
}


/*
	���¹��˷����ڴ濨��ʼ��
 */					
int rfmInitDS(void)
{
	int status;
	
	status = GERFM_OpenDevice(&GERFM_hDev);     
	
	printf("RFM opened.\n");   

	return 0;
}



/*
	���¹رչ��˷����ڴ濨
 */
int rfmCloseDS(void)
{
	int status;
	
	status = GERFM_CloseDevice(&GERFM_hDev);     
	 
	printf("RFM closed.\n");   

	return 0;
}








/*
	ת̨��������ļ��������ɺ���
 */
unsigned char rfmRotaryParamCheck(int paramLength, unsigned char *param)
{
	int i;
	unsigned char temp = *param;
	
	for (i = 1; i < paramLength; i ++)
	{
		temp ^= *(param + i);	
	}
	
	return temp;
}




/*
   ��������������ó�ʼ�Ƕȡ��ٶ�
 */
int rfmRotaryClimb(float *initAngle, float *initRate, float *initAngleGet, float *initRateGet, int step)
{
	long i;
	
	unsigned char *pUChar1, *pUChar2;
	float *pFloat1, *pFloat2;
	float angleGet[3];
	float rateGet[3];
	
	ViUInt32 addr = 0x2000;
	

	
	/*if (abs(*(initAngle + 0) - angleGet[0]) > 180)
		*(initAngle + 0) = 360 - *(initAngle + 0);
	if (abs(*(initAngle + 1) - angleGet[1]) > 180)
		*(initAngle + 1) = 360 - *(initAngle + 1);
	if (abs(*(initAngle + 2) - angleGet[2]) > 180)
		*(initAngle + 2) = 360 - *(initAngle + 2); */
	
	
	
	
	// Send command
	RFMStructCmd.cmdFlag = 0x55;
	RFMStructCmd.cmdCode = 0x01;
	RFMStructCmd.cmdParamLength = 25;
	
	pUChar1 = (unsigned char *)initAngle;
	pUChar2 = (unsigned char *)initRate;
	
	for (i = 0; i < 12; i ++)
		RFMStructCmd.cmdParam[i] = *(pUChar1 + i);
	
	for (i = 0; i < 12; i ++)
		RFMStructCmd.cmdParam[i + 12] = *(pUChar2 + i);
	
	// Step
	RFMStructCmd.cmdParam[24] = (unsigned char)(step * 10);

	
	RFMStructCmd.cmdParamCheck = rfmRotaryParamCheck(25, RFMStructCmd.cmdParam);
	
	// Write data to RFM
	viMoveOut8 (GERFM_hDev.GERFM_instr, VI_PXI_BAR3_SPACE, addr, RFM_ROTARY_CMD_SIZE, (char*)&RFMStructCmd);  
	
	// Send RFM event
	GERFM_SendEvent(GERFM_hDev, RFM_NODE_ROTARY, addr, RFM2G_NIC_INT1);
	

	
	// Read status
	i = 0;
	do
	{		
		viMoveIn8 (GERFM_hDev.GERFM_instr, VI_PXI_BAR3_SPACE, addr + 32, RFM_ROTARY_STATUS_SIZE, (char*)&RFMStructStatus);
		if (i++ == 65536)
		{
			printf("Error: Read rotary status over time when climb!\n");
			return 1;
		}
	}while ((RFMStructStatus.statusParam[28 - 4] != 1) && (RFMStructStatus.statusFlag != 0x55));
	
	

	// Decode data
	pFloat1 = (float *)RFMStructStatus.statusParam;
	pFloat2 = (float *)(RFMStructStatus.statusParam + 12);
		
	for (i = 0; i < 3; i ++)
		*(initAngleGet + i) = *(pFloat1 + i);
	for (i = 0; i < 3; i ++)
		*(initRateGet + i) = *(pFloat2 + i);
		
		
		
		
		
		/**(temp + 0) = RFMStructStatus.statusFlag;
		*(temp + 1) = RFMStructStatus.statusCode;
		*(temp + 2) = RFMStructStatus.statusParamLength;
		*(temp + 3) = RFMStructStatus.statusParamCheck;
		*(temp + 4) = rfmRotaryParamCheck(25, RFMStructStatus.statusParam);
		for (i = 0; i < 28; i ++)
			*(temp + i + 5) = RFMStructStatus.statusParam[i];*/
		
	//if (RFMStructStatus.statusParamCheck != rfmRotaryParamCheck(25, RFMStructStatus.statusParam))
	//	printf("Error: Check rotary status error when climb!\n");
		
		
	RFMStructStatus.statusFlag = 0xaa;
	viMoveOut8 (GERFM_hDev.GERFM_instr, VI_PXI_BAR3_SPACE, addr + 32, RFM_ROTARY_STATUS_SIZE, (char*)&RFMStructStatus);

		
	return 0;

}



/*
   ���������������ʵʱ�ĽǶȡ��ٶ�
 */
int rfmRotaryTrack(float *angle, float *rate, float *angleGet, float *rateGet)
{
	long i;
	
	unsigned char *pUChar1, *pUChar2;
	float *pFloat1, *pFloat2;
	
	ViUInt32 addr = 0x2000;

	
	
	// Send command
	RFMStructCmd.cmdFlag = 0x55;
	RFMStructCmd.cmdCode = 0x02;
	RFMStructCmd.cmdParamLength = 24;
	
	pUChar1 = (unsigned char *)angle;
	pUChar2 = (unsigned char *)rate;
	
	for (i = 0; i < 12; i ++)
		RFMStructCmd.cmdParam[i] = *(pUChar1 + i);
	
	for (i = 0; i < 12; i ++)
		RFMStructCmd.cmdParam[i + 12] = *(pUChar2 + i);
	
	RFMStructCmd.cmdParamCheck = rfmRotaryParamCheck(24, RFMStructCmd.cmdParam); 
	
	// Write data to RFM
	viMoveOut8 (GERFM_hDev.GERFM_instr, VI_PXI_BAR3_SPACE, addr, RFM_ROTARY_CMD_SIZE, (char*)&RFMStructCmd);  
	
	// Send RFM event
	GERFM_SendEvent(GERFM_hDev, RFM_NODE_ROTARY, addr, RFM2G_NIC_INT1);
	
	
	
	// Read status
	i = 0;
	do
	{
		viMoveIn8 (GERFM_hDev.GERFM_instr, VI_PXI_BAR3_SPACE, addr + 32, RFM_ROTARY_STATUS_SIZE, (char*)&RFMStructStatus);
		if (i++ == 65536)
		{
			printf("Error: Read rotary status over time when track!\n");
			return 1;
		}
	}while (RFMStructStatus.statusFlag != 0x55);
	

	// Decode data	
	pFloat1 = (float *)RFMStructStatus.statusParam;
	pFloat2 = (float *)(RFMStructStatus.statusParam + 12);
		
	for (i = 0; i < 3; i ++)
		*(angleGet + i) = *(pFloat1 + i);
	for (i = 0; i < 3; i ++)
		*(rateGet + i) = *(pFloat2 + i);
		
		
		
		
		
		
		
		/**(temp + 0) = RFMStructStatus.statusFlag;
		*(temp + 1) = RFMStructStatus.statusCode;
		*(temp + 2) = RFMStructStatus.statusParamLength;
		*(temp + 3) = RFMStructStatus.statusParamCheck;
		*(temp + 4) = rfmRotaryParamCheck(25, RFMStructStatus.statusParam);
		for (i = 0; i < 28; i ++)
			*(temp + i + 5) = RFMStructStatus.statusParam[i];*/
		
	//if (RFMStructStatus.statusParamCheck != rfmRotaryParamCheck(25, RFMStructStatus.statusParam))
	//	printf("Error: Check rotary status error when track!\n");
		
	RFMStructStatus.statusFlag = 0xaa;
	viMoveOut8 (GERFM_hDev.GERFM_instr, VI_PXI_BAR3_SPACE, addr + 32, RFM_ROTARY_STATUS_SIZE, (char*)&RFMStructStatus);
		
	return 0;


}



/*
   ��ȡʵʱ�ĽǶȡ��ٶ�
 */
/*int rfmRotaryReadPV(float *angleGet, float *rateGet)
{
	long i;
	
	float *pFloat1, *pFloat2;
	
	ViUInt32 addr = 0x2000;
	
	// Send command
	RFMStructCmd.cmdFlag = 0x55;
	RFMStructCmd.cmdCode = 0x81;
	RFMStructCmd.cmdParamLength = 0;
	
	viMoveOut8 (GERFM_hDev.GERFM_instr, VI_PXI_BAR3_SPACE, addr, RFM_ROTARY_CMD_SIZE, (char*)&RFMStructCmd);  
	
	GERFM_SendEvent(GERFM_hDev, RFM_NODE_ROTARY, addr, RFM2G_NIC_INT1);
	
	
	
	// Read status
	i = 0;
	do
	{
		viMoveIn8 (GERFM_hDev.GERFM_instr, VI_PXI_BAR3_SPACE, addr + 32, RFM_ROTARY_STATUS_SIZE, (char*)&RFMStructStatus);
		if (i++ == 65536)
		{
			printf("Error: Read rotary status over time when read!\n");
			return 1;
		}
	}while (RFMStructStatus.statusFlag != 0x55);
	
	if (RFMStructStatus.statusParamCheck == rfmRotaryParamCheck(25, RFMStructStatus.statusParam))
	{
		pFloat1 = (float *)RFMStructStatus.statusParam;
		pFloat2 = (float *)(RFMStructStatus.statusParam + 12);
		
		for (i = 0; i < 3; i ++)
			*(angleGet + i) = *(pFloat1 + i);
		for (i = 0; i < 3; i ++)
			*(rateGet + i) = *(pFloat2 + i);
		
		RFMStructStatus.statusFlag = 0xaa;
		viMoveOut8 (GERFM_hDev.GERFM_instr, VI_PXI_BAR3_SPACE, addr + 32, RFM_ROTARY_STATUS_SIZE, (char*)&RFMStructStatus);

		return 0;
	}
	else
	{
		printf("Error: Check rotary status error when read!\n");
		return 1;
	}
}*/






