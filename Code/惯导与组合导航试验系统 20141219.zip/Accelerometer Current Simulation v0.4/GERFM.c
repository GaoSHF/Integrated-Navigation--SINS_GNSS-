#include "GERFM.h"

int GERFM_OpenDevice(GERFM_DevHandle *phDev)
{
	int status;
	ViFindList fList;
	ViChar desc[256];
	ViUInt32 numInstrs=0;
	status = viOpenDefaultRM(&(phDev->GERFM_defaultRM));
	status = viFindRsrc (phDev->GERFM_defaultRM, "PXI?*INSTR{(VI_ATTR_MANF_ID==0x114A && VI_ATTR_MODEL_CODE==0x5565) || (VI_ATTR_MANF_ID==0x1556 && VI_ATTR_MODEL_CODE==0x0080)}", &fList,&numInstrs,desc);
	
	status = viOpen(phDev->GERFM_defaultRM, desc, VI_NULL,VI_NULL, &(phDev->GERFM_instr));
	
//	status = viClose(defaultRM);

    return status;
}

int GERFM_CloseDevice(GERFM_DevHandle *phDev)
{
	int status;   
	status = viClose(phDev->GERFM_instr);
	status = viClose(phDev->GERFM_defaultRM);
	
    return status;
}

int GERFM_ReadModWrite32(GERFM_DevHandle hDev,ViUInt16 pxi_space,GERFM_UINT32 offset,GERFM_UINT32 bit_mask,GERFM_UINT32 value)
{
	int status;
	
	ViUInt32 value2=0; 
	
	ViUInt32 result=0;
	 
	status = viIn32 (hDev.GERFM_instr, pxi_space, offset, &value2);
	result = value2 & (~bit_mask);	  //??
	result = result | value;		  //?1
	status = viOut32 (hDev.GERFM_instr,pxi_space, offset, result); 
    return status;
}


int GERFM_SetLED(GERFM_DevHandle hDev,GERFM_BOOL state) 
{
	int status;	
	ViUInt32 value=0;
	if(state == LED_ON)
		value = 0x80000000;
	else if (state == LED_OFF)
		value = 0;
	status = GERFM_ReadModWrite32(hDev,VI_PXI_BAR2_SPACE,rfm2g_lcsr,0x80000000,value);

	return status;

}

int GERFM_GetLED(GERFM_DevHandle hDev,GERFM_BOOL* pState) 
{
	int status;	
	ViUInt32 value=0;
	status = viIn32 (hDev.GERFM_instr, VI_PXI_BAR2_SPACE, rfm2g_lcsr, &value);
	value = value & 0x80000000;
	
	if(value == 0x80000000)
		*pState = LED_ON;
	else
		*pState = LED_OFF;
	
	return status;

}

int GERFM_GetNodeID(GERFM_DevHandle hDev,ViUInt8* NodeID) 
{
	int status;	
	ViUInt32 value=0;
	status = viIn8 (hDev.GERFM_instr, VI_PXI_BAR2_SPACE, rfm2g_nid, NodeID);
	return status;

}


int GERFM_EnableDMA(GERFM_DevHandle *phDev,GERFM_UINT32 transize,GERFM_BOOL operatestate)
{
	int status;
	ViUInt32 value=0; 
	status = viOpenDefaultRM(&(phDev->MEMACC_defaultRM)); 
	status = viOpen(phDev->MEMACC_defaultRM, "PXI0::MEMACC", VI_NULL,VI_NULL,&(phDev->MEMACC_instr));
	status = viMemAlloc (phDev->MEMACC_instr, transize, &(phDev->MEMACC_memoffset));
	phDev->MEMACC_bytecount = transize;
	status = viOut32(phDev->GERFM_instr, VI_PXI_BAR0_SPACE, rfmor_DmaMode0, 0x183);  
	status = viOut32(phDev->GERFM_instr, VI_PXI_BAR0_SPACE, rfmor_DmaCount0,transize); 
	status = viOut32(phDev->GERFM_instr, VI_PXI_BAR0_SPACE, rfmor_DmaPciAddr0,phDev->MEMACC_memoffset);
	if(operatestate == OPERATE_READ)
		value = 8;
	else if(operatestate == OPERATE_WRITE)
		value = 0; 
	status = viOut32(phDev->GERFM_instr, VI_PXI_BAR0_SPACE, rfmor_DmaPtr0,value);   
    return status;
}

int GERFM_DisableDMA(GERFM_DevHandle *phDev)
{
	int status;
	ViUInt32 value=0; 
	status = viOut8(phDev->GERFM_instr, VI_PXI_BAR0_SPACE, rfmor_Dma0Csr,0);   
	status = viMemFree (phDev->MEMACC_instr, phDev->MEMACC_memoffset);
	status = viClose(phDev->MEMACC_instr);
	status = viClose(phDev->MEMACC_defaultRM);
    return status;
}

int GERFM_DMA_Write(GERFM_DevHandle hDev,GERFM_UINT32 offset,ViUInt8 buffer[])
{
	int status;
	ViUInt8 value=0; 

	status = viOut32(hDev.GERFM_instr, VI_PXI_BAR0_SPACE, rfmor_DmaLocAddr0, offset);
	status = viMoveOut8 (hDev.MEMACC_instr, VI_PXI_ALLOC_SPACE, hDev.MEMACC_memoffset, hDev.MEMACC_bytecount, buffer);
	status = viOut8(hDev.GERFM_instr, VI_PXI_BAR0_SPACE, rfmor_Dma0Csr, 3); 
	while(value != 0x11)
	{
		status = viIn8 (hDev.GERFM_instr, VI_PXI_BAR0_SPACE, rfmor_Dma0Csr, &value);
	}
	status = viOut8(hDev.GERFM_instr, VI_PXI_BAR0_SPACE, rfmor_Dma0Csr, 8); 
	
    return status;
}

int GERFM_DMA_Read(GERFM_DevHandle hDev,GERFM_UINT32 offset,ViUInt8 buffer[])
{
	int status;
	ViUInt8 value=0; 

	status = viOut32(hDev.GERFM_instr, VI_PXI_BAR0_SPACE, rfmor_DmaLocAddr0, offset);
	status = viOut8(hDev.GERFM_instr, VI_PXI_BAR0_SPACE, rfmor_Dma0Csr, 3); 
	while(value != 0x11)
	{
		status = viIn8 (hDev.GERFM_instr, VI_PXI_BAR0_SPACE, rfmor_Dma0Csr, &value);
	}
	
	viMoveIn8 (hDev.MEMACC_instr, VI_PXI_ALLOC_SPACE, hDev.MEMACC_memoffset, hDev.MEMACC_bytecount, buffer);
	status = viOut8(hDev.GERFM_instr, VI_PXI_BAR0_SPACE, rfmor_Dma0Csr, 8); 
	
    return status;
}


int GERFM_SendEvent(GERFM_DevHandle hDev,ViUInt8 target_node,ViUInt32 user_data,ViUInt8 event_type)
{
	int status;
	ViUInt8 value=0; 

	status = viOut32(hDev.GERFM_instr, VI_PXI_BAR2_SPACE, rfm2g_ntd, user_data);
	status = viOut8(hDev.GERFM_instr, VI_PXI_BAR2_SPACE, rfm2g_ntn, target_node); 
	status = viOut8(hDev.GERFM_instr, VI_PXI_BAR2_SPACE, rfm2g_nic, event_type);
	
    return status;
}

 /*

ViStatus _VI_FUNCH GERFM_interrupt(ViSession vi , ViEventType eventType ,ViEvent ctx ,ViAddr userHdlr)
{
	ViUInt8 Sender_id;
	ViUInt32 Sender_data; 					  
	viPeek32 (vi, (ViAddr)rfm2g_sid1, &Sender_data);
	viPeek8 (vi, (ViAddr)rfm2g_isd1, &Sender_id); 
	
	
	return VI_SUCCESS;
}    	  */  
						 
int GERFM_EnableEventCallback(GERFM_DevHandle *phDev,ViUInt8 event_type,ViHndlr pEventFunc)	 // 
{
	int status;
	ViUInt8 value=0; 
	 
	if(event_type == RFM2G_NIC_INT1)
	{
		status = viOut8(phDev->GERFM_instr, VI_PXI_BAR2_SPACE, rfm2g_sid1,0);   
		status = GERFM_ReadModWrite32(*phDev,VI_PXI_BAR2_SPACE,rfm2g_lier,0x8001,0x8001); 
	}
	else if(event_type == RFM2G_NIC_INT2)
	{
		status = viOut8(phDev->GERFM_instr, VI_PXI_BAR2_SPACE, rfm2g_sid2, 0);   
		status = GERFM_ReadModWrite32(*phDev,VI_PXI_BAR2_SPACE,rfm2g_lier,0x8002,0x8002);
	}																						   
	else if(event_type == RFM2G_NIC_INT3)
	{
		status = viOut8(phDev->GERFM_instr, VI_PXI_BAR2_SPACE, rfm2g_sid3, 0);   
		status = GERFM_ReadModWrite32(*phDev,VI_PXI_BAR2_SPACE,rfm2g_lier,0x8004,0x8004);
	}
	else if(event_type == RFM2G_NIC_RSTREQ)
	{
		status = GERFM_ReadModWrite32(*phDev, VI_PXI_BAR2_SPACE, rfm2g_lisr,8,0);   
		status = GERFM_ReadModWrite32(*phDev,VI_PXI_BAR2_SPACE,rfm2g_lier,0x8008,0x8008);
	}
	else if(event_type == RFM2G_NIC_INITINT)
	{
		status = GERFM_ReadModWrite32(*phDev,VI_PXI_BAR2_SPACE,rfm2g_lier,0x808F,0x808F);
	}
	else if(event_type == RFM2G_NIC_GLOBAL)
	{
		status = viOut8(phDev->GERFM_instr, VI_PXI_BAR2_SPACE, rfm2g_initn, 0);   
		status = GERFM_ReadModWrite32(*phDev,VI_PXI_BAR2_SPACE,rfm2g_lier,0x8080,0x8080);
	}		 

	status = GERFM_ReadModWrite32(*phDev,VI_PXI_BAR2_SPACE,rfm2g_lisr,0x4000,0x4000);  
	status = GERFM_ReadModWrite32(*phDev,VI_PXI_BAR0_SPACE,rfmor_intcsr,0x900,0x900);	
//	status = viUnmapAddress (hDev.GERFM_instr);
	status = viMapAddress (phDev->GERFM_instr, VI_PXI_BAR2_SPACE, 0, 0x40, 0, VI_NULL, &(phDev->Map_addr));
	status = viInstallHandler (phDev->GERFM_instr, VI_EVENT_PXI_INTR, pEventFunc, (ViAddr)10); //(ViAddr)10
	status = viEnableEvent (phDev->GERFM_instr, VI_EVENT_PXI_INTR, VI_HNDLR, VI_NULL);//VI_QUEUE VI_HNDLR
	
    return status;
}	

int GERFM_DisableEventCallback(GERFM_DevHandle hDev,ViUInt8 event_type)
{
	int status;
	
	if(event_type == RFM2G_NIC_INT1)
	{
		status = viUnmapAddress (hDev.GERFM_instr);
		status = GERFM_ReadModWrite32(hDev,VI_PXI_BAR2_SPACE,rfm2g_lier,0x1,0); 
	}
	else if(event_type == RFM2G_NIC_INT2)
	{
		status = viUnmapAddress (hDev.GERFM_instr);
		status = GERFM_ReadModWrite32(hDev,VI_PXI_BAR2_SPACE,rfm2g_lier,0x2,0); 
	}
	else if(event_type == RFM2G_NIC_INT3)
	{
		status = viUnmapAddress (hDev.GERFM_instr);
		status = GERFM_ReadModWrite32(hDev,VI_PXI_BAR2_SPACE,rfm2g_lier,0x4,0); 
	}
	else if(event_type == RFM2G_NIC_RSTREQ)
	{
		status = viUnmapAddress (hDev.GERFM_instr);
		status = GERFM_ReadModWrite32(hDev,VI_PXI_BAR2_SPACE,rfm2g_lier,0x8,0); 
	}
	else if(event_type == RFM2G_NIC_INITINT)
	{
		status = viUnmapAddress (hDev.GERFM_instr);
		status = GERFM_ReadModWrite32(hDev,VI_PXI_BAR2_SPACE,rfm2g_lier,0x80,0); 
	}
	else if(event_type == RFM2G_NIC_GLOBAL)
	{
		status = viUnmapAddress (hDev.GERFM_instr); 
		status = GERFM_ReadModWrite32(hDev,VI_PXI_BAR0_SPACE,rfmor_intcsr,0x800,0); 
		status = viOut32(hDev.GERFM_instr, VI_PXI_BAR2_SPACE, rfm2g_lisr, 0);
		status = viOut32(hDev.GERFM_instr, VI_PXI_BAR2_SPACE, rfm2g_lier, 0x8000);
		status = viDisableEvent (hDev.GERFM_instr, VI_EVENT_PXI_INTR, VI_HNDLR);//VI_QUEUE VI_HNDL
	}

    return status;
}

/*
void geledon()
{
	int status;
	GERFM_BOOL state;
	status = GERFM_OpenDevice(&hDev);     
	status = GERFM_SetLED(hDev,LED_ON);
 
//	status = GERFM_GetLED(hDev,&state);  
	status = GERFM_CloseDevice(&hDev); 	
}

void geledoff()
{
	int status;
	GERFM_BOOL state;
	status = GERFM_OpenDevice(&hDev);     
	status = GERFM_SetLED(hDev,LED_OFF);
 
//	status = GERFM_GetLED(hDev,&state);  
	status = GERFM_CloseDevice(&hDev); 	
}

void dmawriteread()
{
	int status;
	ViUInt8 a[100]={1,1,2,3,4,5,6,7,8,9};
	ViUInt8 b[100] ;
	
	status = GERFM_OpenDevice(&hDev);     
	
	status = GERFM_EnableDMA(&hDev,100,OPERATE_WRITE);  
		
	status = GERFM_DMA_Write(hDev,0,a) ;  
	
	status = GERFM_DMA_Read(hDev,0,b) ;  
 
	status = GERFM_CloseDevice(&hDev); 	
}

void dmawritenetwork()
{
	int status;
	ViUInt8 a[10]={1,1,2,3,4,5,6,7,8,9};
	
	status = GERFM_OpenDevice(&hDev);     
	
	status = GERFM_EnableDMA(&hDev,10,OPERATE_WRITE);  
		
	status = GERFM_DMA_Write(hDev,0,a) ;  
	
	status = GERFM_SendEvent(hDev,1,0,RFM2G_NIC_INT1); 
	
	status = GERFM_CloseDevice(&hDev); 	
}

void dmareadnetwork()
{
	int status;
	ViUInt8 b[10] ;
	
	status = GERFM_OpenDevice(&hDev);     
	
	status = GERFM_EnableEventCallback(hDev,RFM2G_NIC_INT1,GERFM_interrupt); 

	status = GERFM_EnableDMA(&hDev,10,OPERATE_READ);   
	
	status = GERFM_DMA_Read(hDev,0,b); 
	
	status = GERFM_DisableEventCallback(hDev,RFM2G_NIC_INT1); 
	
	status = GERFM_CloseDevice(&hDev); 	
}

ViStatus _VI_FUNCH GERFM_interrupt(ViSession vi , ViEventType eventType ,ViEvent ctx ,ViAddr userHdlr)
{
	ViUInt8 Sender_id;
	ViUInt32 Sender_data;
	ViUInt8 b[10] ;
	ViAddr c; 
	//c= (ViAddr)hDev.Map_addr;
	//viPeek32 (vi,hDev.Map_addr, &Sender_data);
	viPeek32 (vi,ADD_OFFSET(hDev.Map_addr,rfm2g_isd1), &Sender_data);
	viPeek8 (vi, ADD_OFFSET(hDev.Map_addr,rfm2g_sid1), &Sender_id); 
	//viIn8(hDev.GERFM_instr,VI_PXI_BAR2_SPACE,rfm2g_sid1,&Sender_id);
	//viIn32(hDev.GERFM_instr,VI_PXI_BAR2_SPACE,0x20,&Sender_data); 
	GERFM_EnableDMA(&hDev,10,OPERATE_READ); 
	GERFM_DMA_Read(hDev,Sender_data,b); 
	viOut32(hDev.GERFM_instr, VI_PXI_BAR2_SPACE, rfm2g_lisr, 0x4000);
	SetCtrlVal(panelHandle,PANEL_NUMERIC,b[0]);
	
	return VI_SUCCESS;
}



*/


