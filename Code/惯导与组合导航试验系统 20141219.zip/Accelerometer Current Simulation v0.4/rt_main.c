#include <formatio.h>   
#include <tcpsupp.h>
#include "asynctmr.h"
#include <cvirte.h>
#include <rtutil.h>
#include <userint.h> 
#include <analysis.h>
#include <utility.h>
#include <cvinetv.h>
#include <ansi_c.h>

#include "common.h"
#include "acc_simu.h"
#include "rfm.h"

#define	pi	3.1415926


// Global variables
static unsigned int StatusTCP	= TCP_INVALID_CONNECTION;

static int gLock;

static int gThdLock;

int gThreadPool	= 0;

volatile int gDone; // Signal the main thread to exit the while loop in RTMain

CommandMessage Cmd;			     

// Thread ID
static int ThreadFunctionId = 0;

// Flag of thread    
int FlagThread = 0;

DataMessage Data;

// Timer ID
int TimerIDCurrentRefresh = NULL;

long long CounterRefresh = 0;

int FlagRefresh = 0;

int FlagRefreshPre = 0;
int FlagRefreshAfter = 0;

FILE *FileHandleCurrentRT = NULL;




// Global function
int CVICALLBACK TCPDataCallback (unsigned handle, int xType, int errCode, void *cbData);

int QuitCMDCallback(void);

int AccsimuSetCallback(void);
int AccsimuGetCallback(void);

int Update (void);
int Refresh (void);
int CVICALLBACK TimerCurrentRefresh(int reserved, int timerId, int event, void *callbackData, int eventData1, int eventData2);

static int CVICALLBACK ThreadFunction(void *functionData);

/*
	RT main entry
 */
void CVIFUNC_C RTmain (void)
{
	CNVData SelfTestFinshData;
	unsigned int prevProcessorMask = 0;
	
	if (InitCVIRTE (0, 0, 0) == 0)
		return;    /* out of memory */
	
	if (ConnectToTCPServer (&StatusTCP, HOST_PORT, HOST_ADDRESS, TCPDataCallback, 0, 5000) < 0)
		goto Done;
	
	// Configure the system processor pool to only include the first processor on the system.
	ConfigureProcessorPool (kProcessorPool_System, 0x1, &prevProcessorMask);
	// Suspend asynchronous timer callback so it can start when command is received from host application.
	//SuspendAsyncTimerCallbacks ();
	/* Your initialization code. */
	/* It is common for Real-Time applications to use multiple threads to */
	/* separate higher priority tasks from lower priority tasks. See the  */
	/* Thread Pool functions in the Utility Library and the Asynchronous  */
	/* Timer functions in <CVI>\toolslib\toolbox\asynctmr.fp.             */
	// Create lock to synchronize writing TCP data
	CmtNewLock (0, 0, &gLock);
	CmtNewLock (0, 0, &gThdLock);
	CmtNewThreadPool (5, &gThreadPool);
	
	
	//CmtNewThreadPool (2, &ThreadFunction); // Simulator operation thread contains a timer
	

	// Init DC power board
	accsimuInit (&DC0);
	accsimuInit (&DC1);
	accsimuInit (&DC2);
	
	
	// Init RFM
	rfmInitDS();
	
	rfmEnableDMA();
	
	rfmStartMC();
	
	// Create thread at CPU2
	//CmtScheduleThreadPoolFunction (gThreadPool, ThreadFunction, NULL, &ThreadFunctionId);
	
	// Create timer at CPU1
	TimerIDCurrentRefresh = NewAsyncTimer (0.010, -1, 0, TimerCurrentRefresh, 0);
	SetAsyncTimerAttribute(TimerIDCurrentRefresh, ASYNC_ATTR_ENABLED, 1);
	
	while (!RTIsShuttingDown () && !gDone)
	{
		/* Your code. */
		/* Sleep for some amount of time to give the desired loop rate */
		/* and to allow lower priority threads to run.                 */
		ProcessSystemEvents();
		SleepUS (100);
		
	}
	
	SetAsyncTimerAttribute(TimerIDCurrentRefresh, ASYNC_ATTR_ENABLED, 0);
	DiscardAsyncTimer(TimerIDCurrentRefresh);
	
	// Kill thread
	//CmtWaitForThreadPoolFunctionCompletion (gThreadPool, ThreadFunctionId, OPT_TP_PROCESS_EVENTS_WHILE_WAITING);
	//CmtReleaseThreadPoolFunctionID (gThreadPool, ThreadFunctionId);
	
	rfmStopMC();
	
	rfmDisableDMA();
	
	// Close RFM
	rfmCloseDS();
	 

	
	// Release thread pool
	if (gThreadPool)
		// CmtDiscardThreadPool waits for the thread function to exit.
		CmtDiscardThreadPool (gThreadPool);
	
	
	// Restore the original system processor pool configuration.
	if (prevProcessorMask)
		ConfigureProcessorPool (kProcessorPool_System, prevProcessorMask, NULL);
	
	/* Your cleanup code. */
	CmtDiscardLock (gLock);
	if (StatusTCP != TCP_INVALID_CONNECTION)
		DisconnectFromTCPServer (StatusTCP);
Done:  	
	CloseCVIRTE ();
	
}





/*
	TCP callback
 */
int CVICALLBACK TCPDataCallback (unsigned handle, int xType, int errCode, void *cbData)
{

	
    switch (xType)
    {
        case TCP_DISCONNECT:
            StatusTCP = TCP_INVALID_CONNECTION;
            break;
        case TCP_DATAREADY: // Client executable sent a command.
			// ClientTCPRead does not guarantee that all data will be transferred in
			// a single call, but this code assumes that it does for simplicity.
			ClientTCPRead (StatusTCP, &Cmd, sizeof(Cmd), 5000);
			switch(Cmd.command)
			{
				
				case QUIT_COMMAND:
					QuitCMDCallback();  
					break;
				
				case GPSSIM_COMMAND:
					break;
					
				case GPSSIM_AGC_COMMAND:
					break;
					
				case GPSSIM_IO_CHANGE_COMMAND:
					break;
					
				case ACCSIMU_SET_COMMAND:
					AccsimuSetCallback();
					break;
					
				case ACCSIMU_GET_COMMAND:
					AccsimuGetCallback();
					break;
					
				case ACCSIMU_REFRESH_COMMAND:
					if (Cmd.statusRefresh == 1)
					{
						FlagRefresh = 1;
						//ResumeAsyncTimerCallbacks();
						SetAsyncTimerAttribute (TimerIDCurrentRefresh, ASYNC_ATTR_ENABLED, 1);
						FlagThread = 1;
					}
					else if (Cmd.statusRefresh == 0)
					{
						FlagThread = 0;
						FlagRefresh = 0;
						SetAsyncTimerAttribute (TimerIDCurrentRefresh, ASYNC_ATTR_ENABLED, 0);
					}
					break;
		
			}
			
            break;
			
    }
    
    return 0;
}



/*
	Accelerometer simulation setting TCP callback
 */
int AccsimuSetCallback(void)
{
    double acceleration[3];
	
	if ((DC0.SessionVI != VI_NULL) && (DC1.SessionVI != VI_NULL) && (DC2.SessionVI != VI_NULL))
	{
		CmtGetLock (gLock);
	
		acceleration[0] = Cmd.acceleration[0];
		acceleration[1] = Cmd.acceleration[1];
		acceleration[2] = Cmd.acceleration[2];
    
		DC0.currentLevel = acceleration[0] * ACCELERATION_TO_CURRENT;
		DC1.currentLevel = acceleration[1] * ACCELERATION_TO_CURRENT;
		DC2.currentLevel = acceleration[2] * ACCELERATION_TO_CURRENT;
	
		// Set current
		accsimuSet4141 (DC0);
		accsimuSet4130 (DC1);
		accsimuSet4130 (DC2);
	
		CmtReleaseLock (gLock);
		
		printf("Data set successfully.\n");
	}
	
	return 0;

}



/*
	Accelerometer simulation measurement TCP callback
 */
int AccsimuGetCallback(void)
{
	
	if ((DC0.SessionVI != VI_NULL) && (DC1.SessionVI != VI_NULL) && (DC2.SessionVI != VI_NULL))
	{
		CmtGetLock (gLock);
	
		// Measure
		accsimuMeasure(&DC0);
		accsimuMeasure(&DC1);
		accsimuMeasure(&DC2);
	
		// Transmit measurements
		Cmd.measuredCurrent[0] = DC0.measuredCurrent;
		Cmd.measuredVoltage[0] = DC0.measuredVoltage;
		Cmd.inCompliance[0] = DC0.inCompliance;
	
		Cmd.measuredCurrent[1] = DC1.measuredCurrent;
		Cmd.measuredVoltage[1] = DC1.measuredVoltage;
		Cmd.inCompliance[1] = DC1.inCompliance;
	
		Cmd.measuredCurrent[2] = DC2.measuredCurrent;
		Cmd.measuredVoltage[2] = DC2.measuredVoltage;
		Cmd.inCompliance[2] = DC2.inCompliance;
	
		ClientTCPWrite (StatusTCP, &Cmd, sizeof(Cmd), 5000);
	
		CmtReleaseLock (gLock);
	}
	
	return 0;
}


/*
	Quit RT programme TCP callback
 */
int QuitCMDCallback(void)
{
	
	DiscardAsyncTimer(TimerIDCurrentRefresh);
	
	printf("Quit RT programme success.\n");
	
	// Disable (reset) output
	//accsimuDisable (DC0);
	//accsimuDisable (DC1);
	//accsimuDisable (DC2);
	
	// Close DC power board
	accsimuClose (&DC0);
	accsimuClose (&DC1);
	accsimuClose (&DC2);
	
	gDone = 1; // Signal the main thread to exit the while loop in RTMain
	
	return 0;
}


/*
	Transfer data from RT to host
 */
int Update (void)
{
	CmtGetLock (gLock);
	// Create message with program state and send to host executable.
	if (StatusTCP != TCP_INVALID_CONNECTION)
	{
		// ClientTCPWrite does not guarantee that all Data will be transferred in
		// a single call, but this code assumes that it does for simplicity.
		ClientTCPWrite (StatusTCP, &Data, sizeof(Data), 5000);
	}
	CmtReleaseLock (gLock);
	
	return 0;
}


/*
	Refresh current to DC power board
 */
int Refresh(void)
{
	double timeUS, timeMS;
	
	timeMS = (double) GetTimeUS () / 1000.0;
	//printf("%f\r\n", timeMS); 
	
	Data.timeSet = timeMS;
	Data.currentSet[0] = DC0.currentLevel;
	Data.currentSet[1] = DC1.currentLevel;
	Data.currentSet[2] = DC2.currentLevel;
	
	// Set current
	accsimuSet4141 (DC0);
	accsimuSet4130 (DC1);
	accsimuSet4130 (DC2);
	
	//Delay(0.0002); 
	
	// Measure
	accsimuMeasure(&DC0);
	accsimuMeasure(&DC1);
	accsimuMeasure(&DC2);
	
	timeMS = (double) GetTimeUS () / 1000.0;
	//printf("%f\r\n", timeMS);
	
	Data.timeGet = timeMS;
	Data.currentGet[0] = DC0.measuredCurrent;
	Data.currentGet[1] = DC1.measuredCurrent;
	Data.currentGet[2] = DC2.measuredCurrent;
	
	Update();
	
	return 0;
}



/*
	Timer
 */
int CVICALLBACK TimerCurrentRefresh(int reserved, int timerId, int event, void *callbackData, int eventData1, int eventData2)
{
	
	double w[3] = {0};
	double f[3] = {0};
	
	if (event == EVENT_TIMER_TICK)
	{
		CmtGetLock (gLock);
		
		/*if (FlagRefresh == 0)
			SuspendAsyncTimerCallbacks();*/
		/*if ((CounterRefresh == 1000) || (gDone != 0))
		{
			printf("Timer closed success!\n");
			SuspendAsyncTimerCallbacks();
		}*/
		
		
		//DC0.currentLevel = 0.64e-3 * cos((double)CounterRefresh);
		//DC1.currentLevel = 0.64e-3 * cos((double)CounterRefresh + pi / 4);
		//DC2.currentLevel = 0.64e-3 * cos((double)CounterRefresh + pi / 2);
		
		DC0.currentLevel = 0.32e-3;
		DC1.currentLevel = 0.32e-3; 
		DC2.currentLevel = 0.32e-3;
		
		
		//DC0.currentLevel = w[0] = 0.0005e-3 * CounterRefresh * 2;
		//DC1.currentLevel = w[1] = 0.0005e-3 * CounterRefresh * 2;
		//DC2.currentLevel = w[2] = 0.0005e-3 * CounterRefresh * 2;

		CounterRefresh ++;
		
		FlagRefreshPre = FlagRefreshAfter;
		FlagRefreshAfter = (FlagRefreshPre == 0) ? 1 : 0;
		//printf("Set data!\n");
		
		Refresh();
		
		// Transfer to MC
		//rfmIMU(w, f);
		
		CmtReleaseLock (gLock); 
		
	}
	
	return 0;
}


/*
	Thread of DCPower operation
 */
static int CVICALLBACK ThreadFunction(void *functionData)
{
	// CPU2
	SetProcessorAffinityForThread (kProcessorPool_None, 1, NULL, NULL);
	
	while (FlagThread)
	{
		SleepUS (50);
		
		if (FlagRefreshPre != FlagRefreshAfter)
		{
			CmtGetLock (gLock);
			printf("Get data!\n");
			Refresh();
			CmtReleaseLock (gLock); 
		}
		
	}
	
	return 0;
}





