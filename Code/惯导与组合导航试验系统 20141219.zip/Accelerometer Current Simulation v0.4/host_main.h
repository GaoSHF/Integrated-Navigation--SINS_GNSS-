/**************************************************************************/
/* LabWindows/CVI User Interface Resource (UIR) Include File              */
/* Copyright (c) National Instruments 2013. All Rights Reserved.          */
/*                                                                        */
/* WARNING: Do not add to, delete from, or otherwise modify the contents  */
/*          of this include file.                                         */
/**************************************************************************/

#include <userint.h>

#ifdef __cplusplus
    extern "C" {
#endif

     /* Panels and Controls: */

#define  PANEL                            1
#define  PANEL_ACCELERATION2              2
#define  PANEL_ACCELERATION1              3
#define  PANEL_ACCELERATION0              4
#define  PANEL_DECORATION_8               5
#define  PANEL_MEASUREDVOLTAGE2           6
#define  PANEL_MEASUREDCURRENT2           7
#define  PANEL_COMPLIANCE2                8
#define  PANEL_LABEL_DC2                  9
#define  PANEL_START                      10      /* callback function: Start */
#define  PANEL_DECORATION_7               11
#define  PANEL_MEASUREDVOLTAGE1           12
#define  PANEL_MEASUREDCURRENT1           13
#define  PANEL_COMPLIANCE1                14
#define  PANEL_LABEL_DC1                  15
#define  PANEL_QUIT                       16      /* callback function: Quit */
#define  PANEL_DECORATION_6               17
#define  PANEL_MEASUREDVOLTAGE0           18
#define  PANEL_MEASUREDCURRENT0           19
#define  PANEL_COMPLIANCE0                20
#define  PANEL_LABEL_DC0                  21
#define  PANEL_STRING_TCP_STATUS          22
#define  PANEL_TOGGLEBUTTON               23      /* callback function: buttonRefresh */
#define  PANEL_TIMER                      24      /* callback function: timer */


     /* Menu Bars, Menus, and Menu Items: */

          /* (no menu bars in the resource file) */


     /* Callback Prototypes: */

int  CVICALLBACK buttonRefresh(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK Quit(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK Start(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK timer(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);


#ifdef __cplusplus
    }
#endif
