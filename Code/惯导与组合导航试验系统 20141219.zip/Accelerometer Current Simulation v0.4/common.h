#ifndef _COMMON_H_
#define _COMMON_H_


#define TCP_INVALID_CONNECTION 	((unsigned int)-1) 

#define HOST_ADDRESS 			"169.254.176.1"
#define HOST_PORT 				10001


#define START_COMMAND			1
#define STOP_COMMAND			2
#define QUIT_COMMAND			3

#define SELFTEST_COMMAND        4

#define GPSRECEIVE_COMMAND      5  
#define INSRECEIVE_COMMAND      6

#define GPSSIM_COMMAND          7
#define GPSSIM_AGC_COMMAND      8
#define	GPSSIM_IO_CHANGE_COMMAND	9

#define	ACCSIMU_SET_COMMAND		10
#define	ACCSIMU_GET_COMMAND		11

#define	ACCSIMU_REFRESH_COMMAND		12

#define	STATUS_ON	1
#define	STATUS_OFF	0






#define FILE_PATH_CURRENT	"c:\\current.txt"
#define FILE_PATH_CURRENT_RT	"c:\\current.txt" 




// Command message structure
typedef struct
{
	int countertime;
	
	int statusYCReceive;
	
	int statusINSReceive;
	
	int statusGPSReceive;
	
	int statusSimulator;
	
	int statusRefresh;
	
	int valueAGC;
	
	int	command;
	
	double acceleration[3];
	
	double measuredVoltage[3];
	double measuredCurrent[3];
   	int inCompliance[3];
} CommandMessage;

// Data structure
typedef struct
{
	double timeSet;
    double currentSet[3];
	double timeGet;
	double currentGet[3];
} DataMessage;








#endif

