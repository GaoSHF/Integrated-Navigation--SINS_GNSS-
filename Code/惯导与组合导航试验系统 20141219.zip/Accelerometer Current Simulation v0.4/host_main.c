/******************************************************************************/
/*                                                                            */
/* National Instruments - NI-DCPower - CVI Examples                           */
/*                                                                            */
/* NI-DCPower Source DC Current                                               */
/*                                                                            */
/* Demonstrates how to use the DC Current Output Function to force an output  */
/* current.  This example initializes a session, configures the Output        */
/* Function, Sense, Autorange, Current Level and Voltage Limit, initiates     */
/* generation, waits for a specified delay, and measures the voltage and      */
/* current output.  This example uses Single Point source mode.               */
/*                                                                            */
/* Functions Utilized:                                                        */
/*                                                                            */
/* niDCPower_InitializeWithChannels                                           */
/* niDCPower_ConfigureSourceMode                                              */
/* niDCPower_ConfigureOutputFunction                                          */
/* niDCPower_ConfigureSense                                                   */
/* niDCPower_ConfigureCurrentLevel                                            */
/* niDCPower_ConfigureVoltageLimit                                            */
/* niDCPower_ConfigureCurrentLevelRange                                       */
/* niDCPower_ConfigureVoltageLimitRange                                       */
/* niDCPower_Initiate                                                         */
/* niDCPower_MeasureMultiple                                                  */
/* niDCPower_QueryInCompliance                                                */
/* niDCPower_ConfigureOutputEnabled                                           */
/* niDCPower_close                                                            */
/*                                                                            */
/******************************************************************************/

#include <ansi_c.h>
#include <cvirte.h>		
#include <userint.h>
#include <utility.h>
#include <tcpsupp.h>
#include <visatype.h>

#include "common.h"
#include "host_main.h"

static int HandlePanel;

static unsigned int	StatusTCP = TCP_INVALID_CONNECTION;


CommandMessage Cmd;

int FlagTimer = 0;


FILE *FileHandleCurrent = NULL;

DataMessage Data;



int CVICALLBACK TCPDataCallback (unsigned handle, int xType, int errCode, 
	void *callbackData);

int InitPanel(void);



/*
	main entry
 */
int main (int argc, char *argv[])
{
	if (InitCVIRTE (0, argv, 0) == 0)
		return -1;	/* out of memory */
	if ((HandlePanel = LoadPanel (0, "host_main.uir", PANEL)) < 0)
		return -1;
  
	RegisterTCPServer (HOST_PORT, TCPDataCallback, 0); 
	
   
   
   
	DisplayPanel (HandlePanel);
	InitPanel();
   
	RunUserInterface ();
   
	DiscardPanel (HandlePanel);
   
	UnregisterTCPServer(HOST_PORT);            
   
	return 0;
}


/*
	Initiate panel
 */
int InitPanel()
{

	SetCtrlVal(HandlePanel, PANEL_STRING_TCP_STATUS, "Waiting for connection.");
	
	return 0;
}



/*
	TCP/IP callback
 */
int CVICALLBACK TCPDataCallback (unsigned handle, int xType, int errCode, 
	void *callbackData)
{
	
	switch (xType)
    {
        case TCP_CONNECT:
            // Accept only one client connection
            if (StatusTCP != TCP_INVALID_CONNECTION)
                DisconnectTCPClient (handle);
            else
                StatusTCP = handle;
			SetCtrlVal (HandlePanel, PANEL_STRING_TCP_STATUS, "Connected.");
            break;
			
        case TCP_DISCONNECT:
            StatusTCP = TCP_INVALID_CONNECTION;
			SetCtrlVal (HandlePanel, PANEL_STRING_TCP_STATUS, "Waiting for connection.");
            break;
			
        case TCP_DATAREADY:
			/*ServerTCPRead (StatusTCP, &Cmd, sizeof(Cmd), 5000);
			
			SetCtrlAttribute (HandlePanel, PANEL_MEASUREDCURRENT0, ATTR_CTRL_VAL, Cmd.measuredCurrent[0]);
			SetCtrlAttribute (HandlePanel, PANEL_MEASUREDVOLTAGE0, ATTR_CTRL_VAL, Cmd.measuredVoltage[0]);
			SetCtrlAttribute (HandlePanel, PANEL_COMPLIANCE0, ATTR_CTRL_VAL, Cmd.inCompliance[0]);
			
			SetCtrlAttribute (HandlePanel, PANEL_MEASUREDCURRENT1, ATTR_CTRL_VAL, Cmd.measuredCurrent[1]);
			SetCtrlAttribute (HandlePanel, PANEL_MEASUREDVOLTAGE1, ATTR_CTRL_VAL, Cmd.measuredVoltage[1]);
			SetCtrlAttribute (HandlePanel, PANEL_COMPLIANCE1, ATTR_CTRL_VAL, Cmd.inCompliance[1]);
			
			SetCtrlAttribute (HandlePanel, PANEL_MEASUREDCURRENT2, ATTR_CTRL_VAL, Cmd.measuredCurrent[2]);
			SetCtrlAttribute (HandlePanel, PANEL_MEASUREDVOLTAGE2, ATTR_CTRL_VAL, Cmd.measuredVoltage[2]);
			SetCtrlAttribute (HandlePanel, PANEL_COMPLIANCE2, ATTR_CTRL_VAL, Cmd.inCompliance[2]);
			
			if ((Cmd.inCompliance[0] != 0) && (Cmd.inCompliance[1] != 0) && (Cmd.inCompliance[2] != 0))
				FlagTimer = 0;*/
			
			ServerTCPRead (StatusTCP, &Data, sizeof(Data), 5000);
			
			fprintf(FileHandleCurrent, "%f\t", Data.timeSet);
			fprintf(FileHandleCurrent, "%f\t", Data.timeGet);
			
			fprintf(FileHandleCurrent, "%f\t", Data.currentSet[0]);
			fprintf(FileHandleCurrent, "%f\t", Data.currentGet[0]);
			
			fprintf(FileHandleCurrent, "%f\t", Data.currentSet[1]);
			fprintf(FileHandleCurrent, "%f\t", Data.currentGet[1]);
			
			fprintf(FileHandleCurrent, "%f\t", Data.currentSet[2]);
			fprintf(FileHandleCurrent, "%f\n", Data.currentGet[2]);
			
            break;
    }
    
    return 0;
}




/*
	Quit callback
 */
int CVICALLBACK Quit (int panel, int control, int event,
                      void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
	case EVENT_COMMIT:
		if (StatusTCP != TCP_INVALID_CONNECTION) {
      		Cmd.command = QUIT_COMMAND;
		
			ServerTCPWrite (StatusTCP, &Cmd, sizeof(Cmd), 5000);
		}
	   
		QuitUserInterface (0);
		break;
	}

	return 0;
}



/*
	Start callback
 */
int CVICALLBACK Start (int panel, int control, int event,
                       void *callbackData, int eventData1, int eventData2)
{
   ViReal64 acceleration0 = 1, acceleration1 = 0, acceleration2 = 0;
   ViReal64 measuredVoltage0 = 0, measuredVoltage1 = 0, measuredVoltage2 = 0;
   ViReal64 measuredCurrent0 = 0, measuredCurrent1 = 0, measuredCurrent2 = 0;
   ViBoolean inCompliance0 = 0, inCompliance1 = 0, inCompliance2 = 0;
   
   ViStatus error = VI_SUCCESS;

	switch (event)
	{
		case EVENT_COMMIT:

		if (StatusTCP != TCP_INVALID_CONNECTION)
		{
         /* Disable START button. */
         SetCtrlAttribute (HandlePanel, PANEL_START, ATTR_DIMMED, 1);
         SetWaitCursor (1);
         ProcessDrawEvents ();

			/* Get the values from the UI. */
			GetCtrlAttribute (HandlePanel, PANEL_ACCELERATION0, ATTR_CTRL_VAL, &acceleration0);
			GetCtrlAttribute (HandlePanel, PANEL_ACCELERATION1, ATTR_CTRL_VAL, &acceleration1);
			GetCtrlAttribute (HandlePanel, PANEL_ACCELERATION2, ATTR_CTRL_VAL, &acceleration2); 
		 
		 
			Cmd.command = ACCSIMU_SET_COMMAND;
		
			Cmd.acceleration[0] = acceleration0;
			Cmd.acceleration[1] = acceleration1;
			Cmd.acceleration[2] = acceleration2;
		
			ServerTCPWrite (StatusTCP, &Cmd, sizeof(Cmd), 5000);
		 
		
			/* Enable START button. */
			SetCtrlAttribute (HandlePanel, PANEL_START, ATTR_DIMMED, 0);

			SetWaitCursor (0);
			ProcessDrawEvents ();
			
			FlagTimer = 1;
		}

		break;
	}

	/* Process any errors. */
	if(error < VI_SUCCESS) {
		/* Enable START button. */
		SetCtrlAttribute (HandlePanel, PANEL_START, ATTR_DIMMED, 0);
		SetWaitCursor (0);
		ProcessDrawEvents ();
	}

	return 0;
}



/*
	PXI-4141 measurement timer
 */
int CVICALLBACK timer (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{

	switch (event)
	{
		case EVENT_TIMER_TICK:
 
			/*if (FlagTimer == 1)
			{
				Cmd.command = ACCSIMU_GET_COMMAND;
		
				ServerTCPWrite (StatusTCP, &Cmd, sizeof(Cmd), 5000);	
			}*/
			
			break;
	}
	return 0;
}



/*
	Refresh button callback
 */
int CVICALLBACK buttonRefresh (int panel, int control, int event,
                       void *callbackData, int eventData1, int eventData2)
{
	
	int value;
	
	switch (event)
	{
		case EVENT_COMMIT:
			GetCtrlVal (HandlePanel, PANEL_TOGGLEBUTTON, &value);
			if (value == 1)
			{
				SetCtrlAttribute (HandlePanel, PANEL_START, ATTR_DIMMED, 1);
				
				FileHandleCurrent = fopen(FILE_PATH_CURRENT, "w");
				
				Cmd.command = ACCSIMU_REFRESH_COMMAND;
				Cmd.statusRefresh = 1;
				ServerTCPWrite (StatusTCP, &Cmd, sizeof(Cmd), 5000);
			}
			else if (value == 0)
			{
				SetCtrlAttribute (HandlePanel, PANEL_START, ATTR_DIMMED, 0);
				
				Cmd.command = ACCSIMU_REFRESH_COMMAND;
				Cmd.statusRefresh = 0;
				ServerTCPWrite (StatusTCP, &Cmd, sizeof(Cmd), 5000);
				
				fclose(FileHandleCurrent);
				
			}
			break;
	}
	
	return 0;
}








