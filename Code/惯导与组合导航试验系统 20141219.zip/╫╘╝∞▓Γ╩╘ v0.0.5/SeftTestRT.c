//==============================================================================
//
// Title:		SelftestRT
// Purpose:		A simple test for hardware.
//
// Created on:	2014-6-26 at 9:00:00 by ZZY.
// Copyright:	buaa. All Rights Reserved.
//
//==============================================================================

//==============================================================================

// Include files
#include <rtutil.h>
#include <utility.h>
#include <ansi_c.h>
#include <tcpsupp.h>
#include <userint.h>
#include <cvinetv.h>  

#include "common.h"
#include "selftestRT.h"
#include "RS422.h"    
#include "P3531.h"
#include "P3530.h"
#include "acc_simu.h" 
volatile int gDone;

RS422_DevHandle DeviceHandle422Com3;
RS422_DevHandle DeviceHandle422Com4;

void CallbackMCTestInit(void);  
void CallbackDSTestInit(void); 
void CallbackRTQuit(void);
int CallbackSelftest422(void);
int CallbackSelftest429(void);
int CallbackSelftest1553B(void);
int CallbackSelftestCurrent(void);

//RT main entry
void CVIFUNC_C RTmain (void)
{
	CNVData SelfTestFinshData;
	unsigned int prevProcessorMask = 0;
	
	StatusTcpRT = TCP_INVALID_CONNECTION;
	
	if (InitCVIRTE (0, 0, 0) == 0)
		return;    /* out of memory */
	
	// Configure the system processor pool to only include the first processor on the system.
	ConfigureProcessorPool (kProcessorPool_System, 0xFFFFFFFF, &prevProcessorMask);

	CmtNewLock (0, 0, &gLock);
	CmtNewThreadPool (10, &gThreadPool);

	printf("Start RT programme successfully!\n");

	// Create a TCP server to communicate with RT target.
    RegisterTCPServer (HOST_PORT, TCPDataCallback, 0);

	while (!RTIsShuttingDown () && !gDone)
	{
		/* Sleep for some amount of time to give the desired loop rate */
		/* and to allow lower priority threads to run.                 */
		ProcessSystemEvents();
		SleepUS (100);
	} 

	
	if (gThreadPool)
		// CmtDiscardThreadPool waits for the thread function to exit.
		CmtDiscardThreadPool (gThreadPool);
	 
	if (prevProcessorMask)
		ConfigureProcessorPool (kProcessorPool_System, prevProcessorMask, NULL);
	
	CmtDiscardLock (gLock);
	
	UnregisterTCPServer(HOST_PORT);
	
Done:  	
	CloseCVIRTE ();
}

//TCP callback  
int CVICALLBACK TCPDataCallback (unsigned handle, int xType, int errCode, void *cbData)
{
    switch (xType)
    {
		case TCP_CONNECT:
			StatusTcpRT = handle;
			printf("TCP connected!\n");
            break;
        case TCP_DISCONNECT:
            StatusTcpRT = TCP_INVALID_CONNECTION;
			printf("TCP disconnected!\n");
            break;
        case TCP_DATAREADY: //ʵʱ������ָ�� 

			ServerTCPRead (StatusTcpRT, &CmdRT, sizeof(CmdRT), 5000);
			switch(CmdRT.command)
			{
				case MC_TEST:
					CallbackMCTestInit();
				    break; 
				case DS_TEST:  
					CallbackDSTestInit();
				    break; 		
				case RT_QUIT_COMMAND:
					CallbackRTQuit();
					break;
				
				case CHECK_422:
					CallbackSelftest422();
					break;
					
				case CHECK_429:
					CallbackSelftest429();
					break;
					
				case CHECK_1553:
					CallbackSelftest1553B();
					break;
					
				case CHECK_CURRENT:
					CallbackSelftestCurrent();
					break;
			}
            break;
    }
    return 0;
}

//DS test initial callback
void CallbackMCTestInit(void)
{

}

//MC test initial callback
void CallbackDSTestInit(void)
{
	accsimuInit(&DC0);
	accsimuInit(&DC1);
	accsimuInit(&DC2);
}

//Quit callback
void CallbackRTQuit(void)
{
	gDone = 1;
	printf("Quit RT program successfully.\n");
}



//422 selftest
int CallbackSelftest422(void) 
{
	unsigned long long timeStart;
	unsigned long long timePresent;
	
	int status, i, j;
	int k = 0; 
 	//char a[10] = {1,3,5,7,9,11,13,15,17,19};
	//char b[10] = {0};
	unsigned int lenReceived = 0;
	unsigned int lenError = 0;
	
	
	DeviceHandle422Com3.bps = SERIAL_BPS;
	if (CmdRT.selftestMode == SELFTEST_MODE_MC)
		DeviceHandle422Com3.comValue = COM3;
	else
		DeviceHandle422Com3.comValue = COM5;
	DeviceHandle422Com3.check = NOPARITY;
	DeviceHandle422Com3.data = 8;
	DeviceHandle422Com3.stop = 1;
	
	DeviceHandle422Com4.bps = SERIAL_BPS;
	if (CmdRT.selftestMode == SELFTEST_MODE_MC)
		DeviceHandle422Com4.comValue = COM4;
	else
		DeviceHandle422Com4.comValue = COM6;
	DeviceHandle422Com4.check = NOPARITY;
	DeviceHandle422Com4.data = 8;
	DeviceHandle422Com4.stop = 1;
	
	if (!RS422_OpenConfig(DeviceHandle422Com3))
	{
		RS422_Close(DeviceHandle422Com3);
	}
	
	if (!RS422_OpenConfig(DeviceHandle422Com4))
	{
		RS422_Close(DeviceHandle422Com4);
	}
	
	// ******** Test COM3
	
	// Write data
	for(i=0;i<10;i++)
	{
		//ComWrtByte (DeviceHandle422Com3.comValue,a[i]);
		ComWrtByte (DeviceHandle422Com3.comValue,CmdRT.selftestData422[i]);
	}
	
	// Check if read enough data
	// Get start time
	timeStart = GetTimeUS();
	while(lenReceived != 10)
	{
		lenReceived = GetInQLen (DeviceHandle422Com3.comValue);
		
		// Get present time
		timePresent = GetTimeUS();
		
		if ((timePresent - timeStart) / 1000000 > 5)
		{
			printf("Selftest RS422: COM3 over time\r\n");
			break;
		}
	}
	
	if (lenReceived == 10)
	{
		// read data
		for(i = 0; i < 10; i++)
		{		
			//b[i] = ComRdByte(DeviceHandle422Com3.comValue);
			DataRT.selftestData422COM3[i] = ComRdByte(DeviceHandle422Com3.comValue);
		}
		CloseCom (DeviceHandle422Com3.comValue);
	
		// Check data
		lenError = 0;
		for(j = 0; j < lenReceived; j++) 
		{
			if(DataRT.selftestData422COM3[j] != CmdRT.selftestData422[j])
			{
				lenError ++;
			}
		}
		if (lenError == 0)
		{
			printf("Selftest RS422: COM3 success\r\n");
		}
		else
		{
			printf("Selftest RS422: COM3 data error rate %.2f\r\n", (double)lenError / (double)lenReceived);
		}
	}
	
	
	// ******** Test COM4
	
	// Write data
	for(i = 0; i < 10; i ++)
	{
		//ComWrtByte (DeviceHandle422Com4.comValue, a[i]);
		ComWrtByte (DeviceHandle422Com4.comValue,CmdRT.selftestData422[i]);
	}
	
	// Check if read enough data
	// Get start time
	timeStart = GetTimeUS();
	while(lenReceived != 10)
	{
		lenReceived = GetInQLen (DeviceHandle422Com4.comValue);
		
		// Get present time
		timePresent = GetTimeUS();
		
		if ((timePresent - timeStart) / 1000000 > 5)
		{
			printf("Selftest RS422: COM4 over time\r\n");
			Update();
			break;
		}
	}
	
	if (lenReceived == 10)
	{
		// read data
		for(i = 0; i < 10; i++)
		{		
			//b[i] = ComRdByte(DeviceHandle422Com4.comValue);
			DataRT.selftestData422COM4[i] = ComRdByte(DeviceHandle422Com4.comValue);
		}
		CloseCom (DeviceHandle422Com4.comValue);
	
		// Check data
		lenError = 0;
		for(j = 0; j < lenReceived; j++)
		{
			if(DataRT.selftestData422COM4[j] != CmdRT.selftestData422[j])
			{
				lenError ++;
			}
		}

		if (lenError == 0)
		{
			printf("Selftest RS422: COM4 success\r\n");
		}
		else
		{
			printf("Selftest RS422: COM4 data error rate %.2f\r\n", (double)lenError / (double)lenReceived);
		}
	}
	
	DataRT.selftestBoard = SELFTEST_BOARD_422;
	Update();
	
   	return 0;   
}

//429 selftest
int CallbackSelftest429(void)
{
	unsigned long long timeStart;
	unsigned long long timePresent;
	
	unsigned int lenError = 0;
	
	PS_DevHandle   PS3531_hDev; 
	int status,i,j;
	int k=0;
	int countOfCards = 0;  
	int countOfModules = 0;
	int msgCount=0; 
	int lengthRead ;
	//int a[10]={9,8,7,6,5,4,3,2,1,0};
	int b[10]={0};
	PS_DevInfoHandle pDevs = NULL; 
	status = P3531_ScanDevices(&pDevs, &countOfCards);
	if(countOfCards < 1)
	{
		printf("Selftest 429: Board not found\r\n");
		return SELFFAIL_429; 
	}
	status = P3531_OpenDevice(pDevs, &PS3531_hDev);	
	if (status != PS_SUCCESS)
	{
		printf("Selftest 429: Board open failed\r\n");
		return SELFFAIL_429;
	}
	P3531_ReleaseDevInfo(pDevs);	// release all the device information.     
	P3531_GetCountOfModule(PS3531_hDev, &countOfModules);  // get moudles number
	for(i=0; i < countOfModules; ++i)
	{
		P3531_ResetModule(PS3531_hDev, i);
		P3531_ConfigureModule(PS3531_hDev, i, MODULE_DISABLE_SELF_TEST); // disable self-test
	}  
	// Enable Rx channel and clear Rx FIFO
	status = P3531_EnableRCVChannel(PS3531_hDev, 0, 1);	 	
	status = P3531_ResetRCVFIFO(PS3531_hDev, 0);
	status = P3531_ResetSNDFIFO(PS3531_hDev, 0); 
	
	for(j = 0; j < 10; j++)
	{
		status = P3531_LoadMessage(PS3531_hDev, 0, CmdRT.selftestData429[j]);    // transmit data
		//printf("tx = %d\r\n", CmdRT.selftestData429[j]);
	}
	
	// Get start time
	timeStart = GetTimeUS();
	while(msgCount!=10)
	{
		status = P3531_GetCountOfRCVDMessage(PS3531_hDev, 0, &msgCount);
		// Get present time
		timePresent = GetTimeUS();
		
		if ((timePresent - timeStart) / 1000000 > 5)
		{
			printf("Selftest 429: over time\r\n");
			break;
		}
	}
	for(i=0;i<10;i++)
	{
		status = P3531_ReadNextData(PS3531_hDev, 0, &(DataRT.selftestData429[i]));    // receive data
		//printf("rx = %d\r\n", DataRT.selftestData429[i]);
		DataRT.selftestData429[i] &= 0x7FFFFFFF;
	}
	
	DataRT.selftestBoard = SELFTEST_BOARD_429;
	Update();
	
	
	/*lenError = 0;
	for(i=0;i<10;i++)
	{
		b[i] &= 0x7FFFFFFF;
		if(DataRT.selftestData429[i]!=CmdRT.selftestData429[i])
		{
			lenError ++;
		}
	}
	P3531_LightenLED(PS3531_hDev,8);	// light the led 0 and 1 
	P3531_CloseDevice(PS3531_hDev); 
	
	if (lenError == 0)
	{
		printf("Selftest 429: success\r\n");
	}
	else
	{
		printf("Selftest 429: data error rate %.2f\r\n", (double)lenError / 10);
	}*/
	return SELFTEST_SUCCESS;
}

//1553 selftest
int CallbackSelftest1553B(void)
{
	PS_DevHandle   PS3530_hDev;
	
	unsigned int lenError;
	
	// 1553 board parameters
	PS_DevInfoHandle  pDevs = NULL;
	int countOfCards = 0;
	
	//����Channel 1 Ϊ RT
	unsigned char RTsubAddress=1;
	unsigned int  RTmodule=1;
	unsigned char rtAddr = 1;
	unsigned char RTmsgCountOut=0;
	MSG_RECEIVE RTmsgReceive;
	
	
	//����Channel 0 Ϊ BC
	unsigned char BCsubAddress=1;
	unsigned int BCmodule=0;
	MSG_SEND BCmsgSend;
	unsigned int  BCmsgCount=1; 
	unsigned int BCmsgIndex=0;
	
	unsigned int sizeofblock = 10;
	unsigned long flag = 1; 
	unsigned char i = 0;

	
	SUBADDR_LKP_TBL subaddressLookupTable;
	subaddressLookupTable.Bcst_SAn=0x400;
	subaddressLookupTable.Rx_Bcst_SAn=0x800;
	subaddressLookupTable.Tx_SAn=0x400;
	subaddressLookupTable.SACW_SAn=0x80;
	
	// Init 1553
	P3530_ScanDevices(&pDevs, &countOfCards);
	P3530_OpenDevice(pDevs, &PS3530_hDev);
	P3530_ReleaseDevInfo(pDevs);
	
	
	// ******** ��ʼ��RT
	//��ʼ��RTģʽ
	P3530_SetMode(PS3530_hDev, RTmodule, MODE_RT);
	//��ʼ��RT��ַ
	P3530_RTSetAddr(PS3530_hDev, RTmodule, rtAddr);
	//�����Զ�������Ϣ����
	P3530_RTMTSetAutoBufferMsg(PS3530_hDev, RTmodule, 0);
	//����SubaddressLookupTable(�˴���ʹ�õ��ӵ�ַΪ1,������/�㲥���յ�ַ��Ϊ���õ�ַ0x800,
	//�����͵�ַ��Ϊ0x400,�ӵ�ַ��ȡģʽ��Ϊ��ռ1K�ռ��ѭ������ģʽ.)
	P3530_RTSetSubaddressLookupTablesABySubaddress(PS3530_hDev,RTmodule,RTsubAddress,&subaddressLookupTable);
	
	
	
	// ******** BC���Լ�����д��RT
	//��ʼ��BCģʽ
	P3530_SetMode(PS3530_hDev,BCmodule,MODE_BC);
	//��������֡��Ϣ
	BCmsgSend.msgGapTime=0x320;
	BCmsgSend.controlWord=0x80;
	//BCmsgSend.msgBlock[0]=0x825;//��ȡ��Ϣ
	BCmsgSend.msgBlock[0]= (rtAddr<<11)|(0x0<<10)|(BCsubAddress<<5)|sizeofblock;
	for (int j = 0; j < sizeofblock; j++)
	{
		//BCmsgSend.msgBlock[j + 1] = j;
		BCmsgSend.msgBlock[j + 1] = CmdRT.selftestData1553[j];
	}

	//д����Ϣ	  
	P3530_BCWriteMsg(PS3530_hDev, BCmodule,0, &BCmsgSend, sizeofblock + 1);
	//����֡��Ϣ����
	P3530_BCSetFrameMsgCount(PS3530_hDev,BCmodule,BCmsgCount);
	//����֡��ʼ��Ϣ����
	P3530_BCSetFrameMsgStartIndex(PS3530_hDev,BCmodule,BCmsgIndex);
	//����BC
	P3530_BCMTStart(PS3530_hDev,BCmodule);
	//�ȴ���ǰ֡�������
 	while (flag)
	{
		P3530_BCIsFrmInProgress(PS3530_hDev, BCmodule, &flag);
	}
	
	// ******** RT�����Լ�����
	//RT��ȡ��Ϣ
	P3530_RTMTMsgCount(PS3530_hDev, RTmodule, &RTmsgCountOut);
	for(i = 0; i < 37; i++)   
	{
		RTmsgReceive.msgBlock[i] =0;
	}
	
	for(i = 0; i < RTmsgCountOut; i++)
	{
		P3530_RTMTReadMsg(PS3530_hDev, RTmodule, &RTmsgReceive);
	}
	
	// Close 1553
	P3530_CloseDevice(PS3530_hDev);
	
	// Check data
	lenError = 0;
	for(i = 0; i < sizeofblock; i++)
	{
		
		DataRT.selftestData1553[i] = RTmsgReceive.msgBlock[i + 1];
		
		//printf("%d\r\n", RTmsgReceive.msgBlock[i + 1]);
		if(BCmsgSend.msgBlock[i + 1] != RTmsgReceive.msgBlock[i + 1])
		{
			lenError ++;
		}	
	}
	
	if (lenError == 0)
	{
		printf("Selftest 1553B: success\r\n");
	}
	else
	{
		printf("Selftest 1553B: data error rate %.2f\r\n", (double)lenError / sizeofblock);
	}
	
	DataRT.selftestBoard = SELFTEST_BOARD_1553;
	Update();
	
	return SELFTEST_SUCCESS;
}

//Current selftest
int CallbackSelftestCurrent(void)		
{
	DC0.currentLevel = CmdRT.selftestDataCurrent[0]*0.001;
	DC1.currentLevel = CmdRT.selftestDataCurrent[1]*0.001;  
	DC2.currentLevel = CmdRT.selftestDataCurrent[2]*0.001;  
	
	accsimuSet4141(DC0);
	accsimuSet4130(DC1); 
	accsimuSet4130(DC2); 
	
	return CURRENT_SET_SUCCESS;   	
}











