#ifndef _COMMON_H_
#define _COMMON_H_

#define HOST_MC_ADDRESS 			"169.254.121.1"
#define RT_MC_ADDRESS 				"169.254.121.139"

#define HOST_DS_ADDRESS 			"169.254.176.1"
#define RT_DS_ADDRESS 				"169.254.176.211"

#define HOST_PORT 				10001
#define TCP_INVALID_CONNECTION 	((unsigned int)-1)



#define	SELFTEST_BOARD_422						0
#define	SELFTEST_BOARD_429						1
#define	SELFTEST_BOARD_1553						2


// ************** Data struct from RT to HOST
typedef struct
{
	// Pulse parameters
    unsigned long laxp ;
	unsigned long laxn ; 
	unsigned long layp ; 
	unsigned long layn ; 
	unsigned long lazp ; 
	unsigned long lazn ; 
	
	unsigned long asxp ;
	unsigned long asxn ; 
	unsigned long asyp ; 
	unsigned long asyn ; 
	unsigned long aszp ; 
	unsigned long aszn ;
	
	unsigned long accumAxp;
	unsigned long accumAxn;
	unsigned long accumAyp;
	unsigned long accumAyn;
	unsigned long accumAzp;
	unsigned long accumAzn;
	
	unsigned long accumGxp;
	unsigned long accumGxn;
	unsigned long accumGyp;
	unsigned long accumGyn;
	unsigned long accumGzp;
	unsigned long accumGzn;
	
	double pulse_time;
	
	int flagPulseAccum;
	
	
	// GNSS parameters
	char sFixQuality[2]; // ��λ����
	int FixQuality;
	char FixMode[20]; // ��λģʽ
	
	double RcvTime; // ���ջ���ʱ��
	unsigned char SVs; // ������Ŀ
	double PDOP;
	
	double Lon;
	double Lat;
	double Alt;
	
	double X;
	double Y;
	double Z;
	
	double Vx;
	double Vy;
	double Vz;
	
	int sRec_OK; // �Լ�OK

	double gps_time;
	double pps_time;
	double pps_time_cha; 
	unsigned long gps_firstdata;
	//unsigned long gpsdata[128];
	
	
	// YC LVDS to 422 parameters
	double timeYC;
	double timeIntervalYC;
	unsigned short dataYC[256];
	
	// 422 GNSS paramters
	//unsigned char gnss422Data[340];
	
	// Flight control data (16 bits)
	unsigned short dataFlightControl[30];
	unsigned char dataType[5];
	double timeFC1553;
	
	// Fire control data from data simulation computer
	double TraceTime;
	double CraftPosition[3];
	int CraftGPulseOut[3];
	int CraftFPulseOut[3];
	
	// IMU data
	double timeIMU;
	double wibb[3];
	double fb[3];
	
	// Others
	int selftest_status;
	int state;
	int statusAuto;
	
	
	
	unsigned int selftestData1553[10];
	int selftestData429[10];
	char selftestData422COM3[10];
	char selftestData422COM4[10]; 
	int selftestBoard;
	int selftestMode; // �Լ�ģʽ

} DataMessage;


// ************** command for CommandMessage
#define RT_QUIT_COMMAND					1 
#define SELFTEST_COMMAND        		2

#define IM_START_COMMAND				3
#define IM_STOP_COMMAND					4
#define IM_GPSRECEIVE_COMMAND     		5  
#define IM_INSRECEIVE_COMMAND     		6 
#define IM_AUTOSTART_COMMAND			7

#define RECORD_IMU_DATA_COMMAND			8

#define FC_START_COMMAND				9
#define FC_STOP_COMMAND					10
#define FC_GPSRECEIVE_COMMAND      		11
#define FC_YCRECEIVE_COMMAND   	   		12
#define FC_FIRE_CONTROL_COMMAND   	   	13
#define FC_AUTOSTART_COMMAND			14

#define FTP_COMMAND						15

#define RT_QUIT_SUCCESS					16

#define	CHECK_422						30
#define	CHECK_429						31
#define	CHECK_1553						32

#define CHECK_CURRENT					33

#define DS_TEST							40
#define MC_TEST							41




// ****************************  Test state  
#define SELFTEST_SUCCESS	    0 
#define SELFFAIL_429        	1 
#define SELFFAIL_422         	2  
#define SELFFAIL_GERFM        	3  
#define SELFFAIL_1553B        	4
#define CURRENT_SET_SUCCESS		5


// ****************************  Test state 

#define SELFTEST_MODE_MC                 1
#define SELFTEST_MODE_DS                 2

// ************** Command sent from Host to RT
typedef struct
{
	int pulseCountTime; // �����������

	int statusPulse; // ���������ʼ/ֹͣ
	int statusGNSS429; // GNSS429��ʼ/ֹͣ
	
	int statusGNSS422FC; // �ɿ�ģʽGNSS422��ʼ/ֹͣ
	int statusYC; // ң�⿪ʼ/ֹͣ
	int statusFireControl; // ��ؿ�ʼ/ֹͣ
	int modeFireControl; //��ز���ģʽ (Dynamic / Static)
	
	int statusAutostartIM; // Inertial measuremet autostart
	int statusAutostartFC; // Flight control autostart
	
	int statusFileFTP; // File to send through FTP
	char hostUserName[30];
	char hostPassword[30];
	char hostFolderPath[100];
	
	int selftestMode; // �Լ�ģʽ MC or DS
	
	unsigned int selftestData1553[10];
	int selftestData429[10];
	char selftestData422[10];
	
	double selftestDataCurrent[3];
	
	int	command;
} CommandMessage;

// ****************************  File variables 
#define MAX_PATHNAME_LEN  260    /* includes nul byte */
char IMUSimSetFilePath[MAX_PATHNAME_LEN];
char IMUTestSetFilePath[MAX_PATHNAME_LEN];
char FCTestSetFilePath[MAX_PATHNAME_LEN]; 
char GNSSTestSetFilePath[MAX_PATHNAME_LEN];


int gLock;

int gThreadPool;

// ****************************  Global variables
unsigned int StatusTcpRT;
unsigned int StatusTcpHost;

DataMessage DataRT;
DataMessage DataHost;

CommandMessage CmdRT;
CommandMessage CmdHost;

// ****************************  Global functions
void Update (void);



#endif
