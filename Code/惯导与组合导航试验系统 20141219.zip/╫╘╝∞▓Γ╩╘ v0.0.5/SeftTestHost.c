//==============================================================================
//
// Title:		SelftestRT
// Purpose:		A simple test for hardware.
//
// Created on:	2014-6-26 at 9:00:00 by ZZY.
// Copyright:	buaa. All Rights Reserved.
//
//==============================================================================

#include <rs232.h>
#include <utility.h>
#include <userint.h>
#include <tcpsupp.h>
#include <stdio.h>

#include "Common.h"
#include "SelfTestHost.h"

#include "MAIN_PANEL.h"
#include "DS_TEST_PANEL.h" 
#include "MC_TEST_PANEL.h" 


//���ڷ���ָ��̶� CRCУ����ֱ����Ϊ���ݷ��� 
unsigned char BufferPowerOn27[8]  ={0x02, 0x05, 0x00, 0x00, 0xFF, 0x00, 0x8C, 0x09};		 //����
unsigned char BufferPowerOff27[8] ={0x02, 0x05, 0x00, 0x00, 0x00, 0x00, 0xCD, 0xF9};         //�ϵ�
unsigned char BufferPowerTest27[8]={0x02, 0x03, 0x00, 0x00, 0x00, 0x02, 0xC4, 0x38}; 		 //�ض���ѹ����

unsigned char BufferPowerOn5V2[8]  ={0x02, 0x05, 0x00, 0x00, 0xFF, 0x00, 0x8C, 0x09};		 
unsigned char BufferPowerOff5V2[8] ={0x02, 0x05, 0x00, 0x00, 0x00, 0x00, 0xCD, 0xF9};       
unsigned char BufferPowerTest5V2[8]={0x02, 0x03, 0x00, 0x00, 0x00, 0x02, 0xC4, 0x38}; 

unsigned char BufferPowerOn5V3[8]  ={0x03, 0x05, 0x00, 0x00, 0xFF, 0x00, 0x8D, 0xD8};		 
unsigned char BufferPowerOff5V3[8] ={0x03, 0x05, 0x00, 0x00, 0x00, 0x00, 0xCC, 0x28};       
unsigned char BufferPowerTest5V3[8]={0x03, 0x03, 0x00, 0x00, 0x00, 0x02, 0xC5, 0xE9}; 

unsigned char BufferPowerOn5V4[8]  ={0x04, 0x05, 0x00, 0x00, 0xFF, 0x00, 0x8C, 0x6F};		 
unsigned char BufferPowerOff5V4[8] ={0x04, 0x05, 0x00, 0x00, 0x00, 0x00, 0xCD, 0x9F};       
unsigned char BufferPowerTest5V4[8]={0x04, 0x03, 0x00, 0x00, 0x00, 0x02, 0xC4, 0x5E}; 

unsigned char BufferPowerRead[9]={1};



static int HandlePanel_Main;
static int HandlePanel_MC;
static int HandlePanel_DS;

int Program_Status;

int TextboxLine = 0;

Point PointTemp;



//main entry
int main (int argc, char *argv[])
{
    int error = 0;
	
	StatusTcpHost = TCP_INVALID_CONNECTION;
	
    /* initialize and load resources */
	
	InitCVIRTE (0, argv, 0);
	
	HandlePanel_Main = LoadPanel (0, "MAIN_PANEL.uir", MainPanel);
	
    /* display the panel and run the user interface */
	
	DisplayPanel (HandlePanel_Main);
	RunUserInterface ();	

	if (StatusTcpHost != TCP_INVALID_CONNECTION)
		DisconnectFromTCPServer (StatusTcpHost);
	
Error:
    /* clean up */
    DiscardPanel (HandlePanel_Main);
    return 0;
}

//TCP callback
int CVICALLBACK TCPDataCallback (unsigned handle, int xType, int errCode, 
	void *callbackData)
{
	int i;
	
	switch (xType)
    {
        case TCP_CONNECT:
            
			StatusTcpHost = handle;
			
            break;
        case TCP_DISCONNECT:
			
            StatusTcpHost = TCP_INVALID_CONNECTION;
			
			if(Program_Status == SELFTEST_MODE_MC)
				SetCtrlVal (HandlePanel_MC,MC_PANEL_TCP_STATUS ,"����ʵʱ���Ͽ�");
			else if(Program_Status == SELFTEST_MODE_DS)
				SetCtrlVal (HandlePanel_DS,DS_PANEL_TCP_STATUS ,"����ʵʱ���Ͽ�");
			else;			

            break;
        case TCP_DATAREADY:
			// ClientTCPRead does not guarantee that all DataHost will be transferred in
			// a single call, but this code assumes that it does for simplicity.
			ClientTCPRead (StatusTcpHost, &DataHost, sizeof(DataHost), 5000);  //��ȡTCP����״̬�ṹ�� ִ����Ӧ����
			
			switch (DataHost.selftestBoard)
			{
				case SELFTEST_BOARD_429:
					for(i = 0; i < 10; i ++ )
					{
						PointTemp.x = i + 1;
						PointTemp.y = 1;
						if (CmdHost.selftestMode == SELFTEST_MODE_MC)
							SetTableCellAttribute (HandlePanel_MC, MC_PANEL_TABLE_429_RX, PointTemp, ATTR_CTRL_VAL, DataHost.selftestData429[i]);
						else
							SetTableCellAttribute (HandlePanel_DS, DS_PANEL_TABLE_429_RX, PointTemp, ATTR_CTRL_VAL, DataHost.selftestData429[i]);	
					}
					break;
					
				case SELFTEST_BOARD_422:
					for(i = 0; i < 10; i ++ )
					{
						PointTemp.x = i + 1;
						PointTemp.y = 1;
						if (CmdHost.selftestMode == SELFTEST_MODE_MC)
							SetTableCellAttribute (HandlePanel_MC, MC_PANEL_TABLE_422_RX3, PointTemp, ATTR_CTRL_VAL, DataHost.selftestData422COM3[i]);
						else
							SetTableCellAttribute (HandlePanel_DS, DS_PANEL_TABLE_422_RX3, PointTemp, ATTR_CTRL_VAL, DataHost.selftestData422COM3[i]);
					}
					for(i = 0; i < 10; i ++ )
					{
						PointTemp.x = i + 1;
						PointTemp.y = 1;
						if (CmdHost.selftestMode == SELFTEST_MODE_MC)
							SetTableCellAttribute (HandlePanel_MC, MC_PANEL_TABLE_422_RX4, PointTemp, ATTR_CTRL_VAL, DataHost.selftestData422COM4[i]);
						else
							SetTableCellAttribute (HandlePanel_DS, DS_PANEL_TABLE_422_RX4, PointTemp, ATTR_CTRL_VAL, DataHost.selftestData422COM4[i]);
					}
					break;
					
				case SELFTEST_BOARD_1553:
					for(i = 0; i < 10; i ++ )
					{
						PointTemp.x = i + 1;
						PointTemp.y = 1;
						SetTableCellAttribute (HandlePanel_MC, MC_PANEL_TABLE_1553_RX, PointTemp, ATTR_CTRL_VAL, DataHost.selftestData1553[i]);
					}
					break;
			}
	}
	return 0;  
}			

//MC selftest callback
int CVICALLBACK MC_Test_Callback (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:
			
			CmdHost.selftestMode = SELFTEST_MODE_MC;
			
			
			ConnectToTCPServer (&StatusTcpHost, HOST_PORT, RT_MC_ADDRESS, TCPDataCallback, 0, 1000);
			if (StatusTcpHost != TCP_INVALID_CONNECTION)
			{
				SetCtrlVal (HandlePanel_MC, MC_PANEL_TCP_STATUS, "�ɹ���������ʵʱ��");
				CmdHost.command = MC_TEST;
				ClientTCPWrite (StatusTcpHost, &CmdHost, sizeof(CmdHost), 5000); 				
			}
			
			// Install sub panel  
			HandlePanel_MC = LoadPanel (HandlePanel_MC, "MC_TEST_PANEL.uir", MainPanel);
			// Wait until quit the sub panel
			DisplayPanel(HandlePanel_MC);	
			
			break;
	}
	return 0;
}

//DS selftest callback
int CVICALLBACK DS_Test_Callback (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:
			
			CmdHost.selftestMode = SELFTEST_MODE_DS;  
		
			ConnectToTCPServer (&StatusTcpHost, HOST_PORT, RT_DS_ADDRESS, TCPDataCallback, 0, 1000);
			if (StatusTcpHost != TCP_INVALID_CONNECTION)
			{
				SetCtrlVal (HandlePanel_DS,DS_PANEL_TCP_STATUS ,"�ɹ���������ʵʱ��");  
				CmdHost.command = DS_TEST;
				ClientTCPWrite (StatusTcpHost, &CmdHost, sizeof(CmdHost), 5000); 				
			}			

//			testmodeflag = MODE_FLIGHT_CONTROL; 
			// Install sub panel
			HandlePanel_DS = LoadPanel (HandlePanel_DS, "DS_TEST_PANEL.uir", MainPanel);
			// Wait until quit the sub panel
//			SetPanelAttribute (PanelHandleFC, ATTR_WINDOW_ZOOM, VAL_MAXIMIZE);
			DisplayPanel(HandlePanel_DS);
			
			break;
	}
	return 0;
}

//Quit button
int CVICALLBACK Quit_Callback (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:

			if (StatusTcpHost != TCP_INVALID_CONNECTION)
			{
				CmdHost.command = RT_QUIT_COMMAND; 
				ClientTCPWrite (StatusTcpHost, &CmdHost, sizeof(CmdHost), 1000);
			}

			DiscardPanel (HandlePanel_MC); 
			QuitUserInterface(0);        
			
			break;
	}
	return 0;
}





/*********************Button on main control panel********************/
//Power control button
int CVICALLBACK PowerCallback (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:

			int powerstate;
			
			GetCtrlVal (HandlePanel_MC, MC_PANEL_BINARYSWITCH, &powerstate);
			
			if(powerstate)
			{
				
				OpenComConfig (4, "", 19200, 0, 8, 1, 512, 512);  //Com4����5����Դ   
				
				ComWrt (4, BufferPowerOn5V2, 8);	
				Delay(0.05);
				ComWrt (4, BufferPowerOn5V2, 8);	
				Delay(0.05);
				ComWrt (4, BufferPowerOn5V3, 8);
				Delay(0.05);
				ComWrt (4, BufferPowerOn5V3, 8);
				Delay(0.05);
			}
			else
			{
				ComWrt (4, BufferPowerOff5V2, 8);	
			  	Delay(0.05);
				ComWrt (4, BufferPowerOff5V2, 8);	
			  	Delay(0.05);
			  	ComWrt (4, BufferPowerOff5V3, 8);
			  	Delay(0.05);
				ComWrt (4, BufferPowerOff5V3, 8);
			  	Delay(0.05);
				
				CloseCom (4);  
			}
			
			break;
	}
	return 0;
}

//Check 422 MC
int CVICALLBACK MC_Check422Callback (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	int i;
	
	switch (event)
	{
		case EVENT_COMMIT:
			
			for(i = 0; i < 10; i ++ )
			{
				PointTemp.x = i + 1;
				PointTemp.y = 1;
				GetTableCellAttribute (HandlePanel_MC, MC_PANEL_TABLE_422_TX, PointTemp, ATTR_CTRL_VAL, &(CmdHost.selftestData422[i]));
			}
			
			CmdHost.command = CHECK_422;
			ClientTCPWrite (StatusTcpHost, &CmdHost, sizeof(CmdHost), 5000);    
			
			break;
	}
	return 0;
}

//Check 429 MC
int CVICALLBACK MC_Check429Callback (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	int i;
	
	switch (event)
	{
		case EVENT_COMMIT:

			for(i = 0; i < 10; i ++ )
			{
				PointTemp.x = i + 1;
				PointTemp.y = 1;
				GetTableCellAttribute (HandlePanel_MC, MC_PANEL_TABLE_429_TX, PointTemp, ATTR_CTRL_VAL, &(CmdHost.selftestData429[i]));
			}
			
			CmdHost.command = CHECK_429;
			ClientTCPWrite (StatusTcpHost, &CmdHost, sizeof(CmdHost), 5000); 
			
			break;
	}
	return 0;
}

//Check 1553 MC
int CVICALLBACK MC_Check1553Callback (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	int i;
	
	switch (event)
	{
		case EVENT_COMMIT:

			for(i = 0; i < 10; i ++ )
			{
				PointTemp.x = i + 1;
				PointTemp.y = 1;
				GetTableCellAttribute (HandlePanel_MC, MC_PANEL_TABLE_1553_TX, PointTemp, ATTR_CTRL_VAL, &(CmdHost.selftestData1553[i]));
			}
			
			CmdHost.command = CHECK_1553;
			ClientTCPWrite (StatusTcpHost, &CmdHost, sizeof(CmdHost), 5000);    
			
			break;
	}
	return 0;
}

//Back button MC
int CVICALLBACK MC_TestBackCallback (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:

			DiscardPanel (HandlePanel_MC);
			HandlePanel_MC = 0;
			
			break;
	}
	return 0;
}





/*********************Button on data simulation panel********************/   

//Check 422 DS
int CVICALLBACK DS_Check422Callback (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	int i;
	
	switch (event)
	{
		case EVENT_COMMIT:
			
			for(i = 0; i < 10; i ++ )
			{
				PointTemp.x = i + 1;
				PointTemp.y = 1;
				GetTableCellAttribute (HandlePanel_DS, DS_PANEL_TABLE_422_TX, PointTemp, ATTR_CTRL_VAL, &(CmdHost.selftestData422[i]));
			}
			
			CmdHost.command = CHECK_422;
			ClientTCPWrite (StatusTcpHost, &CmdHost, sizeof(CmdHost), 5000);    
			
			break;
	}
	return 0;
}

//Check 429 DS
int CVICALLBACK DS_Check429Callback (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	int i;
	
	switch (event)
	{
		case EVENT_COMMIT:

			for(i = 0; i < 10; i ++ )
			{
				PointTemp.x = i + 1;
				PointTemp.y = 1;
				GetTableCellAttribute (HandlePanel_DS, DS_PANEL_TABLE_429_TX, PointTemp, ATTR_CTRL_VAL, &(CmdHost.selftestData429[i]));
			}
			
			CmdHost.command = CHECK_429;
			ClientTCPWrite (StatusTcpHost, &CmdHost, sizeof(CmdHost), 5000); 
			
			break;
	}
	return 0;
}

//Chenk Current board
int CVICALLBACK DS_CheckCurrentCallback (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:

			GetCtrlVal (HandlePanel_DS, DS_PANEL_CurrentSet_0, &(CmdHost.selftestDataCurrent[0]));
			GetCtrlVal (HandlePanel_DS, DS_PANEL_CurrentSet_1, &(CmdHost.selftestDataCurrent[1]));  
			GetCtrlVal (HandlePanel_DS, DS_PANEL_CurrentSet_2, &(CmdHost.selftestDataCurrent[2]));  
			
			CmdHost.command = CHECK_CURRENT;
			ClientTCPWrite (StatusTcpHost, &CmdHost, sizeof(CmdHost), 5000);
			break;
	}
	return 0;
}

//Back button DS
int CVICALLBACK DS_TestBackCallback (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:
			
			DiscardPanel (HandlePanel_DS);
			HandlePanel_DS = 0;
			
			break;
	}
	return 0;
}



