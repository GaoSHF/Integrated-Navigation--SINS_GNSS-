#ifndef ACC_SIMU_H__
#define ACC_SIMU_H__


#include <nidcpower.h>


//#define	ACCELERATION_TO_CURRENT	(0.326667e-3)	//10/9.7959*0.32
#define	ACCELERATION_TO_CURRENT	(0.3264837e-3)	//10/9.8014*0.32   

#define	RESOURCE_NAME_LENGTH		256
#define	CHANNEL_NAME_LENGTH			2

#define	RESOURCE_NAME_X			"PXI2Slot4" 
#define	RESOURCE_NAME_Y			"PXI2Slot3"
#define	RESOURCE_NAME_Z			"PXI2Slot2" 


#define	CURRENT_LEVEL			0.00000E-3 // A
#define	VOLTAGE_LIMIT			2.00000E+0 // V
#define	CURRENT_LEVEL_RANGE		20.00000E-3 // A
#define	VOLTAGE_LIMIT_RANGE		6.00000E+0 // V
#define	SENSE					1009 // Remote
#define	CHANNEL_COUNT			0
#define	SOURCE_DELAY			50.00000E-3 // s
//������ֵ
#define CURRENT_OFFSET_VAL		    0.000004


// DC current power parameter
typedef	struct
{
	ViSession SessionVI;
	
	ViChar resourceName[RESOURCE_NAME_LENGTH];
	ViChar channelName[CHANNEL_NAME_LENGTH];
   	ViReal64 currentLevel; 
	ViReal64 voltageLimit; 
	ViReal64 currentLevelRange;
	ViReal64 voltageLimitRange;
   	ViInt32 sense; // 1009 = Remote, 1008 = Local
   	ViInt32 channelCount;
   	ViReal64 measuredVoltage;
	ViReal64 measuredCurrent;
   	ViBoolean inCompliance;
   	ViReal64 sourceDelay;

	
} DC_PARAM;


// Channel 0
extern DC_PARAM DC0;

// Channel 1
extern DC_PARAM DC1;

// Channel 2
extern DC_PARAM DC2;



int accsimuInit (DC_PARAM *dcx);


int accsimuEnable (DC_PARAM *dcx);  

int accsimuDisable (DC_PARAM *dcx);

int accsimuSet4141 (DC_PARAM dcx);
int accsimuSet4130 (DC_PARAM dcx);

int accsimuClose (DC_PARAM *dcx);

int accsimuMeasure (DC_PARAM *dcx);

int accsimuReset (DC_PARAM *dcx);


#endif
