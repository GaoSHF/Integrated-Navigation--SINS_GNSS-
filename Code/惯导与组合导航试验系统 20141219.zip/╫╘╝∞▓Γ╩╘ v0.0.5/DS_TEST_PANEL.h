/**************************************************************************/
/* LabWindows/CVI User Interface Resource (UIR) Include File              */
/* Copyright (c) National Instruments 2014. All Rights Reserved.          */
/*                                                                        */
/* WARNING: Do not add to, delete from, or otherwise modify the contents  */
/*          of this include file.                                         */
/**************************************************************************/

#include <userint.h>

#ifdef __cplusplus
    extern "C" {
#endif

     /* Panels and Controls: */

#define  DS_PANEL                         1
#define  DS_PANEL_CHECK_Current           2       /* callback function: DS_CheckCurrentCallback */
#define  DS_PANEL_CHECK_429               3       /* callback function: DS_Check429Callback */
#define  DS_PANEL_CHECK_422               4       /* callback function: DS_Check422Callback */
#define  DS_PANEL_BUTTON_BACK             5       /* callback function: DS_TestBackCallback */
#define  DS_PANEL_TABLE_422_RX4           6
#define  DS_PANEL_TABLE_422_RX3           7
#define  DS_PANEL_TCP_STATUS              8
#define  DS_PANEL_TABLE_429_RX            9
#define  DS_PANEL_TABLE_422_TX            10
#define  DS_PANEL_TABLE_429_TX            11
#define  DS_PANEL_CurrentSet_1            12
#define  DS_PANEL_CurrentSet_2            13
#define  DS_PANEL_CurrentSet_0            14
#define  DS_PANEL_TEXTMSG                 15
#define  DS_PANEL_TEXTMSG_2               16
#define  DS_PANEL_TEXTMSG_3               17


     /* Menu Bars, Menus, and Menu Items: */

          /* (no menu bars in the resource file) */


     /* Callback Prototypes: */

int  CVICALLBACK DS_Check422Callback(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK DS_Check429Callback(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK DS_CheckCurrentCallback(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK DS_TestBackCallback(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);


#ifdef __cplusplus
    }
#endif
