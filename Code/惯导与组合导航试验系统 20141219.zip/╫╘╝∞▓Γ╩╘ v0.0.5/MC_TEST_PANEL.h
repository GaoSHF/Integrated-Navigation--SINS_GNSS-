/**************************************************************************/
/* LabWindows/CVI User Interface Resource (UIR) Include File              */
/* Copyright (c) National Instruments 2014. All Rights Reserved.          */
/*                                                                        */
/* WARNING: Do not add to, delete from, or otherwise modify the contents  */
/*          of this include file.                                         */
/**************************************************************************/

#include <userint.h>

#ifdef __cplusplus
    extern "C" {
#endif

     /* Panels and Controls: */

#define  MC_PANEL                         1
#define  MC_PANEL_CHECK_1553              2       /* callback function: MC_Check1553Callback */
#define  MC_PANEL_CHECK_429               3       /* callback function: MC_Check429Callback */
#define  MC_PANEL_CHECK_422               4       /* callback function: MC_Check422Callback */
#define  MC_PANEL_BUTTON_BACK             5       /* callback function: MC_TestBackCallback */
#define  MC_PANEL_TCP_STATUS              6
#define  MC_PANEL_TABLE_422_RX4           7
#define  MC_PANEL_TABLE_422_RX3           8
#define  MC_PANEL_TABLE_1553_RX           9
#define  MC_PANEL_TABLE_1553_TX           10
#define  MC_PANEL_TABLE_429_RX            11
#define  MC_PANEL_TABLE_429_TX            12
#define  MC_PANEL_TABLE_422_TX            13
#define  MC_PANEL_BINARYSWITCH            14      /* callback function: PowerCallback */


     /* Menu Bars, Menus, and Menu Items: */

          /* (no menu bars in the resource file) */


     /* Callback Prototypes: */

int  CVICALLBACK MC_Check1553Callback(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK MC_Check422Callback(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK MC_Check429Callback(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK MC_TestBackCallback(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK PowerCallback(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);


#ifdef __cplusplus
    }
#endif
