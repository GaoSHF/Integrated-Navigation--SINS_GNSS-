#include <formatio.h>   
#include <tcpsupp.h>
#include "asynctmr.h"
#include <cvirte.h>
#include <rtutil.h>
#include <userint.h> 
#include <analysis.h>
#include <utility.h>
#include <cvinetv.h>
#include <ansi_c.h>

#include "common.h"
#include "timer.h"
#include "sensor_simu.h"
#include "simulator.h"
#include "rfm.h"


#define	INTERVAL	0.002 // s
#define	PERIOD		20 // s
#define	POINT_NUMBER	(long)(PERIOD / INTERVAL)
#define	STEP		(int)(INTERVAL * 1000)

#define	INIT_ANGLE_I	30
#define	INIT_ANGLE_M	30
#define	INIT_ANGLE_O	30

#define	INIT_RATE_I		20
#define	INIT_RATE_M		20
#define	INIT_RATE_O		5

#define	FLAG_CLIMB		0
#define	FLAG_TRACK		1



// Global variables
static unsigned int StatusTCP	= TCP_INVALID_CONNECTION;

static int gLock;

static int gThdLock;

volatile int gDone; // Signal the main thread to exit the while loop in RTMain

CommandMessage Cmd;

static int ThreadFunctionIDSimulator = 0;

long Count = 0;


int TimerTrack;


float initAngle[3];
float initRate[3];
float initAngleGet[3];
float initRateGet[3];
	
float Angle[3];
float Rate[3];
float AnglePre[3];
float AngleGet[3];
float RateGet[3];

DataMessage Data;

int FlagTimerOver = 0;


int FlagTimer = FLAG_CLIMB;

unsigned char Temp[50];











// Global function
int CVICALLBACK TCPDataCallback (unsigned handle, int xType, int errCode, void *cbData);


int CMDCallbackQuit(void);

int CMDCallbackRotarySetMode(void);

int CMDCallbackRotaryClimb(void);	  

int CMDCallbackRotaryTrack(void);

int CMDCallbackRotarySetPThres(void);

int CMDCallbackRotarySetVThres(void);

int CVICALLBACK TrackTimer(int reserved, int timerId, int event, void *callbackData, int eventData1, int eventData2);

int Update (void);



/*
	RT main entry
 */
void CVIFUNC_C RTmain (void)
{
	CNVData SelfTestFinshData;
	unsigned int prevProcessorMask = 0;
	
	if (InitCVIRTE (0, 0, 0) == 0)
		return;    /* out of memory */
	
	if (ConnectToTCPServer (&StatusTCP, HOST_PORT, HOST_ADDRESS, TCPDataCallback, 0, 5000) < 0)
		goto Done;
	
	// Configure the system processor pool to only include the first processor on the system.
	ConfigureProcessorPool (kProcessorPool_System, 0x1, &prevProcessorMask);
	// Suspend asynchronous timer callback so it can start when command is received from host application.
	//SuspendAsyncTimerCallbacks ();
	/* Your initialization code. */
	/* It is common for Real-Time applications to use multiple threads to */
	/* separate higher priority tasks from lower priority tasks. See the  */
	/* Thread Pool functions in the Utility Library and the Asynchronous  */
	/* Timer functions in <CVI>\toolslib\toolbox\asynctmr.fp.             */
	// Create lock to synchronize writing TCP data
	CmtNewLock (0, 0, &gLock);
	CmtNewLock (0, 0, &gThdLock); 
	
	
	//CmtNewThreadPool (2, &ThreadFunctionIDSimulator); // Simulator operation thread contains a timer
	

	rfmInitDS();
	
	TimerTrack = NewAsyncTimer (INTERVAL, -1, 0, TrackTimer, 0);
	
	while (!RTIsShuttingDown () && !gDone)
	{
		/* Your code. */
		/* Sleep for some amount of time to give the desired loop rate */
		/* and to allow lower priority threads to run.                 */
		ProcessSystemEvents();
		SleepUS (100);
	} 
	
	
	FlagTimerOver = 1;
	DiscardAsyncTimer (TimerTrack);
	
	rfmCloseDS();
	 
	
	// Release thread
	/*if (ThreadFunctionIDSimulator)
		CmtDiscardThreadPool (ThreadFunctionIDSimulator);*/
	
	
	// Restore the original system processor pool configuration.
	if (prevProcessorMask)
		ConfigureProcessorPool (kProcessorPool_System, prevProcessorMask, NULL);
	
	/* Your cleanup code. */
	CmtDiscardLock (gLock);
	if (StatusTCP != TCP_INVALID_CONNECTION)
		DisconnectFromTCPServer (StatusTCP);
Done:  	
	CloseCVIRTE ();
	
}





/*
	TCP callback
 */
int CVICALLBACK TCPDataCallback (unsigned handle, int xType, int errCode, void *cbData)
{

	
    switch (xType)
    {
        case TCP_DISCONNECT:
            StatusTCP = TCP_INVALID_CONNECTION;
            break;
        case TCP_DATAREADY: // Client executable sent a command.
			// ClientTCPRead does not guarantee that all data will be transferred in
			// a single call, but this code assumes that it does for simplicity.
			ClientTCPRead (StatusTCP, &Cmd, sizeof(Cmd), 5000);
			switch(Cmd.command)
			{
				
				case QUIT_COMMAND:
					CMDCallbackQuit();  
					break;
					
				case ROTARY_CMD_CLIMB:
					CMDCallbackRotaryClimb();  
					break;

				case ROTARY_CMD_TRACK:
					CMDCallbackRotaryTrack();  
					break;
					
			}
			
            break;
			
    }
    
    return 0;
}





/*
	��������������ó�ʼ�Ƕȡ��ٶ�
 */
int CMDCallbackRotaryClimb(void)
{
	int i;
	
	double timeStart;
	double timeNow;

	
	CmtGetLock (gLock);
	
	Count ++;
	
	
	initAngle[0] = INIT_ANGLE_I;
	initAngle[1] = INIT_ANGLE_M;
	initAngle[2] = INIT_ANGLE_O;
	
	initRate[0] = INIT_RATE_I;
	initRate[1] = INIT_RATE_M;
	initRate[2] = INIT_RATE_O;

	
	
	
	
	/*if (rfmRotaryClimb(initAngle, initRate, initAngleGet, initRateGet) == 0)
	{
		printf("Rotary climb set success.\n");
		
	}
	else
		printf("Rotary climb set fail.\n");*/
	
	rfmRotaryClimb(initAngle, initRate, initAngleGet, initRateGet, STEP);
	//FlagTimer = FLAG_CLIMB;
	//SetAsyncTimerAttribute (TimerTrack, ASYNC_ATTR_ENABLED, 1);
	//printf("Timer enabled.\n");
	
	
	// Read until init angle reached
	timeStart = (double)GetTimeUS() / 1000; 
	while((abs(initAngleGet[0] - initAngle[0]) > 1.5) || (abs(initAngleGet[1] - initAngle[1]) > 1.5) || (abs(initAngleGet[2] - initAngle[2]) > 1.5))
	{
		Delay(0.01);
		rfmRotaryClimb(initAngle, initRate, initAngleGet, initRateGet, STEP);
				
		// Over time 100s
		timeNow = (double)GetTimeUS() / 1000;
		if (timeNow - timeStart > 100 * 1000)
		{
			CmtReleaseLock (gLock);
			printf("Error: Rotary climb set fail!\n");
			return 1;
		}
		
		Data.timeMS = timeNow;
		Data.angle[0] = initAngle[0];
		Data.angle[1] = initAngle[1];
		Data.angle[2] = initAngle[2];
		Data.rate[0] = initRate[0];
		Data.rate[1] = initRate[1];
		Data.rate[2] = initRate[2];
		Data.angleGet[0] = initAngleGet[0];
		Data.angleGet[1] = initAngleGet[1];
		Data.angleGet[2] = initAngleGet[2];
		Data.rateGet[0] = initRateGet[0];
		Data.rateGet[1] = initRateGet[1];
		Data.rateGet[2] = initRateGet[2];
		
		//for (i = 0; i < 33; i ++)
		//	Data.temp[i] = Temp[i];
	
		Update();
	} 
	
	printf("initAngleGet[0] = %f\n", *initAngleGet);
	printf("initAngleGet[1] = %f\n", *(initAngleGet + 1));
	printf("initAngleGet[2] = %f\n", *(initAngleGet + 2));
	
	printf("initRateGet[0] = %f\n", *(initRateGet + 0));
	printf("initRateGet[1] = %f\n", *(initRateGet + 1));
	printf("initRateGet[2] = %f\n", *(initRateGet + 2));
	
	
	CmtReleaseLock (gLock);
	
	return 0;

}




/*
	���������������ʵʱ�ĽǶȡ��ٶ�
 */
int CMDCallbackRotaryTrack(void)
{

	CmtGetLock (gLock);
	
	if (Cmd.statusTrack == 1)
	{
		Angle[0] = INIT_ANGLE_I;
		Angle[1] = INIT_ANGLE_M;
		Angle[2] = INIT_ANGLE_O;
		SetAsyncTimerAttribute (TimerTrack, ASYNC_ATTR_ENABLED, 1);
		//FlagTimer = FLAG_TRACK;
		printf("Timer enabled.\n");
	}
	else
	{
		SetAsyncTimerAttribute (TimerTrack, ASYNC_ATTR_ENABLED, 0);
		//FlagTimer = FLAG_CLIMB;
		printf("Timer disabled.\n");
		
		Rate[0] = 0;
		Rate[1] = 0;
		Rate[2] = 0;
		rfmRotaryTrack(Angle, Rate, AngleGet, RateGet);
		rfmRotaryClimb(initAngle, initRate, initAngleGet, initRateGet, STEP);
		
		Count = 0;
	}


	
	CmtReleaseLock (gLock);
	
	return 0;

}






/*
	Quit RT programme TCP callback
 */
int CMDCallbackQuit(void)
{
	
	printf("Quit RT programme success.\n");
	
	gDone = 1; // Signal the main thread to exit the while loop in RTMain
	
	return 0;
}



/*
	���͸�������Ķ�ʱ��
 */
int CVICALLBACK TrackTimer(int reserved, int timerId, int event, void *callbackData, int eventData1, int eventData2)
{
	int i;
	
	if (FlagTimerOver == 1)
		return 0;
	
	
	/*if (FlagTimer == FLAG_CLIMB)
	{
		initAngle[0] = INIT_ANGLE_I;
	initAngle[1] = INIT_ANGLE_M;
	initAngle[2] = INIT_ANGLE_O;
	
	initRate[0] = INIT_RATE_I;
	initRate[1] = INIT_RATE_M;
	initRate[2] = INIT_RATE_O;
	
	rfmRotaryClimb(initAngle, initRate, initAngleGet, initRateGet);
		
	}
	else if (FlagTimer == FLAG_TRACK)
	{*/
	
		AnglePre[0] = Angle[0];
		AnglePre[1] = Angle[1];
		AnglePre[2] = Angle[2];
	
		Count ++;
		Count %= POINT_NUMBER;
	
		Angle[0] = INIT_ANGLE_I * cos((double)Count / POINT_NUMBER * 3.14 * 2);
		Angle[1] = INIT_ANGLE_M * cos((double)Count / POINT_NUMBER * 3.14 * 2);
		Angle[2] = INIT_ANGLE_O * cos((double)Count / POINT_NUMBER * 3.14 * 2);
	
		Rate[0] = (Angle[0] - AnglePre[0]) / INTERVAL;
		Rate[1] = (Angle[1] - AnglePre[1]) / INTERVAL;
		Rate[2] = (Angle[2] - AnglePre[2]) / INTERVAL;
	
	
		rfmRotaryTrack(Angle, Rate, AngleGet, RateGet);
		//rfmRotaryReadPV(AngleGet, RateGet);
	
		Data.timeMS = (double)GetTimeUS() / 1000;
		Data.angle[0] = Angle[0];
		Data.angle[1] = Angle[1];
		Data.angle[2] = Angle[2];
		Data.rate[0] = Rate[0];
		Data.rate[1] = Rate[1];
		Data.rate[2] = Rate[2];
		Data.angleGet[0] = AngleGet[0];
		Data.angleGet[1] = AngleGet[1];
		Data.angleGet[2] = AngleGet[2];
		Data.rateGet[0] = RateGet[0];
		Data.rateGet[1] = RateGet[1];
		Data.rateGet[2] = RateGet[2];
	
		
		
		//for (i = 0; i < 33; i ++)
		//	Data.temp[i] = Temp[i];
		
		
		Update();
	//}

	
	return 0;
}


/*
	RT �� Host ��������
 */
int Update (void)
{
	CmtGetLock (gLock);
	// Create message with program state and send to host executable.
	if (StatusTCP != TCP_INVALID_CONNECTION)
	{
		// ClientTCPWrite does not guarantee that all Data will be transferred in
		// a single call, but this code assumes that it does for simplicity.
		ClientTCPWrite (StatusTCP, &Data, sizeof(Data), 5000);
	}
	CmtReleaseLock (gLock);
	
	return 0;
}












