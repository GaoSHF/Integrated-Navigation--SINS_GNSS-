/**************************************************************************/
/* LabWindows/CVI User Interface Resource (UIR) Include File              */
/* Copyright (c) National Instruments 2014. All Rights Reserved.          */
/*                                                                        */
/* WARNING: Do not add to, delete from, or otherwise modify the contents  */
/*          of this include file.                                         */
/**************************************************************************/

#include <userint.h>

#ifdef __cplusplus
    extern "C" {
#endif

     /* Panels and Controls: */

#define  PANEL                            1
#define  PANEL_BUTTON_GET_PV              2
#define  PANEL_BUTTON_CLIMB               3       /* callback function: buttonClimb */
#define  PANEL_BUTTON_QUIT_HOST           4       /* callback function: buttonQuitHost */
#define  PANEL_BUTTON_QUIT_RT             5       /* callback function: buttonQuitRT */
#define  PANEL_STRING_TCP_STATUS          6
#define  PANEL_NUMERIC_O_P_SET            7
#define  PANEL_NUMERIC_M_P_SET            8
#define  PANEL_NUMERIC_I_PV_SET           9
#define  PANEL_NUMERIC_O_P                10
#define  PANEL_NUMERIC_M_P                11
#define  PANEL_NUMERIC_I_PV               12
#define  PANEL_BUTTON_TRACK               13      /* callback function: buttonTrack */


     /* Menu Bars, Menus, and Menu Items: */

          /* (no menu bars in the resource file) */


     /* Callback Prototypes: */

int  CVICALLBACK buttonClimb(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK buttonQuitHost(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK buttonQuitRT(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK buttonTrack(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);


#ifdef __cplusplus
    }
#endif
