#include <formatio.h>
#include <ansi_c.h> 
#include <cvinetv.h>
#include <cvirte.h> 
#include <userint.h>
#include <tcpsupp.h> 
#include <visa.h>
#include <toolbox.h>


#include "common.h"
#include "host_main.h"
#include "host_sub_no_tcp.h"





#define	HOST_FILE_PATH_ROTARY_TRACK		"rotary_track.txt"

// Global variables

CommandMessage Cmd;

FILE *FileHandleRotaryTrack = NULL;

static unsigned int	StatusTCP = TCP_INVALID_CONNECTION;

DataMessage Data;


// Global function
int CVICALLBACK TCPDataCallback (unsigned handle, int xType, int errCode, void *callbackData);

int InitPanel(void);

int CreatFolder(void);




/*
	Host main entry
 */
int main (int argc, char *argv[])
{
     
	int error = 0;
	
    /* initialize and load resources */
    nullChk (InitCVIRTE (0, argv, 0));
    errChk (HandlePanel = LoadPanel (0, "host_main.uir", PANEL));
	
	// Create a TCP server to communicate with RT target.
    RegisterTCPServer (HOST_PORT, TCPDataCallback, 0);
	
	
	CreatFolder();
	FileHandleRotaryTrack = fopen (HOST_FILE_PATH_ROTARY_TRACK, "wb");
	
	// Init panel
	InitPanel();
	SetCtrlAttribute (HandlePanel, PANEL_BUTTON_TRACK, ATTR_DIMMED, 1);
	
    /* display the panel and run the user interface */
    errChk (DisplayPanel (HandlePanel));
    errChk (RunUserInterface ());
	// Cleanup
	UnregisterTCPServer(HOST_PORT);
	
	fclose (FileHandleRotaryTrack);
	
Error:
    /* clean up */
    DiscardPanel (HandlePanel);
    return 0;
}





/*
	Initiate panel
 */
int InitPanel(void)
{
	
	SetCtrlVal(HandlePanel, PANEL_STRING_TCP_STATUS, "Waiting for connection.");
	
	
	return 0;
}




/*
	TCP/IP callback
 */
int CVICALLBACK TCPDataCallback (unsigned handle, int xType, int errCode, 
	void *callbackData)
{
	int i;

	
	switch (xType)
    {
        case TCP_CONNECT:
            // Accept only one client connection
            if (StatusTCP != TCP_INVALID_CONNECTION)
                DisconnectTCPClient (handle);
            else
                StatusTCP = handle;
			SetCtrlVal (HandlePanel, PANEL_STRING_TCP_STATUS, "Connected.");
            break;
			
        case TCP_DISCONNECT:
            StatusTCP = TCP_INVALID_CONNECTION;
			SetCtrlVal (HandlePanel, PANEL_STRING_TCP_STATUS, "Waiting for connection.");
            break;
			
        case TCP_DATAREADY:
			ServerTCPRead (StatusTCP, &Data, sizeof(Data), 5000);
			fprintf(FileHandleRotaryTrack, "%f\t", Data.timeMS);
			fprintf(FileHandleRotaryTrack, "%f\t", Data.angle[0]);
			fprintf(FileHandleRotaryTrack, "%f\t", Data.angle[1]);
			fprintf(FileHandleRotaryTrack, "%f\t", Data.angle[2]);
			fprintf(FileHandleRotaryTrack, "%f\t", Data.rate[0]);
			fprintf(FileHandleRotaryTrack, "%f\t", Data.rate[1]);
			fprintf(FileHandleRotaryTrack, "%f\t", Data.rate[2]);
			fprintf(FileHandleRotaryTrack, "%f\t", Data.angleGet[0]);
			fprintf(FileHandleRotaryTrack, "%f\t", Data.angleGet[1]);
			fprintf(FileHandleRotaryTrack, "%f\t", Data.angleGet[2]);
			fprintf(FileHandleRotaryTrack, "%f\t", Data.rateGet[0]);
			fprintf(FileHandleRotaryTrack, "%f\t", Data.rateGet[1]);
			fprintf(FileHandleRotaryTrack, "%f\n", Data.rateGet[2]);
			
			/*for (i = 0; i < 33; i ++)
				fprintf(FileHandleRotaryTrack, "%d\t", (int)Data.temp[i]); 
			fprintf(FileHandleRotaryTrack, "\n");*/
			
            break;
    }
    
    return 0;
}










/*
	Quit RT button callback
 */
int CVICALLBACK buttonQuitRT (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:
			if (StatusTCP != TCP_INVALID_CONNECTION)
			{
				Cmd.command = QUIT_COMMAND;
				ServerTCPWrite (StatusTCP, &Cmd, sizeof(Cmd), 5000); // Stop simulation
			}
			else;
			
			break;
	}
	return 0;
}



/*
	Quit host button callback
 */
int CVICALLBACK buttonQuitHost (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:
			
			if (StatusTCP != TCP_INVALID_CONNECTION)
			{
				Cmd.command = QUIT_COMMAND; 
				ServerTCPWrite (StatusTCP, &Cmd, sizeof(Cmd), 5000); // Stop simulation
			}
			else;
			
			QuitUserInterface(0);
			
			break;
	}
	return 0;
}












/*
   ��������������ó�ʼ�Ƕȡ��ٶ�
 */
int CVICALLBACK buttonClimb (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:
			if (StatusTCP != TCP_INVALID_CONNECTION)
			{
				GetCtrlVal (HandlePanel, PANEL_NUMERIC_I_PV_SET, &Cmd.angleInner);
				GetCtrlVal (HandlePanel, PANEL_NUMERIC_M_P_SET, &Cmd.angleMiddle);
				GetCtrlVal (HandlePanel, PANEL_NUMERIC_O_P_SET, &Cmd.angleOuter);

				
				Cmd.command = ROTARY_CMD_CLIMB; 
				
				ServerTCPWrite (StatusTCP, &Cmd, sizeof(Cmd), 5000);
				
				SetCtrlAttribute (HandlePanel, PANEL_BUTTON_TRACK, ATTR_DIMMED, 0);
			}
			break;
	}
	return 0;
}

/*
   ���������������ʵʱ�ĽǶȡ��ٶ�
 */
int CVICALLBACK buttonTrack (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:
			if (StatusTCP != TCP_INVALID_CONNECTION)
			{
				GetCtrlVal (HandlePanel, PANEL_NUMERIC_I_PV_SET, &Cmd.angleInner);
				GetCtrlVal (HandlePanel, PANEL_NUMERIC_M_P_SET, &Cmd.angleMiddle);
				GetCtrlVal (HandlePanel, PANEL_NUMERIC_O_P_SET, &Cmd.angleOuter);
				
				Cmd.command = ROTARY_CMD_TRACK;
				
				GetCtrlVal (HandlePanel, PANEL_BUTTON_TRACK, &Cmd.statusTrack);

				

				if (Cmd.statusTrack == 0)
				{
					SetCtrlAttribute (HandlePanel, PANEL_BUTTON_TRACK, ATTR_DIMMED, 1);
					SetCtrlAttribute (HandlePanel, PANEL_BUTTON_QUIT_RT, ATTR_DIMMED, 0);
					SetCtrlAttribute (HandlePanel, PANEL_BUTTON_QUIT_RT, ATTR_DIMMED, 0);
				}
				else
				{
					SetCtrlAttribute (HandlePanel, PANEL_BUTTON_QUIT_RT, ATTR_DIMMED, 1);
					SetCtrlAttribute (HandlePanel, PANEL_BUTTON_QUIT_RT, ATTR_DIMMED, 1);	
				}
				
				ServerTCPWrite (StatusTCP, &Cmd, sizeof(Cmd), 5000);
			}
			break;
	}
	return 0;
}


/*
	Creat file folder
 */
int CreatFolder(void)
{
	int month;
	int day;  
	int year;  
	int hours;
	int minutes;  
	int seconds;  
	char time[100];
	char dir[200];
	char g_dir[200];
	
	int f_exist;
	
	GetSystemDate (&month, &day, &year);
	GetSystemTime (&hours, &minutes, &seconds);
	sprintf(time,"%04d%02d%02d%02d%02d", year, month, day,hours,minutes);
	Fmt (dir, "%s<%100c", time); 
	f_exist = FileExists("C:\\test",0);
	
	if(f_exist == 0) 
	{
		MakeDir("C:\\test"); 
		SetDir("C:\\test"); 
		MakeDir(dir);
		SetDir(dir);     
	}
	else		   
	{
		SetDir("C:\\test"); 
		Fmt (g_dir, "C:\\test\\");  
		strcat(g_dir,time);
		f_exist = FileExists(g_dir,0); 
		if(f_exist == 0)
		{
			MakeDir(dir);
			SetDir(dir);		
		}
	}
	
	return 0;
}

