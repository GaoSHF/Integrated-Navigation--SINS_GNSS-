//==============================================================================
//
// Title:       sensor_simu.c
// Purpose:     A short description of the implementation.
//
// Created on:  2013/12/20 at 13:49:09 by ZhaoHengyang.
// Copyright:   Beihang University. All Rights Reserved.
//
//==============================================================================

//==============================================================================
// Include files

#include <ansi_c.h>
#include "sensor_simu.h"

//==============================================================================
// Constants


//==============================================================================
// Types

//==============================================================================
// Static global variables

//==============================================================================
// Static functions

//==============================================================================
// Global variables

//==============================================================================
// Global functions

/// HIFN  What does your function do?
/// HIPAR x/What inputs does your function expect?
/// HIRET What does your function return?


/*
	������뾶
 */
double Rm (double la, double h)
{
	return (Re / (1 + 2 * e - 3 * e * sin(la * la)) + h);
}

/*
	î����뾶
 */
double Rn (double la, double h)
{
	return (Re / (1 - e * sin(la * la)) + h);
}



/*
	Velocity from ENU to WGS84
	
	Cet = [cos(pi / 2 + lon),	sin(pi / 2 + lon),	0;
		   -cos(pi / 2- la) * sin(pi / 2 + lon),	cos(pi / 2- la) * cos(pi / 2 + lon),	sin(pi / 2- la);
		   sin(pi / 2- la) * sin(pi / 2 + lon),	sin(pi / 2- la) * cos(pi / 2 + lon),	cos(pi / 2- la)]
	
 */
int sensorVenu2xyz (double *vx, double *vy, double *vz, double ve, double vn, double vu, double la, double lon)
{

	*vx = cos(pi / 2 + lon) * ve - cos(pi / 2 - la) * sin(pi / 2 + lon) * vn + sin(pi / 2 - la) * sin(pi / 2 + lon) *vu;
	*vy = sin(pi / 2 + lon) * ve + cos(pi / 2 - la) * cos(pi / 2 + lon) * vn - sin(pi / 2 - la) * cos(pi / 2 + lon) *vu;
	*vz = sin(pi / 2 - la) * vn + cos(pi / 2 - la) *vu;
	
	return 0;
}


/*
	Acceleration from ENU to WGS84
	
 */
int sensorAenu2xyz (double *ax, double *ay, double *az, double ae, double an, double au, double la, double lon)
{

	*ax = cos(pi / 2 + lon) * ae - cos(pi / 2 - la) * sin(pi / 2 + lon) * an + sin(pi / 2 - la) * sin(pi / 2 + lon) *au;
	*ay = sin(pi / 2 + lon) * ae + cos(pi / 2 - la) * cos(pi / 2 + lon) * an - sin(pi / 2 - la) * cos(pi / 2 + lon) *au;
	*az = sin(pi / 2 - la) * an + cos(pi / 2 - la) *au;
	
	return 0;
}



/*
	Position from geographic to WGS84
	
 */
int sensorPgeo2xyz (double *x, double *y, double *z, double la, double lon, double h)
{
	double ex2, N;
	
	ex2 = (2 - e) * e / ((1 - e) * (1 - e));
	
	N = Re * sqrt(1 + ex2) / sqrt(1 + ex2 * cos(la) * cos(la));
	
	*x = (N + h) * cos(la) * cos(lon);
	*y = (N + h) * cos(la) * sin(lon);
	*z = ((1 - e) * (1 - e) * N + h) * sin(la);
	
	return 0;
}




/*
	Geographic position refresh
	
 */
int sensorPgeoRefresh (double *laNew, double *lonNew, double *hNew, double ve, double vn, double vu, double la, double lon, double h, double T)
{
	
	double laTemp, lonTemp, hTemp;
	
	laTemp = vn / Rm(la, h) * T + la;
    lonTemp = ve / (Rn(la, h) * cos(la)) * T + lon;
    hTemp = vu * T + h;
	
	*laNew = laTemp;
    *lonNew = lonTemp;
    *hNew = hTemp;

	return 0;
}


/*
	Velocity ENU refresh
	
 */
int sensorVenuRefresh (double *ve, double *vn, double *vu, double ae, double an, double au, double T)
{
	
	*ve += ae * T;
	*vn += an * T;
	*vu += au * T;
	
	return 0;
}




/*
	Accelerometer output refresh
	
 */
int sensorFbRefresh (double *ft, double ae, double an, double au, double la, double h)
{
	
	double g;
	
	g = g0 * (1 + gk1 * sin(la) * sin(la)) * (1 - 2 * h / Re) / sqrt(1 - gk2 * sin(la) * sin(la));
	
	*ft = ae;
	*(ft + 1) = an;
	*(ft + 2) = au + g;
	
	return 0;
}





/*
	Gyroscope output refresh
	
 */
int sensorWibbRefresh (double *witt, double ve, double vn, double la, double h)
{
	
	
	*witt = -vn / Rm(la, h);
	*(witt + 1) = wie * cos(la) + ve / Rn(la, h);
	*(witt + 2) = wie * sin(la) + ve / Rn(la, h) * tan(la);
	
	return 0;
}










