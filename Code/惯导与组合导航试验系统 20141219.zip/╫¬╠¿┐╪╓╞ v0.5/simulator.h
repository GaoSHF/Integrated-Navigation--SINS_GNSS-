//==============================================================================
//
// Title:       simulator.h
// Purpose:     A short description of the interface.
//
// Created on:  2013/10/18 at 21:57:10 by ZhaoHengyang.
// Copyright:   Beihang University. All Rights Reserved.
//
//==============================================================================

#ifndef __simulator_H__
#define __simulator_H__



#define TRACK_FILE_PATH  "c:\\track.txt"

#define	TIMER_INTERVAL	0.01

#define	VELOCITY_X	-10
#define	VELOCITY_Y	0
#define	VELOCITY_Z	0

#define	AGC_DEFAULT_VALUE	25

struct TRfmCardTransRec  //?GNSS????????????
{
     long long Cmdkey;

     long long iTrackBDT;
     long long iTrackID;
     double   dbeSimTime;

     double   dUserPosX;
     double   dUserPosY;
     double   dUserPosZ;

     double   dUserVelX;
     double   dUserVelY;
     double   dUserVelZ;

     double   dUserAccX;
     double   dUserAccY;
     double   dUserAccZ;

     double   dUserJekX;
     double   dUserJekY;
     double   dUserJekZ;

     long long iPoseBDT;
     long long iPoseID;
     double   dbeSimTime2;

     //???????XYZ:????????,???????O-XYZ,??????????????
     double   dUserRoll;  //???(mrad),?X????????
     double   dUserAzimu; //???(mrad),?Y????????
     double   dUserPitch; //???(mrad),?Z????????
     //???????????????,??????????????,????????X/Y/Z??????
     double   dUserRollVelX; //???(mrad/s)
     double   dUserRollVelY; //???(mrad/s)
     double   dUserRollVelZ; //???(mrad/s)

     double   dUserRollAccX; //???(mrad/s/s)
     double   dUserRollAccY; //???(mrad/s/s)
     double   dUserRollAccZ; //???(mrad/s/s)

     double   dUserRollJekX; //???(mrad/s/s/s)
     double   dUserRollJekY; //???(mrad/s/s/s)
     double   dUserRollJekZ; //???(mrad/s/s/s)
};




extern struct TRfmCardTransRec lRfmTransRec;

extern unsigned int glRfmComPtkID;

extern int CountTrack;


extern double x, y, z;
extern double vx, vy, vz;
extern double ax, ay, az;

extern double la, lon, h;  // rad, rad, m
extern double ve, vn, vu;
extern double ae, an, au;




int simulatorOpenDev(void);
int simulatorCloseDev(void);

int simulatorInit(void);

int simulatorStop(void);

int simulatorSetAGC(int valueAGC);

int ioBoardOpen(void); 

int ioBoardClose(void); 

int ioBoardChangeRelay(void);

int SendTrkData(char * pData, int iDataCount); 





#endif  /* ndef __simulator_H__ */
