#ifndef _COMMON_H_
#define _COMMON_H_


#include "GERFM.h"



#define TCP_INVALID_CONNECTION 	((unsigned int)-1) 

#define HOST_ADDRESS 			"169.254.121.1"
#define HOST_PORT 				10001


#define START_COMMAND			1
#define STOP_COMMAND			2
#define QUIT_COMMAND			3

#define SELFTEST_COMMAND        4

#define GPSRECEIVE_COMMAND      5  
#define INSRECEIVE_COMMAND      6

#define GPSSIM_COMMAND          7
#define GPSSIM_AGC_COMMAND      8
#define	GPSSIM_IO_CHANGE_COMMAND	9

#define ROTARY_CMD_SET_MODE      10
#define ROTARY_CMD_GET_MODE      11
#define ROTARY_CMD_CLIMB      		12
#define ROTARY_CMD_TRACK      		13
#define ROTARY_CMD_SET_PTHRES		14
#define ROTARY_CMD_SET_VTHRES		15

#define	STATUS_ON	1
#define	STATUS_OFF	0


// Command message structure
typedef struct
{
	int countertime;
	
	int statusYCReceive;
	
	int statusINSReceive;
	
	int statusGPSReceive;
	
	int statusSimulator;
	
	int statusTrack;
	
	int valueAGC;
	
	int	command;
	
	
	unsigned char mode;
	unsigned char dir;
	
	float angleInner;
	float angleMiddle;
	float angleOuter;
	
	float rateInner;
	float rateMiddle;
	float rateOuter;
	
	float pThresID;
	float pThresIU;
	float pThresMD;
	float pThresMU;
	float pThresOD;
	float pThresOU;
	
	float vThresID;
	float vThresIU;
	float vThresMD;
	float vThresMU;
	float vThresOD;
	float vThresOU;
	
} CommandMessage;




typedef struct
{
	double timeMS;
	float angle[3];
	float rate[3];
	float angleGet[3];
	float rateGet[3];
	
	unsigned char temp[50];
} DataMessage;


static int HandlePanel;
static int HandleSubPanelTCP;






#endif

