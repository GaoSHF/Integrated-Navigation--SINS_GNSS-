#include "DATAFILE_TRAN.h"
#include "ALGORITHM_PANEL.h"
#include "MAIN_PANEL.h"

//==============================================================================
//
// Title:       host
// Purpose:     A short description of the application.
//
// Created on:  2013-9-13 at 19:27:25 by Yushuang Liu.
// Copyright:   Beihang University. All Rights Reserved.
//
//==============================================================================

#include <cvintwrk.h>
#include <asynctmr.h>
#include <formatio.h>
#include <ansi_c.h> 
#include <cvinetv.h>
#include <cvirte.h> 
#include <userint.h>
#include <tcpsupp.h> 
#include <visa.h>  
#include <toolbox.h>
#include <analysis.h>
#include <math.h>
#include <stdio.h>
#include <cvinetv.h>

//���ͷ�ļ�
#include "SNavigation.h"
#include "CRAFT_PANEL.h"  
#include "MISSILE_PANEL.h" 
#include "WAIT_PANEL.h"
#include "AlgoPANEL.h"

#include "Common.h"   
#include "GlobalFunction.h"    
#include "ConstVariable.h"
#include "PanelInputVariable.h"
#include "ComputeVariable.h"
#include "InitialVariable.h"

double PanVel=0.0, PanAcc=0.0; 

//�ṹ������  
CommandMessage cmd;               //��λ������ָ��
DataMessage data;                 //��λ����������

IniParDataMessage CraftPara;      //��λ������λ�����͵��ػ���ʼ����
CraftTraceDataMessage CraftTrace; //��λ������λ�����͵��ػ��켣����
MisIniParMessage MisPara;		  //��λ������λ�����͵ĵ�����ʼ����
MisTraceMessage MisTrace;		  //��λ������λ�����͵ĵ����켣����
TarMessage TarData;				  //��λ������λ�����͵�Ŀ�����ʼ����

//��λ�����ر���
int TraceModeSelect;

int MainPanelIni_exist;			//��ʼ���ļ��Ƿ���ڱ�־ 
int CraftPanelIni_exist;  		
int MissilePanelIni_exist; 
			
char MisChinese[8];             //�켣����������ĺ��� 
int MissileFreeFlightFlag=0;	//�������ɷ��б�־
int MissileGuiFlightFlag=0;		//�����Ƶ����б�־
int MissileDataReadFlag=0;		//��ȡ�̿ص����ݱ�־
int DisTableCounter = 1;  
int CraftFlightZhuanWanFlag=0;


/*****��λ�����غ�������*****/ 
void InitialMainPanel(void); 

void InitialCraftPanelVariable(void); 
void StructureDataInitial_Craft(void);
void GetCraftParameterFromPanel(void);   
void WriteCraftParameterToFile(FILE *FileHandle, char *FilePath);
void WriteCraftTraceToFile(FILE *FileHandle, char *FilePath);
void ReadCraftParameterToPanel(FILE *FileHandle, char *FilePath) ;
void ReadCraftTraceToPanel(FILE *FileHandle, char *FilePath);
void SetCraftParameterToPanel(void);
void SetCraftTraceToPanel(void);

void InitialMissileVariable(void);
void StructureDataInitial_Missile(void); 
void SetVariableToPanel(void);
void GuiModeDis(void);		 
void FreeModeDis(void);
void ReadModeDis(void);
void CreateFolder(void);
void MisTableWrite(int TempMisTraceNum); 
void CalcAtt_Error(void);
//���ݷ�����λ��������
int main (int argc, char *argv[])
{
    int error = 0;
	gDataConnection = TCP_INVALID_CONNECTION;

    nullChk (InitCVIRTE (0, argv, 0));
	
    errChk (MainPanelHandle = LoadPanel (0, "MAIN_PANEL.uir", MainPanel));
	if(ConnectToTCPServer (&gDataConnection, HOST_PORT, SERVER_ADDRESS, TCPDataCallback, 0, 1000) < 0);
	{
		SetCtrlVal (MainPanelHandle, MainPanel_STRINGNetConnentState, "�ȴ���������ʵʱ����");  
	}
	
	//���ļ��������� ���б�����ʼ��
	MainPanelIni_exist = FileExists(MainPanelIni_FILE_PATH,0);
	if(MainPanelIni_exist==1)
	{
		InitialMainPanel(); 
	}
	
  	CraftPanelIni_exist = FileExists(CraftPanelIni_FILE_PATH,0);
		
	if(CraftPanelIni_exist==1)
	{
	    InitialCraftPanelVariable();
	}
	
	MissilePanelIni_exist = FileExists(MissilePanelIni_FILE_PATH,0);
	if(MissilePanelIni_exist==1)
	{
		InitialMissileVariable();  
	}
	
//	InsertTextBoxLine (MainPanelHandle, MainPanel_ProStatusTextBox, -1, "ϵͳ�Լ��������ɽ���ʵ���ʼ����");  
	InsertTableRows (MainPanelHandle, MainPanel_ProStatusTextBox, -1, 1, VAL_CELL_STRING);
	SetTableCellVal (MainPanelHandle, MainPanel_ProStatusTextBox, MakePoint (1, DisTableCounter), 
					 " ϵͳ�Լ��������ɽ���ʵ���ʼ����");		 
	SetCtrlAttribute (MainPanelHandle, MainPanel_ProStatusTextBox, ATTR_VSCROLL_OFFSET, 32767);
	
	SetPanelAttribute (MainPanelHandle, ATTR_WINDOW_ZOOM, VAL_MAXIMIZE);  
    errChk (DisplayPanel (MainPanelHandle));
    errChk (RunUserInterface ());  
Error:
    //�ر������
    DiscardPanel (MainPanelHandle);
    return 0;
}

//TCPͨѶ�ص�����
int CVICALLBACK TCPDataCallback (unsigned handle, int xType, int errCode, void *callbackData)
{
	switch (xType)  
    {
		case TCP_DISCONNECT:
            gDataConnection = TCP_INVALID_CONNECTION;
			SetCtrlVal (MainPanelHandle, MainPanel_STRINGNetConnentState, "�ȴ���������ʵʱ����"); 
            break;
		//��λ��׼�������ݺ�
        case TCP_DATAREADY:   
			
			ClientTCPRead (gDataConnection, &data, sizeof(data), TCPDataWaitTime);
			
	    	switch(data.status)
			{
				case TCP_CONNECTED:
					SetCtrlVal (MainPanelHandle, MainPanel_STRINGNetConnentState, "����������ʵʱ����");
					SetCtrlAttribute (MainPanelHandle, MainPanel_ConnectionCreat, ATTR_DIMMED, 1); 
					SetCtrlAttribute (MainPanelHandle, MainPanel_InitialButton, ATTR_DIMMED, 0);
					SetCtrlAttribute (MainPanelHandle, MainPanel_StartButton, ATTR_DIMMED, 0);
					SetCtrlAttribute (MainPanelHandle, MainPanel_StopButton, ATTR_DIMMED, 0);
					SetCtrlAttribute (MainPanelHandle, MainPanel_UpdateButton, ATTR_DIMMED, 0); 
					SetCtrlAttribute (MainPanelHandle, MainPanel_QuitButton, ATTR_DIMMED, 0); 
					SetCtrlAttribute (MainPanelHandle, MainPanel_CraftMode, ATTR_DIMMED, 0); 
					SetCtrlAttribute (MainPanelHandle, MainPanel_MisGuiMode, ATTR_DIMMED, 0); 
					SetCtrlAttribute (MainPanelHandle, MainPanel_MisFreeMode, ATTR_DIMMED, 0); 
					SetCtrlAttribute (MainPanelHandle, MainPanel_MisProMode, ATTR_DIMMED, 0); 
					SetCtrlAttribute (MainPanelHandle, MainPanel_DataSaveFlag, ATTR_DIMMED, 0); 
					break;
				case GNSS_ROTARY_INIT_START:
					InsertTableRows (MainPanelHandle, MainPanel_ProStatusTextBox, -1, 1, VAL_CELL_STRING);
					DisTableCounter++; 
					SetTableCellVal (MainPanelHandle, MainPanel_ProStatusTextBox, MakePoint (1, DisTableCounter), 
									" ���ڽ�������ģ������ת̨��ʼ����");		 
					SetCtrlAttribute (MainPanelHandle, MainPanel_ProStatusTextBox, ATTR_VSCROLL_OFFSET, 32767);
					
					SetCtrlAttribute (MainPanelHandle, MainPanel_InitialButton, ATTR_DIMMED, 1);
					SetCtrlAttribute (MainPanelHandle, MainPanel_StartButton, ATTR_DIMMED, 1);
					SetCtrlAttribute (MainPanelHandle, MainPanel_StopButton, ATTR_DIMMED, 1);
					SetCtrlAttribute (MainPanelHandle, MainPanel_UpdateButton, ATTR_DIMMED, 1); 					
					SetCtrlAttribute (MainPanelHandle, MainPanel_QuitButton, ATTR_DIMMED, 1); 
					SetCtrlAttribute (MainPanelHandle, MainPanel_CraftMode, ATTR_DIMMED, 1); 
					SetCtrlAttribute (MainPanelHandle, MainPanel_MisGuiMode, ATTR_DIMMED, 1); 
					SetCtrlAttribute (MainPanelHandle, MainPanel_MisFreeMode, ATTR_DIMMED, 1); 
					SetCtrlAttribute (MainPanelHandle, MainPanel_MisProMode, ATTR_DIMMED, 1); 
					SetCtrlAttribute (MainPanelHandle, MainPanel_ROTARYSHAKEBUTTON, ATTR_DIMMED, 1);  
					SetCtrlAttribute (MainPanelHandle, MainPanel_CURRENTOFFSETBUTTON, ATTR_DIMMED, 1);   
					SetCtrlAttribute (MainPanelHandle, MainPanel_RotaryTabIn, ATTR_DIMMED, 1);  
					SetCtrlAttribute (MainPanelHandle, MainPanel_RotaryTabOut, ATTR_DIMMED, 1);  
					SetCtrlAttribute (MainPanelHandle, MainPanel_RotaryTabMid, ATTR_DIMMED, 1); 
					SetCtrlAttribute (MainPanelHandle, MainPanel_DataSaveFlag, ATTR_DIMMED, 1); 
					
					break;
				case ROTARY_DATA_TIMEOUT:
					InsertTableRows (MainPanelHandle, MainPanel_ProStatusTextBox, -1, 1, VAL_CELL_STRING);
					DisTableCounter++; 
					SetTableCellVal (MainPanelHandle, MainPanel_ProStatusTextBox, MakePoint (1, DisTableCounter), 
									" ת̨��ʼ���ض����ݳ�ʱ��");		 
					SetCtrlAttribute (MainPanelHandle, MainPanel_ProStatusTextBox, ATTR_VSCROLL_OFFSET, 32767);
					break;
				case ROTARY_INIT_FAIL:
				//	InsertTextBoxLine (MainPanelHandle, MainPanel_ProStatusTextBox, -1, "ת̨��ʼ��ʧ�ܡ�"); 
					InsertTableRows (MainPanelHandle, MainPanel_ProStatusTextBox, -1, 1, VAL_CELL_STRING);
					DisTableCounter++; 
					SetTableCellVal (MainPanelHandle, MainPanel_ProStatusTextBox, MakePoint (1, DisTableCounter), 
									" ת̨��ʼ��ʧ�ܡ�");		 
					SetCtrlAttribute (MainPanelHandle, MainPanel_ProStatusTextBox, ATTR_VSCROLL_OFFSET, 32767);

					break;
				case ROTARY_INIT_DONE:
				//	InsertTextBoxLine (MainPanelHandle, MainPanel_ProStatusTextBox, -1, "ת̨��ʼ���ɹ���"); 
					InsertTableRows (MainPanelHandle, MainPanel_ProStatusTextBox, -1, 1, VAL_CELL_STRING);
					DisTableCounter++; 
					SetTableCellVal (MainPanelHandle, MainPanel_ProStatusTextBox, MakePoint (1, DisTableCounter), 
									" ת̨��ʼ���ɹ���");		 
					SetCtrlAttribute (MainPanelHandle, MainPanel_ProStatusTextBox, ATTR_VSCROLL_OFFSET, 32767);					
					break;
				case GNSS_INIT_DONE:
				//	InsertTextBoxLine (MainPanelHandle, MainPanel_ProStatusTextBox, -1, "ת̨��ʼ���ɹ���"); 
					InsertTableRows (MainPanelHandle, MainPanel_ProStatusTextBox, -1, 1, VAL_CELL_STRING);
					DisTableCounter++; 
					SetTableCellVal (MainPanelHandle, MainPanel_ProStatusTextBox, MakePoint (1, DisTableCounter), 
									" ����ģ������ʼ����ɡ�");		 
					SetCtrlAttribute (MainPanelHandle, MainPanel_ProStatusTextBox, ATTR_VSCROLL_OFFSET, 32767);						
					
					
					SetCtrlAttribute (MainPanelHandle, MainPanel_InitialButton, ATTR_DIMMED, 0);
					SetCtrlAttribute (MainPanelHandle, MainPanel_StartButton, ATTR_DIMMED, 0);
					SetCtrlAttribute (MainPanelHandle, MainPanel_StopButton, ATTR_DIMMED, 1);
					SetCtrlAttribute (MainPanelHandle, MainPanel_UpdateButton, ATTR_DIMMED, 1); 
					SetCtrlAttribute (MainPanelHandle, MainPanel_QuitButton, ATTR_DIMMED, 0); 
					SetCtrlAttribute (MainPanelHandle, MainPanel_CraftMode, ATTR_DIMMED, 1); 
					SetCtrlAttribute (MainPanelHandle, MainPanel_MisGuiMode, ATTR_DIMMED, 1); 
					SetCtrlAttribute (MainPanelHandle, MainPanel_MisFreeMode, ATTR_DIMMED, 1); 
					SetCtrlAttribute (MainPanelHandle, MainPanel_MisProMode, ATTR_DIMMED, 1); 
					SetCtrlAttribute (MainPanelHandle, MainPanel_ROTARYSHAKEBUTTON, ATTR_DIMMED, 1); 
					SetCtrlAttribute (MainPanelHandle, MainPanel_CURRENTOFFSETBUTTON, ATTR_DIMMED, 0);
					SetCtrlAttribute (MainPanelHandle, MainPanel_RotaryTabIn, ATTR_DIMMED, 1);  
					SetCtrlAttribute (MainPanelHandle, MainPanel_RotaryTabOut, ATTR_DIMMED, 1);  
					SetCtrlAttribute (MainPanelHandle, MainPanel_RotaryTabMid, ATTR_DIMMED, 1); 
					SetCtrlAttribute (MainPanelHandle, MainPanel_DataSaveFlag, ATTR_DIMMED, 1); 
					break;	
				case GNSS_INIT_FAIL:
				//	InsertTextBoxLine (MainPanelHandle, MainPanel_ProStatusTextBox, -1, "����ģ������ʼ����ʱʧ�ܡ�"); 
					
					InsertTableRows (MainPanelHandle, MainPanel_ProStatusTextBox, -1, 1, VAL_CELL_STRING);
					DisTableCounter++; 
					SetTableCellVal (MainPanelHandle, MainPanel_ProStatusTextBox, MakePoint (1, DisTableCounter), 
									" ����ģ������ʼ����ʱʧ�ܡ�");		 
					SetCtrlAttribute (MainPanelHandle, MainPanel_ProStatusTextBox, ATTR_VSCROLL_OFFSET, 32767);						
					
					
					SetCtrlAttribute (MainPanelHandle, MainPanel_InitialButton, ATTR_DIMMED, 0);
					SetCtrlAttribute (MainPanelHandle, MainPanel_StartButton, ATTR_DIMMED, 0);
					SetCtrlAttribute (MainPanelHandle, MainPanel_StopButton, ATTR_DIMMED, 0);
					SetCtrlAttribute (MainPanelHandle, MainPanel_UpdateButton, ATTR_DIMMED, 0); 
					SetCtrlAttribute (MainPanelHandle, MainPanel_QuitButton, ATTR_DIMMED, 0); 
					SetCtrlAttribute (MainPanelHandle, MainPanel_CraftMode, ATTR_DIMMED, 0); 
					SetCtrlAttribute (MainPanelHandle, MainPanel_MisGuiMode, ATTR_DIMMED, 0); 
					SetCtrlAttribute (MainPanelHandle, MainPanel_MisFreeMode, ATTR_DIMMED, 0); 
					SetCtrlAttribute (MainPanelHandle, MainPanel_MisProMode, ATTR_DIMMED, 0); 
					SetCtrlAttribute (MainPanelHandle, MainPanel_ROTARYSHAKEBUTTON, ATTR_DIMMED, 0);
					SetCtrlAttribute (MainPanelHandle, MainPanel_CURRENTOFFSETBUTTON, ATTR_DIMMED, 0);
					SetCtrlAttribute (MainPanelHandle, MainPanel_RotaryTabIn, ATTR_DIMMED, 0);  
					SetCtrlAttribute (MainPanelHandle, MainPanel_RotaryTabOut, ATTR_DIMMED, 0);  
					SetCtrlAttribute (MainPanelHandle, MainPanel_RotaryTabMid, ATTR_DIMMED, 0);
					SetCtrlAttribute (MainPanelHandle, MainPanel_DataSaveFlag, ATTR_DIMMED, 0); 
					break;
				case MISPRO_FILE_READ:
					
					int MisFTPerror=0;

					MisFTPerror = InetFTPAutoSend ( "169.254.176.211" ,"","", TrueDataFilePath ,
						                  "C:\\MisData.txt" , INET_FTP_FILE_TYPE_BINARY); 
					if (MisFTPerror < 0)
					{
						SetCtrlVal (MainPanelHandle, MainPanel_ProStatusTextBox, "ϵͳ�Լ��������ɽ���ʵ���ʼ����");  
						SetCtrlAttribute (MainPanelHandle, MainPanel_InitialButton, ATTR_DIMMED, 0);
						SetCtrlAttribute (MainPanelHandle, MainPanel_QuitButton, ATTR_DIMMED, 0);
						SetCtrlAttribute (MainPanelHandle, MainPanel_CraftMode, ATTR_DIMMED, 0); 
						SetCtrlAttribute (MainPanelHandle, MainPanel_MisGuiMode, ATTR_DIMMED, 0); 
						SetCtrlAttribute (MainPanelHandle, MainPanel_MisFreeMode, ATTR_DIMMED, 0); 
						SetCtrlAttribute (MainPanelHandle, MainPanel_MisProMode, ATTR_DIMMED, 0);
						SetCtrlAttribute (MainPanelHandle, MainPanel_DataSaveFlag, ATTR_DIMMED, 0); 
						MessagePopup ("����", "�ļ�·����Ч��");
						//MessagePopup (s, InetGetErrorMessage (MisFTPerror)); 
					}
					else
					{
				///		InsertTextBoxLine (MainPanelHandle, MainPanel_ProStatusTextBox, -1, " �����ļ�������ϣ����ڶ���ʵʱ���ڴ档"); 	

						InsertTableRows (MainPanelHandle, MainPanel_ProStatusTextBox, -1, 1, VAL_CELL_STRING);
						DisTableCounter++; 
						SetTableCellVal (MainPanelHandle, MainPanel_ProStatusTextBox, MakePoint (1, DisTableCounter), 
										" �����ļ�������ϣ����ڶ���ʵʱ���ڴ档");		 
						SetCtrlAttribute (MainPanelHandle, MainPanel_ProStatusTextBox, ATTR_VSCROLL_OFFSET, 32767);	
						cmd.SensorDataTrans_Flag = 1;
						ClientTCPWrite (gDataConnection, &cmd, sizeof(cmd), TCPDataWaitTime);					
					}
					
					break;
					
				case MISPRO_FILE_READ_FINISHED:
			//		InsertTextBoxLine (MainPanelHandle, MainPanel_ProStatusTextBox, -1, "ʵʱ�����ݶ�ȡ��ϡ�");
					InsertTableRows (MainPanelHandle, MainPanel_ProStatusTextBox, -1, 1, VAL_CELL_STRING);
					DisTableCounter++; 
					SetTableCellVal (MainPanelHandle, MainPanel_ProStatusTextBox, MakePoint (1, DisTableCounter), 
									" ʵʱ�����ݶ�ȡ��ϡ�");		 
					SetCtrlAttribute (MainPanelHandle, MainPanel_ProStatusTextBox, ATTR_VSCROLL_OFFSET, 32767);						
					
					break;
				case DATARD_MODE_ROTARY_INIT:
					//InsertTextBoxLine (MainPanelHandle, MainPanel_ProStatusTextBox, -1, "ʵʱ�������ļ���ȡ��ϣ����ڽ���ת̨��ʼ����"); 
					InsertTableRows (MainPanelHandle, MainPanel_ProStatusTextBox, -1, 1, VAL_CELL_STRING);
					DisTableCounter++; 
					SetTableCellVal (MainPanelHandle, MainPanel_ProStatusTextBox, MakePoint (1, DisTableCounter), 
									" ʵʱ�������ļ���ȡ��ϣ����ڽ���ת̨��ʼ����");		 
					SetCtrlAttribute (MainPanelHandle, MainPanel_ProStatusTextBox, ATTR_VSCROLL_OFFSET, 32767);						
					
					break;
				case TRACE_START:
		//			InsertTextBoxLine (MainPanelHandle, MainPanel_ProStatusTextBox, -1, "�켣��ʼ���ɡ�");

					InsertTableRows (MainPanelHandle, MainPanel_ProStatusTextBox, -1, 1, VAL_CELL_STRING);
					DisTableCounter++; 
					SetTableCellVal (MainPanelHandle, MainPanel_ProStatusTextBox, MakePoint (1, DisTableCounter), 
									" �켣��ʼ���ɡ�");		 
					SetCtrlAttribute (MainPanelHandle, MainPanel_ProStatusTextBox, ATTR_VSCROLL_OFFSET, 32767);						
					
					SetCtrlAttribute (MainPanelHandle, MainPanel_InitialButton, ATTR_DIMMED, 1);
					SetCtrlAttribute (MainPanelHandle, MainPanel_StartButton, ATTR_DIMMED, 1);
					SetCtrlAttribute (MainPanelHandle, MainPanel_StopButton, ATTR_DIMMED, 0);
					SetCtrlAttribute (MainPanelHandle, MainPanel_UpdateButton, ATTR_DIMMED, 1); 					
					SetCtrlAttribute (MainPanelHandle, MainPanel_QuitButton, ATTR_DIMMED, 1); 
					SetCtrlAttribute (MainPanelHandle, MainPanel_CraftMode, ATTR_DIMMED, 1); 
					SetCtrlAttribute (MainPanelHandle, MainPanel_MisGuiMode, ATTR_DIMMED, 1); 
					SetCtrlAttribute (MainPanelHandle, MainPanel_MisFreeMode, ATTR_DIMMED, 1); 
					SetCtrlAttribute (MainPanelHandle, MainPanel_MisProMode, ATTR_DIMMED, 1); 
					SetCtrlAttribute (MainPanelHandle, MainPanel_ROTARYSHAKEBUTTON, ATTR_DIMMED, 0);  
					SetCtrlAttribute (MainPanelHandle, MainPanel_CURRENTOFFSETBUTTON, ATTR_DIMMED, 1);   
					SetCtrlAttribute (MainPanelHandle, MainPanel_RotaryTabIn, ATTR_DIMMED, 0);  
					SetCtrlAttribute (MainPanelHandle, MainPanel_RotaryTabOut, ATTR_DIMMED, 0);  
					SetCtrlAttribute (MainPanelHandle, MainPanel_RotaryTabMid, ATTR_DIMMED, 0); 
					SetCtrlAttribute (MainPanelHandle, MainPanel_DataSaveFlag, ATTR_DIMMED, 1); 					
				
					break;
				case TRACE_FINISHED :
			//		InsertTextBoxLine (MainPanelHandle, MainPanel_ProStatusTextBox, -1, "�켣���ɽ�����");
					
					InsertTableRows (MainPanelHandle, MainPanel_ProStatusTextBox, -1, 1, VAL_CELL_STRING);
					DisTableCounter++; 
					SetTableCellVal (MainPanelHandle, MainPanel_ProStatusTextBox, MakePoint (1, DisTableCounter), 
									" �켣���ɽ�����");		 
					SetCtrlAttribute (MainPanelHandle, MainPanel_ProStatusTextBox, ATTR_VSCROLL_OFFSET, 32767);						
					
					if(!cmd.DataSaveFlag)
					{   //���ļ���������ť�ָ�����״̬
						SetCtrlAttribute (MainPanelHandle, MainPanel_InitialButton, ATTR_DIMMED, 0);
						SetCtrlAttribute (MainPanelHandle, MainPanel_StartButton, ATTR_DIMMED, 0);
						SetCtrlAttribute (MainPanelHandle, MainPanel_StopButton, ATTR_DIMMED, 0);
						SetCtrlAttribute (MainPanelHandle, MainPanel_UpdateButton, ATTR_DIMMED, 0); 					
						SetCtrlAttribute (MainPanelHandle, MainPanel_QuitButton, ATTR_DIMMED, 0); 
						SetCtrlAttribute (MainPanelHandle, MainPanel_CraftMode, ATTR_DIMMED, 0); 
						SetCtrlAttribute (MainPanelHandle, MainPanel_MisGuiMode, ATTR_DIMMED, 0); 
						SetCtrlAttribute (MainPanelHandle, MainPanel_MisFreeMode, ATTR_DIMMED, 0); 
						SetCtrlAttribute (MainPanelHandle, MainPanel_MisProMode, ATTR_DIMMED, 0); 
						SetCtrlAttribute (MainPanelHandle, MainPanel_DataSaveFlag, ATTR_DIMMED, 0); 
					}
					break;
				case TRACE_SAVING :
		//			InsertTextBoxLine (MainPanelHandle, MainPanel_ProStatusTextBox, -1, "���ڽ�����д����̡�");
					
					
					InsertTableRows (MainPanelHandle, MainPanel_ProStatusTextBox, -1, 1, VAL_CELL_STRING);
					DisTableCounter++; 
					SetTableCellVal (MainPanelHandle, MainPanel_ProStatusTextBox, MakePoint (1, DisTableCounter), 
									" ���ڽ�����д����̡�");		 
					SetCtrlAttribute (MainPanelHandle, MainPanel_ProStatusTextBox, ATTR_VSCROLL_OFFSET, 32767);						
					
					SetCtrlAttribute (MainPanelHandle, MainPanel_InitialButton, ATTR_DIMMED, 1);
					SetCtrlAttribute (MainPanelHandle, MainPanel_StartButton, ATTR_DIMMED, 1);
					SetCtrlAttribute (MainPanelHandle, MainPanel_StopButton, ATTR_DIMMED, 1);
					SetCtrlAttribute (MainPanelHandle, MainPanel_UpdateButton, ATTR_DIMMED, 1); 					
					SetCtrlAttribute (MainPanelHandle, MainPanel_QuitButton, ATTR_DIMMED, 1); 
					SetCtrlAttribute (MainPanelHandle, MainPanel_CraftMode, ATTR_DIMMED, 1); 
					SetCtrlAttribute (MainPanelHandle, MainPanel_MisGuiMode, ATTR_DIMMED, 1); 
					SetCtrlAttribute (MainPanelHandle, MainPanel_MisFreeMode, ATTR_DIMMED, 1); 
					SetCtrlAttribute (MainPanelHandle, MainPanel_MisProMode, ATTR_DIMMED, 1);
					SetCtrlAttribute (MainPanelHandle, MainPanel_DataSaveFlag, ATTR_DIMMED, 1); 
					break;
				case DATA_SAVE_FINISHED:
			//		InsertTextBoxLine (MainPanelHandle, MainPanel_ProStatusTextBox, -1, "���ݴ洢��ϣ����Խ����ϴ���"); 
					
					InsertTableRows (MainPanelHandle, MainPanel_ProStatusTextBox, -1, 1, VAL_CELL_STRING);
					DisTableCounter++; 
					SetTableCellVal (MainPanelHandle, MainPanel_ProStatusTextBox, MakePoint (1, DisTableCounter), 
									" ���ݴ洢��ϣ����Խ����ϴ���");		 
					SetCtrlAttribute (MainPanelHandle, MainPanel_ProStatusTextBox, ATTR_VSCROLL_OFFSET, 32767);						
					
					SetCtrlAttribute (MainPanelHandle, MainPanel_InitialButton, ATTR_DIMMED, 0);
					SetCtrlAttribute (MainPanelHandle, MainPanel_StartButton, ATTR_DIMMED, 0);
					SetCtrlAttribute (MainPanelHandle, MainPanel_StopButton, ATTR_DIMMED, 1);//by zxl 20141107
					SetCtrlAttribute (MainPanelHandle, MainPanel_UpdateButton, ATTR_DIMMED, 0); 					
					SetCtrlAttribute (MainPanelHandle, MainPanel_QuitButton, ATTR_DIMMED, 0); 
					SetCtrlAttribute (MainPanelHandle, MainPanel_CraftMode, ATTR_DIMMED, 0); 
					SetCtrlAttribute (MainPanelHandle, MainPanel_MisGuiMode, ATTR_DIMMED, 0); 
					SetCtrlAttribute (MainPanelHandle, MainPanel_MisFreeMode, ATTR_DIMMED, 0); 
					SetCtrlAttribute (MainPanelHandle, MainPanel_MisProMode, ATTR_DIMMED, 0); 	
					SetCtrlAttribute (MainPanelHandle, MainPanel_DataSaveFlag, ATTR_DIMMED, 0); 
				case DATA_FILE_SENT:
		//			InsertTextBoxLine (MainPanelHandle, MainPanel_ProStatusTextBox, -1, "�����ļ��ϴ���ϡ�");  
			
					InsertTableRows (MainPanelHandle, MainPanel_ProStatusTextBox, -1, 1, VAL_CELL_STRING);
					DisTableCounter++; 
					SetTableCellVal (MainPanelHandle, MainPanel_ProStatusTextBox, MakePoint (1, DisTableCounter), 
									" �����ļ��ϴ���ϡ�");		 
					SetCtrlAttribute (MainPanelHandle, MainPanel_ProStatusTextBox, ATTR_VSCROLL_OFFSET, 32767);						
					
					SetCtrlAttribute (MainPanelHandle, MainPanel_InitialButton, ATTR_DIMMED, 0);
					SetCtrlAttribute (MainPanelHandle, MainPanel_StartButton, ATTR_DIMMED, 0);
					SetCtrlAttribute (MainPanelHandle, MainPanel_StopButton, ATTR_DIMMED, 1);
					SetCtrlAttribute (MainPanelHandle, MainPanel_UpdateButton, ATTR_DIMMED, 0); 					
					SetCtrlAttribute (MainPanelHandle, MainPanel_QuitButton, ATTR_DIMMED, 0); 
					SetCtrlAttribute (MainPanelHandle, MainPanel_CraftMode, ATTR_DIMMED, 0); 
					SetCtrlAttribute (MainPanelHandle, MainPanel_MisGuiMode, ATTR_DIMMED, 0); 
					SetCtrlAttribute (MainPanelHandle, MainPanel_MisFreeMode, ATTR_DIMMED, 0); 
					SetCtrlAttribute (MainPanelHandle, MainPanel_MisProMode, ATTR_DIMMED, 0); 
					SetCtrlAttribute (MainPanelHandle, MainPanel_DataSaveFlag, ATTR_DIMMED, 0); 
					break;
				case DATA_FILE_SENT_FAIL:
		//			InsertTextBoxLine (MainPanelHandle, MainPanel_ProStatusTextBox, -1, "�����ļ��ϴ�ʧ�ܡ�");  
					InsertTableRows (MainPanelHandle, MainPanel_ProStatusTextBox, -1, 1, VAL_CELL_STRING);
					DisTableCounter++; 
					SetTableCellVal (MainPanelHandle, MainPanel_ProStatusTextBox, MakePoint (1, DisTableCounter), 
									" �����ļ��ϴ�ʧ�ܡ�");		 
					SetCtrlAttribute (MainPanelHandle, MainPanel_ProStatusTextBox, ATTR_VSCROLL_OFFSET, 32767);						
					
					
					SetCtrlAttribute (MainPanelHandle, MainPanel_InitialButton, ATTR_DIMMED, 0);
					SetCtrlAttribute (MainPanelHandle, MainPanel_StartButton, ATTR_DIMMED, 0);
					SetCtrlAttribute (MainPanelHandle, MainPanel_StopButton, ATTR_DIMMED, 0);
					SetCtrlAttribute (MainPanelHandle, MainPanel_UpdateButton, ATTR_DIMMED, 0); 					
					SetCtrlAttribute (MainPanelHandle, MainPanel_QuitButton, ATTR_DIMMED, 0); 
					SetCtrlAttribute (MainPanelHandle, MainPanel_CraftMode, ATTR_DIMMED, 0); 
					SetCtrlAttribute (MainPanelHandle, MainPanel_MisGuiMode, ATTR_DIMMED, 0); 
					SetCtrlAttribute (MainPanelHandle, MainPanel_MisFreeMode, ATTR_DIMMED, 0); 
					SetCtrlAttribute (MainPanelHandle, MainPanel_MisProMode, ATTR_DIMMED, 0); 
					SetCtrlAttribute (MainPanelHandle, MainPanel_DataSaveFlag, ATTR_DIMMED, 0); 
					break;
				case DATA_DISPLAY:
					switch(data.TraceStatus)
					{
						case TRACE_GENERATING_CRAFT:
					         SetCtrlVal (MainPanelHandle, MainPanel_Box_TraceState, "�ػ��ҵ��켣������...");
							 break;
				      	case TRACE_GENERATING_M_FREE:
							 SetCtrlVal (MainPanelHandle, MainPanel_Box_TraceState, "�������ɷ��й켣������..."); 
							 break;
						case TRACE_GENERATING_M_GUI:
							 SetCtrlVal (MainPanelHandle, MainPanel_Box_TraceState, "�����Ƶ��켣������...");  
							 break;
						case TRACE_GENERATING_M_PRO:
							 SetCtrlVal (MainPanelHandle, MainPanel_Box_TraceState, "�̿ص����ݶ�ȡ�켣������...");  
						   	 break;
							 
						case TRACE_FINISHED_CRAFT:
							 SetCtrlVal (MainPanelHandle, MainPanel_Box_TraceState, "�ػ��ҵ��켣���ɽ�����");
							 break;
						case TRACE_FINISHED_M_FREE:
							 SetCtrlVal (MainPanelHandle, MainPanel_Box_TraceState, "�������ɷ��й켣���ɽ�����");
							 break;
						case TRACE_FINISHED_M_GUI:
							 SetCtrlVal (MainPanelHandle, MainPanel_Box_TraceState, "�����Ƶ��켣���ɽ�����");
							 break;							 
						case TRACE_FINISHED_M_PRO:
							 SetCtrlVal (MainPanelHandle, MainPanel_Box_TraceState, "������ȡ���ݹ켣���ɽ�����");
							 break;	
							 
						case MISGUI_HIT:
							SetCtrlVal (MainPanelHandle, MainPanel_Box_TraceState, "Ŀ�걻���У�"); 
						break;	 
			 
					}
					SetCtrlVal (MainPanelHandle, MainPanel_Box_TraceTime, (data.TraceTime + 0.1)); 
					SetCtrlVal (MainPanelHandle, MainPanel_Box_PositionLon, data.TraceLon); 
					SetCtrlVal (MainPanelHandle, MainPanel_Box_PositionLat, data.TraceLat); 
					SetCtrlVal (MainPanelHandle, MainPanel_Box_PositionAlt, data.TraceAlt); 
					SetCtrlVal (MainPanelHandle, MainPanel_Box_VelocityE, data.VelocityE); 	
					SetCtrlVal (MainPanelHandle, MainPanel_Box_VelocityN, data.VelocityN); 	
					SetCtrlVal (MainPanelHandle, MainPanel_Box_VelocityU, data.VelocityU); 	
					SetCtrlVal (MainPanelHandle, MainPanel_Box_TraceYaw, data.TraceYaw); 	
					SetCtrlVal (MainPanelHandle, MainPanel_Box_TracePitch, data.TracePitch);
					SetCtrlVal (MainPanelHandle, MainPanel_Box_TraceRoll, data.TraceRoll); 	
					SetCtrlVal (MainPanelHandle, MainPanel_Box_RotaryOut, data.RotaryOut); 	
					SetCtrlVal (MainPanelHandle, MainPanel_Box_RotaryMid, data.RotaryMid); 	
					SetCtrlVal (MainPanelHandle, MainPanel_Box_RotaryIn, data.RotaryIn);
					
					SetCtrlVal (MainPanelHandle, MainPanel_Box_FC_PosX, data.FC_PosX); 	  
					SetCtrlVal (MainPanelHandle, MainPanel_Box_FC_PosY, data.FC_PosY); 	  
					SetCtrlVal (MainPanelHandle, MainPanel_Box_FC_PosZ, data.FC_PosZ); 	  
					SetCtrlVal (MainPanelHandle, MainPanel_Box_FC_VelX, data.FC_VelX); 	  
					SetCtrlVal (MainPanelHandle, MainPanel_Box_FC_VelY, data.FC_VelY); 	  
					SetCtrlVal (MainPanelHandle, MainPanel_Box_FC_VelZ, data.FC_VelZ); 	  
					SetCtrlVal (MainPanelHandle, MainPanel_Box_Qua0, data.FC_Qua0); 	  
					SetCtrlVal (MainPanelHandle, MainPanel_Box_Qua1, data.FC_Qua1); 	  
					SetCtrlVal (MainPanelHandle, MainPanel_Box_Qua2, data.FC_Qua2); 	  
					SetCtrlVal (MainPanelHandle, MainPanel_Box_Qua3, data.FC_Qua3); 	  

					MissileVb = sqrt(data.VelocityE * data.VelocityE +
						             data.VelocityN * data.VelocityN +
									 data.VelocityU * data.VelocityU);
					SetCtrlVal (MainPanelHandle, MainPanel_VelocityIndicator, MissileVb);  
					
					SetCtrlVal (MainPanelHandle, MainPanel_YawIndicator, data.TraceYaw); 
					SetCtrlVal (MainPanelHandle, MainPanel_PitchIndicator, data.TracePitch); 
					SetCtrlVal (MainPanelHandle, MainPanel_RollIndicator, data.TraceRoll); 
					
					break;		   
			}   		
            break;
    }
    return 0;
}

/************************************�������***************************************/

//�����˵��ص�����
void CVICALLBACK  CraParSetCallback(int menuBar, int menuItem, void *callbackData,int panel)	 	 //�ػ����ò˵�
{
	switch(menuItem)
	{  
		case MENUBAR_CraParSet:
			 CraftSetPanelHandle = LoadPanel(0, "CRAFT_PANEL.uir",CraftPANEL) ;
			 CraftNewRow = 0; 
			 
			 if(CraftPanelIni_exist == 1)
			 {
				 InitialCraftPanelVariable(); 
				 SetCraftParameterToPanel();		//������д�����
				 SetCraftTraceToPanel();
				 
				 SetCtrlAttribute (CraftSetPanelHandle, CraftPANEL_NUMERICCraftTime, ATTR_DIMMED, 0);
			     SetCtrlAttribute (CraftSetPanelHandle, CraftPANEL_NUMERICCraftIniAcc, ATTR_DIMMED, 0);		  
				 SetCtrlAttribute (CraftSetPanelHandle, CraftPANEL_NUMERICCraftAziCha, ATTR_DIMMED, 1);
			     SetCtrlAttribute (CraftSetPanelHandle, CraftPANEL_NUMERICCraftPitCha, ATTR_DIMMED, 1);
			     SetCtrlAttribute (CraftSetPanelHandle, CraftPANEL_NUMERICCraftRolCha, ATTR_DIMMED, 1);				 
		     }
			 
			 SetPanelAttribute (CraftSetPanelHandle, ATTR_WINDOW_ZOOM, VAL_MAXIMIZE);   
			 DisplayPanel (CraftSetPanelHandle);
			 HidePanel (MainPanelHandle);
			 break;
	}
}

void CVICALLBACK  MisParSetCallback(int menuBar, int menuItem, void *callbackData,int panel)         //�������ò˵�
{
	switch(menuItem)
	{  
		case MENUBAR_MisGuiParSet:
			 MissileSetPanelHandle=LoadPanel(0, "MISSILE_PANEL.uir",MisPANEL) ;
			//��ʼ�������������ĸ��ؼ�����
			if(MissilePanelIni_exist==1)
			{
				SetVariableToPanel();
			}
			
			SetPanelAttribute (MissileSetPanelHandle, ATTR_WINDOW_ZOOM, VAL_MAXIMIZE);   
			DisplayPanel (MissileSetPanelHandle);
			HidePanel (MainPanelHandle);
			
			break;
	}
}

void CVICALLBACK  AlgorithmResearchCallback(int menuBar, int menuItem, void *callbackData,int panel) //�㷨�о����ü���ʾ�˵�
{
	switch(menuItem)
	{  
		case MENUBAR_AlgorithmResearch:
			 AlgorithmResearchPanelHandle=LoadPanel(0, "ALGORITHM_PANEL.uir",AlgoPANEL);
			 
			 SetPanelAttribute (AlgorithmResearchPanelHandle, ATTR_WINDOW_ZOOM, VAL_MAXIMIZE);   
			 DisplayPanel (AlgorithmResearchPanelHandle);
			 HidePanel (MainPanelHandle);

		break;
	}
}

void    DataFileCallback(int menuBar, int menuItem, void *callbackData,int panel) //�㷨�о����ü���ʾ�˵�
{  
	char panelparsavepath[260];
	switch(menuItem)
	{  
		case MENUBAR_DataFileTrans:
			 
			DataFileTransPanelHandle = LoadPanel(MainPanelHandle, "DATAFILE_TRAN.uir", Data_PANEL);
		
			GetProjectDir (panelparsavepath); 
			strcat(panelparsavepath, "\\datapanelsavefile");
		
   		    RecallPanelState (DataFileTransPanelHandle, panelparsavepath, 0);
			SetCtrlVal (DataFileTransPanelHandle, Data_PANEL_Processing_Slide, 0); 
			SetCtrlVal (DataFileTransPanelHandle, Data_PANEL_TransStatus, "�ȴ����ݴ�����ʼ��");
			HidePanel (MainPanelHandle);
			InstallPopup(DataFileTransPanelHandle);
			 
		break;
	}
}

//�����ѡ��ص����� 
int CVICALLBACK CraftModeCallback (int panel, int control, int event, void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:
			SetCtrlVal (MainPanelHandle, MainPanel_CraftMode, 1); 
			SetCtrlVal (MainPanelHandle, MainPanel_MisGuiMode, 0); 
			SetCtrlVal (MainPanelHandle, MainPanel_MisFreeMode, 0); 
			SetCtrlVal (MainPanelHandle, MainPanel_MisProMode, 0); 
			TraceModeSelect = CRAFT_MODE;
			break;
	}
	return 0;
}

int CVICALLBACK MisGuiModeCallback (int panel, int control, int event,void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:
			SetCtrlVal (MainPanelHandle, MainPanel_CraftMode, 0); 
			SetCtrlVal (MainPanelHandle, MainPanel_MisGuiMode, 1); 
			SetCtrlVal (MainPanelHandle, MainPanel_MisFreeMode, 0); 
			SetCtrlVal (MainPanelHandle, MainPanel_MisProMode, 0);
			TraceModeSelect = MISGUI_MODE;  
			break;
	}
	return 0;
}

int CVICALLBACK MisFreeModeCallback (int panel, int control, int event,void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:
			SetCtrlVal (MainPanelHandle, MainPanel_CraftMode, 0); 
			SetCtrlVal (MainPanelHandle, MainPanel_MisGuiMode, 0); 
			SetCtrlVal (MainPanelHandle, MainPanel_MisFreeMode, 1); 
			SetCtrlVal (MainPanelHandle, MainPanel_MisProMode, 0);
			TraceModeSelect = MISFREE_MODE; 
			break;
	}
	return 0;
}

int CVICALLBACK MisProModeCallback (int panel, int control, int event,void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:
			SetCtrlVal (MainPanelHandle, MainPanel_CraftMode, 0); 
			SetCtrlVal (MainPanelHandle, MainPanel_MisGuiMode, 0); 
			SetCtrlVal (MainPanelHandle, MainPanel_MisFreeMode, 0); 
			SetCtrlVal (MainPanelHandle, MainPanel_MisProMode, 1);
			TraceModeSelect = DATARD_MODE; 

			break;
	}
	return 0;
}

//����尴ť�ص�����
int CVICALLBACK ConnectionCreatCallback (int panel, int control, int event,void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:
			if(ConnectToTCPServer (&gDataConnection, HOST_PORT, SERVER_ADDRESS, TCPDataCallback, 0, 500) < 0);
			{
				SetCtrlVal (MainPanelHandle, MainPanel_STRINGNetConnentState, "�ȴ���������ʵʱ����");  
			}
			break;
	}
	return 0;						 
}
 
int CVICALLBACK CurrentOffsetCallback (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:
			GetCtrlVal (MainPanelHandle, MainPanel_CURRENTOFFSETBUTTON, &cmd.CurrentButtonStatus);
			
			cmd.command = CURRENT_OFFSET;
			ClientTCPWrite (gDataConnection, &cmd, sizeof(cmd), TCPDataWaitTime); 
		
			break;
	}
	return 0;
}

int CVICALLBACK RotaryShakeCallback (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		int RotaryShakeCMD_Out; 
		int RotaryShakeCMD_Mid;   
		int RotaryShakeCMD_In;
		
		case EVENT_COMMIT:

			GetCtrlVal (MainPanel, MainPanel_RotaryTabOut, &RotaryShakeCMD_Out);
			GetCtrlVal (MainPanel, MainPanel_RotaryTabMid, &RotaryShakeCMD_Mid); 
			GetCtrlVal (MainPanel, MainPanel_RotaryTabIn, &RotaryShakeCMD_In); 
			
			if( !(RotaryShakeCMD_Out || RotaryShakeCMD_Mid || RotaryShakeCMD_In) )
				cmd.RotaryTabShakeStatus = ALL_STOP;
			else if(RotaryShakeCMD_Out && RotaryShakeCMD_Mid && RotaryShakeCMD_In)
				cmd.RotaryTabShakeStatus = ALL_SHAKE; 
			else if(RotaryShakeCMD_Out && !RotaryShakeCMD_Mid && !RotaryShakeCMD_In) 
				cmd.RotaryTabShakeStatus = ONLY_OUT; 
			else if(!RotaryShakeCMD_Out && RotaryShakeCMD_Mid && !RotaryShakeCMD_In) 
				cmd.RotaryTabShakeStatus = ONLY_MID; 
			else if(!RotaryShakeCMD_Out && !RotaryShakeCMD_Mid && RotaryShakeCMD_In) 
				cmd.RotaryTabShakeStatus = ONLY_INN; 
			else if(RotaryShakeCMD_Out && RotaryShakeCMD_Mid && !RotaryShakeCMD_In) 
				cmd.RotaryTabShakeStatus = OUT_MID; 
			else if(RotaryShakeCMD_Out && !RotaryShakeCMD_Mid && RotaryShakeCMD_In) 
				cmd.RotaryTabShakeStatus = OUT_INN; 
			else if(!RotaryShakeCMD_Out && RotaryShakeCMD_Mid && RotaryShakeCMD_In) 
				cmd.RotaryTabShakeStatus = MID_INN; 
			else;
			
			cmd.command = ROTARY_SHAKE;
			ClientTCPWrite (gDataConnection, &cmd, sizeof(cmd), TCPDataWaitTime);			
	}
	return 0;
}
 
int CVICALLBACK InitialCallback (int panel, int control, int event,void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:
		
			CalcAtt_Error(); 

			DeleteTableRows (MainPanelHandle, MainPanel_ProStatusTextBox, 1, -1);
			DisTableCounter = 0;

			GetCtrlVal (MainPanel, MainPanel_DataSaveFlag, &cmd.DataSaveFlag);
			cmd.command = INITIAL_COMMAND;
			cmd.tracemode = TraceModeSelect;
		
			switch(TraceModeSelect)
			{
				case CRAFT_MODE:
					StructureDataInitial_Craft();
					ClientTCPWrite (gDataConnection, &cmd, sizeof(cmd), TCPDataWaitTime); 
			
					ClientTCPRead (gDataConnection, &cmd, sizeof(cmd), TCPDataWaitTime);
					ClientTCPWrite (gDataConnection, &CraftPara, sizeof(CraftPara), TCPDataWaitTime); 
			
					ClientTCPRead (gDataConnection, &cmd, sizeof(cmd), TCPDataWaitTime);
					ClientTCPWrite (gDataConnection, &CraftTrace, sizeof(CraftTrace), TCPDataWaitTime);	
					break;
					
				case MISGUI_MODE: 
					StructureDataInitial_Missile();
					ClientTCPWrite (gDataConnection, &cmd, sizeof(cmd), TCPDataWaitTime);
			
					ClientTCPRead (gDataConnection, &cmd, sizeof(cmd), TCPDataWaitTime);
					ClientTCPWrite (gDataConnection, &MisPara, sizeof(MisPara), TCPDataWaitTime);
					
					ClientTCPRead (gDataConnection, &cmd, sizeof(cmd), TCPDataWaitTime); 
					ClientTCPWrite (gDataConnection, &TarData, sizeof(TarData), TCPDataWaitTime);
					break;
				case MISFREE_MODE:
					StructureDataInitial_Missile(); 
					ClientTCPWrite (gDataConnection, &cmd, sizeof(cmd), TCPDataWaitTime);
			
					ClientTCPRead (gDataConnection, &cmd, sizeof(cmd), TCPDataWaitTime);
					ClientTCPWrite (gDataConnection, &MisPara, sizeof(MisPara), TCPDataWaitTime);
					
					ClientTCPRead (gDataConnection, &cmd, sizeof(cmd), TCPDataWaitTime); 
					ClientTCPWrite (gDataConnection, &MisTrace, sizeof(MisTrace), TCPDataWaitTime);   Delay(5);
					break;					
				case DATARD_MODE:
					
					StructureDataInitial_Craft();   //�̿ص��������ػ�������������������
					
					cmd.SensorDataTrans_Flag = 0;
					ClientTCPWrite (gDataConnection, &cmd, sizeof(cmd), TCPDataWaitTime);
					
					ClientTCPRead (gDataConnection, &cmd, sizeof(cmd), TCPDataWaitTime);
					ClientTCPWrite (gDataConnection, &CraftPara, sizeof(CraftPara), TCPDataWaitTime); 
				
			//		InsertTextBoxLine (MainPanelHandle, MainPanel_ProStatusTextBox, -1, "��������λ�����������ļ�����ʼ������");   
				
					InsertTableRows (MainPanelHandle, MainPanel_ProStatusTextBox, -1, 1, VAL_CELL_STRING);
					DisTableCounter++; 
					SetTableCellVal (MainPanelHandle, MainPanel_ProStatusTextBox, MakePoint (1, DisTableCounter), 
									" ��������λ�����������ļ�����ʼ������");		 
					SetCtrlAttribute (MainPanelHandle, MainPanel_ProStatusTextBox, ATTR_VSCROLL_OFFSET, 32767);						
					
					SetCtrlAttribute (MainPanelHandle, MainPanel_InitialButton, ATTR_DIMMED, 1);
					SetCtrlAttribute (MainPanelHandle, MainPanel_StartButton, ATTR_DIMMED, 1);
					SetCtrlAttribute (MainPanelHandle, MainPanel_StopButton, ATTR_DIMMED, 1);
					SetCtrlAttribute (MainPanelHandle, MainPanel_UpdateButton, ATTR_DIMMED, 1); 					
					SetCtrlAttribute (MainPanelHandle, MainPanel_QuitButton, ATTR_DIMMED, 1); 
					SetCtrlAttribute (MainPanelHandle, MainPanel_CraftMode, ATTR_DIMMED, 1); 
					SetCtrlAttribute (MainPanelHandle, MainPanel_MisGuiMode, ATTR_DIMMED, 1); 
					SetCtrlAttribute (MainPanelHandle, MainPanel_MisFreeMode, ATTR_DIMMED, 1); 
					SetCtrlAttribute (MainPanelHandle, MainPanel_MisProMode, ATTR_DIMMED, 1); 
					SetCtrlAttribute (MainPanelHandle, MainPanel_ROTARYSHAKEBUTTON, ATTR_DIMMED, 1);  
					SetCtrlAttribute (MainPanelHandle, MainPanel_CURRENTOFFSETBUTTON, ATTR_DIMMED, 1);   
					SetCtrlAttribute (MainPanelHandle, MainPanel_RotaryTabIn, ATTR_DIMMED, 1);  
					SetCtrlAttribute (MainPanelHandle, MainPanel_RotaryTabOut, ATTR_DIMMED, 1);  
					SetCtrlAttribute (MainPanelHandle, MainPanel_RotaryTabMid, ATTR_DIMMED, 1); 
					SetCtrlAttribute (MainPanelHandle, MainPanel_DataSaveFlag, ATTR_DIMMED, 1); 

					break;					
			}
			break;
	}
	return 0;
}

int CVICALLBACK StartCallback (int panel, int control, int event,void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:
			cmd.command = START_COMMAND;
			ClientTCPWrite (gDataConnection, &cmd, sizeof(cmd), TCPDataWaitTime);
		
			SetCtrlAttribute (MainPanelHandle, MainPanel_InitialButton, ATTR_DIMMED, 1);
			SetCtrlAttribute (MainPanelHandle, MainPanel_StartButton, ATTR_DIMMED, 1);
			SetCtrlAttribute (MainPanelHandle, MainPanel_StopButton, ATTR_DIMMED, 0);
			SetCtrlAttribute (MainPanelHandle, MainPanel_UpdateButton, ATTR_DIMMED, 1); 					
			SetCtrlAttribute (MainPanelHandle, MainPanel_QuitButton, ATTR_DIMMED, 1); 
			SetCtrlAttribute (MainPanelHandle, MainPanel_CraftMode, ATTR_DIMMED, 1); 
			SetCtrlAttribute (MainPanelHandle, MainPanel_MisGuiMode, ATTR_DIMMED, 1); 
			SetCtrlAttribute (MainPanelHandle, MainPanel_MisFreeMode, ATTR_DIMMED, 1); 
			SetCtrlAttribute (MainPanelHandle, MainPanel_MisProMode, ATTR_DIMMED, 1); 
			SetCtrlAttribute (MainPanelHandle, MainPanel_ROTARYSHAKEBUTTON, ATTR_DIMMED, 0);  
			SetCtrlAttribute (MainPanelHandle, MainPanel_CURRENTOFFSETBUTTON, ATTR_DIMMED, 0);   
			SetCtrlAttribute (MainPanelHandle, MainPanel_RotaryTabIn, ATTR_DIMMED, 0);  
			SetCtrlAttribute (MainPanelHandle, MainPanel_RotaryTabOut, ATTR_DIMMED, 0);  
			SetCtrlAttribute (MainPanelHandle, MainPanel_RotaryTabMid, ATTR_DIMMED, 0); 
			SetCtrlAttribute (MainPanelHandle, MainPanel_DataSaveFlag, ATTR_DIMMED, 1); 
			
			break;
	}
	return 0;
}

int CVICALLBACK StopCallback (int panel, int control, int event,void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:
			cmd.command = STOP_COMMAND;
			ClientTCPWrite (gDataConnection, &cmd, sizeof(cmd), TCPDataWaitTime);
			
			SetCtrlAttribute (MainPanelHandle, MainPanel_InitialButton, ATTR_DIMMED, 1);
			SetCtrlAttribute (MainPanelHandle, MainPanel_StartButton, ATTR_DIMMED, 1);
			SetCtrlAttribute (MainPanelHandle, MainPanel_StopButton, ATTR_DIMMED, 1);
			SetCtrlAttribute (MainPanelHandle, MainPanel_UpdateButton, ATTR_DIMMED, 1); 					
			SetCtrlAttribute (MainPanelHandle, MainPanel_QuitButton, ATTR_DIMMED, 1); 
			SetCtrlAttribute (MainPanelHandle, MainPanel_CraftMode, ATTR_DIMMED, 1); 
			SetCtrlAttribute (MainPanelHandle, MainPanel_MisGuiMode, ATTR_DIMMED, 1); 
			SetCtrlAttribute (MainPanelHandle, MainPanel_MisFreeMode, ATTR_DIMMED, 1); 
			SetCtrlAttribute (MainPanelHandle, MainPanel_MisProMode, ATTR_DIMMED, 1); 
			SetCtrlAttribute (MainPanelHandle, MainPanel_DataSaveFlag, ATTR_DIMMED, 1); 			
			
			break;
	}
	return 0;
}

int CVICALLBACK UpdataCallback (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:
			
	//		InsertTextBoxLine (MainPanelHandle, MainPanel_ProStatusTextBox, -1, "�����ϴ������ļ���");  
			
			InsertTableRows (MainPanelHandle, MainPanel_ProStatusTextBox, -1, 1, VAL_CELL_STRING);
			DisTableCounter++; 
			SetTableCellVal (MainPanelHandle, MainPanel_ProStatusTextBox, MakePoint (1, DisTableCounter), 
							" �����ϴ������ļ���");		 
			SetCtrlAttribute (MainPanelHandle, MainPanel_ProStatusTextBox, ATTR_VSCROLL_OFFSET, 32767);				
			
			SetCtrlAttribute (MainPanelHandle, MainPanel_InitialButton, ATTR_DIMMED, 1);
			SetCtrlAttribute (MainPanelHandle, MainPanel_StartButton, ATTR_DIMMED, 1);
			SetCtrlAttribute (MainPanelHandle, MainPanel_StopButton, ATTR_DIMMED, 1);
			SetCtrlAttribute (MainPanelHandle, MainPanel_UpdateButton, ATTR_DIMMED, 1); 					
			SetCtrlAttribute (MainPanelHandle, MainPanel_QuitButton, ATTR_DIMMED, 1); 
			SetCtrlAttribute (MainPanelHandle, MainPanel_CraftMode, ATTR_DIMMED, 1); 
			SetCtrlAttribute (MainPanelHandle, MainPanel_MisGuiMode, ATTR_DIMMED, 1); 
			SetCtrlAttribute (MainPanelHandle, MainPanel_MisFreeMode, ATTR_DIMMED, 1); 
			SetCtrlAttribute (MainPanelHandle, MainPanel_MisProMode, ATTR_DIMMED, 1); 
			SetCtrlAttribute (MainPanelHandle, MainPanel_DataSaveFlag, ATTR_DIMMED, 1); 
			
			CreateFolder();  
			cmd.tracemode = TraceModeSelect;
			cmd.command = UPDATE_COMMAND;
			strcpy(cmd.HostDataPath, HostDataPath);  
			ClientTCPWrite (gDataConnection, &cmd, sizeof(cmd), TCPDataWaitTime); 
			break;
	}
	return 0;
}

int CVICALLBACK QuitCallback (int panel, int control, int event,void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:
			 cmd.command = QUIT_COMMAND; 
			 ClientTCPWrite (gDataConnection, &cmd, sizeof(cmd), TCPDataWaitTime);
			 
			 GetCtrlVal (MainPanel, MainPanel_DataSaveFlag, &cmd.DataSaveFlag); 
 	 	 	 
			 MainPanelIniFileHandle=fopen(MainPanelIni_FILE_PATH,"wb"); 
		  	 fprintf(MainPanelIniFileHandle,"%d\t%d", TraceModeSelect, cmd.DataSaveFlag); 
			 fclose(MainPanelIniFileHandle);
			 
			 QuitUserInterface(0); 
			break;
	}
	return 0;
}

//����¼��ص�����
int CVICALLBACK  MainPanelCallback (int panel, int event, void *callbackData, int eventData1, int eventData2) 	 	 
{
	if(event == EVENT_CLOSE)
	{
 	 	 MainPanelIniFileHandle=fopen(MainPanelIni_FILE_PATH,"wb"); 
	  	 fprintf(MainPanelIniFileHandle,"%d ", TraceModeSelect); 
		 fclose(MainPanelIniFileHandle);
		 QuitUserInterface(0);
	}
	return 0;
}

/***************************�ػ����й켣���������������****************************/

//ȷ�ϰ�ť�ص����� 
int CVICALLBACK CraftTraceParameterCallback (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)  
{   
	switch (event)
	{
		case EVENT_COMMIT:  //��ȡ����������Ĳ��������������ṹ�帳ֵ����������ֵ�����ı�
			//ת̨ҡ�ڲ����޷�

			GetCraftParameterFromPanel(); 
			
			for(int i = 0; i <= 2; i++)
			{
				AngleSetMax[i] = RotaryAmp[i] * RotaryFre[i] * 2 * 3.14159;
				AngleRateSetMax[i] = pow((RotaryAmp[i] * RotaryFre[i] * 2 * 3.14159), 2); 
			}
			
			if( (AngleSetMax[0] >= 600) || (AngleSetMax[1] >= 600) || (AngleSetMax[2] >= 600) ||
				(AngleRateSetMax[0] >= 5500) || (AngleRateSetMax[1] >= 2000) || (AngleRateSetMax[2] >= 2000))
				
				MessagePopup ("ת̨ҡ�ڲ������ó������ƣ�", 
				"����������ת̨ҡ�ڲ�����ʹ\n\n\t������ٶȡ�600��/s��\n\t�ڿ�Ǽ��ٶȡ�5500��/s^2��\n\t�п�Ǽ��ٶȡ�2000��/s^2��\n\t���Ǽ��ٶȡ�2000��/s^2��\n\n\t�������¹�ʽ���㣺\n\t���ٶ� = 2 * pi * ��ֵ * Ƶ�ʡ�\n\t�Ǽ��ٶ� = (2 * pi * ��ֵ * Ƶ��)^2��"); 

			else
			{
				CraftPanelIniFileHandle=fopen(CraftPanelIni_FILE_PATH,"wb");

				fprintf(CraftPanelIniFileHandle,"%f ", CraftIniLongitude);
				fprintf(CraftPanelIniFileHandle,"%f ", CraftIniLatitude);
				fprintf(CraftPanelIniFileHandle,"%f ", CraftIniAltitude);
				fprintf(CraftPanelIniFileHandle,"%f ", CraftIniForwardVelocity);
				fprintf(CraftPanelIniFileHandle,"%f ", CraftIniYaw); 		 
				fprintf(CraftPanelIniFileHandle,"%f ", CraftIniPitch);  
				fprintf(CraftPanelIniFileHandle,"%f ", CraftIniRoll);
			
				fprintf(CraftPanelIniFileHandle, "\r\n");

				fprintf(CraftPanelIniFileHandle,"%f ", CraftGyroConstDrift[0][0]);
				fprintf(CraftPanelIniFileHandle,"%f ", CraftGyroConstDrift[1][0]);
				fprintf(CraftPanelIniFileHandle,"%f ", CraftGyroConstDrift[2][0]);
				fprintf(CraftPanelIniFileHandle,"%f ", CraftGyroRandomDrift[0][0]);
				fprintf(CraftPanelIniFileHandle,"%f ", CraftGyroRandomDrift[1][0]);
				fprintf(CraftPanelIniFileHandle,"%f ", CraftGyroRandomDrift[2][0]);										   
				fprintf(CraftPanelIniFileHandle,"%f ", CraftGyroScaleFactor[0][0]);
				fprintf(CraftPanelIniFileHandle,"%f ", CraftGyroScaleFactor[1][0]);
				fprintf(CraftPanelIniFileHandle,"%f ", CraftGyroScaleFactor[2][0]);
			
				fprintf(CraftPanelIniFileHandle, "\r\n");

				fprintf(CraftPanelIniFileHandle,"%f ", CraftAccelerometerConstBias[0][0]);
				fprintf(CraftPanelIniFileHandle,"%f ", CraftAccelerometerConstBias[1][0]);
				fprintf(CraftPanelIniFileHandle,"%f ", CraftAccelerometerConstBias[2][0]);
				fprintf(CraftPanelIniFileHandle,"%f ", CraftAccelerometerRandomBias[0][0]);
				fprintf(CraftPanelIniFileHandle,"%f ", CraftAccelerometerRandomBias[1][0]);
				fprintf(CraftPanelIniFileHandle,"%f ", CraftAccelerometerRandomBias[2][0]);
				fprintf(CraftPanelIniFileHandle,"%f ", CraftAccelerometerScaleFactor[0][0]);
				fprintf(CraftPanelIniFileHandle,"%f ", CraftAccelerometerScaleFactor[1][0]);
				fprintf(CraftPanelIniFileHandle,"%f ", CraftAccelerometerScaleFactor[2][0]);

				fprintf(CraftPanelIniFileHandle,"%f ", CraftAccelerometerQuantizationFactor);
				fprintf(CraftPanelIniFileHandle,"%f ", CraftGyroQuantizationFactor);	

				fprintf(CraftPanelIniFileHandle, "\r\n");
			
				fprintf(CraftPanelIniFileHandle,"%f ", MissileMountAngle[0][0]);
				fprintf(CraftPanelIniFileHandle,"%f ", MissileMountAngle[1][0]);
				fprintf(CraftPanelIniFileHandle,"%f ", MissileMountAngle[2][0]);
				fprintf(CraftPanelIniFileHandle,"%f ", MissileMountAngleError[0][0]);
				fprintf(CraftPanelIniFileHandle,"%f ", MissileMountAngleError[1][0]);
				fprintf(CraftPanelIniFileHandle,"%f ", MissileMountAngleError[2][0]);			 

				fprintf(CraftPanelIniFileHandle,"%f ", NominalLeverArm[0][0]);
				fprintf(CraftPanelIniFileHandle,"%f ", NominalLeverArm[1][0]);
				fprintf(CraftPanelIniFileHandle,"%f ", NominalLeverArm[2][0]);
				fprintf(CraftPanelIniFileHandle,"%f ", LeverArmLengthError[0][0]);
				fprintf(CraftPanelIniFileHandle,"%f ", LeverArmLengthError[1][0]);
				fprintf(CraftPanelIniFileHandle,"%f ", LeverArmLengthError[2][0]);
			
				fprintf(CraftPanelIniFileHandle, "\r\n");

				fprintf(CraftPanelIniFileHandle,"%f ", MissileAccelerometerConstBias[0][0]);
				fprintf(CraftPanelIniFileHandle,"%f ", MissileAccelerometerConstBias[1][0]);
				fprintf(CraftPanelIniFileHandle,"%f ", MissileAccelerometerConstBias[2][0]);
				fprintf(CraftPanelIniFileHandle,"%f ", MissileAccelerometerRandomBias[0][0]);
				fprintf(CraftPanelIniFileHandle,"%f ", MissileAccelerometerRandomBias[1][0]);
				fprintf(CraftPanelIniFileHandle,"%f ", MissileAccelerometerRandomBias[2][0]);
				fprintf(CraftPanelIniFileHandle,"%f ", MissileAccelerometerScaleFactor[0][0]);
				fprintf(CraftPanelIniFileHandle,"%f ", MissileAccelerometerScaleFactor[1][0]);
				fprintf(CraftPanelIniFileHandle,"%f ", MissileAccelerometerScaleFactor[2][0]);

				fprintf(CraftPanelIniFileHandle,"%f ", RotaryAmp[0]);
				fprintf(CraftPanelIniFileHandle,"%f ", RotaryAmp[1]);
				fprintf(CraftPanelIniFileHandle,"%f ", RotaryAmp[2]);
				fprintf(CraftPanelIniFileHandle,"%f ", RotaryFre[0]);
				fprintf(CraftPanelIniFileHandle,"%f ", RotaryFre[1]);
				fprintf(CraftPanelIniFileHandle,"%f ", RotaryFre[2]);
				fprintf(CraftPanelIniFileHandle,"%f ", RotaryPha[0]);
				fprintf(CraftPanelIniFileHandle,"%f ", RotaryPha[1]);
				fprintf(CraftPanelIniFileHandle,"%f ", RotaryPha[2]);
			
				fprintf(CraftPanelIniFileHandle, "\r\n");

				fprintf(CraftPanelIniFileHandle,"%f ", MissileAccelerometerCrossCoupling[0][1]);
				fprintf(CraftPanelIniFileHandle,"%f ", MissileAccelerometerCrossCoupling[0][2]);
				fprintf(CraftPanelIniFileHandle,"%f ", MissileAccelerometerCrossCoupling[1][0]);
				fprintf(CraftPanelIniFileHandle,"%f ", MissileAccelerometerCrossCoupling[1][2]);
				fprintf(CraftPanelIniFileHandle,"%f ", MissileAccelerometerCrossCoupling[2][0]);
				fprintf(CraftPanelIniFileHandle,"%f ", MissileAccelerometerCrossCoupling[2][1]);

				fprintf(CraftPanelIniFileHandle,"%f ", MissileGyroCrossCoupling[0][1]);
				fprintf(CraftPanelIniFileHandle,"%f ", MissileGyroCrossCoupling[0][2]);
				fprintf(CraftPanelIniFileHandle,"%f ", MissileGyroCrossCoupling[1][0]);
				fprintf(CraftPanelIniFileHandle,"%f ", MissileGyroCrossCoupling[1][2]);
				fprintf(CraftPanelIniFileHandle,"%f ", MissileGyroCrossCoupling[2][0]);
				fprintf(CraftPanelIniFileHandle,"%f ", MissileGyroCrossCoupling[2][1]);

				fprintf(CraftPanelIniFileHandle,"%f ", MissileAccelerometerQuantizationFactor);
				fprintf(CraftPanelIniFileHandle,"%f ", MissileGyroQuantizationFactor);
			
				fprintf(CraftPanelIniFileHandle, "\r\n"); 
			
				fprintf(CraftPanelIniFileHandle,"%f ", CraftTraceStepSize);
				fprintf(CraftPanelIniFileHandle,"%f ", CraftNavigationStepSize);
				fprintf(CraftPanelIniFileHandle,"%f ", FcsNavigationStepSize);
				fprintf(CraftPanelIniFileHandle,"%f ", FcsOutputStepSize);

				fprintf(CraftPanelIniFileHandle,"%f ", SimulationStartTime);
				fprintf(CraftPanelIniFileHandle,"%f ", CraNavStartTime);
				fprintf(CraftPanelIniFileHandle,"%f ", CraNavEndTime);
				fprintf(CraftPanelIniFileHandle,"%f ", FcsNavStartTime);
				fprintf(CraftPanelIniFileHandle,"%f ", FcsNavEndTime);
				fprintf(CraftPanelIniFileHandle,"%f ", TransferAlignmentStartTime);
				fprintf(CraftPanelIniFileHandle,"%f ", TransferAlignmentTime);

				fprintf(CraftPanelIniFileHandle, "\r\n");  //��֤�洢���ݻ���
			
				fprintf(CraftPanelIniFileHandle,"%d ", CraftFlightStateNum);  //���ػ��켣�ļ��ĵ�һ��д�ػ��켣�ܸ���
				fprintf(CraftPanelIniFileHandle, "\r\n");						//����CraftFlightStateNum�ĳ�ֵΪ-1������������ػ��켣����Ҫ��1

				for(int i=1;i <= CraftFlightStateNum;i++)																			    
				{   																					   
					fprintf(CraftPanelIniFileHandle,"%d ", i);
					fprintf(CraftPanelIniFileHandle,"%d ", CraftFlightState[i]); 				 
					fprintf(CraftPanelIniFileHandle,"%f ", EachCraftTraceTime[i]);
					fprintf(CraftPanelIniFileHandle,"%f ", CraftForwardAccelerationExpect[i]); 
					fprintf(CraftPanelIniFileHandle,"%f ", CraftAttitudeChange[0][i]); 
					fprintf(CraftPanelIniFileHandle,"%f ", CraftAttitudeChange[1][i]);
					fprintf(CraftPanelIniFileHandle,"%f ", CraftAttitudeChange[2][i]);
				//	if(i<CraftFlightStateNum)
						fprintf(CraftPanelIniFileHandle, "\r\n");	
				}
		
				//��ȡ����·������
				fprintf(CraftPanelIniFileHandle,"%s", TrueDataFilePath); 
				
				fclose(CraftPanelIniFileHandle);  
				DiscardPanel(CraftSetPanelHandle); 

				DisplayPanel (MainPanelHandle);  
				SetPanelAttribute (MainPanelHandle, ATTR_WINDOW_ZOOM, VAL_MAXIMIZE);

				break;			
			}
	}
	return 0;
}

//�رհ�ť�ص�����
int CVICALLBACK CraQuitCallback (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:
			DiscardPanel(CraftSetPanelHandle) ;
			DisplayPanel (MainPanelHandle);   
			SetPanelAttribute (MainPanelHandle, ATTR_WINDOW_ZOOM, VAL_MAXIMIZE);  
			break;
	}
	return 0;
}

//��λ��ť�ص�����
int CVICALLBACK CraftTraceParameterZeroCallback (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)	
{
	switch (event)
	{
		case EVENT_COMMIT:
			CraftNewRow=0;
			CraftFlightStateNum=0;
			DiscardPanel(CraftSetPanelHandle);
			CraftSetPanelHandle=LoadPanel(MainPanelHandle, "CRAFT_PANEL.uir",CraftPANEL) ;
			InstallPopup(CraftSetPanelHandle); 
			break;
	}
	return 0;
}

//�켣�μ�ƽ���Ƿ���ѡ��ص�����
int CVICALLBACK CraftSmoothCallback (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:
				   SmoothTimePercent=0;
			break;
	}
	return 0;
}

//�ػ�����������ť�ص�����
int CVICALLBACK CraPanelSavePraCallback (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{   
	char TempFilePath[260] = {0}; 
	switch (event)
	{
		case EVENT_COMMIT:
			 
			 GetProjectDir (TempFilePath);
			 strcat(TempFilePath, "\\�ػ�����");
			 stateCraParFileSelectPopup=FileSelectPopup (TempFilePath,"*.par","*.par", 
				 "�����ʼ��������",VAL_OK_BUTTON,0,0,1,0,CraftParFilePath);   // ѡ�񱣴�������ļ���resultΪ�洢�ѱ����ļ���·��
             if (stateCraParFileSelectPopup!=0) 
			 {
				 WriteCraftParameterToFile(CraftParFileHandle, CraftParFilePath);
			 }
			break;
	}
	return 0;
}

//�ػ��������밴ť�ص�����   
int CVICALLBACK CraPanelReadParCallback (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{   
	char TempFilePath[260] = {0};
	switch (event)
	{
		case EVENT_COMMIT: 
			 
			 GetProjectDir (TempFilePath);
			 strcat(TempFilePath, "\\�ػ�����");
			 stateCraParFileSelectPopup=FileSelectPopup (TempFilePath, "*.par", "*.par", 
				 "��ȡ�ػ���ʼ����",VAL_OK_BUTTON,0,0,1,0,CraftParFilePath);   // ѡ�񱣴�������ļ���resultΪ�洢�ѱ����ļ���·��
			 
			 if( (stateCraParFileSelectPopup==1)||(stateCraParFileSelectPopup==2) )
			 {
				 ReadCraftParameterToPanel(CraftParFileHandle,CraftParFilePath); 
				 SetCraftParameterToPanel(); 
			 }
			 break;
	}
	return 0;
}

//�ػ����й켣ȷ�ϰ�ť�ص�����    
int CVICALLBACK CraftTraceProgrammingCallback (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{   
	int CT=0;

	
	switch (event)
	{
		case EVENT_COMMIT://�����ػ����й켣�滮ȷ�ϡ���ť��Ķ�����Ϊѭ��ִ�У�

			 CraftFlightStateNum++;

			 GetCtrlVal(CraftSetPanelHandle,CraftPANEL_RINGCraftTrace,&CraftFlightState[CraftFlightStateNum]);//ע��ؼ��е�ֵ����������Ҫ��ֵ�ı�����ֵΪ����
			 GetCtrlVal(CraftSetPanelHandle,CraftPANEL_NUMERICCraftTime,&EachCraftTraceTime[CraftFlightStateNum]); //ÿ�ι켣�ػ�������ʱ�� 			
			 GetCtrlVal(CraftSetPanelHandle,CraftPANEL_NUMERICCraftIniAcc,&CraftForwardAccelerationExpect[CraftFlightStateNum]); //�ػ���ǰ����ٶ�
			 GetCtrlVal(CraftSetPanelHandle,CraftPANEL_NUMERICCraftAziCha,&CraftAttitudeChange[0][CraftFlightStateNum]); //�ػ�����Ǳ仯��
			 GetCtrlVal(CraftSetPanelHandle,CraftPANEL_NUMERICCraftPitCha,&CraftAttitudeChange[1][CraftFlightStateNum]); //�ػ������Ǳ仯��
			 GetCtrlVal(CraftSetPanelHandle,CraftPANEL_NUMERICCraftRolCha,&CraftAttitudeChange[2][CraftFlightStateNum]); //�ػ�����Ǳ仯��

			 PanAcc=PanAcc+CraftForwardAccelerationExpect[CraftFlightStateNum];
			 
			 if(CraftFlightStateNum==1 && (CraftFlightState[CraftFlightStateNum]==3) && abs(CraftIniForwardVelocity)<=0.00001 && PanAcc<=0.00001)
			 {
				 MessagePopup ("�������ô���", "Э��ת��켣����ʼ�ٶȲ���Ϊ0��");
				 CraftFlightStateNum--;
			 }
			 else if (abs(CraftIniForwardVelocity)<=0.00001 && PanAcc<=0.00001 && (CraftFlightState[CraftFlightStateNum]==3))
			 {
				 MessagePopup ("�������ô���", "��Э��ת�俪ʼʱ�����ػ��ٶ�����Ϊ�㣡");
				 CraftFlightStateNum--;
			 }
			 else if(abs(CraftAttitudeChange[1][CraftFlightStateNum])>=90 )
			 {
				 MessagePopup ("�������ô���", "һ�θ����˶�ʱ���������𳬹�90�ȣ�");
				 CraftFlightStateNum--;	
			 }
			 else
			 {
				 CraftNewRow++;

				 InsertTableRows(CraftSetPanelHandle,CraftPANEL_TABLE,CraftNewRow,1,VAL_USE_MASTER_CELL_TYPE);//��켣�滮Table���м����µ�һ��
				 //�����е�CraftNewRow�Ǵ�1��ʼ�������ػ��켣�����У��������Ǵ�0��ʼ���������ｫCraftNewRow��1
				 //���ļ��ͱ����йص�CraftNewRow�Ǵ�0��ʼ���������������йص�CraftNewRow�Ǵ�1��ʼ
			 
				 if (CraftFlightState[CraftNewRow]==CraftDengJiaoFeiXing)       //�ػ��Ƚ��˶�����
			     {
					sprintf(&CraftChinese[CraftFlightStateNum], "%s", "�ػ��Ƚ��˶�����"); //���ַ����������ĺ���������֪������
				 }
			     else if (CraftFlightState[CraftNewRow]==CraftFuYangYunDong) //�ػ������˶�����
			     {
				   sprintf(&CraftChinese[CraftFlightStateNum], "%s", "�ػ������˶�����");
				 }
			 	 else if (CraftFlightState[CraftNewRow]==CraftFuYangGaiPing) //�ػ�������ƽ����
			     {
				   sprintf(&CraftChinese[CraftFlightStateNum], "%s", "�ػ�������ƽ����");
				 }
			  	 else if (CraftFlightState[CraftNewRow]==CraftXieTiaoZhuanWan)  //�ػ�Э��ת�����
			     {
				   sprintf(&CraftChinese[CraftFlightStateNum], "%s", "�ػ�Э��ת�����");
				 }
			  	 else if (CraftFlightState[CraftNewRow]==CraftZhuanWanXunHang)  //�ػ�ת��Ѳ������
			     {
				   sprintf(&CraftChinese[CraftFlightStateNum], "%s", "�ػ�ת��Ѳ������");
				 }
		 	 	 else if (CraftFlightState[CraftNewRow]==CraftZhuanWanGaiPing)  //�ػ�ת���ƽ����
			     {
				   sprintf(&CraftChinese[CraftFlightStateNum], "%s", "�ػ�ת���ƽ����");
				 }
		 	  	 else if (CraftFlightState[CraftNewRow]==CraftYiBanHengGun)  //�ػ�һ��������
			     {
				   sprintf(&CraftChinese[CraftFlightStateNum], "%s", "�ػ�һ��������");
				 }
			  	 else if (CraftFlightState[CraftNewRow]==CraftYiBanZhuanWan)   //�ػ�һ��ת�����
			     {
				   sprintf(&CraftChinese[CraftFlightStateNum], "%s", "�ػ�һ��ת�����");
				 }
				 SetTableCellVal(CraftSetPanelHandle,CraftPANEL_TABLE,MakePoint(1,CraftNewRow),&CraftChinese[CraftFlightStateNum]);
				 SetTableCellVal(CraftSetPanelHandle,CraftPANEL_TABLE,MakePoint(2,CraftNewRow),EachCraftTraceTime[CraftFlightStateNum]);
				 SetTableCellVal(CraftSetPanelHandle,CraftPANEL_TABLE,MakePoint(3,CraftNewRow),CraftForwardAccelerationExpect[CraftFlightStateNum]);
				 SetTableCellVal(CraftSetPanelHandle,CraftPANEL_TABLE,MakePoint(4,CraftNewRow),CraftAttitudeChange[0][CraftFlightStateNum]);
				 SetTableCellVal(CraftSetPanelHandle,CraftPANEL_TABLE,MakePoint(5,CraftNewRow),CraftAttitudeChange[1][CraftFlightStateNum]);
				 SetTableCellVal(CraftSetPanelHandle,CraftPANEL_TABLE,MakePoint(6,CraftNewRow),CraftAttitudeChange[2][CraftFlightStateNum]);	 
		 	 }
			break;
	}
	return 0;
}

//�ػ����й켣�����ť�ص����� 
int CVICALLBACK CraftTraceDeleteCallback (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{   
	switch (event)
	{
		case EVENT_COMMIT:
			 DeleteTableRows(CraftSetPanelHandle,CraftPANEL_TABLE,1,-1);
			 CraftNewRow=0; //�������������CraftNewRow���㣬��ɾ��Table�е�����ʱ�ᱨ����
			 CraftFlightStateNum=0;
			
			break;
	}
	return 0;
}
  
//�ػ��ֶη��з�ʽѡ�������˵��ص�����
int CVICALLBACK CraftTraceChooseCallback (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{   
	int Ring_CraftTrace;   //�ػ��켣��ͬ���������ʶ��0-7��8�ַ���״̬
	Ring_CraftTrace=0;
	
	switch (event)
	{
		case EVENT_COMMIT:
		  //��ȡRing�ؼ�������ֵ�������ػ��켣״̬�Ĳ�ͬ��Ring_CraftTraceȡ��ͬ��ֵ��
		  //��������Ҫ��ȡ����Tab�ľ���󣬲���ִ�����³�������Ҫ�Ȱ���Tab��ȷ���������Ring�ؼ�����ѡ��
          GetCtrlVal (CraftSetPanelHandle, CraftPANEL_RINGCraftTrace, &Ring_CraftTrace);

          //����TABCraftҳ���пؼ�NUMERICCraftAziCha��NUMERICCraftPitCha��NUMERICCraftRolCha����Ч����
		  //^^^^^^^��Ҫ��ʾ�Ŀؼ�����Ϊ1�����ɼ�����ڼ����ͬʱ������Ҫ���ýǶȱ仯�ؼ���ֵ���㣬��ؼ��䰵^^^^^^^^//
		  if (Ring_CraftTrace==CraftDengJiaoFeiXing)       //�ػ��Ƚ��˶�����
		     {   				 
				 SetCtrlAttribute (CraftSetPanelHandle, CraftPANEL_NUMERICCraftTime, ATTR_DIMMED, 0);
	             SetCtrlAttribute (CraftSetPanelHandle, CraftPANEL_NUMERICCraftIniAcc, ATTR_DIMMED, 0);
				 SetCtrlAttribute (CraftSetPanelHandle, CraftPANEL_NUMERICCraftAziCha, ATTR_DIMMED, 1);
			     SetCtrlAttribute (CraftSetPanelHandle, CraftPANEL_NUMERICCraftPitCha, ATTR_DIMMED, 1);
			     SetCtrlAttribute (CraftSetPanelHandle, CraftPANEL_NUMERICCraftRolCha, ATTR_DIMMED, 1);

			     SetCtrlVal (CraftSetPanelHandle, CraftPANEL_NUMERICCraftTime, 0.0);
			     SetCtrlVal (CraftSetPanelHandle, CraftPANEL_NUMERICCraftIniAcc, 0.0);
			     SetCtrlVal (CraftSetPanelHandle, CraftPANEL_NUMERICCraftAziCha, 0.0);
			     SetCtrlVal (CraftSetPanelHandle, CraftPANEL_NUMERICCraftPitCha, 0.0);
			     SetCtrlVal (CraftSetPanelHandle, CraftPANEL_NUMERICCraftRolCha, 0.0);
			 }
		  else if (Ring_CraftTrace==CraftFuYangYunDong)    //�ػ������˶�����
		     {   				 
				 SetCtrlAttribute (CraftSetPanelHandle, CraftPANEL_NUMERICCraftTime, ATTR_DIMMED, 0);
	             SetCtrlAttribute (CraftSetPanelHandle, CraftPANEL_NUMERICCraftIniAcc, ATTR_DIMMED, 0);
				 SetCtrlAttribute (CraftSetPanelHandle, CraftPANEL_NUMERICCraftAziCha, ATTR_DIMMED, 1);
				 SetCtrlAttribute (CraftSetPanelHandle, CraftPANEL_NUMERICCraftPitCha, ATTR_DIMMED, 0);
			     SetCtrlAttribute (CraftSetPanelHandle, CraftPANEL_NUMERICCraftRolCha, ATTR_DIMMED, 1);
				 
			     SetCtrlVal (CraftSetPanelHandle, CraftPANEL_NUMERICCraftTime, 0.0);
			     SetCtrlVal (CraftSetPanelHandle, CraftPANEL_NUMERICCraftIniAcc, 0.0);				 
				 SetCtrlVal (CraftSetPanelHandle, CraftPANEL_NUMERICCraftAziCha, 0.0);
			     SetCtrlVal (CraftSetPanelHandle, CraftPANEL_NUMERICCraftPitCha, 0.0);
			     SetCtrlVal (CraftSetPanelHandle, CraftPANEL_NUMERICCraftRolCha, 0.0);
			 }
		  else if (Ring_CraftTrace==CraftFuYangGaiPing)    //�ػ�������ƽ����
		     {   				 
				 SetCtrlAttribute (CraftSetPanelHandle, CraftPANEL_NUMERICCraftTime, ATTR_DIMMED, 0);
	             SetCtrlAttribute (CraftSetPanelHandle, CraftPANEL_NUMERICCraftIniAcc, ATTR_DIMMED, 0);
				 SetCtrlAttribute (CraftSetPanelHandle, CraftPANEL_NUMERICCraftAziCha, ATTR_DIMMED, 1);
				 SetCtrlAttribute (CraftSetPanelHandle, CraftPANEL_NUMERICCraftPitCha, ATTR_DIMMED, 1);
			     SetCtrlAttribute (CraftSetPanelHandle, CraftPANEL_NUMERICCraftRolCha, ATTR_DIMMED, 1);
				 
			     SetCtrlVal (CraftSetPanelHandle, CraftPANEL_NUMERICCraftTime, 0.0);
			     SetCtrlVal (CraftSetPanelHandle, CraftPANEL_NUMERICCraftIniAcc, 0.0);				 
				 SetCtrlVal (CraftSetPanelHandle, CraftPANEL_NUMERICCraftAziCha, 0.0);
				 SetCtrlVal (CraftSetPanelHandle, CraftPANEL_NUMERICCraftPitCha, 0.0);
			     SetCtrlVal (CraftSetPanelHandle, CraftPANEL_NUMERICCraftRolCha, 0.0);
			 }
		  else if (Ring_CraftTrace==CraftXieTiaoZhuanWan)  //�ػ�Э��ת�����
		     {   
			//	 if(abs(CraftIniForwardVelocity)<=0.00001 &&  )

				 
				 
				 SetCtrlAttribute (CraftSetPanelHandle, CraftPANEL_NUMERICCraftTime, ATTR_DIMMED, 0);
	             SetCtrlAttribute (CraftSetPanelHandle, CraftPANEL_NUMERICCraftIniAcc, ATTR_DIMMED, 0);
				 SetCtrlAttribute (CraftSetPanelHandle, CraftPANEL_NUMERICCraftAziCha, ATTR_DIMMED, 1);
				 SetCtrlAttribute (CraftSetPanelHandle, CraftPANEL_NUMERICCraftPitCha, ATTR_DIMMED, 1);
				 SetCtrlAttribute (CraftSetPanelHandle, CraftPANEL_NUMERICCraftRolCha, ATTR_DIMMED, 0);
				 
			     SetCtrlVal (CraftSetPanelHandle, CraftPANEL_NUMERICCraftTime, 0.0);
			     SetCtrlVal (CraftSetPanelHandle, CraftPANEL_NUMERICCraftIniAcc, 0.0);				 
				 SetCtrlVal (CraftSetPanelHandle, CraftPANEL_NUMERICCraftAziCha, 0.0);
			     SetCtrlVal (CraftSetPanelHandle, CraftPANEL_NUMERICCraftPitCha, 0.0);
			     SetCtrlVal (CraftSetPanelHandle, CraftPANEL_NUMERICCraftRolCha, 0.0);
			 }
		  else if (Ring_CraftTrace==CraftZhuanWanXunHang)  //�ػ�ת��Ѳ������
		     {   				
				 SetCtrlAttribute (CraftSetPanelHandle, CraftPANEL_NUMERICCraftTime, ATTR_DIMMED, 0);
	             SetCtrlAttribute (CraftSetPanelHandle, CraftPANEL_NUMERICCraftIniAcc, ATTR_DIMMED, 0);
				 SetCtrlAttribute (CraftSetPanelHandle, CraftPANEL_NUMERICCraftAziCha, ATTR_DIMMED, 1);
				 SetCtrlAttribute (CraftSetPanelHandle, CraftPANEL_NUMERICCraftPitCha, ATTR_DIMMED, 1);
				 SetCtrlAttribute (CraftSetPanelHandle, CraftPANEL_NUMERICCraftRolCha, ATTR_DIMMED, 1);
				 
			     SetCtrlVal (CraftSetPanelHandle, CraftPANEL_NUMERICCraftTime, 0.0);
			     SetCtrlVal (CraftSetPanelHandle, CraftPANEL_NUMERICCraftIniAcc, 0.0);				 
				 SetCtrlVal (CraftSetPanelHandle, CraftPANEL_NUMERICCraftAziCha, 0.0);
			     SetCtrlVal (CraftSetPanelHandle, CraftPANEL_NUMERICCraftPitCha, 0.0);
			     SetCtrlVal (CraftSetPanelHandle, CraftPANEL_NUMERICCraftRolCha, 0.0);
			 }
		  else if (Ring_CraftTrace==CraftZhuanWanGaiPing)  //�ػ�ת���ƽ����
		     {   				 
				 SetCtrlAttribute (CraftSetPanelHandle, CraftPANEL_NUMERICCraftTime, ATTR_DIMMED, 0);
	             SetCtrlAttribute (CraftSetPanelHandle, CraftPANEL_NUMERICCraftIniAcc, ATTR_DIMMED, 0);
				 SetCtrlAttribute (CraftSetPanelHandle, CraftPANEL_NUMERICCraftAziCha, ATTR_DIMMED, 1);
				 SetCtrlAttribute (CraftSetPanelHandle, CraftPANEL_NUMERICCraftPitCha, ATTR_DIMMED, 1);
				 SetCtrlAttribute (CraftSetPanelHandle, CraftPANEL_NUMERICCraftRolCha, ATTR_DIMMED, 1);
				 
			     SetCtrlVal (CraftSetPanelHandle, CraftPANEL_NUMERICCraftTime, 0.0);
			     SetCtrlVal (CraftSetPanelHandle, CraftPANEL_NUMERICCraftIniAcc, 0.0);				 
				 SetCtrlVal (CraftSetPanelHandle, CraftPANEL_NUMERICCraftAziCha, 0.0);
			     SetCtrlVal (CraftSetPanelHandle, CraftPANEL_NUMERICCraftPitCha, 0.0);
			     SetCtrlVal (CraftSetPanelHandle, CraftPANEL_NUMERICCraftRolCha, 0.0);
			 }
		  else if (Ring_CraftTrace==CraftYiBanHengGun)     //�ػ�һ��������
		     {   				 
				 SetCtrlAttribute (CraftSetPanelHandle, CraftPANEL_NUMERICCraftTime, ATTR_DIMMED, 0);
	             SetCtrlAttribute (CraftSetPanelHandle, CraftPANEL_NUMERICCraftIniAcc, ATTR_DIMMED, 0);
				 SetCtrlAttribute (CraftSetPanelHandle, CraftPANEL_NUMERICCraftAziCha, ATTR_DIMMED, 1);
				 SetCtrlAttribute (CraftSetPanelHandle, CraftPANEL_NUMERICCraftPitCha, ATTR_DIMMED, 1);
				 SetCtrlAttribute (CraftSetPanelHandle, CraftPANEL_NUMERICCraftRolCha, ATTR_DIMMED, 0);
				 
			     SetCtrlVal (CraftSetPanelHandle, CraftPANEL_NUMERICCraftTime, 0.0);
			     SetCtrlVal (CraftSetPanelHandle, CraftPANEL_NUMERICCraftIniAcc, 0.0);				 
				 SetCtrlVal (CraftSetPanelHandle, CraftPANEL_NUMERICCraftAziCha, 0.0);
			     SetCtrlVal (CraftSetPanelHandle, CraftPANEL_NUMERICCraftPitCha, 0.0);
			     SetCtrlVal (CraftSetPanelHandle, CraftPANEL_NUMERICCraftRolCha, 0.0);
			 }
		  else if (Ring_CraftTrace==CraftYiBanZhuanWan)    //�ػ�һ��ת�����
			 
		     {
				 SetCtrlAttribute (CraftSetPanelHandle, CraftPANEL_NUMERICCraftTime, ATTR_DIMMED, 0);
	             SetCtrlAttribute (CraftSetPanelHandle, CraftPANEL_NUMERICCraftIniAcc, ATTR_DIMMED, 0);		  
				 SetCtrlAttribute (CraftSetPanelHandle, CraftPANEL_NUMERICCraftAziCha, ATTR_DIMMED, 0);
				 SetCtrlAttribute (CraftSetPanelHandle, CraftPANEL_NUMERICCraftPitCha, ATTR_DIMMED, 1);
				 SetCtrlAttribute (CraftSetPanelHandle, CraftPANEL_NUMERICCraftRolCha, ATTR_DIMMED, 1);
				 
			     SetCtrlVal (CraftSetPanelHandle, CraftPANEL_NUMERICCraftTime, 0.0);
			     SetCtrlVal (CraftSetPanelHandle, CraftPANEL_NUMERICCraftIniAcc, 0.0);				 
				 SetCtrlVal (CraftSetPanelHandle, CraftPANEL_NUMERICCraftAziCha, 0.0);
			     SetCtrlVal (CraftSetPanelHandle, CraftPANEL_NUMERICCraftPitCha, 0.0);
			     SetCtrlVal (CraftSetPanelHandle, CraftPANEL_NUMERICCraftRolCha, 0.0);
			 }
			break;
	}
	return 0;
}

//�ػ��ֶι켣������ť�ص�����
int CVICALLBACK CraftTraceParSaveCallback (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{   
	char TempFilePath[260] = {0};
	switch (event)
	{
		case EVENT_COMMIT:
			 
			 GetProjectDir (TempFilePath);
			 strcat(TempFilePath, "\\�ػ��켣");
			 stateCraTraSetFileSelectPopup=FileSelectPopup (TempFilePath, "*.tra", "*.txt;*.par;*.tra", 
				 "�����ʼ��������",  VAL_OK_BUTTON , 0, 0,1, 0, CraftTraceSetFilePath);   //ѡ�񱣴�������ļ���resultΪ�洢�ѱ����ļ���·��
			 if (stateCraTraSetFileSelectPopup==0)
			 {
				 
			 }
			 else 
			 {
				 WriteCraftTraceToFile(CraftDataFileHandle, CraftTraceSetFilePath);
			 }
			break;
	}
	return 0;
}

//�ػ��ֶι켣���밴ť�ص����� 
int CVICALLBACK CraftTraceParReadCallback (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{   
	char TempFilePath[260] = {0};  
	switch (event)
	{
		case EVENT_COMMIT:
			 CraftNewRow=0; 
			 
			 GetProjectDir (TempFilePath);
			 strcat(TempFilePath, "\\�ػ��켣");
			 stateCraTraSetFileSelectPopup=FileSelectPopup (TempFilePath, "*.tra", "*.txt;*.par;*.tra", 
				 "��ȡ�ػ��켣��ʼ��������",  VAL_OK_BUTTON , 0, 0,1, 0, CraftTraceSetFilePath);   //ѡ�񱣴�������ļ���resultΪ�洢�ѱ����ļ���·��
			 if (stateCraTraSetFileSelectPopup != 0)
			 {
				 ReadCraftTraceToPanel(CraftTraceSetFileHandle, CraftTraceSetFilePath); 
			 }
			break;
	}
	return 0;
}

//������ʵ�켣��ȡ��ť  ��ȡʵ�ʲ����Ĺ����������  
int CVICALLBACK CraftRealTraceRdCallback (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{   
	int status;   
	switch (event)
	{
		case EVENT_COMMIT:
										  
			status = TrueDataFileSelectPopup = FileSelectPopup ("c:\\Documents and Settings\\Administrator\\����", "*.txt", "*.txt", 
									"��ȡ�̿ص�����",  VAL_OK_BUTTON , 0, 0, 1, 0, TrueDataFilePath); 
			if(status != 0)
				SetCtrlVal (CraftSetPanelHandle, CraftPANEL_TrueDataPathName, TrueDataFilePath);

			break;
	}
	return 0;
}

//ʧ׼�Ǽ���
void CalcAtt_Error(void)
{
	double TempAtt[3][1];
	double TempMountA[3][1];
	double Temp_Angle_Err[3][1];
	double Temp_AE_OUT[3][1];
	
	double cBp[3][3] = {0};
	double cbB[3][3] = {0};
	
	double cbi[3][3];
	
	double pi = 3.141592653589793;
	
	TempAtt[0][0] = -CraftIniYaw*pi/180;
	TempAtt[1][0] = CraftIniPitch*pi/180; 
	TempAtt[2][0] = CraftIniRoll*pi/180; 

	TempMountA[0][0] = MissileMountAngle[0][0]*pi/180;
	TempMountA[1][0] = MissileMountAngle[1][0]*pi/180; 
	TempMountA[2][0] = MissileMountAngle[2][0]*pi/180; 
	
	Calcxx(TempAtt, cBp); 
	Calcxx(TempMountA, cbB);
	
	MatMulMat(cBp, cbB, cbi);   
	
	Temp_AE_OUT[0][0] = MissileMountAngleError[2][0];
	Temp_AE_OUT[1][0] = MissileMountAngleError[0][0]; 
	Temp_AE_OUT[2][0] = MissileMountAngleError[1][0]; 
	
	MatMulVec(cbi, Temp_AE_OUT, Temp_Angle_Err);

	SetCtrlVal (MainPanelHandle, MainPanel_Yaw_Error, -Temp_Angle_Err[1][0]); 
	SetCtrlVal (MainPanelHandle, MainPanel_Pitch_Error, -Temp_Angle_Err[2][0]);  
	SetCtrlVal (MainPanelHandle, MainPanel_Roll_Error, -Temp_Angle_Err[0][0]);  
}

void WriteCraftParameterToFile(FILE *FileHandle, char *FilePath)
{
	FileHandle=fopen(FilePath,"wb");
	
	fprintf(FileHandle,"%f ", CraftIniLongitude);
	fprintf(FileHandle,"%f ", CraftIniLatitude);
	fprintf(FileHandle,"%f ", CraftIniAltitude);
	fprintf(FileHandle,"%f ", CraftIniForwardVelocity);

	fprintf(FileHandle,"%f ", CraftIniYaw); 		 
	fprintf(FileHandle,"%f ", CraftIniPitch);  
	fprintf(FileHandle,"%f ", CraftIniRoll);
	
	fprintf(FileHandle,"%f ", CraftGyroConstDrift[0][0]);
	fprintf(FileHandle,"%f ", CraftGyroConstDrift[1][0]);
	fprintf(FileHandle,"%f ", CraftGyroConstDrift[2][0]);
	fprintf(FileHandle,"%f ", CraftGyroRandomDrift[0][0]);
	fprintf(FileHandle,"%f ", CraftGyroRandomDrift[1][0]);
	fprintf(FileHandle,"%f ", CraftGyroRandomDrift[2][0]);										   
	fprintf(FileHandle,"%f ", CraftGyroScaleFactor[0][0]);
	fprintf(FileHandle,"%f ", CraftGyroScaleFactor[1][0]);
	fprintf(FileHandle,"%f ", CraftGyroScaleFactor[2][0]);
	
	fprintf(FileHandle,"%f ", CraftAccelerometerConstBias[0][0]);
	fprintf(FileHandle,"%f ", CraftAccelerometerConstBias[1][0]);
	fprintf(FileHandle,"%f ", CraftAccelerometerConstBias[2][0]);
	fprintf(FileHandle,"%f ", CraftAccelerometerRandomBias[0][0]);
	fprintf(FileHandle,"%f ", CraftAccelerometerRandomBias[1][0]);
	fprintf(FileHandle,"%f ", CraftAccelerometerRandomBias[2][0]);
	fprintf(FileHandle,"%f ", CraftAccelerometerScaleFactor[0][0]);
	fprintf(FileHandle,"%f ", CraftAccelerometerScaleFactor[1][0]);
	fprintf(FileHandle,"%f ", CraftAccelerometerScaleFactor[2][0]);
	
	fprintf(FileHandle,"%f ", CraftAccelerometerQuantizationFactor);
	fprintf(FileHandle,"%f ", CraftGyroQuantizationFactor);	
	
	fprintf(FileHandle,"%f ", MissileMountAngle[0][0]);
	fprintf(FileHandle,"%f ", MissileMountAngle[1][0]);
	fprintf(FileHandle,"%f ", MissileMountAngle[2][0]);
	fprintf(FileHandle,"%f ", MissileMountAngleError[0][0]);
	fprintf(FileHandle,"%f ", MissileMountAngleError[1][0]);
	fprintf(FileHandle,"%f ", MissileMountAngleError[2][0]);			 
	
	fprintf(FileHandle,"%f ", NominalLeverArm[0][0]);
	fprintf(FileHandle,"%f ", NominalLeverArm[1][0]);
	fprintf(FileHandle,"%f ", NominalLeverArm[2][0]);
	fprintf(FileHandle,"%f ", LeverArmLengthError[0][0]);
	fprintf(FileHandle,"%f ", LeverArmLengthError[1][0]);
	fprintf(FileHandle,"%f ", LeverArmLengthError[2][0]);
	
	fprintf(FileHandle,"%f ", MissileAccelerometerConstBias[0][0]);
	fprintf(FileHandle,"%f ", MissileAccelerometerConstBias[1][0]);
	fprintf(FileHandle,"%f ", MissileAccelerometerConstBias[2][0]);
	fprintf(FileHandle,"%f ", MissileAccelerometerRandomBias[0][0]);
	fprintf(FileHandle,"%f ", MissileAccelerometerRandomBias[1][0]);
	fprintf(FileHandle,"%f ", MissileAccelerometerRandomBias[2][0]);
	fprintf(FileHandle,"%f ", MissileAccelerometerScaleFactor[0][0]);
	fprintf(FileHandle,"%f ", MissileAccelerometerScaleFactor[1][0]);
	fprintf(FileHandle,"%f ", MissileAccelerometerScaleFactor[2][0]);
	
	fprintf(FileHandle,"%f ", RotaryAmp[0]);
	fprintf(FileHandle,"%f ", RotaryAmp[1]);
	fprintf(FileHandle,"%f ", RotaryAmp[2]);
	fprintf(FileHandle,"%f ", RotaryFre[0]);
	fprintf(FileHandle,"%f ", RotaryFre[1]);
	fprintf(FileHandle,"%f ", RotaryFre[2]);
	fprintf(FileHandle,"%f ", RotaryPha[0]);
	fprintf(FileHandle,"%f ", RotaryPha[1]);
	fprintf(FileHandle,"%f ", RotaryPha[2]);
	
	fprintf(FileHandle,"%f ", MissileAccelerometerCrossCoupling[0][1]);
	fprintf(FileHandle,"%f ", MissileAccelerometerCrossCoupling[0][2]);
	fprintf(FileHandle,"%f ", MissileAccelerometerCrossCoupling[1][0]);
	fprintf(FileHandle,"%f ", MissileAccelerometerCrossCoupling[1][2]);
	fprintf(FileHandle,"%f ", MissileAccelerometerCrossCoupling[2][0]);
	fprintf(FileHandle,"%f ", MissileAccelerometerCrossCoupling[2][1]);
	
	fprintf(FileHandle,"%f ", MissileGyroCrossCoupling[0][1]);
	fprintf(FileHandle,"%f ", MissileGyroCrossCoupling[0][2]);
	fprintf(FileHandle,"%f ", MissileGyroCrossCoupling[1][0]);
	fprintf(FileHandle,"%f ", MissileGyroCrossCoupling[1][2]);
	fprintf(FileHandle,"%f ", MissileGyroCrossCoupling[2][0]);
	fprintf(FileHandle,"%f ", MissileGyroCrossCoupling[2][1]);
	
	fprintf(FileHandle,"%f ", MissileAccelerometerQuantizationFactor);
	fprintf(FileHandle,"%f ", MissileGyroQuantizationFactor);
	
	fprintf(FileHandle,"%f ", CraftTraceStepSize);
	fprintf(FileHandle,"%f ", CraftNavigationStepSize);
	fprintf(FileHandle,"%f ", FcsNavigationStepSize);
	fprintf(FileHandle,"%f ", FcsOutputStepSize);
	
	fprintf(FileHandle,"%f ", SimulationStartTime);
	fprintf(FileHandle,"%f ", CraNavStartTime);
	fprintf(FileHandle,"%f ", CraNavEndTime);
	fprintf(FileHandle,"%f ", FcsNavStartTime);
	fprintf(FileHandle,"%f ", FcsNavEndTime);
	fprintf(FileHandle,"%f ", TransferAlignmentStartTime);
	fprintf(FileHandle,"%f ", TransferAlignmentTime);
	
	fprintf(FileHandle, "\r\n");  //��֤�洢���ݻ��� 	  */
	fclose(FileHandle);
}

void ReadCraftParameterToPanel(FILE *FileHandle, char *FilePath) 
{
	 FileHandle=fopen(FilePath,"r");
	 
	 fscanf(FileHandle,"%lf", &CraftIniLongitude); 
	 fscanf(FileHandle,"%lf", &CraftIniLatitude); 
	 fscanf(FileHandle,"%lf", &CraftIniAltitude); 
	 fscanf(FileHandle,"%lf", &CraftIniForwardVelocity); 
 	 
	 fscanf(FileHandle,"%lf", &CraftIniYaw);
	 fscanf(FileHandle,"%lf", &CraftIniPitch);			  
	 fscanf(FileHandle,"%lf", &CraftIniRoll);
	 
	 fscanf(FileHandle,"%lf", &CraftGyroConstDrift[0][0]); 
	 fscanf(FileHandle,"%lf", &CraftGyroConstDrift[1][0]); 
	 fscanf(FileHandle,"%lf", &CraftGyroConstDrift[2][0]); 
	 fscanf(FileHandle,"%lf", &CraftGyroRandomDrift[0][0]); 
	 fscanf(FileHandle,"%lf", &CraftGyroRandomDrift[1][0]); 
	 fscanf(FileHandle,"%lf", &CraftGyroRandomDrift[2][0]); 
	 fscanf(FileHandle,"%lf", &CraftGyroScaleFactor[0][0]); 
	 fscanf(FileHandle,"%lf", &CraftGyroScaleFactor[1][0]); 
	 fscanf(FileHandle,"%lf", &CraftGyroScaleFactor[2][0]); 
	 
	 fscanf(FileHandle,"%lf", &CraftAccelerometerConstBias[0][0]);  
	 fscanf(FileHandle,"%lf", &CraftAccelerometerConstBias[1][0]);   
	 fscanf(FileHandle,"%lf", &CraftAccelerometerConstBias[2][0]);   
	 fscanf(FileHandle,"%lf", &CraftAccelerometerRandomBias[0][0]);  
	 fscanf(FileHandle,"%lf", &CraftAccelerometerRandomBias[1][0]);  
	 fscanf(FileHandle,"%lf", &CraftAccelerometerRandomBias[2][0]);  
	 fscanf(FileHandle,"%lf", &CraftAccelerometerScaleFactor[0][0]); 
	 fscanf(FileHandle,"%lf", &CraftAccelerometerScaleFactor[1][0]); 
	 fscanf(FileHandle,"%lf", &CraftAccelerometerScaleFactor[2][0]); 
	 
	 fscanf(FileHandle,"%lf", &CraftAccelerometerQuantizationFactor);
	 fscanf(FileHandle,"%lf", &CraftGyroQuantizationFactor);

	 
	 fscanf(FileHandle,"%lf", &MissileMountAngle[0][0]);      
	 fscanf(FileHandle,"%lf", &MissileMountAngle[1][0]);      
	 fscanf(FileHandle,"%lf", &MissileMountAngle[2][0]);      
	 fscanf(FileHandle,"%lf", &MissileMountAngleError[0][0]); 
	 fscanf(FileHandle,"%lf", &MissileMountAngleError[1][0]); 
	 fscanf(FileHandle,"%lf", &MissileMountAngleError[2][0]);
	 
	 fscanf(FileHandle,"%lf", &NominalLeverArm[0][0]);    
	 fscanf(FileHandle,"%lf", &NominalLeverArm[1][0]);    
	 fscanf(FileHandle,"%lf", &NominalLeverArm[2][0]);    
	 fscanf(FileHandle,"%lf", &LeverArmLengthError[0][0]);
	 fscanf(FileHandle,"%lf", &LeverArmLengthError[1][0]);
	 fscanf(FileHandle,"%lf", &LeverArmLengthError[2][0]);
	 
	 fscanf(FileHandle,"%lf", &MissileAccelerometerConstBias[0][0]);  
	 fscanf(FileHandle,"%lf", &MissileAccelerometerConstBias[1][0]);  
	 fscanf(FileHandle,"%lf", &MissileAccelerometerConstBias[2][0]);  
	 fscanf(FileHandle,"%lf", &MissileAccelerometerRandomBias[0][0]); 
	 fscanf(FileHandle,"%lf", &MissileAccelerometerRandomBias[1][0]); 
	 fscanf(FileHandle,"%lf", &MissileAccelerometerRandomBias[2][0]); 
	 fscanf(FileHandle,"%lf", &MissileAccelerometerScaleFactor[0][0]);
	 fscanf(FileHandle,"%lf", &MissileAccelerometerScaleFactor[1][0]);
	 fscanf(FileHandle,"%lf", &MissileAccelerometerScaleFactor[2][0]);

	 fscanf(FileHandle,"%lf", &RotaryAmp[0]); 
	 fscanf(FileHandle,"%lf", &RotaryAmp[1]); 
	 fscanf(FileHandle,"%lf", &RotaryAmp[2]); 
	 fscanf(FileHandle,"%lf", &RotaryFre[0]);
	 fscanf(FileHandle,"%lf", &RotaryFre[1]);
	 fscanf(FileHandle,"%lf", &RotaryFre[2]);
	 fscanf(FileHandle,"%lf", &RotaryPha[0]);
	 fscanf(FileHandle,"%lf", &RotaryPha[1]);
	 fscanf(FileHandle,"%lf", &RotaryPha[2]);
	 
	 fscanf(FileHandle,"%lf", &MissileAccelerometerCrossCoupling[0][1]);
	 fscanf(FileHandle,"%lf", &MissileAccelerometerCrossCoupling[0][2]);
	 fscanf(FileHandle,"%lf", &MissileAccelerometerCrossCoupling[1][0]);
	 fscanf(FileHandle,"%lf", &MissileAccelerometerCrossCoupling[1][2]);
	 fscanf(FileHandle,"%lf", &MissileAccelerometerCrossCoupling[2][0]);
	 fscanf(FileHandle,"%lf", &MissileAccelerometerCrossCoupling[2][1]);
	 
	 fscanf(FileHandle,"%lf", &MissileGyroCrossCoupling[0][1]);
	 fscanf(FileHandle,"%lf", &MissileGyroCrossCoupling[0][2]);
	 fscanf(FileHandle,"%lf", &MissileGyroCrossCoupling[1][0]);
	 fscanf(FileHandle,"%lf", &MissileGyroCrossCoupling[1][2]);
	 fscanf(FileHandle,"%lf", &MissileGyroCrossCoupling[2][0]);
	 fscanf(FileHandle,"%lf", &MissileGyroCrossCoupling[2][1]);
	 
	 fscanf(FileHandle,"%lf", &MissileAccelerometerQuantizationFactor);
	 fscanf(FileHandle,"%lf", &MissileGyroQuantizationFactor);         
	 
	 fscanf(FileHandle,"%lf", &CraftTraceStepSize);      
	 fscanf(FileHandle,"%lf", &CraftNavigationStepSize);   
	 fscanf(FileHandle,"%lf", &FcsNavigationStepSize); 
	 fscanf(FileHandle,"%lf", &FcsOutputStepSize);  
	 
	 fscanf(FileHandle,"%lf", &SimulationStartTime);      
	 fscanf(FileHandle,"%lf", &CraNavStartTime);          
	 fscanf(FileHandle,"%lf", &CraNavEndTime);            
	 fscanf(FileHandle,"%lf", &FcsNavStartTime);          
	 fscanf(FileHandle,"%lf", &FcsNavEndTime);            
	 fscanf(FileHandle,"%lf", &TransferAlignmentStartTime);
	 fscanf(FileHandle,"%lf", &TransferAlignmentTime);

	 fclose(FileHandle); 
}

void GetCraftParameterFromPanel()
{
	GetCtrlVal(CraftSetPanelHandle,CraftPANEL_NUMERICCraftIniLon,&CraftIniLongitude); //�ػ���ʼ����
	GetCtrlVal(CraftSetPanelHandle,CraftPANEL_NUMERICCraftIniLat,&CraftIniLatitude);//�ػ���ʼγ��
	GetCtrlVal(CraftSetPanelHandle,CraftPANEL_NUMERICCraftIniAlt,&CraftIniAltitude); //�ػ���ʼ�߶�			
	GetCtrlVal(CraftSetPanelHandle,CraftPANEL_NUMERICCraftIniForV,&CraftIniForwardVelocity); //�ػ���ʼǰ���ٶ�
	
	GetCtrlVal(CraftSetPanelHandle,CraftPANEL_NUMERICCraftIniYaw,&CraftIniYaw); //�ػ���ʼ����			
	GetCtrlVal(CraftSetPanelHandle,CraftPANEL_NUMERICCraftIniPitch,&CraftIniPitch); //�ػ���ʼ����			
	GetCtrlVal(CraftSetPanelHandle,CraftPANEL_NUMERICCraftIniRoll,&CraftIniRoll); //�ػ���ʼ���
	
	//���ߵ���������
	GetCtrlVal (CraftSetPanelHandle, CraftPANEL_NUMERICCraGyroConDriX, &CraftGyroConstDrift[0][0]);
	GetCtrlVal (CraftSetPanelHandle, CraftPANEL_NUMERICCraGyroConDriY, &CraftGyroConstDrift[1][0]);
	GetCtrlVal (CraftSetPanelHandle, CraftPANEL_NUMERICCraGyroConDriZ, &CraftGyroConstDrift[2][0]);
	
	GetCtrlVal (CraftSetPanelHandle, CraftPANEL_NUMERICCraGyroScaX, &CraftGyroScaleFactor[0][0]);
	GetCtrlVal (CraftSetPanelHandle, CraftPANEL_NUMERICCraGyroScaY, &CraftGyroScaleFactor[1][0]);			
	GetCtrlVal (CraftSetPanelHandle, CraftPANEL_NUMERICCraGyroScaZ, &CraftGyroScaleFactor[2][0]);
	
	GetCtrlVal (CraftSetPanelHandle, CraftPANEL_NUMERICCraGyroRanDriX, &CraftGyroRandomDrift[0][0]);
	GetCtrlVal (CraftSetPanelHandle, CraftPANEL_NUMERICCraGyroRanDriY, &CraftGyroRandomDrift[1][0]);
	GetCtrlVal (CraftSetPanelHandle, CraftPANEL_NUMERICCraGyroRanDriZ, &CraftGyroRandomDrift[2][0]);
	
	GetCtrlVal (CraftSetPanelHandle, CraftPANEL_NUMERICCraAccConBiaX, &CraftAccelerometerConstBias[0][0]);
	GetCtrlVal (CraftSetPanelHandle, CraftPANEL_NUMERICCraAccConBiaY, &CraftAccelerometerConstBias[1][0]);
	GetCtrlVal (CraftSetPanelHandle, CraftPANEL_NUMERICCraAccConBiaZ, &CraftAccelerometerConstBias[2][0]);
	
	GetCtrlVal (CraftSetPanelHandle, CraftPANEL_NUMERICCraAccScaX, &CraftAccelerometerScaleFactor[0][0]);
	GetCtrlVal (CraftSetPanelHandle, CraftPANEL_NUMERICCraAccScaY, &CraftAccelerometerScaleFactor[1][0]);
	GetCtrlVal (CraftSetPanelHandle, CraftPANEL_NUMERICCraAccScaZ, &CraftAccelerometerScaleFactor[2][0]);
	
	GetCtrlVal (CraftSetPanelHandle, CraftPANEL_NUMERICCraAccRanBiaX, &CraftAccelerometerRandomBias[0][0]);
	GetCtrlVal (CraftSetPanelHandle, CraftPANEL_NUMERICCraAccRanBiaY, &CraftAccelerometerRandomBias[1][0]);
	GetCtrlVal (CraftSetPanelHandle, CraftPANEL_NUMERICCraAccRanBiaZ, &CraftAccelerometerRandomBias[2][0]);
	
	GetCtrlVal (CraftSetPanelHandle, CraftPANEL_NUMERICAccQunFacM, &CraftAccelerometerQuantizationFactor);
	GetCtrlVal (CraftSetPanelHandle, CraftPANEL_NUMERICGyroQuaFacM, &CraftGyroQuantizationFactor);

	//���õ�����װ�Ǽ���װ������Ƹ˱ۺ͸˱����
	//������GetCtrlVal�����д���ֵ��������C������������Ĭ��Ϊ������
 	GetCtrlVal (CraftSetPanelHandle, CraftPANEL_NUMERICNominalLevX, &NominalLeverArm[0][0]); //��Ƹ˱۳���
	GetCtrlVal (CraftSetPanelHandle, CraftPANEL_NUMERICNominalLevY, &NominalLeverArm[1][0]);
	GetCtrlVal (CraftSetPanelHandle, CraftPANEL_NUMERICNominalLevZ, &NominalLeverArm[2][0]);
	
	//������ǰ������ϵ���ֱ�Ϊ���򡢸����������һ���������нǶ�
	GetCtrlVal (CraftSetPanelHandle, CraftPANEL_NUMERICMisMouYaw, &MissileMountAngle[0][0]); //�����ڻ����ϵİ�װ�Ƕ�
	GetCtrlVal (CraftSetPanelHandle, CraftPANEL_NUMERICMisMouPitch, &MissileMountAngle[1][0]);
	GetCtrlVal (CraftSetPanelHandle, CraftPANEL_NUMERICMisMouRoll, &MissileMountAngle[2][0]);

	GetCtrlVal (CraftSetPanelHandle, CraftPANEL_NUMERICMisMouAngErrX, &MissileMountAngleError[0][0]); //���ϵͳ���㰲װ���
	GetCtrlVal (CraftSetPanelHandle, CraftPANEL_NUMERICMisMouAngErrY, &MissileMountAngleError[1][0]);
	GetCtrlVal (CraftSetPanelHandle, CraftPANEL_NUMERICMisMouAngErrZ, &MissileMountAngleError[2][0]);
	
	GetCtrlVal (CraftSetPanelHandle, CraftPANEL_NUMERICLevArmAngErrX, &LeverArmLengthError[0][0]); //���ϵͳ����˱����
	GetCtrlVal (CraftSetPanelHandle, CraftPANEL_NUMERICLevArmAngErrY, &LeverArmLengthError[1][0]);
	GetCtrlVal (CraftSetPanelHandle, CraftPANEL_NUMERICLevArmAngErrZ, &LeverArmLengthError[2][0]);

	//�����ӹߵ�����
    GetCtrlVal (CraftSetPanelHandle, CraftPANEL_NUMERICMisAccConX, &MissileAccelerometerConstBias[0][0]); //�ӹߵ����ٶȼƳ�ֵ��ƫ��������
	GetCtrlVal (CraftSetPanelHandle, CraftPANEL_NUMERICMisAccConY, &MissileAccelerometerConstBias[1][0]);
	GetCtrlVal (CraftSetPanelHandle, CraftPANEL_NUMERICMisAccConZ, &MissileAccelerometerConstBias[2][0]);
	
	GetCtrlVal (CraftSetPanelHandle, CraftPANEL_NUMERICMisAccRanX, &MissileAccelerometerRandomBias[0][0]); //�ӹߵ����ٶȼ������ƫ��������
	GetCtrlVal (CraftSetPanelHandle, CraftPANEL_NUMERICMisAccRanY, &MissileAccelerometerRandomBias[1][0]);
	GetCtrlVal (CraftSetPanelHandle, CraftPANEL_NUMERICMisAccRanZ, &MissileAccelerometerRandomBias[2][0]);
	
	GetCtrlVal (CraftSetPanelHandle, CraftPANEL_NUMERICMisAccScaX, &MissileAccelerometerScaleFactor[0][0]); //�ӹߵ����ٶȼƿ̶�������������
	GetCtrlVal (CraftSetPanelHandle, CraftPANEL_NUMERICMisAccScaY, &MissileAccelerometerScaleFactor[1][0]);		   
	GetCtrlVal (CraftSetPanelHandle, CraftPANEL_NUMERICMisAccScaZ, &MissileAccelerometerScaleFactor[2][0]);
	
	GetCtrlVal (CraftSetPanelHandle, CraftPANEL_NUMERICMisAccCroXY, &MissileAccelerometerCrossCoupling[0][1]);  //�ӹߵ����ٶȼƽ�����ϣ�����
	GetCtrlVal (CraftSetPanelHandle, CraftPANEL_NUMERICMisAccCroXZ, &MissileAccelerometerCrossCoupling[0][2]);		   
	GetCtrlVal (CraftSetPanelHandle, CraftPANEL_NUMERICMisAccCroYX, &MissileAccelerometerCrossCoupling[1][0]);		   
	GetCtrlVal (CraftSetPanelHandle, CraftPANEL_NUMERICMisAccCroYZ, &MissileAccelerometerCrossCoupling[1][2]);		   
	GetCtrlVal (CraftSetPanelHandle, CraftPANEL_NUMERICMisAccCroZX, &MissileAccelerometerCrossCoupling[2][0]);		   
	GetCtrlVal (CraftSetPanelHandle, CraftPANEL_NUMERICMisAccCroZY, &MissileAccelerometerCrossCoupling[2][1]);		   
	
	GetCtrlVal (CraftSetPanelHandle, CraftPANEL_NUMERICAccQunFacS, &MissileAccelerometerQuantizationFactor);//�ӹߵ����ٶȼ��������ӣ������� 		   
	
	GetCtrlVal (CraftSetPanelHandle, CraftPANEL_NUMERICRotaryInnAmp, &RotaryAmp[0]); 
	GetCtrlVal (CraftSetPanelHandle, CraftPANEL_NUMERICRotaryMidAmp, &RotaryAmp[1]);
	GetCtrlVal (CraftSetPanelHandle, CraftPANEL_NUMERICRotaryOutAmp, &RotaryAmp[2]);
	
	GetCtrlVal (CraftSetPanelHandle, CraftPANEL_NUMERICRotaryInnFre, &RotaryFre[0]);
	GetCtrlVal (CraftSetPanelHandle, CraftPANEL_NUMERICRotaryMidFre, &RotaryFre[1]);
	GetCtrlVal (CraftSetPanelHandle, CraftPANEL_NUMERICRotaryOutFre, &RotaryFre[2]);
	
	GetCtrlVal (CraftSetPanelHandle, CraftPANEL_NUMERICRotaryInnPha, &RotaryPha[0]); 
	GetCtrlVal (CraftSetPanelHandle, CraftPANEL_NUMERICRotaryMidPha, &RotaryPha[1]);		   
	GetCtrlVal (CraftSetPanelHandle, CraftPANEL_NUMERICRotaryOutPha, &RotaryPha[2]);

	//����ʱ������
	GetCtrlVal(CraftSetPanelHandle,CraftPANEL_NUMERICSimStartTime,&SimulationStartTime); 	//�����ϵ�ʱ�� 
	GetCtrlVal(CraftSetPanelHandle,CraftPANEL_NUMERICCraNavStaTime,&CraNavStartTime); 		//���ߵ�������ʼʱ��
	GetCtrlVal(CraftSetPanelHandle,CraftPANEL_NUMERICCraNavStaTime,&CraNavEndTime); 		//���ߵ���������ʱ��
	GetCtrlVal(CraftSetPanelHandle,CraftPANEL_NUMERICFcsNavStaTime,&FcsNavStartTime);		//��ؽ���ʱ��,��׼��������ϵ����ʱ��
	GetCtrlVal(CraftSetPanelHandle,CraftPANEL_NUMERICAligEndTime,&TransferAlignmentTime); 	//��׼ʱ�䳤�� 			 

	//���沽������ 
	GetCtrlVal(CraftSetPanelHandle,CraftPANEL_NUMERICInteralStep,&CraftTraceStepSize); 		//�����㷨�Ĳ���
	GetCtrlVal(CraftSetPanelHandle,CraftPANEL_NUMERICCraNavStep,&CraftNavigationStepSize); 	//���ߵ����㲽�� 
	GetCtrlVal(CraftSetPanelHandle,CraftPANEL_NUMERICFcsNavStep,&FcsNavigationStepSize); 	//��ص������㲽��
	
	GetCtrlVal (CraftSetPanelHandle, CraftPANEL_TrueDataPathName, TrueDataFilePath);  
}

void SetCraftParameterToPanel()
{
	SetCtrlVal(CraftSetPanelHandle,CraftPANEL_NUMERICCraftIniLon,CraftIniLongitude); //�ػ���ʼ����
	SetCtrlVal(CraftSetPanelHandle,CraftPANEL_NUMERICCraftIniLat,CraftIniLatitude);  //�ػ���ʼγ��
	SetCtrlVal(CraftSetPanelHandle,CraftPANEL_NUMERICCraftIniAlt,CraftIniAltitude);  //�ػ���ʼ�߶�	
	SetCtrlVal(CraftSetPanelHandle,CraftPANEL_NUMERICCraftIniForV,CraftIniForwardVelocity); //�ػ���ʼǰ���ٶ�
	SetCtrlVal(CraftSetPanelHandle,CraftPANEL_NUMERICCraftIniYaw,CraftIniYaw);     //�ػ���ʼ����			
	SetCtrlVal(CraftSetPanelHandle,CraftPANEL_NUMERICCraftIniPitch,CraftIniPitch); //�ػ���ʼ����			
	SetCtrlVal(CraftSetPanelHandle,CraftPANEL_NUMERICCraftIniRoll,CraftIniRoll);   //�ػ���ʼ���

	//���ߵ���������
	SetCtrlVal (CraftSetPanelHandle, CraftPANEL_NUMERICCraGyroConDriX, CraftGyroConstDrift[0][0]);
	SetCtrlVal (CraftSetPanelHandle, CraftPANEL_NUMERICCraGyroConDriY, CraftGyroConstDrift[1][0]);
	SetCtrlVal (CraftSetPanelHandle, CraftPANEL_NUMERICCraGyroConDriZ, CraftGyroConstDrift[2][0]);

	SetCtrlVal (CraftSetPanelHandle, CraftPANEL_NUMERICCraGyroScaX, CraftGyroScaleFactor[0][0]);
	SetCtrlVal (CraftSetPanelHandle, CraftPANEL_NUMERICCraGyroScaY, CraftGyroScaleFactor[1][0]);
	SetCtrlVal (CraftSetPanelHandle, CraftPANEL_NUMERICCraGyroScaZ, CraftGyroScaleFactor[2][0]);

	SetCtrlVal (CraftSetPanelHandle, CraftPANEL_NUMERICCraGyroRanDriX, CraftGyroRandomDrift[0][0]);
	SetCtrlVal (CraftSetPanelHandle, CraftPANEL_NUMERICCraGyroRanDriY, CraftGyroRandomDrift[1][0]);
	SetCtrlVal (CraftSetPanelHandle, CraftPANEL_NUMERICCraGyroRanDriZ, CraftGyroRandomDrift[2][0]);

	SetCtrlVal (CraftSetPanelHandle, CraftPANEL_NUMERICCraAccConBiaX, CraftAccelerometerConstBias[0][0]);
	SetCtrlVal (CraftSetPanelHandle, CraftPANEL_NUMERICCraAccConBiaY, CraftAccelerometerConstBias[1][0]);
	SetCtrlVal (CraftSetPanelHandle, CraftPANEL_NUMERICCraAccConBiaZ, CraftAccelerometerConstBias[2][0]);

	SetCtrlVal (CraftSetPanelHandle, CraftPANEL_NUMERICCraAccScaX, CraftAccelerometerScaleFactor[0][0]);
	SetCtrlVal (CraftSetPanelHandle, CraftPANEL_NUMERICCraAccScaY, CraftAccelerometerScaleFactor[1][0]);
	SetCtrlVal (CraftSetPanelHandle, CraftPANEL_NUMERICCraAccScaZ, CraftAccelerometerScaleFactor[2][0]);

	SetCtrlVal (CraftSetPanelHandle, CraftPANEL_NUMERICCraAccRanBiaX, CraftAccelerometerRandomBias[0][0]);
	SetCtrlVal (CraftSetPanelHandle, CraftPANEL_NUMERICCraAccRanBiaY, CraftAccelerometerRandomBias[1][0]);
	SetCtrlVal (CraftSetPanelHandle, CraftPANEL_NUMERICCraAccRanBiaZ, CraftAccelerometerRandomBias[2][0]);

	SetCtrlVal (CraftSetPanelHandle, CraftPANEL_NUMERICAccQunFacM, CraftAccelerometerQuantizationFactor);
	SetCtrlVal (CraftSetPanelHandle, CraftPANEL_NUMERICGyroQuaFacM, CraftGyroQuantizationFactor);


	//���õ�����װ�Ǽ���װ������Ƹ˱ۺ͸˱����
	//������GetCtrlVal�����д���ֵ��������C������������Ĭ��Ϊ������
	SetCtrlVal (CraftSetPanelHandle, CraftPANEL_NUMERICNominalLevX, NominalLeverArm[0][0]); 			//��Ƹ˱۳���
	SetCtrlVal (CraftSetPanelHandle, CraftPANEL_NUMERICNominalLevY, NominalLeverArm[1][0]);
	SetCtrlVal (CraftSetPanelHandle, CraftPANEL_NUMERICNominalLevZ, NominalLeverArm[2][0]);

	//������ǰ������ϵ���ֱ�Ϊ���򡢸����������һ���������нǶ�
	SetCtrlVal (CraftSetPanelHandle, CraftPANEL_NUMERICMisMouYaw, MissileMountAngle[0][0]); 			//�����ڻ����ϵİ�װ�Ƕ�
	SetCtrlVal (CraftSetPanelHandle, CraftPANEL_NUMERICMisMouPitch, MissileMountAngle[1][0]);
	SetCtrlVal (CraftSetPanelHandle, CraftPANEL_NUMERICMisMouRoll, MissileMountAngle[2][0]);

	SetCtrlVal (CraftSetPanelHandle, CraftPANEL_NUMERICMisMouAngErrX, MissileMountAngleError[0][0]); 	//���ϵͳ���㰲װ���
	SetCtrlVal (CraftSetPanelHandle, CraftPANEL_NUMERICMisMouAngErrY, MissileMountAngleError[1][0]);
	SetCtrlVal (CraftSetPanelHandle, CraftPANEL_NUMERICMisMouAngErrZ, MissileMountAngleError[2][0]);
 
	SetCtrlVal (CraftSetPanelHandle, CraftPANEL_NUMERICLevArmAngErrX, LeverArmLengthError[0][0]); 		//���ϵͳ����˱����
	SetCtrlVal (CraftSetPanelHandle, CraftPANEL_NUMERICLevArmAngErrY, LeverArmLengthError[1][0]);
	SetCtrlVal (CraftSetPanelHandle, CraftPANEL_NUMERICLevArmAngErrZ, LeverArmLengthError[2][0]);

	//�����ӹߵ�����
	SetCtrlVal (CraftSetPanelHandle, CraftPANEL_NUMERICMisAccConX, MissileAccelerometerConstBias[0][0]); 		//�ӹߵ����ٶȼƳ�ֵ��ƫ��������
	SetCtrlVal (CraftSetPanelHandle, CraftPANEL_NUMERICMisAccConY, MissileAccelerometerConstBias[1][0]);
	SetCtrlVal (CraftSetPanelHandle, CraftPANEL_NUMERICMisAccConZ, MissileAccelerometerConstBias[2][0]);

	SetCtrlVal (CraftSetPanelHandle, CraftPANEL_NUMERICMisAccRanX, MissileAccelerometerRandomBias[0][0]); 		//�ӹߵ����ٶȼ������ƫ��������
	SetCtrlVal (CraftSetPanelHandle, CraftPANEL_NUMERICMisAccRanY, MissileAccelerometerRandomBias[1][0]);
	SetCtrlVal (CraftSetPanelHandle, CraftPANEL_NUMERICMisAccRanZ, MissileAccelerometerRandomBias[2][0]);

	SetCtrlVal (CraftSetPanelHandle, CraftPANEL_NUMERICMisAccScaX, MissileAccelerometerScaleFactor[0][0]); 	//�ӹߵ����ٶȼƿ̶�������������
	SetCtrlVal (CraftSetPanelHandle, CraftPANEL_NUMERICMisAccScaY, MissileAccelerometerScaleFactor[1][0]);		   
	SetCtrlVal (CraftSetPanelHandle, CraftPANEL_NUMERICMisAccScaZ, MissileAccelerometerScaleFactor[2][0]);

	SetCtrlVal (CraftSetPanelHandle, CraftPANEL_NUMERICMisAccCroXY, MissileAccelerometerCrossCoupling[0][1]);  //�ӹߵ����ٶȼƽ�����ϣ�����
	SetCtrlVal (CraftSetPanelHandle, CraftPANEL_NUMERICMisAccCroXZ, MissileAccelerometerCrossCoupling[0][2]);		   
	SetCtrlVal (CraftSetPanelHandle, CraftPANEL_NUMERICMisAccCroYX, MissileAccelerometerCrossCoupling[1][0]);		   
	SetCtrlVal (CraftSetPanelHandle, CraftPANEL_NUMERICMisAccCroYZ, MissileAccelerometerCrossCoupling[1][2]);		   
	SetCtrlVal (CraftSetPanelHandle, CraftPANEL_NUMERICMisAccCroZX, MissileAccelerometerCrossCoupling[2][0]);		   
	SetCtrlVal (CraftSetPanelHandle, CraftPANEL_NUMERICMisAccCroZY, MissileAccelerometerCrossCoupling[2][1]);		   

	SetCtrlVal (CraftSetPanelHandle, CraftPANEL_NUMERICAccQunFacS, MissileAccelerometerQuantizationFactor);	//�ӹߵ����ٶȼ��������ӣ������� 		   

	SetCtrlVal (CraftSetPanelHandle, CraftPANEL_NUMERICRotaryInnAmp, RotaryAmp[0]); 			//�ӹߵ������ǳ�ֵƯ�� ��������
	SetCtrlVal (CraftSetPanelHandle, CraftPANEL_NUMERICRotaryMidAmp, RotaryAmp[1]);	
	SetCtrlVal (CraftSetPanelHandle, CraftPANEL_NUMERICRotaryOutAmp, RotaryAmp[2]);

	SetCtrlVal (CraftSetPanelHandle, CraftPANEL_NUMERICRotaryInnFre, RotaryFre[0]); 			//�ӹߵ����������Ư�ƣ�������
	SetCtrlVal (CraftSetPanelHandle, CraftPANEL_NUMERICRotaryMidFre, RotaryFre[1]);
	SetCtrlVal (CraftSetPanelHandle, CraftPANEL_NUMERICRotaryOutFre, RotaryFre[2]);

	SetCtrlVal (CraftSetPanelHandle, CraftPANEL_NUMERICRotaryInnPha, RotaryPha[0]); 			//�ӹߵ����ݿ̶�������������
	SetCtrlVal (CraftSetPanelHandle, CraftPANEL_NUMERICRotaryMidPha, RotaryPha[1]);		   
	SetCtrlVal (CraftSetPanelHandle, CraftPANEL_NUMERICRotaryOutPha, RotaryPha[2]);

	//����ʱ������
	SetCtrlVal(CraftSetPanelHandle,CraftPANEL_NUMERICSimStartTime,SimulationStartTime); 		//�����ϵ�ʱ�� 
	SetCtrlVal(CraftSetPanelHandle,CraftPANEL_NUMERICCraNavStaTime,CraNavStartTime); 			//���ߵ�������ʼʱ��
	SetCtrlVal(CraftSetPanelHandle,CraftPANEL_NUMERICCraNavStaTime,CraNavEndTime); 			//���ߵ���������ʱ��
	SetCtrlVal(CraftSetPanelHandle,CraftPANEL_NUMERICFcsNavStaTime,FcsNavStartTime);			//��ؽ���ʱ��,��׼��������ϵ����ʱ��
	SetCtrlVal(CraftSetPanelHandle,CraftPANEL_NUMERICAligEndTime,TransferAlignmentTime); 		//��׼����ʱ�� 			 

	SetCtrlVal (CraftSetPanelHandle, CraftPANEL_TrueDataPathName, TrueDataFilePath);  
 	
	//���沽������ 
 	SetCtrlVal(CraftSetPanelHandle,CraftPANEL_NUMERICInteralStep,CraftTraceStepSize); 			//�����㷨�Ĳ���
 	SetCtrlVal(CraftSetPanelHandle,CraftPANEL_NUMERICCraNavStep,CraftNavigationStepSize); 		//���ߵ����㲽�� ��
 	SetCtrlVal(CraftSetPanelHandle,CraftPANEL_NUMERICFcsNavStep,FcsNavigationStepSize); 		//��ص������㲽����
		

}

void ReadCraftTraceToPanel(FILE *FileHandle, char *FilePath)
{
    FileHandle=fopen(FilePath,"r");
	fscanf(FileHandle,"%d", &CraftFlightStateNum);
	 
	int CRAFTTRACENUMBER[100];
	for(int i=1;i<=CraftFlightStateNum;i++) //���й켣�����ļ��ж�ȡ�Ƕ��٣��������Ǵ�0��ʼ���У�����Ҫ��ȥ1
	{   
		fscanf(FileHandle,"%d", &CRAFTTRACENUMBER[i]);
		fscanf(FileHandle,"%d", &CraftFlightState[i]); 				 
		fscanf(FileHandle,"%lf", &EachCraftTraceTime[i]);
		fscanf(FileHandle,"%lf", &CraftForwardAccelerationExpect[i]); 
		fscanf(FileHandle,"%lf", &CraftAttitudeChange[0][i]); 	
		fscanf(FileHandle,"%lf", &CraftAttitudeChange[1][i]); 
		fscanf(FileHandle,"%lf", &CraftAttitudeChange[2][i]);
		fscanf(FileHandle, "\r\n");

		CraftNewRow=CraftNewRow+1; 

		InsertTableRows(CraftSetPanelHandle,CraftPANEL_TABLE,CraftNewRow,1,VAL_USE_MASTER_CELL_TYPE);//��켣�滮Table���м����µ�һ��

		if (CraftFlightState[CraftNewRow]==CraftDengJiaoFeiXing)       //�ػ��Ƚ��˶�����
		{
		sprintf(&CraftChinese[i], "%s", "�ػ��Ƚ��˶�����"); //���ַ����������ĺ���������֪������
		}
		else if (CraftFlightState[CraftNewRow]==CraftFuYangYunDong) //�ػ������˶�����
		{
		sprintf(&CraftChinese[i], "%s", "�ػ������˶�����");
		}
		else if (CraftFlightState[CraftNewRow]==CraftFuYangGaiPing) //�ػ�������ƽ����
		{
		sprintf(&CraftChinese[i], "%s", "�ػ�������ƽ����");
		}
		else if (CraftFlightState[CraftNewRow]==CraftXieTiaoZhuanWan)  //�ػ�Э��ת�����
		{
		sprintf(&CraftChinese[i], "%s", "�ػ�Э��ת�����");
		}
		else if (CraftFlightState[CraftNewRow]==CraftZhuanWanXunHang)  //�ػ�ת��Ѳ������
		{
		sprintf(&CraftChinese[i], "%s", "�ػ�ת��Ѳ������");
		}
		else if (CraftFlightState[CraftNewRow]==CraftZhuanWanGaiPing)  //�ػ�ת���ƽ����
		{
		sprintf(&CraftChinese[i], "%s", "�ػ�ת���ƽ����");
		}
		else if (CraftFlightState[CraftNewRow]==CraftYiBanHengGun)  //�ػ�һ��������
		{
		sprintf(&CraftChinese[i], "%s", "�ػ�һ��������");
		}
		else if (CraftFlightState[CraftNewRow]==CraftYiBanZhuanWan )   //�ػ�һ��ת�����
		{
		sprintf(&CraftChinese[i], "%s", "�ػ�һ��ת�����");
		}
		SetTableCellVal(CraftSetPanelHandle,CraftPANEL_TABLE,MakePoint(1,CraftNewRow),&CraftChinese[i]);
		SetTableCellVal(CraftSetPanelHandle,CraftPANEL_TABLE,MakePoint(2,CraftNewRow),EachCraftTraceTime[i]);
		SetTableCellVal(CraftSetPanelHandle,CraftPANEL_TABLE,MakePoint(3,CraftNewRow),CraftForwardAccelerationExpect[i]);
		SetTableCellVal(CraftSetPanelHandle,CraftPANEL_TABLE,MakePoint(4,CraftNewRow),CraftAttitudeChange[0][i]);
		SetTableCellVal(CraftSetPanelHandle,CraftPANEL_TABLE,MakePoint(5,CraftNewRow),CraftAttitudeChange[1][i]);
		SetTableCellVal(CraftSetPanelHandle,CraftPANEL_TABLE,MakePoint(6,CraftNewRow),CraftAttitudeChange[2][i]);	 
	}									
    fclose(FileHandle);
}	

void WriteCraftTraceToFile(FILE *FileHandle, char *FilePath)
{
			 FileHandle=fopen(FilePath,"wb");
			 
			 fprintf(FileHandle,"%d ", CraftFlightStateNum);  //���ػ��켣�ļ��ĵ�һ��д�ػ��켣�ܸ���
			 fprintf(FileHandle, "\r\n");						//����CraftFlightStateNum�ĳ�ֵΪ-1������������ػ��켣����Ҫ��1
		 
			 for(int i=1;i<=CraftFlightStateNum;i++)																			    
			 {   																					   
				 fprintf(FileHandle,"%d ", i);
			     fprintf(FileHandle,"%d ", CraftFlightState[i]); 				 
				 fprintf(FileHandle,"%f ", EachCraftTraceTime[i]);
			     fprintf(FileHandle,"%f ", CraftForwardAccelerationExpect[i]); 
			     fprintf(FileHandle,"%f ", CraftAttitudeChange[0][i]); 
			     fprintf(FileHandle,"%f ", CraftAttitudeChange[1][i]);
				 fprintf(FileHandle,"%f ", CraftAttitudeChange[2][i]);
				 fprintf(FileHandle, "\r\n");	
			 }
			 fclose(FileHandle); 
	
}

void SetCraftTraceToPanel()
{
	for(int i=1;i <= CraftFlightStateNum;i++) 
	{
		 CraftNewRow=CraftNewRow+1; 

	     InsertTableRows(CraftSetPanelHandle,CraftPANEL_TABLE,CraftNewRow,1,VAL_USE_MASTER_CELL_TYPE);//��켣�滮Table���м����µ�һ��

	     if (CraftFlightState[CraftNewRow]==CraftDengJiaoFeiXing)       //�ػ��Ƚ��˶�����
	     {
	     	sprintf(&CraftChinese[i], "%s", "�ػ��Ƚ��˶�����"); //���ַ����������ĺ���������֪������
	     }
	     else if (CraftFlightState[CraftNewRow]==CraftFuYangYunDong) //�ػ������˶�����
	     {
	       sprintf(&CraftChinese[i], "%s", "�ػ������˶�����");
	     }
	     else if (CraftFlightState[CraftNewRow]==CraftFuYangGaiPing) //�ػ�������ƽ����
	     {
	       sprintf(&CraftChinese[i], "%s", "�ػ�������ƽ����");
	     }
	     else if (CraftFlightState[CraftNewRow]==CraftXieTiaoZhuanWan)  //�ػ�Э��ת�����
	     {
	        sprintf(&CraftChinese[i], "%s", "�ػ�Э��ת�����");
	     }
	     else if (CraftFlightState[CraftNewRow]==CraftZhuanWanXunHang)  //�ػ�ת��Ѳ������
	     {
	        sprintf(&CraftChinese[i], "%s", "�ػ�ת��Ѳ������");
	     }
	     else if (CraftFlightState[CraftNewRow]==CraftZhuanWanGaiPing)  //�ػ�ת���ƽ����
	     {
	        sprintf(&CraftChinese[i], "%s", "�ػ�ת���ƽ����");
	     }
	     else if (CraftFlightState[CraftNewRow]==CraftYiBanHengGun)  //�ػ�һ��������
	     {
	        sprintf(&CraftChinese[i], "%s", "�ػ�һ��������");
	     }
	     else if (CraftFlightState[CraftNewRow]==CraftYiBanZhuanWan )   //�ػ�һ��ת�����
	     {
	        sprintf(&CraftChinese[i], "%s", "�ػ�һ��ת�����");
	     }
	     SetTableCellVal(CraftSetPanelHandle,CraftPANEL_TABLE,MakePoint(1,CraftNewRow),&CraftChinese[i]);
	     SetTableCellVal(CraftSetPanelHandle,CraftPANEL_TABLE,MakePoint(2,CraftNewRow),EachCraftTraceTime[i]);
	     SetTableCellVal(CraftSetPanelHandle,CraftPANEL_TABLE,MakePoint(3,CraftNewRow),CraftForwardAccelerationExpect[i]);
	     SetTableCellVal(CraftSetPanelHandle,CraftPANEL_TABLE,MakePoint(4,CraftNewRow),CraftAttitudeChange[0][i]);
	     SetTableCellVal(CraftSetPanelHandle,CraftPANEL_TABLE,MakePoint(5,CraftNewRow),CraftAttitudeChange[1][i]);
	     SetTableCellVal(CraftSetPanelHandle,CraftPANEL_TABLE,MakePoint(6,CraftNewRow),CraftAttitudeChange[2][i]);	 
	}	
}

void InitialCraftPanelVariable()
{
	SmoothTimePercent=0.1;                 //�켣ƽ��ʱ��ռ�켣�˶�ʱ��İٷֱ�
	
	CraftPanelIniFileHandle=fopen(CraftPanelIni_FILE_PATH,"r");

	fscanf(CraftPanelIniFileHandle,"%lf", &CraftIniLongitude); 
	fscanf(CraftPanelIniFileHandle,"%lf", &CraftIniLatitude); 
	fscanf(CraftPanelIniFileHandle,"%lf", &CraftIniAltitude); 
	fscanf(CraftPanelIniFileHandle,"%lf", &CraftIniForwardVelocity); 

	fscanf(CraftPanelIniFileHandle,"%lf", &CraftIniYaw);
	fscanf(CraftPanelIniFileHandle,"%lf", &CraftIniPitch);			  
	fscanf(CraftPanelIniFileHandle,"%lf", &CraftIniRoll);

	fscanf(CraftPanelIniFileHandle,"%lf", &CraftGyroConstDrift[0][0]); 
	fscanf(CraftPanelIniFileHandle,"%lf", &CraftGyroConstDrift[1][0]); 
	fscanf(CraftPanelIniFileHandle,"%lf", &CraftGyroConstDrift[2][0]); 
	fscanf(CraftPanelIniFileHandle,"%lf", &CraftGyroRandomDrift[0][0]); 
	fscanf(CraftPanelIniFileHandle,"%lf", &CraftGyroRandomDrift[1][0]); 
	fscanf(CraftPanelIniFileHandle,"%lf", &CraftGyroRandomDrift[2][0]); 
	fscanf(CraftPanelIniFileHandle,"%lf", &CraftGyroScaleFactor[0][0]); 
	fscanf(CraftPanelIniFileHandle,"%lf", &CraftGyroScaleFactor[1][0]); 
	fscanf(CraftPanelIniFileHandle,"%lf", &CraftGyroScaleFactor[2][0]); 

	fscanf(CraftPanelIniFileHandle,"%lf", &CraftAccelerometerConstBias[0][0]);  
	fscanf(CraftPanelIniFileHandle,"%lf", &CraftAccelerometerConstBias[1][0]);   
	fscanf(CraftPanelIniFileHandle,"%lf", &CraftAccelerometerConstBias[2][0]);   
	fscanf(CraftPanelIniFileHandle,"%lf", &CraftAccelerometerRandomBias[0][0]);  
	fscanf(CraftPanelIniFileHandle,"%lf", &CraftAccelerometerRandomBias[1][0]);  
	fscanf(CraftPanelIniFileHandle,"%lf", &CraftAccelerometerRandomBias[2][0]);  
	fscanf(CraftPanelIniFileHandle,"%lf", &CraftAccelerometerScaleFactor[0][0]); 
	fscanf(CraftPanelIniFileHandle,"%lf", &CraftAccelerometerScaleFactor[1][0]); 
	fscanf(CraftPanelIniFileHandle,"%lf", &CraftAccelerometerScaleFactor[2][0]); 

	fscanf(CraftPanelIniFileHandle,"%lf", &CraftAccelerometerQuantizationFactor);
	fscanf(CraftPanelIniFileHandle,"%lf", &CraftGyroQuantizationFactor);


	fscanf(CraftPanelIniFileHandle,"%lf", &MissileMountAngle[0][0]);      
	fscanf(CraftPanelIniFileHandle,"%lf", &MissileMountAngle[1][0]);      
	fscanf(CraftPanelIniFileHandle,"%lf", &MissileMountAngle[2][0]);      
	fscanf(CraftPanelIniFileHandle,"%lf", &MissileMountAngleError[0][0]); 
	fscanf(CraftPanelIniFileHandle,"%lf", &MissileMountAngleError[1][0]); 
	fscanf(CraftPanelIniFileHandle,"%lf", &MissileMountAngleError[2][0]);

	fscanf(CraftPanelIniFileHandle,"%lf", &NominalLeverArm[0][0]);    
	fscanf(CraftPanelIniFileHandle,"%lf", &NominalLeverArm[1][0]);    
	fscanf(CraftPanelIniFileHandle,"%lf", &NominalLeverArm[2][0]);    
	fscanf(CraftPanelIniFileHandle,"%lf", &LeverArmLengthError[0][0]);
	fscanf(CraftPanelIniFileHandle,"%lf", &LeverArmLengthError[1][0]);
	fscanf(CraftPanelIniFileHandle,"%lf", &LeverArmLengthError[2][0]);

	fscanf(CraftPanelIniFileHandle,"%lf", &MissileAccelerometerConstBias[0][0]);  
	fscanf(CraftPanelIniFileHandle,"%lf", &MissileAccelerometerConstBias[1][0]);  
	fscanf(CraftPanelIniFileHandle,"%lf", &MissileAccelerometerConstBias[2][0]);  
	fscanf(CraftPanelIniFileHandle,"%lf", &MissileAccelerometerRandomBias[0][0]); 
	fscanf(CraftPanelIniFileHandle,"%lf", &MissileAccelerometerRandomBias[1][0]); 
	fscanf(CraftPanelIniFileHandle,"%lf", &MissileAccelerometerRandomBias[2][0]); 
	fscanf(CraftPanelIniFileHandle,"%lf", &MissileAccelerometerScaleFactor[0][0]);
	fscanf(CraftPanelIniFileHandle,"%lf", &MissileAccelerometerScaleFactor[1][0]);
	fscanf(CraftPanelIniFileHandle,"%lf", &MissileAccelerometerScaleFactor[2][0]);

	fscanf(CraftPanelIniFileHandle,"%lf", &RotaryAmp[0]); 
	fscanf(CraftPanelIniFileHandle,"%lf", &RotaryAmp[1]); 
	fscanf(CraftPanelIniFileHandle,"%lf", &RotaryAmp[2]); 
	fscanf(CraftPanelIniFileHandle,"%lf", &RotaryFre[0]);
	fscanf(CraftPanelIniFileHandle,"%lf", &RotaryFre[1]);
	fscanf(CraftPanelIniFileHandle,"%lf", &RotaryFre[2]);
	fscanf(CraftPanelIniFileHandle,"%lf", &RotaryPha[0]);
	fscanf(CraftPanelIniFileHandle,"%lf", &RotaryPha[1]);
	fscanf(CraftPanelIniFileHandle,"%lf", &RotaryPha[2]);

	fscanf(CraftPanelIniFileHandle,"%lf", &MissileAccelerometerCrossCoupling[0][1]);
	fscanf(CraftPanelIniFileHandle,"%lf", &MissileAccelerometerCrossCoupling[0][2]);
	fscanf(CraftPanelIniFileHandle,"%lf", &MissileAccelerometerCrossCoupling[1][0]);
	fscanf(CraftPanelIniFileHandle,"%lf", &MissileAccelerometerCrossCoupling[1][2]);
	fscanf(CraftPanelIniFileHandle,"%lf", &MissileAccelerometerCrossCoupling[2][0]);
	fscanf(CraftPanelIniFileHandle,"%lf", &MissileAccelerometerCrossCoupling[2][1]);

	fscanf(CraftPanelIniFileHandle,"%lf", &MissileGyroCrossCoupling[0][1]);
	fscanf(CraftPanelIniFileHandle,"%lf", &MissileGyroCrossCoupling[0][2]);
	fscanf(CraftPanelIniFileHandle,"%lf", &MissileGyroCrossCoupling[1][0]);
	fscanf(CraftPanelIniFileHandle,"%lf", &MissileGyroCrossCoupling[1][2]);
	fscanf(CraftPanelIniFileHandle,"%lf", &MissileGyroCrossCoupling[2][0]);
	fscanf(CraftPanelIniFileHandle,"%lf", &MissileGyroCrossCoupling[2][1]);

	fscanf(CraftPanelIniFileHandle,"%lf", &MissileAccelerometerQuantizationFactor);
	fscanf(CraftPanelIniFileHandle,"%lf", &MissileGyroQuantizationFactor);         

	fscanf(CraftPanelIniFileHandle,"%lf", &CraftTraceStepSize);      
	fscanf(CraftPanelIniFileHandle,"%lf", &CraftNavigationStepSize);   
	fscanf(CraftPanelIniFileHandle,"%lf", &FcsNavigationStepSize); 
	fscanf(CraftPanelIniFileHandle,"%lf", &FcsOutputStepSize);  

	fscanf(CraftPanelIniFileHandle,"%lf", &SimulationStartTime);      
	fscanf(CraftPanelIniFileHandle,"%lf", &CraNavStartTime);          
	fscanf(CraftPanelIniFileHandle,"%lf", &CraNavEndTime);            
	fscanf(CraftPanelIniFileHandle,"%lf", &FcsNavStartTime);          
	fscanf(CraftPanelIniFileHandle,"%lf", &FcsNavEndTime);            
	fscanf(CraftPanelIniFileHandle,"%lf", &TransferAlignmentStartTime);
	fscanf(CraftPanelIniFileHandle,"%lf", &TransferAlignmentTime);
 
	fscanf(CraftPanelIniFileHandle,"%d", &CraftFlightStateNum);

	int CRAFTTRACENUMBER[100];
	for(int i=1;i<=CraftFlightStateNum;i++) 
	{   
		 fscanf(CraftPanelIniFileHandle,"%d", &CRAFTTRACENUMBER[i]);
	     fscanf(CraftPanelIniFileHandle,"%d", &CraftFlightState[i]); 				 
		 fscanf(CraftPanelIniFileHandle,"%lf", &EachCraftTraceTime[i]);
	     fscanf(CraftPanelIniFileHandle,"%lf", &CraftForwardAccelerationExpect[i]); 
	     fscanf(CraftPanelIniFileHandle,"%lf", &CraftAttitudeChange[0][i]); 	
	     fscanf(CraftPanelIniFileHandle,"%lf", &CraftAttitudeChange[1][i]); 
		 fscanf(CraftPanelIniFileHandle,"%lf \r\n", &CraftAttitudeChange[2][i]);
	}	

	fread(TrueDataFilePath, 1, 260, CraftPanelIniFileHandle);  
 
    fclose(CraftPanelIniFileHandle);   	
}

void InitialMainPanel()
{
	MainPanelIniFileHandle=fopen(MainPanelIni_FILE_PATH,"r");
	fscanf(MainPanelIniFileHandle,"%d" , &TraceModeSelect); 
	fscanf(MainPanelIniFileHandle,"%d" , &cmd.DataSaveFlag);  
	fclose(MainPanelIniFileHandle);
	
	SetCtrlVal (MainPanelHandle, MainPanel_DataSaveFlag, cmd.DataSaveFlag); 
	switch(TraceModeSelect)
	{
		case CRAFT_MODE:
			SetCtrlVal (MainPanelHandle, MainPanel_CraftMode, 1); 
			SetCtrlVal (MainPanelHandle, MainPanel_MisGuiMode, 0); 
			SetCtrlVal (MainPanelHandle, MainPanel_MisFreeMode, 0); 
			SetCtrlVal (MainPanelHandle, MainPanel_MisProMode, 0); 
	    	break;
		case MISGUI_MODE:
			SetCtrlVal (MainPanelHandle, MainPanel_CraftMode, 0); 
			SetCtrlVal (MainPanelHandle, MainPanel_MisGuiMode, 1); 
			SetCtrlVal (MainPanelHandle, MainPanel_MisFreeMode, 0); 
			SetCtrlVal (MainPanelHandle, MainPanel_MisProMode, 0);
			break;
		case MISFREE_MODE:
			SetCtrlVal (MainPanelHandle, MainPanel_CraftMode, 0); 
			SetCtrlVal (MainPanelHandle, MainPanel_MisGuiMode, 0); 
			SetCtrlVal (MainPanelHandle, MainPanel_MisFreeMode, 1); 
			SetCtrlVal (MainPanelHandle, MainPanel_MisProMode, 0);
			break;
		case DATARD_MODE:
			SetCtrlVal (MainPanelHandle, MainPanel_CraftMode, 0); 
			SetCtrlVal (MainPanelHandle, MainPanel_MisGuiMode, 0); 
			SetCtrlVal (MainPanelHandle, MainPanel_MisFreeMode, 0); 
			SetCtrlVal (MainPanelHandle, MainPanel_MisProMode, 1);
			break;
	}
}

/******************************�������в��������������*****************************/   
//ȷ�ϰ�ť�ص�����
int CVICALLBACK MisTarConfirmCallback (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)	//�ú��������ؼ���ȷ����ť�����º��ϵͳ��Ӧ
{
	switch (event)
	{   
		
		case EVENT_COMMIT:
		   
			MisNewRow=0;
			TarNewRow=0;

			//������������
			//��Ӧ�����켣����ģʽ
			GetCtrlVal(MissileSetPanelHandle,MisPANEL_CHECKBOXMissileFree,&MissileFreeFlightFlag);   
			GetCtrlVal(MissileSetPanelHandle,MisPANEL_CHECKBOXMissileGui,&MissileGuiFlightFlag);
			GetCtrlVal(MissileSetPanelHandle,MisPANEL_CHECKBOXMissileData,&MissileDataReadFlag);  

			if(MissileFreeFlightFlag==0 && MissileGuiFlightFlag==0 && MissileDataReadFlag==0)
			{
			   MessagePopup("������ʾ","��ѡ�񵼵��ķ������鷽ʽ�����ɷ��С��Ƶ����л��ȡ�̿ص�����");
			}
			else
			{
				if(MissileFreeFlightFlag==1)
				    MisModeDisplay=MISFREE_MODE;
				   if(MissileGuiFlightFlag==1)
					   MisModeDisplay=MISGUI_MODE;  
					   if(MissileDataReadFlag==1)
						   MisModeDisplay=DATARD_MODE;  
				MissilePanelIniFileHandle=fopen(MissilePanelIni_FILE_PATH,"w");

				fprintf(MissilePanelIniFileHandle,"%d ",MisModeDisplay);
				fprintf(MissilePanelIniFileHandle,"\n"); 
				GetCtrlVal(MissileSetPanelHandle,MisPANEL_NUMERICMisIniPosX,&MissileIniLon);	 
				GetCtrlVal(MissileSetPanelHandle,MisPANEL_NUMERICMisIniPosY,&MissileIniLat);		   
				GetCtrlVal(MissileSetPanelHandle,MisPANEL_NUMERICMisIniPosZ,&MissileIniAlt);
				GetCtrlVal(MissileSetPanelHandle,MisPANEL_NUMERICMisIniVel,&MissileIniVel);			
				GetCtrlVal(MissileSetPanelHandle,MisPANEL_NUMERICMisIniYaw,&MissileIniYaw);
				GetCtrlVal(MissileSetPanelHandle,MisPANEL_NUMERICMisIniPitch,&MissileIniPitch);
				GetCtrlVal(MissileSetPanelHandle,MisPANEL_NUMERICMisIniRoll,&MissileIniRoll);			  //��ʼ λ�� ǰ���ٶ� �����
				GetCtrlVal(MissileSetPanelHandle,MisPANEL_NUMERICMisFraOriLat,&FrameOriginLatitude);	  //����ԭ��γ
				GetCtrlVal(MissileSetPanelHandle,MisPANEL_NUMERICMisStepSize,&MisStepTime);

				fprintf(MissilePanelIniFileHandle,"%lf ",MissileIniLon);
				fprintf(MissilePanelIniFileHandle,"%lf ",MissileIniLat);  
				fprintf(MissilePanelIniFileHandle,"%lf ",MissileIniAlt);  
				fprintf(MissilePanelIniFileHandle,"%lf ",MissileIniVel);  
				fprintf(MissilePanelIniFileHandle,"%lf ",MissileIniYaw);  
				fprintf(MissilePanelIniFileHandle,"%lf ",MissileIniPitch);
				fprintf(MissilePanelIniFileHandle,"%lf ",MissileIniRoll);
				fprintf(MissilePanelIniFileHandle,"%lf ",FrameOriginLatitude);
				fprintf(MissilePanelIniFileHandle,"%lf ",MisStepTime); 
				fprintf(MissilePanelIniFileHandle,"\r\n");

				//���ɷ�����ز���
				GetCtrlVal(MissileSetPanelHandle,MisPANEL_NUMERICMisFlightTime,&MissileFreeFlightTime);	
				GetCtrlVal(MissileSetPanelHandle,MisPANEL_NUMERICMisSmoothTime,&MisSmoothTime);	//���ɷ���ʱ��

				fprintf(MissilePanelIniFileHandle,"%lf \r\n", MissileFreeFlightTime);
				fprintf(MissilePanelIniFileHandle,"%lf \r\n", MisSmoothTime); 
				fprintf(MissilePanelIniFileHandle,"%d  \r\n", MisFlightStateNum);

				for(int i=1;i<=MisFlightStateNum;i++)												  //����滮�����켣
				{   
					fprintf(MissilePanelIniFileHandle,"%lf ", MissileChangeStartTime[i]); 
					fprintf(MissilePanelIniFileHandle,"%lf ", MissileChangeEndTime[i]); 

					fprintf(MissilePanelIniFileHandle,"%lf ", MisSFAmplitudeX[i]); 
					fprintf(MissilePanelIniFileHandle,"%lf ", MisSFAmplitudeY[i]);   
					fprintf(MissilePanelIniFileHandle,"%lf ", MisSFAmplitudeZ[i]);   
					fprintf(MissilePanelIniFileHandle,"%lf ", MisSFFrequencyX[i]); 
					fprintf(MissilePanelIniFileHandle,"%lf ", MisSFFrequencyY[i]);
					fprintf(MissilePanelIniFileHandle,"%lf ", MisSFFrequencyZ[i]);
					fprintf(MissilePanelIniFileHandle,"%lf ", MisSFPhaseX[i]); 
					fprintf(MissilePanelIniFileHandle,"%lf ", MisSFPhaseY[i]); 
					fprintf(MissilePanelIniFileHandle,"%lf ", MisSFPhaseZ[i]);

					fprintf(MissilePanelIniFileHandle,"%lf ", MisAngRateAmplitudeX[i]); 
					fprintf(MissilePanelIniFileHandle,"%lf ", MisAngRateAmplitudeY[i]);   
					fprintf(MissilePanelIniFileHandle,"%lf ", MisAngRateAmplitudeZ[i]);   
					fprintf(MissilePanelIniFileHandle,"%lf ", MisAngRateFrequencyX[i]); 
					fprintf(MissilePanelIniFileHandle,"%lf ", MisAngRateFrequencyY[i]);
					fprintf(MissilePanelIniFileHandle,"%lf ", MisAngRateFrequencyZ[i]);
					fprintf(MissilePanelIniFileHandle,"%lf ", MisAngRatePhaseX[i]); 
					fprintf(MissilePanelIniFileHandle,"%lf ", MisAngRatePhaseY[i]); 
					fprintf(MissilePanelIniFileHandle,"%lf ", MisAngRatePhaseZ[i]);
				} 
				fprintf(MissilePanelIniFileHandle,"\n");

				//�Ƶ�������ز���
				GetCtrlVal(MissileSetPanelHandle,MisPANEL_NUMERICMisGuiTime,&MissileGuiFlightTime);	      //�Ƶ�����ʱ��
				GetCtrlVal(MissileSetPanelHandle,MisPANEL_NUMERICMisNavRatio,&NavigationRatio);			  //������

				GetCtrlVal(MissileSetPanelHandle,MisPANEL_NUMERICTarIniPosX,&TargetIniLon);  
				GetCtrlVal(MissileSetPanelHandle,MisPANEL_NUMERICTarIniPosY,&TargetIniLat); 
				GetCtrlVal(MissileSetPanelHandle,MisPANEL_NUMERICTarIniPosZ,&TargetIniAlt); 

				GetCtrlVal(MissileSetPanelHandle,MisPANEL_NUMERICTarIniVelN,&TargetIniVelN); 
				GetCtrlVal(MissileSetPanelHandle,MisPANEL_NUMERICTarIniVelU,&TargetIniVelU); 
				GetCtrlVal(MissileSetPanelHandle,MisPANEL_NUMERICTarIniVelE,&TargetIniVelE); 		

				fprintf(MissilePanelIniFileHandle,"%lf ", MissileGuiFlightTime); 
				fprintf(MissilePanelIniFileHandle,"%lf ", NavigationRatio);

				fprintf(MissilePanelIniFileHandle,"%lf ", TargetIniLon); 
				fprintf(MissilePanelIniFileHandle,"%lf ", TargetIniLat); 
				fprintf(MissilePanelIniFileHandle,"%lf ", TargetIniAlt);
				
				fprintf(MissilePanelIniFileHandle,"%lf ", TargetIniVelN); 
				fprintf(MissilePanelIniFileHandle,"%lf ", TargetIniVelU); 
				fprintf(MissilePanelIniFileHandle,"%lf ", TargetIniVelE); 

				fprintf(MissilePanelIniFileHandle,"\r\n" );

				fprintf(MissilePanelIniFileHandle,"%d ", Tarflightstatenum);  //Ŀ��켣����
				fprintf(MissilePanelIniFileHandle, "\r\n");						

				for(int i=1;i<=Tarflightstatenum;i++)
				{   
					fprintf(MissilePanelIniFileHandle,"%lf ", TargetChangeStartTime[i]); 
					fprintf(MissilePanelIniFileHandle,"%lf ", TargetChangeEndTime[i]); 

					fprintf(MissilePanelIniFileHandle,"%lf ", TargetAccAmplitudeX[i]); 
					fprintf(MissilePanelIniFileHandle,"%lf ", TargetAccFrequencyX[i]); 
					fprintf(MissilePanelIniFileHandle,"%lf ", TargetAccPhaseX[i]); 
					fprintf(MissilePanelIniFileHandle,"%lf ", TargetAccAmplitudeY[i]); 
					fprintf(MissilePanelIniFileHandle,"%lf ", TargetAccFrequencyY[i]); 
					fprintf(MissilePanelIniFileHandle,"%lf ", TargetAccPhaseY[i]); 
					fprintf(MissilePanelIniFileHandle,"%lf ", TargetAccAmplitudeZ[i]); 
					fprintf(MissilePanelIniFileHandle,"%lf ", TargetAccFrequencyZ[i]); 
					fprintf(MissilePanelIniFileHandle,"%lf ", TargetAccPhaseZ[i]); 
				}
				fprintf(MissilePanelIniFileHandle, "\r\n");	
				//��ȡ�ļ�ģʽ·��
				GetCtrlVal (MissileSetPanelHandle, MisPANEL_MisDataPathName, MisDataFilePath);
				fprintf(MissilePanelIniFileHandle,"%s", MisDataFilePath); 

				fclose(MissilePanelIniFileHandle);
				DiscardPanel(MissileSetPanelHandle);
	
				DisplayPanel (MainPanelHandle); 
				SetPanelAttribute (MainPanelHandle, ATTR_WINDOW_ZOOM, VAL_MAXIMIZE);  
			}
   
			break;
	}
	return 0;
}

//�رհ�ť�ص�����
int CVICALLBACK MisGuiQuitCallback (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:
			MisNewRow=0;
			TarNewRow=0;
			DiscardPanel(MissileSetPanelHandle);
			
			DisplayPanel (MainPanelHandle); 
			SetPanelAttribute (MainPanelHandle, ATTR_WINDOW_ZOOM, VAL_MAXIMIZE);  
			break;
	}
	return 0;
}

//��λ��ť�ص�����
int CVICALLBACK MisTarResetCallback (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:
			MisNewRow=0;
			TarNewRow=0;
			Tarflightstatenum=0;
			MisFlightStateNum=0;
			DiscardPanel(MissileSetPanelHandle);
			MissileSetPanelHandle=LoadPanel(MainPanelHandle, "MISSILE_PANEL.uir",MisPANEL) ;
			InstallPopup(MissileSetPanelHandle); 
			break;
	}
	return 0;
}

//�����켣����ģʽѡ��
int CVICALLBACK MisFreeCallback (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:
			SetCtrlVal (MissileSetPanelHandle, MisPANEL_CHECKBOXMissileFree, 1);
			SetCtrlVal (MissileSetPanelHandle, MisPANEL_CHECKBOXMissileGui, 0);
			SetCtrlVal (MissileSetPanelHandle, MisPANEL_CHECKBOXMissileData, 0); 
			FreeModeDis(); 
			break;
	}
	return 0;
}

int CVICALLBACK MisGuiCallback (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:
			SetCtrlVal (MissileSetPanelHandle, MisPANEL_CHECKBOXMissileGui, 1); 
			SetCtrlVal (MissileSetPanelHandle, MisPANEL_CHECKBOXMissileFree, 0);
	    	SetCtrlVal (MissileSetPanelHandle, MisPANEL_CHECKBOXMissileData, 0); 
			GuiModeDis();
			break;
	}
	return 0;
}

int CVICALLBACK MisDataCallback (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:
			SetCtrlVal (MissileSetPanelHandle, MisPANEL_CHECKBOXMissileGui, 0); 
			SetCtrlVal (MissileSetPanelHandle, MisPANEL_CHECKBOXMissileFree, 0); 
			SetCtrlVal (MissileSetPanelHandle, MisPANEL_CHECKBOXMissileData, 1); 
			ReadModeDis();
			break;
	}
	return 0;
}

//***��������***//

//��������������ť 
int CVICALLBACK MisPraSavCallback (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{   
	char TempFilePath[260] = {0};  
	switch (event)
	{
		case EVENT_COMMIT:
			 
			 GetProjectDir (TempFilePath);
			 strcat(TempFilePath, "\\��������");
			 
	         stateMisParFileSelectPopup=FileSelectPopup (TempFilePath, "*.par", "*.par;*.txt", "���浼����������",  VAL_OK_BUTTON , 0, 0,
									   1, 0, MissileParFilePath);   // ѡ�񱣴�������ļ���resultΪ�洢�ѱ����ļ���·��
			 
			 GetCtrlVal(MissileSetPanelHandle,MisPANEL_CHECKBOXMissileFree,&MissileFreeFlightFlag);
			 GetCtrlVal(MissileSetPanelHandle,MisPANEL_CHECKBOXMissileGui,&MissileGuiFlightFlag);  
			 GetCtrlVal(MissileSetPanelHandle,MisPANEL_CHECKBOXMissileData,&MissileDataReadFlag);

			 GetCtrlVal(MissileSetPanelHandle,MisPANEL_NUMERICMisFlightTime,&MissileFreeFlightTime);
			 GetCtrlVal(MissileSetPanelHandle,MisPANEL_NUMERICMisGuiTime,&MissileGuiFlightTime);  
			 GetCtrlVal(MissileSetPanelHandle,MisPANEL_NUMERICMisFraOriLat,&FrameOriginLatitude);  
			 GetCtrlVal(MissileSetPanelHandle,MisPANEL_NUMERICMisNavRatio,&NavigationRatio);  
			 GetCtrlVal(MissileSetPanelHandle,MisPANEL_NUMERICMisIniVel,&MissileIniVel);  
			 GetCtrlVal(MissileSetPanelHandle,MisPANEL_NUMERICMisIniPosX,&MissileIniLon);  
			 GetCtrlVal(MissileSetPanelHandle,MisPANEL_NUMERICMisIniPosY,&MissileIniLat);  
			 GetCtrlVal(MissileSetPanelHandle,MisPANEL_NUMERICMisIniPosZ,&MissileIniAlt);  
			 GetCtrlVal(MissileSetPanelHandle,MisPANEL_NUMERICMisIniYaw,&MissileIniYaw);  
			 GetCtrlVal(MissileSetPanelHandle,MisPANEL_NUMERICMisIniPitch,&MissileIniPitch);  
			 GetCtrlVal(MissileSetPanelHandle,MisPANEL_NUMERICMisIniRoll,&MissileIniRoll); 	 			 
			 GetCtrlVal(MissileSetPanelHandle,MisPANEL_NUMERICMisStepSize,&MisStepTime);
			 
			 if (stateMisParFileSelectPopup!=0)
			 {
				 MisParFileHandle=fopen(MissileParFilePath,"wb");
				 
				 if(MissileFreeFlightFlag==1)
				 {
				     fprintf(MisParFileHandle,"%d", 0);
				 }
				 if(MissileGuiFlightFlag==1)
				 {
				     fprintf(MisParFileHandle,"%d", 1);
				 }
				 if(MissileDataReadFlag==1)
				 {
				     fprintf(MisParFileHandle,"%d", 2);
				 }	
				 
				 fprintf(MisParFileHandle,"%lf ", MissileFreeFlightTime); 
				 fprintf(MisParFileHandle,"%lf ", MissileGuiFlightTime); 
				 fprintf(MisParFileHandle,"%lf ", FrameOriginLatitude); 
				 fprintf(MisParFileHandle,"%lf ", NavigationRatio); 
				 fprintf(MisParFileHandle,"%lf ", MissileIniVel); 
				 fprintf(MisParFileHandle,"%lf ", MissileIniLon); 
				 fprintf(MisParFileHandle,"%lf ", MissileIniLat); 
				 fprintf(MisParFileHandle,"%lf ", MissileIniAlt); 
				 fprintf(MisParFileHandle,"%lf ", MissileIniYaw); 
				 fprintf(MisParFileHandle,"%lf ", MissileIniPitch); 
				 fprintf(MisParFileHandle,"%lf ", MissileIniRoll); 
				 fprintf(MisParFileHandle,"%lf ", MisStepTime); 
				 
		         fclose(MisParFileHandle);		 
			 }	 
			break;
	}
	return 0;
}

//���뵼��������ť
int CVICALLBACK MisPraRdCallback (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{   
	char TempFilePath[260] = {0}; 
	switch (event)
	{   
		case EVENT_COMMIT:
			

			 GetProjectDir (TempFilePath);
			 strcat(TempFilePath, "\\��������");	
			 
	         stateMisParFileSelectPopup=FileSelectPopup (TempFilePath, "*.par", "*.par;*.txt", "��ȡ������������",  VAL_OK_BUTTON , 0, 0,
									   1, 0, MissileParFilePath);   // ѡ���ȡ�����������ļ���resultΪ�洢�ѱ����ļ���·��
			 
             if (stateMisParFileSelectPopup!=0) 
			 {
				 MisParFileHandle=fopen(MissileParFilePath,"r");
				 
				 fscanf(MisParFileHandle,"%d ", &MisModeDisplay);  
				 
				 fscanf(MisParFileHandle,"%lf ", &MissileFreeFlightTime);   
				 fscanf(MisParFileHandle,"%lf ", &MissileGuiFlightTime);  
				 fscanf(MisParFileHandle,"%lf ", &FrameOriginLatitude);  
				 fscanf(MisParFileHandle,"%lf ", &NavigationRatio);  
				 fscanf(MisParFileHandle,"%lf ", &MissileIniVel);  
				 fscanf(MisParFileHandle,"%lf ", &MissileIniLon);  
				 fscanf(MisParFileHandle,"%lf ", &MissileIniLat);  
				 fscanf(MisParFileHandle,"%lf ", &MissileIniAlt);  
				 fscanf(MisParFileHandle,"%lf ", &MissileIniYaw);  
				 fscanf(MisParFileHandle,"%lf ", &MissileIniPitch);  
				 fscanf(MisParFileHandle,"%lf ", &MissileIniRoll);  
				 fscanf(MisParFileHandle,"%lf ", &MisStepTime);
				 
				 fclose(MisParFileHandle);		 
			 }	
			 switch(MisModeDisplay)
			 {
			 	 case MISFREE_MODE:
					 SetCtrlVal(MissileSetPanelHandle, MisPANEL_CHECKBOXMissileFree, 1);  
					 SetCtrlVal(MissileSetPanelHandle, MisPANEL_CHECKBOXMissileGui, 0);  
					 SetCtrlVal(MissileSetPanelHandle, MisPANEL_CHECKBOXMissileData, 0);
					 FreeModeDis();
					 break;
				 case MISGUI_MODE:
					 SetCtrlVal(MissileSetPanelHandle, MisPANEL_CHECKBOXMissileFree, 0);
					 SetCtrlVal(MissileSetPanelHandle, MisPANEL_CHECKBOXMissileGui, 1); 
					 SetCtrlVal(MissileSetPanelHandle, MisPANEL_CHECKBOXMissileData, 0);
					 GuiModeDis();
					 break;
				 case DATARD_MODE:
				 	 SetCtrlVal(MissileSetPanelHandle, MisPANEL_CHECKBOXMissileFree, 0);
				 	 SetCtrlVal(MissileSetPanelHandle, MisPANEL_CHECKBOXMissileGui, 0); 
				 	 SetCtrlVal(MissileSetPanelHandle, MisPANEL_CHECKBOXMissileData, 1);
					 ReadModeDis();
					 break;
			 }
			 SetCtrlVal(MissileSetPanelHandle, MisPANEL_NUMERICMisFlightTime, MissileFreeFlightTime);   
			 SetCtrlVal(MissileSetPanelHandle, MisPANEL_NUMERICMisGuiTime, MissileGuiFlightTime); 
			 SetCtrlVal(MissileSetPanelHandle, MisPANEL_NUMERICMisFraOriLat, FrameOriginLatitude); 
			 SetCtrlVal(MissileSetPanelHandle, MisPANEL_NUMERICMisNavRatio, NavigationRatio); 
			 SetCtrlVal(MissileSetPanelHandle, MisPANEL_NUMERICMisIniVel, MissileIniVel); 
			 SetCtrlVal(MissileSetPanelHandle, MisPANEL_NUMERICMisIniPosX, MissileIniLon); 
			 SetCtrlVal(MissileSetPanelHandle, MisPANEL_NUMERICMisIniPosY, MissileIniLat); 
			 SetCtrlVal(MissileSetPanelHandle, MisPANEL_NUMERICMisIniPosZ, MissileIniAlt); 
			 SetCtrlVal(MissileSetPanelHandle, MisPANEL_NUMERICMisIniYaw, MissileIniYaw); 
			 SetCtrlVal(MissileSetPanelHandle, MisPANEL_NUMERICMisIniPitch, MissileIniPitch); 
			 SetCtrlVal(MissileSetPanelHandle, MisPANEL_NUMERICMisIniRoll, MissileIniRoll);
			 SetCtrlVal(MissileSetPanelHandle, MisPANEL_NUMERICMisStepSize, MisStepTime);
			
			break;
	}
	return 0;
}

//���ӵ����켣��ť 
int CVICALLBACK MissileTraceProgrammingCallback (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:

		   MisFlightStateNum=MisFlightStateNum+1;
		   
		   GetCtrlVal(MissileSetPanelHandle,MisPANEL_NUMERICMisAccRangeX,&MisSFAmplitudeX[MisFlightStateNum]); //ȡ���������
		   GetCtrlVal(MissileSetPanelHandle,MisPANEL_NUMERICMisAccRangeY,&MisSFAmplitudeY[MisFlightStateNum]);
		   GetCtrlVal(MissileSetPanelHandle,MisPANEL_NUMERICMisAccRangeZ,&MisSFAmplitudeZ[MisFlightStateNum]);
		   GetCtrlVal(MissileSetPanelHandle,MisPANEL_NUMERICMisAccFreX,&MisSFFrequencyX[MisFlightStateNum]);
		   GetCtrlVal(MissileSetPanelHandle,MisPANEL_NUMERICMisAccFreY,&MisSFFrequencyY[MisFlightStateNum]);
		   GetCtrlVal(MissileSetPanelHandle,MisPANEL_NUMERICMisAccFreZ,&MisSFFrequencyZ[MisFlightStateNum]);
		   GetCtrlVal(MissileSetPanelHandle,MisPANEL_NUMERICMisAccPhaseX,&MisSFPhaseX[MisFlightStateNum]);
		   GetCtrlVal(MissileSetPanelHandle,MisPANEL_NUMERICMisAccPhaseY,&MisSFPhaseY[MisFlightStateNum]);
		   GetCtrlVal(MissileSetPanelHandle,MisPANEL_NUMERICMisAccPhaseZ,&MisSFPhaseZ[MisFlightStateNum]);
		   
		   GetCtrlVal(MissileSetPanelHandle,MisPANEL_NUMERICMisAdAngRangeX,&MisAngRateAmplitudeX[MisFlightStateNum]);
		   GetCtrlVal(MissileSetPanelHandle,MisPANEL_NUMERICMisAdAngRangeY,&MisAngRateAmplitudeY[MisFlightStateNum]);
		   GetCtrlVal(MissileSetPanelHandle,MisPANEL_NUMERICMisAdAngRangeZ,&MisAngRateAmplitudeZ[MisFlightStateNum]);
		   GetCtrlVal(MissileSetPanelHandle,MisPANEL_NUMERICMisAdAngFreX,&MisAngRateFrequencyX[MisFlightStateNum]);
		   GetCtrlVal(MissileSetPanelHandle,MisPANEL_NUMERICMisAdAngFreY,&MisAngRateFrequencyY[MisFlightStateNum]);
		   GetCtrlVal(MissileSetPanelHandle,MisPANEL_NUMERICMisAdAngFreZ,&MisAngRateFrequencyZ[MisFlightStateNum]);
		   GetCtrlVal(MissileSetPanelHandle,MisPANEL_NUMERICMisAdAngPhaseX,&MisAngRatePhaseX[MisFlightStateNum]);
		   GetCtrlVal(MissileSetPanelHandle,MisPANEL_NUMERICMisAdAngPhaseY,&MisAngRatePhaseY[MisFlightStateNum]);
		   GetCtrlVal(MissileSetPanelHandle,MisPANEL_NUMERICMisAdAngPhaseZ,&MisAngRatePhaseZ[MisFlightStateNum]);		   
		   
		   GetCtrlVal(MissileSetPanelHandle,MisPANEL_NUMERICMisFlightChaSt,&MissileChangeStartTime[MisFlightStateNum]);
		   GetCtrlVal(MissileSetPanelHandle,MisPANEL_NUMERICMisFlightChaEn,&MissileChangeEndTime[MisFlightStateNum]);
		  
		   MisTableWrite(MisFlightStateNum); 		 //����д�뵼���켣������
		  
		   break;
	}
	return 0;
}

//��������켣��ť
int CVICALLBACK MissileTraceDeleteCallback (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:
			 DeleteTableRows(MissileSetPanelHandle,MisPANEL_TABLE_Mis,1,-1);
			 MisNewRow=0;        //�������������MisNewRow���㣬��ɾ��Table�е�����ʱ�ᱨ����
			 MisFlightStateNum=0;// �ػ����й켣������
		     break;
	}
	return 0;
}

//���뵼���켣��ť
int CVICALLBACK MisTraRdCallback (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{   
	char TempFilePath[260] = {0}; 
	switch (event)
	{
		case EVENT_COMMIT:
			 
			 GetProjectDir (TempFilePath);
			 strcat(TempFilePath, "\\�����켣");
			
			 stateMisTraceSetFileSelectPopup=FileSelectPopup (TempFilePath, "*.tra", "*.tra", 
								 "��ȡ�����켣",VAL_OK_BUTTON,0,0,1,0,MissileTraceSetFilePath);   
			 
			 if (stateMisTraceSetFileSelectPopup!=0)
			 {
				 int j;
			     MisTraceSetFileHandle=fopen(MissileTraceSetFilePath,"r");
			 	
				 fscanf(MisTraceSetFileHandle,"%d", &MisSmoothTime); 
				 fscanf(MisTraceSetFileHandle,"%d", &MisFlightStateNum);   //�켣����
				  
				 for(int i=1;i<=MisFlightStateNum;i++) 
				 {
					fscanf(MisTraceSetFileHandle,"%d",&j);                  // �����ļ���ͷ��� 
					
					fscanf(MisTraceSetFileHandle,"%lf ", &MissileChangeStartTime[i]); 
					fscanf(MisTraceSetFileHandle,"%lf ", &MissileChangeEndTime[i]); 

					fscanf(MisTraceSetFileHandle,"%lf ", &MisSFAmplitudeX[i]);
					fscanf(MisTraceSetFileHandle,"%lf ", &MisSFAmplitudeY[i]);
					fscanf(MisTraceSetFileHandle,"%lf ", &MisSFAmplitudeZ[i]);
					fscanf(MisTraceSetFileHandle,"%lf ", &MisSFFrequencyX[i]);
					fscanf(MisTraceSetFileHandle,"%lf ", &MisSFFrequencyY[i]);
					fscanf(MisTraceSetFileHandle,"%lf ", &MisSFFrequencyZ[i]);
					fscanf(MisTraceSetFileHandle,"%lf ", &MisSFPhaseX[i]);
					fscanf(MisTraceSetFileHandle,"%lf ", &MisSFPhaseY[i]);
					fscanf(MisTraceSetFileHandle,"%lf ", &MisSFPhaseZ[i]);

					fscanf(MisTraceSetFileHandle,"%lf ", &MisAngRateAmplitudeX[i]);
					fscanf(MisTraceSetFileHandle,"%lf ", &MisAngRateAmplitudeY[i]);
					fscanf(MisTraceSetFileHandle,"%lf ", &MisAngRateAmplitudeZ[i]);
					fscanf(MisTraceSetFileHandle,"%lf ", &MisAngRateFrequencyX[i]);
					fscanf(MisTraceSetFileHandle,"%lf ", &MisAngRateFrequencyY[i]);
					fscanf(MisTraceSetFileHandle,"%lf ", &MisAngRateFrequencyZ[i]);
					fscanf(MisTraceSetFileHandle,"%lf ", &MisAngRatePhaseX[i]);
					fscanf(MisTraceSetFileHandle,"%lf ", &MisAngRatePhaseY[i]);
					fscanf(MisTraceSetFileHandle,"%lf ", &MisAngRatePhaseZ[i]);
					
					MisTableWrite(i);   //����д�뵼���켣������
				 }


				 fclose(MisTraceSetFileHandle); 
			 }
			break;
	}
	return 0;
}

//���������켣��ť  
int CVICALLBACK MisTraSaveCallback (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{   
		char TempFilePath[260] = {0}; 
		case EVENT_COMMIT:
			 
			 GetProjectDir (TempFilePath);
			 strcat(TempFilePath, "\\�����켣");
			 
			 stateMisTraceSetFileSelectPopup=FileSelectPopup (TempFilePath, "*.tra", "*.tra", 
				 "���浼���켣",VAL_OK_BUTTON,0,0,1,0,MissileTraceSetFilePath);   // ѡ�񱣴�켣���ļ���resultΪ�洢�ѱ����ļ���·��
			 										  
			 if (stateMisTraceSetFileSelectPopup!=0)
			 {
				 MisTraceSetFileHandle=fopen(MissileTraceSetFilePath,"wb");
			 
			 	 fprintf(MisTraceSetFileHandle,"%d ", MisSmoothTime); 
				 fprintf(MisTraceSetFileHandle,"%d ", MisFlightStateNum);  
				 fprintf(MisTraceSetFileHandle, "\r\n");						
			 
				 for(int i=1;i<=MisFlightStateNum;i++)
				 {   
					 fprintf(MisTraceSetFileHandle,"%d ", i);

					 fprintf(MisTraceSetFileHandle,"%lf ", MissileChangeStartTime[i]); 
					 fprintf(MisTraceSetFileHandle,"%lf ", MissileChangeEndTime[i]); 
		   
					 fprintf(MisTraceSetFileHandle,"%lf ", MisSFAmplitudeX[i]); 
					 fprintf(MisTraceSetFileHandle,"%lf ", MisSFAmplitudeY[i]);   
					 fprintf(MisTraceSetFileHandle,"%lf ", MisSFAmplitudeZ[i]);   
					 fprintf(MisTraceSetFileHandle,"%lf ", MisSFFrequencyX[i]); 
					 fprintf(MisTraceSetFileHandle,"%lf ", MisSFFrequencyY[i]);
					 fprintf(MisTraceSetFileHandle,"%lf ", MisSFFrequencyZ[i]);
					 fprintf(MisTraceSetFileHandle,"%lf ", MisSFPhaseX[i]); 
					 fprintf(MisTraceSetFileHandle,"%lf ", MisSFPhaseY[i]); 
					 fprintf(MisTraceSetFileHandle,"%lf ", MisSFPhaseZ[i]);
					 
					 fprintf(MisTraceSetFileHandle,"%lf ", MisAngRateAmplitudeX[i]); 
					 fprintf(MisTraceSetFileHandle,"%lf ", MisAngRateAmplitudeY[i]);   
					 fprintf(MisTraceSetFileHandle,"%lf ", MisAngRateAmplitudeZ[i]);   
					 fprintf(MisTraceSetFileHandle,"%lf ", MisAngRateFrequencyX[i]); 
					 fprintf(MisTraceSetFileHandle,"%lf ", MisAngRateFrequencyY[i]);
					 fprintf(MisTraceSetFileHandle,"%lf ", MisAngRateFrequencyZ[i]);
					 fprintf(MisTraceSetFileHandle,"%lf ", MisAngRatePhaseX[i]); 
					 fprintf(MisTraceSetFileHandle,"%lf ", MisAngRatePhaseY[i]); 
					 fprintf(MisTraceSetFileHandle,"%lf ", MisAngRatePhaseZ[i]); 
	
				 	 fprintf(MisTraceSetFileHandle, "\r\n");
			      }
			      fclose(MisTraceSetFileHandle);				 
		      }	 
			 	 
			break;
	}
	return 0;
}

//������ʵ�켣��ȡ��ť  ��ȡʵ�ʲ����Ĺ����������  
int CVICALLBACK MissileRealTraceRdCallback (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{   
	int status;   
	switch (event)
	{
		case EVENT_COMMIT:
										  
			status = MisDataFileSelectPopup=FileSelectPopup ("c:\\Documents and Settings\\Administrator\\����", "*.txt", "*.txt", 
									"��ȡ�̿ص�����",  VAL_OK_BUTTON , 0, 0, 1, 0, MisDataFilePath_Temp); 
			if(status != 0)
				SetCtrlVal (MissileSetPanelHandle, MisPANEL_MisDataPathName, MisDataFilePath_Temp);

			break;
	}
	return 0;
}

//***Ŀ�������***//

//����Ŀ���������ť
int CVICALLBACK TarPraRdCallback (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{   
	char TempFilePath[260] = {0}; 
	switch (event)
	{
		case EVENT_COMMIT:
					
			GetProjectDir (TempFilePath);
			strcat(TempFilePath, "\\Ŀ�������");	
			
			stateTarParFileSelectPopup=FileSelectPopup (TempFilePath, "*.par", "*.txt;*.par", "��ȡĿ�������",  VAL_OK_BUTTON , 0, 0,
											  1, 0, TargetParFilePath);   // ѡ�񱣴�������ļ���resultΪ�洢�ѱ����ļ���·�� 
		
			if(stateTarParFileSelectPopup==0)
			{
			// TarTraceSetFileHandle=fopen(TargetPra_FILE_PATH,"wb");
			}
			else
			{
				TarParFileHandle=fopen(TargetParFilePath,"r");
				
				fscanf(TarParFileHandle,"%lf ", &TargetIniLon);
				fscanf(TarParFileHandle,"%lf ", &TargetIniLat);  
				fscanf(TarParFileHandle,"%lf ", &TargetIniAlt);
				
				fscanf(TarParFileHandle,"%lf ", &TargetIniVelN);  
				fscanf(TarParFileHandle,"%lf ", &TargetIniVelU);  
				fscanf(TarParFileHandle,"%lf ", &TargetIniVelE);  

				fclose(TarParFileHandle);		 
			}	 
			SetCtrlVal(MissileSetPanelHandle, MisPANEL_NUMERICTarIniPosX,TargetIniLon); 
			SetCtrlVal(MissileSetPanelHandle, MisPANEL_NUMERICTarIniPosY,TargetIniLat);   
			SetCtrlVal(MissileSetPanelHandle, MisPANEL_NUMERICTarIniPosZ,TargetIniAlt);   
			SetCtrlVal(MissileSetPanelHandle, MisPANEL_NUMERICTarIniVelN,TargetIniVelN);    
			SetCtrlVal(MissileSetPanelHandle, MisPANEL_NUMERICTarIniVelU,TargetIniVelU);   
			SetCtrlVal(MissileSetPanelHandle, MisPANEL_NUMERICTarIniVelE,TargetIniVelE);   

			break;
	}
	return 0;
}

//����Ŀ���������ť  
int CVICALLBACK TarPraSavCallback (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{   
	char TempFilePath[260] = {0}; 
	switch (event)
	{
		case EVENT_COMMIT:
			
			GetProjectDir (TempFilePath);
			strcat(TempFilePath, "\\Ŀ�������");			
			
			stateTarParFileSelectPopup=FileSelectPopup (TempFilePath, "*.par", "*.txt;*.par", "�洢Ŀ�������",  VAL_OK_BUTTON , 0, 0,
								   1, 0, TargetParFilePath);   // ѡ�񱣴�������ļ���resultΪ�洢�ѱ����ļ���·��
		
			GetCtrlVal(MissileSetPanelHandle,MisPANEL_NUMERICTarIniPosX,&TargetIniLon);  
			GetCtrlVal(MissileSetPanelHandle,MisPANEL_NUMERICTarIniPosY,&TargetIniLat); 
			GetCtrlVal(MissileSetPanelHandle,MisPANEL_NUMERICTarIniPosZ,&TargetIniAlt);               //λ�� 

			GetCtrlVal(MissileSetPanelHandle,MisPANEL_NUMERICTarIniVelN,&TargetIniVelN);
			GetCtrlVal(MissileSetPanelHandle,MisPANEL_NUMERICTarIniVelU,&TargetIniVelU);  
			GetCtrlVal(MissileSetPanelHandle,MisPANEL_NUMERICTarIniVelE,&TargetIniVelE); 			  //�����
			
			if(stateTarParFileSelectPopup==0)
			{
			  //û����ȷ��·����������������
			}
			else
			{
				TarParFileHandle=fopen(TargetParFilePath,"wb"); 
				
				fprintf(TarParFileHandle,"%lf ", TargetIniLon); 
				fprintf(TarParFileHandle,"%lf ", TargetIniLat); 
				fprintf(TarParFileHandle,"%lf ", TargetIniAlt); 
				fprintf(TarParFileHandle,"%lf ", TargetIniVelN); 
				fprintf(TarParFileHandle,"%lf ", TargetIniVelU); 
				fprintf(TarParFileHandle,"%lf ", TargetIniVelE); 

				fclose(TarParFileHandle);		
			}
				 
			break;
	}
	return 0;
}

//����Ŀ����켣��ť
int CVICALLBACK TargetTraceProgrammingCallback (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:
		  
		   Tarflightstatenum=Tarflightstatenum+1;
		   
		   GetCtrlVal(MissileSetPanelHandle,MisPANEL_NUMERICTarAccRangeX,&TargetAccAmplitudeX[Tarflightstatenum]);
		   GetCtrlVal(MissileSetPanelHandle,MisPANEL_NUMERICTarAccRangeY,&TargetAccAmplitudeY[Tarflightstatenum]);
		   GetCtrlVal(MissileSetPanelHandle,MisPANEL_NUMERICTarAccRangeZ,&TargetAccAmplitudeZ[Tarflightstatenum]);
		   GetCtrlVal(MissileSetPanelHandle,MisPANEL_NUMERICTarAccFreX,&TargetAccFrequencyX[Tarflightstatenum]);
		   GetCtrlVal(MissileSetPanelHandle,MisPANEL_NUMERICTarAccFreY,&TargetAccFrequencyY[Tarflightstatenum]);
		   GetCtrlVal(MissileSetPanelHandle,MisPANEL_NUMERICTarAccFreZ,&TargetAccFrequencyZ[Tarflightstatenum]);
		   GetCtrlVal(MissileSetPanelHandle,MisPANEL_NUMERICTarAccPhaseX,&TargetAccPhaseX[Tarflightstatenum]);
		   GetCtrlVal(MissileSetPanelHandle,MisPANEL_NUMERICTarAccPhaseY,&TargetAccPhaseY[Tarflightstatenum]);
		   GetCtrlVal(MissileSetPanelHandle,MisPANEL_NUMERICTarAccPhaseZ,&TargetAccPhaseZ[Tarflightstatenum]);
		   
		   GetCtrlVal(MissileSetPanelHandle,MisPANEL_NUMERICTarStartTime,&TargetChangeStartTime[Tarflightstatenum]);
		   GetCtrlVal(MissileSetPanelHandle,MisPANEL_NUMERICTarEndTime,&TargetChangeEndTime[Tarflightstatenum]);
		  
		   TarNewRow=TarNewRow+1;  
		   InsertTableRows(MissileSetPanelHandle,MisPANEL_TABLE_Tar,TarNewRow,1,VAL_USE_MASTER_CELL_TYPE);//��켣�滮Table���м����µ�һ��

		   //ע���޸�Table��ÿһ�е�cell setting������
		   SetTableCellVal(MissileSetPanelHandle,MisPANEL_TABLE_Tar,MakePoint(1,TarNewRow),TargetChangeStartTime[Tarflightstatenum]);
		   SetTableCellVal(MissileSetPanelHandle,MisPANEL_TABLE_Tar,MakePoint(2,TarNewRow),TargetChangeEndTime[Tarflightstatenum]);
		   SetTableCellVal(MissileSetPanelHandle,MisPANEL_TABLE_Tar,MakePoint(3,TarNewRow),TargetAccAmplitudeX[Tarflightstatenum]);
		   SetTableCellVal(MissileSetPanelHandle,MisPANEL_TABLE_Tar,MakePoint(4,TarNewRow),TargetAccFrequencyX[Tarflightstatenum]);
		   SetTableCellVal(MissileSetPanelHandle,MisPANEL_TABLE_Tar,MakePoint(5,TarNewRow),TargetAccPhaseX[Tarflightstatenum]);
		   SetTableCellVal(MissileSetPanelHandle,MisPANEL_TABLE_Tar,MakePoint(6,TarNewRow),TargetAccAmplitudeY[Tarflightstatenum]); 
		   SetTableCellVal(MissileSetPanelHandle,MisPANEL_TABLE_Tar,MakePoint(7,TarNewRow),TargetAccFrequencyY[Tarflightstatenum]); 
		   SetTableCellVal(MissileSetPanelHandle,MisPANEL_TABLE_Tar,MakePoint(8,TarNewRow),TargetAccPhaseY[Tarflightstatenum]); 
		   SetTableCellVal(MissileSetPanelHandle,MisPANEL_TABLE_Tar,MakePoint(9,TarNewRow),TargetAccAmplitudeZ[Tarflightstatenum]); 
		   SetTableCellVal(MissileSetPanelHandle,MisPANEL_TABLE_Tar,MakePoint(10,TarNewRow),TargetAccFrequencyZ[Tarflightstatenum]); 
		   SetTableCellVal(MissileSetPanelHandle,MisPANEL_TABLE_Tar,MakePoint(11,TarNewRow),TargetAccPhaseZ[Tarflightstatenum]);  
		   break;   
	}
	return 0;
}

//���Ŀ����켣��ť
int CVICALLBACK TargetTraceDeleteCallback (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:
			 DeleteTableRows(MissileSetPanelHandle,MisPANEL_TABLE_Tar,1,-1);
			 TarNewRow=0; //�������������CraftNewRow���㣬��ɾ��Table�е�����ʱ�ᱨ����
			 Tarflightstatenum=0;// �ػ����й켣������

			break;
	}
	return 0;
}

//����Ŀ����켣��ť
int CVICALLBACK TarTraRdCallback (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{   
	char TempFilePath[260] = {0};
	switch (event)
	{
		case EVENT_COMMIT:
		
			GetProjectDir (TempFilePath);
			strcat(TempFilePath, "\\Ŀ����켣");
	        stateTarTraceSetFileSelectPopup=FileSelectPopup (TempFilePath, "*.tra", "*.txt;*.tra", "��ȡĿ����켣",  VAL_OK_BUTTON , 0, 0,
									   1, 0, TargetTraceSetFilePath);   // ѡ�񱣴�켣���ļ���resultΪ�洢�ѱ����ļ���·��
			
			if(stateTarTraceSetFileSelectPopup==0)
			{
			  // TarTraceSetFileHandle=fopen(TargetTrace_FILE_PATH,"r");    
			}
			else
			{
				int j;
				TarTraceSetFileHandle=fopen(TargetTraceSetFilePath,"r");

				fscanf(TarTraceSetFileHandle,"%d", &Tarflightstatenum);   //�켣����

				for(int i=1;i<=Tarflightstatenum;i++) 
				{
					fscanf(TarTraceSetFileHandle,"%d",&j);                  // �����ļ���ͷ��� 

					fscanf(TarTraceSetFileHandle,"%lf ", &TargetChangeStartTime[i]);
					fscanf(TarTraceSetFileHandle,"%lf ", &TargetChangeEndTime[i]);
					
					fscanf(TarTraceSetFileHandle,"%lf ", &TargetAccAmplitudeX[i]);
					fscanf(TarTraceSetFileHandle,"%lf ", &TargetAccFrequencyX[i]);
					fscanf(TarTraceSetFileHandle,"%lf ", &TargetAccPhaseX[i]);
					fscanf(TarTraceSetFileHandle,"%lf ", &TargetAccAmplitudeY[i]);
					fscanf(TarTraceSetFileHandle,"%lf ", &TargetAccFrequencyY[i]);
					fscanf(TarTraceSetFileHandle,"%lf ", &TargetAccPhaseY[i]);
					fscanf(TarTraceSetFileHandle,"%lf ", &TargetAccAmplitudeZ[i]);   
					fscanf(TarTraceSetFileHandle,"%lf ", &TargetAccFrequencyZ[i]);   
					fscanf(TarTraceSetFileHandle,"%lf ", &TargetAccPhaseZ[i]);   
				}
				fclose(TarTraceSetFileHandle);
			}
			
			for(int i=1;i<=Tarflightstatenum;i++)  
			{
				TarNewRow=TarNewRow+1;  
				InsertTableRows(MissileSetPanelHandle,MisPANEL_TABLE_Tar,TarNewRow,1,VAL_USE_MASTER_CELL_TYPE);//��켣�滮Table���м����µ�һ��

				//ע���޸�Table��ÿһ�е�cell setting������

				SetTableCellVal(MissileSetPanelHandle,MisPANEL_TABLE_Tar,MakePoint(1,TarNewRow),TargetChangeStartTime[i]);
				SetTableCellVal(MissileSetPanelHandle,MisPANEL_TABLE_Tar,MakePoint(2,TarNewRow),TargetChangeEndTime[i]);
				SetTableCellVal(MissileSetPanelHandle,MisPANEL_TABLE_Tar,MakePoint(3,TarNewRow),TargetAccAmplitudeX[i]);
				SetTableCellVal(MissileSetPanelHandle,MisPANEL_TABLE_Tar,MakePoint(4,TarNewRow),TargetAccFrequencyX[i]);
				SetTableCellVal(MissileSetPanelHandle,MisPANEL_TABLE_Tar,MakePoint(5,TarNewRow),TargetAccPhaseX[i]);
				SetTableCellVal(MissileSetPanelHandle,MisPANEL_TABLE_Tar,MakePoint(6,TarNewRow),TargetAccAmplitudeY[i]); 
				SetTableCellVal(MissileSetPanelHandle,MisPANEL_TABLE_Tar,MakePoint(7,TarNewRow),TargetAccFrequencyY[i]); 
				SetTableCellVal(MissileSetPanelHandle,MisPANEL_TABLE_Tar,MakePoint(8,TarNewRow),TargetAccPhaseY[i]); 
				SetTableCellVal(MissileSetPanelHandle,MisPANEL_TABLE_Tar,MakePoint(9,TarNewRow),TargetAccAmplitudeZ[i]); 
				SetTableCellVal(MissileSetPanelHandle,MisPANEL_TABLE_Tar,MakePoint(10,TarNewRow),TargetAccFrequencyZ[i]); 
				SetTableCellVal(MissileSetPanelHandle,MisPANEL_TABLE_Tar,MakePoint(11,TarNewRow),TargetAccPhaseZ[i]); 
			}
			break;
	}
	return 0;
}

//����Ŀ����켣��ť 
int CVICALLBACK TarTraSavCallback (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{   
	char TempFilePath[260] = {0}; 
	switch (event)
	{
		case EVENT_COMMIT:
				
			GetProjectDir (TempFilePath);
			strcat(TempFilePath, "\\Ŀ����켣");				
			stateTarTraceSetFileSelectPopup=FileSelectPopup (TempFilePath, "*.tra", "*.txt;*.tra", "�洢Ŀ����켣",  VAL_OK_BUTTON , 
															 0, 0,1, 0, TargetTraceSetFilePath);   
			
			if(stateTarTraceSetFileSelectPopup==0)
			{
		      // TarTraceSetFileHandle=fopen(TargetTrace_FILE_PATH,"wb");   				
			}
			else
			{
				TarTraceSetFileHandle=fopen(TargetTraceSetFilePath,"wb");
				
				fprintf(TarTraceSetFileHandle,"%d ", Tarflightstatenum);  //��Ŀ��켣�ļ��ĵ�һ��дĿ��켣����
				fprintf(TarTraceSetFileHandle, "\r\n");						

				for(int i=1;i<=Tarflightstatenum;i++)
				{   
					fprintf(TarTraceSetFileHandle,"%d ", i); 
					
					fprintf(TarTraceSetFileHandle,"%lf ", TargetChangeStartTime[i]); 
					fprintf(TarTraceSetFileHandle,"%lf ", TargetChangeEndTime[i]); 
					
					fprintf(TarTraceSetFileHandle,"%lf ", TargetAccAmplitudeX[i]); 
					fprintf(TarTraceSetFileHandle,"%lf ", TargetAccFrequencyX[i]); 
					fprintf(TarTraceSetFileHandle,"%lf ", TargetAccPhaseX[i]); 
					fprintf(TarTraceSetFileHandle,"%lf ", TargetAccAmplitudeY[i]); 
					fprintf(TarTraceSetFileHandle,"%lf ", TargetAccFrequencyY[i]); 
					fprintf(TarTraceSetFileHandle,"%lf ", TargetAccPhaseY[i]); 
					fprintf(TarTraceSetFileHandle,"%lf ", TargetAccAmplitudeZ[i]); 
					fprintf(TarTraceSetFileHandle,"%lf ", TargetAccFrequencyZ[i]); 
					fprintf(TarTraceSetFileHandle,"%lf ", TargetAccPhaseZ[i]); 
					
					fprintf(TarTraceSetFileHandle, "\r\n");
				}
				fclose(TarTraceSetFileHandle);  
			}

		break;
	}
	return 0;
}

//***���ú�������***//


void StructureDataInitial_Craft() 			  //����λ���������ص�RT��  
{
	CraftPara.SmoothTimePercent=SmoothTimePercent;

	CraftPara.CraftIniLongitude=CraftIniLongitude;
	CraftPara.CraftIniLatitude=CraftIniLatitude;
	CraftPara.CraftIniAltitude=CraftIniAltitude;
	
	CraftPara.CraftIniYaw=CraftIniYaw;    //ƫ����
	CraftPara.CraftIniPitch=CraftIniPitch;  //������
	CraftPara.CraftIniRoll=CraftIniRoll;   //��ת��	
	
	CraftPara.CraftPosition[0][0]=CraftIniLongitude;	//����ɽ���������ľ�γ�ȸ����ṹ��ʱ��λ����
	CraftPara.CraftPosition[1][0]=CraftIniLatitude;
	CraftPara.CraftPosition[2][0]=CraftIniAltitude;

	CraftPara.CraftIniForwardVelocity=CraftIniForwardVelocity; //��ʼǰ���ٶ�(�ػ�����ϵΪ��ǰ�ϣ�ǰ��Y��)
	
	CraftPara.CraftAttitude[0][0]=CraftIniYaw;    //ƫ����
	CraftPara.CraftAttitude[1][0]=CraftIniPitch;  //������
	CraftPara.CraftAttitude[2][0]=CraftIniRoll;   //��ת��

	CraftPara.CraftVelocity[0][0]=(CraftPara.CraftIniForwardVelocity)*cos(CraftPara.CraftAttitude[1][0])*sin(CraftPara.CraftAttitude[0][0]);
	CraftPara.CraftVelocity[1][0]=(CraftPara.CraftIniForwardVelocity)*cos(CraftPara.CraftAttitude[1][0])*cos(CraftPara.CraftAttitude[0][0]);
	CraftPara.CraftVelocity[2][0]=(CraftPara.CraftIniForwardVelocity)*sin(CraftPara.CraftAttitude[1][0]);

	CraftPara.CraftGyroConstDrift[0][0]=CraftGyroConstDrift[0][0];
	CraftPara.CraftGyroConstDrift[1][0]=CraftGyroConstDrift[1][0];
	CraftPara.CraftGyroConstDrift[2][0]=CraftGyroConstDrift[2][0];
		   
	CraftPara.CraftGyroRandomDrift[0][0]=CraftGyroRandomDrift[0][0];
	CraftPara.CraftGyroRandomDrift[1][0]=CraftGyroRandomDrift[1][0];
	CraftPara.CraftGyroRandomDrift[2][0]=CraftGyroRandomDrift[2][0];
		   
	CraftPara.CraftGyroScaleFactor[0][0]=CraftGyroScaleFactor[0][0];
	CraftPara.CraftGyroScaleFactor[1][0]=CraftGyroScaleFactor[1][0];
	CraftPara.CraftGyroScaleFactor[2][0]=CraftGyroScaleFactor[2][0];

	CraftPara.CraftAccelerometerConstBias[0][0]=CraftAccelerometerConstBias[0][0];
	CraftPara.CraftAccelerometerConstBias[1][0]=CraftAccelerometerConstBias[1][0];
	CraftPara.CraftAccelerometerConstBias[2][0]=CraftAccelerometerConstBias[2][0];
		   
	CraftPara.CraftAccelerometerScaleFactor[0][0]=CraftAccelerometerScaleFactor[0][0];
	CraftPara.CraftAccelerometerScaleFactor[1][0]=CraftAccelerometerScaleFactor[1][0];
	CraftPara.CraftAccelerometerScaleFactor[2][0]=CraftAccelerometerScaleFactor[2][0];
		   
	CraftPara.CraftAccelerometerRandomBias[0][0]=CraftAccelerometerRandomBias[0][0];
	CraftPara.CraftAccelerometerRandomBias[1][0]=CraftAccelerometerRandomBias[1][0];
	CraftPara.CraftAccelerometerRandomBias[2][0]=CraftAccelerometerRandomBias[2][0];	
	
	CraftPara.CraftAccelerometerQuantizationFactor=CraftAccelerometerQuantizationFactor;
	CraftPara.CraftGyroQuantizationFactor=CraftGyroQuantizationFactor;

			
	CraftPara.MissileMountAngle[0][0]= MissileMountAngle[0][0];
	CraftPara.MissileMountAngle[1][0]= MissileMountAngle[1][0];
	CraftPara.MissileMountAngle[2][0]= MissileMountAngle[2][0];
		   
	CraftPara.NominalLeverArm[0][0]=NominalLeverArm[0][0];
	CraftPara.NominalLeverArm[1][0]=NominalLeverArm[1][0];
	CraftPara.NominalLeverArm[2][0]=NominalLeverArm[2][0];	
		   
	CraftPara.MissileMountAngleError[0][0]=MissileMountAngleError[0][0];
	CraftPara.MissileMountAngleError[1][0]=MissileMountAngleError[1][0];
	CraftPara.MissileMountAngleError[2][0]=MissileMountAngleError[2][0];
			 
	CraftPara.LeverArmLengthError[0][0]=LeverArmLengthError[0][0];
	CraftPara.LeverArmLengthError[1][0]=LeverArmLengthError[1][0];
	CraftPara.LeverArmLengthError[2][0]=LeverArmLengthError[2][0];		   
		   
	CraftPara.MissileAccelerometerQuantizationFactor=MissileAccelerometerQuantizationFactor;

	CraftPara.RotaryAmp[0]=RotaryAmp[0];
	CraftPara.RotaryAmp[1]=RotaryAmp[1];
	CraftPara.RotaryAmp[2]=RotaryAmp[2];
		   
	CraftPara.RotaryFre[0]=RotaryFre[0];
	CraftPara.RotaryFre[1]=RotaryFre[1];
	CraftPara.RotaryFre[2]=RotaryFre[2];
		   
	CraftPara.RotaryPha[0]=RotaryPha[0];
	CraftPara.RotaryPha[1]=RotaryPha[1];
	CraftPara.RotaryPha[2]=RotaryPha[2];
		   
	CraftPara.MissileGyroCrossCoupling[0][0]=MissileGyroCrossCoupling[0][1];
	CraftPara.MissileGyroCrossCoupling[0][0]=MissileGyroCrossCoupling[0][2];
	CraftPara.MissileGyroCrossCoupling[0][0]=MissileGyroCrossCoupling[1][0];
	CraftPara.MissileGyroCrossCoupling[0][0]=MissileGyroCrossCoupling[1][2];
	CraftPara.MissileGyroCrossCoupling[0][0]=MissileGyroCrossCoupling[2][0];
	CraftPara.MissileGyroCrossCoupling[0][0]=MissileGyroCrossCoupling[2][1];
		   
	CraftPara.MissileGyroQuantizationFactor=MissileGyroQuantizationFactor;	
		   
	CraftPara.SimulationStartTime=SimulationStartTime; 
	CraftPara.CraNavStartTime=CraNavStartTime;
	CraftPara.CraNavEndTime=CraNavEndTime;
	CraftPara.FcsNavStartTime=FcsNavStartTime;
	CraftPara.FcsNavEndTime=FcsNavEndTime;
	CraftPara.TransferAlignmentStartTime=TransferAlignmentStartTime;
	CraftPara.TransferAlignmentTime=TransferAlignmentTime; 			 

	CraftPara.CraftTraceStepSize=CraftTraceStepSize;
	CraftPara.CraftNavigationStepSize=CraftNavigationStepSize;
	CraftPara.FcsNavigationStepSize=FcsNavigationStepSize;
	CraftPara.FcsOutputStepSize=FcsOutputStepSize;
	
	for(int i=1;i<=CraftFlightStateNum;i++)																			    
	{   																					   
		CraftTrace.CraftFlightStateNum=CraftFlightStateNum;
		CraftTrace.CraftFlightState[i]=CraftFlightState[i];
		CraftTrace.EachCraftTraceTime[i]=EachCraftTraceTime[i];
		CraftTrace.CraftForwardAccelerationExpect[i]=CraftForwardAccelerationExpect[i];
		CraftTrace.CraftAttitudeChange[0][i]=CraftAttitudeChange[0][i];
		CraftTrace.CraftAttitudeChange[1][i]=CraftAttitudeChange[1][i];
		CraftTrace.CraftAttitudeChange[2][i]=CraftAttitudeChange[2][i];
	}
}									  

void StructureDataInitial_Missile(void)
{
	MisPara.MissileIniLon = MissileIniLon;
	MisPara.MissileIniLat = MissileIniLat;
	MisPara.MissileIniAlt = MissileIniAlt;
	MisPara.MissileIniVel = MissileIniVel;
	MisPara.MissileIniYaw = MissileIniYaw;
	MisPara.MissileIniPitch = MissileIniPitch;
	MisPara.MissileIniRoll = MissileIniRoll;
	MisPara.FrameOriginLatitude = FrameOriginLatitude;
	MisPara.MisStepTime = MisStepTime;
	switch(TraceModeSelect)
	{
	    case MISFREE_MODE:
			MisPara.MissileFreeFlightTime = MissileFreeFlightTime;
			MisTrace.MisSmoothTime = MisSmoothTime; 
			MisTrace.MisFlightStateNum = MisFlightStateNum;  
			for(int i=1;i<=MisFlightStateNum;i++)	
			{   
				MisTrace.MissileChangeStartTime[i]=MissileChangeStartTime[i];
				MisTrace.MissileChangeEndTime[i]=MissileChangeEndTime[i]; 

				MisTrace.MisSFAmplitudeX[i]=MisSFAmplitudeX[i]; 
				MisTrace.MisSFAmplitudeY[i]=MisSFAmplitudeY[i]; 
				MisTrace.MisSFAmplitudeZ[i]=MisSFAmplitudeZ[i]; 
				MisTrace.MisSFFrequencyX[i]=MisSFFrequencyX[i]; 
				MisTrace.MisSFFrequencyY[i]=MisSFFrequencyY[i]; 
				MisTrace.MisSFFrequencyZ[i]=MisSFFrequencyZ[i]; 
				MisTrace.MisSFPhaseX[i]=MisSFPhaseX[i]; 
				MisTrace.MisSFPhaseY[i]=MisSFPhaseY[i]; 
				MisTrace.MisSFPhaseZ[i]=MisSFPhaseZ[i];

				MisTrace.MisAngRateAmplitudeX[i]=MisAngRateAmplitudeX[i]; 
				MisTrace.MisAngRateAmplitudeY[i]=MisAngRateAmplitudeY[i]; 
				MisTrace.MisAngRateAmplitudeZ[i]=MisAngRateAmplitudeZ[i]; 
				MisTrace.MisAngRateFrequencyX[i]=MisAngRateFrequencyX[i]; 
				MisTrace.MisAngRateFrequencyY[i]=MisAngRateFrequencyY[i]; 
			  	MisTrace.MisAngRateFrequencyZ[i]=MisAngRateFrequencyZ[i];  	
			  	MisTrace.MisAngRatePhaseX[i]=MisAngRatePhaseX[i];  
				MisTrace.MisAngRatePhaseY[i]=MisAngRatePhaseY[i];  
				MisTrace.MisAngRatePhaseZ[i]=MisAngRatePhaseZ[i];  
			} 
			break;
		case MISGUI_MODE:
			
			MisPara.MissileGuiFlightTime=MissileGuiFlightTime;
			MisPara.NavigationRatio=NavigationRatio;

			TarData.TargetIniLon=TargetIniLon;
			TarData.TargetIniLat=TargetIniLat;
			TarData.TargetIniAlt=TargetIniAlt;

			TarData.TargetIniVelN=TargetIniVelN;
			TarData.TargetIniVelU=TargetIniVelU;
			TarData.TargetIniVelE=TargetIniVelE;

			TarData.Tarflightstatenum=Tarflightstatenum; 
			
			for(int i=1;i<=Tarflightstatenum;i++)
			{   
				TarData.TargetChangeStartTime[i]=TargetChangeStartTime[i];
				TarData.TargetChangeEndTime[i]=TargetChangeEndTime[i]; 

				TarData.TargetAccAmplitudeX[i]=TargetAccAmplitudeX[i];  
				TarData.TargetAccFrequencyX[i]=TargetAccFrequencyX[i];  
				TarData.TargetAccPhaseX[i]=TargetAccPhaseX[i];  
				TarData.TargetAccAmplitudeY[i]=TargetAccAmplitudeY[i];  
				TarData.TargetAccFrequencyY[i]=TargetAccFrequencyY[i];  
				TarData.TargetAccPhaseY[i]=TargetAccPhaseY[i];  
				TarData.TargetAccAmplitudeZ[i]=TargetAccAmplitudeZ[i];  
				TarData.TargetAccFrequencyZ[i]=TargetAccFrequencyZ[i];  
				TarData.TargetAccPhaseZ[i]=TargetAccPhaseZ[i];
			}
			break;
	}
}

void InitialMissileVariable(void)		      //�����켣������ʼ��
{
	MissilePanelIniFileHandle=fopen(MissilePanelIni_FILE_PATH,"r");
	
	fscanf(MissilePanelIniFileHandle,"%d " , &MisModeDisplay);   	
	
	fscanf(MissilePanelIniFileHandle,"%lf ", &MissileIniLon);  
	fscanf(MissilePanelIniFileHandle,"%lf ", &MissileIniLat);  
	fscanf(MissilePanelIniFileHandle,"%lf ", &MissileIniAlt); 
	fscanf(MissilePanelIniFileHandle,"%lf ", &MissileIniVel); 
	fscanf(MissilePanelIniFileHandle,"%lf ", &MissileIniYaw);  
	fscanf(MissilePanelIniFileHandle,"%lf ", &MissileIniPitch);  
	fscanf(MissilePanelIniFileHandle,"%lf ", &MissileIniRoll);  
	fscanf(MissilePanelIniFileHandle,"%lf ", &FrameOriginLatitude);  
	fscanf(MissilePanelIniFileHandle,"%lf ", &MisStepTime);


	//���ɷ���ģʽ
	fscanf(MissilePanelIniFileHandle,"%lf " , &MissileFreeFlightTime);
	fscanf(MissilePanelIniFileHandle,"%lf" ,  &MisSmoothTime); 
	fscanf(MissilePanelIniFileHandle,"%d " ,  &MisFlightStateNum);
	
	for(int i=1;i<=MisFlightStateNum;i++) 
	{
		fscanf(MissilePanelIniFileHandle,"%lf ", &MissileChangeStartTime[i]); 
		fscanf(MissilePanelIniFileHandle,"%lf ", &MissileChangeEndTime[i]); 

		fscanf(MissilePanelIniFileHandle,"%lf ", &MisSFAmplitudeX[i]);
		fscanf(MissilePanelIniFileHandle,"%lf ", &MisSFAmplitudeY[i]);
		fscanf(MissilePanelIniFileHandle,"%lf ", &MisSFAmplitudeZ[i]);
		fscanf(MissilePanelIniFileHandle,"%lf ", &MisSFFrequencyX[i]);
		fscanf(MissilePanelIniFileHandle,"%lf ", &MisSFFrequencyY[i]);
		fscanf(MissilePanelIniFileHandle,"%lf ", &MisSFFrequencyZ[i]);
		fscanf(MissilePanelIniFileHandle,"%lf ", &MisSFPhaseX[i]);
		fscanf(MissilePanelIniFileHandle,"%lf ", &MisSFPhaseY[i]);
		fscanf(MissilePanelIniFileHandle,"%lf ", &MisSFPhaseZ[i]);

		fscanf(MissilePanelIniFileHandle,"%lf ", &MisAngRateAmplitudeX[i]);
		fscanf(MissilePanelIniFileHandle,"%lf ", &MisAngRateAmplitudeY[i]);
		fscanf(MissilePanelIniFileHandle,"%lf ", &MisAngRateAmplitudeZ[i]);
		fscanf(MissilePanelIniFileHandle,"%lf ", &MisAngRateFrequencyX[i]);
		fscanf(MissilePanelIniFileHandle,"%lf ", &MisAngRateFrequencyY[i]);
		fscanf(MissilePanelIniFileHandle,"%lf ", &MisAngRateFrequencyZ[i]);
		fscanf(MissilePanelIniFileHandle,"%lf ", &MisAngRatePhaseX[i]);
		fscanf(MissilePanelIniFileHandle,"%lf ", &MisAngRatePhaseY[i]);
		fscanf(MissilePanelIniFileHandle,"%lf ", &MisAngRatePhaseZ[i]);
	}

	//�Ƶ�����ģʽ
    fscanf(MissilePanelIniFileHandle,"%lf " , &MissileGuiFlightTime);
	fscanf(MissilePanelIniFileHandle,"%lf " , &NavigationRatio);
	
	fscanf(MissilePanelIniFileHandle,"%lf " , &TargetIniLon);
	fscanf(MissilePanelIniFileHandle,"%lf " , &TargetIniLat);
	fscanf(MissilePanelIniFileHandle,"%lf " , &TargetIniAlt);

	fscanf(MissilePanelIniFileHandle,"%lf " , &TargetIniVelN);
	fscanf(MissilePanelIniFileHandle,"%lf " , &TargetIniVelU);
	fscanf(MissilePanelIniFileHandle,"%lf " , &TargetIniVelE);
  
	fscanf(MissilePanelIniFileHandle,"%d " , &Tarflightstatenum);
	
	for(int i=1;i<=Tarflightstatenum;i++) 
	{
		fscanf(MissilePanelIniFileHandle,"%lf ", &TargetChangeStartTime[i]);
		fscanf(MissilePanelIniFileHandle,"%lf ", &TargetChangeEndTime[i]);
		
		fscanf(MissilePanelIniFileHandle,"%lf ", &TargetAccAmplitudeX[i]);
		fscanf(MissilePanelIniFileHandle,"%lf ", &TargetAccFrequencyX[i]);
		fscanf(MissilePanelIniFileHandle,"%lf ", &TargetAccPhaseX[i]);
		fscanf(MissilePanelIniFileHandle,"%lf ", &TargetAccAmplitudeY[i]);
		fscanf(MissilePanelIniFileHandle,"%lf ", &TargetAccFrequencyY[i]);
		fscanf(MissilePanelIniFileHandle,"%lf ", &TargetAccPhaseY[i]);
		fscanf(MissilePanelIniFileHandle,"%lf ", &TargetAccAmplitudeZ[i]);   
		fscanf(MissilePanelIniFileHandle,"%lf ", &TargetAccFrequencyZ[i]);   
		fscanf(MissilePanelIniFileHandle,"%lf ", &TargetAccPhaseZ[i]);   
	}
	
	//���ļ�ģʽ
	fread(MisDataFilePath, 1, 260, MissilePanelIniFileHandle);
	fclose(MissilePanelIniFileHandle);
}

void SetVariableToPanel(void)				  //�����켣����ֵ�����ʾ
{
	if(MisModeDisplay == MISFREE_MODE)
	{
	 SetCtrlVal(MissileSetPanelHandle, MisPANEL_CHECKBOXMissileFree, 1);   
	 SetCtrlVal(MissileSetPanelHandle, MisPANEL_CHECKBOXMissileGui, 0);  
	 SetCtrlVal(MissileSetPanelHandle, MisPANEL_CHECKBOXMissileData, 0); 
	 FreeModeDis();  
	}
	if(MisModeDisplay == MISGUI_MODE)
	{
	 SetCtrlVal(MissileSetPanelHandle, MisPANEL_CHECKBOXMissileFree, 0);   
	 SetCtrlVal(MissileSetPanelHandle, MisPANEL_CHECKBOXMissileGui, 1);  
	 SetCtrlVal(MissileSetPanelHandle, MisPANEL_CHECKBOXMissileData, 0); 
	 GuiModeDis(); 
	}
	if(MisModeDisplay == DATARD_MODE)
	{
		SetCtrlVal(MissileSetPanelHandle, MisPANEL_CHECKBOXMissileFree, 0);   
		SetCtrlVal(MissileSetPanelHandle, MisPANEL_CHECKBOXMissileGui, 0);  
		SetCtrlVal(MissileSetPanelHandle, MisPANEL_CHECKBOXMissileData, 1);
		ReadModeDis();  
	}
	
	SetCtrlVal(MissileSetPanelHandle, MisPANEL_NUMERICMisIniPosX, MissileIniLon); 
	SetCtrlVal(MissileSetPanelHandle, MisPANEL_NUMERICMisIniPosY, MissileIniLat); 
	SetCtrlVal(MissileSetPanelHandle, MisPANEL_NUMERICMisIniPosZ, MissileIniAlt); 
	SetCtrlVal(MissileSetPanelHandle, MisPANEL_NUMERICMisIniVel, MissileIniVel); 
	SetCtrlVal(MissileSetPanelHandle, MisPANEL_NUMERICMisIniYaw, MissileIniYaw); 
	SetCtrlVal(MissileSetPanelHandle, MisPANEL_NUMERICMisIniPitch, MissileIniPitch); 
	SetCtrlVal(MissileSetPanelHandle, MisPANEL_NUMERICMisIniRoll, MissileIniRoll);
	SetCtrlVal(MissileSetPanelHandle, MisPANEL_NUMERICMisFraOriLat, FrameOriginLatitude); 
	SetCtrlVal(MissileSetPanelHandle, MisPANEL_NUMERICMisStepSize, MisStepTime);
	
	SetCtrlVal(MissileSetPanelHandle, MisPANEL_NUMERICMisFlightTime, MissileFreeFlightTime);
	SetCtrlVal(MissileSetPanelHandle, MisPANEL_NUMERICMisSmoothTime, MisSmoothTime); 
	
	for(int i=1;i<=MisFlightStateNum;i++) 
	{
		MisTableWrite(i);   //����д�뵼���켣������
	}
	
	SetCtrlVal(MissileSetPanelHandle, MisPANEL_NUMERICMisGuiTime, MissileGuiFlightTime); 
	SetCtrlVal(MissileSetPanelHandle, MisPANEL_NUMERICMisNavRatio, NavigationRatio); 
	
	SetCtrlVal(MissileSetPanelHandle, MisPANEL_NUMERICTarIniPosX,TargetIniLon); 
	SetCtrlVal(MissileSetPanelHandle, MisPANEL_NUMERICTarIniPosY,TargetIniLat);   
	SetCtrlVal(MissileSetPanelHandle, MisPANEL_NUMERICTarIniPosZ,TargetIniAlt);   
	SetCtrlVal(MissileSetPanelHandle, MisPANEL_NUMERICTarIniVelN,TargetIniVelN);    
	SetCtrlVal(MissileSetPanelHandle, MisPANEL_NUMERICTarIniVelU,TargetIniVelU);   
	SetCtrlVal(MissileSetPanelHandle, MisPANEL_NUMERICTarIniVelE,TargetIniVelE);   

	for(int i=1;i<=Tarflightstatenum;i++)  
	{
		TarNewRow=TarNewRow+1;  
		InsertTableRows(MissileSetPanelHandle,MisPANEL_TABLE_Tar,TarNewRow,1,VAL_USE_MASTER_CELL_TYPE);

		SetTableCellVal(MissileSetPanelHandle,MisPANEL_TABLE_Tar,MakePoint(1,TarNewRow),TargetChangeStartTime[i]);
		SetTableCellVal(MissileSetPanelHandle,MisPANEL_TABLE_Tar,MakePoint(2,TarNewRow),TargetChangeEndTime[i]);
		SetTableCellVal(MissileSetPanelHandle,MisPANEL_TABLE_Tar,MakePoint(3,TarNewRow),TargetAccAmplitudeX[i]);
		SetTableCellVal(MissileSetPanelHandle,MisPANEL_TABLE_Tar,MakePoint(4,TarNewRow),TargetAccFrequencyX[i]);
		SetTableCellVal(MissileSetPanelHandle,MisPANEL_TABLE_Tar,MakePoint(5,TarNewRow),TargetAccPhaseX[i]);
		SetTableCellVal(MissileSetPanelHandle,MisPANEL_TABLE_Tar,MakePoint(6,TarNewRow),TargetAccAmplitudeY[i]); 
		SetTableCellVal(MissileSetPanelHandle,MisPANEL_TABLE_Tar,MakePoint(7,TarNewRow),TargetAccFrequencyY[i]); 
		SetTableCellVal(MissileSetPanelHandle,MisPANEL_TABLE_Tar,MakePoint(8,TarNewRow),TargetAccPhaseY[i]); 
		SetTableCellVal(MissileSetPanelHandle,MisPANEL_TABLE_Tar,MakePoint(9,TarNewRow),TargetAccAmplitudeZ[i]); 
		SetTableCellVal(MissileSetPanelHandle,MisPANEL_TABLE_Tar,MakePoint(10,TarNewRow),TargetAccFrequencyZ[i]); 
		SetTableCellVal(MissileSetPanelHandle,MisPANEL_TABLE_Tar,MakePoint(11,TarNewRow),TargetAccPhaseZ[i]); 
	}
	
	SetCtrlVal(MissileSetPanelHandle, MisPANEL_MisDataPathName,MisDataFilePath);     
}

void MisTableWrite(TempMisTraceNum)	          //������������д�뺯��
	{
		MisNewRow=MisNewRow+1;       			 

		//��켣�滮Table���м����µ�һ�� 	  
		InsertTableRows(MissileSetPanelHandle,MisPANEL_TABLE_Mis,MisNewRow,1,VAL_USE_MASTER_CELL_TYPE);
		//ע���޸�Table��ÿһ�е�cell setting������
		sprintf(&MisChinese[0], "%s", "��λ"); 
		SetTableCellVal(MissileSetPanelHandle,MisPANEL_TABLE_Mis,MakePoint(3,MisNewRow),&MisChinese[0]);
		SetTableCellVal(MissileSetPanelHandle,MisPANEL_TABLE_Mis,MakePoint(4,MisNewRow),MisSFPhaseX[TempMisTraceNum]);
		SetTableCellVal(MissileSetPanelHandle,MisPANEL_TABLE_Mis,MakePoint(5,MisNewRow),MisSFPhaseY[TempMisTraceNum]);
		SetTableCellVal(MissileSetPanelHandle,MisPANEL_TABLE_Mis,MakePoint(6,MisNewRow),MisSFPhaseZ[TempMisTraceNum]);
		SetTableCellVal(MissileSetPanelHandle,MisPANEL_TABLE_Mis,MakePoint(7,MisNewRow),MisAngRatePhaseX[TempMisTraceNum]);
		SetTableCellVal(MissileSetPanelHandle,MisPANEL_TABLE_Mis,MakePoint(8,MisNewRow),MisAngRatePhaseY[TempMisTraceNum]);
		SetTableCellVal(MissileSetPanelHandle,MisPANEL_TABLE_Mis,MakePoint(9,MisNewRow),MisAngRatePhaseZ[TempMisTraceNum]);

		InsertTableRows(MissileSetPanelHandle,MisPANEL_TABLE_Mis,MisNewRow,1,VAL_USE_MASTER_CELL_TYPE);
		//ע���޸�Table��ÿһ�е�cell setting������
		sprintf(&MisChinese[0], "%s", "Ƶ��"); 
		SetTableCellVal(MissileSetPanelHandle,MisPANEL_TABLE_Mis,MakePoint(3,MisNewRow),&MisChinese[0]);
		SetTableCellVal(MissileSetPanelHandle,MisPANEL_TABLE_Mis,MakePoint(4,MisNewRow),MisSFFrequencyX[TempMisTraceNum]);
		SetTableCellVal(MissileSetPanelHandle,MisPANEL_TABLE_Mis,MakePoint(5,MisNewRow),MisSFFrequencyY[TempMisTraceNum]);
		SetTableCellVal(MissileSetPanelHandle,MisPANEL_TABLE_Mis,MakePoint(6,MisNewRow),MisSFFrequencyZ[TempMisTraceNum]);
		SetTableCellVal(MissileSetPanelHandle,MisPANEL_TABLE_Mis,MakePoint(7,MisNewRow),MisAngRateFrequencyX[TempMisTraceNum]);
		SetTableCellVal(MissileSetPanelHandle,MisPANEL_TABLE_Mis,MakePoint(8,MisNewRow),MisAngRateFrequencyY[TempMisTraceNum]);
		SetTableCellVal(MissileSetPanelHandle,MisPANEL_TABLE_Mis,MakePoint(9,MisNewRow),MisAngRateFrequencyZ[TempMisTraceNum]);

		InsertTableRows(MissileSetPanelHandle,MisPANEL_TABLE_Mis,MisNewRow,1,VAL_USE_MASTER_CELL_TYPE);
		//ע���޸�Table��ÿһ�е�cell setting������
		sprintf(&MisChinese[0], "%s", "��ֵ");
		SetTableCellVal(MissileSetPanelHandle,MisPANEL_TABLE_Mis,MakePoint(1,MisNewRow),MissileChangeStartTime[TempMisTraceNum]);
		SetTableCellVal(MissileSetPanelHandle,MisPANEL_TABLE_Mis,MakePoint(2,MisNewRow),MissileChangeEndTime[TempMisTraceNum]);
		SetTableCellVal(MissileSetPanelHandle,MisPANEL_TABLE_Mis,MakePoint(3,MisNewRow),&MisChinese[0]);
		SetTableCellVal(MissileSetPanelHandle,MisPANEL_TABLE_Mis,MakePoint(4,MisNewRow),MisSFAmplitudeX[TempMisTraceNum]);
		SetTableCellVal(MissileSetPanelHandle,MisPANEL_TABLE_Mis,MakePoint(5,MisNewRow),MisSFAmplitudeY[TempMisTraceNum]);
		SetTableCellVal(MissileSetPanelHandle,MisPANEL_TABLE_Mis,MakePoint(6,MisNewRow),MisSFAmplitudeZ[TempMisTraceNum]);
		SetTableCellVal(MissileSetPanelHandle,MisPANEL_TABLE_Mis,MakePoint(7,MisNewRow),MisAngRateAmplitudeX[TempMisTraceNum]);
		SetTableCellVal(MissileSetPanelHandle,MisPANEL_TABLE_Mis,MakePoint(8,MisNewRow),MisAngRateAmplitudeY[TempMisTraceNum]);
		SetTableCellVal(MissileSetPanelHandle,MisPANEL_TABLE_Mis,MakePoint(9,MisNewRow),MisAngRateAmplitudeZ[TempMisTraceNum]);

		MisNewRow=MisNewRow+2; 			 //ȷ����һ�����Ӵ������Ժ�ʼ		
	}

void GuiModeDis(void)                         //�����Ƶ�ģʽ������ʾ		        	 
 	{
		SetCtrlAttribute (MissileSetPanelHandle, MisPANEL_NUMERICMisIniVel, ATTR_TEXT_BOLD, 1); 
		SetCtrlAttribute (MissileSetPanelHandle, MisPANEL_NUMERICMisStepSize, ATTR_TEXT_BOLD, 1); 
		SetCtrlAttribute (MissileSetPanelHandle, MisPANEL_NUMERICMisIniPosX, ATTR_TEXT_BOLD, 1); 
		SetCtrlAttribute (MissileSetPanelHandle, MisPANEL_NUMERICMisIniPosY, ATTR_TEXT_BOLD, 1); 
		SetCtrlAttribute (MissileSetPanelHandle, MisPANEL_NUMERICMisIniPosZ, ATTR_TEXT_BOLD, 1); 
		SetCtrlAttribute (MissileSetPanelHandle, MisPANEL_NUMERICMisIniYaw, ATTR_TEXT_BOLD, 1); 
		SetCtrlAttribute (MissileSetPanelHandle, MisPANEL_NUMERICMisIniPitch, ATTR_TEXT_BOLD, 1); 
		SetCtrlAttribute (MissileSetPanelHandle, MisPANEL_NUMERICMisIniRoll, ATTR_TEXT_BOLD, 1); 		
		
		SetCtrlAttribute (MissileSetPanelHandle, MisPANEL_NUMERICMisSmoothTime, ATTR_TEXT_BOLD, 0); 
		SetCtrlAttribute (MissileSetPanelHandle, MisPANEL_NUMERICMisFlightTime, ATTR_TEXT_BOLD, 0); 
		SetCtrlAttribute (MissileSetPanelHandle, MisPANEL_NUMERICMisGuiTime, ATTR_TEXT_BOLD, 1); 
		SetCtrlAttribute (MissileSetPanelHandle, MisPANEL_NUMERICMisNavRatio, ATTR_TEXT_BOLD, 1); 
		
		SetCtrlAttribute (MissileSetPanelHandle, MisPANEL_NUMERICTarIniVelN, ATTR_TEXT_BOLD, 1);
		SetCtrlAttribute (MissileSetPanelHandle, MisPANEL_NUMERICTarIniVelU, ATTR_TEXT_BOLD, 1);  
		SetCtrlAttribute (MissileSetPanelHandle, MisPANEL_NUMERICTarIniVelE, ATTR_TEXT_BOLD, 1);  
		SetCtrlAttribute (MissileSetPanelHandle, MisPANEL_NUMERICTarIniPosX, ATTR_TEXT_BOLD, 1);  
		SetCtrlAttribute (MissileSetPanelHandle, MisPANEL_NUMERICTarIniPosY, ATTR_TEXT_BOLD, 1);  
		SetCtrlAttribute (MissileSetPanelHandle, MisPANEL_NUMERICTarIniPosZ, ATTR_TEXT_BOLD, 1);  
	
		SetCtrlAttribute (MissileSetPanelHandle, MisPANEL_NUMERICTarStartTime, ATTR_TEXT_BOLD, 1); 
		SetCtrlAttribute (MissileSetPanelHandle, MisPANEL_NUMERICTarEndTime, ATTR_TEXT_BOLD, 1);
		SetCtrlAttribute (MissileSetPanelHandle, MisPANEL_NUMERICTarAccRangeX, ATTR_TEXT_BOLD, 1); 
		SetCtrlAttribute (MissileSetPanelHandle, MisPANEL_NUMERICTarAccFreX, ATTR_TEXT_BOLD, 1); 
		SetCtrlAttribute (MissileSetPanelHandle, MisPANEL_NUMERICTarAccPhaseX, ATTR_TEXT_BOLD, 1); 
		SetCtrlAttribute (MissileSetPanelHandle, MisPANEL_NUMERICTarAccRangeY, ATTR_TEXT_BOLD, 1); 
		SetCtrlAttribute (MissileSetPanelHandle, MisPANEL_NUMERICTarAccFreY, ATTR_TEXT_BOLD, 1); 
		SetCtrlAttribute (MissileSetPanelHandle, MisPANEL_NUMERICTarAccPhaseY, ATTR_TEXT_BOLD, 1); 
		SetCtrlAttribute (MissileSetPanelHandle, MisPANEL_NUMERICTarAccRangeZ, ATTR_TEXT_BOLD, 1); 
		SetCtrlAttribute (MissileSetPanelHandle, MisPANEL_NUMERICTarAccFreZ, ATTR_TEXT_BOLD, 1); 
		SetCtrlAttribute (MissileSetPanelHandle, MisPANEL_NUMERICTarAccPhaseZ, ATTR_TEXT_BOLD, 1); 
		
		SetCtrlAttribute (MissileSetPanelHandle, MisPANEL_TABLE_Tar, ATTR_TEXT_BOLD, 1); 
		
		SetCtrlAttribute (MissileSetPanelHandle, MisPANEL_NUMERICMisAccRangeX, ATTR_TEXT_BOLD, 0); 
		SetCtrlAttribute (MissileSetPanelHandle, MisPANEL_NUMERICMisAccFreX, ATTR_TEXT_BOLD, 0); 
		SetCtrlAttribute (MissileSetPanelHandle, MisPANEL_NUMERICMisAccPhaseX, ATTR_TEXT_BOLD, 0); 
		SetCtrlAttribute (MissileSetPanelHandle, MisPANEL_NUMERICMisAccRangeY, ATTR_TEXT_BOLD, 0); 
		SetCtrlAttribute (MissileSetPanelHandle, MisPANEL_NUMERICMisAccFreY, ATTR_TEXT_BOLD, 0); 
		SetCtrlAttribute (MissileSetPanelHandle, MisPANEL_NUMERICMisAccPhaseY, ATTR_TEXT_BOLD, 0); 
		SetCtrlAttribute (MissileSetPanelHandle, MisPANEL_NUMERICMisAccRangeZ, ATTR_TEXT_BOLD, 0); 
		SetCtrlAttribute (MissileSetPanelHandle, MisPANEL_NUMERICMisAccFreZ, ATTR_TEXT_BOLD, 0); 
		SetCtrlAttribute (MissileSetPanelHandle, MisPANEL_NUMERICMisAccPhaseZ, ATTR_TEXT_BOLD, 0); 
		
		SetCtrlAttribute (MissileSetPanelHandle, MisPANEL_NUMERICMisAdAngRangeX, ATTR_TEXT_BOLD, 0); 
		SetCtrlAttribute (MissileSetPanelHandle, MisPANEL_NUMERICMisAdAngFreX, ATTR_TEXT_BOLD, 0); 
		SetCtrlAttribute (MissileSetPanelHandle, MisPANEL_NUMERICMisAdAngPhaseX, ATTR_TEXT_BOLD, 0); 
		SetCtrlAttribute (MissileSetPanelHandle, MisPANEL_NUMERICMisAdAngRangeY, ATTR_TEXT_BOLD, 0); 
		SetCtrlAttribute (MissileSetPanelHandle, MisPANEL_NUMERICMisAdAngFreY, ATTR_TEXT_BOLD, 0); 
		SetCtrlAttribute (MissileSetPanelHandle, MisPANEL_NUMERICMisAdAngPhaseY, ATTR_TEXT_BOLD, 0); 
		SetCtrlAttribute (MissileSetPanelHandle, MisPANEL_NUMERICMisAdAngRangeZ, ATTR_TEXT_BOLD, 0); 
		SetCtrlAttribute (MissileSetPanelHandle, MisPANEL_NUMERICMisAdAngFreZ, ATTR_TEXT_BOLD, 0); 
		SetCtrlAttribute (MissileSetPanelHandle, MisPANEL_NUMERICMisAdAngPhaseZ, ATTR_TEXT_BOLD, 0);
		
		SetCtrlAttribute (MissileSetPanelHandle, MisPANEL_NUMERICMisFlightChaSt, ATTR_TEXT_BOLD, 0);
		SetCtrlAttribute (MissileSetPanelHandle, MisPANEL_NUMERICMisFlightChaEn, ATTR_TEXT_BOLD, 0);
		SetCtrlAttribute (MissileSetPanelHandle, MisPANEL_TABLE_Mis, ATTR_TEXT_BOLD, 0);
		
		SetCtrlAttribute (MissileSetPanelHandle, MisPANEL_MisDataPathName, ATTR_TEXT_BOLD, 0); 		
    }

void FreeModeDis(void)					      //��������ģʽ������ʾ 
    {
		SetCtrlAttribute (MissileSetPanelHandle, MisPANEL_NUMERICMisIniVel, ATTR_TEXT_BOLD, 1); 
		SetCtrlAttribute (MissileSetPanelHandle, MisPANEL_NUMERICMisStepSize, ATTR_TEXT_BOLD, 1); 
		SetCtrlAttribute (MissileSetPanelHandle, MisPANEL_NUMERICMisIniPosX, ATTR_TEXT_BOLD, 1); 
		SetCtrlAttribute (MissileSetPanelHandle, MisPANEL_NUMERICMisIniPosY, ATTR_TEXT_BOLD, 1); 
		SetCtrlAttribute (MissileSetPanelHandle, MisPANEL_NUMERICMisIniPosZ, ATTR_TEXT_BOLD, 1); 
		SetCtrlAttribute (MissileSetPanelHandle, MisPANEL_NUMERICMisIniYaw, ATTR_TEXT_BOLD, 1); 
		SetCtrlAttribute (MissileSetPanelHandle, MisPANEL_NUMERICMisIniPitch, ATTR_TEXT_BOLD, 1); 
		SetCtrlAttribute (MissileSetPanelHandle, MisPANEL_NUMERICMisIniRoll, ATTR_TEXT_BOLD, 1); 
		
		SetCtrlAttribute (MissileSetPanelHandle, MisPANEL_NUMERICMisSmoothTime, ATTR_TEXT_BOLD, 1);
		SetCtrlAttribute (MissileSetPanelHandle, MisPANEL_NUMERICMisFlightTime, ATTR_TEXT_BOLD, 1); 
		SetCtrlAttribute (MissileSetPanelHandle, MisPANEL_NUMERICMisGuiTime, ATTR_TEXT_BOLD, 0); 
		SetCtrlAttribute (MissileSetPanelHandle, MisPANEL_NUMERICMisNavRatio, ATTR_TEXT_BOLD, 0); 
		
		SetCtrlAttribute (MissileSetPanelHandle, MisPANEL_NUMERICTarIniVelN, ATTR_TEXT_BOLD, 0);
		SetCtrlAttribute (MissileSetPanelHandle, MisPANEL_NUMERICTarIniVelU, ATTR_TEXT_BOLD, 0);  
		SetCtrlAttribute (MissileSetPanelHandle, MisPANEL_NUMERICTarIniVelE, ATTR_TEXT_BOLD, 0);  
		SetCtrlAttribute (MissileSetPanelHandle, MisPANEL_NUMERICTarIniPosX, ATTR_TEXT_BOLD, 0);  
		SetCtrlAttribute (MissileSetPanelHandle, MisPANEL_NUMERICTarIniPosY, ATTR_TEXT_BOLD, 0);  
		SetCtrlAttribute (MissileSetPanelHandle, MisPANEL_NUMERICTarIniPosZ, ATTR_TEXT_BOLD, 0);  
		
		SetCtrlAttribute (MissileSetPanelHandle, MisPANEL_NUMERICTarStartTime, ATTR_TEXT_BOLD, 0); 
		SetCtrlAttribute (MissileSetPanelHandle, MisPANEL_NUMERICTarEndTime, ATTR_TEXT_BOLD, 0);
		SetCtrlAttribute (MissileSetPanelHandle, MisPANEL_NUMERICTarAccRangeX, ATTR_TEXT_BOLD, 0); 
		SetCtrlAttribute (MissileSetPanelHandle, MisPANEL_NUMERICTarAccFreX, ATTR_TEXT_BOLD, 0); 
		SetCtrlAttribute (MissileSetPanelHandle, MisPANEL_NUMERICTarAccPhaseX, ATTR_TEXT_BOLD, 0); 
		SetCtrlAttribute (MissileSetPanelHandle, MisPANEL_NUMERICTarAccRangeY, ATTR_TEXT_BOLD, 0); 
		SetCtrlAttribute (MissileSetPanelHandle, MisPANEL_NUMERICTarAccFreY, ATTR_TEXT_BOLD, 0); 
		SetCtrlAttribute (MissileSetPanelHandle, MisPANEL_NUMERICTarAccPhaseY, ATTR_TEXT_BOLD, 0); 
		SetCtrlAttribute (MissileSetPanelHandle, MisPANEL_NUMERICTarAccRangeZ, ATTR_TEXT_BOLD, 0); 
		SetCtrlAttribute (MissileSetPanelHandle, MisPANEL_NUMERICTarAccFreZ, ATTR_TEXT_BOLD, 0); 
		SetCtrlAttribute (MissileSetPanelHandle, MisPANEL_NUMERICTarAccPhaseZ, ATTR_TEXT_BOLD, 0); 
		
		SetCtrlAttribute (MissileSetPanelHandle, MisPANEL_TABLE_Tar, ATTR_TEXT_BOLD, 0); 
		
		SetCtrlAttribute (MissileSetPanelHandle, MisPANEL_NUMERICMisAccRangeX, ATTR_TEXT_BOLD, 1); 
		SetCtrlAttribute (MissileSetPanelHandle, MisPANEL_NUMERICMisAccFreX, ATTR_TEXT_BOLD, 1); 
		SetCtrlAttribute (MissileSetPanelHandle, MisPANEL_NUMERICMisAccPhaseX, ATTR_TEXT_BOLD, 1); 
		SetCtrlAttribute (MissileSetPanelHandle, MisPANEL_NUMERICMisAccRangeY, ATTR_TEXT_BOLD, 1); 
		SetCtrlAttribute (MissileSetPanelHandle, MisPANEL_NUMERICMisAccFreY, ATTR_TEXT_BOLD, 1); 
		SetCtrlAttribute (MissileSetPanelHandle, MisPANEL_NUMERICMisAccPhaseY, ATTR_TEXT_BOLD, 1); 
		SetCtrlAttribute (MissileSetPanelHandle, MisPANEL_NUMERICMisAccRangeZ, ATTR_TEXT_BOLD, 1); 
		SetCtrlAttribute (MissileSetPanelHandle, MisPANEL_NUMERICMisAccFreZ, ATTR_TEXT_BOLD, 1); 
		SetCtrlAttribute (MissileSetPanelHandle, MisPANEL_NUMERICMisAccPhaseZ, ATTR_TEXT_BOLD, 1); 
		
		SetCtrlAttribute (MissileSetPanelHandle, MisPANEL_NUMERICMisAdAngRangeX, ATTR_TEXT_BOLD, 1); 
		SetCtrlAttribute (MissileSetPanelHandle, MisPANEL_NUMERICMisAdAngFreX, ATTR_TEXT_BOLD, 1); 
		SetCtrlAttribute (MissileSetPanelHandle, MisPANEL_NUMERICMisAdAngPhaseX, ATTR_TEXT_BOLD, 1); 
		SetCtrlAttribute (MissileSetPanelHandle, MisPANEL_NUMERICMisAdAngRangeY, ATTR_TEXT_BOLD, 1); 
		SetCtrlAttribute (MissileSetPanelHandle, MisPANEL_NUMERICMisAdAngFreY, ATTR_TEXT_BOLD, 1); 
		SetCtrlAttribute (MissileSetPanelHandle, MisPANEL_NUMERICMisAdAngPhaseY, ATTR_TEXT_BOLD, 1); 
		SetCtrlAttribute (MissileSetPanelHandle, MisPANEL_NUMERICMisAdAngRangeZ, ATTR_TEXT_BOLD, 1); 
		SetCtrlAttribute (MissileSetPanelHandle, MisPANEL_NUMERICMisAdAngFreZ, ATTR_TEXT_BOLD, 1); 
		SetCtrlAttribute (MissileSetPanelHandle, MisPANEL_NUMERICMisAdAngPhaseZ, ATTR_TEXT_BOLD, 1);
		
		SetCtrlAttribute (MissileSetPanelHandle, MisPANEL_NUMERICMisFlightChaSt, ATTR_TEXT_BOLD, 1);
		SetCtrlAttribute (MissileSetPanelHandle, MisPANEL_NUMERICMisFlightChaEn, ATTR_TEXT_BOLD, 1);
		SetCtrlAttribute (MissileSetPanelHandle, MisPANEL_TABLE_Mis, ATTR_TEXT_BOLD, 1);
		
		SetCtrlAttribute (MissileSetPanelHandle, MisPANEL_MisDataPathName, ATTR_TEXT_BOLD, 0); 
    }

void ReadModeDis(void)					      //��ȡ�̿ص�����ģʽ������ʾ 
    {
		SetCtrlAttribute (MissileSetPanelHandle, MisPANEL_NUMERICMisIniVel, ATTR_TEXT_BOLD, 1); 
		SetCtrlAttribute (MissileSetPanelHandle, MisPANEL_NUMERICMisStepSize, ATTR_TEXT_BOLD, 1); 
		SetCtrlAttribute (MissileSetPanelHandle, MisPANEL_NUMERICMisIniPosX, ATTR_TEXT_BOLD, 1); 
		SetCtrlAttribute (MissileSetPanelHandle, MisPANEL_NUMERICMisIniPosY, ATTR_TEXT_BOLD, 1); 
		SetCtrlAttribute (MissileSetPanelHandle, MisPANEL_NUMERICMisIniPosZ, ATTR_TEXT_BOLD, 1); 
		SetCtrlAttribute (MissileSetPanelHandle, MisPANEL_NUMERICMisIniYaw, ATTR_TEXT_BOLD, 1); 
		SetCtrlAttribute (MissileSetPanelHandle, MisPANEL_NUMERICMisIniPitch, ATTR_TEXT_BOLD, 1); 
		SetCtrlAttribute (MissileSetPanelHandle, MisPANEL_NUMERICMisIniRoll, ATTR_TEXT_BOLD, 1); 
		
		SetCtrlAttribute (MissileSetPanelHandle, MisPANEL_NUMERICMisSmoothTime, ATTR_TEXT_BOLD, 0); 
		SetCtrlAttribute (MissileSetPanelHandle, MisPANEL_NUMERICMisFlightTime, ATTR_TEXT_BOLD, 0); 
		SetCtrlAttribute (MissileSetPanelHandle, MisPANEL_NUMERICMisGuiTime, ATTR_TEXT_BOLD, 0); 
		SetCtrlAttribute (MissileSetPanelHandle, MisPANEL_NUMERICMisNavRatio, ATTR_TEXT_BOLD, 0); 
		
		SetCtrlAttribute (MissileSetPanelHandle, MisPANEL_NUMERICTarIniVelN, ATTR_TEXT_BOLD, 0);
		SetCtrlAttribute (MissileSetPanelHandle, MisPANEL_NUMERICTarIniVelU, ATTR_TEXT_BOLD, 0);  
		SetCtrlAttribute (MissileSetPanelHandle, MisPANEL_NUMERICTarIniVelE, ATTR_TEXT_BOLD, 0);   
		SetCtrlAttribute (MissileSetPanelHandle, MisPANEL_NUMERICTarIniPosX, ATTR_TEXT_BOLD, 0);  
		SetCtrlAttribute (MissileSetPanelHandle, MisPANEL_NUMERICTarIniPosY, ATTR_TEXT_BOLD, 0);  
		SetCtrlAttribute (MissileSetPanelHandle, MisPANEL_NUMERICTarIniPosZ, ATTR_TEXT_BOLD, 0);  
		
		SetCtrlAttribute (MissileSetPanelHandle, MisPANEL_NUMERICTarStartTime, ATTR_TEXT_BOLD, 0); 
		SetCtrlAttribute (MissileSetPanelHandle, MisPANEL_NUMERICTarEndTime, ATTR_TEXT_BOLD, 0);
		SetCtrlAttribute (MissileSetPanelHandle, MisPANEL_NUMERICTarAccRangeX, ATTR_TEXT_BOLD, 0); 
		SetCtrlAttribute (MissileSetPanelHandle, MisPANEL_NUMERICTarAccFreX, ATTR_TEXT_BOLD, 0); 
		SetCtrlAttribute (MissileSetPanelHandle, MisPANEL_NUMERICTarAccPhaseX, ATTR_TEXT_BOLD, 0); 
		SetCtrlAttribute (MissileSetPanelHandle, MisPANEL_NUMERICTarAccRangeY, ATTR_TEXT_BOLD, 0); 
		SetCtrlAttribute (MissileSetPanelHandle, MisPANEL_NUMERICTarAccFreY, ATTR_TEXT_BOLD, 0); 
		SetCtrlAttribute (MissileSetPanelHandle, MisPANEL_NUMERICTarAccPhaseY, ATTR_TEXT_BOLD, 0); 
		SetCtrlAttribute (MissileSetPanelHandle, MisPANEL_NUMERICTarAccRangeZ, ATTR_TEXT_BOLD, 0); 
		SetCtrlAttribute (MissileSetPanelHandle, MisPANEL_NUMERICTarAccFreZ, ATTR_TEXT_BOLD, 0); 
		SetCtrlAttribute (MissileSetPanelHandle, MisPANEL_NUMERICTarAccPhaseZ, ATTR_TEXT_BOLD, 0); 
		
		SetCtrlAttribute (MissileSetPanelHandle, MisPANEL_TABLE_Tar, ATTR_TEXT_BOLD, 0); 
		
		SetCtrlAttribute (MissileSetPanelHandle, MisPANEL_NUMERICMisAccRangeX, ATTR_TEXT_BOLD, 0); 
		SetCtrlAttribute (MissileSetPanelHandle, MisPANEL_NUMERICMisAccFreX, ATTR_TEXT_BOLD, 0); 
		SetCtrlAttribute (MissileSetPanelHandle, MisPANEL_NUMERICMisAccPhaseX, ATTR_TEXT_BOLD, 0); 
		SetCtrlAttribute (MissileSetPanelHandle, MisPANEL_NUMERICMisAccRangeY, ATTR_TEXT_BOLD, 0); 
		SetCtrlAttribute (MissileSetPanelHandle, MisPANEL_NUMERICMisAccFreY, ATTR_TEXT_BOLD, 0); 
		SetCtrlAttribute (MissileSetPanelHandle, MisPANEL_NUMERICMisAccPhaseY, ATTR_TEXT_BOLD, 0); 
		SetCtrlAttribute (MissileSetPanelHandle, MisPANEL_NUMERICMisAccRangeZ, ATTR_TEXT_BOLD, 0); 
		SetCtrlAttribute (MissileSetPanelHandle, MisPANEL_NUMERICMisAccFreZ, ATTR_TEXT_BOLD, 0); 
		SetCtrlAttribute (MissileSetPanelHandle, MisPANEL_NUMERICMisAccPhaseZ, ATTR_TEXT_BOLD, 0); 
		
		SetCtrlAttribute (MissileSetPanelHandle, MisPANEL_NUMERICMisAdAngRangeX, ATTR_TEXT_BOLD, 0); 
		SetCtrlAttribute (MissileSetPanelHandle, MisPANEL_NUMERICMisAdAngFreX, ATTR_TEXT_BOLD, 0); 
		SetCtrlAttribute (MissileSetPanelHandle, MisPANEL_NUMERICMisAdAngPhaseX, ATTR_TEXT_BOLD, 0); 
		SetCtrlAttribute (MissileSetPanelHandle, MisPANEL_NUMERICMisAdAngRangeY, ATTR_TEXT_BOLD, 0); 
		SetCtrlAttribute (MissileSetPanelHandle, MisPANEL_NUMERICMisAdAngFreY, ATTR_TEXT_BOLD, 0); 
		SetCtrlAttribute (MissileSetPanelHandle, MisPANEL_NUMERICMisAdAngPhaseY, ATTR_TEXT_BOLD, 0); 
		SetCtrlAttribute (MissileSetPanelHandle, MisPANEL_NUMERICMisAdAngRangeZ, ATTR_TEXT_BOLD, 0); 
		SetCtrlAttribute (MissileSetPanelHandle, MisPANEL_NUMERICMisAdAngFreZ, ATTR_TEXT_BOLD, 0); 
		SetCtrlAttribute (MissileSetPanelHandle, MisPANEL_NUMERICMisAdAngPhaseZ, ATTR_TEXT_BOLD, 0);
		
		SetCtrlAttribute (MissileSetPanelHandle, MisPANEL_NUMERICMisFlightChaSt, ATTR_TEXT_BOLD, 0);
		SetCtrlAttribute (MissileSetPanelHandle, MisPANEL_NUMERICMisFlightChaEn, ATTR_TEXT_BOLD, 0);
		SetCtrlAttribute (MissileSetPanelHandle, MisPANEL_TABLE_Mis, ATTR_TEXT_BOLD, 0);
		
		SetCtrlAttribute (MissileSetPanelHandle, MisPANEL_MisDataPathName, ATTR_TEXT_BOLD, 1); 
    }

void CreateFolder(void)
{
	int month;
	int day;  
	int year;  
	int hours;
	int minutes;  
	int seconds;  
	char time[100];
	char dir[200];
	char g_dir[200];
	char project_dir[260];
	
	int f_exist;
	
	GetSystemDate (&month, &day, &year);
	GetSystemTime (&hours, &minutes, &seconds);
	sprintf(time,"%04d_%02d%02d_%02d%02d_%02d", year, month, day,hours,minutes,seconds);
	Fmt (dir, "%s<%100c", time); 
	f_exist = FileExists("D:\\TestData",0);
	
	if(f_exist == 0)              			//ͬ���ļ��в�����
	{
		MakeDir("D:\\TestData"); 	  	//�����ļ���
		SetDir("D:\\TestData"); 	  	//���ø��ļ���Ϊ��ǰ�����ļ���
		MakeDir(dir);
		SetDir(dir);     
	}
	else		   
	{
		SetDir("D:\\TestData");       //�����²�ʱ�������ļ���
		Fmt (g_dir, "D:\\TestData\\");  
		strcat(g_dir,time);
		f_exist = FileExists(g_dir,0); 
		if(f_exist == 0)
		{
			MakeDir(dir);
			SetDir(dir);		
		}
	}
	// Get folder path for FTP operation
	strcpy(HostDataPath, "TestData\\");
	strcat(HostDataPath, time);
	strcat(HostDataPath, "\\");
	GetProjectDir (project_dir);
	SetDir(project_dir);	
}

/*******************************�㷨�о����������ʼ********************************/ 

//�㷨�о�������˳���ť�ص�����
int CVICALLBACK AlgorithmResearchQuitCallback (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:
			 DiscardPanel(AlgorithmResearchPanelHandle);
			 
			 DisplayPanel (MainPanelHandle); 
			 SetPanelAttribute (MainPanelHandle, ATTR_WINDOW_ZOOM, VAL_MAXIMIZE);  
			break;
	}
	return 0;
}

//��λ���㷨�о�����
int CVICALLBACK CraftAlgorithmCallback (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:
			
		InitialConstVariable();  //ȫ�ֳ�����ʼ��
		
	    InitialPanelInputVariable(); //ȫ�ֱ�����ʼ��
		
		CraftForwardAcceleration = 0;	
		
		double Rotary_Ini_In = 0;
	    double Rotary_Ini_Mid = 0;
		double Rotary_Ini_Out = 0;
		
	    SinsInitial(CraftAttitude,CraftVelocity,CraftPosition,CraftInsQtnS,CraftInsVelocityP,
			        CraftInsCep,&CraftInsAltitude,CraftInsPosition); 
		
 		InitMis_Att(CraftIniRoll, CraftIniPitch, CraftIniYaw,
				&Rotary_Ini_In, &Rotary_Ini_Mid, &Rotary_Ini_Out);	
				
		RotaryControlAngle[0][0] =  Rotary_Ini_In * DEGREE;
		RotaryControlAngle[1][0] =  Rotary_Ini_Mid * DEGREE;
		RotaryControlAngle[2][0] =  Rotary_Ini_Out * DEGREE;		
		
		
		TestFileHandle=fopen(TestFile_FILE_PATH,"wb");//���Ҫ������һ���ļ���д�����ݣ��������ѭ���������ļ� 
		fprintf(TestFileHandle,"%s   %s      %s      %s             %s             %s          ",
			"�ػ�����ʱ��","�켣���","�켣Ԥ��ʱ��","84ϵX��","84ϵY��","84ϵZ��");
		fprintf(TestFileHandle,"%s       %s       %s       %s       %s       %s      ",
				"84ϵX���ٶ�","84ϵY���ٶ�","84ϵZ���ٶ�", "84ϵX����ٶ�","84ϵY����ٶ�","84ϵZ����ٶ�");
		fprintf(TestFileHandle,"%s      %s      %s      ","��̬ʱ��","��̬�������","��̬Ԥ��ʱ��");
		fprintf(TestFileHandle,"%s      %s      %s      %s      %s      %s      %s      %s      %s      ",
              "�ػ�ƫ����","�ػ�������","�ػ���ת��","�ػ�ƫ�����ٶ�","�ػ��������ٶ�","�ػ���ת���ٶ�","�ػ�ƫ���Ǽ��ٶ�","�ػ������Ǽ��ٶ�","�ػ���ת�Ǽ��ٶ�");
		fprintf(TestFileHandle, "\r\n");
		
		CraftDataFileHandle=fopen(CRAFT_DATA_FILE_PATH,"wb");
		fprintf(CraftDataFileHandle,"%s   %s        %s         %s              ",
			"�ػ�����ʱ��","����","γ��","�߶�");
		fprintf(CraftDataFileHandle,"%s      %s      %s      %s      %s      %s     ",
			"�����ٶ�","�����ٶ�","�����ٶ�","������ٶ�", "������ٶ�", "������ٶ�");
		fprintf(CraftDataFileHandle,"%s      %s      %s      %s      %s      %s      %s      %s      %s      ",
			"�����","������","��ת��","������ٶ�", "�������ٶ�", "��ת���ٶ�","����Ǽ��ٶ�","�����Ǽ��ٶ�", "��ת�Ǽ��ٶ�");
		
		fprintf(CraftDataFileHandle,"%s      %s      %s      %s      %s      %s     ",
			"���ߵ�X��Ӽ�����","���ߵ�Y��Ӽ�����","���ߵ�Z��Ӽ�����","���ߵ�X����������","���ߵ�Y����������","���ߵ�Z����������"); 
		fprintf(CraftDataFileHandle,"%s      %s      %s      %s      %s      %s      %s     %s     %s     %s     %s     %s     %s     %s     %s     ",
			"���ߵ�X��Ӽ����","���ߵ�Y��Ӽ����","���ߵ�Z��Ӽ����","���ߵ�X���������","���ߵ�Y���������","���ߵ�Z���������",
			"���ߵ�����ľ���","���ߵ������γ��","���ߵ�����ĸ߶�","���ߵ�����Ķ����ٶ�","���ߵ�����ı����ٶ�","���ߵ�����������ٶ�","���ߵ������ƫ����","���ߵ�����ĸ�����","���ߵ�����Ĺ�ת��");
		
		fprintf(CraftDataFileHandle,"%s      %s      %s      %s      %s      %s      %s     %s     %s      ",
			"���ߵ����㾭�����","���ߵ�����γ�����","���ߵ�����߶����","���ߵ����㶫���ٶ����","���ߵ����㱱���ٶ����","���ߵ����������ٶ����","���ߵ�����ƫ�������","���ߵ����㸩�������","���ߵ������ת�����");

		fprintf(CraftDataFileHandle,"%s      %s      %s      %s      %s      %s     %s      %s      %s      %s      %s      %s      ",
			"���׼����ϵ�Ļ��Z��","���׼����ϵ�Ļ��Y��","���׼����ϵ�Ļ��X��","��ر����ٶ�", "��������ٶ�", "��ض����ٶ�"
			     ,"�����̬��ת��", "�����̬ƫ����", "�����̬������","�������X","�������Y","�������Z"); 

		fprintf(CraftDataFileHandle,"%s      %s      %s      %s      %s      %s     ",
			"���ߵ�X��Ӽ��������", "���ߵ�Y��Ӽ��������", "���ߵ�Z��Ӽ��������", "���ߵ�X�������������", "���ߵ�Y�������������", "���ߵ�Z�������������");				
/*	    fprintf(CraftDataFileHandle,"%s      %s      %s      %s      %s      %s     ",
			"�ӹߵ�X��Ӽ�����", "�ӹߵ�Y��Ӽ�����", "�ӹߵ�Z��Ӽ�����", "�ӹߵ�X����������", "�ӹߵ�Y����������", "�ӹߵ�Z����������");
			
		fprintf(CraftDataFileHandle,"%s      %s      %s      %s      %s      %s     ",
			"�ӹߵ�X��Ӽ��������", "�ӹߵ�Y��Ӽ��������", "�ӹߵ�Z��Ӽ��������", "�ӹߵ�X�������������", "�ӹߵ�Y�������������", "�ӹߵ�Z�������������");
 */
		
		fprintf(CraftDataFileHandle,"%s      %s      %s      %s      %s      %s      %s     %s     %s     %s     %s     %s      ",
			"���������","����������","������ת��","��������������X","��������������Y","��������������Z","����X�����","����Y�����","����Z�����","�����󵼵�X�����","�����󵼵�Y�����","�����󵼵�Z�����");
		
		
		fprintf(CraftDataFileHandle, "\r\n");					   		
			

		for( iCraft = 1; iCraft <= CraftFlightStateNum; iCraft++)
		{
			SampleNum=(int)(EachCraftTraceTime[iCraft]/CraftTraceStepSize);//ÿ�η��й켣�ķ���ʱ����Ի��ֲ���Ϊÿ�η��й켣�Ĳ�������
										  
			Tg=EachCraftTraceTime[iCraft]*SmoothTimePercent;       //����ʱ�䣬�����ٶȣ�ƽ��������ʱ��̶�
			Tw=EachCraftTraceTime[iCraft]*(1.0-SmoothTimePercent); //ƽ��ʱ��
            Omega=pi/Tg; 
			
		    TzG[0]=CraftTraceStepSize;     //��ÿ�ι켣��ʼʱ��Ҫ��TzG��ֵΪCraftTraceStepSize
		    TzG[1]=CraftTraceStepSize;
		    TzG[2]=CraftTraceStepSize;
		    TzA=CraftTraceStepSize;
			
			CraftAttitudeChangeCraft[0][iCraft]=CraftAttitudeChange[0][iCraft]*DEGREE;
			CraftAttitudeChangeCraft[1][iCraft]=CraftAttitudeChange[1][iCraft]*DEGREE;
			CraftAttitudeChangeCraft[2][iCraft]=CraftAttitudeChange[2][iCraft]*DEGREE;			

            //ƽ����ʼ
			if(CraftFlightState[iCraft]==CraftDengJiaoFeiXing)
		    {
				 CraftAttitudeChangeRateExpect[0][iCraft]=0;
				 CraftAttitudeChangeRateExpect[1][iCraft]=0;
				 CraftAttitudeChangeRateExpect[2][iCraft]=0;
		    	 CraftFlightZhuanWanFlag=0;
			}
		   
		    if (CraftFlightState[iCraft]==CraftFuYangYunDong)//�����ػ�����״̬���ػ��ķ��в������м��㲢��ֵ�������˶�
            {  											  
	            CraftAttitudeChangeRateExpect[1][iCraft]=CraftAttitudeChangeCraft[1][iCraft]/(EachCraftTraceTime[iCraft]*(1.0-SmoothTimePercent));//��ÿ�����ֲ����ڣ��������ٶ�Ԥ�ڱ仯ֵ
				CraftFlightZhuanWanFlag=0;
			}//CraftAttitudeChange�Ǵ��ػ��켣�滮���еõ�����̬�Ǳ仯�Ķ���
		    
			if (CraftFlightState[iCraft]==CraftFuYangGaiPing)//�����ػ�����״̬���ػ��ķ��в������м��㲢��ֵ��������ƽ
            {
	            CraftAttitudeChangeRateExpect[1][iCraft]=(-CraftAttitude[1][0])/(EachCraftTraceTime[iCraft]*(1.0-SmoothTimePercent));//��ÿ�����ֲ����ڣ��������ٶ�Ԥ�ڱ仯ֵ
				CraftFlightZhuanWanFlag=0;
			}										  
            
			if (CraftFlightState[iCraft]==CraftZhuanWanGaiPing)//ת���ƽ�������ǽ����еĺ���Ǳ�Ϊ��
            {
	            CraftAttitudeChangeRateExpect[2][iCraft]=(-CraftAttitude[2][0])/(EachCraftTraceTime[iCraft]*(1.0-SmoothTimePercent));
				CraftFlightZhuanWanFlag=0;
			}
		    
			if (CraftFlightState[iCraft]==CraftYiBanHengGun)//һ����������Ǳ仯���ٻ��ȣ����Թ켣�仯ʱ�䣬�õ���̬�仯�ʣ����ٶȣ�
            {
	            CraftAttitudeChangeRateExpect[2][iCraft]=CraftAttitudeChangeCraft[2][iCraft]/(EachCraftTraceTime[iCraft]*(1.0-SmoothTimePercent));
				CraftFlightZhuanWanFlag=0;
			}
			
			if((CraftFlightState[iCraft]==CraftYiBanZhuanWan))//һ��ת�䣬����ǲ��䣬���к���Ǳ仯
			{
				CraftAttitudeChangeRateExpect[0][iCraft]=CraftAttitudeChangeCraft[0][iCraft]/(EachCraftTraceTime[iCraft]*(1.0-SmoothTimePercent));
				CraftFlightZhuanWanFlag=0;
			}
				
			for ( jCraft = 1; jCraft <= SampleNum; jCraft++) 
			{
				TraceTime=CraftTraceStepSize+TraceTime;//��¼ʱ��,��ÿ���ػ��켣ʱ��

				//���漰���ػ��켣��ص�CraftForwardVelocity����̬�ǵı仯�ϣ������ڵڶ���ѭ�������ػ����ٶȱ仯��
				if(CraftFlightState[iCraft]==CraftZhuanWanXunHang) //ת��Ѳ�����к����ʱ�Ž�ת��Ѳ��
				{
						CraftFlightZhuanWanFlag=1;
				}			
				
		        if ((CraftFlightState[iCraft]==CraftXieTiaoZhuanWan))//Э��ת�� 
		        {
						CraftAttitudeChangeRateExpect[2][iCraft]=CraftAttitudeChangeCraft[2][iCraft]/(EachCraftTraceTime[iCraft]*(1.0-SmoothTimePercent));
						CraftFlightZhuanWanFlag=1;
				}
				
				if(CraftFlightZhuanWanFlag)
				{
				    CraftAttitudeChangeRate[0][0]=g0*tan(CraftAttitude[2][0])/(CraftForwardVelocity);  //������Э��ת���ת��Ѳ��ʱ�������и������
				     //(Э��ת��)����ƽ�������, Ҳ����ת��Ѳ��
				}			
				
			    if(SmoothTimePercent==0)
			    {
					CraftForwardAcceleration=CraftForwardAccelerationExpect[iCraft];
			        CraftAttitudeChangeRate[0][0]=CraftAttitudeChangeRateExpect[0][iCraft];//���ػ��켣��ȫ�ֱ��������ػ��켣��������
			        CraftAttitudeChangeRate[1][0]=CraftAttitudeChangeRateExpect[1][iCraft];//ÿ�μ���һ������ 
			        CraftAttitudeChangeRate[2][0]=CraftAttitudeChangeRateExpect[2][iCraft]; 
				}
				else
				{
					
                   //�ػ����ٶ�ƽ��  //ƽ���ٶȵ��������½��׶�
			       for(int m=0;m<3;m++)
                   { 
                      if(fabs(CraftAttitudeChangeRateExpect[m][iCraft])>0.0001)  //�ж��Ƿ�Ӧ�ý�����ٶ�ƽ��
		              {
			              if(TzG[m]<=Tg)
                          {
							  CraftAttitudeChangeRate[m][0]=0.5*CraftAttitudeChangeRateExpect[m][iCraft]*(1.0-cos(Omega*TzG[m]));
							  CraftAttitudeChangeRateD[m][0]=0.5*CraftAttitudeChangeRateExpect[m][iCraft]*Omega*sin(Omega*TzG[m]);
						  }
                          else
			              {
							  if ((TzG[m]<=Tw) && (TzG[m]>Tg))
			                  {
				                  CraftAttitudeChangeRate[m][0]=CraftAttitudeChangeRate[m][0]; //������ǰһʱ�̸�ֵ������ʱ��
								  CraftAttitudeChangeRateD[m][0]=0;
							  }
					          else //((TzA<=Tp) && (TzA<=Tg) && (TzA<=Tj)) 
					         { 
                              CraftAttitudeChangeRate[m][0]=0.5*CraftAttitudeChangeRateExpect[m][iCraft]*(1.0-cos(Omega*TzG[m]));
							  CraftAttitudeChangeRateD[m][0]=0.5*CraftAttitudeChangeRateExpect[m][iCraft]*Omega*sin(Omega*TzG[m]);
							 }
			               }
			               TzG[m]=TzG[m]+CraftTraceStepSize; 									
		              }
			        }

                    //�ػ�ǰ����ٶ�ƽ���������׶�
                    //ǰ�������������ٶȵĲ���Ϊƽ������ʼ���ٶ�,��Ϊ���ٶ��Ǹı䵽ĳ��ֵ
                    //ֻ������ƽ������Ҫǰ����������ļ��ٶ����
                    if(iCraft > 0)  
                    {
                    	   DCraftForwardAcceleration=CraftForwardAccelerationExpect[iCraft]-CraftForwardAccelerationExpect[iCraft-1];
                    }
                    else 
                    { 
                    	   DCraftForwardAcceleration=CraftForwardAccelerationExpect[iCraft];
                    }	
			   
                    if(iCraft == 1)
                    {
                    		 CraftForwardAccelerationOld=0;
                    }
                    else
                    {	
                    		if(jCraft==1)
                    		   CraftForwardAccelerationOld=CraftForwardAcceleration; //��ƽ������ֵ //CraftForwardAcclerationOldӦΪ�ڴ��仯����ֵ
                    		else
                    		   CraftForwardAccelerationOld=CraftForwardAccelerationOld; //��ƽ������ֵ //CraftForwardAcclerationOldӦΪ�ڴ��仯����ֵ
                    }

                    if(fabs(DCraftForwardAcceleration!=0))   //ֻƽ�����ٶȵ������׶Σ�
                    {
                         if(fabs(DCraftForwardAcceleration)>0.0001)//�ж��Ƿ�Ӧ�ý�����ٶ�ƽ��
                         {
                            if(TzA<=Tg)
                            {
                                  CraftForwardAccelerationD=0.5*DCraftForwardAcceleration*(1-cos(Omega*TzA));
						          CraftForwardAcceleration=CraftForwardAccelerationOld+CraftForwardAccelerationD;
                            }  //CraftForwardAccelerationOld��ƽ���׶εĹ̶�ֵ
				            else
			                {
				                  CraftForwardAcceleration=CraftForwardAcceleration;
			                }
			                TzA=TzA+CraftTraceStepSize; 
		                 }
                    }
                    else 
                    {
                    		CraftForwardAcceleration=CraftForwardAcceleration;
                    }
				}//ƽ������ 

				CraftTrack(CraftAttitude,CraftAttitudeChangeRate,CraftVelocity,CraftPosition,&CraftForwardVelocity,
					         &CraftForwardAcceleration,CraftTraceStepSize,CraftAcc);  //�����ػ��켣 
				
				TraceToGNSS(CraftPosition, CraftVelocity, CraftAcc, CraftPositionWGS84,CraftVelocityGNSS, CraftAccGNSS);//����ϵ�켣����ת����84ϵ
			
				CraftImuInput(CraftAttitude,CraftAttitudeChangeRate,CraftVelocity,CraftPosition,
					          CraftSFB,CraftOmegaiBB,CraftAcc);
				
				CraftImuOutput(CraftSFB,CraftOmegaiBB,CraftInsSFs,CraftInsOmegaiBBs);
				
				
                RotaryControlInputFunc(CraftAttitude, RotaryControlAngle, RotaryControlAngleRate, CraftTraceStepSize, 
								   RotaryControlAngleOld);
				
				//���ݲ��� 
				GyroBuChang(CraftAttitude, CraftAttitudeChangeRate, CraftOmegaiBB, 
			                       RotaryControlAngle, RotaryControlAngleRate, CraftTraceStepSize, 
								   CraftPosition, CraftVelocity, RotaryQuaternion, RotaryControlAngleOld);
				
				Vec2Vec(RotaryControlAngle, RotaryControlAngleOld); 

				
				//�����ػ�����Ӱ����ٶȡ����������ٶ�: relvel,MissileSOmegaibb,MissileSInsSFb	
	            AccelerometerControlInput(CraftOmegaiBB, CraftSFB, MissileSInsSFb,CraftTraceStepSize, WingLever, 
										   CraftAttitude, CraftPosition,CraftVelocity, MissileSFCompensate, OmegapBb1);
				
				//�ӼƲ���
	            AccelerometerBuChang(CraftTraceStepSize, RotaryControlAngleRate,
						             MissileSFCompensate, RotaryControlAngleRateOld,RotaryControlAngle);
              
				CalcImuIncPulse(CraftFPulse,CraftFRem,CraftInsSFs,CraftAccelerometerQuantizationFactor,CraftTraceStepSize); //�����ߵ����������ת��Ϊ������� 
				CalcImuIncPulse(CraftGPulse,CraftGRem,CraftInsOmegaiBBs,CraftGyroQuantizationFactor_rad,CraftTraceStepSize);

				CalcImuIncPulseSum(CraftFPulseSum,CraftFPulse);  //�������ߵ������������
				CalcImuIncPulseSum(CraftGPulseSum,CraftGPulse);

				if (TraceTime>=CraNavStartTime)//���ݶ�׼��ʼʱ���ӹߵ���ʼ��������ؿ�ʼ����
			    {
			        FrequencyControl(&CountCraftNav,&MaxCountCraftNav,&CraftNavFlag);//�������ߵ�������־λ,��CountCraftNav�ﵽMaxCountCraftNavʱ�����ߵ��������CraftNavFlagΪ1�������ߵ����������

		            if (CraftNavFlag==1)//���ߵ�������Ч�����ߵ������Ĳ������ػ��켣�����ļ���������ĳ���͸�����ִ��һ��
				    {
						//�����ߵ��ļ������ڵ���ʱ��Imu������������ߵ����㣬ͬʱ�������������
						AssignAndResetImuIncPulse(CraftFPulseSum,CraftFPulseOut); //CraftFPulseOut��Ϊ���ߵ���������������������ߵ��ĵ�������
						AssignAndResetImuIncPulse(CraftGPulseSum,CraftGPulseOut);

						// SinsNav(CraftInsOmegaiBBs,CraftInsSFs,CraftInsQtnS,CraftInsVelocityP,CraftInsCep,&CraftInsAltitude,
						// 	     CraftNavigationStepSize, CraftInsOmegaipp, CraftInsPosition, CraftInsAttitude, &CraftSNavGravity, CraftOmegapBB);//�������ߵ����� ,�����ߵ��������һ��omegaipp�����
								 
					    SinsNavPulse(CraftFPulseOut, CraftGPulseOut, CraftInsQtnS, CraftInsVelocityP, CraftInsCep, 
					        &CraftInsAltitude,CraftNavigationStepSize, CraftInsOmegaipp, CraftInsPosition, CraftInsAttitude,
							CraftFInc, &CraftSNavGravity, CraftOmegapBB); //�����������ļ�ʱ����������������ٶ�ת��Ϊ������

				    }	
				}
				
				if (TraceTime>=TransferAlignmentStartTime)//���ݶ�׼��ʼʱ���ӹߵ���ʼ��������ؿ�ʼ����
			    {
				    FrequencyControl(&CountFcsNav, &MaxCountFcsNav,&FcsNavFlag);       //���»�ص�����Ч��־
				    FrequencyControl(&CountSAcce,&MaxCountSAcce,&MissileAcceFlag);     //�����ӼӼ���Ч��־
				    FrequencyControl(&CountSGyro,&MaxCountSGyro,&MissileGyroFlag);     //������������Ч��־
										
				    if (IniFcsFlag==0)//�����һ�ν�������г�ʼ��
				    {
						 InitialFcsPulse(CraftInsAttitude,&CraftSNavGravity, &CraftInsAltitude, CraftInsVelocityP, 
										FcsVel, FcsPos, FcsCbB, Gn, FcsQtn, CraftInsQtnSFcs, 
										MisAlignN, FcsNavigationStepSize);
					}
					if (FcsNavFlag==1)
			        { 
//				          FcsNavS(CraftInsSFs, CraftInsOmegaiBBs, CraftInsOmegaipp, CraftInsAttitude, &CraftSNavGravity,
//							  FcsGravity, CraftInsQtnSFcs, FcsQtn, FcsAttitude, FcsVel, FcsPos, &CraftInsAltitude,
//							   FcsH0, FcsNavigationStepSize, FcsCbB);
						  
						  FcsNavSPulse(CraftFPulseOut, CraftGPulseOut, CraftInsOmegaipp, CraftInsAttitude, &CraftSNavGravity,
							  FcsGravity, CraftInsQtnSFcs, FcsQtn, FcsAttitude, FcsVel, FcsPos, &CraftInsAltitude,
							   FcsH0, FcsNavigationStepSize, FcsCbB);
				    
					}	
		        }//if (TraceTime>=TransferAlignmentStartTime)//���ݶ�׼��ʼʱ���ӹߵ���ʼ��������ؿ�ʼ����
				
				Cig[0][0]=cos(pi/2+CraftPosition[0][0]);
				Cig[0][1]=-sin(pi/2+CraftPosition[0][0])*cos(pi/2-CraftPosition[0][1]);
				Cig[0][2]=sin(pi/2+CraftPosition[0][0])*sin(pi/2-CraftPosition[0][1]);
				Cig[1][0]=sin(pi/2+CraftPosition[0][0]);
				Cig[1][1]=cos(pi/2+CraftPosition[0][0])*cos(pi/2-CraftPosition[0][1]);
				Cig[1][2]=-cos(pi/2+CraftPosition[0][0])*sin(pi/2-CraftPosition[0][1]);
				Cig[2][0]=0;
				Cig[2][1]=sin(pi/2-CraftPosition[0][1]);
				Cig[2][2]=cos(pi/2-CraftPosition[0][1]);

				CraftPositionWGS84[0][0]=(CalRn(CraftPosition[1][0])+CraftPosition[2][0])*(cos(CraftPosition[1][0]))*(cos(CraftPosition[0][0]));
			    CraftPositionWGS84[1][0]=(CalRn(CraftPosition[1][0])+CraftPosition[2][0])*(cos(CraftPosition[1][0]))*(sin(CraftPosition[0][0]));
			    CraftPositionWGS84[2][0]=(CalRn(CraftPosition[1][0])*(1-e2)+CraftPosition[2][0])*sin(CraftPosition[1][0]);				
				
				MatMulVec(Cig,CraftVelocity,CraftVelocityGNSS);  	
				MatMulVec(Cig,CraftAcc,CraftAccGNSS);
														
				AlgorithmTestResult() ; //��λ���㷨��ʾ����
				
				//���ߵ���������
				VecDivSca(CraftAttitude,DEGREE,CraftAttitudeCha);
				VecDivSca(CraftInsAttitude,DEGREE,CraftInsAttitudeCha);
				VecSubVec(CraftAttitudeCha,CraftInsAttitudeCha,AttCha);
				VecSubVec(CraftVelocity,CraftInsVelocityP,CraftVelocityCha);
				VecSubVec(CraftPosition,CraftInsPosition,CraftPositionCha);
				//���ߵ���������
				
				//�ӹߵ���������
				VecDivSca(MissileSInsAttitude,DEGREE,MissileAttitudeCha);
				MissileAttCha[0][0]=CraftAttitudeCha[0][0]-MissileAttitudeCha[0][0];
				MissileAttCha[1][0]=CraftAttitudeCha[1][0]-MissileAttitudeCha[1][0];
				MissileAttCha[2][0]=CraftAttitudeCha[2][0]-MissileAttitudeCha[2][0];
				VecSubVec(CraftVelocity,MissileSInsVel,MissileVelocityCha);
				VecSubVec(CraftPosition,MissileSInsPos,MissilePositionCha);
				//�ӹߵ���������
				
				WriteCraftTraceResultToFile(CraftDataFileHandle);
				
				WriteCraftTraceResultToGNSSFile(TestFileHandle);	
				
		    }//if (jCraft<=SampleNum)�ڶ���ѭ������,��λ�����м���SampleNum�ĳ���Ӧ����������1��Ϊ�켣ÿ�β�������  												  

	        if(jCraft==SampleNum && iCraft<CraftFlightStateNum)
		    {
			   jCraft=1;
			   iCraft++;
		    }

		}//if(iCraft<=CraftFlightStateNum) ��һ��ѭ������ 
		
		fclose(CraftDataFileHandle);
		fclose(TestFileHandle); 	
		
		CraftTracePlot();

	    break;  			    
	}	
	return 0;
}

//�ػ��켣��ͼ����
void CraftTracePlot()
{
		PlotWaveform(AlgorithmResearchPanelHandle,AlgoPANEL_CraftPosXNav,CraftPositionPlot[0],(int)(TraceTime/CraftTraceStepSize + 1),VAL_DOUBLE,1,0,0,1,VAL_THIN_LINE,VAL_EMPTY_SQUARE,VAL_SOLID,1,VAL_RED);
	    PlotWaveform(AlgorithmResearchPanelHandle,AlgoPANEL_CraftPosYNav,CraftPositionPlot[1],(int)(TraceTime/CraftTraceStepSize + 1),VAL_DOUBLE,1,0,0,1,VAL_THIN_LINE,VAL_EMPTY_SQUARE,VAL_SOLID,1,VAL_RED);
		PlotWaveform(AlgorithmResearchPanelHandle,AlgoPANEL_CraftPosZNav,CraftPositionPlot[2],(int)(TraceTime/CraftTraceStepSize + 1),VAL_DOUBLE,1,0,0,1,VAL_THIN_LINE,VAL_EMPTY_SQUARE,VAL_SOLID,1,VAL_RED);
		PlotWaveform(AlgorithmResearchPanelHandle,AlgoPANEL_CraftPosX,CraftPositionWGS84Plot[0],(int)(TraceTime/CraftTraceStepSize + 1),VAL_DOUBLE,1,0,0,1,VAL_THIN_LINE,VAL_EMPTY_SQUARE,VAL_SOLID,1,VAL_RED);
	    PlotWaveform(AlgorithmResearchPanelHandle,AlgoPANEL_CraftPosY,CraftPositionWGS84Plot[1],(int)(TraceTime/CraftTraceStepSize + 1),VAL_DOUBLE,1,0,0,1,VAL_THIN_LINE,VAL_EMPTY_SQUARE,VAL_SOLID,1,VAL_RED);
		PlotWaveform(AlgorithmResearchPanelHandle,AlgoPANEL_CraftPosZ,CraftPositionWGS84Plot[2],(int)(TraceTime/CraftTraceStepSize + 1),VAL_DOUBLE,1,0,0,1,VAL_THIN_LINE,VAL_EMPTY_SQUARE,VAL_SOLID,1,VAL_RED);
		PlotWaveform(AlgorithmResearchPanelHandle,AlgoPANEL_CraftVelX,CraftVelocityPlot[0],(int)(TraceTime/CraftTraceStepSize + 1),VAL_DOUBLE,1,0,0,1,VAL_THIN_LINE,VAL_EMPTY_SQUARE,VAL_SOLID,1,VAL_RED);
		PlotWaveform(AlgorithmResearchPanelHandle,AlgoPANEL_CraftVelY,CraftVelocityPlot[1],(int)(TraceTime/CraftTraceStepSize + 1),VAL_DOUBLE,1,0,0,1,VAL_THIN_LINE,VAL_EMPTY_SQUARE,VAL_SOLID,1,VAL_RED);
		PlotWaveform(AlgorithmResearchPanelHandle,AlgoPANEL_CraftVelZ,CraftVelocityPlot[2],(int)(TraceTime/CraftTraceStepSize + 1),VAL_DOUBLE,1,0,0,1,VAL_THIN_LINE,VAL_EMPTY_SQUARE,VAL_SOLID,1,VAL_RED);
		PlotWaveform(AlgorithmResearchPanelHandle,AlgoPANEL_CraftAccX,CraftAccelerationPlot[0],(int)(TraceTime/CraftTraceStepSize + 1),VAL_DOUBLE,1,0,0,1,VAL_THIN_LINE,VAL_EMPTY_SQUARE,VAL_SOLID,1,VAL_RED);
		PlotWaveform(AlgorithmResearchPanelHandle,AlgoPANEL_CraftAccY,CraftAccelerationPlot[1],(int)(TraceTime/CraftTraceStepSize + 1),VAL_DOUBLE,1,0,0,1,VAL_THIN_LINE,VAL_EMPTY_SQUARE,VAL_SOLID,1,VAL_RED);
		PlotWaveform(AlgorithmResearchPanelHandle,AlgoPANEL_CraftAccZ,CraftAccelerationPlot[2],(int)(TraceTime/CraftTraceStepSize + 1),VAL_DOUBLE,1,0,0,1,VAL_THIN_LINE,VAL_EMPTY_SQUARE,VAL_SOLID,1,VAL_RED);
		PlotWaveform(AlgorithmResearchPanelHandle,AlgoPANEL_CraftYaw,CraftAttitudePlot[0],(int)(TraceTime/CraftTraceStepSize + 1),VAL_DOUBLE,1,0,0,1,VAL_THIN_LINE,VAL_EMPTY_SQUARE,VAL_SOLID,1,VAL_RED);
		PlotWaveform(AlgorithmResearchPanelHandle,AlgoPANEL_CraftPitch,CraftAttitudePlot[1],(int)(TraceTime/CraftTraceStepSize + 1),VAL_DOUBLE,1,0,0,1,VAL_THIN_LINE,VAL_EMPTY_SQUARE,VAL_SOLID,1,VAL_RED);
		PlotWaveform(AlgorithmResearchPanelHandle,AlgoPANEL_CraftRoll,CraftAttitudePlot[2],(int)(TraceTime/CraftTraceStepSize + 1),VAL_DOUBLE,1,0,0,1,VAL_THIN_LINE,VAL_EMPTY_SQUARE,VAL_SOLID,1,VAL_RED);
		PlotWaveform(AlgorithmResearchPanelHandle,AlgoPANEL_CraftYawVel,CraftAttitudeChangeRatePlot[0],(int)(TraceTime/CraftTraceStepSize + 1),VAL_DOUBLE,1,0,0,1,VAL_THIN_LINE,VAL_EMPTY_SQUARE,VAL_SOLID,1,VAL_RED);
		PlotWaveform(AlgorithmResearchPanelHandle,AlgoPANEL_CraftPitchVel,CraftAttitudeChangeRatePlot[1],(int)(TraceTime/CraftTraceStepSize + 1),VAL_DOUBLE,1,0,0,1,VAL_THIN_LINE,VAL_EMPTY_SQUARE,VAL_SOLID,1,VAL_RED);
		PlotWaveform(AlgorithmResearchPanelHandle,AlgoPANEL_CraftRollVel,CraftAttitudeChangeRatePlot[2],(int)(TraceTime/CraftTraceStepSize + 1),VAL_DOUBLE,1,0,0,1,VAL_THIN_LINE,VAL_EMPTY_SQUARE,VAL_SOLID,1,VAL_RED);
		PlotWaveform(AlgorithmResearchPanelHandle,AlgoPANEL_CraftYawAcc,CraftAttitudeChangeRateDPlot[0],(int)(TraceTime/CraftTraceStepSize + 1),VAL_DOUBLE,1,0,0,1,VAL_THIN_LINE,VAL_EMPTY_SQUARE,VAL_SOLID,1,VAL_RED);
		PlotWaveform(AlgorithmResearchPanelHandle,AlgoPANEL_CraftPitchAcc,CraftAttitudeChangeRateDPlot[1],(int)(TraceTime/CraftTraceStepSize + 1),VAL_DOUBLE,1,0,0,1,VAL_THIN_LINE,VAL_EMPTY_SQUARE,VAL_SOLID,1,VAL_RED);
		PlotWaveform(AlgorithmResearchPanelHandle,AlgoPANEL_CraftRollAcc,CraftAttitudeChangeRateDPlot[2],(int)(TraceTime/CraftTraceStepSize + 1),VAL_DOUBLE,1,0,0,1,VAL_THIN_LINE,VAL_EMPTY_SQUARE,VAL_SOLID,1,VAL_RED);
}

//�ػ���ͼ����׼������
void  AlgorithmTestResult()
{
	CraftAttitudePlot[0][(iCraft-1)*SampleNum+jCraft]=CraftAttitude[0][0]/DEGREE; //��ͼ��ʾ�Ƕ�
	CraftAttitudePlot[1][(iCraft-1)*SampleNum+jCraft]=CraftAttitude[1][0]/DEGREE;					
	CraftAttitudePlot[2][(iCraft-1)*SampleNum+jCraft]=CraftAttitude[2][0]/DEGREE;
	
	CraftAttitudeChangeRatePlot[0][(iCraft-1)*SampleNum+jCraft]=CraftAttitudeChangeRate[0][0]/DEGREE;//���ػ����ٶ����������ػ��켣���������ı���
	CraftAttitudeChangeRatePlot[1][(iCraft-1)*SampleNum+jCraft]=CraftAttitudeChangeRate[1][0]/DEGREE; 
	CraftAttitudeChangeRatePlot[2][(iCraft-1)*SampleNum+jCraft]=CraftAttitudeChangeRate[2][0]/DEGREE; 
	
	CraftAttitudeChangeRateDPlot[0][(iCraft-1)*SampleNum+jCraft]=CraftAttitudeChangeRateD[0][0]/DEGREE;//���ػ����ٶ����������ػ��켣���������ı���
	CraftAttitudeChangeRateDPlot[1][(iCraft-1)*SampleNum+jCraft]=CraftAttitudeChangeRateD[1][0]/DEGREE; 
	CraftAttitudeChangeRateDPlot[2][(iCraft-1)*SampleNum+jCraft]=CraftAttitudeChangeRateD[2][0]/DEGREE; 
	
	CraftAccelerationPlot[0][(iCraft-1)*SampleNum+jCraft]=CraftAcc[0][0];
	CraftAccelerationPlot[1][(iCraft-1)*SampleNum+jCraft]=CraftAcc[1][0];
	CraftAccelerationPlot[2][(iCraft-1)*SampleNum+jCraft]=CraftAcc[2][0];				

	CraftVelocityPlot[0][(iCraft-1)*SampleNum+jCraft]=CraftVelocity[0][0];
	CraftVelocityPlot[1][(iCraft-1)*SampleNum+jCraft]=CraftVelocity[1][0];
	CraftVelocityPlot[2][(iCraft-1)*SampleNum+jCraft]=CraftVelocity[2][0];

	CraftPositionPlot[0][(iCraft-1)*SampleNum+jCraft]=CraftPosition[0][0]/DEGREE;
	CraftPositionPlot[1][(iCraft-1)*SampleNum+jCraft]=CraftPosition[1][0]/DEGREE;
	CraftPositionPlot[2][(iCraft-1)*SampleNum+jCraft]=CraftPosition[2][0];

	CraftPositionWGS84Plot[0][(iCraft-1)*SampleNum+jCraft]=CraftPositionWGS84[0][0];
	CraftPositionWGS84Plot[1][(iCraft-1)*SampleNum+jCraft]=CraftPositionWGS84[1][0];
	CraftPositionWGS84Plot[2][(iCraft-1)*SampleNum+jCraft]=CraftPositionWGS84[2][0];
}

//��ȡ���浼���켣������λ������
int CVICALLBACK MisTestCallback (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:
			InitialConstVariable(); 
			
		    FILE *InputHandle;
			FILE *OutputHandle;
			
			InputHandle=fopen("c:\\Input.txt","r");
			OutputHandle=fopen("c:\\Output.txt","wb");
			
			MisQuaternion[0][0] = 1.0;
			MisQuaternion[1][0] = 0.0;
			MisQuaternion[2][0] = 0.0;
			MisQuaternion[3][0] = 0.0;
			
			MisVelocity[0][0] = 0.0;
			MisVelocity[1][0] = 1000.0;
			MisVelocity[2][0] = 0.0;
			
			MisAltitude = 0.0;
			
			MisStepTimeSec = 0.01;
			
			MisPosition[0][0] = 0.0;
			MisPosition[1][0] = 0.0;
			MisPosition[2][0] = 0.0;
			
			MisAttitude_Rad[0][0] = 0.0;
			MisAttitude_Rad[1][0] = 0.0; 
			MisAttitude_Rad[2][0] = 0.0; 

			for(int i=0; i<=5999; i++)
			{
		    	fscanf (InputHandle, "%lf", &Tarvb); 
				fscanf (InputHandle, "%lf", &MisAngRate_Rad[0][0]);
				fscanf (InputHandle, "%lf", &MisAngRate_Rad[1][0]); 
				fscanf (InputHandle, "%lf", &MisAngRate_Rad[2][0]); 
				fscanf (InputHandle, "%lf", &MissileSF[0][0]); 
				fscanf (InputHandle, "%lf", &MissileSF[1][0]); 
				fscanf (InputHandle, "%lf", &MissileSF[2][0]);	
				
				//SinsNav(MisAngRate_Rad, MissileSF, MisQuaternion, MisVelocity, MisCep, 
				//&MisAltitude, MisStepTimeSec, MisOmegaipp, MisPosition, MisAttitude_Rad, &MisGravity);
			
				fprintf (OutputHandle, "%lf  ", MisGravity);  
				
				fprintf (OutputHandle, "%lf  ", MisQuaternion[0][0]);
				fprintf (OutputHandle, "%lf  ", MisQuaternion[1][0]); 
				fprintf (OutputHandle, "%lf  ", MisQuaternion[2][0]); 
				fprintf (OutputHandle, "%lf  ", MisQuaternion[3][0]);
			
				fprintf (OutputHandle, "%lf  ", MisVelocity[0][0]);
				fprintf (OutputHandle, "%lf  ", MisVelocity[1][0]); 
				fprintf (OutputHandle, "%lf  ", MisVelocity[2][0]); 

				fprintf (OutputHandle, "%lf  ", MisPosition[0][0]);
				fprintf (OutputHandle, "%lf  ", MisPosition[1][0]); 
				fprintf (OutputHandle, "%lf  ", MisPosition[2][0]); 
				
				fprintf (OutputHandle, "%lf  ", MisAttitude_Rad[0][0]);
				fprintf (OutputHandle, "%lf  ", MisAttitude_Rad[1][0]); 
				fprintf (OutputHandle, "%lf  ", MisAttitude_Rad[2][0]); 
				fprintf (OutputHandle, "\r\n"); 	
			}
			fclose(InputHandle);
			fclose(OutputHandle);
			
			break;
	}
	return 0;
}

int CVICALLBACK TEST_1_CallBack (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:
			
			double Test_Parameter;
			
			GetCtrlVal (MainPanelHandle, MainPanel_Test_Parameter, &Test_Parameter);
			cmd.Test_parameter = Test_Parameter;
			cmd.command = TEST_1;
			ClientTCPWrite (gDataConnection, &cmd, sizeof(cmd), TCPDataWaitTime); 
			
			break;
	}
	return 0;
}

int CVICALLBACK TEST_2_CallBack (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:

			double Test_Parameter;
			
			GetCtrlVal (MainPanelHandle, MainPanel_Test_Parameter, &Test_Parameter);
			cmd.Test_parameter = Test_Parameter;
			cmd.command = TEST_2;
			ClientTCPWrite (gDataConnection, &cmd, sizeof(cmd), TCPDataWaitTime); 
			
			break;
	}
	return 0;
}

int CVICALLBACK TEST_3_CallBack (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:
	
			double Test_Parameter;
			
			GetCtrlVal (MainPanelHandle, MainPanel_Test_Parameter, &Test_Parameter);
			cmd.Test_parameter = Test_Parameter;
			cmd.command = TEST_3;
			ClientTCPWrite (gDataConnection, &cmd, sizeof(cmd), TCPDataWaitTime); 
			
			break;
	}
	return 0;
}


/*******************************���ݴ������������ʼ********************************/ 

char InputFliePath[260];
char OutputFliePath[260];  

int CVICALLBACK InFileCallback (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	int status;
	switch (event)
	{
		case EVENT_COMMIT:
			
			status = FileSelectPopup ("c:\\Documents and Settings\\Administrator\\����",
				              "*.txt", "*.txt", "��ȡ����ֵ����",  VAL_OK_BUTTON , 0, 0, 1, 0, InputFliePath); 
			if(status != 0)
				SetCtrlVal (DataFileTransPanelHandle, Data_PANEL_InputPath, InputFliePath);
			
			break;
	}
	return 0;
}

int CVICALLBACK OutFileCallback (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	int status;
	switch (event)
	{
		case EVENT_COMMIT:
 			
			status = FileSelectPopup ("c:\\Documents and Settings\\Administrator\\����",
				              "*.txt", "*.txt", "��ֵ�������",  VAL_OK_BUTTON , 0, 0, 1, 0, OutputFliePath); 
			if(status != 0) 
				SetCtrlVal (DataFileTransPanelHandle, Data_PANEL_OutputPath, OutputFliePath);

			break;
	}
	return 0;
}

int CVICALLBACK ProcessCallback (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	double InStepSize = 0;
	double OutStepSize = 0; 
	int InsideNum = 0;
	double Line_Last[7] = {0};
	double Line_Next[7] = {0};
	double Delta_Data[7] = {0};
	double DataToWrite[30][7] = {0};
	double Tempdata = 0;
	int LineNum = 0;
	int Counter = 0;
	int FinishRate = 0;
	FILE *HandleDataFileInput;
	FILE *HandleDataFileOutput;
	
	switch (event)
	{
		case EVENT_COMMIT:
			
			SetCtrlVal (DataFileTransPanelHandle, Data_PANEL_TransStatus, "���ڴ������ݡ�");  
			
			GetCtrlVal (DataFileTransPanelHandle , Data_PANEL_InputPath, InputFliePath);
			GetCtrlVal (DataFileTransPanelHandle , Data_PANEL_OutputPath, OutputFliePath); 
			
			GetCtrlVal (DataFileTransPanelHandle , Data_PANEL_InStepSize, &InStepSize);
			GetCtrlVal (DataFileTransPanelHandle , Data_PANEL_OutStepSize, &OutStepSize);
			InsideNum = InStepSize/OutStepSize;
			
			//�����ļ�����
			HandleDataFileInput = fopen (InputFliePath, "r"); 	
			while(!feof(HandleDataFileInput))
			{
				fscanf (HandleDataFileInput, "%lf", &Tempdata);
				Counter ++;
				if(Counter == 7)
				{
					LineNum ++;
					Counter = 0;
				}
			}
			fclose(HandleDataFileInput); 
//			printf("%d",LineNum);
			
			HandleDataFileInput = fopen (InputFliePath, "r"); 			
			HandleDataFileOutput = fopen (OutputFliePath, "wb"); 			
			
			for(int k = 0; k < LineNum; k ++)
			{
				for(int i = 0; i < 7; i ++)
				{
					fscanf (HandleDataFileInput, "%lf", &Line_Next[i]);
					Delta_Data[i] = (Line_Next[i] - Line_Last[i])/InsideNum;
		
					for(int j = 0; j <= InsideNum - 2; j ++)
					{
					    DataToWrite[j][i] = Line_Last[i] + Delta_Data[i] * (j + 1);
					}
				}
				
				if( k>=1 )
				{
					for(int i = 0; i <= InsideNum - 2; i++)
					{
						for(int j = 0; j < 7; j ++)
						{
							fprintf (HandleDataFileOutput, "%.16f\t", DataToWrite[i][j]); 		
						}
		
						fprintf (HandleDataFileOutput, "\r\n"); 
					}				
				}

				for(int i = 0; i < 7; i ++)
				{
					fprintf (HandleDataFileOutput, "%.16f\t", Line_Next[i]); 	
					Line_Last[i] = Line_Next[i];
				}
				fprintf (HandleDataFileOutput, "\r\n");  
		
				FinishRate = k * 100 / LineNum;
					
				SetCtrlVal (DataFileTransPanelHandle, Data_PANEL_Processing_Slide, FinishRate);  				
			}			
			SetCtrlVal (DataFileTransPanelHandle, Data_PANEL_Processing_Slide, 100); 
			
			SetCtrlVal (DataFileTransPanelHandle, Data_PANEL_TransStatus, "���ݴ�����ϡ�"); 
			
			fclose(HandleDataFileInput);
			fclose(HandleDataFileOutput); 						   
			break;
	}
	return 0;
}

int CVICALLBACK ReturnCallback (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	char panelparsavepath[260];
	switch (event)
	{
		case EVENT_COMMIT:

			GetProjectDir (panelparsavepath);
			
			strcat(panelparsavepath, "\\datapanelsavefile");

			SavePanelState (DataFileTransPanelHandle, panelparsavepath , 0);

			DiscardPanel(DataFileTransPanelHandle); 
			
			DisplayPanel (MainPanelHandle); 
			SetPanelAttribute (MainPanelHandle, ATTR_WINDOW_ZOOM, VAL_MAXIMIZE); 
			break;
	}
	return 0;
}
