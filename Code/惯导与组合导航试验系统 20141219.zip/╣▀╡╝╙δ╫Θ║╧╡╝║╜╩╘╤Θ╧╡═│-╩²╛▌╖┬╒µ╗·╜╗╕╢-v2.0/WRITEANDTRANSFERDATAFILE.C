//==============================================================================
//
// Title:       WriteAndTransferDataFile.c
// Purpose:     A short description of the implementation.
//
// Created on:  2014-11-10 at 10:38:56 by ������.
// Copyright:   014. All Rights Reserved.
//
//==============================================================================

//==============================================================================
// Include files

//#include "WriteAndTransferDataFile.h"

//==============================================================================
// Constants

//==============================================================================
// Types

//==============================================================================
// Static global variables

//==============================================================================
// Static functions

//==============================================================================
// Global variables

//==============================================================================
// Global functions

/// HIFN  What does your function do?
/// HIPAR x/What inputs does your function expect?
/// HIRET What does your function return?
int Define_Your_Functions_Here (int x)
{
    return x;
}
