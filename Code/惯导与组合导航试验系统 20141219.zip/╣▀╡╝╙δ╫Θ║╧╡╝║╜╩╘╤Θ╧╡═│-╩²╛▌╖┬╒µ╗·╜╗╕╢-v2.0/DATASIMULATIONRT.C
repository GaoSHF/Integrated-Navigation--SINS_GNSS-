#include "MAIN_PANEL.h"

//==============================================================================
//
// Title:		rt
// Purpose:		A short description of the application.
//
// Created on:	2013-9-13 at 19:28:33 by Yushuang Liu.
// Copyright:	Beihang University. All Rights Reserved.
//
//==============================================================================
#include <cvintwrk.h>
#include <formatio.h>   
#include <tcpsupp.h>
#include "asynctmr.h"
#include <cvirte.h>
#include <rtutil.h>			
#include <userint.h> 
#include <analysis.h>
#include <utility.h>
#include <cvinetv.h>
#include <ansi_c.h>
#include <Time.h> 

#include "GERFM.h"				         //���俨����
#include "P3531.h"				         //ARINC-429�忨����
#include "RS422.h"				         //RS-422�忨����
#include "acc_simu.h"  					 //����ע�뿨����
#include "rfm.h"						 //���ݷ�����������ؼ����  
#include "DuoJi422.h"

#include "Common.h"  					 //����λ�����ñ�������
#include "GlobalFunction.h"				 //ȫ�ֺ�����
#include "ConstVariable.h"		         //��ֵ��������
#include "PanelInputVariable.h"			 //�����������
#include "ComputeVariable.h"			 //�������
#include "InitialVariable.h"			 //������ʼ�� 

static int gLock;
int gThreadPool	= 0; 

//******************************RT��������ͽṹ������*****************************// 
//ʱ����Ա��
unsigned int Inner_Time_Flag;
unsigned int Start_Time_Flag;
unsigned int Stop_Time_Flag;

//��ʱ��ID
int CraftTrace_TimerID;
int CurrentWrite_TimerID;

//�ṹ������
DataMessage data;                        //�ϴ����ݡ�״̬�ṹ��
CommandMessage cmd;			             //����ָ��ṹ��

struct TRfmCardTransRec  lRfmTransRec;   //TRfmCardTransRecf��GNSSģ��������Э��Ľṹ��
struct GNSS_SimStartCMD  GNSS_Start;

RFM_FireControl_Data  RFMFireControlData; 

//���»�Ӳ���豸���
RS422_DevHandle RS422_hDev; 
RS422_DevHandle RS422_hDev1;
RS422_DevHandle RS422_hDev2;

volatile int	gDone;                   //RT���߳�ֹͣ����
static int 		gRFMInt_ThdLock;         //ң�ش����߳���

int CraftTraceInitial_Flag;              //�ж�TCPDataCallback�����Ƿ�ִ����ı�־
int DataTraceInitial_Flag;               //�жϳ̿ص������Ƿ��ȡ��ϱ�־
int MisTraceIniDone_Flag;				 //�����켣���ɳ�ʼ����� �������Timer
int CraftFlightZhuanWanFlag=0;     		 //����ת���жϱ�־

int TimerHandleCurrentOffset;

double Time_RotaryShake = 0;
double Time_ShakeStart = 0;

int CountFireControlInt = 0;

int GNSS_Init_Counter = 0;

int MC_Control_CMD; //ң��ָ���־

int ii;

//******************************��������*****************************// 

int CVICALLBACK TCPDataCallback 	//TCPͨѶ�ص�����
	(unsigned handle, int xType, int errCode, void *cbData);
void Update(void); 
void StartCMDCallback(void);		//ʵ�����ָ��� 
void StopCMDCallback(void);
void QuitCMDCallback(void);

//�ػ���λ������
void CraftTraceCMDCallback(void);   //�ػ��켣���ƺ��� 
void StartCraftTrace(void);			//��ʼ�ػ��켣����
void StopCraftTrace(void);			//ֹͣ�ػ��켣����
void CraftTraceGenerate(void); 		//�����ػ��켣  
void DataTraceGenerate(void); 		//������ȡ���ݹ켣  
void CraftNav(void);				//�ػ����ߵ�����
void FcsNav(void);					//�ػ���س���

//������λ������
void MisTraceCMDCallback(void);		//�����켣���ƺ��� 
void StartMisTrace(void);
void StopMisTrace(void);
void MisTraceGenerate(void);		//���������켣
int MisSmooth(double MisSF_SmoothStart[3][1], double MisAng_SmoothStart[3][1],    //�����켣�μ�ƽ������ 
	          double MisSF_SmoothValue[3][1], double MisAng_SmoothValue[3][1],
			  double MisSmoothT, double MisStepTS);   
void MisTraceRotaryWrite(void);		//ת̨����ָ��д�� 

//GNSSģ����ָ���
void GNSS_GE_Write(double Position[3][1], double Velocity[3][1], double Acc[3][1]);             //�ػ��켣����д������ģ�����ⷴ��
void GNSS_GE_Initial(long long GNSS_TraceStartTimetart, long long GNSS_TraceTimeLast, double IniPosition[3][1]);//, double IniAngle[3][1]);  //�ⷴ����������ģ������ʼ������
void SendTrackDataToGNSS(char * pData, int iDataCount); 	//�ⷴ��д���켣
void SendAGCSetCMDTOGNSS(unsigned int AGC_Value); 			//ģ������������ָ��
void SendAGCChangeCMDTOGNSS(unsigned int SatGroup, 			//ģ����������������ָ�� 
							unsigned int SatNum, unsigned int TimeStart, unsigned int AGCValueStart,
							unsigned int TimeStop, unsigned int AGCValueStop, unsigned int FlagChange);
void SendPseudorangeChangeCMDTOGNSS(unsigned int SatGroup,  //ģ����α����������ָ��
									unsigned int SatNum, unsigned int PRChange, unsigned int TimeChange);
void SendStartCMDToGNSS(char * pData, int iDataCount);  	//ģ������ʼָ��
void SendStopCMDToGNSS(void);								//ģ����ָֹͣ��

//תָ̨���
int Initial_RotaryTab				//ת̨��ʼ��������ָ�
	(double Rotary_Angle_Inner , double Rotary_Angle_Mid , double Rotary_Angle_Outer);

void TraceToRotary				    //ת̨�ǶȻ���
	(double TraceAttitude[3][1], double TraceAttitudeRate[3][1], float RotaryAttitude[3][1], float RotaryAttitudeRate[3][1]);

void RotaryTabShake					//ת̨ҡ�ڹ���
	(float RotaryAttWithoutshake[3][1], float RotaryRateWithoutshake[3][1],
     float RotaryAttWithshake[3], float RotaryRateWithshake[3],
	 double AmpleShake[3], double FrequenceShake[3], double PhaseShake[3],
	 double Time_Shake);

//�ػ��켣�����ߵ����㡢��ؼ��㶨ʱ���ص�����
int CVICALLBACK CraftTrace_Timer (int reserved, int timerId, int event, void *callbackData, int eventData1, int eventData2);
int CVICALLBACK CraftNav_Timer   (int reserved, int timerId, int event, void *callbackData, int eventData1, int eventData2);
int CVICALLBACK FcsNav_Timer     (int reserved, int timerId, int event, void *callbackData, int eventData1, int eventData2);
int CVICALLBACK CraftNavFcs_Timer(int reserved, int timerId, int event, void *callbackData, int eventData1, int eventData2);

//�����켣��ʱ���ص����� 
int CVICALLBACK MisTraceTimer    (int reserved, int timerId, int event, void *callbackData, int eventData1, int eventData2); 
int CVICALLBACK CurrentWrite_Timer(int reserved, int timerId, int event, void *callbackData, int eventData1, int eventData2);
int CVICALLBACK CurrentOffsetTimer(int reserved, int timerId, int event, void *callbackData, int eventData1, int eventData2); 

//���ͨ���߳�
static int CVICALLBACK ThreadFunctionDuoJi422(void *functionData); 	

//�ļ��洢����
void CraftDataWriteToMemory(void);
void CraftDataWriteToFile(void);
void MissileDataWriteToMemory(void); 
void MissileDataWriteToFile(void); 	
void GetData(void);

//����ֵ��ʼ��
void InitCurrentBoard(void);   


//��λ�������� 
void CVIFUNC_C RTmain (void)
{
	unsigned int prevProcessorMask = 0;
	
	if (InitCVIRTE (0, 0, 0) == 0)
		return;   
	
	ConfigureProcessorPool (kProcessorPool_System, 0x1, &prevProcessorMask);
	
	gDataConnection = TCP_INVALID_CONNECTION;
	
	CmtNewLock (0, 0, &gLock);
	
	CmtNewThreadPool (5, &gThreadPool);	
	
	CmtNewLock (0, 0, &gRFMInt_ThdLock); 
	
	//����TCP���ӷ�����
	if(RegisterTCPServer (HOST_PORT, TCPDataCallback, 0) == 0)  
		printf("TCP Server created successfully.\n");
	
	//�ⷴ����ʼ�� 
	rfmInitDS();  
	
	//��ʼ������ע�뿨
	accsimuInit (&DC0);      
	accsimuInit (&DC1); 
	accsimuInit (&DC2);
	
	while (!RTIsShuttingDown () && !gDone)
	{
		//�����켣���ɳ�ʼ����� �����켣��ʼ����
		if (MisTraceIniDone_Flag==1)  
		{   
			SuspendAsyncTimerCallbacks ();
			//ʹ�ýϸ����ȼ��Ķ�ʱ����֤�����ʵʱ��
			NewAsyncTimerWithPriority (MisStepTimeSec, -1, 1, MisTraceTimer, 0, 9);  
			ResumeAsyncTimerCallbacks ();
			MisTraceIniDone_Flag=0;
		}

		ProcessSystemEvents();
		SleepUS (100000);
	}

	DiscardAsyncTimer (-1); 
	
	UnregisterTCPServer(HOST_PORT);
	
	//�رյ���ע�뿨 
	accsimuClose (&DC0);       
	accsimuClose (&DC1);
	accsimuClose (&DC2);
	
	//�رչⷴ��DMA���ⷴ��
	rfmDisableDMA();
	GERFM_CloseDevice(&GERFM_hDev); 
	
	CmtDiscardLock (gRFMInt_ThdLock); 
	CmtDiscardThreadPool (gThreadPool); 

	Done:
		CloseCVIRTE ();
}

//TCPͨѶ������������λ��ָ�����
CVICALLBACK TCPDataCallback (unsigned handle, int xType, int errCode, void *cbData)
{
    switch (xType)						    
    {
	    case TCP_CONNECT:
			//������Ч���ж��Ƿ�Ϊ��������
	        if (gDataConnection != TCP_INVALID_CONNECTION)		                                 
	            DisconnectTCPClient (handle);
	        //���ӵ���λ��
			else
			{
	            gDataConnection = handle;
				printf("TCP connection created.\n");
				data.status = TCP_CONNECTED;
				Update();
			}
	        break;
        case TCP_DISCONNECT:
            gDataConnection = TCP_INVALID_CONNECTION;
            break;
        case TCP_DATAREADY: 
			ServerTCPRead (gDataConnection, &cmd, sizeof(cmd), 5000);
			strcpy(HostDataPath, cmd.HostDataPath);
			switch(cmd.command)
			{
				case INITIAL_COMMAND: //�����λ������λ�������ݴ���
					
					switch(cmd.tracemode)
					{    			
						case CRAFT_MODE:
							ServerTCPWrite(gDataConnection, &cmd, sizeof(cmd), 5000);
							ServerTCPRead (gDataConnection, &CraftPara, sizeof(CraftPara), 5000); 
                    	
							ServerTCPWrite(gDataConnection, &cmd, sizeof(cmd), 5000);
							ServerTCPRead (gDataConnection, &CraftTrace, sizeof(CraftTrace), 5000);
							//�ش�״̬
							data.status = GNSS_ROTARY_INIT_START;
							Update(); 

							//��ʼ���ػ�����
							InitialConstVariable(); 
							IniRTCraftVariable(cmd.tracemode); 
						    InitialPanelInputVariable(); 
							
							//��ʼ������ģ���� 
						    //��ʼ��������ⷴ���洢����
							viMoveOut8 (GERFM_hDev.GERFM_instr, VI_PXI_BAR3_SPACE,0x500, sizeof(CraftPara),(char *)&CraftPara);  
							GNSS_Sim_Init_Start_Flag = GetTimeUS();
								//ģ����ָ���ѯλ����ֵ
							viMoveOut8 (GERFM_hDev.GERFM_instr, VI_PXI_BAR3_SPACE, 0x500, 4, (char*)&glRfmComPtkID_CMD);
							
							time(&Time_Now);

							GNSS_TraceStartTime = 1000*difftime(Time_Now , mktime(&Time2006));
						    GNSS_GE_Initial(GNSS_TraceStartTime, GNSS_TraceTime, CraIniPos_WGS84); 
							
							InitMis_Att(CraftIniRoll, CraftIniPitch, CraftIniYaw,
								        &Rotary_Ini_In, &Rotary_Ini_Mid, &Rotary_Ini_Out);
							
							printf("%lf\t%lf\t%lf\n",Rotary_Ini_In, Rotary_Ini_Mid, Rotary_Ini_Out );
							
							//ת̨��ʼ������������ʼλ�ã�
			                Initial_RotaryTab(Rotary_Ini_In, Rotary_Ini_Mid, Rotary_Ini_Out);
							//��������ʼ��
							InitCurrentBoard();
							//�ж�ģ�����Ƿ�׼����
							do
							{
								if(GNSS_Init_Counter == 250)//25s��ʱ����
								{
									GNSS_Init_Counter = 0; 
									printf("GNSS timeout & GNSS_OK_Flag = %x\n", GNSS_OK_Flag); 

									data.status = GNSS_INIT_FAIL;									
									Update();
									break; 
								}
								viMoveIn8 (GERFM_hDev.GERFM_instr, VI_PXI_BAR3_SPACE, 0x5300, 4, (char*)&GNSS_OK_Flag);
								SleepUS(100000);
								GNSS_Init_Counter++;							
							}
							while(GNSS_OK_Flag != 0xffffffff); 

							if(GNSS_OK_Flag == 0xffffffff)
							{
								GNSS_Init_Counter = 0; 
								printf("Got GNSS signal & GNSS_OK_Flag = %x\n", GNSS_OK_Flag);
								data.status = GNSS_INIT_DONE;
								Update();								
							}

							break;
							
						case DATARD_MODE:
							
							if(cmd.SensorDataTrans_Flag == 0)
							{
								ServerTCPWrite(gDataConnection, &cmd, sizeof(cmd), 3000);
								ServerTCPRead (gDataConnection, &CraftPara, sizeof(CraftPara), 3000);
							
								data.status = MISPRO_FILE_READ;
								Update(); 								
							}
							else if(cmd.SensorDataTrans_Flag == 1)
							{
								InitialConstVariable();
								IniRTCraftVariable(cmd.tracemode); 
						        InitialPanelInputVariable(); 
								
						        CraftVelocity[0][0]=-130.7813;
						        CraftVelocity[1][0]=-0.78125;
						        CraftVelocity[2][0]=-232.42188;
								
								data.status = GNSS_ROTARY_INIT_START;
								Update(); 

								//��ʼ������ģ���� 
							
						        //��ʼ��������ⷴ���洢����
							    viMoveOut8 (GERFM_hDev.GERFM_instr, VI_PXI_BAR3_SPACE,0x500, sizeof(CraftPara),(char *)&CraftPara);  
							    GNSS_Sim_Init_Start_Flag = GetTimeUS();
							    //ģ����ָ���ѯλ����ֵ
							    viMoveOut8 (GERFM_hDev.GERFM_instr, VI_PXI_BAR3_SPACE, 0x500, 4, (char*)&glRfmComPtkID_CMD);
							
							    time(&Time_Now);

							    GNSS_TraceStartTime = 1000*difftime(Time_Now , mktime(&Time2006));
						        GNSS_GE_Initial(GNSS_TraceStartTime, GNSS_TraceTime, CraIniPos_WGS84); 
							
							    InitMis_Att(CraftIniRoll, CraftIniPitch, CraftIniYaw,
								            &Rotary_Ini_In, &Rotary_Ini_Mid, &Rotary_Ini_Out);

							    //ת̨��ʼ������������ʼλ�ã�
			                    Initial_RotaryTab(Rotary_Ini_In, Rotary_Ini_Mid, Rotary_Ini_Out);
							
						      	//�ж�ģ�����Ƿ�׼����
							    do
							    {
									if(GNSS_Init_Counter == 250)//25s��ʱ����
									{
										GNSS_Init_Counter = 0; 
										printf("GNSS timeout & GNSS_OK_Flag = %x\n", GNSS_OK_Flag); 

										data.status = GNSS_INIT_FAIL;									
										Update();
										break; 
									}
									viMoveIn8 (GERFM_hDev.GERFM_instr, VI_PXI_BAR3_SPACE, 0x5300, 4, (char*)&GNSS_OK_Flag);
									SleepUS(100000);
									GNSS_Init_Counter++;							
							     }
								while(GNSS_OK_Flag != 0xffffffff); 

								if(GNSS_OK_Flag == 0xffffffff)
								{
									GNSS_Init_Counter = 0; 
									printf("Got GNSS signal & GNSS_OK_Flag = %x\n", GNSS_OK_Flag);
									data.status = GNSS_INIT_DONE;
									Update();								
								}										
							}
							else;

							break;							
							
							
							
					    case MISGUI_MODE:
							ServerTCPWrite(gDataConnection, &cmd, sizeof(cmd), 10000);
							ServerTCPRead (gDataConnection, &MisPara, sizeof(MisPara), 10000);
							
		 		        	ServerTCPWrite(gDataConnection, &cmd, sizeof(cmd), 10000);
							ServerTCPRead (gDataConnection, &TarData, sizeof(TarData), 10000); 
                            
							//�ش�״̬
							data.status = GNSS_ROTARY_INIT_START;
							Update(); 
							
							InitialConstVariable();    
							IniRTMisVariable(MISGUI_MODE);
							
							GNSS_Sim_Init_Start_Flag = GetTimeUS();
							//��ʼ������ģ���� 
						//	GNSS_GE_Initial(MisIniPos_WGS84, MisIniVel_WGS84, MisIniAcc_WGS84);
							GNSS_Sim_Init_Done_Flag = GetTimeUS();
							//ת̨��ʼ������������ʼλ�ã�
							Initial_RotaryTab(MissileIniRoll, MissileIniPitch, MissileIniYaw);
							while( abs(GNSS_Sim_Init_Done_Flag - GNSS_Sim_Init_Start_Flag) < 25000000 )
							{
								GNSS_Sim_Init_Done_Flag = GetTimeUS(); 
								SleepUS(1000000);
							}
							data.status = GNSS_INIT_DONE;
							Update(); 
							
							break;
							
						case MISFREE_MODE:
							ServerTCPWrite(gDataConnection, &cmd, sizeof(cmd), 10000);
							ServerTCPRead (gDataConnection, &MisPara, sizeof(MisPara), 10000); 
							
							ServerTCPWrite(gDataConnection, &cmd, sizeof(cmd), 10000);
							ServerTCPRead (gDataConnection, &MisTrace, sizeof(MisTrace), 10000);
							
							InitialConstVariable();    
							IniRTMisVariable(MISFREE_MODE);

				        	//ת̨��ʼ������������ʼλ�ã�
				//			data.status = DATA_ROTARY_INIT_START;
				//			Update(); 							
				//			Initial_RotaryTab(MissileIniRoll, MissileIniPitch, MissileIniYaw);  
							break;
							

					}
					break;
					
				case START_COMMAND: 	 
					StartCMDCallback(); 
					break;
					
				case STOP_COMMAND:
					StopCMDCallback();    
					break; 
					
				case UPDATE_COMMAND:
					GetData();
					break; 	
				
				case CURRENT_OFFSET:
					if(cmd.CurrentButtonStatus == 1)
					{
						DC0.currentLevel = 0;
						accsimuSet4141 (DC0);
						TimerHandleCurrentOffset =	NewAsyncTimer (0.01, -1, 1, CurrentOffsetTimer, 0);  
					}
					else
						DiscardAsyncTimer (TimerHandleCurrentOffset);   
					break;
				
				case ROTARY_SHAKE:
					 //ȡҡ����ʼʱ��					 
					 Time_ShakeStart = TraceTime;
					 
					 if(cmd.RotaryTabShakeStatus == ALL_STOP)
					 { flag_Shake_out = 0; flag_Shake_mid = 0; flag_Shake_in = 0; }   
					
					 if(cmd.RotaryTabShakeStatus == ALL_SHAKE)
					 { flag_Shake_out = 1; flag_Shake_mid = 1; flag_Shake_in = 1; } 						 
					
					 if(cmd.RotaryTabShakeStatus == ONLY_OUT)
					 { flag_Shake_out = 1; flag_Shake_mid = 0; flag_Shake_in = 0; } 			
					 
					 if(cmd.RotaryTabShakeStatus == ONLY_MID)
					 { flag_Shake_out = 0; flag_Shake_mid = 1; flag_Shake_in = 0; } 					 
					 
					 if(cmd.RotaryTabShakeStatus == ONLY_INN)
					 { flag_Shake_out = 0; flag_Shake_mid = 0; flag_Shake_in = 1; } 					 
					
					 if(cmd.RotaryTabShakeStatus == OUT_MID)
					 { flag_Shake_out = 1; flag_Shake_mid = 1; flag_Shake_in = 0; } 					 
					 
					 if(cmd.RotaryTabShakeStatus == OUT_INN)
					 { flag_Shake_out = 1; flag_Shake_mid = 0; flag_Shake_in = 1; } 					 
					 
					 if(cmd.RotaryTabShakeStatus == MID_INN)
					 { flag_Shake_out = 0; flag_Shake_mid = 1; flag_Shake_in = 1; } 

					break;
					
				case QUIT_COMMAND:
					QuitCMDCallback();    
					break; 
				//���԰�ť			
				case TEST_1:
					printf("Got Test 1 command.\n");  

					int No1;
					No1 = 0xffffffff;//cmd.Test_parameter;
		      		viMoveOut8 (GERFM_hDev.GERFM_instr, VI_PXI_BAR3_SPACE, 0x5300, 4, (char*)&No1);
					viMoveIn8 (GERFM_hDev.GERFM_instr, VI_PXI_BAR3_SPACE, 0x5300, 4, (char*)&GNSS_OK_Flag); 
					printf("GNSS_OK_Flag = %x\n", GNSS_OK_Flag);
					
			/*		printf("size_double = %d\n", sizeof(double));	
					printf("size_long = %d\n", sizeof(long));
					printf("size_longlong = %d\n", sizeof(long long));
					printf("size_int = %d\n", sizeof(int));
					printf("size_un_int = %d\n", sizeof(unsigned int));
					printf("size_long_int = %d\n", sizeof(long int)); 					
					printf("size_float = %d\n", sizeof(float)); 
					printf("size_short = %d\n", sizeof(short));  
					
				*/
					break; 					
				
				case TEST_2:
				    printf("Got Test 2 command.\n");
				/*	
					int No2;
					No2 = 0x00000000;//cmd.Test_parameter;
		      		viMoveOut8 (GERFM_hDev.GERFM_instr, VI_PXI_BAR3_SPACE, 0x5300, 4, (char*)&No2);
					viMoveIn8 (GERFM_hDev.GERFM_instr, VI_PXI_BAR3_SPACE, 0x5300, 4, (char*)&GNSS_OK_Flag); 
					printf("GNSS_OK_Flag = %x\n", GNSS_OK_Flag);				   
    		    */		
					SendAGCSetCMDTOGNSS((unsigned int) cmd.Test_parameter); 
					break; 	
					
				case TEST_3:
					printf("Got Test 3 command.\n");
					
					SendPseudorangeChangeCMDTOGNSS(0, 0, 20, 10);
					
					//SendAGCChangeCMDTOGNSS(0, 0, 20, 0, 25, 1, 1);
					
					break; 	
			}
            break;					
    }
    return 0;
}

//��ʼָ��
void StartCMDCallback(void)   
{
	//Ϊ�洢�켣���ݷ����ڴ�ռ� 
	SimDataAddrOffset = 0;
	SimDataIniLength = 40000000;	   
	SimulationDataSaveAddr = (double *) malloc (sizeof(double)*SimDataIniLength);  

	switch(cmd.tracemode)
	{
		case CRAFT_MODE:
			StartCraftTrace();
			break;
		case DATARD_MODE:
			MissileMode = DATARD_MODE; 
		    StartCraftTrace();
			break;
		case MISGUI_MODE:
			MissileMode = MISGUI_MODE; 
		    StartMisTrace();
			break;
		case MISFREE_MODE:
			MissileMode = MISFREE_MODE;  
		    StartMisTrace();
			break;
	}
}
													   
//ָֹͣ��
void StopCMDCallback(void)	 
{
    //ң��ֹͣ���ػ�ʵ��ָ��
	//��ѯ��ʽ����ָ��
	MC_Control_CMD = RFM_CMD_MC_STOP; 
	viMoveOut8 (GERFM_hDev.GERFM_instr, VI_PXI_BAR3_SPACE, 0x96, 4, (char *)&MC_Control_CMD); 	
	//�жϷ�ʽ����ָ��
//	rfmStopMC();
	
	switch(cmd.tracemode)
	{
		case CRAFT_MODE:
			StopCraftTrace();
			break;
		case DATARD_MODE:
			StopCraftTrace(); 
			free(SensorDataAddr);    //�ͷ���ǰ�������ݵ��ڴ�
			break;			
		case MISGUI_MODE:
			StopMisTrace();
			break;
		case MISFREE_MODE:
			StopMisTrace();
			break;

	}
	SleepUS(1000);
	//�ͷŴ��ʵ�����ݵ��ڴ�
	free(SimulationDataSaveAddr);
}

//�˳�ָ��
void QuitCMDCallback(void)	  
{
	gDone = 1;            //RT���߳�ֹͣ
	printf("Quit RT program successfully.\n");
}
 void InitParaFunc()
 {
	MissileSFCompensate[0][0]=0;   
	MissileSFCompensate[2][0]=0;  
	MissileSFCompensate[1][0]=0;
 }
//**************************�ػ��켣��������*************************//

void StartCraftTrace()   
{
	data.status = TRACE_START;
	Update();
	printf("Generating ... ...\n\n"); 
	TimerCounter = 0; 
	InitParaFunc();
	NewAsyncTimer (0.002, -1, 1, CurrentWrite_Timer, 0); 
	
	SleepUS(200); 
	
	MC_Control_CMD = RFM_CMD_MC_START;
	
	viMoveOut8 (GERFM_hDev.GERFM_instr, VI_PXI_BAR3_SPACE, 0x32, 8,(char *)&TransferAlignmentTime);
	viMoveOut8 (GERFM_hDev.GERFM_instr, VI_PXI_BAR3_SPACE, 0x96, 4,(char *)&MC_Control_CMD);  	
	
	SleepUS(1000000); 	
	
	NewAsyncTimer (CraftTraceStepSize, -1, 1, CraftTrace_Timer, 0);  
}

void StopCraftTrace()   
{
    int status; //�忨���
	int iTemp;
	
	SetAsyncTimerAttribute (CraftTrace_TimerID, ASYNC_ATTR_ENABLED, 0);
	SleepUS(1000);
	SetAsyncTimerAttribute (CurrentWrite_TimerID, ASYNC_ATTR_ENABLED, 0); 
	
	DiscardAsyncTimer (-1); 

	//ת̨����ָ�����һ��
	CraftAngRate_Rotary[0] = 0;
	CraftAngRate_Rotary[1] = 0;
	CraftAngRate_Rotary[2] = 0;
	
	rfmRotaryTrack(CraftAttitude_Rotary , CraftAngRate_Rotary, RotaryAngleGet, RotaryRateGet);
	
	data.status = DATA_DISPLAY;
	data.TraceStatus = TRACE_FINISHED_CRAFT; 	
	Update();		
	
	data.status = TRACE_FINISHED;
	Update();	
	
	printf("Trace finished and rotary table start resetting.\n.");
	
	//����ʱ�ٸ�λ��ʵ�鿪ʼλ��     
	Initial_RotaryTab(Rotary_Ini_In, Rotary_Ini_Mid, Rotary_Ini_Out);    
	
	printf("Rotary reset finished.\n"); 	

	//�������ź�ģ�������ͽ����ź�
    SendStopCMDToGNSS();

	if(cmd.DataSaveFlag == 1)
	{
		data.status = TRACE_SAVING; 
		Update();   
	    CraftDataWriteToFile();
		data.status = DATA_SAVE_FINISHED;
		Update();
	}
	printf("Craft Trace Generate Finished !\n");
	printf("TimerCounter = %d\n",TimerCounter ) ;  
}

//�ػ��켣��ʱ��
int CVICALLBACK CraftTrace_Timer(int reserved, int timerId, int event, void *callbackData,
	                              int eventData1, int eventData2)
{
	CmtGetLock (gLock); 
	
	if (event == EVENT_TIMER_TICK)	  
	{
		//�켣ģʽѡ��
		if(cmd.tracemode == CRAFT_MODE)   
	     	CraftTraceGenerate();   
		else if(cmd.tracemode == DATARD_MODE) 	  
			DataTraceGenerate();
		else;
		
		//Timer�ڹ켣��ֹͣʱ������timer�Ļص�����������ֹͣ
		//�ñ�־��֤��Timerָֹͣ��������³���������
		if(CraTraceStop_Flag != 1)
		{	
			//����ģ�����켣��������
			if(TimerCounter %10 == 0)
			{   
				TraceTime2GNSS = GetTimeUS()%1000;
				
				//�켣���������������ݴ���������ģ���� 
			 	GNSS_GE_Write(CraftPositionWGS84, CraftVelocityGNSS, CraftAccGNSS); 
			}
			
			//���ߵ���������   
			if(TraceTime >= CraNavStartTime)  
			{   
		        FrequencyControl(&CountCraftNav,&MaxCountCraftNav,&CraftNavFlag);  //�������ߵ�������־λ
				
				if (CraftNavFlag == 1)  //���ߵ�������Ч 
			    {
			        CraftNav();
			    }
			}
			
			//��ص�������
			if(TraceTime >= FcsNavStartTime)
			{
			    FrequencyControl(&CountFcsNav, &MaxCountFcsNav,&FcsNavFlag); 		//���»�ص�����Ч��־
			    FrequencyControl(&CountSAcce,&MaxCountSAcce,&MissileAcceFlag);    	//�����ӼӼ���Ч��־
			    FrequencyControl(&CountSGyro,&MaxCountSGyro,&MissileGyroFlag);   	//������������Ч��־	
				
				if(FcsNavFlag == 1)
				{
			        FcsNav();
					
					// ����������д���ؽṹ�壬�ùⷴ�����͵����ؼ����
					RFMFireControlDataTx.temp[0] = AcurrentLevel_x;
					RFMFireControlDataTx.temp[1] = AcurrentLevel_y;
					RFMFireControlDataTx.temp[2] = AcurrentLevel_z;
					
					//�����ػ����ͻ�����ݣ�����DMA�Ͳ�ѯ��־λ��ģʽ��
					CountFireControlInt ++;
					if (CountFireControlInt == 1)
					{
						CountFireControlInt = 0;
						rfmFireControl_Send();	
					}
				}
			}
																			  
			//Ϊ��ʼ�����ڴ�ռ�����һ����ʼ����SimDataIniLength  				
			if(MemoryReallocFlag == 1)
			{
	            SimulationDataSaveAddr = (double *) realloc (SimulationDataSaveAddr,  
		                    sizeof(double)*SimDataIniLength*(SimDataAddrOffset/SimDataIniLength+2));
				MemoryReallocFlag = 0;
			}														 
			
			//�켣��������ֱ�Ӵ����ڴ�
			CraftDataWriteToMemory(); 				
			
/*			//���ػ���ʼ��������ָ��
			if( (TraceTime - CraftTraceStepSize - SimulationStartTime <= 0.0009)&&
				(TraceTime - CraftTraceStepSize - SimulationStartTime >= -0.0009) )
			{
				//ң�����ػ���ʼ����ָ��
				//��ѯ��ʽ����ָ��
				MC_Control_CMD = RFM_CMD_MC_START;
				
				viMoveOut8 (GERFM_hDev.GERFM_instr, VI_PXI_BAR3_SPACE, 0x32, 8,(char *)&TransferAlignmentTime);
			//	printf("TransferAlignmentTime = %lf\n",TransferAlignmentTime);
				viMoveOut8 (GERFM_hDev.GERFM_instr, VI_PXI_BAR3_SPACE, 0x96, 4,(char *)&MC_Control_CMD);  
				//�жϷ�ʽ����ָ��
			//	rfmStartMC(TransferAlignmentTime);
			}														
*/			
			//����λ���ش�ʵʱ�켣����
			if(TimerCounter % 100 == 0)
			{
				data.status = DATA_DISPLAY;
		
				data.TraceStatus = TRACE_GENERATING_CRAFT;

				data.TraceTime = TraceTime;
				data.TraceLon = CraftPosition[0][0]/DEGREE;
				data.TraceLat = CraftPosition[1][0]/DEGREE; 
				data.TraceAlt = CraftPosition[2][0]; 
				data.VelocityE = CraftVelocity[0][0]; 
				data.VelocityN = CraftVelocity[1][0]; 
				data.VelocityU = CraftVelocity[2][0]; 
				data.TraceYaw = CraftAttitude[0][0]/DEGREE;
				data.TracePitch = CraftAttitude[1][0]/DEGREE;
				data.TraceRoll =  CraftAttitude[2][0]/DEGREE;
				data.RotaryOut = RotaryAngleGet[2];
				data.RotaryMid = RotaryAngleGet[1];
				data.RotaryIn =  RotaryAngleGet[0];
				
				data.FC_PosX = FcsPos[0][0];
				data.FC_PosY = FcsPos[1][0]; 
				data.FC_PosZ = FcsPos[2][0]; 
				data.FC_VelX = FcsVel[0][0];
				data.FC_VelY = FcsVel[1][0];
				data.FC_VelZ = FcsVel[2][0];
				data.FC_Qua0 = FcsQtn[0][0];
				data.FC_Qua1 = FcsQtn[1][0]; 
				data.FC_Qua2 = FcsQtn[2][0]; 
				data.FC_Qua3 = FcsQtn[3][0]; 
			
				Update();
			}													
		}   
	}
	TimerCounter++;		
	
	CmtReleaseLock (gLock);  
	
	return 0;			  
}

//�ػ��켣��������
void CraftTraceGenerate()
{
	//���ڳ�ʼ����־��ÿ�ι켣ִֻ��һ��
	if(CraftTraceLoopFlag == 0)   
	{   
		//ÿ�η��й켣�ķ���ʱ����Ի��ֲ���Ϊÿ�η��й켣�Ĳ�������
		SampleNum = (int)(EachCraftTraceTime[iCraft] / CraftTraceStepSize);
		//����ʱ�䣬�����ٶȣ�ƽ��������ʱ��̶� 							  
		Tg = EachCraftTraceTime[iCraft] * SmoothTimePercent; 
		//ƽ��ʱ��
		Tw = EachCraftTraceTime[iCraft] * (1.0 - SmoothTimePercent);
        Omega=pi / Tg; 
		//��ÿ�ι켣��ʼʱ��Ҫ��TzG��ֵΪCraftTraceStepSize 
	    TzG[0] = CraftTraceStepSize;   
	    TzG[1] = CraftTraceStepSize;
	    TzG[2] = CraftTraceStepSize;
	    TzA = CraftTraceStepSize;
		
		CraftAttitudeChangeCraft[0][iCraft] = CraftAttitudeChange[0][iCraft] * DEGREE;
		CraftAttitudeChangeCraft[1][iCraft] = CraftAttitudeChange[1][iCraft] * DEGREE;
		CraftAttitudeChangeCraft[2][iCraft] = CraftAttitudeChange[2][iCraft] * DEGREE;			

		//����ģ��
		//�ȽǷ���ģ��
		if(CraftFlightState[iCraft] == CraftDengJiaoFeiXing)
	    {
			 CraftAttitudeChangeRateExpect[0][iCraft] = 0 ;
			 CraftAttitudeChangeRateExpect[1][iCraft] = 0 ;
			 CraftAttitudeChangeRateExpect[2][iCraft] = 0 ;
	    	 CraftFlightZhuanWanFlag = 0 ;
			 CraftAttitudeChangeRate[0][0] = 0;
			 CraftAttitudeChangeRate[1][0] = 0;
			 CraftAttitudeChangeRate[2][0] = 0;
		}
	    //�����˶�ģ�� 
	    if (CraftFlightState[iCraft] == CraftFuYangYunDong)
        {  											  
            CraftAttitudeChangeRateExpect[1][iCraft] = CraftAttitudeChangeCraft[1][iCraft] / (EachCraftTraceTime[iCraft] * (1.0 - SmoothTimePercent));//��ÿ�����ֲ����ڣ��������ٶ�Ԥ�ڱ仯ֵ
			CraftFlightZhuanWanFlag = 0;
		}
	    //������ƽģ��
		if (CraftFlightState[iCraft] == CraftFuYangGaiPing)
        {
            CraftAttitudeChangeRateExpect[1][iCraft] = (-CraftAttitude[1][0]) / (EachCraftTraceTime[iCraft] * (1.0 - SmoothTimePercent));//��ÿ�����ֲ����ڣ��������ٶ�Ԥ�ڱ仯ֵ
			CraftFlightZhuanWanFlag = 0;
		}										  
        //ת���ƽģ�ͣ������ǽ����еĺ���Ǳ�Ϊ��
		if (CraftFlightState[iCraft] == CraftZhuanWanGaiPing)
        {
			CraftAttitudeChangeRateExpect[1][iCraft]=0;
			CraftAttitudeChangeRateExpect[2][iCraft]=(-CraftAttitude[2][0]) / (EachCraftTraceTime[iCraft] * (1.0 - SmoothTimePercent));
			CraftFlightZhuanWanFlag = 1;
		}
	    //һ����ģ�ͣ�����Ǳ仯���ٻ��ȣ����Թ켣�仯ʱ�䣬�õ���̬�仯��
		if (CraftFlightState[iCraft] == CraftYiBanHengGun)
        {
			CraftAttitudeChangeRateExpect[0][iCraft] = 0; 
			CraftAttitudeChangeRateExpect[1][iCraft] = 0; 
            CraftAttitudeChangeRateExpect[2][iCraft] = CraftAttitudeChangeCraft[2][iCraft] / (EachCraftTraceTime[iCraft] * ( 1.0 - SmoothTimePercent));
			CraftFlightZhuanWanFlag = 0;
		}
		//һ��ת��ģ�ͣ�������Ǳ仯
		if((CraftFlightState[iCraft] == CraftYiBanZhuanWan))
		{
			CraftAttitudeChangeRateExpect[0][iCraft] = CraftAttitudeChangeCraft[0][iCraft] / (EachCraftTraceTime[iCraft] * (1.0 - SmoothTimePercent));
			CraftAttitudeChangeRateExpect[1][iCraft] = 0; 
			CraftAttitudeChangeRateExpect[2][iCraft] = 0;
			CraftFlightZhuanWanFlag = 0;
		}
		
	}//if(CraftTraceLoopFlag==0) ����		
	//��ʼ�ڶ���ѭ��(����)�����ݵ�һ��ѭ�������ÿ���ػ��켣�еĲ���������ȷ��ѭ������
	if (jCraft <= SampleNum)
	{   
		//��¼ʱ��,��ÿ���ػ��켣ʱ��
		TraceTime = CraftTraceStepSize + TraceTime;
		//ת��Ѳ�����к����ʱ�Ž�ת��Ѳ��
		if(CraftFlightState[iCraft] == CraftZhuanWanXunHang) 
		{
			CraftFlightZhuanWanFlag = 1;
			
			CraftAttitudeChangeRateExpect[0][iCraft] = 0; 
			CraftAttitudeChangeRateExpect[1][iCraft] = 0; 
			CraftAttitudeChangeRateExpect[2][iCraft] = 0;
		}			
		//Э��ת�䣬�����ʱ仯�ڶ�����ʱ��ı�
        else if ((CraftFlightState[iCraft] == CraftXieTiaoZhuanWan)) 
        {
			CraftAttitudeChangeRateExpect[1][iCraft] = 0;  			
			CraftAttitudeChangeRateExpect[2][iCraft] = CraftAttitudeChangeCraft[2][iCraft] / (EachCraftTraceTime[iCraft] * (1.0 - SmoothTimePercent));
			CraftFlightZhuanWanFlag = 1;
		}
		else;
		
		if(CraftFlightZhuanWanFlag)
		{   
			//��ת�ǲ�Ϊ0��ʱ�򣬺�������ʳ�ʼ��
			if( fabs(CraftForwardVelocity) >0.0001 )
		    	CraftAttitudeChangeRate[0][0] = g0 * tan(CraftAttitude[2][0]) / (CraftForwardVelocity);  
			else
				CraftAttitudeChangeRate[0][0] = 0;
		}
		else;
		
		//�켣��ƽ��
	    if(SmoothTimePercent == 0)
	    {
			CraftForwardAcceleration = CraftForwardAccelerationExpect[iCraft];
	        CraftAttitudeChangeRate[0][0] = CraftAttitudeChangeRateExpect[0][iCraft];
	        CraftAttitudeChangeRate[1][0] = CraftAttitudeChangeRateExpect[1][iCraft];
	        CraftAttitudeChangeRate[2][0] = CraftAttitudeChangeRateExpect[2][iCraft]; 
		}
		else
		{
			//�ػ�������ٶ�ƽ���ж� 
			for(int m=0;m<3;m++)
			{ 
				//�ж��Ƿ�Ӧ�ý�����ٶ�ƽ�� 
				if(fabs(CraftAttitudeChangeRateExpect[m][iCraft])>0.0001)  
				{
					if(TzG[m]<=Tg)
					{
						CraftAttitudeChangeRate[m][0]=0.5*CraftAttitudeChangeRateExpect[m][iCraft]*(1.0-cos(Omega*TzG[m]));
						CraftAttitudeChangeRateD[m][0]=0.5*CraftAttitudeChangeRateExpect[m][iCraft]*Omega*sin(Omega*TzG[m]);
					}
					else
					{
						if ((TzG[m]<=Tw) && (TzG[m]>Tg))
						{
							CraftAttitudeChangeRate[m][0]=CraftAttitudeChangeRate[m][0]; 
							CraftAttitudeChangeRateD[m][0]=0;
						}
						else //((TzA<=Tp) && (TzA<=Tg) && (TzA<=Tj)) 
						{ 
							CraftAttitudeChangeRate[m][0]=0.5*CraftAttitudeChangeRateExpect[m][iCraft]*(1.0-cos(Omega*TzG[m]));
							CraftAttitudeChangeRateD[m][0]=0.5*CraftAttitudeChangeRateExpect[m][iCraft]*Omega*sin(Omega*TzG[m]);
						}
					}
					TzG[m]=TzG[m]+CraftTraceStepSize; 									
				}
			}

            //�ػ�ǰ����ٶ�ƽ���������׶�
            //ǰ�������������ٶȵĲ���Ϊƽ������ʼ���ٶ�,��Ϊ���ٶ��Ǹı䵽ĳ��ֵ
            //ֻ������ƽ������Ҫǰ����������ļ��ٶ����
            if(iCraft>1)  
            {
            	DCraftForwardAcceleration=CraftForwardAccelerationExpect[iCraft]-CraftForwardAccelerationExpect[iCraft-1];
            }
            else 
            { 
            	DCraftForwardAcceleration=CraftForwardAccelerationExpect[iCraft];
            }	
	   
            if(iCraft==1)
            {
            	CraftForwardAccelerationOld=0;
            }
            else
            {	
        		if(jCraft == 0)
					//CraftForwardAccelerationΪ��ƽ������ֵ��CraftForwardAcclerationOldΪ�ڴ��仯����ֵ
        			CraftForwardAccelerationOld=CraftForwardAcceleration; 
        		else
        		    CraftForwardAccelerationOld=CraftForwardAccelerationOld; 
            }
			//ֻƽ�����ٶȵ������׶�
			if(fabs(DCraftForwardAcceleration!=0))   			
            {	 
				//�ж��Ƿ�Ӧ�ý�����ٶ�ƽ��
				if(fabs(DCraftForwardAcceleration)>0.0001)		
				{
                    if(TzA<=Tg)
                    {
                          CraftForwardAccelerationD=0.5*DCraftForwardAcceleration*(1-cos(Omega*TzA));
				          CraftForwardAcceleration=CraftForwardAccelerationOld+CraftForwardAccelerationD;
                    }   
		            else
	                {
		                  CraftForwardAcceleration=CraftForwardAcceleration;
	                }
	                TzA=TzA+CraftTraceStepSize; 
                }
            }
            else 
            {
            	CraftForwardAcceleration=CraftForwardAcceleration;
            }
		}//ƽ������
		
		//�����ػ��켣													 				
		CraftTrack(CraftAttitude,CraftAttitudeChangeRate,CraftVelocity,CraftPosition,&CraftForwardVelocity,
			      &CraftForwardAcceleration,CraftTraceStepSize,CraftAcc);  
		
		//����ϵ�켣����ת����84ϵ
		TraceToGNSS(CraftPosition, CraftVelocity, CraftAcc, CraftPositionWGS84, CraftVelocityGNSS, CraftAccGNSS);

		//�����ػ�������������(���������ٶ�)
		CraftImuInput(CraftAttitude,CraftAttitudeChangeRate,CraftVelocity,CraftPosition,
					  CraftSFB,CraftOmegaiBB,CraftAcc);
		//�ػ���������ģ��
		CraftImuOutput(CraftSFB,CraftOmegaiBB,CraftInsSFs,CraftInsOmegaiBBs);
		
		//�ӼƲ���������ģ��
		CalcImuIncPulse(CraftFPulse,CraftFRem,CraftInsSFs,CraftAccelerometerQuantizationFactor,CraftTraceStepSize); 
		
		//���ݲ���������ģ�� 
		CalcImuIncPulse(CraftGPulse,CraftGRem,CraftInsOmegaiBBs,CraftGyroQuantizationFactor_rad,CraftTraceStepSize);
		
		//�Ӽ��������  											 
		CalcImuIncPulseSum(CraftFPulseSum,CraftFPulse);  
		
		//�����������
		CalcImuIncPulseSum(CraftGPulseSum,CraftGPulse);
/***********************************************************************************************/
/*                          //���ػ���̬�õ���ʼת̨������                                          */
/***********************************************************************************************/		
		RotaryControlInputFunc(CraftAttitude, RotaryControlAngle, RotaryControlAngleRate, 
						       CraftTraceStepSize, RotaryControlAngleOld);
		
		//�������ص�����ת�����ʲ���  
	//	GyroBuChang(CraftAttitude, CraftAttitudeChangeRate, CraftOmegaiBB,RotaryControlAngle, RotaryControlAngleRate, 
	//				CraftTraceStepSize,CraftPosition, CraftVelocity, RotaryQuaternion, RotaryControlAngleOld);

		Vec2Vec(RotaryControlAngle, RotaryControlAngleOld); 
/***********************************************************************************************/
/*                            ���ػ��������㵼������                                           */
/***********************************************************************************************/		
		//�ػ�����������������ת������ͬ����λ����������ģ�͡�����˱۴��������ļ��ٶ�ģ�͡�����ע��ģ�� 
        AccelerometerControlInput(CraftOmegaiBB, CraftSFB, MissileSInsSFb, CraftTraceStepSize, WingLever, 
								  CraftAttitude, CraftPosition, CraftVelocity, MissileSFCompensate, OmegapBb1);
/**********************************************************************************************************/		
		//��ʵ�˱�(0.34m)���ٶ�����ģ��(����ע��)
   //   AccelerometerBuChang(CraftTraceStepSize, RotaryControlAngleRate,
   //		                 MissileSFCompensate, RotaryControlAngleRateOld, RotaryControlAngle);
		
		//�켣��ת̨����ϵ�仯
		float CraftAttitude_Rotary_Temp[3][1], CraftAngRate_Rotary_Temp[3][1];  
        TraceToRotary(RotaryControlAngle, RotaryControlAngleRate,  CraftAttitude_Rotary_Temp,  CraftAngRate_Rotary_Temp);

		//ҡ�ڷ�ֵ����0��ʼ
		Time_RotaryShake = TraceTime - Time_ShakeStart;

		//ת̨ҡ�ڿ���
		RotaryTabShake( CraftAttitude_Rotary_Temp, CraftAngRate_Rotary_Temp, CraftAttitude_Rotary, 
						CraftAngRate_Rotary, RotaryAmp, RotaryFre, RotaryPha, Time_RotaryShake );	
		
		//ת̨����ָ�������ֵ����һ����û���յ��ض����ݣ�����ֹͣ
	if( rfmRotaryTrack( CraftAttitude_Rotary , CraftAngRate_Rotary, RotaryAngleGet, RotaryRateGet) )
		{
			StopCMDCallback();
			CraTraceStop_Flag = 1;	
			iCraft = 1;
			jCraft = 0;				
		}	 
	
	    //ת��ת̨�洢�Ƕ�
		TurnTableAngle[0][0] = RotaryAngleGet[0];
		if (TurnTableAngle[0][0] > 180)
			TurnTableAngle[0][0] -= 360;
	
		TurnTableAngle[1][0] = RotaryAngleGet[1];
		if (TurnTableAngle[1][0] > 180)
			TurnTableAngle[1][0] -= 360;
	
		TurnTableAngle[2][0] = RotaryAngleGet[2];
		if (TurnTableAngle[2][0] > 180)
			TurnTableAngle[2][0] -= 360;
			
		jCraft++;
		CraftTraceLoopFlag = 1;
	} //if (jCraft<=SampleNum)����	
	
	//�켣�滮ִ������˳���ʱ��
	if( (iCraft >= CraftFlightStateNum) && (jCraft == SampleNum) )
	{
		StopCMDCallback();
		CraTraceStop_Flag = 1;	
		iCraft = 1;
		jCraft = 0 ;
	}
	
	//ÿ�ι켣����������+1������һ�ι켣
	if(jCraft == SampleNum)
	{
		jCraft = 0;
		iCraft++;
		CraftTraceLoopFlag = 0;
	}		 
} 

//�̿����ݹ켣��������
void DataTraceGenerate()
{
    if(RDModeCounter >= SensorAddrCounter/7)
	{	
		StopCMDCallback();		   
        CraTraceStop_Flag=1; 
	}
	else
	{
		CraftSensorAR[1][0] = *(SensorDataAddr + 7*RDModeCounter + 1) * DEGREE;   //ǰ����->��ǰ��
		CraftSensorAR[2][0] = *(SensorDataAddr + 7*RDModeCounter + 2) * DEGREE;   
		CraftSensorAR[0][0] = *(SensorDataAddr + 7*RDModeCounter + 3) * DEGREE;  
	
		CraftSensorSF[1][0] = *(SensorDataAddr + 7*RDModeCounter + 4);
		CraftSensorSF[2][0] = *(SensorDataAddr + 7*RDModeCounter + 5);
		CraftSensorSF[0][0] = *(SensorDataAddr + 7*RDModeCounter + 6);			

		Vec2Vec(CraftAttitude, CraftAttitude_Old);  //����
		
		Vec2Vec(CraftVelocity, CraftVelocity_Old); 
		
		SinsNav_2_Trace(CraftSensorAR, CraftSensorSF, CraftTraceQtnS, CraftVelocity, CraftInsCep, 
					   &CraftInsAltitude, CraftTraceStepSize, CraftPosition, CraftAttitude);
		
		CraftAttitudeChangeRate[0][0] = (CraftAttitude[0][0] - CraftAttitude_Old[0][0])/CraftTraceStepSize;
		CraftAttitudeChangeRate[1][0] = (CraftAttitude[1][0] - CraftAttitude_Old[1][0])/CraftTraceStepSize; 
		CraftAttitudeChangeRate[2][0] = (CraftAttitude[2][0] - CraftAttitude_Old[2][0])/CraftTraceStepSize;
			
		//΢�� �������ٶ�
		CraftAcc[0][0] = (CraftVelocity[0][0] - CraftVelocity_Old[0][0])/CraftTraceStepSize;
		CraftAcc[1][0] = (CraftVelocity[1][0] - CraftVelocity_Old[1][0])/CraftTraceStepSize; 
		CraftAcc[2][0] = (CraftVelocity[2][0] - CraftVelocity_Old[2][0])/CraftTraceStepSize;
		
		TraceTime = CraftTraceStepSize + TraceTime;

		//����ϵ�켣����ת����84ϵ
		TraceToGNSS(CraftPosition, CraftVelocity, CraftAcc, CraftPositionWGS84, CraftVelocityGNSS, CraftAccGNSS);

		//�����ػ�������������(���������ٶ�)
		CraftImuInput(CraftAttitude,CraftAttitudeChangeRate,CraftVelocity,CraftPosition, CraftSFB,CraftOmegaiBB,CraftAcc);
		
		//�ػ���������ģ��
    	CraftImuOutput(CraftSFB,CraftOmegaiBB,CraftInsSFs,CraftInsOmegaiBBs);
		
		//�ӼƲ���������ģ��
		CalcImuIncPulse(CraftFPulse,CraftFRem,CraftInsSFs,CraftAccelerometerQuantizationFactor,CraftTraceStepSize); 
		
		//���ݲ���������ģ�� 
		CalcImuIncPulse(CraftGPulse,CraftGRem,CraftInsOmegaiBBs,CraftGyroQuantizationFactor_rad,CraftTraceStepSize);
		
		//�Ӽ��������  											 
		CalcImuIncPulseSum(CraftFPulseSum,CraftFPulse);  
		
		//�����������
		CalcImuIncPulseSum(CraftGPulseSum,CraftGPulse);
		
		//���ػ���̬�õ���ʼת̨������
        RotaryControlInputFunc(CraftAttitude, RotaryControlAngle, RotaryControlAngleRate, CraftTraceStepSize, RotaryControlAngleOld);
		
		//�������ص�����ת�����ʲ��� 
		GyroBuChang(CraftAttitude, CraftAttitudeChangeRate, CraftOmegaiBB,RotaryControlAngle, RotaryControlAngleRate, 
					CraftTraceStepSize,CraftPosition, CraftVelocity, RotaryQuaternion, RotaryControlAngleOld);

		Vec2Vec(RotaryControlAngle, RotaryControlAngleOld); 

		//��ͬ����λ����������ģ�͡�����˱۴��������ļ��ٶ�ģ��(����ע��) 
        AccelerometerControlInput(CraftOmegaiBB, CraftSFB, MissileSInsSFb, CraftTraceStepSize, WingLever, 
								  CraftAttitude, CraftPosition, CraftVelocity, MissileSFCompensate, OmegapBb1);
		
		//��ʵ�˱�(0.34m)���ٶ�����ģ��(����ע��)
        AccelerometerBuChang(CraftTraceStepSize, RotaryControlAngleRate, 
							 MissileSFCompensate, RotaryControlAngleRateOld, RotaryControlAngle);
		
		//�켣��ת̨����ϵ�仯
		float CraftAttitude_Rotary_Temp[3][1], CraftAngRate_Rotary_Temp[3][1];  
        TraceToRotary(RotaryControlAngle, RotaryControlAngleRate,  CraftAttitude_Rotary_Temp,  CraftAngRate_Rotary_Temp);

		//ҡ�����Һ�����ֵ����0��ʼ
		Time_RotaryShake = TraceTime - Time_ShakeStart;

		//ת̨ҡ�ڿ���
		RotaryTabShake( CraftAttitude_Rotary_Temp, CraftAngRate_Rotary_Temp, CraftAttitude_Rotary, 
						CraftAngRate_Rotary, RotaryAmp, RotaryFre, RotaryPha, Time_RotaryShake );	
		
/*		CraftAttitude_Rotary[0] = 45.8014;
	    CraftAttitude_Rotary[1] = 358.9420;
		CraftAttitude_Rotary[2] = 147.1933;  
		
		CraftAngRate_Rotary[0] = 0;
		CraftAngRate_Rotary[1] = 0;  
		CraftAngRate_Rotary[2] = 0;
*/		
		//ת̨����ָ�������ֵ����һ����û���յ��ض����ݣ�����ֹͣ
	 	if( rfmRotaryTrack( CraftAttitude_Rotary , CraftAngRate_Rotary, RotaryAngleGet, RotaryRateGet) )
		{
			CraTraceStop_Flag = 1;	
			StopCMDCallback();
		}	
		
	    //ת��ת̨�洢�Ƕ�
		TurnTableAngle[0][0] = RotaryAngleGet[0];
		if (TurnTableAngle[0][0] > 180)
			TurnTableAngle[0][0] -= 360;
	
		TurnTableAngle[1][0] = RotaryAngleGet[1];
		if (TurnTableAngle[1][0] > 180)
			TurnTableAngle[1][0] -= 360;
	
		TurnTableAngle[2][0] = RotaryAngleGet[2];
		if (TurnTableAngle[2][0] > 180)
			TurnTableAngle[2][0] -= 360;
													    
//		TurnTableAngle[0][0] = - TurnTableAngle[0][0];   //�洢ת̨�ض��Ƕ�����ʱ��ת̨���ȡ����
		
		
	} 
	RDModeCounter++;					    
}

//���ߵ��������
void CraftNav()
{	
	//CraftFPulseOut��Ϊ���ߵ���������������������ߵ��ĵ�������													
	AssignAndResetImuIncPulse(CraftFPulseSum,CraftFPulseOut); 
	AssignAndResetImuIncPulse(CraftGPulseSum,CraftGPulseOut);

	Vec2Vec(CraftOmegapBB, CraftOmegapBBOld);  	
	
	//�������ߵ�����
	SinsNavPulse(CraftFPulseOut, CraftGPulseOut, CraftInsQtnS, CraftInsVelocityP, CraftInsCep, &CraftInsAltitude,
				 CraftNavigationStepSize, CraftInsOmegaipp, CraftInsPosition, CraftInsAttitude,
				 CraftFInc, &CraftSNavGravity, CraftOmegapBB); 
		
	//���ߵ���������
	VecDivSca(CraftAttitude,DEGREE,CraftAttitudeCha);
	VecDivSca(CraftInsAttitude,DEGREE,CraftInsAttitudeCha);
	VecSubVec(CraftAttitudeCha,CraftInsAttitudeCha,AttCha);
	VecSubVec(CraftVelocity,CraftInsVelocityP,CraftVelocityCha);
	VecSubVec(CraftPosition,CraftInsPosition,CraftPositionCha);	
}

//����������ɼ������
void FcsNav()
{
	if (IniFcsFlag == 0)//�����һ�ν�������г�ʼ��
	{
		InitialFcsPulse(CraftInsAttitude,&CraftSNavGravity, &CraftInsAltitude, CraftInsVelocityP, 
						FcsVel, FcsPos, FcsCbB, Gn, FcsQtn, CraftInsQtnSFcs, MisAlignN, FcsNavigationStepSize);

		FcsLongitude = CraftInsPosition[0][0] / DEGREE;
		FcsLatitude = CraftInsPosition[1][0] / DEGREE;
		FcsAltitude = CraftInsPosition[2][0];	
	}
		//FcsAttitude ��̬��˳�򣺹�ת-����-����
		FcsNavSPulse(CraftFPulseOut, CraftGPulseOut, CraftInsOmegaipp, CraftInsAttitude, &CraftSNavGravity,
					 FcsGravity, CraftInsQtnSFcs, FcsQtn, FcsAttitude, FcsVel, FcsPos, &CraftInsAltitude,
					 FcsH0, FcsNavigationStepSize, FcsCbB);	
}

//**************************�����켣��������*************************// 

void StartMisTrace(void)   
{   
//	printf("GNSS Simulator Iniitial Start !\n");

//	GNSS_GE_Initial(MisIniPos_WGS84, MisIniVel_WGS84, MisIniAcc_WGS84);	            //GNSSģ�����ⷴ��ͨѶ��ʼ��
                                              
//  printf("GNSS Simulator Iniitial Done !\n");

//	printf("Missile Trace Generate Start !\n");
	//��س�ʼ����־
	
	
	
	
	data.status = TRACE_START;
	Update();	
	
	FC_Init_Flag = 0;
	
	printf("Generating ... ...\n\n"); 
	
	TimerCounter = 0;
	
	MisTraceIniDone_Flag=1;	//�൱�ڰ�ť
}

void StopMisTrace(void)
{
	int status;
	int iTemp;
	DiscardAsyncTimer (-1);    //ֹͣ��ʱ�� 
 
	/*
	rfmRotaryTrack(CraftAttitude_Rotary , CraftAngRate_Rotary, RotaryAngleGet, RotaryRateGet);
	
	printf("Trace finished and rotary table start resetting.\n.");
	
	//����ʱ�ٸ�λ��ʵ�鿪ʼλ��     
	Initial_RotaryTab(Rotary_Ini_In, Rotary_Ini_Mid, Rotary_Ini_Out);    
	
	printf("Rotary reset finished.\n"); 
	 */
	
		//�������ź�ģ�������ͽ����ź�
    SendStopCMDToGNSS();
	
	data.status = DATA_DISPLAY;
	data.TraceStatus = TRACE_FINISHED_M_PRO; 	
	Update();		
	
	data.status = TRACE_FINISHED;
	Update();

	if(cmd.DataSaveFlag == 1)
	{
		data.status = TRACE_SAVING; 
		Update();   
		MissileDataWriteToFile();  
		data.status = DATA_SAVE_FINISHED;
		Update();
	}
	printf("Missile Trace Generate Finished !\n");

	printf("TimerCounter = %d\n",TimerCounter ) ;  

	fclose(TestFileHandle);
}

int CVICALLBACK MisTraceTimer(int reserved, int timerId, int event, void *callbackData,  
	                          int eventData1, int eventData2)
{  
	CmtGetLock (gLock);  
		
	if (event == EVENT_TIMER_TICK)	  
	{
			    //�㷨ʱ�������־   ������ͬһ�ļ����
	//			Start_Time_Flag=GetTimeUS();
	//			fprintf(MisTraceGNSSFileHandle,"Start_Time_Flag = %d     ",Start_Time_Flag);		
		if(MisTraceStop_Flag!=1)
		{		
			MisTraceGenerate();
			if(MisTraceStop_Flag!=1)
			{				
	//			Inner_Time_Flag=GetTimeUS();                                                 
	//			fprintf(MisTraceGNSSFileHandle,"Inner_Time_Flag = %d     ",Inner_Time_Flag);
	
				if(TimerCounter %10 == 0)
				{
				 	GNSS_GE_Write(MisPositionWGS84, MisVelocityWGS84, MisAccWGS84); 
				}
				
				//�����ģ����λ���ٶȼ��ٶ�ΪWGS84ϵ��
			//	GNSS_GE_Write(MisPositionWGS84, MisVelocityWGS84, MisAccWGS84);
 
				//Ϊ��ʼ�����ڴ�ռ�����һ����ʼ����SimDataIniLength  				
				if(MemoryReallocFlag == 1)
				{
		            SimulationDataSaveAddr = (double *) realloc (SimulationDataSaveAddr,  
			                    sizeof(double)*SimDataIniLength*(SimDataAddrOffset/SimDataIniLength+2));
					MemoryReallocFlag = 0;
				}
				//��س�ʼ��
				if(FC_Init_Flag == 0)
				{
					//��ؼ��������ʼ��
				    InitialFcsPulse( MisAttitude_Rad, &MisGravity, &MisAltitude, MisVelocity, 
									 FcsVel, FcsPos, FcsCbB, Gn, FcsQtn, CraftInsQtnSFcs,  //
									 MisAlignN, MisStepTimeSec);   //��ص�������δ�õ�FcsNavigationStepSize
					FC_Init_Flag = 1;
				}
				//��ص�������
	/*		    FcsNavS(MissileSF, MissileAngleRate, MisOmegaipp, MisAttitude_Rad, &MisGravity,
					    FcsGravity, CraftInsQtnSFcs, FcsQtn, FcsAttitude, FcsVel, FcsPos, &MisAltitude,
					 FcsH0, MisStepTimeSec, FcsCbB);
	*/	
				//�켣��������ֱ�Ӵ����ڴ�
				MissileDataWriteToMemory(); 		
				
				//ʵʱ��ʾ���ݻش�
			    if(TimerCounter % 100 == 0)
				{
					data.status = DATA_DISPLAY;
					switch (MissileMode)
					{
						case MISFREE_MODE:
							 data.TraceStatus = TRACE_GENERATING_M_FREE;
							 break;
					    case MISGUI_MODE:
							 data.TraceStatus = TRACE_GENERATING_M_GUI;
							 break;
						case DATARD_MODE:
							 data.TraceStatus = TRACE_GENERATING_M_PRO;
							 break;
					}
					data.TraceTime = TraceTime;
					data.TraceLon = MisPosition[0][0];
					data.TraceLat = MisPosition[1][0]; 
					data.TraceAlt = MisPosition[2][0]; 
					data.VelocityE = MisVelocity[0][0]; 
					data.VelocityN = MisVelocity[1][0]; 
					data.VelocityU = MisVelocity[2][0]; 
					data.TraceYaw =   MisAttitude[0][0];
					data.TracePitch = MisAttitude[1][0];
					data.TraceRoll =  MisAttitude[2][0];
					data.RotaryOut = MisAttitude_Rotary[2];
					data.RotaryMid = MisAttitude_Rotary[1];
					data.RotaryIn =  MisAttitude_Rotary[0];
				
					data.FC_PosX = FcsPos[0][0];
					data.FC_PosY = FcsPos[1][0]; 
					data.FC_PosZ = FcsPos[2][0]; 
					data.FC_VelX = FcsVel[0][0];
					data.FC_VelY = FcsVel[1][0];
					data.FC_VelZ = FcsVel[2][0];
					data.FC_Qua0 = FcsQtn[0][0];
					data.FC_Qua1 = FcsQtn[1][0]; 
					data.FC_Qua2 = FcsQtn[2][0]; 
					data.FC_Qua3 = FcsQtn[3][0]; 					
								
					Update();
				}		
				//�����ת̨����̬����̬�仯��Ϊ����ϵ�������½Ƕ� 
	//		 	rfmRotaryTrack( MisAttitude_Rotary , MisAngRate_Rotary, RotaryAngleGet, RotaryRateGet); 

	//			Stop_Time_Flag=GetTimeUS();
	//			fprintf(MisTraceGNSSFileHandle,"Stop_Time_Flag = %d \n",Stop_Time_Flag);
			}
		}
	}
	CmtReleaseLock (gLock);   
	TimerCounter = TimerCounter+1;	 
	TraceTime = MisStepTimeSec+TraceTime;    
	return 0; 
}

void MisTraceGenerate(void)
{	
	//����ģʽ�жϱ�־
	if(MissileMode == MISFREE_MODE)
	{
		if(MisiCounter > MisFlightStateNum)
		{
            MisTraceStop_Flag=1; 
			SuspendAsyncTimerCallbacks ();
			StopCMDCallback();
		}
		else
		{
			MisSampleNum=(MissileChangeEndTime[MisiCounter]-MissileChangeStartTime[MisiCounter])/MisStepTimeSec; 
			if(MisjCounter==MisSampleNum+2)
			{   
				//ÿ�ν������ٶ�ƽ������
				if(MisSmooth_StartFlag == 0)
				{
					MisSF_SmoothStart[0][0] = MissileSF[0][0];
					MisSF_SmoothStart[1][0] = MissileSF[1][0];
					MisSF_SmoothStart[2][0] = MissileSF[2][0];
					
					MisAngRate_SmoothStart[0][0] = MisAngRate_Rad[0][0];
					MisAngRate_SmoothStart[1][0] = MisAngRate_Rad[1][0];
					MisAngRate_SmoothStart[2][0] = MisAngRate_Rad[2][0];
					MisSmooth_StartFlag = 1;
				}
				
				if(MisSmooth(MisSF_SmoothStart, MisAngRate_SmoothStart, 
				             MissileSF, MisAngRate_Rad, MisSmoothTime, MisStepTimeSec) == 1) 
				{
					MisiCounter=MisiCounter+1;
					MisjCounter=0;
					MisSmooth_StartFlag = 0;
				}
			}
			else
			{
				//��j�������㴦���ٶ� 
				MissileSF[0][0]=MisSFAmplitudeX[MisiCounter]*sin(2*pi*MisSFFrequencyX[MisiCounter]*
					         (MisStepTimeSec*MisjCounter)+MisSFPhaseX_Rad[MisiCounter]); 
				MissileSF[1][0]=MisSFAmplitudeY[MisiCounter]*sin(2*pi*MisSFFrequencyY[MisiCounter]*
					         (MisStepTimeSec*MisjCounter)+MisSFPhaseY_Rad[MisiCounter]);    
				MissileSF[2][0]=MisSFAmplitudeZ[MisiCounter]*sin(2*pi*MisSFFrequencyZ[MisiCounter]*
					         (MisStepTimeSec*MisjCounter)+MisSFPhaseZ_Rad[MisiCounter]);  
				//��j�������㴦���ӽ��ٶ� 				  
				MissileAngleRate[0][0]=MisAngRateAmplitudeX_Rad[MisiCounter]*sin(2*pi*MisAngRateFrequencyX[MisiCounter]*
				                	(MisStepTimeSec*MisjCounter)+MisAngRatePhaseX_Rad[MisiCounter]);
				MissileAngleRate[1][0]=MisAngRateAmplitudeY_Rad[MisiCounter]*sin(2*pi*MisAngRateFrequencyY[MisiCounter]*
				                	(MisStepTimeSec*MisjCounter)+MisAngRatePhaseY_Rad[MisiCounter]); 
				MissileAngleRate[2][0]=MisAngRateAmplitudeZ_Rad[MisiCounter]*sin(2*pi*MisAngRateFrequencyZ[MisiCounter]*
			                   		(MisStepTimeSec*MisjCounter)+MisAngRatePhaseZ_Rad[MisiCounter]);
			    MisjCounter++; 				
			}
			
			Vec2Vec(MisAttitude_Rad, MisAttitude_Rad_Old);
			
			Vec2Vec(MisVelocity, MisVelocity_Old);
			
			//SinsNav(MissileAngleRate, MissileSF, MisQuaternion, MisVelocity, MisCep, 
	   		//	   &MisAltitude, MisStepTimeSec, MisOmegaipp, MisPosition_Rad, MisAttitude_Rad, &MisGravity);
	
			MisAngRate_Rad[0][0] = (MisAttitude_Rad_Old[0][0] - MisAttitude_Rad[0][0])/MisStepTimeSec;
			MisAngRate_Rad[1][0] = (MisAttitude_Rad_Old[1][0] - MisAttitude_Rad[1][0])/MisStepTimeSec; 
			MisAngRate_Rad[2][0] = (MisAttitude_Rad_Old[2][0] - MisAttitude_Rad[2][0])/MisStepTimeSec; 	
			
			MisAttitude[0][0] = MisAttitude_Rad[0][0]*180/pi;
			MisAttitude[1][0] = MisAttitude_Rad[1][0]*180/pi; 
			MisAttitude[2][0] = MisAttitude_Rad[2][0]*180/pi; 
			
			MisAngRate[0][0] = MisAngRate_Rad[0][0]*180/pi;
			MisAngRate[1][0] = MisAngRate_Rad[1][0]*180/pi; 
			MisAngRate[2][0] = MisAngRate_Rad[2][0]*180/pi; 
			
			MisPosition[0][0] = MisPosition_Rad[0][0]*180/pi; 
			MisPosition[1][0] = MisPosition_Rad[1][0]*180/pi; 			
			MisPosition[2][0] = MisPosition_Rad[2][0]; 				
			
			MisAcc[0][0] = (MisVelocity_Old[0][0] - MisVelocity[0][0])/MisStepTimeSec;
			MisAcc[1][0] = (MisVelocity_Old[1][0] - MisVelocity[1][0])/MisStepTimeSec; 
			MisAcc[2][0] = (MisVelocity_Old[2][0] - MisVelocity[2][0])/MisStepTimeSec; 
			
			Cig[0][0]= cos(pi/2+MisPosition_Rad[0][0]);
			Cig[0][1]=-sin(pi/2+MisPosition_Rad[0][0])*cos(pi/2-MisPosition_Rad[0][1]);
			Cig[0][2]= sin(pi/2+MisPosition_Rad[0][0])*sin(pi/2-MisPosition_Rad[0][1]);
			Cig[1][0]= sin(pi/2+MisPosition_Rad[0][0]);
			Cig[1][1]= cos(pi/2+MisPosition_Rad[0][0])*cos(pi/2-MisPosition_Rad[0][1]);
			Cig[1][2]=-cos(pi/2+MisPosition_Rad[0][0])*sin(pi/2-MisPosition_Rad[0][1]);
			Cig[2][0]= 0;
			Cig[2][1]= sin(pi/2-MisPosition_Rad[0][1]);
			Cig[2][2]= cos(pi/2-MisPosition_Rad[0][1]);

			MisPositionWGS84[0][0]=(CalRn(MisPosition_Rad[1][0])+MisPosition[2][0])
				                  *(cos(MisPosition_Rad[1][0]))
								  *(cos(MisPosition_Rad[0][0]));
		    MisPositionWGS84[1][0]=(CalRn(MisPosition_Rad[1][0])+MisPosition[2][0])
				                  *(cos(MisPosition_Rad[1][0]))
								  *(sin(MisPosition_Rad[0][0]));
		    MisPositionWGS84[2][0]=(CalRn(MisPosition_Rad[1][0])*(1-e2)+MisPosition[2][0])
				                  *sin(MisPosition_Rad[1][0]);				
			
			MatMulVec(Cig, MisVelocity, MisVelocityWGS84);
			
			MatMulVec(Cig, MisAcc, MisAccWGS84); 
			
			MisAttitude_Rotary[0] = (float)MisAttitude[2][0];
			MisAttitude_Rotary[1] = (float)MisAttitude[1][0]; 
			MisAttitude_Rotary[2] = (float)MisAttitude[0][0]; 
		
			MisAngRate_Rotary[0] = (float)MisAngRate[2][0];
			MisAngRate_Rotary[1] = (float)MisAngRate[1][0];	
			MisAngRate_Rotary[2] = (float)MisAngRate[0][0];	
			
	/*		fprintf(MisTraceGNSSFileHandle,"   %f ", MisAttitude_Rotary[0]); 	//ת̨���ٹ켣����ָ��
			fprintf(MisTraceGNSSFileHandle,"   %f ", MisAttitude_Rotary[1]); 
			fprintf(MisTraceGNSSFileHandle,"   %f ", MisAttitude_Rotary[2]); 
		
			fprintf(MisTraceGNSSFileHandle,"   %f ", MisAngRate_Rotary[0]); 
			fprintf(MisTraceGNSSFileHandle,"   %f ", MisAngRate_Rotary[1]); 
			fprintf(MisTraceGNSSFileHandle,"   %f ", MisAngRate_Rotary[2]);
			
			fprintf(MisTraceGNSSFileHandle,"/n");  
	*/	

		
	/*		fprintf(MisTraceGNSSFileHandle,"   %lf ", MisPosition[0][0]); 
			fprintf(MisTraceGNSSFileHandle,"   %lf ", MisPosition[1][0]); 
			fprintf(MisTraceGNSSFileHandle,"   %lf ", MisPosition[2][0]);
			
			fprintf(MisTraceGNSSFileHandle,"   %lf ", MisVelocity[0][0]); 
			fprintf(MisTraceGNSSFileHandle,"   %lf ", MisVelocity[1][0]); 
			fprintf(MisTraceGNSSFileHandle,"   %lf ", MisVelocity[2][0]); 	 
			
			fprintf(MisTraceGNSSFileHandle,"   %lf ", MisSF[0][0]); 
			fprintf(MisTraceGNSSFileHandle,"   %lf ", MisSF[1][0]); 
			fprintf(MisTraceGNSSFileHandle,"   %lf ", MisSF[2][0]);
			
			fprintf(MisTraceGNSSFileHandle,"   %lf ", MisAngRate_Rad[0][0]); 
			fprintf(MisTraceGNSSFileHandle,"   %lf ", MisAngRate_Rad[1][0]); 
			fprintf(MisTraceGNSSFileHandle,"   %lf ", MisAngRate_Rad[2][0]);
			fprintf(MisTraceGNSSFileHandle,"\r\n"); */
		}
	}					 
	if(MissileMode == MISGUI_MODE)	  	
	{	
        if(TraceTime > 30.0)                //����300S                           ����Ŀ��δ����
		{																  
			MisTraceStop_Flag = 1;
			SuspendAsyncTimerCallbacks ();
			StopCMDCallback();	
			printf("Over Time ! \n"); 			
			data.status = MISGUI_TIMEOUT;
			Update();
		}
		else
		{										
			if(Tarflightstatenum == 0)	              //Ŀ����켣����Ϊ�㣨Ŀ�꾲ֹ��
			{
//				data.status = MISGUI_STATIC_TARGET;
//		        Update();
			}							              
			else									  //Ŀ����켣������Ϊ��
			{
				if(TariCounter == 0) 					  
				{
					TariCounter = 1;		    	  //�켣������������1��ʼ
				}  
			
				TarSampleNum=(TargetChangeEndTime[TariCounter]-TargetChangeStartTime[TariCounter])/MisStepTimeSec;
	            if(TariCounter > Tarflightstatenum)   //�켣������                        ����Ŀ��δ����
				{
					MisTraceStop_Flag=1;
			    	SuspendAsyncTimerCallbacks ();
					StopCMDCallback();	
					printf("Target trace finished ! \n"); 
					data.status = MISGUI_TRACE_FINISHED;
				    Update();											
				}	
				if(TarjCounter == TarSampleNum)
				{
				    TariCounter=TariCounter+1;
				    TarjCounter=0;					
				}
			}
			//Ŀ������ٶ�
			TarAcc[0][0]=TargetAccAmplitudeX[TariCounter]*sin(2*pi*TargetAccFrequencyX[TariCounter]*
			             (MisStepTimeSec*TarjCounter)+TargetAccPhaseX[TariCounter]);  
			TarAcc[1][0]=TargetAccAmplitudeY[TariCounter]*sin(2*pi*TargetAccFrequencyY[TariCounter]*
			             (MisStepTimeSec*TarjCounter)+TargetAccPhaseY[TariCounter]);  
			TarAcc[2][0]=TargetAccAmplitudeZ[TariCounter]*sin(2*pi*TargetAccFrequencyZ[TariCounter]*
			             (MisStepTimeSec*TarjCounter)+TargetAccPhaseZ[TariCounter]);	
			//Ŀ���λ���ٶȸ���
			TargetTrack(TarAcc, TarVelocity, TarPosition, MisStepTimeSec);
		
			TarPosition_Rad[0][0] = TarPosition[0][0]*pi/180;
			TarPosition_Rad[1][0] = TarPosition[1][0]*pi/180;
			TarPosition_Rad[2][0] = TarPosition[2][0]; 

			//����λ����Ŀ��λ�þ�ת��84ϵ����ʸ����
			TarPositionWGS84[0][0]=(CalRn(TarPosition_Rad[1][0])+TarPosition_Rad[2][0])
				                  *(cos(TarPosition_Rad[1][0]))
								  *(cos(TarPosition_Rad[0][0]));
		    TarPositionWGS84[1][0]=(CalRn(TarPosition_Rad[1][0])+TarPosition_Rad[2][0])
				                  *(cos(TarPosition_Rad[1][0]))
								  *(sin(TarPosition_Rad[0][0]));
		    TarPositionWGS84[2][0]=(CalRn(TarPosition_Rad[1][0])*(1-e2)+TarPosition_Rad[2][0])
				                   *sin(TarPosition_Rad[1][0]);			

			//��Ŀ������춫���������춫����ϵת�ƾ������
			Ctm[0][0] =  cos(MisPosition_Rad[1][0])*cos(TarPosition_Rad[1][0])+
				         sin(MisPosition_Rad[1][0])*sin(TarPosition_Rad[1][0])*
					 	 cos(MisPosition_Rad[0][0]-TarPosition_Rad[0][0]);
		
			Ctm[0][1] =  cos(MisPosition_Rad[1][0])*sin(TarPosition_Rad[1][0])-
				         sin(MisPosition_Rad[1][0])*cos(TarPosition_Rad[1][0])*
						 cos(MisPosition_Rad[0][0]-TarPosition_Rad[0][0]); 
		
			Ctm[0][2] = -sin(MisPosition_Rad[1][0])*sin(MisPosition_Rad[0][0]-TarPosition_Rad[0][0]);
		
			Ctm[1][0] =  sin(MisPosition_Rad[1][0])*cos(TarPosition_Rad[1][0])-
				         cos(MisPosition_Rad[1][0])*sin(TarPosition_Rad[1][0])*
						 cos(MisPosition_Rad[0][0]-TarPosition_Rad[0][0]); 
		
			Ctm[1][1] =  sin(MisPosition_Rad[1][0])*sin(TarPosition_Rad[1][0])+
				         cos(MisPosition_Rad[1][0])*cos(TarPosition_Rad[1][0])*
						 cos(MisPosition_Rad[0][0]-TarPosition_Rad[0][0]);
		
			Ctm[1][2] =  cos(MisPosition_Rad[1][0])*sin(MisPosition_Rad[0][0]-TarPosition_Rad[0][0]); 
		
			Ctm[2][0] =  sin(TarPosition_Rad[1][0])*sin(MisPosition_Rad[0][0]-TarPosition_Rad[0][0]); 
		
			Ctm[2][1] = -cos(TarPosition_Rad[1][0])*sin(MisPosition_Rad[0][0]-TarPosition_Rad[0][0]);
		
			Ctm[2][2] =  cos(MisPosition_Rad[0][0]-TarPosition_Rad[0][0]);
			
			//Ŀ����ٶ�ת������������ϵ(���춫)
			MatMulVec(Ctm, TarVelocity, TarVelocity_M);
		
			Cig[0][0] = -cos(MisPosition_Rad[0][0])*sin(MisPosition_Rad[1][0]);
			Cig[0][1] =  cos(MisPosition_Rad[0][0])*cos(MisPosition_Rad[1][0]);
			Cig[0][2] = -sin(MisPosition_Rad[0][0]);
			Cig[1][0] = -sin(MisPosition_Rad[0][0])*sin(MisPosition_Rad[1][0]);
			Cig[1][1] =  sin(MisPosition_Rad[0][0])*cos(MisPosition_Rad[1][0]);
			Cig[1][2] =  cos(MisPosition_Rad[0][0]);
			Cig[2][0] =  cos(MisPosition_Rad[1][0]);
			Cig[2][1] =  sin(MisPosition_Rad[1][0]); 
			Cig[2][2] =  0;

			MatTMat(Cig, Cgi);
		   
			TempVec[0][0] = MisVelocity[0][0];
			TempVec[1][0] = MisVelocity[1][0]; 
			TempVec[2][0] = MisVelocity[2][0]; 
		
			MisVelocity_NUE[0][0] = TempVec[1][0];
			MisVelocity_NUE[1][0] = TempVec[2][0];
			MisVelocity_NUE[2][0] = TempVec[0][0];
		
			GuideCommandCopy(MisPositionWGS84, MisVelocity_NUE, TarPositionWGS84, 
							 TarVelocity_M, CommandAcc, &CloVel);			
		
			if(CloVel <= 0.01)   //�ӽ��ٶȵļ��Ա仯�жϻ���Ŀ��     ����Ŀ�����
			{  		    
				SuspendAsyncTimerCallbacks(); 
				MisTraceStop_Flag=1;

				printf("Hit Target ! \n");
				data.status = MISGUI_HIT;
			    Update();

				StopCMDCallback();	
			}

//			SeekerInputModel(MisPositionWGS84, MisVelocity_NUE, 
//	                         TarPositionWGS84, TarVelocity_M, OmegaLOS, CloVel);
//									  
//			GuideCommand(MisVelocity_NUE, OmegaLOS, CommandAcc);
		
			//�������ȶ�����µĺ�����ٶ�
			MisAngRate_Rad[0][0] = MisAngRate[0][0]*pi/180;
			MisAngRate_Rad[1][0] = MisAngRate[1][0]*pi/180;  
			MisAngRate_Rad[2][0] = MisAngRate[2][0]*pi/180; 
		
			//ת��������ϵ
			TempVec[0][0] = CommandAcc[0][0];
			TempVec[1][0] = CommandAcc[1][0];
			TempVec[2][0] = CommandAcc[2][0];
		
			CommandAcc[0][0] = TempVec[2][0];
			CommandAcc[1][0] = TempVec[0][0];
			CommandAcc[2][0] = TempVec[1][0];
			
			Vec2Vec(CommandAcc, MisAcc);
		
			Vec2Vec(MisAttitude_Rad, MisAttitude_Rad_Old); 
		
			//������������ϵ�������󣬵����ػ��ߵ��������ģ��
			//���Ϊ�����ĵ���ϵ���������ٶ�
			MissileImuInput(MisAttitude_Rad, MisVelocity, MisPosition_Rad,
						    MissileSF, MissileAngleRate, MisAcc);	

			//�����ػ����ߵ�������ʹ��ģ�Ͳ����Ĺ�������������������켣				
			//SinsNav(MissileAngleRate, MissileSF, MisQuaternion, MisVelocity, MisCep, 
			//	   &MisAltitude, MisStepTimeSec, MisOmegaipp, MisPosition_Rad, MisAttitude_Rad, &MisGravity);				
			//��̬�仯�ʸ���
			MisAngRate_Rad[0][0] = (MisAttitude_Rad[0][0] - MisAttitude_Rad_Old[0][0])/MisStepTimeSec;  				
	 		MisAngRate_Rad[1][0] = (MisAttitude_Rad[1][0] - MisAttitude_Rad_Old[1][0])/MisStepTimeSec;  				
			MisAngRate_Rad[2][0] = (MisAttitude_Rad[2][0] - MisAttitude_Rad_Old[2][0])/MisStepTimeSec; 
			//��̬����̬�����ʡ�λ��ת���Ƕ���
			MisAttitude[0][0] = MisAttitude_Rad[0][0]*180/pi;
			MisAttitude[1][0] = MisAttitude_Rad[1][0]*180/pi; 
			MisAttitude[2][0] = MisAttitude_Rad[2][0]*180/pi; 
	
			MisAngRate[0][0] = MisAngRate_Rad[0][0]*180/pi;
			MisAngRate[1][0] = MisAngRate_Rad[1][0]*180/pi; 
			MisAngRate[2][0] = MisAngRate_Rad[2][0]*180/pi; 
	
			MisPosition[0][0] = MisPosition_Rad[0][0]*180/pi; 
			MisPosition[1][0] = MisPosition_Rad[1][0]*180/pi; 			
			MisPosition[2][0] = MisPosition_Rad[2][0]; 			
			//ģ�����������    		
			MisPositionWGS84[0][0]=(CalRn(MisPosition_Rad[1][0])+MisPosition_Rad[2][0])
				                  *(cos(MisPosition_Rad[1][0]))
								  *(cos(MisPosition_Rad[0][0]));
		    MisPositionWGS84[1][0]=(CalRn(MisPosition_Rad[1][0])+MisPosition_Rad[2][0])
				                  *(cos(MisPosition_Rad[1][0]))
								  *(sin(MisPosition_Rad[0][0]));
		    MisPositionWGS84[2][0]=(CalRn(MisPosition_Rad[1][0])*(1-e2)+MisPosition_Rad[2][0])
				                  *sin(MisPosition_Rad[1][0]);
			//ת����������ϵ���ڹ۲��Ƶ��켣
			MisPositionTemp[0][0] = MisPositionWGS84[0][0] - MisIniPos_WGS84[0][0];
			MisPositionTemp[1][0] = MisPositionWGS84[1][0] - MisIniPos_WGS84[1][0];
			MisPositionTemp[2][0] = MisPositionWGS84[2][0] - MisIniPos_WGS84[2][0];
			
			MatMulVec(Cen, MisPositionTemp, MisPosition_L);
	
    		//������ϵ��84ϵת�ƾ���
			Cig[0][0]= cos(pi/2+MisPosition_Rad[0][0]);
			Cig[0][1]=-sin(pi/2+MisPosition_Rad[0][0])*cos(pi/2-MisPosition_Rad[0][1]);
			Cig[0][2]= sin(pi/2+MisPosition_Rad[0][0])*sin(pi/2-MisPosition_Rad[0][1]);
			Cig[1][0]= sin(pi/2+MisPosition_Rad[0][0]);
			Cig[1][1]= cos(pi/2+MisPosition_Rad[0][0])*cos(pi/2-MisPosition_Rad[0][1]);
			Cig[1][2]=-cos(pi/2+MisPosition_Rad[0][0])*sin(pi/2-MisPosition_Rad[0][1]);
			Cig[2][0]= 0;
			Cig[2][1]= sin(pi/2-MisPosition_Rad[0][1]);
			Cig[2][2]= cos(pi/2-MisPosition_Rad[0][1]);

			MatMulVec(Cig, MisVelocity, MisVelocityWGS84);

			//�����ת̨�ǶȽ��ٶ�Ϊ�Ƕ���
			MisAttitude_Rotary[0] = (float)MisAttitude[2][0];
			MisAttitude_Rotary[1] = (float)MisAttitude[1][0]; 
			MisAttitude_Rotary[2] = (float)MisAttitude[0][0]; 				
		
			MisAngRate_Rotary[0] = (float)MisAngRate[2][0];
			MisAngRate_Rotary[1] = (float)MisAngRate[1][0];	
			MisAngRate_Rotary[2] = (float)MisAngRate[0][0];

		    TarjCounter=TarjCounter+1;  
		}
	}
	if(MissileMode == DATARD_MODE)
	{
		if(RDModeCounter >= SensorAddrCounter/7)
		{
            MisTraceStop_Flag=1; 
			SuspendAsyncTimerCallbacks ();
			StopCMDCallback();		
		}
		else
		{
			MissileAngleRate[1][0] = *(SensorDataAddr + 7*RDModeCounter + 1) * DEGREE; //ǰ����->��ǰ��
			MissileAngleRate[2][0] = *(SensorDataAddr + 7*RDModeCounter + 2) * DEGREE;   
			MissileAngleRate[0][0] = *(SensorDataAddr + 7*RDModeCounter + 3) * DEGREE;  
		
			MissileSF[1][0] = *(SensorDataAddr + 7*RDModeCounter + 4);
			MissileSF[2][0] = *(SensorDataAddr + 7*RDModeCounter + 5);
			MissileSF[0][0] = *(SensorDataAddr + 7*RDModeCounter + 6);			
			
			Vec2Vec(MisAttitude_Rad, MisAttitude_Rad_Old);
			
			Vec2Vec(MisVelocity, MisVelocity_Old); 
			
		//	SinsNav_2_Trace(MissileAngleRate, MissileSF, MisQuaternion, MisVelocity, MisCep, 
		//		   &MisAltitude, MisStepTimeSec, MisOmegaipp, MisPosition_Rad, MisAttitude_Rad, &MisGravity);
			
			MisAngRate_Rad[0][0] = (MisAttitude_Rad_Old[0][0] - MisAttitude_Rad[0][0])/MisStepTimeSec;
			MisAngRate_Rad[1][0] = (MisAttitude_Rad_Old[1][0] - MisAttitude_Rad[1][0])/MisStepTimeSec; 
			MisAngRate_Rad[2][0] = (MisAttitude_Rad_Old[2][0] - MisAttitude_Rad[2][0])/MisStepTimeSec;
			
			MisAttitude[0][0] = MisAttitude_Rad[0][0]*180/pi;
			MisAttitude[1][0] = MisAttitude_Rad[1][0]*180/pi; 
			MisAttitude[2][0] = MisAttitude_Rad[2][0]*180/pi; 
			
			MisAngRate[0][0] = MisAngRate_Rad[0][0]*180/pi;
			MisAngRate[1][0] = MisAngRate_Rad[1][0]*180/pi; 
			MisAngRate[2][0] = MisAngRate_Rad[2][0]*180/pi; 
			
			MisPosition[0][0] = MisPosition_Rad[0][0]*180/pi; 
			MisPosition[1][0] = MisPosition_Rad[1][0]*180/pi; 			
			MisPosition[2][0] = MisPosition_Rad[2][0]; 			
				
			//΢�� �������ٶ�
			MisAcc[0][0] = (MisVelocity[0][0] - MisVelocity_Old[0][0])/MisStepTimeSec;
			MisAcc[1][0] = (MisVelocity[1][0] - MisVelocity_Old[1][0])/MisStepTimeSec; 
			MisAcc[2][0] = (MisVelocity[2][0] - MisVelocity_Old[2][0])/MisStepTimeSec;
				
			Cig[0][0]= cos(pi/2+MisPosition_Rad[0][0]);
			Cig[0][1]=-sin(pi/2+MisPosition_Rad[0][0])*cos(pi/2-MisPosition_Rad[0][1]);
			Cig[0][2]= sin(pi/2+MisPosition_Rad[0][0])*sin(pi/2-MisPosition_Rad[0][1]);
			Cig[1][0]= sin(pi/2+MisPosition_Rad[0][0]);
			Cig[1][1]= cos(pi/2+MisPosition_Rad[0][0])*cos(pi/2-MisPosition_Rad[0][1]);
			Cig[1][2]=-cos(pi/2+MisPosition_Rad[0][0])*sin(pi/2-MisPosition_Rad[0][1]);
			Cig[2][0]= 0;
			Cig[2][1]= sin(pi/2-MisPosition_Rad[0][1]);
			Cig[2][2]= cos(pi/2-MisPosition_Rad[0][1]);

			MisPositionWGS84[0][0]=(CalRn(MisPosition_Rad[1][0])+MisPosition_Rad[2][0])
				                  *(cos(MisPosition_Rad[1][0]))
								  *(cos(MisPosition_Rad[0][0]));
		    MisPositionWGS84[1][0]=(CalRn(MisPosition_Rad[1][0])+MisPosition_Rad[2][0])
				                  *(cos(MisPosition_Rad[1][0]))
								  *(sin(MisPosition_Rad[0][0]));
		    MisPositionWGS84[2][0]=(CalRn(MisPosition_Rad[1][0])*(1-e2)+MisPosition_Rad[2][0])
				                   *sin(MisPosition_Rad[1][0]);				
			
			MatMulVec(Cig, MisVelocity, MisVelocityWGS84);
			
			MatMulVec(Cig, MisAcc, MisAccWGS84); 

			MisAttitude_Rotary[0] = (float)MisAttitude[0][0];
			MisAttitude_Rotary[1] = (float)MisAttitude[2][0]; 
			MisAttitude_Rotary[2] = (float)MisAttitude[1][0]; 
		
			MisAngRate_Rotary[0] = (float)MisAngRate[0][0]; 
			MisAngRate_Rotary[1] = (float)MisAngRate[2][0]; 
			MisAngRate_Rotary[2] = (float)MisAngRate[1][0]; 
		}
	RDModeCounter++;				
	}	
}

int MisSmooth(double MisSF_SmoothStart[3][1], double MisAng_SmoothStart[3][1], 
	          double MisSF_SmoothValue[3][1], double MisAng_SmoothValue[3][1],
			  double MisSmoothT, double MisStepTS)  
{
    int SmoothPointNum;
	SmoothPointNum = MisSmoothT/MisStepTS;
	
	//MisSmoothCounter�����ó�ֵ������Ϊȫ�ֱ���
	if(MisSmoothCounter < SmoothPointNum)
	{
	    for(int i=0;i<=2;i++)
		{
			if(MisSF_SmoothStart[i][0] > 0)
			{
				MisSF_SmoothValue[i][0] = MisSF_SmoothStart[i][0]*0.5*(1 + cos(pi*MisSmoothCounter/SmoothPointNum)); 		
			}
			else
			{
				MisSF_SmoothValue[i][0] = MisSF_SmoothStart[i][0]*0.5*(1 + cos(pi*MisSmoothCounter/SmoothPointNum)); 			
			}
		}		
		
	    for(int i=0;i<=2;i++)
		{
			if(MisAng_SmoothStart[i][0] > 0)
			{
				MisAng_SmoothValue[i][0] = MisAng_SmoothStart[i][0]*0.5*(1 + cos(pi*MisSmoothCounter/SmoothPointNum)); 		
			}
			else
			{
				MisAng_SmoothValue[i][0] = MisAng_SmoothStart[i][0]*0.5*(1 + cos(pi*MisSmoothCounter/SmoothPointNum)); 			
			}
		}
	}
	//���������һ��ƽ���� ����ֵ1
	else if(MisSmoothCounter == SmoothPointNum)
	{
	    for(int i=0;i<=2;i++)
		{
			if(MisSF_SmoothStart[i][0] > 0)
			{
				MisSF_SmoothValue[i][0] = MisSF_SmoothStart[i][0]*0.5*(1 + cos(pi*MisSmoothCounter/SmoothPointNum)); 		
			}
			else
			{
				MisSF_SmoothValue[i][0] = MisSF_SmoothStart[i][0]*0.5*(1 + cos(pi*MisSmoothCounter/SmoothPointNum)); 			
			}	
		}	    
		
		for(int i=0;i<=2;i++)
		{
			if(MisAng_SmoothStart[i][0] > 0)
			{
				MisAng_SmoothValue[i][0] = MisAng_SmoothStart[i][0]*0.5*(1 + cos(pi*MisSmoothCounter/SmoothPointNum)); 		
			}
			else
			{
				MisAng_SmoothValue[i][0] = MisAng_SmoothStart[i][0]*0.5*(1 + cos(pi*MisSmoothCounter/SmoothPointNum)); 			
			}	
		}
		MisSmoothCounter = 1;
	return 1; 
	}
	MisSmoothCounter = MisSmoothCounter+1;
	return 0;
}

//***************************ģ�������ƺ���**************************// 

//ģ�����ⷴ���켣д��
void SendTrackDataToGNSS(char * pData, int iDataCount)			
{
    int status;
    glRfmComPtkID++;

	status = viMoveOut8 (GERFM_hDev.GERFM_instr, VI_PXI_BAR3_SPACE,0x500C, iDataCount, pData);  
	//����GNSSģ����Э�飬ÿ��Ҫ���ⷴ��Ox5000�ĵ�ַд��ͬ����������ģ������Ϊ�ǹ켣����
	status = viMoveOut8 (GERFM_hDev.GERFM_instr, VI_PXI_BAR3_SPACE,0x5000, 4,(char *)&glRfmComPtkID);  
}

//ģ�����ⷴ����ʼָ��д��
void SendStartCMDToGNSS(char * pData, int iDataCount)			
{
    int status;
    glRfmComPtkID_CMD++;

	status = viMoveOut8 (GERFM_hDev.GERFM_instr, VI_PXI_BAR3_SPACE,0x520C, iDataCount, pData);  
	//����GNSSģ����Э�飬ÿ��Ҫ���ⷴ��Ox5000�ĵ�ַд��ͬ����������ģ������Ϊ�ǹ켣����
	status = viMoveOut8 (GERFM_hDev.GERFM_instr, VI_PXI_BAR3_SPACE,0x5200, 4,(char *)&glRfmComPtkID_CMD);
	
	printf("glRfmComPtkID_CMD = %lld\n", glRfmComPtkID_CMD);
	printf("GNSS start cmd sent.\n");  
}

//ģ�����ⷴ��ָֹͣ��д�� 
void SendStopCMDToGNSS()			
{
    int status;
    glRfmComPtkID_CMD++;

	unsigned int framehead;
	unsigned int framesize;
	unsigned int frameend;
	
	unsigned int StopCMDKey; 
	unsigned int StopCMDPra_1; 
	unsigned int StopCMDPra_2; 
	
	framehead = 0x7b7b7b7b;
	framesize = 16;
    frameend = 0x7d7d7d7d; 
	
	StopCMDKey = 0x9099;
	//Ԥ������λ
	StopCMDPra_1 = 0;
	StopCMDPra_2 = 0;
	
	status = viMoveOut8 (GERFM_hDev.GERFM_instr, VI_PXI_BAR3_SPACE, 0x5204, 4,(char *)&framehead);
	status = viMoveOut8 (GERFM_hDev.GERFM_instr, VI_PXI_BAR3_SPACE, 0x5208, 4,(char *)&framesize);	

	status = viMoveOut8 (GERFM_hDev.GERFM_instr, VI_PXI_BAR3_SPACE, 0x520C, 4,(char *)&StopCMDKey);
	status = viMoveOut8 (GERFM_hDev.GERFM_instr, VI_PXI_BAR3_SPACE, 0x5210, 4,(char *)&framesize); 	
	status = viMoveOut8 (GERFM_hDev.GERFM_instr, VI_PXI_BAR3_SPACE, 0x5214, 4,(char *)&StopCMDPra_1); 
	status = viMoveOut8 (GERFM_hDev.GERFM_instr, VI_PXI_BAR3_SPACE, 0x5218, 4,(char *)&StopCMDPra_2); 
	
	status = viMoveOut8 (GERFM_hDev.GERFM_instr, VI_PXI_BAR3_SPACE, 0x5220, 4,(char *)&frameend);  
	
	//����GNSSģ����Э�飬ÿ��Ҫ���ⷴ��Ox5000�ĵ�ַд��ͬ����������ģ������Ϊ��ָ�����
	status = viMoveOut8 (GERFM_hDev.GERFM_instr, VI_PXI_BAR3_SPACE,0x5200, 4,(char *)&glRfmComPtkID_CMD);
	
	printf("glRfmComPtkID_CMD = %lld\n", glRfmComPtkID_CMD);  
	
	printf("GNSS stop cmd sent.\n"); 
}

//ģ�����ⷴ����������
void SendAGCSetCMDTOGNSS(unsigned int AGC_Value)
{
	int status;
	glRfmComPtkID_CMD++;
	
	unsigned int framehead;
	unsigned int framesize;
	unsigned int frameend;
	
	unsigned int AGC_SetCMDKey;
	unsigned int AGC_SetValue;
	unsigned int AGC_SetCMDPra;
	
	framehead = 0x7b7b7b7b;
	framesize = 16;
    frameend = 0x7d7d7d7d; 
	 
	AGC_SetCMDKey = 0x0ABB9055;
	AGC_SetValue = AGC_Value;
	//Ԥ������λ 
	AGC_SetCMDPra = 0;
	
	status = viMoveOut8 (GERFM_hDev.GERFM_instr, VI_PXI_BAR3_SPACE, 0x5204, 4,(char *)&framehead);
	status = viMoveOut8 (GERFM_hDev.GERFM_instr, VI_PXI_BAR3_SPACE, 0x5208, 4,(char *)&framesize);	

	status = viMoveOut8 (GERFM_hDev.GERFM_instr, VI_PXI_BAR3_SPACE, 0x520C, 4,(char *)&AGC_SetCMDKey);
	status = viMoveOut8 (GERFM_hDev.GERFM_instr, VI_PXI_BAR3_SPACE, 0x5210, 4,(char *)&framesize); 	
	status = viMoveOut8 (GERFM_hDev.GERFM_instr, VI_PXI_BAR3_SPACE, 0x5214, 4,(char *)&AGC_SetValue); 
	status = viMoveOut8 (GERFM_hDev.GERFM_instr, VI_PXI_BAR3_SPACE, 0x5218, 4,(char *)&AGC_SetCMDPra); 
	
	status = viMoveOut8 (GERFM_hDev.GERFM_instr, VI_PXI_BAR3_SPACE, 0x5220, 4,(char *)&frameend);  
	
	status = viMoveOut8 (GERFM_hDev.GERFM_instr, VI_PXI_BAR3_SPACE, 0x5200, 4,(char *)&glRfmComPtkID_CMD);
	
	printf("glRfmComPtkID_CMD = %lld\n", glRfmComPtkID_CMD);  
	
	printf("AGC %d set cmd sent.\n", AGC_Value); 	
	
}

//������������ָ��
void SendAGCChangeCMDTOGNSS(unsigned int SatGroup, unsigned int SatNum, unsigned int TimeStart, unsigned int AGCValueStart,
							unsigned int TimeStop, unsigned int AGCValueStop, unsigned int FlagChange)
{
	int status;
	glRfmComPtkID_CMD++;
	
	unsigned int framehead;
	unsigned int framesize;
	unsigned int frameend;
	
	unsigned int AGC_Change_SetCMDKey;
	unsigned int AGC_Change_UserID;
	
	unsigned int AGC_Change_SatGroup;   	//���� 0Ϊȫ��   1:B1 3:B3 4:L1
	unsigned int AGC_Change_SatNum;     	//�Ǻ� 0Ϊȫ��	
	unsigned int AGC_Change_TimeStart;     	//���ʱ仯��ʼʱ�� (s)	��Է��濪ʼʱ��	-1��ʱ����ģ������������
	unsigned int AGC_Change_ValueStart;     //���ʱ仯��ʼֵ	0���ر��ź�  1�����ź�	
	unsigned int AGC_Change_TimeStop;     	//���ʱ仯����ʱ�� (s)	��Է��濪ʼʱ��	-1��ʱ����ģ������������	
	unsigned int AGC_Change_ValueStop;     	//���ʱ仯����ֵ	0���ر��ź�  1�����ź�	                
	unsigned int AGC_Change_FlagChange;     //���ʱ仯��־		0��ֱ����������ʼ����  1���ӿ�ʼ�������Ա仯����������

	//Ԥ������λ
	unsigned int AGC_Change_SetCMDPra_1;
	unsigned int AGC_Change_SetCMDPra_2; 
	
	framehead = 0x7b7b7b7b;
	framesize = 44;
    frameend = 0x7d7d7d7d; 
	 
	AGC_Change_SetCMDKey = 0xFFFFFF14;
	AGC_Change_UserID = 0x0;
	
	AGC_Change_SatGroup = SatGroup;
	AGC_Change_SatNum = SatNum;
	AGC_Change_TimeStart = TimeStart;
	AGC_Change_ValueStart = AGCValueStart;
	AGC_Change_TimeStop = TimeStop;
	AGC_Change_ValueStop = AGCValueStop;
	AGC_Change_FlagChange = FlagChange;

	//Ԥ������λ 
	AGC_Change_SetCMDPra_1 = 0;
	AGC_Change_SetCMDPra_2 = 0;
	
	status = viMoveOut8 (GERFM_hDev.GERFM_instr, VI_PXI_BAR3_SPACE, 0x5204, 4,(char *)&framehead);
	status = viMoveOut8 (GERFM_hDev.GERFM_instr, VI_PXI_BAR3_SPACE, 0x5208, 4,(char *)&framesize);	

	status = viMoveOut8 (GERFM_hDev.GERFM_instr, VI_PXI_BAR3_SPACE, 0x520C, 4,(char *)&AGC_Change_SetCMDKey);
	status = viMoveOut8 (GERFM_hDev.GERFM_instr, VI_PXI_BAR3_SPACE, 0x5210, 4,(char *)&AGC_Change_UserID); 	
	
	status = viMoveOut8 (GERFM_hDev.GERFM_instr, VI_PXI_BAR3_SPACE, 0x5214, 4,(char *)&AGC_Change_SatGroup); 
	status = viMoveOut8 (GERFM_hDev.GERFM_instr, VI_PXI_BAR3_SPACE, 0x5218, 4,(char *)&AGC_Change_SatNum); 	
	status = viMoveOut8 (GERFM_hDev.GERFM_instr, VI_PXI_BAR3_SPACE, 0x521C, 4,(char *)&AGC_Change_TimeStart); 
	status = viMoveOut8 (GERFM_hDev.GERFM_instr, VI_PXI_BAR3_SPACE, 0x5220, 4,(char *)&AGC_Change_ValueStart); 	
	status = viMoveOut8 (GERFM_hDev.GERFM_instr, VI_PXI_BAR3_SPACE, 0x5224, 4,(char *)&AGC_Change_TimeStop); 
	status = viMoveOut8 (GERFM_hDev.GERFM_instr, VI_PXI_BAR3_SPACE, 0x5228, 4,(char *)&AGC_Change_ValueStop); 	
	status = viMoveOut8 (GERFM_hDev.GERFM_instr, VI_PXI_BAR3_SPACE, 0x522C, 4,(char *)&AGC_Change_FlagChange); 

	status = viMoveOut8 (GERFM_hDev.GERFM_instr, VI_PXI_BAR3_SPACE, 0x5230, 4,(char *)&AGC_Change_SetCMDPra_1); 	
	status = viMoveOut8 (GERFM_hDev.GERFM_instr, VI_PXI_BAR3_SPACE, 0x5234, 4,(char *)&AGC_Change_SetCMDPra_2); 
	
	status = viMoveOut8 (GERFM_hDev.GERFM_instr, VI_PXI_BAR3_SPACE, 0x523C, 4,(char *)&frameend); 	
	
	status = viMoveOut8 (GERFM_hDev.GERFM_instr, VI_PXI_BAR3_SPACE, 0x5200, 4,(char *)&glRfmComPtkID_CMD);
	
	printf("glRfmComPtkID_CMD = %lld\n", glRfmComPtkID_CMD);  
	
	printf("%d\t%d\t%d\t%d\t%d\t%d\t%d\n", AGC_Change_SatGroup, AGC_Change_SatNum, AGC_Change_TimeStart, AGC_Change_ValueStart,
										   AGC_Change_TimeStop, AGC_Change_ValueStop, AGC_Change_FlagChange); 
}

//α����������ָ��
void SendPseudorangeChangeCMDTOGNSS(unsigned int SatGroup, unsigned int SatNum, unsigned int PRChange, unsigned int TimeChange) 
{
	int status;
	glRfmComPtkID_CMD++;
	
	unsigned int framehead;
	unsigned int framesize;
	unsigned int frameend;
	
	unsigned int PR_Change_SetCMDKey;
	unsigned int PR_Change_UserID; 
	
	unsigned int PR_Change_SatGroup;   //���� 0Ϊȫ��  1:B1 3:B3 4:L1 
	unsigned int PR_Change_SatNum;     //�Ǻ� 0Ϊȫ��	
	unsigned int PR_Change_Value;      //α������ֵ		(m)
	unsigned int PR_Change_Time;       //α������ʱ��	(s)
	//Ԥ������λ
	unsigned int PR_Change_SetCMDPra_1;
	unsigned int PR_Change_SetCMDPra_2; 
	
	framehead = 0x7b7b7b7b;
	framesize = 32;
    frameend = 0x7d7d7d7d; 
	 
	PR_Change_SetCMDKey = 0xFFFFFF04;
	PR_Change_UserID = 0x0;
	
	PR_Change_SatGroup = SatGroup;
	PR_Change_SatNum = SatNum;
	PR_Change_Value = PRChange;
	PR_Change_Time = TimeChange;

	//Ԥ������λ 
	PR_Change_SetCMDPra_1 = 0;
	PR_Change_SetCMDPra_2 = 0;
	
	status = viMoveOut8 (GERFM_hDev.GERFM_instr, VI_PXI_BAR3_SPACE, 0x5204, 4,(char *)&framehead);
	status = viMoveOut8 (GERFM_hDev.GERFM_instr, VI_PXI_BAR3_SPACE, 0x5208, 4,(char *)&framesize);	

	status = viMoveOut8 (GERFM_hDev.GERFM_instr, VI_PXI_BAR3_SPACE, 0x520C, 4,(char *)&PR_Change_SetCMDKey);
	status = viMoveOut8 (GERFM_hDev.GERFM_instr, VI_PXI_BAR3_SPACE, 0x5210, 4,(char *)&PR_Change_UserID); 	
	
	
	status = viMoveOut8 (GERFM_hDev.GERFM_instr, VI_PXI_BAR3_SPACE, 0x5214, 4,(char *)&PR_Change_SatGroup); 
	status = viMoveOut8 (GERFM_hDev.GERFM_instr, VI_PXI_BAR3_SPACE, 0x5218, 4,(char *)&PR_Change_SatNum); 
	status = viMoveOut8 (GERFM_hDev.GERFM_instr, VI_PXI_BAR3_SPACE, 0x521c, 4,(char *)&PR_Change_Value); 
	status = viMoveOut8 (GERFM_hDev.GERFM_instr, VI_PXI_BAR3_SPACE, 0x5220, 4,(char *)&PR_Change_Time); 	
	status = viMoveOut8 (GERFM_hDev.GERFM_instr, VI_PXI_BAR3_SPACE, 0x5224, 4,(char *)&PR_Change_SetCMDPra_1); 
	status = viMoveOut8 (GERFM_hDev.GERFM_instr, VI_PXI_BAR3_SPACE, 0x5228, 4,(char *)&PR_Change_SetCMDPra_2); 
	
	status = viMoveOut8 (GERFM_hDev.GERFM_instr, VI_PXI_BAR3_SPACE, 0x5230, 4,(char *)&frameend);  
	
	status = viMoveOut8 (GERFM_hDev.GERFM_instr, VI_PXI_BAR3_SPACE, 0x5200, 4,(char *)&glRfmComPtkID_CMD);
	
	printf("glRfmComPtkID_CMD = %lld\n", glRfmComPtkID_CMD);  
	
	printf("%d\t%d\t%d\t%d\n", PR_Change_SatGroup, PR_Change_SatNum, PR_Change_Value, PR_Change_Time); 
}

//����ģ������ʼ��
void GNSS_GE_Initial(long long GNSS_TraceStartTimetart, long long GNSS_TraceTimeLast, double IniPosition[3][1])
{
	int status;
		
	unsigned int framehead;
	unsigned int framesize; 
	unsigned int frameend;
	
	framehead = 0x7b7b7b7b;
	framesize = 80;
	frameend = 0x7d7d7d7d;
	
	status = viMoveOut8 (GERFM_hDev.GERFM_instr, VI_PXI_BAR3_SPACE, 0x5204, 4,(char *)&framehead);
	status = viMoveOut8 (GERFM_hDev.GERFM_instr, VI_PXI_BAR3_SPACE, 0x5208, 4,(char *)&framesize);	
	
	GNSS_Start.CMDByte = 0x0ABB9011;
	GNSS_Start.CMDSize = 80;
	
	GNSS_Start.CMDPra_1 = 0;
	GNSS_Start.CMDPra_2 = 0;
	
	GNSS_Start.Sim_Start_Time = GNSS_TraceStartTimetart;
	GNSS_Start.Sim_Time_Last = GNSS_TraceTimeLast;
	
	GNSS_Start.INIT_POS_X = IniPosition[0][0];
	GNSS_Start.INIT_POS_Y = IniPosition[1][0]; 
	GNSS_Start.INIT_POS_Z = IniPosition[2][0]; 
	
	GNSS_Start.dUserAzimu = 0;
	GNSS_Start.dUserPitch = 0;
	GNSS_Start.dUserRoll = 0;
	//80�����ݳ��� ��λУ��λ
	status = viMoveOut8 (GERFM_hDev.GERFM_instr, VI_PXI_BAR3_SPACE, 0x5260, 4,(char *)&frameend); 	
  
	SendStartCMDToGNSS((char *)&GNSS_Start, sizeof(struct GNSS_SimStartCMD));	
}

//����ģ��������д��
void GNSS_GE_Write(double Position[3][1], double Velocity[3][1], double Acc[3][1])
{
	int status;
	
	unsigned int framehead;
	unsigned int framesize;
	unsigned int frameend;
	
	framehead = 0x7b7b7b7b;
	framesize = 248;
    frameend = 0x7d7d7d7d; 
	
	status = viMoveOut8 (GERFM_hDev.GERFM_instr, VI_PXI_BAR3_SPACE, 0x5004, 4,(char *)&framehead);
	status = viMoveOut8 (GERFM_hDev.GERFM_instr, VI_PXI_BAR3_SPACE, 0x5008, 4,(char *)&framesize);
	
    lRfmTransRec.Cmdkey = 0x0A5A5C39;
	
    double dTime, dTemp;
	int iTime;
	//float->int
	dTime = TraceTime*1000;
	iTime = (int)dTime;
	dTemp = dTime - iTime;
	if(dTemp > 0.1)  iTime++;
	if(dTemp <-0.1)  iTime--;
	
    lRfmTransRec.iTrackBDT = iTime; //��ת��Ϊ���� 
    lRfmTransRec.iTrackID = TimerCounter;
    lRfmTransRec.dbeSimTime1 = 0.0;

    lRfmTransRec.dUserPosX = Position[0][0];
    lRfmTransRec.dUserPosY = Position[1][0];
    lRfmTransRec.dUserPosZ = Position[2][0];
	
    lRfmTransRec.dUserVelX = Velocity[0][0];
    lRfmTransRec.dUserVelY = Velocity[1][0];
    lRfmTransRec.dUserVelZ = Velocity[2][0];
	
    lRfmTransRec.dUserAccX = 0.0;//Acc[0][0];
    lRfmTransRec.dUserAccY = 0.0;//Acc[1][0];
    lRfmTransRec.dUserAccZ = 0.0;//Acc[2][0];
	
    lRfmTransRec.dUserJekX = 0.0; 
    lRfmTransRec.dUserJekY = 0.0; 
    lRfmTransRec.dUserJekZ = 0.0; 

    lRfmTransRec.iPoseBDT =(int)(TraceTime*1000); ;
    lRfmTransRec.iPoseID = 0;
    lRfmTransRec.dbeSimTime2 = 0.0;

    lRfmTransRec.dUserRoll = 0.0;
    lRfmTransRec.dUserAzimu = 0.0;
    lRfmTransRec.dUserPitch = 0.0;
	
    lRfmTransRec.dUserRollVelX = 0.0;
    lRfmTransRec.dUserRollVelY = 0.0;
    lRfmTransRec.dUserRollVelZ = 0.0;
	
    lRfmTransRec.dUserRollAccX = 0.0;
    lRfmTransRec.dUserRollAccY = 0.0;
    lRfmTransRec.dUserRollAccZ = 0.0;
	
    lRfmTransRec.dUserRollJekX = 0.0;
    lRfmTransRec.dUserRollJekY = 0.0;
    lRfmTransRec.dUserRollJekZ = 0.0;
	
	status = viMoveOut8 (GERFM_hDev.GERFM_instr, VI_PXI_BAR3_SPACE, 0x5108, 4,(char *)&frameend); 
    
	SendTrackDataToGNSS((char *)&lRfmTransRec, sizeof(struct TRfmCardTransRec)); 
}

//******************************���ú���*****************************//

//����ע��Timer
int CVICALLBACK CurrentWrite_Timer(int reserved, int timerId, int event, void *callbackData,
	                              int eventData1, int eventData2)
{
	SetProcessorAffinityForThread (kProcessorPool_None, 1 , NULL, NULL); 
	
	double currentLevel_x;
	double currentLevel_y; 
	double currentLevel_z; 
	
	if (event == EVENT_TIMER_TICK)	  
	{
		//�ӼƵ���������ɣ�X�������ע��ͬ��YZ�������ע�뷴�� 
		currentLevel_x = - MissileSFCompensate[0][0] * ACCELERATION_TO_CURRENT / 10;   
		currentLevel_y =   MissileSFCompensate[2][0] * ACCELERATION_TO_CURRENT / 10;  
		currentLevel_z =   MissileSFCompensate[1][0] * ACCELERATION_TO_CURRENT / 10;		

		AcurrentLevel_x =  currentLevel_x;		
		AcurrentLevel_y =  currentLevel_y;
		AcurrentLevel_z =  currentLevel_z;
		
		//X��ӼƵ�����ֵ
		DC0.currentLevel = currentLevel_x;   
		
		//Y��ӼƵ�����ֵ
		if(fabs(currentLevel_y) >= 0.000004)
		{
			DC1.currentLevel = currentLevel_y;	
		}
		else
		{
		    if(CurrentWriteCounter_DC1 == 0)
			{
			    DC1.currentLevel = currentLevel_y + CURRENT_OFFSET_VAL;
				CurrentWriteCounter_DC1 = 1;
			}
		    else if(CurrentWriteCounter_DC1 == 1)
			{
				DC1.currentLevel = currentLevel_y - CURRENT_OFFSET_VAL;  
				CurrentWriteCounter_DC1 = 0; 
			}
		}
		
		//Z��ӼƵ�����ֵ
		if(fabs(currentLevel_z) >= 0.000004)
		{
			DC2.currentLevel = currentLevel_z;	
		}
		else
		{
		    if(CurrentWriteCounter_DC2 == 0)
			{
			    DC2.currentLevel = currentLevel_z + CURRENT_OFFSET_VAL;
				CurrentWriteCounter_DC2 = 1;
			}
		    else if(CurrentWriteCounter_DC2 == 1)
			{
				DC2.currentLevel = currentLevel_z - CURRENT_OFFSET_VAL;  
				CurrentWriteCounter_DC2 = 0; 
			}
		}
		
		//��������Ϊ12mA
		if(		(fabs(DC0.currentLevel) < 0.012) &&
		   		(fabs(DC1.currentLevel) < 0.012) && 
		 	  	(fabs(DC2.currentLevel) < 0.012)  
		  )
		{
			accsimuSet4141 (DC0);
			accsimuSet4130 (DC1);
			accsimuSet4130 (DC2);		
		}
		else
		{
			printf("Current value beyond!\n");	 		
			printf("%lf\t%lf\t%lf\n", DC0.currentLevel, DC1.currentLevel, DC2.currentLevel);
		}

		/*
		A_Start_Time_Flag=GetTimeUS();

		A_StartTime_Sub=A_Start_Time_Flag-A_Start_Time_Flag_Old;

		A_Start_Time_Flag_Old=A_Start_Time_Flag;

		A_Stop_Time_Flag=GetTimeUS();

		ATime=A_Stop_Time_Flag-A_Start_Time_Flag;
		*/	
	
	}
	return 0; 
}

//��̬��׼�����������Timer
int CVICALLBACK CurrentOffsetTimer(int reserved, int timerId, int event, void *callbackData,
	                              int eventData1, int eventData2)
{
	SetProcessorAffinityForThread (kProcessorPool_None, 1 , NULL, NULL); 
	if(CurrentOffsetCounter % 2 == 1 )
	{
	    DC1.currentLevel = CURRENT_OFFSET_VAL;
		DC2.currentLevel = CURRENT_OFFSET_VAL;
		accsimuSet4130 (DC1);
        accsimuSet4130 (DC2);	
	}
		
	else if(CurrentOffsetCounter % 2 == 0 ) 	
	{
	    DC1.currentLevel = - CURRENT_OFFSET_VAL;
		DC2.currentLevel = - CURRENT_OFFSET_VAL;
		accsimuSet4130 (DC1); 
        accsimuSet4130 (DC2);		
	}
	else;
		
	CurrentOffsetCounter++;
	return 0;
}

//ʵ��ǰ������ע�뿨����ֵ
void InitCurrentBoard(void)
{
/*	
 	DC0.currentLevel =  0;
	DC1.currentLevel = -0.000008;
	DC2.currentLevel = -0.000008;

	accsimuSet4141 (DC0);
	accsimuSet4130 (DC1);
	accsimuSet4130 (DC2);    
	
								  	      
	DC0.currentLevel = -0.000000;
	DC1.currentLevel = -0.000008;
	DC2.currentLevel = -0.000008;		
										  
	accsimuSet4141 (DC0);
	accsimuSet4130 (DC1);
	accsimuSet4130 (DC2);
	
    SleepUS(100); 				   	 
*/										
	accsimuMeasure (&DC0);
	printf("DC0.measuredCurrent = %lf\n",DC0.measuredCurrent);
	accsimuMeasure (&DC1);
	printf("DC1.measuredCurrent = %lf\n",DC1.measuredCurrent);  	
	accsimuMeasure (&DC2);	
	printf("DC2.measuredCurrent = %lf\n",DC2.measuredCurrent);  	
}

//���ݡ�״̬�ϴ�����
void Update(void) 
{					  
//  �����߳�ͬʱ����һ��������������� 
	CmtGetLock (gLock);  //����ס�ϸô����ݵ��߳�
	if (gDataConnection != TCP_INVALID_CONNECTION)
	{
		ServerTCPWrite (gDataConnection, &data, sizeof(data), 1);
	}
	CmtReleaseLock (gLock); 
}

//ת̨��ʼ������������ָ� 
int Initial_RotaryTab(double Rotary_Angle_Inner , double Rotary_Angle_Mid , double Rotary_Angle_Outer)
{ 
	int status;
	int timeStart;
	int timeNow;  
	
	float initAngle_Rotary[3][1];
	float initRate_Rotary[3][1];
	float initAngleGet_Rotary[3][1];
	float initRateGet_Rotary[3][1];
	
	float Flag_Init_OK[3];

	double initAngle_Trace[3][1];
	double initRate_Trace[3][1];
	
	//�ض����ݳ�ֵ,��ֹ����ת̨���Ϸ���0���󱨳�ʼ���ɹ�
	initAngleGet_Rotary[0][0] = 400;
	initAngleGet_Rotary[0][0] = 400;  
	initAngleGet_Rotary[0][0] = 400;  

	initRate_Rotary[0][0] = 0.1; 
	initRate_Rotary[1][0] = 0.1; 
	initRate_Rotary[2][0] = 0.1; 	
	
	initAngle_Trace[0][0] = Rotary_Angle_Outer*pi/180;
	initAngle_Trace[1][0] = Rotary_Angle_Mid*pi/180;
	initAngle_Trace[2][0] = Rotary_Angle_Inner*pi/180;
	
	initRate_Trace[0][0] = initRate_Rotary[2][0]*pi/180;
	initRate_Trace[1][0] = initRate_Rotary[1][0]*pi/180;
	initRate_Trace[2][0] = initRate_Rotary[0][0]*pi/180;	
	//�ɹ켣�ǶȽ��ٶȵ�ת̨����ǶȽ��ٶ�
    TraceToRotary(initAngle_Trace, initRate_Trace, initAngle_Rotary, initRate_Rotary); 	
	
	status = rfmRotaryClimb(*initAngle_Rotary, *initRate_Rotary, *initAngleGet_Rotary, *initRateGet_Rotary, MisStepTime);  
	
	if(status == 1)
	{
		data.status = ROTARY_DATA_TIMEOUT;
		Update();
		Delay(1) ;
		data.status = ROTARY_INIT_FAIL;
		Update();
		return 0;		 
	}
	else
	{  
		//�趨���½��ٶ� 
		if(
			((initAngle_Rotary[0][0] - initAngleGet_Rotary[0][0] <=  180)&&(initAngle_Rotary[0][0] - initAngleGet_Rotary[0][0] >= 0))||
			((initAngle_Rotary[0][0] - initAngleGet_Rotary[0][0] <= -180)&&(initAngle_Rotary[0][0] - initAngleGet_Rotary[0][0] >= -360))
		  )
			initRate_Rotary[0][0] =  20;  
		else
			initRate_Rotary[0][0] = -20;
		
		if(
			((initAngle_Rotary[1][0] - initAngleGet_Rotary[1][0] <=  180)&&(initAngle_Rotary[1][0] - initAngleGet_Rotary[1][0] >= 0))||
			((initAngle_Rotary[1][0] - initAngleGet_Rotary[1][0] <= -180)&&(initAngle_Rotary[1][0] - initAngleGet_Rotary[1][0] >= -360))
		  )
			initRate_Rotary[1][0] =  10;  
		else
			initRate_Rotary[1][0] = -10;		
		
		if(
			((initAngle_Rotary[2][0] - initAngleGet_Rotary[2][0] <=  180)&&(initAngle_Rotary[2][0] - initAngleGet_Rotary[2][0] >= 0))||
			((initAngle_Rotary[2][0] - initAngleGet_Rotary[2][0] <= -180)&&(initAngle_Rotary[2][0] - initAngleGet_Rotary[2][0] >= -360))
		  )
			initRate_Rotary[2][0] =  5;  
		else
			initRate_Rotary[2][0] = -5;
	}

	printf("Rotary tabler Iniitial Start !\n");

	timeStart = (double)GetTimeUS() / 1000; 
	//�������С��0.01�����ж�ת̨��λ
	do{
		SleepUS(100000);
		status = rfmRotaryClimb(*initAngle_Rotary, *initRate_Rotary, *initAngleGet_Rotary, *initRateGet_Rotary, MisStepTime);
		//�ض����ݳ�ʱ����
		if(status == 1)
		{
			 data.status = ROTARY_DATA_TIMEOUT;
			 Update();
			 return 0;
		}
		//ת��ʱ�䳬��40s����
		timeNow = (double)GetTimeUS() / 1000;
		if (timeNow - timeStart > 40 * 1000)
		{
			printf("Error: Rotary climb set fail!\n");
			data.status = ROTARY_INIT_FAIL;
			Update();
			
			return 0;
		}
	
		Flag_Init_OK[0] = fabs(initAngleGet_Rotary[0][0] - initAngle_Rotary[0][0]);
		Flag_Init_OK[1] = fabs(initAngleGet_Rotary[1][0] - initAngle_Rotary[1][0]);  
		Flag_Init_OK[2] = fabs(initAngleGet_Rotary[2][0] - initAngle_Rotary[2][0]); 
//		printf("%lf\t%lf\t%lf\n", Flag_Init_OK[0], Flag_Init_OK[1], Flag_Init_OK[2]);
		for(int k=0; k<3; k++)
		{
			if(fabs(Flag_Init_OK[k] - 360)<0.01)
				Flag_Init_OK[k] = 0;	
		}
//		printf("%lf\t%lf\t%lf\n", Flag_Init_OK[0], Flag_Init_OK[1], Flag_Init_OK[2]); 
	}
	while(  ( Flag_Init_OK[0] > 0.01) || 
		    ( Flag_Init_OK[1] > 0.01) || 
		    ( Flag_Init_OK[2] > 0.01) );	

    printf("Inn_error = %f\tMid_error = %f\tOut_error = %f\n", 
			(initAngleGet_Rotary[0][0] - initAngle_Rotary[0][0]), 
			(initAngleGet_Rotary[1][0] - initAngle_Rotary[1][0]), 
			(initAngleGet_Rotary[2][0] - initAngle_Rotary[2][0]));

	data.status = ROTARY_INIT_DONE;
	Update();
	
	printf("Rotary table Iniitial Done !\n");
	return 1; 
}  

//�ػ��켣���ݴ����ڴ�
void CraftDataWriteToMemory(void) 
{
	if (SimDataIniLength*((SimDataAddrOffset/SimDataIniLength)+1) - SimDataAddrOffset <= 110)
	{
		MemoryReallocFlag = 1;
	}
    //�ػ��켣����
	*(SimulationDataSaveAddr + SimDataAddrOffset) = TraceTime;									 
	SimDataAddrOffset++;	
	
	*(SimulationDataSaveAddr + SimDataAddrOffset) = (double) TraceTime2GNSS;									 
	SimDataAddrOffset++;
	*(SimulationDataSaveAddr + SimDataAddrOffset) = CraftPosition[0][0]*180/pi;
	SimDataAddrOffset++;
	*(SimulationDataSaveAddr + SimDataAddrOffset) = CraftPosition[1][0]*180/pi;
	SimDataAddrOffset++;
	*(SimulationDataSaveAddr + SimDataAddrOffset) = CraftPosition[2][0];
	SimDataAddrOffset++;
	*(SimulationDataSaveAddr + SimDataAddrOffset) = CraftVelocity[0][0];
	SimDataAddrOffset++;
	*(SimulationDataSaveAddr + SimDataAddrOffset) = CraftVelocity[1][0];
	SimDataAddrOffset++;
	*(SimulationDataSaveAddr + SimDataAddrOffset) = CraftVelocity[2][0];
	SimDataAddrOffset++;
	*(SimulationDataSaveAddr + SimDataAddrOffset) = CraftAcc[0][0];
	SimDataAddrOffset++;						         
	*(SimulationDataSaveAddr + SimDataAddrOffset) = CraftAcc[1][0];
	SimDataAddrOffset++;						         
	*(SimulationDataSaveAddr + SimDataAddrOffset) = CraftAcc[2][0];
	SimDataAddrOffset++;
	
	*(SimulationDataSaveAddr + SimDataAddrOffset) = CraftAttitude[0][0]*180/pi;
	SimDataAddrOffset++;								      
	*(SimulationDataSaveAddr + SimDataAddrOffset) = CraftAttitude[1][0]*180/pi;
	SimDataAddrOffset++;								      
	*(SimulationDataSaveAddr + SimDataAddrOffset) = CraftAttitude[2][0]*180/pi;
	SimDataAddrOffset++;
	*(SimulationDataSaveAddr + SimDataAddrOffset) = CraftAttitudeChangeRate[0][0]*180/pi;
	SimDataAddrOffset++;								            
	*(SimulationDataSaveAddr + SimDataAddrOffset) = CraftAttitudeChangeRate[1][0]*180/pi;
	SimDataAddrOffset++;								            
	*(SimulationDataSaveAddr + SimDataAddrOffset) = CraftAttitudeChangeRate[2][0]*180/pi;
	SimDataAddrOffset++;
	
	*(SimulationDataSaveAddr + SimDataAddrOffset) = CraftSFB[0][0];
	SimDataAddrOffset++;										        
	*(SimulationDataSaveAddr + SimDataAddrOffset) = CraftSFB[1][0];
	SimDataAddrOffset++;										        
	*(SimulationDataSaveAddr + SimDataAddrOffset) = CraftSFB[2][0];
	SimDataAddrOffset++;
	
	*(SimulationDataSaveAddr + SimDataAddrOffset) = CraftOmegaiBB[0][0]*180/pi;
	SimDataAddrOffset++;										        
	*(SimulationDataSaveAddr + SimDataAddrOffset) = CraftOmegaiBB[1][0]*180/pi;
	SimDataAddrOffset++;
	*(SimulationDataSaveAddr + SimDataAddrOffset) = CraftOmegaiBB[2][0]*180/pi;
	SimDataAddrOffset++;
	
	*(SimulationDataSaveAddr + SimDataAddrOffset) = CraftInsSFs[0][0];
	SimDataAddrOffset++;
	*(SimulationDataSaveAddr + SimDataAddrOffset) = CraftInsSFs[1][0];
	SimDataAddrOffset++;										        
	*(SimulationDataSaveAddr + SimDataAddrOffset) = CraftInsSFs[2][0];
	SimDataAddrOffset++;
	*(SimulationDataSaveAddr + SimDataAddrOffset) = CraftInsOmegaiBBs[0][0]*180/pi;
	SimDataAddrOffset++;										        
	*(SimulationDataSaveAddr + SimDataAddrOffset) = CraftInsOmegaiBBs[1][0]*180/pi;
	SimDataAddrOffset++;
	*(SimulationDataSaveAddr + SimDataAddrOffset) = CraftInsOmegaiBBs[2][0]*180/pi;
	SimDataAddrOffset++;

	//int��
	*(SimulationDataSaveAddr + SimDataAddrOffset) = CraftGPulseOut[0][0];		
	SimDataAddrOffset++;										        
	*(SimulationDataSaveAddr + SimDataAddrOffset) = CraftGPulseOut[1][0];
	SimDataAddrOffset++;
	*(SimulationDataSaveAddr + SimDataAddrOffset) = CraftGPulseOut[2][0];
	SimDataAddrOffset++;
	*(SimulationDataSaveAddr + SimDataAddrOffset) = CraftGPulseOut[0][0];
	SimDataAddrOffset++;										        
	*(SimulationDataSaveAddr + SimDataAddrOffset) = CraftGPulseOut[1][0];
	SimDataAddrOffset++;
	*(SimulationDataSaveAddr + SimDataAddrOffset) = CraftGPulseOut[2][0];
	SimDataAddrOffset++;
	
	//���ߵ���Ч��־
	*(SimulationDataSaveAddr + SimDataAddrOffset) = CraftNavFlag;
	SimDataAddrOffset++;
	
	*(SimulationDataSaveAddr + SimDataAddrOffset) = CraftInsPosition[0][0]*180/pi;
	SimDataAddrOffset++;										        
	*(SimulationDataSaveAddr + SimDataAddrOffset) = CraftInsPosition[1][0]*180/pi;
	SimDataAddrOffset++;
	*(SimulationDataSaveAddr + SimDataAddrOffset) = CraftInsPosition[2][0];
	SimDataAddrOffset++;
	
	*(SimulationDataSaveAddr + SimDataAddrOffset) = CraftInsVelocityP[0][0];
	SimDataAddrOffset++;										        
	*(SimulationDataSaveAddr + SimDataAddrOffset) = CraftInsVelocityP[1][0];
	SimDataAddrOffset++;
	*(SimulationDataSaveAddr + SimDataAddrOffset) = CraftInsVelocityP[2][0];
	SimDataAddrOffset++;
	
	*(SimulationDataSaveAddr + SimDataAddrOffset) = CraftInsAttitude[0][0]*180/pi;
	SimDataAddrOffset++;										        
	*(SimulationDataSaveAddr + SimDataAddrOffset) = CraftInsAttitude[1][0]*180/pi;
	SimDataAddrOffset++;
	*(SimulationDataSaveAddr + SimDataAddrOffset) = CraftInsAttitude[2][0]*180/pi;
	SimDataAddrOffset++;
	
	*(SimulationDataSaveAddr + SimDataAddrOffset) = CraftPositionCha[0][0];
	SimDataAddrOffset++;
	*(SimulationDataSaveAddr + SimDataAddrOffset) = CraftPositionCha[1][0];
	SimDataAddrOffset++;
	*(SimulationDataSaveAddr + SimDataAddrOffset) = CraftPositionCha[2][0];
	SimDataAddrOffset++;
	
	*(SimulationDataSaveAddr + SimDataAddrOffset) = CraftVelocityCha[0][0];
	SimDataAddrOffset++;
	*(SimulationDataSaveAddr + SimDataAddrOffset) = CraftVelocityCha[1][0];
	SimDataAddrOffset++;
	*(SimulationDataSaveAddr + SimDataAddrOffset) = CraftVelocityCha[2][0];
	SimDataAddrOffset++;
	
	*(SimulationDataSaveAddr + SimDataAddrOffset) = AttCha[0][0];
	SimDataAddrOffset++;
	*(SimulationDataSaveAddr + SimDataAddrOffset) = AttCha[1][0];
	SimDataAddrOffset++;
	*(SimulationDataSaveAddr + SimDataAddrOffset) = AttCha[2][0];
	SimDataAddrOffset++;
	
	
	//�����Ч��־
	*(SimulationDataSaveAddr + SimDataAddrOffset) = FcsNavFlag;
	SimDataAddrOffset++;
	
	*(SimulationDataSaveAddr + SimDataAddrOffset) = FcsPos[0][0];
	SimDataAddrOffset++;										        
	*(SimulationDataSaveAddr + SimDataAddrOffset) = FcsPos[1][0];
	SimDataAddrOffset++;
	*(SimulationDataSaveAddr + SimDataAddrOffset) = FcsPos[2][0];
	SimDataAddrOffset++;
	
	*(SimulationDataSaveAddr + SimDataAddrOffset) = FcsVel[0][0];
	SimDataAddrOffset++;										        
	*(SimulationDataSaveAddr + SimDataAddrOffset) = FcsVel[1][0];
	SimDataAddrOffset++;
	*(SimulationDataSaveAddr + SimDataAddrOffset) = FcsVel[2][0];
	SimDataAddrOffset++;
	
	*(SimulationDataSaveAddr + SimDataAddrOffset) = FcsAttitude[0][0]/DEGREE;
	SimDataAddrOffset++;														
	*(SimulationDataSaveAddr + SimDataAddrOffset) = FcsAttitude[1][0]/DEGREE;
	SimDataAddrOffset++;	
	*(SimulationDataSaveAddr + SimDataAddrOffset) = FcsAttitude[2][0]/DEGREE;
	SimDataAddrOffset++;	
	
	*(SimulationDataSaveAddr + SimDataAddrOffset) = FcsQtn[0][0];
	SimDataAddrOffset++;										        
	*(SimulationDataSaveAddr + SimDataAddrOffset) = FcsQtn[1][0];
	SimDataAddrOffset++;
	*(SimulationDataSaveAddr + SimDataAddrOffset) = FcsQtn[2][0];
	SimDataAddrOffset++;
	*(SimulationDataSaveAddr + SimDataAddrOffset) = FcsQtn[3][0];
	SimDataAddrOffset++;	
		
	*(SimulationDataSaveAddr + SimDataAddrOffset) = FcsGravity[0][0];
	SimDataAddrOffset++;								        
	*(SimulationDataSaveAddr + SimDataAddrOffset) = FcsGravity[1][0];
	SimDataAddrOffset++;
	*(SimulationDataSaveAddr + SimDataAddrOffset) = FcsGravity[2][0];
	SimDataAddrOffset++;
	
	//84ϵ
	*(SimulationDataSaveAddr + SimDataAddrOffset) = CraftPositionWGS84[0][0];  
	SimDataAddrOffset++;	
	*(SimulationDataSaveAddr + SimDataAddrOffset) = CraftPositionWGS84[1][0];
	SimDataAddrOffset++;	
	*(SimulationDataSaveAddr + SimDataAddrOffset) = CraftPositionWGS84[2][0];
	SimDataAddrOffset++;	
	
	*(SimulationDataSaveAddr + SimDataAddrOffset) = CraftVelocityGNSS[0][0];  
	SimDataAddrOffset++;	
	*(SimulationDataSaveAddr + SimDataAddrOffset) = CraftVelocityGNSS[1][0];
	SimDataAddrOffset++;	
	*(SimulationDataSaveAddr + SimDataAddrOffset) = CraftVelocityGNSS[2][0];
	SimDataAddrOffset++;	

	*(SimulationDataSaveAddr + SimDataAddrOffset) = CraftAccGNSS[0][0];  
	SimDataAddrOffset++;	
	*(SimulationDataSaveAddr + SimDataAddrOffset) = CraftAccGNSS[1][0];
	SimDataAddrOffset++;	
	*(SimulationDataSaveAddr + SimDataAddrOffset) = CraftAccGNSS[2][0];
	SimDataAddrOffset++;
	
	//��ת̨���͵�����
	*(SimulationDataSaveAddr + SimDataAddrOffset) = CraftAttitude_Rotary[0];  
	SimDataAddrOffset++;	
	*(SimulationDataSaveAddr + SimDataAddrOffset) = CraftAttitude_Rotary[1];
	SimDataAddrOffset++;	
	*(SimulationDataSaveAddr + SimDataAddrOffset) = CraftAttitude_Rotary[2];
	SimDataAddrOffset++;	

	*(SimulationDataSaveAddr + SimDataAddrOffset) = CraftAngRate_Rotary[0];  
	SimDataAddrOffset++;	
	*(SimulationDataSaveAddr + SimDataAddrOffset) = CraftAngRate_Rotary[1];
	SimDataAddrOffset++;	
	*(SimulationDataSaveAddr + SimDataAddrOffset) = CraftAngRate_Rotary[2];
	SimDataAddrOffset++;	
	
	//ת̨�ض�����
	*(SimulationDataSaveAddr + SimDataAddrOffset) = TurnTableAngle[0][0];		 
	SimDataAddrOffset++;
	*(SimulationDataSaveAddr + SimDataAddrOffset) = TurnTableAngle[1][0];
	SimDataAddrOffset++;
	*(SimulationDataSaveAddr + SimDataAddrOffset) = TurnTableAngle[2][0];
	SimDataAddrOffset++;
	
	*(SimulationDataSaveAddr + SimDataAddrOffset) = RotaryRateGet[0];		  
	SimDataAddrOffset++;
	*(SimulationDataSaveAddr + SimDataAddrOffset) = RotaryRateGet[1];
	SimDataAddrOffset++;
	*(SimulationDataSaveAddr + SimDataAddrOffset) = RotaryRateGet[2];
	SimDataAddrOffset++;

	//��������6��
	*(SimulationDataSaveAddr + SimDataAddrOffset) = TestVarible_1;  
	SimDataAddrOffset++;	
	*(SimulationDataSaveAddr + SimDataAddrOffset) = TestVarible_2;
	SimDataAddrOffset++;	
	*(SimulationDataSaveAddr + SimDataAddrOffset) = TestVarible_3;
	SimDataAddrOffset++;
	
	*(SimulationDataSaveAddr + SimDataAddrOffset) = TestVarible_4;  
	SimDataAddrOffset++;	
	*(SimulationDataSaveAddr + SimDataAddrOffset) = TestVarible_5;
	SimDataAddrOffset++;	
	*(SimulationDataSaveAddr + SimDataAddrOffset) = TestVarible_6;
	SimDataAddrOffset++;
}

//�����켣���ݴ����ڴ�
void MissileDataWriteToMemory(void) 
{
	if (SimDataIniLength*((SimDataAddrOffset/SimDataIniLength)+1) - SimDataAddrOffset <= 64)
	{
		MemoryReallocFlag = 1;
	}
    //�ػ��켣����
	*(SimulationDataSaveAddr + SimDataAddrOffset) = TraceTime;
	SimDataAddrOffset++;
	*(SimulationDataSaveAddr + SimDataAddrOffset) = MisPosition[0][0];
	SimDataAddrOffset++;
	*(SimulationDataSaveAddr + SimDataAddrOffset) = MisPosition[1][0];
	SimDataAddrOffset++;
	*(SimulationDataSaveAddr + SimDataAddrOffset) = MisPosition[2][0];
	SimDataAddrOffset++;
	*(SimulationDataSaveAddr + SimDataAddrOffset) = MisVelocity[0][0];
	SimDataAddrOffset++;
	*(SimulationDataSaveAddr + SimDataAddrOffset) = MisVelocity[1][0];
	SimDataAddrOffset++;
	*(SimulationDataSaveAddr + SimDataAddrOffset) = MisVelocity[2][0];
	SimDataAddrOffset++;
	*(SimulationDataSaveAddr + SimDataAddrOffset) = MisAcc[0][0];
	SimDataAddrOffset++;						         
	*(SimulationDataSaveAddr + SimDataAddrOffset) = MisAcc[1][0];
	SimDataAddrOffset++;						         
	*(SimulationDataSaveAddr + SimDataAddrOffset) = MisAcc[2][0];
	SimDataAddrOffset++;
	*(SimulationDataSaveAddr + SimDataAddrOffset) = MisAttitude[0][0];
	SimDataAddrOffset++;								      
	*(SimulationDataSaveAddr + SimDataAddrOffset) = MisAttitude[1][0];
	SimDataAddrOffset++;								      
	*(SimulationDataSaveAddr + SimDataAddrOffset) = MisAttitude[2][0];
	SimDataAddrOffset++;
	*(SimulationDataSaveAddr + SimDataAddrOffset) = MisAngRate[0][0];
	SimDataAddrOffset++;								      
	*(SimulationDataSaveAddr + SimDataAddrOffset) = MisAngRate[1][0];
	SimDataAddrOffset++;								      
	*(SimulationDataSaveAddr + SimDataAddrOffset) = MisAngRate[2][0];
	SimDataAddrOffset++;
	*(SimulationDataSaveAddr + SimDataAddrOffset) = MissileSF[0][0];
	SimDataAddrOffset++;										        
	*(SimulationDataSaveAddr + SimDataAddrOffset) = MissileSF[1][0];
	SimDataAddrOffset++;										        
	*(SimulationDataSaveAddr + SimDataAddrOffset) = MissileSF[2][0];
	SimDataAddrOffset++;
	*(SimulationDataSaveAddr + SimDataAddrOffset) = MissileAngleRate[0][0];
	SimDataAddrOffset++;										        
	*(SimulationDataSaveAddr + SimDataAddrOffset) = MissileAngleRate[1][0];
	SimDataAddrOffset++;
	*(SimulationDataSaveAddr + SimDataAddrOffset) = MissileAngleRate[2][0];
	SimDataAddrOffset++;	
	
	*(SimulationDataSaveAddr + SimDataAddrOffset) = FcsPos[0][0];
	SimDataAddrOffset++;
	*(SimulationDataSaveAddr + SimDataAddrOffset) = FcsPos[1][0];
	SimDataAddrOffset++;
	*(SimulationDataSaveAddr + SimDataAddrOffset) = FcsPos[2][0];
	SimDataAddrOffset++;
	*(SimulationDataSaveAddr + SimDataAddrOffset) = FcsVel[0][0];
	SimDataAddrOffset++;								        
	*(SimulationDataSaveAddr + SimDataAddrOffset) = FcsVel[1][0];
	SimDataAddrOffset++;								        
	*(SimulationDataSaveAddr + SimDataAddrOffset) = FcsVel[2][0];
	SimDataAddrOffset++;
	*(SimulationDataSaveAddr + SimDataAddrOffset) = FcsQtn[0][0];
	SimDataAddrOffset++;								        
	*(SimulationDataSaveAddr + SimDataAddrOffset) = FcsQtn[1][0];
	SimDataAddrOffset++;								        
	*(SimulationDataSaveAddr + SimDataAddrOffset) = FcsQtn[2][0];
	SimDataAddrOffset++;
	*(SimulationDataSaveAddr + SimDataAddrOffset) = FcsQtn[3][0];
	SimDataAddrOffset++;
}

//�ػ��켣���ݴ����ļ�  
void CraftDataWriteToFile(void)
{
	cmd.DataSaveFlag == 0;

	CraftDataFileHandle=fopen(CRAFT_DATA_FILE_PATH,"wb");

	fprintf(CraftDataFileHandle,"%s 	%s  	%s 	  %s	   %s 	%s  	%s  	%s   ",
			"ϵͳʱ��","�켣ʱ��","����","γ��","�߶�","�����ٶ�","�����ٶ�","�����ٶ�");

	fprintf(CraftDataFileHandle,"%s	%s	%s	%s	%s	%s	",
			"������ٶ�", "������ٶ�", "������ٶ�", "�����","������","��ת��");

	fprintf(CraftDataFileHandle,"%s	%s	%s	%s	%s 	%s	%s	%s	%s	 ",
			"������ٶ�", "�������ٶ�", "��ת���ٶ�",
			"����Ӽ�����X","����Ӽ�����Y", "����Ӽ�����Z","������������X","������������Y", "������������Z");

	fprintf(CraftDataFileHandle,"%s	%s	%s	%s	%s	%s	",
			"���ߵ��Ӽ����X","���ߵ��Ӽ����Y", "���ߵ��Ӽ����Z","���ߵ��������X","���ߵ��������Y", "���ߵ��������Z"); 

	fprintf(CraftDataFileHandle,"%s	%s	%s	%s	%s	%s	",
			"���ߵ��Ӽ����������X","���ߵ��Ӽ����������Y","���ߵ��Ӽ����������Z",
			"���ߵ��������������X","���ߵ��������������Y","���ߵ��������������Z");

	fprintf(CraftDataFileHandle,"%s   %s	%s	%s	%s	%s	%s	%s	%s	%s	",
			"���ߵ���Ч��־","���ߵ�����","���ߵ�γ��","���ߵ��߶�","���ߵ������ٶ�","���ߵ������ٶ�","���ߵ������ٶ�",
			"���ߵ�ƫ����","���ߵ�������","���ߵ���ת��" );

	fprintf(CraftDataFileHandle,"%s      %s      %s      %s      %s      %s      %s     %s     %s      ",
			"���ߵ����㾭�����","���ߵ�����γ�����","���ߵ�����߶����",
			"���ߵ����㶫���ٶ����","���ߵ����㱱���ٶ����","���ߵ����������ٶ����",
			"���ߵ�����ƫ�������","���ߵ����㸩�������","���ߵ������ת�����");

	fprintf(CraftDataFileHandle,"%s   %s	%s	%s	%s	%s	%s	%s	%s	%s	%s	%s	%s	%s	%s	%s	%s   ",
			"�����Ч��־","���λ��X","���λ��Y","���λ��Z","��ر����ٶ�", "��������ٶ�", "��ض����ٶ�", 
			"�����̬��ת��", "�����̬ƫ����", "�����̬������",
			"�����Ԫ��0","�����Ԫ��1","�����Ԫ��2","�����Ԫ��3","�������X","�������Y","�������Z" );

	fprintf(CraftDataFileHandle,"%s      %s      %s      %s      %s      %s      %s     %s     %s     ",
			"84ϵX��λ��","84ϵY��λ��","84ϵZ��λ��","84ϵX���ٶ�","84ϵY���ٶ�","84ϵZ���ٶ�",
			"84ϵX����ٶ�","84ϵY����ٶ�","84ϵZ����ٶ�");

	fprintf(CraftDataFileHandle,"%s      %s      %s      %s      %s      %s     ",
			"��ת̨���͵��ڿ�Ƕ�", "��ת̨���͵��п�Ƕ�", "��ת̨���͵����Ƕ�", 
			"��ת̨���͵��ڿ���ٶ�", "��ת̨���͵��п���ٶ�", "��ת̨���͵������ٶ�");	

	fprintf(CraftDataFileHandle,"%s      %s      %s      %s      %s      %s     ",
			"ת̨�ڿ�ض��Ƕ�", "ת̨�п�ض��Ƕ�", "ת̨���ض��Ƕ�", 
			"ת̨�ڿ�ض����ٶ�", "ת̨�п�ض����ٶ�", "ת̨���ض����ٶ�");	

	fprintf(CraftDataFileHandle,"%s      %s      %s      %s      %s      %s     ",
			"��������1", "��������2", "��������3", 
			"��������4", "��������5", "��������6");	

	fprintf(CraftDataFileHandle, "\r\n");

	for(int i = 0; i < SimDataAddrOffset; i++ )
	{
		if(i % 98 == 0)
		{  
			fprintf(CraftDataFileHandle,"\r\n"); 
			fprintf(CraftDataFileHandle,"%lf  ", *(SimulationDataSaveAddr + i));
		}
		else
		{
			fprintf(CraftDataFileHandle,"%lf  ", *(SimulationDataSaveAddr + i)); 	
		}
	}
	fclose(CraftDataFileHandle);	

}

//�����켣���ݴ����ļ�
void MissileDataWriteToFile(void)

{
	MissileDataFileHandle=fopen(MISSILE_DATA_FILE_PATH,"wb");
	
	fprintf(MissileDataFileHandle,"%s	%s 	%s	%s	%s	%s	%s	",
		"�켣ʱ��","����","γ��","�߶�","�����ٶ�","�����ٶ�","�����ٶ�");
	
	fprintf(MissileDataFileHandle,"  %s	  %s	  %s	  %s	  %s 	%s	",
		"������ٶ�", "������ٶ�", "������ٶ�", "�����","������","��ת��");
	
	fprintf(MissileDataFileHandle,"%s	%s	%s	%s	%s 	%s	%s	%s	%s	",
		"������ٶ�", "�������ٶ�", "��ת���ٶ�","�Ӽ�����X","�Ӽ�����Y", "�Ӽ�����Z","��������X","��������Y", "��������Z");
	
	/*
	fprintf(CraftDataFileHandle,"%s	%s	%s	%s	%s	%s	",
		"�Ӽ����X","�Ӽ����Y", "�Ӽ����Z","�������X","�������Y", "�������Z"); 
	
	fprintf(CraftDataFileHandle,"%s	%s	%s	%s	%s	%s	",
		"�Ӽ����������X","�Ӽ����������Y","�Ӽ����������Z","�������������X","�������������Y","�������������Z");

	fprintf(CraftDataFileHandle,"%s   %s	%s	%s	%s	%s	%s	%s	%s	%s	",
		"���ߵ���Ч��־","���ߵ�����","���ߵ�γ��","���ߵ��߶�","���ߵ������ٶ�","���ߵ������ٶ�","���ߵ������ٶ�",
		"���ߵ�ƫ����","���ߵ�������","���ߵ���ת��" );
*/ 	
	fprintf(MissileDataFileHandle,"%s	%s	%s	%s	%s	%s	%s	%s	%s	%s	",
		"���λ��X","���λ��Y","���λ��Z","����ٶ�X","����ٶ�Y","����ٶ�Z",
		"�����Ԫ��0","�����Ԫ��1","�����Ԫ��2","�����Ԫ��3" );
	   
	fprintf(MissileDataFileHandle, "\r\n");
	
	for(int i = 0; i < SimDataAddrOffset; i++ )
	{
		if(i % 32 == 0)
		{  
			fprintf(MissileDataFileHandle,"\r\n"); 
			fprintf(MissileDataFileHandle,"%lf  ", *(SimulationDataSaveAddr + i));
		}
		else
		{
			fprintf(MissileDataFileHandle,"%lf  ", *(SimulationDataSaveAddr + i)); 	
		}
	}
	fclose(MissileDataFileHandle);
}

//�����ϴ�����
void GetData(void)
{
	switch(cmd.tracemode)
	{
		int result;
		case CRAFT_MODE:
			//���ļ�������λ��
			strcat(HostDataPath, "CraftData.txt");

			result = InetFTPAutoSend (HOST_ADDRESS, HostUserName, HostPassword, CRAFT_DATA_FILE_PATH, 
				            HostDataPath, INET_FTP_FILE_TYPE_BINARY);
			data.status = DATA_FILE_SENT;
			Update();
			printf("File sent result = %d !\n", result);  
			break;
		case DATARD_MODE:
			strcat(HostDataPath, "MissileProData.txt");	
			result = InetFTPAutoSend (HOST_ADDRESS, HostUserName, HostPassword, CRAFT_DATA_FILE_PATH, 
				            		  HostDataPath, INET_FTP_FILE_TYPE_BINARY);
			data.status = DATA_FILE_SENT;
			Update();
			printf("File sent result = %d !\n", result);  
			break;			
		case MISGUI_MODE:
			strcat(HostDataPath, "MissileGuidanceData.txt");	
			result = InetFTPAutoSend (HOST_ADDRESS, HostUserName, HostPassword, MISSILE_DATA_FILE_PATH, 
				            		  HostDataPath, INET_FTP_FILE_TYPE_BINARY);
			data.status = DATA_FILE_SENT;
			Update();
			printf("File sent result = %d !\n", result);  
			break;
		case MISFREE_MODE:
			strcat(HostDataPath, "MissileFreeData.txt");	
			result = InetFTPAutoSend (HOST_ADDRESS, HostUserName, HostPassword, MISSILE_DATA_FILE_PATH, 
				            		  HostDataPath, INET_FTP_FILE_TYPE_BINARY);
			data.status = DATA_FILE_SENT;
			Update();
			printf("File sent result = %d !\n", result);  
			break;			   
	}
}

//�켣��̬ת����ת̨��̬
void TraceToRotary(double TraceAttitude[3][1], double TraceAttitudeRate[3][1], float RotaryAttitude[3][1], float RotaryAttitudeRate[3][1])
{
	//RotaryAttitudeΪת̨���ڿ��п����
	//TraceAttitudeΪ�ػ���ƫ������������ת
	
	RotaryAttitude[2][0] = (float) TraceAttitude[0][0] / DEGREE;
	RotaryAttitude[1][0] = (float) TraceAttitude[1][0] / DEGREE; 
	RotaryAttitude[0][0] = (float) TraceAttitude[2][0] / DEGREE;			
									
	RotaryAttitudeRate[2][0] = (float) TraceAttitudeRate[0][0] / DEGREE; 
	RotaryAttitudeRate[1][0] = (float) TraceAttitudeRate[1][0] / DEGREE; 
	RotaryAttitudeRate[0][0] = (float) TraceAttitudeRate[2][0] / DEGREE; 	
	
	
	/******�߲�������ת����******/ 	
/*	if(RotaryAttitude[2][0] >= 0)
		RotaryAttitude[2][0] =  360 - RotaryAttitude[2][0];
	else
		RotaryAttitude[2][0] =  - RotaryAttitude[2][0]; 		
		
	RotaryAttitude[1][0] =  RotaryAttitude[1][0];     		
	
	RotaryAttitude[0][0] =  RotaryAttitude[0][0];
*/	/****************************/
	
	
	/******�ɿ�������ת����******/
	//1.�������������ֵ ����д��� ��������ת����ж�
	//2.������ת̨Ϊ��ֵ ת̨��360�������� �Ҹ��ظ���ֵ ���Ը���ת̨Ӧ��Ϊ��ֵ ������ض����ݱȽ�
	
	//��ת
	RotaryAttitude[0][0] =  RotaryAttitude[0][0] + 90;	
	
	//ƫ��
	if(RotaryAttitude[2][0] >= 0)
		RotaryAttitude[2][0] =  360 - RotaryAttitude[2][0];
	else
		RotaryAttitude[2][0] =  - RotaryAttitude[2][0]; 	//�������븺�ĺ���ǣ�ת̨���յ����ĺ���ǣ�ת̨����ת
	/****************************/ 							//ת̨��������ָ����ģ�ת̨����Ǳ�ƫ��Ϊ����
  
	
	RotaryAttitudeRate[2][0] = - RotaryAttitudeRate[2][0] ; 
}

//����ת̨��̬ҡ��
void RotaryTabShake(float RotaryAttWithoutshake[3][1], float RotaryRateWithoutshake[3][1],
	                float RotaryAttWithshake[3], float RotaryRateWithshake[3],
					double AmpleShake[3], double FrequenceShake[3], double PhaseShake[3],
					double Time_Shake)
{
	if(flag_Shake_in)
	{
		RotaryAttWithshake[0] = AmpleShake[0] * sin(2 * pi * FrequenceShake[0] * Time_Shake + PhaseShake[0]) +
								   RotaryAttWithoutshake[0][0]; 	
		RotaryRateWithshake[0] = AmpleShake[0] * (2 * pi * FrequenceShake[0]) * 
									cos(2 * pi * FrequenceShake[0] * Time_Shake + PhaseShake[0]) + RotaryRateWithoutshake[0][0]; 		
	}
	else
	{
		RotaryAttWithshake[0] = RotaryAttWithoutshake[0][0];
		RotaryRateWithshake[0] = RotaryRateWithoutshake[0][0];
	}
	
	if(flag_Shake_mid)
	{
		RotaryAttWithshake[1] = AmpleShake[1] * sin(2 * pi * FrequenceShake[1] * Time_Shake + PhaseShake[1]) +
								   RotaryAttWithoutshake[1][0]; 		
		RotaryRateWithshake[1] = AmpleShake[1] * (2 * pi * FrequenceShake[1]) * 
									cos(2 * pi * FrequenceShake[1] * Time_Shake + PhaseShake[1]) + RotaryRateWithoutshake[1][0]; 	
	}
	else
	{
		RotaryAttWithshake[1] = RotaryAttWithoutshake[1][0]; 
		RotaryRateWithshake[1] = RotaryRateWithoutshake[1][0];
	}
	
	if(flag_Shake_out)
	{
		RotaryAttWithshake[2] = AmpleShake[2] * sin(2 * pi * FrequenceShake[2] * Time_Shake + PhaseShake[2]) +
								   RotaryAttWithoutshake[2][0];
		RotaryRateWithshake[2] = AmpleShake[2] * (2 * pi * FrequenceShake[2]) * 
									cos(2 * pi * FrequenceShake[2] * Time_Shake + PhaseShake[2]) + RotaryRateWithoutshake[2][0];	
	}
	else
	{
		RotaryAttWithshake[2] = RotaryAttWithoutshake[2][0]; 
		RotaryRateWithshake[2] = RotaryRateWithoutshake[2][0];
	}
}

//���422ͨ���߳�   /*   ����Э���д δ����ʹ��   */
static int CVICALLBACK ThreadFunctionDuoJi422(void *functionData)
{
	int i, j;
	
	unsigned int byteLen = 0;
	
	unsigned char byteRead[9];
	unsigned char byteSend[9]; 
	
	
	// R1
	while (DuoJi_Flag == 1)
    {
		byteLen = GetInQLen (DUOJI422Handle.comValue);

		if(byteLen >= 9 * 3)
		{
			for (i = 0; i < 9; i ++)
			{
				byteRead[i] = ComRdByte(DUOJI422Handle.comValue);	
			}
			
			// T1
			if(byteRead[1] == 0x81)
			{
				for (j = 0; j < 3; j ++)
				{
					byteSend[0] = 0x75;
					byteSend[1] = 0x81;
					byteSend[2] = 0xa0;
					for (i = 3; i < 7; i ++)
						byteSend[i] = 0x00;
					byteSend[7] = (0x70 + 0x10 * j);
					byteSend[8] = XorByte(byteSend);
					
					for (i = 0; i < 9; i ++)
						ComWrtByte (DUOJI422Handle.comValue, byteSend[i]);
					printf("1T\n");
				}
				break;
			}
		}
		SleepUS (100);  
    }
	
	// R2
	while (DuoJi_Flag == 1)
    {
		byteLen = GetInQLen (DUOJI422Handle.comValue);

		if(byteLen >= 9 * 3)
		{
			for (i = 0; i < 9; i ++)
			{
				byteRead[i] = ComRdByte(DUOJI422Handle.comValue);	
			}
			
			// T2
			if(byteRead[1] == 0x82)
			{
				for (j = 0; j < 3; j ++)
				{
					byteSend[0] = 0x75;
					byteSend[1] = 0x82;
					byteSend[2] = 0x0a;
					for (i = 3; i < 7; i ++)
						byteSend[i] = 0x00;
					byteSend[7] = (0x70 + 0x10 * j);
					byteSend[8] = XorByte(byteSend);
					
					for (i = 0; i < 9; i ++)
						ComWrtByte (DUOJI422Handle.comValue, byteSend[i]);
					printf("2T\n");
				}
				break;
			}
		}
		SleepUS (100);  
    }
	
	// R3
	while (DuoJi_Flag == 1)
    {
		byteLen = GetInQLen (DUOJI422Handle.comValue);

		if(byteLen >= 9 * 3)
		{
			for (i = 0; i < 9; i ++)
			{
				byteRead[i] = ComRdByte(DUOJI422Handle.comValue);	
			}
			
			// T3
			if(byteRead[1] == 0x83)
			{
				for (j = 0; j < 3; j ++)
				{
					byteSend[0] = 0x75;
					byteSend[1] = 0x83;
					byteSend[2] = 0x00;
					byteSend[3] = 0xaa;
					for (i = 4; i < 7; i ++)
						byteSend[i] = 0x00;
					byteSend[7] = (0x70 + 0x10 * j);
					byteSend[8] = XorByte(byteSend);
					
					for (i = 0; i < 9; i ++)
						ComWrtByte (DUOJI422Handle.comValue, byteSend[i]);
					printf("3T\n");
				}
				break;
			}
		}
		SleepUS (100);  
    }
	
	// R4
	while (DuoJi_Flag == 1)
    {
		byteLen = GetInQLen (DUOJI422Handle.comValue);

		if(byteLen >= 9)
		{
			for (i = 0; i < 9; i ++)
			{
				byteRead[i] = ComRdByte(DUOJI422Handle.comValue);	
			}
			
			// T4
			if(byteRead[1] == 0x84 * 3)
			{
				for (j = 0; j < 3; j ++)
				{
					byteSend[0] = 0x75;
					byteSend[1] = 0x84;
					byteSend[2] = 0x00;
					for (i = 3; i < 7; i ++)
						byteSend[i] = 0x00;
					byteSend[7] = (0x70 + 0x10 * j);
					byteSend[8] = XorByte(byteSend);
					
					for (i = 0; i < 9; i ++)
						ComWrtByte (DUOJI422Handle.comValue, byteSend[i]);
					printf("4T\n");
				}
			}
		}
		SleepUS (100);  
    }

    return 0;
}
	
