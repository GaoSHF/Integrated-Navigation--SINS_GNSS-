#include <ansi_c.h>
#include <utility.h>
#include <nidcpower.h>
#include "acc_simu.h"


// X axis, PXIe-4141
DC_PARAM DC0 = {
	VI_NULL,
	"PXI2Slot4",				// resourceName
	"0",						// channelName
	0.000e-3,					// currentLevel A
	2,							// voltageLimit V
	0.2,						// currentLevelRange A
	20,							// voltageLimitRange V
	1009,						// sense
	0,							// channelCount
	0.00000E+0,					// measuredVoltage V
	0.00000E+0,					// measuredCurrent A
	0,							// inCompliance
	0.01000E-3					// sourceDelay
};

// Y axis, PXI-4130
DC_PARAM DC1 = {
	VI_NULL,
	"PXI2Slot3",				// resourceName
	"1",						// channelName
	0.004e-3,					// currentLevel A
	2,							// voltageLimit V
	0.2,						// currentLevelRange A
	6,							// voltageLimitRange V
	1009,						// sense
	0,							// channelCount
	0.00000E+0,					// measuredVoltage V
	0.00000E+0,					// measuredCurrent A
	0,							// inCompliance
	0.01000E-3					// sourceDelay
};

// Z axis, PXI-4130
DC_PARAM DC2 = {
	VI_NULL,
	"PXI2Slot2",				// resourceName
	"1",						// channelName
	0.004e-3,					// currentLevel A
	2,							// voltageLimit V
	0.2,						// currentLevelRange A
	6,							// voltageLimitRange V
	1009,						// sense
	0,							// channelCount
	0.00000E+0,					// measuredVoltage V
	0.00000E+0,					// measuredCurrent A
	0,							// inCompliance
	0.01000E-3					// sourceDelay
};


//Initiate DC
int accsimuInit (DC_PARAM *dcx)
{
	
	ViChar resourceName[RESOURCE_NAME_LENGTH];
	ViChar channelName[CHANNEL_NAME_LENGTH];
   	ViReal64 currentLevel; 
	ViReal64 voltageLimit; 
	ViReal64 currentLevelRange;
	ViReal64 voltageLimitRange;
   	ViInt32 sense;
   	ViInt32 channelCount;
	ViReal64 sourceDelay;
   	
	
	int i;
	
	ViStatus error = VI_SUCCESS;
	
	if (dcx->SessionVI == VI_NULL) {
		
		for (i = 0; i < RESOURCE_NAME_LENGTH; i ++)
			resourceName[i] = dcx->resourceName[i];	
		
		for (i = 0; i < CHANNEL_NAME_LENGTH; i ++)
			channelName[i] = dcx->channelName[i];
		
		currentLevel = dcx->currentLevel;
		
		voltageLimit = dcx->voltageLimit;
		
		currentLevelRange = dcx->currentLevelRange;
		
		voltageLimitRange = dcx->voltageLimitRange;
		
		sense = dcx->sense;
		
		channelCount = dcx->channelCount;
		
		sourceDelay = dcx->sourceDelay;
		
		
		/* Initialize a session to the device. */
        checkWarn(niDCPower_InitializeWithChannels(resourceName, channelName, VI_FALSE, VI_NULL, &(dcx->SessionVI)));

        /* Configure the Source mode to Single Point. */
        checkWarn(niDCPower_ConfigureSourceMode(dcx->SessionVI, NIDCPOWER_VAL_SINGLE_POINT));

		/* Set the Output Function to DC Current.  If you change the Output
            Function to DC Voltage, you must use Voltage Level and Current Limit
            instead of Current Level and Voltage Limit. */
		checkWarn(niDCPower_ConfigureOutputFunction(dcx->SessionVI, channelName, NIDCPOWER_VAL_DC_CURRENT));

		/* Configure Remote Sense (It can only be set to Remote on specific
            channels of specific hardware.  Refer to the documentation for more
            information). */
		checkWarn(niDCPower_ConfigureSense(dcx->SessionVI, channelName, sense));
		 
		
		 
		// Current level range
		//checkWarn(niDCPower_SetAttributeViReal64(dcx->SessionVI, channelName, NIDCPOWER_ATTR_CURRENT_LEVEL_RANGE, currentLevelRange));
		
		// Voltage limit range
		//checkWarn(niDCPower_SetAttributeViReal64(dcx->SessionVI, channelName, NIDCPOWER_ATTR_VOLTAGE_LIMIT_RANGE, voltageLimitRange));
		
		
		// Current level autorange
		checkWarn(niDCPower_SetAttributeViInt32(dcx->SessionVI, channelName, NIDCPOWER_ATTR_CURRENT_LEVEL_AUTORANGE, 1));
		 
		// Voltage limit autorange
		checkWarn(niDCPower_SetAttributeViInt32(dcx->SessionVI, channelName, NIDCPOWER_ATTR_VOLTAGE_LIMIT_AUTORANGE, 1));
		
		
		// Current level
		checkWarn(niDCPower_SetAttributeViReal64(dcx->SessionVI, channelName, NIDCPOWER_ATTR_CURRENT_LEVEL, currentLevel));
		 
		// Voltage limit
		checkWarn(niDCPower_SetAttributeViReal64(dcx->SessionVI, channelName, NIDCPOWER_ATTR_VOLTAGE_LIMIT, voltageLimit));
		 
		// Source delay
		checkWarn(niDCPower_SetAttributeViReal64(dcx->SessionVI, channelName, NIDCPOWER_ATTR_SOURCE_DELAY, sourceDelay));
		 
        /* Initiate the device to start generation and acquisition. */
        checkWarn(niDCPower_Initiate(dcx->SessionVI));
     
		printf("Initiate DC power successfully!\n");

		 
	}

Error:
	
	//niDCPower_GetAttributeViReal64(dcx->SessionVI, channelName, NIDCPOWER_ATTR_VOLTAGE_LIMIT_RANGE, &voltageLimitRange);
	//printf("%lf\n", voltageLimitRange);
	
	return 0;
}


//Measure DC
int accsimuMeasure (DC_PARAM *dcx)
{
	ViSession SessionVI = dcx->SessionVI;
	
	ViChar channelName[CHANNEL_NAME_LENGTH];
	ViReal64 measuredVoltage;
	ViReal64 measuredCurrent;
   	ViBoolean inCompliance;
   	ViReal64 sourceDelay;
	
	int i;
	
	ViStatus error = VI_SUCCESS;
	
	for (i = 0; i < CHANNEL_NAME_LENGTH; i ++)
		channelName[i] = dcx->channelName[i];
	
	sourceDelay = dcx->sourceDelay;
	
	/* Wait for the output to settle. */
	Delay(sourceDelay);
         
	/* Measure current and voltage. */
	checkWarn(niDCPower_MeasureMultiple(SessionVI, channelName, &measuredVoltage, &measuredCurrent));

	/* Determine if the output is in compliance. */
	checkWarn(niDCPower_QueryInCompliance(SessionVI, channelName, &inCompliance));
	
	dcx->measuredVoltage = measuredVoltage;
	
	dcx->measuredCurrent = measuredCurrent;
	
	dcx->inCompliance = inCompliance;
	
Error:
	return 0;	
}


//Disable DC
int accsimuDisable (DC_PARAM *dcx)
{
	int i;
	
	ViSession SessionVI;
	ViChar channelName[CHANNEL_NAME_LENGTH]; 
	
	ViStatus error = VI_SUCCESS;
	
	SessionVI = dcx->SessionVI;
	for (i = 0; i < CHANNEL_NAME_LENGTH; i ++)
		channelName[i] = dcx->channelName[i];
	
	if (SessionVI != VI_NULL) 
	{
		/* Disable the output. */
	    niDCPower_ConfigureOutputEnabled( SessionVI, channelName, VI_FALSE); 
	}

	
Error:
	return 0;
}


//Enable DC
int accsimuEnable (DC_PARAM *dcx)
{
	int i; 
	
	ViSession SessionVI;
	ViChar channelName[CHANNEL_NAME_LENGTH]; 

	ViStatus error = VI_SUCCESS;
	
	SessionVI = dcx->SessionVI;

	for (i = 0; i < CHANNEL_NAME_LENGTH; i ++)
		channelName[i] = dcx->channelName[i];
	
	if (SessionVI != VI_NULL) 
	{
		/* Enable the output. */
		niDCPower_ConfigureOutputEnabled( SessionVI, channelName, VI_TRUE);
}

	
Error:
	return 0;
}


//Set DC current
int accsimuSet4141 (DC_PARAM dcx)
{

	int i;
	
	ViSession SessionVI = dcx.SessionVI;
	
	ViChar channelName[CHANNEL_NAME_LENGTH];
	ViReal64 currentLevel; 
	
	currentLevel = dcx.currentLevel;
	
	for (i = 0; i < CHANNEL_NAME_LENGTH; i ++)
		channelName[i] = dcx.channelName[i];
	
	
	//niDCPower_SetAttributeViReal64(SessionVI, channelName, NIDCPOWER_ATTR_CURRENT_LEVEL, currentLevel);
	niDCPower_ConfigureCurrentLevel(SessionVI, channelName, currentLevel);
	
	return 0;
}
 

//Set DC current
int accsimuSet4130 (DC_PARAM dcx)
{

	int i;
	
	ViSession SessionVI = dcx.SessionVI;
	
	ViChar channelName[CHANNEL_NAME_LENGTH];
	ViReal64 currentLevel; 
	
	currentLevel = dcx.currentLevel;
	
	for (i = 0; i < CHANNEL_NAME_LENGTH; i ++)
		channelName[i] = dcx.channelName[i];
	
	
	// Cannot < 4uA for PXI-4130
	if ((currentLevel > -0.004e-3) && (currentLevel < 0.004e-3))
		currentLevel = (currentLevel > 0) ? 0.004e-3 : -0.004e-3;
	
	
	//niDCPower_SetAttributeViReal64(SessionVI, channelName, NIDCPOWER_ATTR_CURRENT_LEVEL, currentLevel);
	niDCPower_ConfigureCurrentLevel(SessionVI, channelName, currentLevel);
	
	return 0;
}


//Close VI session
int accsimuClose (DC_PARAM *dcx)
{
	
	ViStatus error = VI_SUCCESS;

	
	dcx->currentLevel = 0.004e-3; //uA
	dcx->voltageLimit = 2; // 2V
	
	if (dcx->SessionVI != VI_NULL) {
		
		error = niDCPower_close (dcx->SessionVI);

	}

	dcx->SessionVI = VI_NULL;

	if(error < VI_SUCCESS) {
		return 1;
	}

	return 0;
}


//Reset VI session
int accsimuReset (DC_PARAM *dcx)
{
	ViSession SessionVI;
	
	ViStatus error = VI_SUCCESS;
	
	SessionVI = dcx->SessionVI;

	if (SessionVI != VI_NULL) {
		error = niDCPower_reset (SessionVI);
	}

	if(error < VI_SUCCESS) {
		return 1;
	}

	return 0;
}

