//==============================================================================
//
// Title:       rfm.c
// Purpose:     A short description of the implementation.
//
// Created on:  2013/12/16 at 10:06:34 by ZhangZhiyi.
// Copyright:   Beihang University. All Rights Reserved.
//
//==============================================================================

//==============================================================================
// Include files

#include <utility.h>
#include <ansi_c.h>

#include "common.h"

double 
