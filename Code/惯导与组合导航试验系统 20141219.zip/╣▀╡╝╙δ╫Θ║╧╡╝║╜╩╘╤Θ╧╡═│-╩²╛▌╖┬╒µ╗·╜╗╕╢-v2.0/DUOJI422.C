#include <ansi_c.h>
#include <rtutil.h>

#include"RS422.h"
#include"DuoJi422.h"  

void DUOJI422OpenConfig(void)
{
	DUOJI422Handle.bps = DUOJI_SERIAL_BPS;
	DUOJI422Handle.comValue = COM5;
	DUOJI422Handle.check = NOPARITY;
	DUOJI422Handle.data = 8; 
	DUOJI422Handle.stop = 1;

	if(!RS422_OpenConfig(DUOJI422Handle))
	{
	    RS422_Close(DUOJI422Handle);
	}
}


unsigned int XorByte(unsigned char byte[18])
{			 
	int i;
	
	unsigned int result;
	
	result = byte[1];
	for (i = 2; i < 8; i ++)
	{
		result = result ^ byte[i];
	}
	
	return result;
}
