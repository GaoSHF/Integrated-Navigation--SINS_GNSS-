//==============================================================================
//
// Title:       pci_io_cvi.c
// Purpose:     A short description of the implementation.
//
// Created on:  2013-3-2 at 15:35:24 by Cindy.
// Copyright:   BUAA. All Rights Reserved.
//
//==============================================================================

//==============================================================================
// Include files
#include <tcpsupp.h>
#include <userint.h>
#include <visa.h>
#include <ansi_c.h> //  For printf, malloc

#include "host_main.h"
#include "common.h"

//==============================================================================
// Constants, set for PCI board instead of pxi board
#define TAB_INDEX_DIGIT_OUT		0
#define TAB_INDEX_DIGIT_IN		1
#define TAB_INDEX_RAM			2
#define TAB_INDEX_LED			3
#define TAB_INDEX_OP			4

//==============================================================================
// Types

//==============================================================================
// Static global variables
static int HandlePanel;
static int HandleTab;

//==============================================================================
// Static functions
ViStatus _VI_FUNCH Interrupt(ViSession vi , ViEventType eventType ,ViEvent ctx ,ViAddr userHdlr);

//==============================================================================
// Global variables

int FlagInterrupt = 0;





ViPEventType OutEventType;
ViPEvent OutContext;
ViStatus Status;


static unsigned int	StatusTCP = TCP_INVALID_CONNECTION;


static int HandlePanel;

CommandMessage Cmd;

//==============================================================================
// Global functions
int CVICALLBACK TCPDataCallback (unsigned handle, int xType, int errCode, void *callbackData);




int Init(){
	// **************** Main panel ****************
	// Numeric data type
	SetCtrlAttribute(HandlePanel, PANEL_MANF_ID, ATTR_FORMAT, VAL_HEX_FORMAT);
	SetCtrlAttribute(HandlePanel, PANEL_MODEL_CODE, ATTR_FORMAT, VAL_HEX_FORMAT);
	
	// Numeric default data value
	SetCtrlAttribute(HandlePanel, PANEL_MANF_ID, ATTR_DFLT_VALUE, 0x0000);
	SetCtrlAttribute(HandlePanel, PANEL_MODEL_CODE, ATTR_DFLT_VALUE, 0x0000);
	
	
	// **************** Tab digit out ****************
	// Creat tab page handle
	GetPanelHandleFromTabPage(HandlePanel, PANEL_TAB, TAB_INDEX_DIGIT_OUT, &HandleTab);
	
	// Set numeric data type
	SetCtrlAttribute(HandleTab, TAB_OUT_NUMERIC_O5, ATTR_DATA_TYPE, VAL_UNSIGNED_INTEGER);
	SetCtrlAttribute(HandleTab, TAB_OUT_NUMERIC_O27, ATTR_DATA_TYPE, VAL_UNSIGNED_INTEGER);
	SetCtrlAttribute(HandleTab, TAB_OUT_NUMERIC_OC5, ATTR_DATA_TYPE, VAL_UNSIGNED_INTEGER);
	
	// Set numeric maximum value
	SetCtrlAttribute(HandleTab, TAB_OUT_NUMERIC_O5, ATTR_MAX_VALUE, 255);// 8 bits
	SetCtrlAttribute(HandleTab, TAB_OUT_NUMERIC_O27, ATTR_MAX_VALUE, 255);
	SetCtrlAttribute(HandleTab, TAB_OUT_NUMERIC_OC5, ATTR_MAX_VALUE, 255);
	
	// Set numeric display format
	SetCtrlAttribute(HandleTab, TAB_OUT_NUMERIC_O5, ATTR_FORMAT, VAL_BINARY_FORMAT);
	SetCtrlAttribute(HandleTab, TAB_OUT_NUMERIC_O27, ATTR_FORMAT, VAL_BINARY_FORMAT);
	SetCtrlAttribute(HandleTab, TAB_OUT_NUMERIC_OC5, ATTR_FORMAT, VAL_BINARY_FORMAT);
	
	// Set numeric range check
	SetCtrlAttribute(HandleTab, TAB_OUT_NUMERIC_O5, ATTR_CHECK_RANGE, VAL_COERCE);
	SetCtrlAttribute(HandleTab, TAB_OUT_NUMERIC_O27, ATTR_CHECK_RANGE, VAL_COERCE);
	SetCtrlAttribute(HandleTab, TAB_OUT_NUMERIC_OC5, ATTR_CHECK_RANGE, VAL_COERCE);
	
	
	// **************** Tab digit in ****************
	// Creat tab page handle
	GetPanelHandleFromTabPage(HandlePanel, PANEL_TAB, TAB_INDEX_DIGIT_IN, &HandleTab);
	
	// Set numeric data type
	SetCtrlAttribute(HandleTab, TAB_IN_NUMERIC_I5, ATTR_DATA_TYPE, VAL_UNSIGNED_INTEGER);
	SetCtrlAttribute(HandleTab, TAB_IN_NUMERIC_I27, ATTR_DATA_TYPE, VAL_UNSIGNED_INTEGER);
	
	// Set numeric maximum value
	SetCtrlAttribute(HandleTab, TAB_IN_NUMERIC_I5, ATTR_MAX_VALUE, 65535);// 16 bits
	SetCtrlAttribute(HandleTab, TAB_IN_NUMERIC_I27, ATTR_MAX_VALUE, 255);// 8 bits    
	
	// Set numeric display format
	SetCtrlAttribute(HandleTab, TAB_IN_NUMERIC_I5, ATTR_FORMAT, VAL_BINARY_FORMAT);
	SetCtrlAttribute(HandleTab, TAB_IN_NUMERIC_I27, ATTR_FORMAT, VAL_BINARY_FORMAT);
	
	// Set numeric range check
	SetCtrlAttribute(HandleTab, TAB_IN_NUMERIC_I5, ATTR_CHECK_RANGE, VAL_COERCE);
	SetCtrlAttribute(HandleTab, TAB_IN_NUMERIC_I27, ATTR_CHECK_RANGE, VAL_COERCE);
	
	
	// **************** Tab RAM ****************
	// Creat tab page handle
	GetPanelHandleFromTabPage(HandlePanel, PANEL_TAB, TAB_INDEX_RAM, &HandleTab);
	
	// Set numeric data type
	SetCtrlAttribute(HandleTab, TAB_RAM_NUMERIC_RAM_I_BEFORE, ATTR_DATA_TYPE, VAL_UNSIGNED_INTEGER);
	SetCtrlAttribute(HandleTab, TAB_RAM_NUMERIC_RAM_O, ATTR_DATA_TYPE, VAL_UNSIGNED_INTEGER);
	SetCtrlAttribute(HandleTab, TAB_RAM_NUMERIC_RAM_I_AFTER, ATTR_DATA_TYPE, VAL_UNSIGNED_INTEGER);
	
	// Set numeric maximum value
	SetCtrlAttribute(HandleTab, TAB_RAM_NUMERIC_RAM_I_BEFORE, ATTR_MAX_VALUE, 65535);
	SetCtrlAttribute(HandleTab, TAB_RAM_NUMERIC_RAM_O, ATTR_MAX_VALUE, 65535);// 16 bits
	SetCtrlAttribute(HandleTab, TAB_RAM_NUMERIC_RAM_I_AFTER, ATTR_MAX_VALUE, 65535);    
	
	// Set numeric display format
	SetCtrlAttribute(HandleTab, TAB_RAM_NUMERIC_RAM_I_BEFORE, ATTR_FORMAT, VAL_BINARY_FORMAT);
	SetCtrlAttribute(HandleTab, TAB_RAM_NUMERIC_RAM_O, ATTR_FORMAT, VAL_BINARY_FORMAT);
	SetCtrlAttribute(HandleTab, TAB_RAM_NUMERIC_RAM_I_AFTER, ATTR_FORMAT, VAL_BINARY_FORMAT);
	
	// Set numeric range check
	SetCtrlAttribute(HandleTab, TAB_RAM_NUMERIC_RAM_I_BEFORE, ATTR_CHECK_RANGE, VAL_COERCE);
	SetCtrlAttribute(HandleTab, TAB_RAM_NUMERIC_RAM_O, ATTR_CHECK_RANGE, VAL_COERCE);
	SetCtrlAttribute(HandleTab, TAB_RAM_NUMERIC_RAM_I_AFTER, ATTR_CHECK_RANGE, VAL_COERCE);
	
	return 0;
}


/* 
 * main entry
 */
int main(int argc, char *argv[])
{
	if (InitCVIRTE(0, argv, 0) == 0) // out of memory
		return -1;
	
	// Panel handle
	if ((HandlePanel = LoadPanel(0, "host_main.uir", PANEL)) < 0)
		return -1;

	DisplayPanel(HandlePanel);
	
	Init();
	
	// Create a TCP server to communicate with RT target.
    RegisterTCPServer (HOST_PORT, TCPDataCallback, 0);

	SetCtrlVal (HandlePanel, PANEL_STATUS, "Waiting for connection.");
	
	
	
	RunUserInterface();
	
	
	
	// Cleanup
	UnregisterTCPServer(HOST_PORT);
	
	DiscardPanel(HandlePanel);
	
	return 0;
}




/*
	TCP callback function
 */
int CVICALLBACK TCPDataCallback (unsigned handle, int xType, int errCode, 
	void *callbackData)
{
	switch (xType)
    {
        case TCP_CONNECT:
            // Accept only one client connection
            if (StatusTCP != TCP_INVALID_CONNECTION)
                DisconnectTCPClient (handle);
            else
                StatusTCP = handle;
			SetCtrlVal (HandlePanel, PANEL_STATUS, "Connected.");
            break;
        case TCP_DISCONNECT:
            StatusTCP = TCP_INVALID_CONNECTION;
			SetCtrlVal (HandlePanel, PANEL_STATUS, "Waiting for connection.");
            break;
        case TCP_DATAREADY:
			// ClientTCPRead does not guarantee that all Data will be transferred in
			// a single call, but this code assumes that it does for simplicity.
			ServerTCPRead (StatusTCP, &Cmd, sizeof(Cmd), 5000);
			switch (Cmd.command)
			{
				case IO_COMMAND_INT:
					SetCtrlVal(HandlePanel, PANEL_INTERRUPT, Cmd.value);
					break;
			}

            break;
    }
    
    return 0;
}









// ********************************************************************** Interface callback
/* 
 * Refresh operation follow the timer with some board operation
 */
int CVICALLBACK Refresh(int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	switch(event){
	case  EVENT_TIMER_TICK:
	
		// Refresh IO board found LED and name display
		Cmd.command = IO_COMMAND_FOUND;
		ServerTCPWrite (StatusTCP, &Cmd, sizeof(Cmd), 5000);
		ServerTCPRead (StatusTCP, &Cmd, sizeof(Cmd), 5000);
		
		if(Cmd.value == 1)
		{
			SetCtrlVal(HandlePanel, PANEL_LED, 1);
			
			Cmd.command = IO_COMMAND;
			Cmd.subcmd = SUBCMD_IO_NAME;
			ServerTCPWrite (StatusTCP, &Cmd, sizeof(Cmd), 5000);
			ServerTCPRead (StatusTCP, &Cmd, sizeof(Cmd), 5000);
			SetCtrlVal(HandlePanel, PANEL_IO_BOARD_NAME, Cmd.name); // Display VISA name
			
			Cmd.command = IO_COMMAND;
			Cmd.subcmd = SUBCMD_IO_MANF_ID;
			ServerTCPWrite (StatusTCP, &Cmd, sizeof(Cmd), 5000);
			ServerTCPRead (StatusTCP, &Cmd, sizeof(Cmd), 5000);
			SetCtrlVal(HandlePanel, PANEL_MANF_ID, Cmd.value);
			
			Cmd.command = IO_COMMAND;
			Cmd.subcmd = SUBCMD_IO_MODEL_CODE;
			ServerTCPWrite (StatusTCP, &Cmd, sizeof(Cmd), 5000);
			ServerTCPRead (StatusTCP, &Cmd, sizeof(Cmd), 5000);
			SetCtrlVal(HandlePanel, PANEL_MODEL_CODE, Cmd.value);
			
			
			
			
			
			// **************** Refresh Real operation tab for the project ****************
			
			// Creat tab page handle
			GetPanelHandleFromTabPage(HandlePanel, PANEL_TAB, TAB_INDEX_OP, &HandleTab);
			
			// **************** 27V Relay output ****************
			// ��������
			GetCtrlVal(HandleTab, TAB_OP_RELAY_27_ED, &Cmd.value);
			Cmd.command = IO_COMMAND;
			Cmd.subcmd = SUBCMD_IO_WRITE_ELECTRO_DISCRETE;
			ServerTCPWrite (StatusTCP, &Cmd, sizeof(Cmd), 5000);
			
			
			// ��������
			GetCtrlVal(HandleTab, TAB_OP_RELAY_27_PD, &Cmd.value);
			Cmd.command = IO_COMMAND;
			Cmd.subcmd = SUBCMD_IO_WRITE_PHYSICAL_DISCRETE;
			ServerTCPWrite (StatusTCP, &Cmd, sizeof(Cmd), 5000);
			
			
			// **************** 5V Relay output ****************
			// ��ص�ѹ����
			GetCtrlVal(HandleTab, TAB_OP_RELAY_27_BVN, &Cmd.value);
			Cmd.command = IO_COMMAND;
			Cmd.subcmd = SUBCMD_IO_WRITE_BATTERY_VOLTAGE_NORMAL;
			ServerTCPWrite (StatusTCP, &Cmd, sizeof(Cmd), 5000);
			
			
			// ��ؼ���
			GetCtrlVal(HandleTab, TAB_OP_RELAY_27_BA, &Cmd.value);
			Cmd.command = IO_COMMAND;
			Cmd.subcmd = SUBCMD_IO_WRITE_BATTERY_ACTIVATE;
			ServerTCPWrite (StatusTCP, &Cmd, sizeof(Cmd), 5000);
			
			
			// ����������ȫ 
			GetCtrlVal(HandleTab, TAB_OP_ISOLATION_5_SAFE, &Cmd.value);
			Cmd.command = IO_COMMAND;
			Cmd.subcmd = SUBCMD_IO_WRITE_SECURITY_SYSTEM;
			ServerTCPWrite (StatusTCP, &Cmd, sizeof(Cmd), 5000);
			
			
			// **************** 5V isolation input **************** 
			// K2 
			Cmd.command = IO_COMMAND;
			Cmd.subcmd = SUBCMD_IO_READ_K2;
			ServerTCPWrite (StatusTCP, &Cmd, sizeof(Cmd), 5000);
			ServerTCPRead (StatusTCP, &Cmd, sizeof(Cmd), 5000);
			SetCtrlVal(HandleTab, TAB_OP_ISOLATION_5_K2, Cmd.value);
			if(Cmd.value != 0)
				printf("K2\n");
			
			// ����׼��
			Cmd.command = IO_COMMAND;
			Cmd.subcmd = SUBCMD_IO_READ_MISSILE_PREPARE;
			ServerTCPWrite (StatusTCP, &Cmd, sizeof(Cmd), 5000);
			ServerTCPRead (StatusTCP, &Cmd, sizeof(Cmd), 5000);
			SetCtrlVal(HandleTab, TAB_OP_ISOLATION_5_MP, Cmd.value);
			if(Cmd.value != 0)
				printf("Missile prepare\n");
			
			// ����ͷ�Ӹ�ѹ   
			Cmd.command = IO_COMMAND;
			Cmd.subcmd = SUBCMD_IO_READ_GUIDER_HIGH_PRESSURE;
			ServerTCPWrite (StatusTCP, &Cmd, sizeof(Cmd), 5000);
			ServerTCPRead (StatusTCP, &Cmd, sizeof(Cmd), 5000);
			SetCtrlVal(HandleTab, TAB_OP_ISOLATION_5_GHP, Cmd.value);
			if(Cmd.value != 0)
				printf("Guidence high preasure\n");
			
			
			// �ɿؼ�����Լ�����		
			Cmd.command = IO_COMMAND;
			Cmd.subcmd = SUBCMD_IO_READ_FLIGHT_CONTROL_SELF_TEST_NORMAL;
			ServerTCPWrite (StatusTCP, &Cmd, sizeof(Cmd), 5000);
			ServerTCPRead (StatusTCP, &Cmd, sizeof(Cmd), 5000);
			SetCtrlVal(HandleTab, TAB_OP_ISOLATION_5_FCSTN, Cmd.value);
			if(Cmd.value != 0)
				printf("Self test normal\n");
		}
		
		else
		{
			SetCtrlVal(HandlePanel, PANEL_LED, 0);
			SetCtrlVal(HandlePanel, PANEL_IO_BOARD_NAME, "No I/O board found!"); // Display not found
			SetCtrlVal(HandlePanel, PANEL_MANF_ID, 0xFFFF);
			SetCtrlVal(HandlePanel, PANEL_MODEL_CODE, 0xFFFF);
		}
		
		
		
		
		
		
		break;
	
	default: 
		break;
	}
	
	return 0;
}

/* 
 * Quit
 */
int CVICALLBACK Quit(int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	switch (event){
	case EVENT_COMMIT:
		if (StatusTCP != TCP_INVALID_CONNECTION)
		{
			Cmd.command = QUIT_COMMAND; 
			ServerTCPWrite (StatusTCP, &Cmd, sizeof(Cmd), 5000);
		}
		
		QuitUserInterface (0);
		break;
		
	default:
		break;		
	}
	return 0;
}

// **************** Digital output ****************
/* 
 * Send 5V relay data
 */
int CVICALLBACK SendO5 (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	switch(event){
	case  EVENT_COMMIT:
		
		GetPanelHandleFromTabPage(HandlePanel, PANEL_TAB, TAB_INDEX_DIGIT_OUT, &HandleTab);
		
		GetCtrlVal(HandleTab, TAB_OUT_NUMERIC_O5, &Cmd.value);
		
		Cmd.command = IO_COMMAND;
		Cmd.subcmd = SUBCMD_IO_WRITE_REL27;
		ServerTCPWrite (StatusTCP, &Cmd, sizeof(Cmd), 5000);
		
		break;
		
	default: 
		break;
	}
	
	return 0;
}

/* 
 * Send 27V relay data
 */
int CVICALLBACK SendO27 (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	switch(event){
	case  EVENT_COMMIT:
		
		GetPanelHandleFromTabPage(HandlePanel, PANEL_TAB, TAB_INDEX_DIGIT_OUT, &HandleTab);
		
		GetCtrlVal(HandleTab, TAB_OUT_NUMERIC_O27, &Cmd.value);
		
		Cmd.command = IO_COMMAND;
		Cmd.subcmd = SUBCMD_IO_WRITE_REL27;
		ServerTCPWrite (StatusTCP, &Cmd, sizeof(Cmd), 5000);
		
		break;
		
	default: 
		break;
	}
	
	return 0;
}

/* 
 * Send 5V OC data
 */
int CVICALLBACK SendOC5 (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	switch(event){
	case  EVENT_COMMIT:
		
		GetPanelHandleFromTabPage(HandlePanel, PANEL_TAB, TAB_INDEX_DIGIT_OUT, &HandleTab);
		
		GetCtrlVal(HandleTab, TAB_OUT_NUMERIC_OC5, &Cmd.value);
		
		Cmd.command = IO_COMMAND;
		Cmd.subcmd = SUBCMD_IO_WRITE_OC;
		ServerTCPWrite (StatusTCP, &Cmd, sizeof(Cmd), 5000);
		
		break;
		
	default: 
		break;
	}
	
	return 0;
}

// **************** Digital input ****************
/* 
 * Read 5V isolation data
 */
int CVICALLBACK ReadI5 (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	switch(event){
	case  EVENT_COMMIT:
		
		GetPanelHandleFromTabPage(HandlePanel, PANEL_TAB, TAB_INDEX_DIGIT_IN, &HandleTab);
		
		Cmd.command = IO_COMMAND;
		Cmd.subcmd = SUBCMD_IO_READ_ISO5;
		ServerTCPWrite (StatusTCP, &Cmd, sizeof(Cmd), 5000);
		ServerTCPRead (StatusTCP, &Cmd, sizeof(Cmd), 5000);
		
		SetCtrlVal(HandleTab, TAB_IN_NUMERIC_I5, Cmd.value);
		
		break;
		
	default: 
		break;
	}
	
	return 0;
}

/* 
 * Read 27V isolation data
 */
int CVICALLBACK ReadI27 (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	switch(event){
	case  EVENT_COMMIT:
		
		GetPanelHandleFromTabPage(HandlePanel, PANEL_TAB, TAB_INDEX_DIGIT_IN, &HandleTab);
		
		Cmd.command = IO_COMMAND;
		Cmd.subcmd = SUBCMD_IO_READ_ISO27;
		ServerTCPWrite (StatusTCP, &Cmd, sizeof(Cmd), 5000);
		ServerTCPRead (StatusTCP, &Cmd, sizeof(Cmd), 5000);
		
		SetCtrlVal(HandleTab, TAB_IN_NUMERIC_I27, Cmd.value);
		
		
		break;
		
	default: 
		break;
	}
	
	return 0;
}

// **************** FPGA RAM ****************
/* 
 * Test FPGA 32 bits RAM
 */
int CVICALLBACK TestRam (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	switch(event){
	case  EVENT_COMMIT:
		
		// Creat tab page handle
		GetPanelHandleFromTabPage(HandlePanel, PANEL_TAB, TAB_INDEX_RAM, &HandleTab);
		
		// Read RAM before
		Cmd.command = IO_COMMAND;
		Cmd.subcmd = SUBCMD_IO_READ_RAM;
		ServerTCPWrite (StatusTCP, &Cmd, sizeof(Cmd), 5000);
		ServerTCPRead (StatusTCP, &Cmd, sizeof(Cmd), 5000);
		SetCtrlVal(HandleTab, TAB_RAM_NUMERIC_RAM_I_BEFORE, Cmd.value);
		
		// Write RAM
		GetCtrlVal(HandleTab, TAB_RAM_NUMERIC_RAM_O, &Cmd.value);
		Cmd.command = IO_COMMAND;
		Cmd.subcmd = SUBCMD_IO_WRITE_RAM;
		ServerTCPWrite (StatusTCP, &Cmd, sizeof(Cmd), 5000);
		
		// Read RAM after
		Cmd.command = IO_COMMAND;
		Cmd.subcmd = SUBCMD_IO_READ_RAM;
		ServerTCPWrite (StatusTCP, &Cmd, sizeof(Cmd), 5000);
		ServerTCPRead (StatusTCP, &Cmd, sizeof(Cmd), 5000);
		SetCtrlVal(HandleTab, TAB_RAM_NUMERIC_RAM_I_AFTER, Cmd.value);
		
		
		break;
		
	default: 
		break;
	}
	
	return 0;
}

// **************** FPGA LED ****************
/* 
 * Turn on LED
 */
int CVICALLBACK TurnOnLed (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	switch(event){
	case  EVENT_COMMIT:
	
		Cmd.command = IO_COMMAND;
		Cmd.subcmd = SUBCMD_IO_WRITE_LED;
		Cmd.value = 1;
		ServerTCPWrite (StatusTCP, &Cmd, sizeof(Cmd), 5000);

		
		break;
		
	default: 
		break;
	}
	
	return 0;
}

/* 
 * Turn off LED
 */
int CVICALLBACK TurnOffLed (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	switch(event){
	case  EVENT_COMMIT:
	
		Cmd.command = IO_COMMAND;
		Cmd.subcmd = SUBCMD_IO_WRITE_LED;
		Cmd.value = 0;
		ServerTCPWrite (StatusTCP, &Cmd, sizeof(Cmd), 5000);

		
		break;
		
	default: 
		break;
	}
	
	return 0;
}







