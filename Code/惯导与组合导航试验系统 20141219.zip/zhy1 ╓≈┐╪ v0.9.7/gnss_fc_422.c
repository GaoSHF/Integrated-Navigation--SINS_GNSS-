//==============================================================================
//
// Title:       gnss_fc_422.c
// Purpose:     A short description of the implementation.
//
// Created on:  2014/1/21 at 11:41:09 by ZhaoHengyang.
// Copyright:   Beihang University. All Rights Reserved.
//
//==============================================================================

//==============================================================================
// Include files
#include <rtutil.h>
#include <ansi_c.h>
#include <utility.h>


#include "common.h"
#include "gnss_fc_422.h"
#include "RS422.h"

//==============================================================================
// Constants

//==============================================================================
// Types

//==============================================================================
// Static global variables

//==============================================================================
// Static functions

//==============================================================================
// Global variables
RS422_DevHandle DeviceHandleGPS422;

static int ThreadFunctionIdGNSSFC422 = 0;

static int FlagExit = 0;

FILE *FileHandleGNSSFC422 = NULL;

unsigned char DataGNSS422FC[340] = { 0 };


//==============================================================================
// Global functions
static int CVICALLBACK ThreadFunctionGNSSFC422(void *functionData);



/*
	��ʼ�ɿ�ģʽ�µ�GNSS422����
 */
int gnssfc422StartReceive(void)
{
	FileHandleGNSSFC422 = fopen (FILE_PATH_RT_FCGNSS422, "wb");
	
	DeviceHandleGPS422.bps = GPS_SERIAL_BPS;
	DeviceHandleGPS422.comValue = COM4;
	DeviceHandleGPS422.check = NOPARITY;
	DeviceHandleGPS422.data = 8;
	DeviceHandleGPS422.stop = 1;
	RS422_Close(DeviceHandleGPS422); 
	if (!RS422_OpenConfig(DeviceHandleGPS422))
	{
		fclose(FileHandleGNSSFC422);
		RS422_Close(DeviceHandleGPS422);
		
		return 1;
	}
	
	FlagExit = 0;
	
	//InstallComCallback (DeviceHandleGPS422.comValue, LWRS_RECEIVE,256, 0, (void *)uartRevLVDS, 0);
	CmtScheduleThreadPoolFunction (RT_ThreadPool,
                                   ThreadFunctionGNSSFC422, NULL,
                                   &ThreadFunctionIdGNSSFC422);
	

	printf("GNSS 422 FC: Open success!\n");
	
	return 0;
}

/*
	ֹͣ�ɿ�ģʽ�µ�GNSS422����
 */
int gnssfc422StopReceive(void)
{
	FlagExit = 1; 
 	CmtWaitForThreadPoolFunctionCompletion (RT_ThreadPool,
                    ThreadFunctionIdGNSSFC422,
                   OPT_TP_PROCESS_EVENTS_WHILE_WAITING);
	CmtReleaseThreadPoolFunctionID (RT_ThreadPool, ThreadFunctionIdGNSSFC422);
	
	RS422_Close(DeviceHandleGPS422);
	
	fclose (FileHandleGNSSFC422);
	
	printf("GNSS 422 FC: Close success!\n");
	
	return 0;
}


/*
	GPS422�����߳�
 */
static int CVICALLBACK ThreadFunctionGNSSFC422(void *functionData)
{
	int i,j;
	unsigned int rev_StrLen=0;//�������ݳ��� 
	static unsigned char rev_Data[4096]={0};//��ʱ���ݽ���
	static unsigned char frame_tail;//֡ͷ
	static unsigned char frame_head;//֡ͷ
	
	long long timeUS;
	double timeMS;					 
	
	//�ж�ͬ��ͷHBGCK
	while (!FlagExit)
    {
		rev_StrLen = GetInQLen (DeviceHandleGPS422.comValue);

		if(rev_StrLen > 0)
		{
			frame_head=ComRdByte(DeviceHandleGPS422.comValue);
			if(frame_head != 0x48)
			continue;
			rev_StrLen=GetInQLen (DeviceHandleGPS422.comValue);
			if(rev_StrLen > 0)
			{
				frame_head=ComRdByte(DeviceHandleGPS422.comValue);
				if(frame_head != 0x42)
					continue;	
				rev_StrLen = GetInQLen (DeviceHandleGPS422.comValue);
				if(rev_StrLen > 0)
				{
					frame_head =ComRdByte(DeviceHandleGPS422.comValue);
					if(frame_head != 0x47)
					continue;
					rev_StrLen=GetInQLen (DeviceHandleGPS422.comValue);
					if(rev_StrLen > 0)
					{
						frame_head=ComRdByte(DeviceHandleGPS422.comValue);
						if(frame_head != 0x43)
						continue;
						rev_StrLen=GetInQLen (DeviceHandleGPS422.comValue);
						if(rev_StrLen > 0)
						{
							frame_head=ComRdByte(DeviceHandleGPS422.comValue);
							if(frame_head != 0x4B)
							continue;
							rev_StrLen=GetInQLen (DeviceHandleGPS422.comValue);
							if(rev_StrLen > 0)
							{
								frame_head=ComRdByte(DeviceHandleGPS422.comValue);
								if(frame_head != 0xF2)
								continue;
								break;
							}

						}
						
					}
					
				}
		
			}
		
		}
		SleepUS (100);  
    }
	
	//��ȡͬ��ͷ��ĵ�һ֡����
	while (!FlagExit)
    {
		rev_StrLen = GetInQLen (DeviceHandleGPS422.comValue);
		if(rev_StrLen >= 339 - 6)
		{
				for(i = 0; i < 339 - 6; i++)
				{			//�����ֽڶ�  
					rev_Data[i] = ComRdByte(DeviceHandleGPS422.comValue);
			 
				}
			/*	fprintf(FileHandleGNSSFC422,"%d ", rev_StrLen); 
				for(j=0;j<332;j++)   
				{
					fprintf (FileHandleGNSSFC422, "%02x ", rev_Data[j]); 
				} 
				fprintf(FileHandleGNSSFC422, "\r\n");   */
				rev_StrLen=0;
				break;
		}
		SleepUS (100);
	}
	
	if (FlagExit == 0)
		printf("GNSS 422 FC: Frame head sync success!\n");
    
	//��һ֡ͬ���������
    while (!FlagExit)
    {
		rev_StrLen=GetInQLen (DeviceHandleGPS422.comValue);
		if(rev_StrLen >= 339)
		{
			rev_StrLen = 0;
			
			timeUS = GetTimeUS (); 
			timeMS = (double)timeUS / 1000;
			DataRT.gps_time = timeMS;
			
			for(i = 0; i < 339; i++)
			{			
				//�����ֽڶ�  
				DataGNSS422FC[i] = ComRdByte(DeviceHandleGPS422.comValue);
			}
			
			
			fprintf(FileHandleGNSSFC422, "%f\t", DataRT.gps_time);
			for (i = 0; i < 339; i ++)
			{
				fprintf(FileHandleGNSSFC422, "%02x\t", DataGNSS422FC[i]);
			}
			fprintf(FileHandleGNSSFC422, "\r\n");
			
			
			DataRT.state = FCGNSS422_STATE; 
			Update();
		}
		SleepUS (100);
    }		

    return 0;
}













