
#include <rtutil.h>
#include "asynctmr.h"
#include <ansi_c.h>
#include <utility.h>
#include <userint.h>
#include <time.h>

#include "fc1553.h"
#include "rfm.h"
#include "pxi_io.h"
#include "common.h"

#define bits(x,y,z)  (((x)>>(y))&(z))
#define	MSB16_SCALE	16384
#define	MSB32_SCALE	1073741824

#define D2R		(3.14159265 / 180)

FILE *FileHandleRTFC1553 = NULL; //  File handle

int FlagFireControlMode = MODE_FIRECONTROL_DYNAMIC; // Flag of fire control mode

int FlagRecordFC1553 = FILE_RECORD_INACTIVE; // File record flag of fire control 1553

long long CountInFC1553 = 0;
long long CountOutFC1553 = 0;

long long IndexInFC1553 = 0;
long long IndexOutFC1553 = 0;

//ʱ�����
unsigned long long TimeUS_Start; 		
unsigned int TimeSec_Start;
unsigned short DateToday;

// �ߵ���ʼ������
time_t FC_Time;
double H0,XN0,YN0,ZN0,HP0,ReCC;
double Lat,Lon,lattemp,lontemp;
double VNX,VNY,VNZ;
double GX,GY,GZ;
double XNR,YNR,ZNR;
double R0,R1,R2,R3;

// ��̬���Բ��� 
int				Dynamic_Counter = 0;

MSG_RECEIVE		Dynamic_BcResults[2];
int				Dynamic_BcFrameNum = 0;
unsigned int	Code[28];

// ��̬���Բ���
uInt16 FireCtrl_PlaneDescribeData_1R[30];
uInt16 FireCtrl_MissileCtrlData_2R[30];
uInt16 FireCtrl_Data_4R[30];
uInt16 FireCtrl_Data_10R[30];
uInt16 FireCtrl_Data_11R[30];
uInt16 FireCtrl_Data_30R[30]; 
uInt16 Missile_Describe_Check[32];
uInt16 Missile_Describe[32];
uInt16 VectorCode;

// Ҫ���͸�����������
double RRELsuo[3]; // �����ҵ��ڵ�������ϵ�е�ͶӰ
double Vout[3]; // �ػ������ٶ��������ػ������������ϵ�ͶӰ
double Rout[3]; // �ػ������ػ���������ϵ�еļ�ʹλ��
double Gsuo[3]; // �������ٶ����ػ������������ϵ�ͶӰ
double QUATsuo[4]; // ��Ԫ��

// �������������
double USETreal[3]; // �����İ�װ��
double DUSET[3]; // ��װ�ǵ����
double RRELOreal[3]; // �����İ�װλ�ã����ػ�����ϵ�е����꣩
double DRREL[3]; // ��װλ�õ����

double VNGinsn[3]; // �����ػ�����˲���ػ��ڵ�������ϵ�е��ٶ�
double einsn; // �����
double DVinsn[3]; // ƽ̨�ٶ�����
double UPCreal[3]; // CCKH����������ϵ�����ƽ̨�ļн�
double gmod;
double OMPinsn[3]; // ƽ̨���ٶ�

// �м�����
double ASETreal[3][3]; // ��CCKP��CCKH����ʵת������
double ASETsuo[3][3]; // ��CCKP'��CCKH����ʵת������
double ARAB[3][3]; // ��ʱ����
double ARAB1[3][3];

double Urab[3];
double Urab1[3];
double AIPsuo[3][3]; // ƽ̨����ϵ���ػ���������ϵ��ת������
double RAB[3];
double DVsuo[3];
double VNIsuo[3];
double RNIsuo[3];
double hxj;

// ��������
double dbFp1[3], dbFp0[3];

double Lat0, Lon0;

double InsH;
double dbH0, dbHp0;


// ����ϵ���ٶ�
double Vt[3];

double VPCreal[3];

// ŷ����
double USETreal[3];

int bMissileLaunch = 0;

long long TATime = 0;

PS_DevHandle   PS3531_hDev;

int CountTest = 0;

int Counter30R;

double TimeFC1553;

//Timer initial function 
void Init_Date_Time();

// Timer handler
int	TimerIdFC1553;
int TimerIdFC1553_30R;

// Global functions  
int CVICALLBACK TimerFC1553(int reserved, int timerId, int event, void *callbackData, int eventData1, int eventData2);

int CVICALLBACK TimerFC1553_30R(int reserved, int timerId, int event, void *callbackData, int eventData1, int eventData2); 

int fc1553Record(unsigned char *dataType, uInt16 *data);

int fc1553Test();

int fc1553Init();

int fc1553CleanUp();


//Write 1553 message (vector code)
void CmdQuery1553bVectorCode(PS_DevHandle hDev,uInt16 *Vector_code,uInt16 MsgGap,uInt16 RtAddr)
{
	MSG_SEND msgSend;  
	MSG_RECEIVE BCmsgReceive;
	unsigned int  BCmsgCount=1; 
	unsigned int BCmsgIndex=0;   
	bool32 flag=1;
	P3530_SetMode(hDev,0,MODE_BC);
	//��������֡��Ϣ
	msgSend.msgGapTime= MsgGap;
	msgSend.controlWord=0x84;
	msgSend.msgBlock[0]=(RtAddr<<11)|(0x1<<10)|0x10;//0xC410;  //vector code
	//д����Ϣ	  
	P3530_BCWriteMsg(hDev,0,0,&msgSend,1);
	//����֡��Ϣ����#
	P3530_BCSetFrameMsgCount(hDev,0,BCmsgCount);
	//����֡��ʼ��Ϣ����
	P3530_BCSetFrameMsgStartIndex(hDev,0,BCmsgIndex);
	//����BC
	P3530_BCMTStart(hDev,0);
	while (flag)
	{
		P3530_BCIsFrmInProgress(hDev,0,&flag);
	}
	//Delay(0.001); 
	//BC��ȡ��Ϣ
	P3530_BCReadMsg(hDev,0,0,&BCmsgReceive);
	*Vector_code = BCmsgReceive.msgBlock[0 + OFFSET_FC1553];
}

//Write 1553 message
void CmdBc2RtMsg(PS_DevHandle hDev,MSG_RECEIVE *BCmsgReceive,uInt16 MsgGap,
	uInt16 RtAddr,uInt16 SubAddr,unsigned int WordCount,uInt16 Data[])
{
	MSG_SEND msgSend; 
//	MSG_RECEIVE BCmsgReceive;
	unsigned int  BCmsgCount = 1; 
	unsigned int BCmsgIndex = 0;   
	bool32 flag=1;
	//��ʼ��BCģʽ
	P3530_SetMode(hDev,0,MODE_BC);
	//��������֡��Ϣ
	msgSend.msgGapTime= MsgGap;
	msgSend.controlWord= 0x80;
	msgSend.msgBlock[0]= (RtAddr<<11)|(0x0<<10)|(SubAddr<<5)|WordCount;//0xC03E;
	for (int j=1;j<(WordCount+1);j++)
	{
		msgSend.msgBlock[j]=Data[j-1];
	}
	//д����Ϣ	  
	P3530_BCWriteMsg(hDev,0,0,&msgSend,WordCount+1);
	//����֡��Ϣ����#
	P3530_BCSetFrameMsgCount(hDev,0,BCmsgCount);
	//����֡��ʼ��Ϣ����
	P3530_BCSetFrameMsgStartIndex(hDev,0,BCmsgIndex);
	//����BC
	P3530_BCMTStart(hDev,0);
	//�ȴ���ǰ֡�������
	while (flag)
	{
		P3530_BCIsFrmInProgress(hDev,0,&flag);
	}
	//BC��ȡ��Ϣ
	P3530_BCReadMsg(hDev,0,0,BCmsgReceive);
	
}

//Read 1553 message
void CmdRt2BcMsg(PS_DevHandle hDev,MSG_RECEIVE *RTmsgReceive,uInt16 MsgGap,
	uInt16 RtAddr,uInt16 SubAddr,unsigned int WordCount)
{
	MSG_SEND msgSend; 
//	MSG_RECEIVE BCmsgReceive;
	unsigned int  BCmsgCount=1; 
	unsigned int BCmsgIndex=0;   
	bool32 flag=1;
	//��ʼ��BCģʽ
	P3530_SetMode(hDev,0,MODE_BC);
	//��������֡��Ϣ
	msgSend.msgGapTime= MsgGap;
	msgSend.controlWord= 0x80;
	msgSend.msgBlock[0]= (RtAddr<<11)|(0x1<<10)|(SubAddr<<5)|WordCount;//0xC43E;
	//д����Ϣ	  
	P3530_BCWriteMsg(hDev,0,0,&msgSend,1);
	//����֡��Ϣ����#
	P3530_BCSetFrameMsgCount(hDev,0,BCmsgCount);
	//����֡��ʼ��Ϣ����
	P3530_BCSetFrameMsgStartIndex(hDev,0,BCmsgIndex);
	//����BC
	P3530_BCMTStart(hDev,0);
	//�ȴ���ǰ֡�������
	while (flag)
	{
		P3530_BCIsFrmInProgress(hDev,0,&flag);
	}
	//BC��ȡ��Ϣ
	P3530_BCReadMsg(hDev,0,0,RTmsgReceive);
}

//ѭ������
unsigned int lol(unsigned int value,unsigned int a)
{
	unsigned short tmp1,tmp2;
	unsigned int temp;
	
	a%=16;
	
	tmp1 = value>>(16-a);
	tmp2 = value<<a;
	temp = tmp1|tmp2;
	
	return temp;
}

//ѭ������
unsigned int ror(unsigned int value,unsigned int a)
{
	unsigned short tmp1,tmp2;
	unsigned int temp;
	
	a%=16;
	
	tmp1 = value<<(16-a);
	tmp2 = value>>a;
	temp = tmp1|tmp2;
	
	return temp;
}

//Check
uInt16 CheckSum(uInt16* data,int a)
{
	int i;
	uInt16 temp;
	temp = *data;
	data++;
	for(i=1;i<a;i++)
	{
		temp = temp^ror(*data,i);
		data++;
	}
	i=i%16;
	temp = lol(temp,i);
	return temp;
}


uInt16 KeyVerify(uInt16 KeyControl)
{
	uInt16 l;
	uInt16 D0,D1,D2,D3,D4,D5,D6,D7,D8,D9,D10;
	uInt16 C0,C1,C2,C3,C4,C5,C6,C7,C8,C9,C10,C11,C12,C13,C14;
	
	D0 = bits(KeyControl,5,1);
	D1 = bits(KeyControl,6,1);
	D2 = bits(KeyControl,7,1);
	D3 = bits(KeyControl,8,1);
	D4 = bits(KeyControl,9,1);
	D5 = bits(KeyControl,10,1);
	D6 = bits(KeyControl,11,1);
	D7 = bits(KeyControl,12,1);
	D8 = bits(KeyControl,13,1);
	D9 = bits(KeyControl,14,1);
	D10 = bits(KeyControl,15,1);
	
	C14 = D10^D9^D6^D1^D0;
	C13 = D9^D8^D5^D0;
	C12 = D8^D7^D4;
	C11 = D6^D7^D3;
	C10 = D10^D9^D5^D2^D1^D0;
	C9 = D10^D8^D6^D4; 
	C8 = D10^D7^D6^D5^D3^D1^D0; 
	C7 = D10^D5^D4^D2^D1; 
	C6 = D10^D6^D4^D3; 
	C5 = D9^D5^D3^D2; 
	C4 = D10^D9^D8^D6^D4^D2^D0; 
	C3 = D9^D8^D7^D5^D3^D1; 
	C2 = D10^D9^D8^D7^D4^D2^D1;   
	C1 = D10^D8^D7^D3;   
	C0 = D10^D7^D2^D1^D0;   
	
	l=(C14<<15)|(C13<<14)|(C12<<13)|(C11<<12)|(C10<<11)|(C9<<10)|(C8<<9)|(C7<<8)|(C6<<7)|(C5<<6)|(C4<<5)|(C3<<4)|(C2<<3)|(C1<<2)|(C0<<1);
	return l;
}

int DoubleToInt(double data,double kuzhi)
{
	int temp;
	
	if(kuzhi ==0)
		return 0;
	if(fabs(data)>kuzhi)
	{
		if(data>0)
			return 0x7fffffff;
		else 
			return 0x80000000;
	}
	else
	{
		temp = (int)(data/kuzhi*pow(2,31));
		return temp;
	}
}

double decode16bit(short Value, double scale)
{
	double ReturnVal;
	ReturnVal = Value * scale / MSB16_SCALE;

	return ReturnVal;
}

double decode32bit(unsigned int low16bit, unsigned int high16bit, double scale)
{
	long TempVal;
	double ReturnVal;
	TempVal = high16bit;
	TempVal = TempVal << 16;
	TempVal = (TempVal & 0xFFFF0000) | (low16bit & 0x0000FFFF);
	ReturnVal = TempVal * scale / MSB32_SCALE;

	return ReturnVal;
}

//���㷽�����Ҿ���
void CalcCan(double a[],double c[][3])
{
	double sp,cp,st,ct,sg,cg;
	double	u[3];	
    u[0]=a[0]*D2R;
	u[1]=a[1]*D2R;
	u[2]=a[2]*D2R;

	sp=sin(u[0]);
	cp=cos(u[0]);
	st=sin(u[1]);
	ct=cos(u[1]);
	sg=sin(u[2]);
	cg=cos(u[2]);
	c[0][0]=cp*ct;
	c[0][1]=sp*sg-cp*cg*st;
	c[0][2]=sp*cg+cp*sg*st;
	c[1][0]=st;
	c[1][1]=cg*ct;
	c[1][2]=-sg*ct;
	c[2][0]=-sp*ct;
	c[2][1]=cp*sg+sp*cg*st;
	c[2][2]=cp*cg-sp*sg*st;
}

//������Ԫ��
void CalcQ(double c[][3],double r[])
{   
	double a,b,e,d;
	a=(1.+c[0][0]+c[1][1]+c[2][2])*0.25;
	b=(1.+c[0][0]-c[1][1]-c[2][2])*0.25;
	e=(1.-c[0][0]+c[1][1]-c[2][2])*0.25;
	d=(1.-c[0][0]-c[1][1]+c[2][2])*0.25;
	if (a < 0.)
	a=0.;
	if (b < 0.)
	b=0.;
	if (e < 0.)
	e=0.;
	if (d < 0.)
	d=0.;
	r[0]=sqrt(a);
	r[1]=sqrt(b);
	r[2]=sqrt(e);
	r[3]=sqrt(d);
	if( c[2][1] < c[1][2])
	r[1]=-r[1];
	if( c[0][2] < c[2][0])
	r[2]=-r[2];
	if(c[1][0] < c[0][1])
	r[3]=-r[3];
}


void Init_Missile_Load_Data1()
{
	int Lat1, Lon1;
	int VNX1, VNY1, VNZ1;
	Lat1 = DoubleToInt(Lat, 180);
	Lon1 = DoubleToInt(Lon, 360);
	int R01, R11, R21, R31;
	int XNR1, YNR1, ZNR1;
	int GX1, GY1, GZ1;
	
	VNX1 = DoubleToInt(VNX, 1600);
	VNY1 = DoubleToInt(VNY, 1600);
	VNZ1 = DoubleToInt(VNZ, 1600);
	
	R01 = DoubleToInt(R0, 1.0);
	R11 = DoubleToInt(R1, 1.0);
	R21 = DoubleToInt(R2, 1.0);
	R31 = DoubleToInt(R3, 1.0);
	
	XNR1 = DoubleToInt(XNR, 12.5);
	YNR1 = DoubleToInt(YNR, 12.5);
	ZNR1 = DoubleToInt(ZNR, 12.5);
	
	GX1 = DoubleToInt(GX, 12.5);
	GY1 = DoubleToInt(GY, 12.5);
	GZ1 = DoubleToInt(GZ, 12.5);
	
	FireCtrl_Data_10R[0] = 0x0003;
	FireCtrl_Data_10R[1] = 0x0000;
	FireCtrl_Data_10R[2] = 0x0000;
	FireCtrl_Data_10R[3] = 0x0000;
	
	FireCtrl_Data_10R[4] = 0x40b0;
	FireCtrl_Data_10R[5] = (VNX1 & 0x80000000) >> 16;
	FireCtrl_Data_10R[6] = ((VNX1 << 1) & 0xFFFF0000) >> 16;
	
	FireCtrl_Data_10R[7] = (VNY1 & 0x80000000) >> 16;
	FireCtrl_Data_10R[8] = ((VNY1 << 1) & 0xFFFF0000) >> 16;
	
	FireCtrl_Data_10R[9] = (VNZ1 & 0x80000000) >> 16;
	FireCtrl_Data_10R[10] = ((VNZ1 << 1) & 0xFFFF0000) >> 16;
	
	FireCtrl_Data_10R[11] = (R01 & 0xFFFF0000) >> 16;
	FireCtrl_Data_10R[12] = (R11 & 0xFFFF0000) >> 16;
	FireCtrl_Data_10R[13] = (R21 & 0xFFFF0000) >> 16;
	FireCtrl_Data_10R[14] = (R31 & 0xFFFF0000) >> 16;
	
	FireCtrl_Data_10R[15] = 0x0000;
	FireCtrl_Data_10R[16] = 0x0000;
	
	FireCtrl_Data_10R[17] = (XNR1 & 0xFFFF0000) >> 16;
	FireCtrl_Data_10R[18] = (YNR1 & 0xFFFF0000) >> 16;
	FireCtrl_Data_10R[19] = (ZNR1 & 0xFFFF0000) >> 16;
	
	FireCtrl_Data_10R[20] = (GX1 & 0xFFFF0000) >> 16;
	FireCtrl_Data_10R[21] = (GY1 & 0xFFFF0000) >> 16;
	FireCtrl_Data_10R[22] = (GZ1 & 0xFFFF0000) >> 16;
	
	FireCtrl_Data_10R[23] = (Lat1 & 0xFFFF0000) >> 16;
	FireCtrl_Data_10R[24] = (Lat1 & 0x0000FFFF);
	FireCtrl_Data_10R[25] = (Lon1 & 0xFFFF0000) >> 16;
	FireCtrl_Data_10R[26] = (Lon1 & 0x0000FFFF);
	
	FireCtrl_Data_10R[27] = CheckSum(FireCtrl_Data_10R, 27);
}

//װ����Ϣ1
void Init_Missile_Load_Data10R(uInt16 data[])   
{
	int month;
	int day;  
	int year;  
	int hours;
	int minutes;  
	int seconds;  
	
	int time_now_Change;
	double Time_now;
	int Lat1,Lon1;
	int VNX1,VNY1,VNZ1,XN01,YN01,ZN01;
	int R01,R11,R21,R31;
	int XNR1,YNR1,ZNR1;
	int GX1,GY1,GZ1;
	int HP01,H01;
	int ReCC1;
	
	H01 = DoubleToInt(H0,12800*65536);
	HP01 = DoubleToInt(HP0,12800*65536);
	ReCC1 = DoubleToInt(ReCC,256);
	
	VNX1 = DoubleToInt(VNX,1600);
	VNY1 = DoubleToInt(VNY,1600);
	VNZ1 = DoubleToInt(VNZ,1600);
	
	XN01 = DoubleToInt(XN0,204800);
	YN01 = DoubleToInt(XN0,204800); 
	ZN01 = DoubleToInt(XN0,204800); 
	
	Lat1 = DoubleToInt(Lat,180);
	Lon1 = DoubleToInt(Lon,180);
	
	VNX1 = DoubleToInt(VNX,52428800); 
	VNY1 = DoubleToInt(VNY,52428800);   
	VNZ1 = DoubleToInt(VNZ,52428800);   
	
	R01 = DoubleToInt(R0,1.0);
	R11 = DoubleToInt(R1,1.0);
	R21 = DoubleToInt(R2,1.0);
	R31 = DoubleToInt(R3,1.0);
	
	XNR1 = DoubleToInt(XNR,12.5);   
	YNR1 = DoubleToInt(YNR,12.5);
	ZNR1 = DoubleToInt(ZNR,12.5); 
	
//	printf("XNR = %f\tYNR = %f\tZNR = %f\n", XNR, YNR, ZNR);
	
	GX1 = DoubleToInt(GX,12.5);
	GY1 = DoubleToInt(GY,12.5);
	GZ1 = DoubleToInt(GZ,12.5);
	
	data[0] = 0x000A;
	data[1] = DateToday;  
	data[2] = (((FC_Time - TimeUS_Start)/40 + TimeSec_Start)>>16) & 0x0000ffff;  
	data[3] = ((FC_Time - TimeUS_Start)/40 + TimeSec_Start) & 0x0000ffff; 
/*	
	time222 = time111;
	time111 = ((data[2]<<16) + data[3])/25;
	time333 = time111 - time222;
	printf("sub_time = %d.\t FC_time = %d.\n", time333, FC_Time);
 */
	data[4] = (VNX1>>16)&0x0000ffff;
	data[5] = (VNX1)&0x0000ffff;
	
	data[6] = (VNY1>>16)&0x0000ffff;
	data[7] = (VNY1)&0x0000ffff;

	data[8] = (VNZ1>>16)&0x0000ffff;
	data[9] = (VNZ1)&0x0000ffff;
	
	//�ػ�λ��
	data[10] = (XN01&0xffff0000)>>16;
	data[11] = (YN01&0xffff0000)>>16;
	data[12] = (ZN01&0xffff0000)>>16;
	//��Ԫ��
	data[13] = (R01&0xffff0000)>>16;
	data[14] = (R11&0xffff0000)>>16;
	data[15] = (R21&0xffff0000)>>16;
	data[16] = (R31&0xffff0000)>>16; 
	//XNR,YNR,ZNR
	data[17] = (XNR1&0xffff0000)>>16;
	data[18] = (YNR1&0xffff0000)>>16;
	data[19] = (ZNR1&0xffff0000)>>16;
	
	//XNR,YNR,ZNR
	data[20] = (GX1&0xffff0000)>>16;
	data[21] = (GY1&0xffff0000)>>16;
	data[22] = (GZ1&0xffff0000)>>16;
	
	data[23] = (Lat1&0xffff0000)>>16;
	data[24] = (Lat1&0x0000ffff); 
	data[25] = (Lon1&0xffff0000)>>16;
	data[26] = (Lon1&0x0000ffff); 
	data[27] = HP01;
	data[28] = (H01&0xff00)|((ReCC1<<1)>>24); 
	data[29] = CheckSum(data,29);
 	
	
}

//װ����Ϣ2
void Init_Missile_Load_Data4R(uInt16 data[])   
{
	double DPZ,AS,BS,DPG,TG,DPYZ,TYZ,WIYZ,TWI,CT;//AC
	int DPZ1,HH,Hk,AS1,BS1,DPG1,TG1,DPYZ1,TYZ1,WIYZ1,TWI1,AC1,CT1;
	char CK,ZB,ZK,BK,Is,DI,Brk,DLC;
	char ReC;
	DPZ=35000;
	HH=0;
	Hk=0;
	AS=0;
	BS=0;
	DPG=0;
	TG=0;
	DPYZ=0;
	TYZ=0;
	WIYZ=-8.0;
	TWI=0.4;
	AC1=3;
	CT=0;
	
	CK=0;
	ZB=0;
	ZK=0;
	
	BK=0;
	ReC=1;
	ReCC=1;
	Is=0;
	DI=1;
	Brk=0;
	DLC=0;
	
	DPZ1 =DoubleToInt(DPZ,51200);
	AS1 =DoubleToInt(AS,90);
	BS1 =DoubleToInt(BS,90);  
	DPG1 = DoubleToInt(DPG,0.5);
	TG1 =DoubleToInt(TG,2);
	TYZ1 = DoubleToInt(TYZ,2);  
	DPYZ1 = DoubleToInt(DPYZ,0.5);
	TWI1 = DoubleToInt(TWI,4.0);
	WIYZ1 = DoubleToInt(WIYZ,256.0);
	CT1 = DoubleToInt(CT,8);
	
	data[0] = 0x0004;
	data[1] = 0x0000;
	data[2] = 0x0000;
	data[3] = DI|Is<<2|ReC<<4|BK<<8|ZK<<10|ZB<<11|AC1<<12|CK<<15;
	
	data[4] = Brk<<15|DLC<<12|HH<<4|Hk;
	data[5] = CT1>>29;
	data[6] = DPZ1>>15;
	data[7] = (AS1&0xff000000)>>16|(BS1&0xff000000)>>24;
	data[8] = ((DPG1&0xff000000)>>16)|(((TG1<<1)&0xff000000)>>24);
	data[9] = ((DPYZ1&0xff000000)>>16)|(((TYZ1<<1)&0xff000000)>>24); 
	data[10] = ((WIYZ1&0xff000000)>>16)|(((TWI1<<1)&0xff000000)>>24);
	
	for(int i=11;i<=28;i++)
	{
		data[i]=0x0000;
	}
	data[29]=CheckSum(data,29);
	
}

//��ʼ��30Rʱ���
void Init_Missile_Load_Data30R(uInt16 data[]) 
{
    unsigned long long Time30R;
	unsigned long long Time30R_Send;
		
	Time30R = GetTimeUS();	
	Time30R = (Time30R - TimeUS_Start)/40;
	
	Time30R_Send = TimeSec_Start + Time30R;
	
	data[0] = DateToday;
	data[1] = (Time30R_Send >> 16 )& 0x0000ffff;
	data[2] = Time30R_Send & 0x0000ffff;  
	
	for(int i=3;i<=28;i++)
	{
		data[i]=0x0000;
	}
	data[29]=CheckSum(data,29);
}

//ʱ���ʼ������
void Init_Date_Time()
{
	struct tm *TimeNow;
	time_t timesec1900;
	time_t TimeUS;
	
	time(&timesec1900);
	TimeNow = localtime (&timesec1900);
	DateToday = ((TimeNow->tm_year-100) & 0x007f) +
		      (((TimeNow->tm_mon+1)<<7) & 0x0780) + 
			  (((TimeNow->tm_mday)<<11) & 0xf800); 
	
	TimeSec_Start = (TimeNow->tm_hour * 3600 + TimeNow->tm_min * 60 + TimeNow->tm_sec) * 25000;
	TimeUS_Start = GetTimeUS();	
}


void Missile_Ready_2R(uInt16 data[])
{
	int i;
	data[0] = 0x0002;
	data[1] = 0x0000; 
	data[2] = 0x0000; 
	data[3] = 0x1038; // ���Ե�2R���ĸ���
	
	for (i = 4; i <= 28; i ++)
	{
		data[i] = 0x0000;
	}
	
	data[29] = CheckSum(data,29);
}   

//2R��Ʒ׼��
void Init_2R_Data(uInt16 data[],int nMissileReady)
{
	int i;
	data[0] = 0x0002;
	data[1] = 0x0000;
	data[2] = 0x0000;
	if(nMissileReady == 1)
	{
		data[3] = 0x1038;
	}
	else
	{
		data[3] = 0x0038;
	}
	
	for(i=4;i<=28;i++)
	{
		data[i] = 0x0000;
	}
	data[29]=CheckSum(data,29);	
}


void Missile_Ctrl_11R(uInt16 data[],int bLaunch)
{
	int i;
	data[0] = 0x0400;
	data[1] = 0x0000;
	data[2] = 0x0000;
	if(bLaunch ==1)
	{
		data[3]=0x8438;
	}
	else
	{
		data[3]=0x0438;
	}
	data[4]=KeyVerify(data[3]);
	
	for(i=5;i<=28;i++)
	{
		data[i] = 0x0000;
	}
	data[29] = CheckSum(data,29);
}

//�ɻ�����
void Init_PlaneDescrib_1R(void)
{
	int i;
	//�ɻ�����
	FireCtrl_PlaneDescribeData_1R[0] = 0x0421;	
	FireCtrl_PlaneDescribeData_1R[1] = 0x0000;
	FireCtrl_PlaneDescribeData_1R[2] = 0x0000;
	FireCtrl_PlaneDescribeData_1R[3] = 0x434e;
	FireCtrl_PlaneDescribeData_1R[4] = 0x1000; 
	FireCtrl_PlaneDescribeData_1R[5] = 0x4a38; //J8
	FireCtrl_PlaneDescribeData_1R[6] = 0x4600; //F
	FireCtrl_PlaneDescribeData_1R[7] = 0x0000;
	FireCtrl_PlaneDescribeData_1R[8] = 0x0000;
	FireCtrl_PlaneDescribeData_1R[9] = 0x0000;
	FireCtrl_PlaneDescribeData_1R[10] = 0x0000;
	FireCtrl_PlaneDescribeData_1R[11] = 0x0000;
	FireCtrl_PlaneDescribeData_1R[12] = 0x0000; //�ҵ�� �ݶ�Ϊ0000
	for(i=13;i<29;i++)
		FireCtrl_PlaneDescribeData_1R[i] = 0x0000;
	FireCtrl_PlaneDescribeData_1R[29] = CheckSum(FireCtrl_PlaneDescribeData_1R,29);

}

//Record 1553 data to FIFO
int fc1553Record(unsigned char *dataType, uInt16 *data)
{
	int i;
	
	TimeFC1553 = (double)GetTimeUS() / 1000.0;
	
	strcpy((DataTemp + IndexInFC1553)->dataType, dataType);
	(DataTemp + IndexInFC1553)->timeFC1553 = TimeFC1553;
	for (i = 0; i < 30; i ++)
	{
		(DataTemp + IndexInFC1553)->dataFlightControl[i] = *(data + i);	
	}
	// FIFO
	CountInFC1553 ++;
	IndexInFC1553 ++;
	if (IndexInFC1553 >= MEMORY_BANK_SIZE)
		IndexInFC1553 = 0;
	return 0;
}

//��ض�̬���Բ�����ֵ
int fc1553Test()
{
	if (FlagFireControlMode == MODE_FIRECONTROL_STATIC)
	{
		FC_Time = RFMFireControlDataRx.FC_TimeUS; 
		
		GX= 0.0;
		GY = -9.7959;
		GZ = 0;
	
		VNX = 0.000;
		VNY = 0.0;
		VNZ = 0.0;
	
		HP0 = 140;
		H0 = 140;
	
		ReCC = 1;
	
		XN0 = 0;
		YN0 = 0;
		ZN0 = 0;
	
		XNR = 1.0;
		YNR = 1.0;
		ZNR = 1.0;
	
		R0 = 1;//./707106;
		R1 = 0;//707106;
		R2 = 0;
		R3 = 0;
	
		Lat = 34.666491944;
		Lon = 112.43179857;	
	}
	else if (FlagFireControlMode == MODE_FIRECONTROL_DYNAMIC)
	{
		FC_Time = RFMFireControlDataRx.FC_TimeUS;

		// �������ٶ��������������ϵ�ϵ�ͶӰ
		GX =  RFMFireControlDataRx.FcsGravity[0][0];
		GY =  RFMFireControlDataRx.FcsGravity[1][0];
		GZ =  RFMFireControlDataRx.FcsGravity[2][0];
	
		// �ػ������ٶ��������������ϵ�ϵ�ͶӰ
		VNX = RFMFireControlDataRx.FcsVel[0][0];
		VNY = RFMFireControlDataRx.FcsVel[1][0];
		VNZ = RFMFireControlDataRx.FcsVel[2][0];
		
		HP0 = RFMFireControlDataRx.CraftAltitude;
		H0  = RFMFireControlDataRx.CraftAltitude;	

		ReCC = 1;   
		
		// �ػ�����λ���������������ϵ�ϵ�ͶӰ
		XN0 = RFMFireControlDataRx.FcsPos[0][0];
		YN0 = RFMFireControlDataRx.FcsPos[1][0];
		ZN0 = RFMFireControlDataRx.FcsPos[2][0];
		
		// �����ҵ��ڵ�������ϵ�е�ͶӰ
		XNR = 0.334;//RFMFireControlDataRx.MissileMountPosition[0][0];
		YNR = 0;//RFMFireControlDataRx.MissileMountPosition[1][0];
		ZNR = 0;//RFMFireControlDataRx.MissileMountPosition[2][0];
	
		// ��Ԫ��
		R0 = RFMFireControlDataRx.FcsQtn[0][0];
		R1 = RFMFireControlDataRx.FcsQtn[1][0];
		R2 = RFMFireControlDataRx.FcsQtn[2][0];
		R3 = RFMFireControlDataRx.FcsQtn[3][0];
	
		Lat = RFMFireControlDataRx.FcsLatitude;
		Lon = RFMFireControlDataRx.FcsLongitude;

	/*		
		GX= 0.0;
		GY = -9.7959;
		GZ = 0;
	
		VNX = 1000;
		VNY = 0.0;
		VNZ = 0.0;
	
		HP0 = 140;
		H0 = 140;
	
		ReCC = 1;
	
		XN0 = 0;
		YN0 = 0;
		ZN0 = 0;
	
		XNR = 1.0;
		YNR = 1.0;
		ZNR = 1.0;
	
		R0 = 1;//./707106;
		R1 = 0;//707106;
		R2 = 0;
		R3 = 0;
	
		Lat = 34.666491944;
		Lon = 112.43179857;	
	*/	
	}
	return 0;
}

//��ʼ��
int fc1553Init()
{
	int i, j;
	
	// 1553 board parameters
	PS_DevInfoHandle  pDevs = NULL;
	int countOfCards = 0;
	
	// Message data
	MSG_RECEIVE BCmsgReceive;
	MSG_RECEIVE RTmsgReceive;
	uInt16 Vector_code;
	
	// Init 1553
	P3530_ScanDevices(&pDevs, &countOfCards);
	P3530_OpenDevice(pDevs, &PS3531_hDev);
	P3530_ReleaseDevInfo(pDevs);
	
	// ����ʱ��
	if(Ali_Time == 0 )
		TATime = (int)(20 / 0.040); // ����δ��������Ĭ��Ϊ20s
	else
		TATime = (int)(Ali_Time / 0.040); // Ali_Times �����·���
	
	printf("TATime = %lld\n", TATime);
	
	CountTest = 0;
	Counter30R = 10;

	//��ʼ��ʱ�����
	Init_Date_Time();
	
	// ��ȡ��������
	fc1553Test();

	// ��ʼ���ɻ�����
	Init_PlaneDescrib_1R();
	
	// Send 1R
	CmdBc2RtMsg(PS3531_hDev, &BCmsgReceive, 0x320, 0x18, 1, 30, FireCtrl_PlaneDescribeData_1R);
	Delay(0.1);
	
	// Record 1R sent data
	fc1553Record("1R", FireCtrl_PlaneDescribeData_1R);
	
	// Require 1T in vector
	i = 0;
	while(1)
	{
		CmdQuery1553bVectorCode(PS3531_hDev, &Vector_code, 0x320, 0x18);
		if((Vector_code & 0x0001) == 0x0001)
		{
			// Read 1T
			CmdRt2BcMsg(PS3531_hDev, &RTmsgReceive, 0x320, 0x18, 1, 30);
		
			// Record 1T received data
			fc1553Record("1T", RTmsgReceive.msgBlock + OFFSET_FC1553);
			
            printf("Fire Control 1553: 1T success!\n");
			break;
		}
		else if (i++ == 5)
		{
			printf("Fire Control 1553: 1T vector code error! %04x\n", Vector_code);
			break;
		}
		Delay(0.02);
	}
	
	//2R��Ʒ׼��
	Init_2R_Data(FireCtrl_MissileCtrlData_2R, 1);
	
	// Send 2R
	CmdBc2RtMsg(PS3531_hDev, &BCmsgReceive, 0x320, 0x18, 2, 30, FireCtrl_MissileCtrlData_2R);
	Delay(1);
	
	// Record 2R sent data
	fc1553Record("2R", FireCtrl_MissileCtrlData_2R);
	
	//4Rװ����Ϣ
	Init_Missile_Load_Data4R(FireCtrl_Data_4R); 	
	
	// Send 4R
	CmdBc2RtMsg(PS3531_hDev, &BCmsgReceive, 0x320, 0x18, 4, 30, FireCtrl_Data_4R);
	
	// Record 4R sent data
	fc1553Record("4R", FireCtrl_Data_4R);

	// Require 2T in vector 
	i = 0;
	while(1)
	{
		//���ͷ�ʽ����
		CmdQuery1553bVectorCode(PS3531_hDev, &Vector_code, 0x320, 0x18); 	
		if((Vector_code & 0x0002) == 0x0002)
		{
			printf("Fire Control 1553: 2T success!\n"); 
			
			// Read 2T
			CmdRt2BcMsg(PS3531_hDev, &RTmsgReceive, 0x320, 0x18, 2, 30);
		
			// Record 2T received data
			fc1553Record("2T", RTmsgReceive.msgBlock + OFFSET_FC1553);
			
			break;
		}
		else if (i++ == 5)
		{
			printf("Fire Control 1553: 2T vector code error! %04x\n", Vector_code);
			break;
		}
		Delay(1);
	}
	
	return 0;
}

//Close 1553
int fc1553CleanUp()
{
	P3530_CloseDevice(PS3531_hDev);
	return 0;
}

//��ʼ��ز���
int fc1553Start(void)
{
	// Enable data file record at first
	FlagRecordFC1553 = FILE_RECORD_START;
	
	// ���������ʼ��
	IO_ElectroDiscrete (&ParamIO, IO_RELAY_CONNECT);
	
	fc1553Init();

	TimerIdFC1553 = NewAsyncTimer (0.040, -1, 0, TimerFC1553, 0);
	
	TimerIdFC1553_30R = NewAsyncTimer (0.4, -1, 0, TimerFC1553_30R, 0);  
	
	SetAsyncTimerAttribute (TimerIdFC1553, ASYNC_ATTR_ENABLED, 1);  
	
	Delay(0.2);
	
//	SetAsyncTimerAttribute (TimerIdFC1553_30R, ASYNC_ATTR_ENABLED, 1);
	
	printf("Fire Control 1553: Start success!\n");	

	return 0;
}

//ֹͣ��ز���
int fc1553Stop(void)
{
   	SetAsyncTimerAttribute (TimerIdFC1553, ASYNC_ATTR_ENABLED, 0);
	DiscardAsyncTimer(TimerIdFC1553);	
		
	SetAsyncTimerAttribute (TimerIdFC1553_30R, ASYNC_ATTR_ENABLED, 0);
	DiscardAsyncTimer(TimerIdFC1553_30R);	
	
	fc1553CleanUp();
	
	// Disable data file record
	FlagRecordFC1553 = FILE_RECORD_STOP;

	printf("Fire Control 1553: Stop success!\n");	
	
	return 0;
}

//1553B ��ز��Զ�ʱ�� 40ms����һ��
int CVICALLBACK TimerFC1553(int reserved, int timerId, int event, void *callbackData, int eventData1, int eventData2)
{
	int i, j;
	int k = 0;
	
	// Message data
	MSG_RECEIVE BCmsgReceive;
	MSG_RECEIVE RTmsgReceive; 
	uInt16 Vector_code;
	
	if (event == EVENT_TIMER_TICK)
	{
		SetProcessorAffinityForThread (kProcessorPool_None, 1, NULL, NULL); 	
		//��̬���鲻��Ҫ�жϻ�������Ƿ��ȡ���
		if(FlagFireControlMode == MODE_FIRECONTROL_STATIC) 
			RFM_ReadOver_Flag = 1;
		
		while(RFM_ReadOver_Flag == 0)
		{
			if(k >= 3)
				break;
			SleepUS(10);
			k++;
		}
		
		if(RFM_ReadOver_Flag == 1)
		{
/*==========================10R============================*/		
			fc1553Test();

			//��ʼ��10R��Ϣ
			Init_Missile_Load_Data10R(FireCtrl_Data_10R); 	
		
			// ����10R
			CmdBc2RtMsg(PS3531_hDev, &BCmsgReceive, 0x320, 0x18, 10, 30, FireCtrl_Data_10R);
		
			// Record 10R sent data
			fc1553Record("10R", FireCtrl_Data_10R);
		
/*==========================30R============================*/
			if(Counter30R == 15)
			{
				//30R ÿ400ms����һ��
				Init_Missile_Load_Data30R(FireCtrl_Data_30R);	

				// Send 30R
				CmdBc2RtMsg(PS3531_hDev, &BCmsgReceive, 0x320, 0x18, 30, 30, FireCtrl_Data_30R); 	

				// Record 30R sent data
				fc1553Record("30R", FireCtrl_Data_30R);	
			
				Counter30R = 0;
			}
			Counter30R++;
/*=========================================================*/			
			//��ʱTATime ������������
			++ CountTest;

			if ((CountTest - 1) == TATime)
			{  	
				//��ȡʸ����
				CmdQuery1553bVectorCode(PS3531_hDev, &Vector_code, 0x320, 0x18); 
			
				if((Vector_code & 0x0002) == 0x0002)
				{
					printf("Fire Control 1553: 2T success!\n");
				
					// Read 2T
					CmdRt2BcMsg(PS3531_hDev, &RTmsgReceive, 0x320, 0x18, 2, 30);
				
					// Record 2T received data
					fc1553Record("2T", RTmsgReceive.msgBlock + OFFSET_FC1553);
				
					//11R��Ʒ����ָ��
					if((RTmsgReceive.msgBlock[4 + OFFSET_FC1553] & 0x3000) == 0x3000 || (RTmsgReceive.msgBlock[4 + OFFSET_FC1553] & 0x3000) == 0x1000)
					{
						Missile_Ctrl_11R(FireCtrl_Data_11R, 1);
					
						// Send 11R
						CmdBc2RtMsg(PS3531_hDev, &BCmsgReceive, 0x320, 0x18, 11, 30, FireCtrl_Data_11R);
						Delay(0.015);
					
						// Record 11R sent data
						fc1553Record("11R", FireCtrl_Data_11R);
					
						CmdQuery1553bVectorCode(PS3531_hDev, &Vector_code, 0x320, 0x18);
					
						if((Vector_code & 0x0400) == 0x0400)
						{
							// Read 11T
							CmdRt2BcMsg(PS3531_hDev, &RTmsgReceive, 0x320, 0x18, 11, 30);
						
							// Record 11T received data
							fc1553Record("11T", RTmsgReceive.msgBlock + OFFSET_FC1553);
				
							if(RTmsgReceive.msgBlock[0 + OFFSET_FC1553] == 0x0420 || (RTmsgReceive.msgBlock[3 + OFFSET_FC1553] & 0x8400) == 0x8400)
							{
								
								//���͵�������ָ��
								IO_ElectroDiscrete (&ParamIO, IO_RELAY_DISCRETE);
								
								DataRT.state = PROGRAM_STATE;
								DataRT.program_status =  ElectroDiscrete;
								Update();
							
								printf("Fire Control 1553: Electric disconnect!\n");
							}
							else
							{
								printf("Fire Control 1553: Missile launch failed! %04x\n", RTmsgReceive.msgBlock[4]);
							}
						}
						else
						{
							printf("Fire Control 1553: 11T vector code error! %04x\n", Vector_code);
						}
					}
					else
					{
						printf("Fire Control 1553: 2T received data error! %04x\n", RTmsgReceive.msgBlock[7]);	
					}
				}
				else
				{
					printf("Fire Control 1553: 2T vecter code error! %04x\n", Vector_code);
				}
			} // if ((CountTest - 1) == TATime)		
		}//if (FlagFireControlMode == MODE_FIRECONTROL_STATIC)
		else
			printf("Frame lost & RFM_ReadOver_Flag = %d.\n",  RFM_ReadOver_Flag); 
	}// if (event == EVENT_TIMER_TICK)   
	return 0;
}


int CVICALLBACK TimerFC1553_30R(int reserved, int timerId, int event, void *callbackData, int eventData1, int eventData2)   
{
	// Message data
	MSG_RECEIVE BCmsgReceive30R;
	MSG_RECEIVE RTmsgReceive30R; 
	if (event == EVENT_TIMER_TICK)
	{
//		SetProcessorAffinityForThread (kProcessorPool_None, 1, NULL, NULL); 
		
		//30R ÿ400ms����һ��
		Init_Missile_Load_Data30R(FireCtrl_Data_30R);	

		// Send 30R
		CmdBc2RtMsg(PS3531_hDev, &BCmsgReceive30R, 0x320, 0x18, 30, 30, FireCtrl_Data_30R); 	

		// Record 30R sent data
		fc1553Record("30R", FireCtrl_Data_30R);	
	}	
	return 0;
}

















