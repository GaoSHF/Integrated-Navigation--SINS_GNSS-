
#ifndef _SELFTEST_H_
#define _SELFTEST_H_


int selftest_GERFM();
int selftest_429();
int selftest_422();
int selftest_1553B();
int module_selftest(void);

#endif 
