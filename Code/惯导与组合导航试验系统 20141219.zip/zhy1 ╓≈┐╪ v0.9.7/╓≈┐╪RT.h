#ifndef _ZKRT_H_
#define _ZKRT_H_

FILE *FileHandleLenthTest; 

#endif
