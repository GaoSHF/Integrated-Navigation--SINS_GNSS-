#include "common.h"  
#include "rfm.h"

void PPS_Interrupt_Nav(unsigned long long Time_PPS);

void FC_Interrupt_Nav(RFM_FireControl_Data FireControl_Nav);  

void IMU_Interrupt_Nav(IMU_Data IMU_Nav); 

void Sat_Interrupt_Nav(Sat_Data Sat_Nav);  
							   
