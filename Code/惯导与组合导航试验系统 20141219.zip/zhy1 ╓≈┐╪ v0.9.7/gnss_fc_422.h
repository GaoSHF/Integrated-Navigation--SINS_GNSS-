//==============================================================================
//
// Title:       gnss_fc_422.h
// Purpose:     A short description of the interface.
//
// Created on:  2014/1/21 at 11:41:09 by ZhaoHengyang.
// Copyright:   Beihang University. All Rights Reserved.
//
//==============================================================================

#ifndef __gnss_fc_422_H__
#define __gnss_fc_422_H__

#ifdef __cplusplus
    extern "C" {
#endif

//==============================================================================
// Include files

#include "cvidef.h"
		
#include "RS422.h"

//==============================================================================
// Constants

//==============================================================================
// Types

//==============================================================================
// External variables
extern RS422_DevHandle DeviceHandleGPS422;
		
		
//==============================================================================
// Global functions
int gnssfc422StartReceive(void); 
int gnssfc422StopReceive(void);

		

#ifdef __cplusplus
    }
#endif

#endif  /* ndef __gnss_fc_422_H__ */
