#include "RS422.h"



int RS422_OpenConfig(RS422_DevHandle hDev)
{
	int status;
	if(hDev.comValue > DEV_NUM)
	{
		return FALSE;
	}
	status = OpenComConfig (hDev.comValue,"",hDev.bps,hDev.check,hDev.data,hDev.stop,4096,4096);
	if(status!=0)
	{
		return FALSE;
	}
	else
	{
		FlushInQ(hDev.comValue);
		FlushOutQ(hDev.comValue);
	}
	return TRUE;
}


int RS422_Close(RS422_DevHandle hDev)
{
	CloseCom (hDev.comValue); 
	return TRUE;
}
