/**************************************************************************/
/* LabWindows/CVI User Interface Resource (UIR) Include File              */
/* Copyright (c) National Instruments 2014. All Rights Reserved.          */
/*                                                                        */
/* WARNING: Do not add to, delete from, or otherwise modify the contents  */
/*          of this include file.                                         */
/**************************************************************************/

#include <userint.h>

#ifdef __cplusplus
    extern "C" {
#endif

     /* Panels and Controls: */

#define  PANELANA                         1
#define  PANELANA_COMMANDBUTTON_QUIT      2       /* callback function: QUIT_TestAnalysis */
#define  PANELANA_COMMANDBUTTON_GNSS      3       /* callback function: TestAnalysis_GNSS */
#define  PANELANA_COMMANDBUTTON_FC        4       /* callback function: TestAnalysis_FC */
#define  PANELANA_COMMANDBUTTON_IMU       5       /* callback function: TestAnalysis_IMU */
#define  PANELANA_COMMANDBUTTON_GNSTest   6       /* callback function: Read_GNSS_Test */
#define  PANELANA_COMMANDBUTTON_FCTest    7       /* callback function: Read_FC_Test */
#define  PANELANA_COMMANDBUTTON_IMUTest   8       /* callback function: Read_IMU_Test */
#define  PANELANA_GNSSTest_Read           9
#define  PANELANA_FCTest_Read             10
#define  PANELANA_COMMANDBUTTON_IMUSim    11      /* callback function: Read_IMU_Simulation */
#define  PANELANA_DECORATION_15           12
#define  PANELANA_DECORATION_14           13
#define  PANELANA_IMUTest_Read            14
#define  PANELANA_IMUSimulation_Read      15
#define  PANELANA_VelZ                    16
#define  PANELANA_VelY                    17
#define  PANELANA_Pitch                   18
#define  PANELANA_Roll                    19
#define  PANELANA_Yaw                     20
#define  PANELANA_VelX                    21
#define  PANELANA_PosZNav                 22
#define  PANELANA_PosYNav                 23
#define  PANELANA_PosXNav                 24


     /* Menu Bars, Menus, and Menu Items: */

          /* (no menu bars in the resource file) */


     /* Callback Prototypes: */

int  CVICALLBACK QUIT_TestAnalysis(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK Read_FC_Test(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK Read_GNSS_Test(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK Read_IMU_Simulation(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK Read_IMU_Test(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK TestAnalysis_FC(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK TestAnalysis_GNSS(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK TestAnalysis_IMU(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);


#ifdef __cplusplus
    }
#endif
