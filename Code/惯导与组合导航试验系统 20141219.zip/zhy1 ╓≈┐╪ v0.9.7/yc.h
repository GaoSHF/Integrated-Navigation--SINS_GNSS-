//==============================================================================
//
// Title:       yc.h
// Purpose:     A short description of the interface.
//
// Created on:  2014/1/21 at 15:31:32 by ZhaoHengyang.
// Copyright:   Beihang University. All Rights Reserved.
//
//==============================================================================

#ifndef __yc_H__
#define __yc_H__

#ifdef __cplusplus
    extern "C" {
#endif

//==============================================================================
// Include files

#include "cvidef.h"

//==============================================================================
// Constants
#define	YC_LENGTH_BYTE		512
		
//==============================================================================
// Types

//==============================================================================
// External variables
extern FILE *FileHandleRTYC;

extern int FlagRecordYC;

extern long long CountInYC;
extern long long CountOutYC;

extern long long IndexInYC;
extern long long IndexOutYC;
	
//==============================================================================
// Global functions
int ycStartReceive(void);
int ycStopReceive(void);


#ifdef __cplusplus
    }
#endif

#endif  /* ndef __yc_H__ */
