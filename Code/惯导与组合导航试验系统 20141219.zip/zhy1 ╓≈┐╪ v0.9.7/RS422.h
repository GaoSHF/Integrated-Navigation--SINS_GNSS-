#ifndef _RS422_H_
#define _RS422_H_

#include <rs232.h> 

#define TRUE    1
#define FALSE   0

#define START128_COMMAND	0x31
#define START256_COMMAND	0x32
#define STOPSERIAL_COMMAND		0x33

#define COM1    1
#define COM2    2
#define COM3    3
#define COM4    4
#define COM5    5
#define COM6    6
#define COM7    7
#define COM8    8
#define COM9    9

#define YC_SERIAL_BPS 1000000
#define GPS_SERIAL_BPS 115200

#define SERIAL_BPS 1000000

#define NOPARITY  0
#define ODDPARITY  1
#define EVENPARITY  2 
//			Parity ��żУ�鷽ʽ
//			   0 ---- ��У��(Ĭ��)
//			   1 ---- ��У�� 
//			   2 ---- żУ��

#define DEV_NUM  9

typedef struct
{
	int comValue;	
	int bps;
	char check;
	char data; 
	char stop; 
	char revData[4096];
	char sendData[256];
}RS422_DevHandle;



int RS422_OpenConfig(RS422_DevHandle hDev);
int RS422_Close(RS422_DevHandle hDev);










































#endif

