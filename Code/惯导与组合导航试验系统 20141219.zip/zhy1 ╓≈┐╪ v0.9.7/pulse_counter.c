#include <rs232.h>
#include <utility.h>
#include <ansi_c.h> 
#include <rtutil.h>
#include <userint.h> 
#include <ansi_c.h>

#include "RS422.h"
#include "common.h"
#include "rfm.h"
#include "Navigation.h" 

FILE *FileHandleRTPulse = NULL; 
FILE *FileHandleRTRAM = NULL;  

RS422_DevHandle DeviceHandle422CmdRAM;
RS422_DevHandle DeviceHandle422Pulse;

int FlagRecordPulse = FILE_RECORD_INACTIVE; // Enable record flag

long long CountInPulse = 0;
long long CountOutPulse = 0;

long long IndexInPulse = 0;
long long IndexOutPulse = 0;


static int ThreadFunctionIDPulse = 0;

int FlagExitThreadPulse = 0;

int FlagFirstDataPulse = 0;
double TimeFirstPulse = 0;
double TimeMS = 0;

int CountMax = 0;

IMU_Data PulseData;

static unsigned char rev_Data[4096] = {0};		//��ʱ���ݽ���

static unsigned long laxp =0;
static unsigned long laxn =0; 
static unsigned long layp =0; 
static unsigned long layn =0; 
static unsigned long lazp =0; 
static unsigned long lazn =0; 

static unsigned long asxp =0;
static unsigned long asxn =0; 
static unsigned long asyp =0; 
static unsigned long asyn =0; 
static unsigned long aszp =0; 
static unsigned long aszn =0; 

static unsigned int CountPulse = 0;

//IMU���ݽ����߳�
static int CVICALLBACK ThreadFunctionPulse(void *functionData)
{
	int i;
	long long PulseTimeUS;
	
	while (!FlagExitThreadPulse)
    {
       	if (GetInQLen(DeviceHandle422Pulse.comValue) >= 24)
		{  
			PulseTimeUS = GetTimeUS();  

			for(i = 0; i < 24; i++)
			{			
				//�����ֽڶ�  
				rev_Data[i] = ComRdByte(DeviceHandle422Pulse.comValue);
			}
		
			TimeMS = (double)PulseTimeUS  / 1000.0;
			
			// First data
			if (FlagFirstDataPulse == 0)
			{
				FlagFirstDataPulse = 1;
				TimeFirstPulse = TimeMS;
			}
			
//			(DataTemp + IndexInPulse)->pulse_time = (TimeMS - TimeFirstPulse) / 1000.0; // s
			(DataTemp + IndexInPulse)->pulse_time = TimeMS; //ms
			
			// Decode data
			(DataTemp + IndexInPulse)->asxp = ((unsigned long)(rev_Data[0])<<8) + rev_Data[1];
			(DataTemp + IndexInPulse)->asxn = ((unsigned long)(rev_Data[2])<<8) + rev_Data[3];
			(DataTemp + IndexInPulse)->asyp = ((unsigned long)(rev_Data[4])<<8) + rev_Data[5];
			(DataTemp + IndexInPulse)->asyn = ((unsigned long)(rev_Data[6])<<8) + rev_Data[7];
			(DataTemp + IndexInPulse)->aszp = ((unsigned long)(rev_Data[8])<<8) + rev_Data[9];
			(DataTemp + IndexInPulse)->aszn = ((unsigned long)(rev_Data[10])<<8) + rev_Data[11];
		
			(DataTemp + IndexInPulse)->laxp = rev_Data[13];
			(DataTemp + IndexInPulse)->laxn = rev_Data[15];
			(DataTemp + IndexInPulse)->layp = rev_Data[17];
			(DataTemp + IndexInPulse)->layn = rev_Data[19];
			(DataTemp + IndexInPulse)->lazp = rev_Data[21];
			(DataTemp + IndexInPulse)->lazn = rev_Data[23];
			
			// Get fire control data from RFM board
			(DataTemp + IndexInPulse)->TraceTime = RFMFireControlDataRx.TraceTime;
			
			(DataTemp + IndexInPulse)->CraftPosition[0] = RFMFireControlDataRx.CraftPosition[0][0];
			(DataTemp + IndexInPulse)->CraftPosition[1] = RFMFireControlDataRx.CraftPosition[1][0];
			(DataTemp + IndexInPulse)->CraftPosition[2] = RFMFireControlDataRx.CraftPosition[2][0];
			
			(DataTemp + IndexInPulse)->CraftGPulseOut[0] = RFMFireControlDataRx.CraftGPulseOut[0][0];
			(DataTemp + IndexInPulse)->CraftGPulseOut[1] = RFMFireControlDataRx.CraftGPulseOut[1][0];
			(DataTemp + IndexInPulse)->CraftGPulseOut[2] = RFMFireControlDataRx.CraftGPulseOut[2][0];
			
			(DataTemp + IndexInPulse)->CraftFPulseOut[0] = RFMFireControlDataRx.CraftFPulseOut[0][0];
			(DataTemp + IndexInPulse)->CraftFPulseOut[1] = RFMFireControlDataRx.CraftFPulseOut[1][0];
			(DataTemp + IndexInPulse)->CraftFPulseOut[2] = RFMFireControlDataRx.CraftFPulseOut[2][0];
			
			// DataRT accumulation
			asxp = asxp + (DataTemp + IndexInPulse)->asxp;
			asxn = asxn + (DataTemp + IndexInPulse)->asxn;
			asyp = asyp + (DataTemp + IndexInPulse)->asyp;
			asyn = asyn + (DataTemp + IndexInPulse)->asyn;
			aszp = aszp + (DataTemp + IndexInPulse)->aszp;
			aszn = aszn + (DataTemp + IndexInPulse)->aszn;
			
			laxp = laxp + (DataTemp + IndexInPulse)->laxp;
			laxn = laxn + (DataTemp + IndexInPulse)->laxn;
			layp = layp + (DataTemp + IndexInPulse)->layp;
			layn = layn + (DataTemp + IndexInPulse)->layn;
			lazp = lazp + (DataTemp + IndexInPulse)->lazp;
			lazn = lazn + (DataTemp + IndexInPulse)->lazn;
			
			//ʵʱ��ϵ���IMU����
			PulseData.Time_Pulse = PulseTimeUS;
			PulseData.asxn = asxp;
			PulseData.asxn = asxn;
			PulseData.asyp = asyp;
			PulseData.asyn = asyn;
			PulseData.aszp = aszp;
			PulseData.aszn = aszn;
			PulseData.laxp = laxp;
			PulseData.laxn = laxn;
			PulseData.layp = layp;
			PulseData.layn = layn;
			PulseData.lazp = lazp;
			PulseData.lazn = lazn;
			
			IMU_Interrupt_Nav(PulseData);
			
			// 200 * 5ms = 1s
			CountPulse++;
			if(CountPulse >= CountMax)
			{
				(DataTemp + IndexInPulse)->accumGxp = asxp;
				(DataTemp + IndexInPulse)->accumGxn = asxn;	   					
				(DataTemp + IndexInPulse)->accumGyp = asyp;
				(DataTemp + IndexInPulse)->accumGyn = asyn;
				(DataTemp + IndexInPulse)->accumGzp = aszp;
				(DataTemp + IndexInPulse)->accumGzn = aszn;
				
				(DataTemp + IndexInPulse)->accumAxp = laxp;
				(DataTemp + IndexInPulse)->accumAxn = laxn;
				(DataTemp + IndexInPulse)->accumAyp = layp;
				(DataTemp + IndexInPulse)->accumAyn = layn;
				(DataTemp + IndexInPulse)->accumAzp = lazp;
				(DataTemp + IndexInPulse)->accumAzn = lazn;
				
				(DataTemp + IndexInPulse)->flagPulseAccum = 1;
			
				CountPulse=0;
				laxp = 0;
				laxn = 0; 
				layp = 0; 
				layn = 0; 
				lazp = 0; 
				lazn = 0; 
			
				asxp = 0;
				asxn = 0; 
				asyp = 0; 
				asyn = 0; 
				aszp = 0; 
				aszn = 0;
			}
			else
			{
				(DataTemp + IndexInPulse)->flagPulseAccum = 0;
			}
			
			// FIFO check
			CountInPulse ++;
			IndexInPulse ++;
			if (IndexInPulse >= MEMORY_BANK_SIZE)
				IndexInPulse = 0;
		}
		
		SleepUS(10);
		
	} // while
	
	return 0;
}

//������422�˿ڣ��������弼�������͵Ŀ���ָ��
void pulseStartReceive(void)
{
	int counter_time;
	int i =0;
	int ram_StrLen;
	int ram_flag = 0; 
	static int ram_timeout = 0; 
	unsigned char ram_Data[256]={0};		//��ʱ���ݽ���
	
	printf("Pulse counting board: receive init\n");
	
	// Get counting interval
	counter_time = CmdRT.pulseCountTime;
	
	// Get counting maximum number to accumulate 1s data
	switch(CmdRT.pulseCountTime)
	{
		// 1ms
		case 1:
			CountMax = 1000;
			break;
		// 3ms
		case 2:
			CountMax = 333;
			break;
		// 4ms
		case 3:
			CountMax = 250;
			break;
		// 5ms
		case 4:
			CountMax = 200;
			break;
		default:
			CountMax = 200;
			break;
	}
	
	// Open RAM record file
	FileHandleRTRAM = fopen (FILE_PATH_RT_RAM, "wb");
	
	DeviceHandle422CmdRAM.bps = SERIAL_BPS;
	DeviceHandle422CmdRAM.comValue = COM3;
	DeviceHandle422CmdRAM.check = NOPARITY;
	DeviceHandle422CmdRAM.data = 8;
	DeviceHandle422CmdRAM.stop = 1;
	DeviceHandle422Pulse.bps = SERIAL_BPS;
	DeviceHandle422Pulse.comValue = COM4;
	DeviceHandle422Pulse.check = NOPARITY;
	DeviceHandle422Pulse.data = 8;
	DeviceHandle422Pulse.stop = 1;
	RS422_Close(DeviceHandle422CmdRAM); 
	RS422_Close(DeviceHandle422Pulse);
	if (!RS422_OpenConfig(DeviceHandle422CmdRAM))
	{
		fclose(FileHandleRTRAM); 
		RS422_Close(DeviceHandle422CmdRAM);
	}
	if (!RS422_OpenConfig(DeviceHandle422Pulse))
	{
		fclose(FileHandleRTRAM);
		RS422_Close(DeviceHandle422Pulse);
	}
	//��λָ��
	ComWrtByte (DeviceHandle422CmdRAM.comValue, 0x09); 
	ComWrtByte (DeviceHandle422CmdRAM.comValue, 0x09);
	Delay(1);
	//��ȡRAMָ�com3���� com3���գ� 
	ComWrtByte (DeviceHandle422CmdRAM.comValue, 0x04); 
	ComWrtByte (DeviceHandle422CmdRAM.comValue, 0x04);
	Delay(1);
	
	// Record RAM data
	while(!ram_flag)
	{
		ram_StrLen=GetInQLen (DeviceHandle422CmdRAM.comValue);
		if(ram_StrLen == 256)
		{
			for(i=0;i<256;i++)
			{			
				//�����ֽڶ�  
				ram_Data[i]=ComRdByte(DeviceHandle422CmdRAM.comValue);
			 
			}
			//fprintf(FileHandleRTRAM,"%d\t", ram_StrLen); 
			for(i=0;i<256;i++)   
			{
				fprintf (FileHandleRTRAM, "%02x\t", ram_Data[i]); 
			} 
			fprintf(FileHandleRTRAM, "\r\n");
			printf("Pulse counting board: read ram ok!\n");
			ram_StrLen=0;
			ram_flag = 1;
		}
		else
		{
			printf("Pulse counting board: read ram error!\n");
			ram_StrLen = 0;
			ram_flag = 1;
		}
		ram_timeout++;
		if(ram_timeout == 500)
			break;
	}  
	
	// Close RAM record file
	fclose (FileHandleRTRAM);
	
	//NewAsyncTimer (0.0001, -1, 1, PulseRev, 0);
	//InstallComCallback (DeviceHandle422CmdRAM.comValue, LWRS_RECEIVE,24, 0, (void *)uartRevPulse, 0);
	//InstallComCallback (DeviceHandle422Pulse.comValue, LWRS_RECEIVE ,256, 0, (void *)uartRevData, 0);
	//ResumeAsyncTimerCallbacks ();
	//�������弼������������
	ComWrtByte (DeviceHandle422CmdRAM.comValue, 0x01); 
	ComWrtByte (DeviceHandle422CmdRAM.comValue, counter_time);
	
	Delay(1);
	
	// Initiate
	laxp = 0;
	laxn = 0; 
	layp = 0; 
	layn = 0; 
	lazp = 0; 
	lazn = 0; 

	asxp = 0;
	asxn = 0; 
	asyp = 0; 
	asyn = 0; 
	aszp = 0; 
	aszn = 0;
	
	// Create receive thread
	CmtScheduleThreadPoolFunction (RT_ThreadPool, ThreadFunctionPulse, NULL, &ThreadFunctionIDPulse);
	FlagExitThreadPulse = 0;
	
	Delay(1);
	//��ʼ����
	ComWrtByte (DeviceHandle422CmdRAM.comValue, 0x02); 
	ComWrtByte (DeviceHandle422CmdRAM.comValue, 0x02);
	
	//InstallComCallback (DeviceHandle422Pulse.comValue, LWRS_RECEIVE, 24, 0, (void *)uartRevPulse, 0);
	 
	FlagFirstDataPulse = 0;
	
	// Enable data file record
	FlagRecordPulse = FILE_RECORD_START;
	
	printf("Pulse counting board: receive start!\n");
	
}

//�ر�����422�˿ڣ��������弼�������͵Ŀ���ָ��
void pulseStopReceive(void)
{
	//ֹͣ����
	ComWrtByte (DeviceHandle422CmdRAM.comValue, 0x03); 
	ComWrtByte (DeviceHandle422CmdRAM.comValue, 0x03);
	
	Delay(1); 
	
	FlagExitThreadPulse = 1;
	CmtScheduleThreadPoolFunction (RT_ThreadPool, ThreadFunctionPulse, NULL, &ThreadFunctionIDPulse);
	CmtReleaseThreadPoolFunctionID (RT_ThreadPool, ThreadFunctionIDPulse);
	
	//SuspendAsyncTimerCallbacks ();
	//RS422_Close(DeviceHandle422CmdRAM);
	//DiscardAsyncTimer (-1);
	RS422_Close(DeviceHandle422CmdRAM);
	RS422_Close(DeviceHandle422Pulse);
	
	// Disable record
	FlagRecordPulse = FILE_RECORD_STOP;
	
	printf("Pulse counting board: receive stop.\n");
}












