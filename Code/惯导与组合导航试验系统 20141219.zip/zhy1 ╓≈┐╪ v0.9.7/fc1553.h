#ifndef _FC1553_H_
#define _FC1553_H_
#include "P3530.h"

#define	OFFSET_FC1553		3

extern int FlagRecordFC1553;

extern long long CountInFC1553;
extern long long CountOutFC1553;

extern long long IndexInFC1553;
extern long long IndexOutFC1553;


extern double Gsuo[3];
extern double Vout[3];
extern double Rout[3];
extern double RRELsuo[3];
extern double QUATsuo[4];
extern double lattemp,lontemp;

extern FILE *FileHandleRTFC1553; //  File handle

extern int FlagFireControlMode; // Flag of fire control mode (Dynamic / Static)


int fc1553Start(void);
int fc1553Stop(void);






#endif 
