#ifndef _PULSE_COUNTER_H_
#define _PULSE_COUNTER_H_

extern int FlagRecordPulse;

extern FILE *FileHandleRTPulse;
extern FILE *FileHandleRTRAM;

extern long long CountInPulse;
extern long long CountOutPulse;

extern long long IndexInPulse;
extern long long IndexOutPulse;


void pulseStopReceive(void);
void pulseStartReceive(void); 



#endif
