//==============================================================================
//
// Title:       IniRTVariable.h
// Purpose:     A short description of the interface.
//
// Created on:  2013-9-24 at 22:15:24 by Yushuang Liu.
// Copyright:   Beihang University. All Rights Reserved.
//
//==============================================================================

#ifndef __InitialVariable_H__
#define __InitialVariable_H__

#include "common.h"

//�ṹ���������
IniParDataMessage CraftPara;       

#endif  /* ndef __IniRTVariable_H__ */
