//==============================================================================
//
// Title:       rfm.c
// Purpose:     A short description of the implementation.
//
// Created on:  2013/12/16 at 10:06:34 by ZhaoHengyang.
// Copyright:   Beihang University. All Rights Reserved.
//
//==============================================================================

//==============================================================================
// Include files

#include <rtutil.h>
#include <utility.h>
#include <ansi_c.h>
#include <visa.h>

#include "common.h"
#include "rfm.h"
#include "ComputeVariable.h"
#include "PanelInputVariable.h"

// Global variables
int RFMMCThreadEnd = 0;

int RFMMCIntRcv = RFM_CMD_MC_NULL;

char DataUInt8Tx[RFM_DATA_UINT8_SIZE] = {2,4,2,3,4,5,6,7,8,9};
char DataUInt8Rx[RFM_DATA_UINT8_SIZE];

RFM_ROTARY_CMD		RFMStructCmd;
RFM_ROTARY_STATUS 	RFMStructStatus;
RFM_FireControl_Data  RFMFireControlDataTx;
RFM_FireControl_Data  RFMFireControlDataRx;

GERFM_DevHandle GERFM_hDev;  //�����еĴ򿪹ⷴ�������õ�GERFM_hDev������
					


//********************************** ת̨���Ʋ��� ***************************************//
//ת̨��������ļ��������ɺ���
unsigned char rfmRotaryParamCheck(int paramLength, unsigned char *param)
{
	int i;
	unsigned char temp = *param;
	
	for (i = 1; i < paramLength; i ++)
	{
		temp ^= *(param + i);	
	}
	
	return temp;
}

//��������������ó�ʼ�Ƕȡ��ٶ�
int rfmRotaryClimb(float *initAngle, float *initRate, float *initAngleGet, float *initRateGet, int step)
{
	long i;
	
	unsigned char *pUChar1, *pUChar2;
	float *pFloat1, *pFloat2;
	float angleGet[3];
	float rateGet[3];
	
	ViUInt32 addr = 0x2000;
	
	/*if (abs(*(initAngle + 0) - angleGet[0]) > 180)
		*(initAngle + 0) = 360 - *(initAngle + 0);
	if (abs(*(initAngle + 1) - angleGet[1]) > 180)
		*(initAngle + 1) = 360 - *(initAngle + 1);
	if (abs(*(initAngle + 2) - angleGet[2]) > 180)
		*(initAngle + 2) = 360 - *(initAngle + 2); */
	
	// Send command
	RFMStructCmd.cmdFlag = 0x55;
	RFMStructCmd.cmdCode = 0x01;
	RFMStructCmd.cmdParamLength = 25;
	
	pUChar1 = (unsigned char *)initAngle;
	pUChar2 = (unsigned char *)initRate;
	
	for (i = 0; i < 12; i ++)
		RFMStructCmd.cmdParam[i] = *(pUChar1 + i);
	
	for (i = 0; i < 12; i ++)
		RFMStructCmd.cmdParam[i + 12] = *(pUChar2 + i);
	
	// Step
	RFMStructCmd.cmdParam[24] = (unsigned char)(step * 10);

	
	RFMStructCmd.cmdParamCheck = rfmRotaryParamCheck(25, RFMStructCmd.cmdParam);
	
	// Write data to RFM
	viMoveOut8 (GERFM_hDev.GERFM_instr, VI_PXI_BAR3_SPACE, addr, RFM_ROTARY_CMD_SIZE, (char*)&RFMStructCmd);  
	
	// Send RFM event
	GERFM_SendEvent(GERFM_hDev, RFM_NODE_ROTARY, addr, RFM2G_NIC_INT1);
	
	// Read status
	i = 0;
	do
	{		
		viMoveIn8 (GERFM_hDev.GERFM_instr, VI_PXI_BAR3_SPACE, addr + 32, RFM_ROTARY_STATUS_SIZE, (char*)&RFMStructStatus);
		if (i++ == 65536)
		{
			printf("Error: Read rotary status over time when climb!\n");
			return 1;
		}
	}while ((RFMStructStatus.statusParam[28 - 4] != 1) && (RFMStructStatus.statusFlag != 0x55));

	// Decode data
	pFloat1 = (float *)RFMStructStatus.statusParam;
	pFloat2 = (float *)(RFMStructStatus.statusParam + 12);
		
	for (i = 0; i < 3; i ++)
		*(initAngleGet + i) = *(pFloat1 + i);
	for (i = 0; i < 3; i ++)
		*(initRateGet + i) = *(pFloat2 + i);

		/**(temp + 0) = RFMStructStatus.statusFlag;
		*(temp + 1) = RFMStructStatus.statusCode;
		*(temp + 2) = RFMStructStatus.statusParamLength;
		*(temp + 3) = RFMStructStatus.statusParamCheck;
		*(temp + 4) = rfmRotaryParamCheck(25, RFMStructStatus.statusParam);
		for (i = 0; i < 28; i ++)
			*(temp + i + 5) = RFMStructStatus.statusParam[i];*/
		
	//if (RFMStructStatus.statusParamCheck != rfmRotaryParamCheck(25, RFMStructStatus.statusParam))
	//	printf("Error: Check rotary status error when climb!\n");
		
	RFMStructStatus.statusFlag = 0xaa;
	viMoveOut8 (GERFM_hDev.GERFM_instr, VI_PXI_BAR3_SPACE, addr + 32, RFM_ROTARY_STATUS_SIZE, (char*)&RFMStructStatus);

	return 0;

}

//���������������ʵʱ�ĽǶȡ��ٶ�
int rfmRotaryTrack(float *angle, float *rate, float *angleGet, float *rateGet)
{
	long i;
	
	unsigned char *pUChar1, *pUChar2;
	float *pFloat1, *pFloat2;
	
	ViUInt32 addr = 0x2000;

	// Send command
	RFMStructCmd.cmdFlag = 0x55;
	RFMStructCmd.cmdCode = 0x02;
	RFMStructCmd.cmdParamLength = 24;
	
	pUChar1 = (unsigned char *)angle;
	pUChar2 = (unsigned char *)rate;
	
	for (i = 0; i < 12; i ++)
		RFMStructCmd.cmdParam[i] = *(pUChar1 + i);
	
	for (i = 0; i < 12; i ++)
		RFMStructCmd.cmdParam[i + 12] = *(pUChar2 + i);
	
	RFMStructCmd.cmdParamCheck = rfmRotaryParamCheck(24, RFMStructCmd.cmdParam); 
	
	// Write data to RFM
	viMoveOut8 (GERFM_hDev.GERFM_instr, VI_PXI_BAR3_SPACE, addr, RFM_ROTARY_CMD_SIZE, (char*)&RFMStructCmd);  
	
	// Send RFM event
	GERFM_SendEvent(GERFM_hDev, RFM_NODE_ROTARY, addr, RFM2G_NIC_INT1);
	
	// Read status
	i = 0;
	do
	{
		viMoveIn8 (GERFM_hDev.GERFM_instr, VI_PXI_BAR3_SPACE, addr + 32, RFM_ROTARY_STATUS_SIZE, (char*)&RFMStructStatus);
		if (i++ == 65536)
		{
			printf("Error: Read rotary status over time when track!\n");
			return 1;
		}
	}while (RFMStructStatus.statusFlag != 0x55);
	

	// Decode data	
	pFloat1 = (float *)RFMStructStatus.statusParam;
	pFloat2 = (float *)(RFMStructStatus.statusParam + 12);
		
	for (i = 0; i < 3; i ++)
		*(angleGet + i) = *(pFloat1 + i);
	for (i = 0; i < 3; i ++)
		*(rateGet + i) = *(pFloat2 + i);
		
		/**(temp + 0) = RFMStructStatus.statusFlag;
		*(temp + 1) = RFMStructStatus.statusCode;
		*(temp + 2) = RFMStructStatus.statusParamLength;
		*(temp + 3) = RFMStructStatus.statusParamCheck;
		*(temp + 4) = rfmRotaryParamCheck(25, RFMStructStatus.statusParam);
		for (i = 0; i < 28; i ++)
			*(temp + i + 5) = RFMStructStatus.statusParam[i];*/
		
	//if (RFMStructStatus.statusParamCheck != rfmRotaryParamCheck(25, RFMStructStatus.statusParam))
	//	printf("Error: Check rotary status error when track!\n");
		
	RFMStructStatus.statusFlag = 0xaa;
	viMoveOut8 (GERFM_hDev.GERFM_instr, VI_PXI_BAR3_SPACE, addr + 32, RFM_ROTARY_STATUS_SIZE, (char*)&RFMStructStatus);
		
	return 0;
}

/*
   ��ȡʵʱ�ĽǶȡ��ٶ�
 */
/*int rfmRotaryReadPV(float *angleGet, float *rateGet)
{
	long i;
	
	float *pFloat1, *pFloat2;
	
	ViUInt32 addr = 0x2000;
	
	// Send command
	RFMStructCmd.cmdFlag = 0x55;
	RFMStructCmd.cmdCode = 0x81;
	RFMStructCmd.cmdParamLength = 0;
	
	viMoveOut8 (GERFM_hDev.GERFM_instr, VI_PXI_BAR3_SPACE, addr, RFM_ROTARY_CMD_SIZE, (char*)&RFMStructCmd);  
	
	GERFM_SendEvent(GERFM_hDev, RFM_NODE_ROTARY, addr, RFM2G_NIC_INT1);
	
	
	
	// Read status
	i = 0;
	do
	{
		viMoveIn8 (GERFM_hDev.GERFM_instr, VI_PXI_BAR3_SPACE, addr + 32, RFM_ROTARY_STATUS_SIZE, (char*)&RFMStructStatus);
		if (i++ == 65536)
		{
			printf("Error: Read rotary status over time when read!\n");
			return 1;
		}
	}while (RFMStructStatus.statusFlag != 0x55);
	
	if (RFMStructStatus.statusParamCheck == rfmRotaryParamCheck(25, RFMStructStatus.statusParam))
	{
		pFloat1 = (float *)RFMStructStatus.statusParam;
		pFloat2 = (float *)(RFMStructStatus.statusParam + 12);
		
		for (i = 0; i < 3; i ++)
			*(angleGet + i) = *(pFloat1 + i);
		for (i = 0; i < 3; i ++)
			*(rateGet + i) = *(pFloat2 + i);
		
		RFMStructStatus.statusFlag = 0xaa;
		viMoveOut8 (GERFM_hDev.GERFM_instr, VI_PXI_BAR3_SPACE, addr + 32, RFM_ROTARY_STATUS_SIZE, (char*)&RFMStructStatus);

		return 0;
	}
	else
	{
		printf("Error: Check rotary status error when read!\n");
		return 1;
	}
}*/



//***************************** ���ء�����ͨѶ���� **************************//

//���˷����ڴ濨INT3�жϻص�����
ViStatus _VI_FUNCH rfmInt(ViSession vi , ViEventType eventType ,ViEvent ctx ,ViAddr userHdlr)
{
	ViUInt8 Sender_id;
	ViUInt32 Sender_data;
	ViUInt32 Sender_lisr;
	
	viPeek32 (vi,ADD_OFFSET(GERFM_hDev.Map_addr,rfm2g_isd2), &Sender_data);
	viPeek8 (vi, ADD_OFFSET(GERFM_hDev.Map_addr,rfm2g_sid2), &Sender_id); 
	 
	if(Sender_data == RFM_CMD_MC_START)
	{
		//���»��趨�Ķ�׼ʱ��
		printf("Got FC start cmd.\n"); 
		viMoveIn8 (GERFM_hDev.GERFM_instr, VI_PXI_BAR3_SPACE, RFM_CMD_MC_START, 8, (char *)(&Ali_Time)); 
	}
	if(Sender_data == RFM_CMD_MC_STOP)
	{
		printf("Got FC stop cmd.\n");
	}	
	//����ң�ر�־	
	RFMMCIntRcv = Sender_data;  
	
	viOut32(GERFM_hDev.GERFM_instr, VI_PXI_BAR2_SPACE, rfm2g_lisr, 0x4000); 

//	printf("rfm interupt.\n");
	
	return VI_SUCCESS;	
}

//*****************����**********************//

//���¼���������ؼ��������IMU����
int rfmIMU(double *w, double *f)
{
	int status;
	
	RFMFireControlDataTx.wibb[0] = *(w + 0);
	RFMFireControlDataTx.wibb[1] = *(w + 1);
	RFMFireControlDataTx.wibb[2] = *(w + 2);
	
	RFMFireControlDataTx.fb[0] = *(f + 0);
	RFMFireControlDataTx.fb[1] = *(f + 1);
	RFMFireControlDataTx.fb[2] = *(f + 2);
	
	status = GERFM_DMA_Write(GERFM_hDev, RFM_CMD_MC_IMU, (char *)(&RFMFireControlDataTx));  
	
	status = GERFM_SendEvent(GERFM_hDev, RFM_NODE_MC, RFM_CMD_MC_IMU, RFM2G_NIC_INT3);
	
	return 0;
}

//���¼���������ؼ�������ͻ������
int rfmFireControl_Interrupt(void)
{
	int status;
	
	//3R
	RFMFireControlDataTx.CraftNavigationStepSize = CraftNavigationStepSize;   //�ߵ�����ʱ��
	
	RFMFireControlDataTx.FcsVel[0][0] = FcsVel[0][0];  //�ػ������ٶ��������ػ���������ϵ���������ϵ����׼����ϵ���ϵ�ͶӰ
	RFMFireControlDataTx.FcsVel[1][0] = FcsVel[1][0];
	RFMFireControlDataTx.FcsVel[2][0] = FcsVel[2][0];
	
	RFMFireControlDataTx.FcsQtn[0][0] = FcsQtn[0][0];  //����أ���Ԫ�� 
	RFMFireControlDataTx.FcsQtn[1][0] = FcsQtn[1][0];
	RFMFireControlDataTx.FcsQtn[2][0] = FcsQtn[2][0];
	RFMFireControlDataTx.FcsQtn[3][0] = FcsQtn[3][0];
	
	RFMFireControlDataTx.JieHuoJuLi = 0;  //�����ػ����
	
	RFMFireControlDataTx.TeZhongDanDaoJiaoDu = 0;  //���ֵ��������Ƕ�
	
	RFMFireControlDataTx.MissileMountPosition[0][0] = 0;   //�����ҵ�����
	RFMFireControlDataTx.MissileMountPosition[0][0] = 0;   //�����ҵ�����
 	RFMFireControlDataTx.MissileMountPosition[0][0] = 0;   //�����ҵ�����
	
	RFMFireControlDataTx.FcsGravity[0][0] = FcsGravity[0][0];   //����أ��������ٶȣ������������ػ���������ϵ���������ϵ����׼����ϵ���ϵ�ͶӰ
	RFMFireControlDataTx.FcsGravity[1][0] = FcsGravity[1][0];
	RFMFireControlDataTx.FcsGravity[2][0] = FcsGravity[2][0];
	
	RFMFireControlDataTx.FcsLongitude = FcsLongitude;	   //����γ��
	
	RFMFireControlDataTx.FcsLatitude = FcsLatitude;   //��������

	//4R
	RFMFireControlDataTx.FcsPos[0][0] = FcsPos[0][0];	   //�ػ����꣨�ػ��ڻ��ϵ�µ����꣩
	RFMFireControlDataTx.FcsPos[1][0] = FcsPos[1][0];
	RFMFireControlDataTx.FcsPos[2][0] = FcsPos[2][0];	
	
	RFMFireControlDataTx.CraftTragetRange[0][0] = 0;	 //�ػ�-Ŀ����Ծ���
	RFMFireControlDataTx.CraftTragetRange[1][0] = 0;	 //�ػ�-Ŀ����Ծ���
	RFMFireControlDataTx.CraftTragetRange[2][0] = 0;	 //�ػ�-Ŀ����Ծ���
	
	RFMFireControlDataTx.CraftTragetVelocity[0][0] = 0;  //�ػ�-Ŀ������ٶ�
	RFMFireControlDataTx.CraftTragetVelocity[1][0] = 0;  //�ػ�-Ŀ������ٶ�
	RFMFireControlDataTx.CraftTragetVelocity[2][0] = 0;  //�ػ�-Ŀ������ٶ�

	RFMFireControlDataTx.CraftAltitude = FcsAltitude; // �ػ��ر�/���θ߶�
	RFMFireControlDataTx.DuoMianYuPianAngle = 0;   //����Ԥƫ�ǡ�
	RFMFireControlDataTx.DuoMianYuPianTime = 0;	 //����Ԥƫ����ʱ��
	RFMFireControlDataTx.TuoLiGuoZaiTime = 0;		 //�����������ʱ��
	RFMFireControlDataTx.TuoLiGuoZai = 0;			 //�������
	
	//Trace
	RFMFireControlDataTx.TraceTime=TraceTime;
	RFMFireControlDataTx.CraftPosition[0][0]=CraftPosition[0][0];
	RFMFireControlDataTx.CraftPosition[1][0]=CraftPosition[1][0];
	RFMFireControlDataTx.CraftPosition[2][0]=CraftPosition[2][0];
	RFMFireControlDataTx.CraftVelocity[0][0]=CraftVelocity[0][0];
	RFMFireControlDataTx.CraftVelocity[1][0]=CraftVelocity[1][0];
	RFMFireControlDataTx.CraftVelocity[2][0]=CraftVelocity[2][0];
	RFMFireControlDataTx.CraftAcc[0][0]=CraftAcc[0][0];
	RFMFireControlDataTx.CraftAcc[1][0]=CraftAcc[1][0];
	RFMFireControlDataTx.CraftAcc[2][0]=CraftAcc[2][0];
	RFMFireControlDataTx.CraftAttitude[0][0]=CraftAttitude[0][0];
	RFMFireControlDataTx.CraftAttitude[1][0]=CraftAttitude[1][0];
	RFMFireControlDataTx.CraftAttitude[2][0]=CraftAttitude[2][0];
	RFMFireControlDataTx.CraftAttitudeChangeRate[0][0]=CraftAttitudeChangeRate[0][0];
	RFMFireControlDataTx.CraftAttitudeChangeRate[1][0]=CraftAttitudeChangeRate[1][0];
	RFMFireControlDataTx.CraftAttitudeChangeRate[2][0]=CraftAttitudeChangeRate[2][0];

	RFMFireControlDataTx.CraftSFB[0][0]=CraftSFB[0][0];	
	RFMFireControlDataTx.CraftSFB[1][0]=CraftSFB[1][0];	
	RFMFireControlDataTx.CraftSFB[2][0]=CraftSFB[2][0];	
	RFMFireControlDataTx.CraftOmegaiBB[0][0]=CraftOmegaiBB[0][0];	
	RFMFireControlDataTx.CraftOmegaiBB[1][0]=CraftOmegaiBB[1][0];	
	RFMFireControlDataTx.CraftOmegaiBB[2][0]=CraftOmegaiBB[2][0];	
	RFMFireControlDataTx.CraftInsSFs[0][0]=CraftInsSFs[0][0];	
	RFMFireControlDataTx.CraftInsSFs[1][0]=CraftInsSFs[1][0];	
	RFMFireControlDataTx.CraftInsSFs[2][0]=CraftInsSFs[2][0];	
	RFMFireControlDataTx.CraftInsOmegaiBBs[0][0]=CraftInsOmegaiBBs[0][0];	
	RFMFireControlDataTx.CraftInsOmegaiBBs[1][0]=CraftInsOmegaiBBs[1][0];	
	RFMFireControlDataTx.CraftInsOmegaiBBs[2][0]=CraftInsOmegaiBBs[2][0];
	
	RFMFireControlDataTx.CraftFPulseOut[0][0]=CraftFPulseOut[0][0];	
	RFMFireControlDataTx.CraftFPulseOut[1][0]=CraftFPulseOut[1][0];	
	RFMFireControlDataTx.CraftFPulseOut[2][0]=CraftFPulseOut[2][0];	
	RFMFireControlDataTx.CraftGPulseOut[0][0]=CraftGPulseOut[0][0];	
	RFMFireControlDataTx.CraftGPulseOut[1][0]=CraftGPulseOut[1][0];	
	RFMFireControlDataTx.CraftGPulseOut[2][0]=CraftGPulseOut[2][0];	
	
	RFMFireControlDataTx.CraftInsPosition[0][0]=CraftInsPosition[0][0];	
	RFMFireControlDataTx.CraftInsPosition[1][0]=CraftInsPosition[1][0];	
	RFMFireControlDataTx.CraftInsPosition[2][0]=CraftInsPosition[2][0];	
	RFMFireControlDataTx.CraftInsVelocityP[0][0]=CraftInsVelocityP[0][0];	
	RFMFireControlDataTx.CraftInsVelocityP[1][0]=CraftInsVelocityP[1][0];	
	RFMFireControlDataTx.CraftInsVelocityP[2][0]=CraftInsVelocityP[2][0];	
	RFMFireControlDataTx.CraftInsAttitude[0][0]=CraftInsAttitude[0][0];	
	RFMFireControlDataTx.CraftInsAttitude[1][0]=CraftInsAttitude[1][0];	
	RFMFireControlDataTx.CraftInsAttitude[2][0]=CraftInsAttitude[2][0];	
	
	status = GERFM_DMA_Write(GERFM_hDev, RFM_CMD_MC_FIRE_CONTROL, (char *)(&RFMFireControlDataTx));  
	
	status = GERFM_SendEvent(GERFM_hDev, RFM_NODE_MC, RFM_CMD_MC_FIRE_CONTROL, RFM2G_NIC_INT3);
	
	return 0;
}

//��ʼ���ز���
int rfmStartMC(void)
{
	int status;
	
	//if (GERFM_hDev == NULL)
	//	status = GERFM_OpenDevice(&GERFM_hDev);     
	
	//status = GERFM_EnableDMA(&GERFM_hDev, RFM_DATA_UINT8_SIZE, OPERATE_WRITE);  
		
	status = GERFM_DMA_Write(GERFM_hDev, RFM_CMD_MC_START, DataUInt8Tx);  
	
	status = GERFM_SendEvent(GERFM_hDev, RFM_NODE_MC, RFM_CMD_MC_START, RFM2G_NIC_INT3);
	
	return 0;
}

//ֹͣ���ز���
int rfmStopMC(void)
{
	int status;
	
	//if (GERFM_hDev == NULL)
	//	status = GERFM_OpenDevice(&GERFM_hDev);     
	
	//status = GERFM_EnableDMA(&GERFM_hDev, RFM_DATA_UINT8_SIZE, OPERATE_WRITE);  
		
	status = GERFM_DMA_Write(GERFM_hDev, RFM_CMD_MC_STOP, DataUInt8Tx);  
	
	status = GERFM_SendEvent(GERFM_hDev, RFM_NODE_MC, RFM_CMD_MC_STOP, RFM2G_NIC_INT3);
	
	return 0;
}

//Open device
int rfmOpenDev(void)
{
	GERFM_OpenDevice(&GERFM_hDev);
	return 0;
}

//Close device
int rfmCloseDev(void)
{
	GERFM_CloseDevice(&GERFM_hDev);
	return 0;
}

//Enable DMA
int rfmEnableDMA(void)
{														  
	GERFM_EnableDMA(&GERFM_hDev, RFM_DATA_UINT8_SIZE, OPERATE_WRITE);
	return 0;
}

//Disable DMA
int rfmDisableDMA(void)
{
	GERFM_DisableDMA(&GERFM_hDev);
	return 0;
}

//���ع��˷����ڴ濨��ʼ��
int rfmInitMC(void)
{
	int status;
	
	status = GERFM_OpenDevice(&GERFM_hDev);     
	//ʹ�ܹⷴ���ж�2	   
	status = GERFM_EnableEventCallback(&GERFM_hDev, RFM2G_NIC_INT2, rfmInt);
	
	printf("RFM opened with interrupt callback.\n");   

	return 0;
}

//���عرչ��˷����ڴ濨
int rfmCloseMC(void)
{
	int status;
	//�رչⷴ���ж�2
	status = GERFM_DisableEventCallback(GERFM_hDev, RFM2G_NIC_INT2);
	status = GERFM_CloseDevice(&GERFM_hDev);     
	 
	printf("RFM closed.\n");   

	return 0;
}

//���¹��˷����ڴ濨��ʼ��
int rfmInitDS(void)
{
	int status;
	
	status = GERFM_OpenDevice(&GERFM_hDev);
	
	rfmEnableDMA();
	
	printf("RFM opened.\n");   

	return 0;
}

//���¹رչ��˷����ڴ濨
int rfmCloseDS(void)
{
	int status;
	
	rfmDisableDMA();
	
	status = GERFM_CloseDevice(&GERFM_hDev);     
	 
	printf("RFM closed.\n");   

	return 0;
}




