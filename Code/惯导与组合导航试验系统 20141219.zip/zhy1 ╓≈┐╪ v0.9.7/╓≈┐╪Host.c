//==============================================================================
//
// Title:       ���ز���Host
// Purpose:     A short description of the application.
//
// Created on:  2013-7-7 at 14:32:26 by BUAA.
// Copyright:   buaa. All Rights Reserved.
//
//==============================================================================

//==============================================================================
// Include files

#include <rtutil.h>
#include "asynctmr.h"
#include <cvintwrk.h>
#include <rs232.h>
#include <formatio.h>
#include <ansi_c.h> 
#include <cvinetv.h>
#include <cvirte.h> 
#include <userint.h>
#include <tcpsupp.h> 
#include <visa.h>
#include "toolbox.h" 

#include "����Host.h"
#include "���ع߲�Host.h"
#include "���طɿ�Host.h"
#include "WAIT_PANEL.h"
#include "ʵ����������Host.h"

#include "common.h"
#include "GlobalFunction.h"
#include "ComputeVariable.h"
#include "PanelInputVariable_ZHUKONG.h"

FILE *NavDataFileHandle;  


//==============================================================================
// Constants

//==============================================================================
// Types


//==============================================================================
// Static global variables
static int PanelHandle;
static int PanelHandleIM;
static int PanelHandleFC;
static int PanelHandleWait; 
static int TimerHandleWait;
static int PanelHandleTestAnalysis;

double stateSimulationIMUSetFileSelectPopup;
double stateTestIMUSetFileSelectPopup;
double stateTestFCSetFileSelectPopup;
double stateTestGNSSSetFileSelectPopup;

FILE *CraftData_FileHandle = NULL;
FILE *pulse_FileHandle = NULL;
FILE *FC_FileHandle = NULL;
FILE *GNSS_FileHandle = NULL;


char FolderPath[260];

int StatusCheckBoxIM = 0;
int StatusCheckBoxFC = 0;
int StatusCheckBoxTR = 0;  

int StatusPower27V;
int StatusPower5V;

double TimeStartIMimugnss = 0;
double TimeStartIMpulse = 0;
double TimeStartFCfc = 0;
double TimeStartFClvds422 = 0;
int FlagIMimugnss = 0;
int FlagIMpulse = 0;
int FlagFCfc = 0;
int FlagFClvds422 = 0;

int waittimecounter = 0;

int testmodeflag = -1;

//��Դ���
static int ThreadFunctionIdPowerIM_27V = 0;
static int ThreadFunctionIdPowerIM_5V = 0; 
int FlagPowerWatchIM = 0;
int Flag_PowerIM_imu_On = 0;
int Flag_PowerIM_imu_Off = 0;
int Flag_PowerIM_gnss_On = 0;
int Flag_PowerIM_gnss_Off = 0;
int Flag_PowerIM_Board_On = 0;
int Flag_PowerIM_Board_Off = 0;  

static int ThreadFunctionIdPowerFC = 0;
int FlagPowerWatchFC = 0;
int Flag_Power5V4On = 0;
int Flag_Power5V4Off = 0;   
int Flag_Power27On = 0;
int Flag_Power27Off = 0; 

//�ȴ�����־
static int ThreadFunctionIDWait = 0; 
int Flag_wait = 0;
//==============================================================================
// Global variables
//���ڷ���ָ��̶� CRCУ����ֱ����Ϊ���ݷ��� 
unsigned char BufferPowerOn27[8]  ={0x02, 0x05, 0x00, 0x00, 0xFF, 0x00, 0x8C, 0x09};		 //����
unsigned char BufferPowerOff27[8] ={0x02, 0x05, 0x00, 0x00, 0x00, 0x00, 0xCD, 0xF9};         //�ϵ�
unsigned char BufferPowerTest27[8]={0x02, 0x03, 0x00, 0x00, 0x00, 0x02, 0xC4, 0x38}; 		 //�ض���ѹ����

unsigned char BufferPowerOn5V2[8]  ={0x02, 0x05, 0x00, 0x00, 0xFF, 0x00, 0x8C, 0x09};		 
unsigned char BufferPowerOff5V2[8] ={0x02, 0x05, 0x00, 0x00, 0x00, 0x00, 0xCD, 0xF9};       
unsigned char BufferPowerTest5V2[8]={0x02, 0x03, 0x00, 0x00, 0x00, 0x02, 0xC4, 0x38}; 

unsigned char BufferPowerOn5V3[8]  ={0x03, 0x05, 0x00, 0x00, 0xFF, 0x00, 0x8D, 0xD8};		 
unsigned char BufferPowerOff5V3[8] ={0x03, 0x05, 0x00, 0x00, 0x00, 0x00, 0xCC, 0x28};       
unsigned char BufferPowerTest5V3[8]={0x03, 0x03, 0x00, 0x00, 0x00, 0x02, 0xC5, 0xE9}; 

unsigned char BufferPowerOn5V4[8]  ={0x04, 0x05, 0x00, 0x00, 0xFF, 0x00, 0x8C, 0x6F};		 
unsigned char BufferPowerOff5V4[8] ={0x04, 0x05, 0x00, 0x00, 0x00, 0x00, 0xCD, 0x9F};       
unsigned char BufferPowerTest5V4[8]={0x04, 0x03, 0x00, 0x00, 0x00, 0x02, 0xC4, 0x5E}; 

unsigned char BufferPowerRead27[9]={1};
unsigned char BufferPowerRead5V2[9]={1};   
unsigned char BufferPowerRead5V3[9]={1};   
unsigned char BufferPowerRead5V4[9]={1};   

//void InitialPara();

// INS pulse count interval
int IMUSamplingInterval = 0;


// File handle
FILE 	*FileHandleHostGNSS429;
FILE 	*FileHandleHostPulse;
FILE 	*FileHandleHostGNSS429Raw;

FILE 	*FileHandleHostPPS;

FILE 	*FileHandleYC;
FILE 	*FileHandleGNSSFC422;

FILE	*FileHandleHostIMU;

//==============================================================================
// Static functions

/* Function prototypes */
int CVICALLBACK TCPDataCallback (unsigned handle, int xType, int errCode, void *callbackData);

void SelftestFinishCallback(void);
void SetPulseData(void); 
void SetGNSS429Data(void);

void SetPPSData(void);

void SetYCData(void);
void SetGNSSFC422Data(void);
void SetFC1553Data(void);

void CreateFolder(void);

void InitialPara(void);
void InitialVariable(void);

void Powerinit(void);
void Powerclose(void);
int PowerOnIMimu(void);
int PowerOffIMimu(void);
int PowerOnIMgnss(void);
int PowerOffIMgnss(void);
int PowerOnIMpulse(void);
int PowerOffIMpulse(void);

int PowerOnFCfc(void);
int PowerOffFCfc(void);
int PowerOnFClvds422(void);
int PowerOffFClvds422(void);
int GetTraceDataFromDS_Computer(char Path_temp[260]); 

static int CVICALLBACK ThreadFunctionPowerFC(void *functionData); 
//�߲⹲����·��Դ
static int CVICALLBACK ThreadFunctionPowerIM_27V(void *functionData); 
static int CVICALLBACK ThreadFunctionPowerIM_5V(void *functionData); 
//�ȴ�����߳�
static int CVICALLBACK ThreadFunctionWait(void *functionData);   
//main entry
int main (int argc, char *argv[])
{
    int error = 0;
	
	StatusTcpHost = TCP_INVALID_CONNECTION;
	
    /* initialize and load resources */
    nullChk (InitCVIRTE (0, argv, 0));
    errChk (PanelHandle = LoadPanel (0, "����Host.uir", PANEL));

	// Connect TCP at first
	ConnectToTCPServer (&StatusTcpHost, HOST_PORT, RT_ADDRESS, TCPDataCallback, 0, 1000);
	if (StatusTcpHost != TCP_INVALID_CONNECTION)
	{
		SetCtrlVal (PanelHandle, PANEL_STATUS, "TCP Connected!");
		SetCtrlVal (PanelHandle, PANEL_BUTTON_CONNECT, 1);
	}
	
	Powerinit();
	
	CmtNewThreadPool (10, &HOST_ThreadPool);

    errChk (DisplayPanel (PanelHandle));
    errChk (RunUserInterface ());
	
	Powerclose();

	if (HOST_ThreadPool)
		CmtDiscardThreadPool (HOST_ThreadPool);

	if (StatusTcpHost != TCP_INVALID_CONNECTION)
		DisconnectFromTCPServer (StatusTcpHost);
	
Error:
    DiscardPanel (PanelHandle);
    return 0;
}


//������Ӧʱ�����ڵ��ļ���
void CreateFolder(void)
{
	int month;
	int day;  
	int year;  
	int hours;
	int minutes;  
	int seconds;  
	char time[100];
	char dir[200];
	char g_dir[200];
	
	int f_exist;
	
	GetSystemDate (&month, &day, &year);
	GetSystemTime (&hours, &minutes, &seconds);
	sprintf(time,"%04d%02d%02d%02d%02d", year, month, day,hours,minutes);
	Fmt (dir, "%s<%100c", time); 
	f_exist = FileExists("C:\\test",0);
	
	if(f_exist == 0)              //ͬ���ļ��в�����
	{
		MakeDir("C:\\test"); 	  //�����ļ���
		SetDir("C:\\test"); 	  //���ø��ļ���Ϊ��ǰ�����ļ���
		MakeDir(dir);
		SetDir(dir);     
	}
	else		   
	{
		SetDir("C:\\test");       //�����²�ʱ�������ļ���
		Fmt (g_dir, "C:\\test\\");  
		strcat(g_dir,time);
		f_exist = FileExists(g_dir,0); 
		if(f_exist == 0)
		{
			MakeDir(dir);
			SetDir(dir);		
		}
	}
	// Get folder path for FTP operation
	strcpy(FolderPath, "test\\");
	strcat(FolderPath, time);
	strcat(FolderPath, "\\");
}

//��ԴCOM�ڳ�ʼ��
void Powerinit(void)
{
	OpenComConfig (3, "", 19200, 0, 8, 1, 512, 512);  //Com3����27����Դ
	OpenComConfig (4, "", 19200, 0, 8, 1, 512, 512);  //Com4����5����Դ
}

//�رյ�ԴCOM��
void Powerclose(void)
{
	CloseCom (3);
	CloseCom (4);
}

//TCP callback
int CVICALLBACK TCPDataCallback (unsigned handle, int xType, int errCode, 
	void *callbackData)
{
	switch (xType)
    {
        case TCP_CONNECT:

			StatusTcpHost = handle;
			
            break;
        case TCP_DISCONNECT:
			
            StatusTcpHost = TCP_INVALID_CONNECTION;
			SetCtrlVal (PanelHandle, PANEL_STATUS, "TCP Disconnected!");
			SetCtrlVal (PanelHandle, PANEL_BUTTON_CONNECT, 0);
			
            break;
        case TCP_DATAREADY:
			 //��ȡTCP����״̬�ṹ�� ִ����Ӧ����
			ClientTCPRead (StatusTcpHost, &DataHost, sizeof(DataHost), 5000); 
			
			// Selftest
			if (DataHost.state == SELFTEST_STATE)
				SelftestFinishCallback();
			
			// FTP files sending over
			else if (DataHost.state == FTP_STATE)
			{
				Flag_wait = 0; 
				CmtWaitForThreadPoolFunctionCompletion (HOST_ThreadPool, ThreadFunctionIDWait, OPT_TP_PROCESS_EVENTS_WHILE_WAITING);
				CmtReleaseThreadPoolFunctionID (HOST_ThreadPool, ThreadFunctionIDWait);					
				DiscardPanel (PanelHandleWait);		  
			}
			
			// Auto mode
			else if (DataHost.state == AUTO_STATE)
			{
				// Power off IM
				if (DataHost.statusAuto == AUTO_STATUS_IM_OFF)
				{
					if (FlagIMimugnss == 1)
					{
						SetCtrlVal (PanelHandleIM, PANEL_IM_POWERSWITCH, 0); 
						Flag_PowerIM_imu_Off = 1;
						Flag_PowerIM_gnss_Off = 1;
					}
					if (FlagIMpulse == 1)
					{
						SetCtrlVal (PanelHandleIM, PANEL_IM_BOARDPOWERSWITCH, 0); 					
						Flag_PowerIM_Board_Off = 1;   
					}
					SetCtrlAttribute (PanelHandleIM, PANEL_IM_QUITBUTTON, ATTR_DIMMED, 1);
				}
				// Power on IM
				else if (DataHost.statusAuto == AUTO_STATUS_IM_ON)
				{
					if (FlagIMimugnss == 0)
					{
						SetCtrlVal (PanelHandleIM, PANEL_IM_POWERSWITCH, 1);						
						Flag_PowerIM_imu_On = 1;
						Flag_PowerIM_gnss_On = 1;
					}
					if (FlagIMpulse == 0)
					{
						SetCtrlVal (PanelHandleIM, PANEL_IM_BOARDPOWERSWITCH, 1);						
						Flag_PowerIM_Board_On = 1;   
					}
				}
				// Power off FC
				else if (DataHost.statusAuto == AUTO_STATUS_FC_OFF)
				{
					if (FlagFCfc == 1)
					{
						Flag_Power27Off = 1;  
						SetCtrlVal (PanelHandleFC, PANEL_FC_POWERSWITCH, 0);
					}
					if (FlagFClvds422 == 1)
					{
						Flag_Power5V4Off = 1; 
						SetCtrlVal (PanelHandleFC, PANEL_FC_BOARDPOWERSWITCH, 0);
					}
					SetCtrlAttribute (PanelHandleFC, PANEL_FC_QUITBUTTON, ATTR_DIMMED, 1);
				}
				// Power on FC
				else if (DataHost.statusAuto == AUTO_STATUS_FC_ON)
				{
					if (FlagFCfc == 0)
					{
						Flag_Power27On = 1; 
						SetCtrlVal (PanelHandleFC, PANEL_FC_POWERSWITCH, 1);	
					}
					if (FlagFClvds422 == 0)
					{
						Flag_Power5V4On = 1; 
						SetCtrlVal (PanelHandleFC, PANEL_FC_BOARDPOWERSWITCH, 1);	
					}
				}
				else if (DataHost.statusAuto == AUTO_PANEL_RESET)
				{
					if(testmodeflag == MODE_IMU_MESURE)
					{
					  	CmdHost.statusAutostartIM = 0; 
						SetCtrlVal (PanelHandleIM, PANEL_IM_LED3, 0);
					
						SetCtrlVal (PanelHandleIM, PANEL_IM_MODULESWITCH, 0); 
						SetCtrlAttribute (PanelHandleIM, PANEL_IM_GPSBUTTON, ATTR_DIMMED, 0);
						SetCtrlAttribute (PanelHandleIM, PANEL_IM_INSBUTTON, ATTR_DIMMED, 0);
						SetCtrlAttribute (PanelHandleIM, PANEL_IM_STARTBUTTON, ATTR_DIMMED, 0);	   
						SetCtrlAttribute (PanelHandleIM, PANEL_IM_STOPBUTTON, ATTR_DIMMED, 0);
						SetCtrlAttribute (PanelHandleIM, PANEL_IM_SELFTESTBUTTON, ATTR_DIMMED, 0);
						SetCtrlAttribute (PanelHandleIM, PANEL_IM_QUITBUTTON, ATTR_DIMMED, 0);
						SetCtrlAttribute (PanelHandleIM, PANEL_IM_POWERSWITCH, ATTR_DIMMED, 0);
						SetCtrlAttribute (PanelHandleIM, PANEL_IM_BOARDPOWERSWITCH, ATTR_DIMMED, 0);
					}	
					else if(testmodeflag == MODE_FLIGHT_CONTROL)
					{
						CmdHost.statusAutostartFC = 0;
						SetCtrlVal (PanelHandleFC, PANEL_FC_LED3, 0);  
					
						SetCtrlVal (PanelHandleFC, PANEL_FC_MODULESWITCH, 0);
						SetCtrlAttribute (PanelHandleFC, PANEL_FC_GPSBUTTON, ATTR_DIMMED, 0);
						SetCtrlAttribute (PanelHandleFC, PANEL_FC_T1553BUTTON, ATTR_DIMMED, 0);
						SetCtrlAttribute (PanelHandleFC, PANEL_FC_YCBUTTON, ATTR_DIMMED, 0);
						SetCtrlAttribute (PanelHandleFC, PANEL_FC_STARTBUTTON, ATTR_DIMMED, 0);	   
						SetCtrlAttribute (PanelHandleFC, PANEL_FC_STOPBUTTON, ATTR_DIMMED, 0);
						SetCtrlAttribute (PanelHandleFC, PANEL_FC_QUITBUTTON, ATTR_DIMMED, 0);
						SetCtrlAttribute (PanelHandleFC, PANEL_FC_SELFTESTBUTTON, ATTR_DIMMED, 0);
						SetCtrlAttribute (PanelHandleFC, PANEL_FC_POWERSWITCH, ATTR_DIMMED, 0);
						SetCtrlAttribute (PanelHandleFC, PANEL_FC_BOARDPOWERSWITCH, ATTR_DIMMED, 0);	
						
						SetCtrlVal (PanelHandleFC, PANEL_FC_LED9, 0); 
					}
				}
			}
			
			// IM mode
			else if (DataHost.state == PULSE_STATE)
				SetPulseData(); 
			
			else if (DataHost.state == GNSS429_STATE)
			{
				SetGNSS429Data(); 
				SetPPSData();
			}

			// FC mode
			else if (DataHost.state == YC_STATE)
				SetYCData();

			else if (DataHost.state == FCGNSS422_STATE)
				SetGNSSFC422Data();

			else if (DataHost.state == FC1553_STATE)
				SetFC1553Data();
           
			else if (DataHost.state == PROGRAM_STATE)
			{
				if(DataHost.program_status == ElectroDiscrete)
					SetCtrlVal (PanelHandleFC, PANEL_FC_LED9, 1);	
			}
			break;
    }
    
    return 0;
}

//Selftest
void SelftestFinishCallback(void)
{
    int selftest; 
	selftest = DataHost.selftest_status;
	SetCtrlAttribute (PanelHandleIM, PANEL_IM_SELFTESTBUTTON, ATTR_LABEL_TEXT, "ϵͳ�Լ�"); 
	if(selftest == SELFTEST_SUCCESS)
	{
		MessagePopup ("", "�Լ�ɹ���"); 
	}
	else if(selftest == SELFFAIL_GERFM)
	{
		MessagePopup ("ERROR", "�����ڴ濨�Լ�ʧ�ܣ�");
	}
	else if(selftest == SELFFAIL_429)
	{
		MessagePopup ("ERROR", "429���Լ�ʧ�ܣ�");
	}
	else if(selftest == SELFFAIL_422)
	{
		MessagePopup ("ERROR", "422���Լ�ʧ�ܣ�");
	}
/*	else if(selftest == SELFFAIL_1553B)
	{
		MessagePopup ("ERROR", "1553B���Լ�ʧ�ܣ�");
	}	  
*/ 
}


/*******************************   ����Host Panel Callback ****************************/


//Connect target TCP callback
int CVICALLBACK buttonConnect (int panel, int control, int event,
	void *callbackData, int eventData1, int eventData2)
{
	int StateButton = 0;
	
	switch (event)
	{
		case EVENT_COMMIT:
			 
			GetCtrlVal (PanelHandle, PANEL_BUTTON_CONNECT, &StateButton);
			
			if ((StateButton == 0) && (StatusTcpHost != TCP_INVALID_CONNECTION))
			{
				DisconnectFromTCPServer (StatusTcpHost);
				StatusTcpHost = TCP_INVALID_CONNECTION;
				SetCtrlVal (PanelHandle, PANEL_STATUS, "TCP Disconnected!");
			}
			else if ((StateButton == 1) && (StatusTcpHost == TCP_INVALID_CONNECTION))
			{
				ConnectToTCPServer (&StatusTcpHost, HOST_PORT, RT_ADDRESS, TCPDataCallback, 0, 5000);
				if (StatusTcpHost != TCP_INVALID_CONNECTION)
				{
					SetCtrlVal (PanelHandle, PANEL_STATUS, "TCP Connected!");
				}
			}
			
			break;
	}
	return 0;
}

//Start inertial measurement callback
int CVICALLBACK buttonIM (int panel, int control, int event,
	void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:
			testmodeflag = MODE_IMU_MESURE; 

			PanelHandleIM = LoadPanel (PanelHandleIM, "���ع߲�Host.uir", PANEL_IM);

			SetPanelAttribute (PanelHandleIM, ATTR_WINDOW_ZOOM, VAL_MAXIMIZE);
			DisplayPanel(PanelHandleIM);
			
			//��ʼ��λ�����ջ�������߳�
			CmdHost.command = FIRECONTROLDATA_REV_START;
			ClientTCPWrite (StatusTcpHost, &CmdHost, sizeof(CmdHost), 3000);  			
			
			FlagPowerWatchIM = 1;
			CmtScheduleThreadPoolFunction (HOST_ThreadPool, ThreadFunctionPowerIM_27V, NULL, &ThreadFunctionIdPowerIM_27V);	
			CmtScheduleThreadPoolFunction (HOST_ThreadPool, ThreadFunctionPowerIM_5V, NULL, &ThreadFunctionIdPowerIM_5V);	
			break;
	}
	return 0;
}

//Start flight control callback
int CVICALLBACK buttonFC (int panel, int control, int event,
	void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:

			testmodeflag = MODE_FLIGHT_CONTROL; 

			PanelHandleFC = LoadPanel (PanelHandleFC, "���طɿ�Host.uir", PANEL_FC);

			SetPanelAttribute (PanelHandleFC, ATTR_WINDOW_ZOOM, VAL_MAXIMIZE);
			DisplayPanel(PanelHandleFC);
			//��ʼ��λ�����ջ�������߳�
			CmdHost.command = FIRECONTROLDATA_REV_START;
			ClientTCPWrite (StatusTcpHost, &CmdHost, sizeof(CmdHost), 3000);  			
			
			FlagPowerWatchFC = 1;
			CmtScheduleThreadPoolFunction (HOST_ThreadPool, ThreadFunctionPowerFC, NULL, &ThreadFunctionIdPowerFC);				

			break;
	}
	return 0;
}

//Save measurement data from RT control callback
int CVICALLBACK buttonSaveData (int panel, int control, int event,
	void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:
			
			GetCtrlVal (PanelHandle, PANEL_CHECKBOX_IM, &StatusCheckBoxIM);
			GetCtrlVal (PanelHandle, PANEL_CHECKBOX_FC, &StatusCheckBoxFC);
			GetCtrlVal (PanelHandle, PANEL_CHECKBOX_TRACE, &StatusCheckBoxTR); 
			
			// Create folder
			CreateFolder();				
			
			if((StatusCheckBoxIM + StatusCheckBoxFC + StatusCheckBoxTR) > 0)
			{
				Flag_wait = 1;
				//Wait panel refresh thread 
				CmtScheduleThreadPoolFunction (HOST_ThreadPool, ThreadFunctionWait, NULL, &ThreadFunctionIDWait);			
			}

			//Load wait panel
			PanelHandleWait = LoadPanel (0, "WAIT_PANEL.uir", WAIT_PANEL);
			
			if(StatusCheckBoxTR != 0)
			{
				InstallPopup (PanelHandleWait);   
				//Retrieve trace data file from data simulation computer
				GetTraceDataFromDS_Computer(FolderPath);

				if((StatusCheckBoxFC || StatusCheckBoxIM) == 0)
				{
					Flag_wait = 0; 
					CmtWaitForThreadPoolFunctionCompletion (HOST_ThreadPool, ThreadFunctionIDWait, OPT_TP_PROCESS_EVENTS_WHILE_WAITING);
					CmtReleaseThreadPoolFunctionID (HOST_ThreadPool, ThreadFunctionIDWait);					
					DiscardPanel (PanelHandleWait);						
				}
			}				
			if ((StatusCheckBoxIM != 0) || (StatusCheckBoxFC != 0))
			{
				InstallPopup (PanelHandleWait);
				// Send command
			    if ((StatusCheckBoxIM != 0) && (StatusCheckBoxFC != 0))
					CmdHost.statusFileFTP = 2;					
				else if (StatusCheckBoxIM != 0)
					CmdHost.statusFileFTP = 0;
				else if (StatusCheckBoxFC != 0)
					CmdHost.statusFileFTP = 1;
				
				strcpy(CmdHost.hostUserName, HOST_USERNAME);
				strcpy(CmdHost.hostPassword, HOST_PASSWORD);
				strcpy(CmdHost.hostFolderPath, FolderPath);
				CmdHost.command = FTP_COMMAND; 
				ClientTCPWrite (StatusTcpHost, &CmdHost, sizeof(CmdHost), 3000);
			}

			break;
	}
	return 0;
}

//Quit UI callback
int CVICALLBACK buttonHostQuit (int panel, int control, int event,
	void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:
				QuitUserInterface(0);  
			break;
	}
	return 0;
}

//Quit RT callback 
int CVICALLBACK RT_Quit (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:
			
			if (StatusTcpHost != TCP_INVALID_CONNECTION)
			{
				CmdHost.command = RT_QUIT_COMMAND; 
				ClientTCPWrite (StatusTcpHost, &CmdHost, sizeof(CmdHost), 1000);
				
				QuitUserInterface(0);  
			}
			break;
	}
	return 0;
}

//���������Ͻǹرջص�����	  
//���ص����� 
int CVICALLBACK panelCallBack (int panel, int event, void *callbackData,   
        int eventData1, int eventData2)
{
    if (event == EVENT_CLOSE)
	{
        QuitUserInterface (0);
	}
    return 0;
}

int GetTraceDataFromDS_Computer(char Path_temp[260]) 
{
	int error;
	char Path_tempTemp[260] = {0};
	char Path_tempTempHead[260] = {0};
	
	strcpy(Path_tempTempHead, "c:\\");
	
	strcpy(Path_tempTemp, strcat(Path_tempTempHead, Path_temp));

	strcat(Path_tempTemp, "CraftData.txt");	

	error = InetFTPAutoRetrieve ("192.168.0.2", "Administrator", "mmmmmm", 
		                          Path_tempTemp, "CraftData.txt", INET_FTP_FILE_TYPE_BINARY);
	if(error < 0)
		MessagePopup ("����", InetGetErrorMessage(error));
	return error; 
}

static int CVICALLBACK ThreadFunctionWait(void *functionData)  
{
	waittimecounter = 0;
    while(Flag_wait)
	{
		Delay(0.1); 
		if(waittimecounter >= 30)
		{
			SetCtrlVal (PanelHandleWait, WAIT_PANEL_TEXTMSG , "�ļ��ϴ���ʱ��\n���������ϴ���"); 
			Flag_wait = 0;
			waittimecounter = 0; 
			CmtReleaseThreadPoolFunctionID (HOST_ThreadPool, ThreadFunctionIDWait);					
			
			break;
		}
		else
		{
			if(waittimecounter % 4 == 0)
		    	SetCtrlVal (PanelHandleWait, WAIT_PANEL_TEXTMSG , "���ݴ�����."); 
			else if(waittimecounter % 4 == 1)
				SetCtrlVal (PanelHandleWait, WAIT_PANEL_TEXTMSG , "���ݴ�����.."); 
			else if(waittimecounter % 4 == 2)
				SetCtrlVal (PanelHandleWait, WAIT_PANEL_TEXTMSG , "���ݴ�����..."); 	
			else if(waittimecounter % 4 == 3)
				SetCtrlVal (PanelHandleWait, WAIT_PANEL_TEXTMSG , "���ݴ�����"); 
			waittimecounter++;	
		} 
	}
	return 0;
}

int CVICALLBACK WAIT_PANELCallback (int panel, int event, void *callbackData,   
        int eventData1, int eventData2)
{
    if (event == EVENT_CLOSE)
	{
        Flag_wait = 0;
		waittimecounter = 0; 
		DiscardPanel (PanelHandleWait);	 
		CmtReleaseThreadPoolFunctionID (HOST_ThreadPool, ThreadFunctionIDWait);	
	}
    return 0;
}

int CVICALLBACK TESTBUTTONCallBack (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:
			CmdHost.command = TEST_COMMAND_1;
			ClientTCPWrite (StatusTcpHost, &CmdHost, sizeof(CmdHost), 5000);
			break;
	}
	return 0;
}

int CVICALLBACK TESTBUTTON2CallBack (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:
			CmdHost.command = TEST_COMMAND_2;
			ClientTCPWrite (StatusTcpHost, &CmdHost, sizeof(CmdHost), 5000);
			break;
	}
	return 0;
}



/******************************* ���ع߲�Host Panel Callback ****************************/


/*****�ؼ��ص�����*****/


//Start inertial measurement all function
int CVICALLBACK buttonStartIM (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:
			// Get pulse count interval
			GetCtrlVal(PanelHandleIM, PANEL_IM_COUNTERTIME, &IMUSamplingInterval);  
			CmdHost.pulseCountTime = IMUSamplingInterval;
			
			CmdHost.command = IM_START_COMMAND;
			
			ClientTCPWrite (StatusTcpHost, &CmdHost, sizeof(CmdHost), 5000);
			break;
	}
	return 0;
}

//stop inertial measurement all function
int CVICALLBACK buttonStopIM (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:
			CmdHost.command = IM_STOP_COMMAND; 
			ClientTCPWrite (StatusTcpHost, &CmdHost, sizeof(CmdHost), 5000); 
			break;
	}
	return 0;
}

//Quit inertial measurement callback
int CVICALLBACK buttonQuitIM (int panel, int control, int event,
	void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:
 			FlagPowerWatchIM = 0;
			
			CmtWaitForThreadPoolFunctionCompletion (HOST_ThreadPool, ThreadFunctionIdPowerIM_27V, OPT_TP_PROCESS_EVENTS_WHILE_WAITING);
			CmtReleaseThreadPoolFunctionID (HOST_ThreadPool, ThreadFunctionIdPowerIM_27V);

			CmtWaitForThreadPoolFunctionCompletion (HOST_ThreadPool, ThreadFunctionIdPowerIM_5V, OPT_TP_PROCESS_EVENTS_WHILE_WAITING);
			CmtReleaseThreadPoolFunctionID (HOST_ThreadPool, ThreadFunctionIdPowerIM_5V);
			
			//ֹͣ��λ��������ݽ����߳�
			CmdHost.command = FIRECONTROLDATA_REV_STOP;
			ClientTCPWrite (StatusTcpHost, &CmdHost, sizeof(CmdHost), 3000);  
			
			DiscardPanel (PanelHandleIM);
			PanelHandleIM = 0;
			break;
	}
	return 0;
}

//Selftest
int CVICALLBACK buttonSelftestIM (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:
			CmdHost.command = SELFTEST_COMMAND;
			ClientTCPWrite (StatusTcpHost, &CmdHost, sizeof(CmdHost), 5000);  
			//MessagePopup ("", "ϵͳ�Լ���,���Ժ�...");
			SetCtrlAttribute (PanelHandleIM, PANEL_IM_SELFTESTBUTTON, ATTR_LABEL_TEXT, "�Լ���...");
			break;
	}
	return 0;
}

//gnss429 receive
int CVICALLBACK buttonGNSS429 (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{

	int flagTest;
	switch (event)
	{
		case EVENT_COMMIT:
			GetCtrlVal(PanelHandleIM,PANEL_IM_GPSBUTTON,&flagTest);
			CmdHost.command = IM_GPSRECEIVE_COMMAND;

			CmdHost.statusGNSS429 = flagTest;
			ClientTCPWrite (StatusTcpHost, &CmdHost, sizeof(CmdHost), 5000);
			
			break;
	}
	return 0;
}

//pulse receive
int CVICALLBACK buttonPulse (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{

	int flagTest;
	switch (event)
	{
		case EVENT_COMMIT:
			GetCtrlVal(PanelHandleIM,PANEL_IM_INSBUTTON,&flagTest);
			CmdHost.statusPulse = flagTest;
			
			CmdHost.command = IM_INSRECEIVE_COMMAND;
			
			// Get pulse count interval
			GetCtrlVal(PanelHandleIM, PANEL_IM_COUNTERTIME, &IMUSamplingInterval);  
			CmdHost.pulseCountTime = IMUSamplingInterval;
			
			ClientTCPWrite (StatusTcpHost, &CmdHost, sizeof(CmdHost), 5000);
			break;
	}
	return 0;
}

//�Զ��ֶ�ģʽ���ػص�����
int CVICALLBACK switchModeIM (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:
			int Module_State;
			GetCtrlVal (PanelHandleIM, PANEL_IM_MODULESWITCH, &Module_State);
			switch(Module_State)
			{
				case 1:											 
				  	CmdHost.command = IM_AUTOSTART_COMMAND;
					CmdHost.statusAutostartIM = 1;
				  	ClientTCPWrite (StatusTcpHost, &CmdHost, sizeof(CmdHost), 5000);
				  	SetCtrlVal (PanelHandleIM, PANEL_IM_LED3, 1);
					
					SetCtrlAttribute (PanelHandleIM, PANEL_IM_GPSBUTTON, ATTR_DIMMED, 1);
					SetCtrlAttribute (PanelHandleIM, PANEL_IM_INSBUTTON, ATTR_DIMMED, 1);
					SetCtrlAttribute (PanelHandleIM, PANEL_IM_STARTBUTTON, ATTR_DIMMED, 1);	   
					SetCtrlAttribute (PanelHandleIM, PANEL_IM_STOPBUTTON, ATTR_DIMMED, 1);
					SetCtrlAttribute (PanelHandleIM, PANEL_IM_SELFTESTBUTTON, ATTR_DIMMED, 1);
					SetCtrlAttribute (PanelHandleIM, PANEL_IM_QUITBUTTON, ATTR_DIMMED, 1);
					SetCtrlAttribute (PanelHandleIM, PANEL_IM_POWERSWITCH, ATTR_DIMMED, 1);
					SetCtrlAttribute (PanelHandleIM, PANEL_IM_BOARDPOWERSWITCH, ATTR_DIMMED, 1);
					break;
			    case 0:
					CmdHost.command = IM_AUTOSTART_COMMAND;
					CmdHost.statusAutostartIM = 0;
				  	ClientTCPWrite (StatusTcpHost, &CmdHost, sizeof(CmdHost), 5000);
				  	SetCtrlVal (PanelHandleIM, PANEL_IM_LED3, 0);
					
					SetCtrlAttribute (PanelHandleIM, PANEL_IM_GPSBUTTON, ATTR_DIMMED, 0);
					SetCtrlAttribute (PanelHandleIM, PANEL_IM_INSBUTTON, ATTR_DIMMED, 0);
					SetCtrlAttribute (PanelHandleIM, PANEL_IM_STARTBUTTON, ATTR_DIMMED, 0);	   
					SetCtrlAttribute (PanelHandleIM, PANEL_IM_STOPBUTTON, ATTR_DIMMED, 0);
					SetCtrlAttribute (PanelHandleIM, PANEL_IM_SELFTESTBUTTON, ATTR_DIMMED, 0);
					SetCtrlAttribute (PanelHandleIM, PANEL_IM_QUITBUTTON, ATTR_DIMMED, 0);
					SetCtrlAttribute (PanelHandleIM, PANEL_IM_POWERSWITCH, ATTR_DIMMED, 0);
					SetCtrlAttribute (PanelHandleIM, PANEL_IM_BOARDPOWERSWITCH, ATTR_DIMMED, 0);
					break;
			}
			break;
	}
	return 0;
}


/*****��Դ���ƺ���*****/    


//�߲����õ���·��Դ���������߳���߻ض���ѹ������Ч��
//��Ʒ��Դ��ء����ƺ���(�߲�) 
static int CVICALLBACK ThreadFunctionPowerIM_27V(void *functionData)
{
	float V_INS,V_GPS,I_INS,I_GPS; 
	float V_Pulse1, V_Pulse2, I_Pulse1, I_Pulse2;
	
	while(FlagPowerWatchIM)
	{
		if(Flag_PowerIM_imu_On)
		{
			PowerOnIMimu();  
			Flag_PowerIM_imu_On = 0;
		}
		
		if(Flag_PowerIM_imu_Off)
		{
			PowerOffIMimu();  
			Flag_PowerIM_imu_Off = 0;
		}		
		
		// IMU 27 
		ComWrt (3, BufferPowerTest27, 8);
		ComRd (3, BufferPowerRead27, 9);
		V_INS = (BufferPowerRead27[3]*16*16+BufferPowerRead27[4])/1000.00;
		I_INS = (BufferPowerRead27[5]*16*16+BufferPowerRead27[6])/1000.00;	
		SetCtrlVal (PanelHandleIM, PANEL_IM_V_INS, V_INS);
		SetCtrlVal (PanelHandleIM, PANEL_IM_I_INS, I_INS);			
		Delay(0.1);  	
	
		// Power on time
		if (FlagIMimugnss == 1)
		{
			SetCtrlVal (PanelHandleIM, PANEL_IM_TIME_IMU_GNSS, clock() / CLOCKS_PER_SEC - TimeStartIMimugnss);
		}			  
    }
	return 0;
}

//�忨��Դ��ء����ƺ���(�߲�) 
static int CVICALLBACK ThreadFunctionPowerIM_5V(void *functionData)
{
	float V_INS,V_GPS,I_INS,I_GPS; 
	float V_Pulse1, V_Pulse2, I_Pulse1, I_Pulse2;
	
	while(FlagPowerWatchIM)
	{
		//���ջ���Ʒ
		if(Flag_PowerIM_gnss_On)
		{
			PowerOnIMgnss();  
			Flag_PowerIM_gnss_On = 0;
		}
		
		if(Flag_PowerIM_gnss_Off)
		{
			PowerOffIMgnss();  
			Flag_PowerIM_gnss_Off = 0;
		}		
		
		//���������
		if(Flag_PowerIM_Board_On)
		{
			PowerOnIMpulse();  
		    Flag_PowerIM_Board_On = 0;  
		}  
		
		if(Flag_PowerIM_Board_Off)
		{
			PowerOffIMpulse();  
		    Flag_PowerIM_Board_Off = 0;  
		}  

		// GNSS receiver 5V
		ComWrt (4, BufferPowerTest5V4, 8);
		ComRd (4, BufferPowerRead5V4, 9);
		V_GPS = (BufferPowerRead5V4[3]*16*16+BufferPowerRead5V4[4])/1000.00;
		I_GPS = (BufferPowerRead5V4[5]*16*16+BufferPowerRead5V4[6])/1000.00;	
		SetCtrlVal (PanelHandleIM, PANEL_IM_V_GPS, V_GPS);
		SetCtrlVal (PanelHandleIM, PANEL_IM_I_GPS, I_GPS);		
		Delay(0.06); 	   
		
		// Pulse counting board 5V
		ComWrt (4, BufferPowerTest5V2, 8);
		ComRd (4, BufferPowerRead5V2, 9);
		V_Pulse1 = (BufferPowerRead5V2[3]*16*16+BufferPowerRead5V2[4])/1000.00;
		I_Pulse1 = (BufferPowerRead5V2[5]*16*16+BufferPowerRead5V2[6])/1000.00;	
		SetCtrlVal (PanelHandleIM, PANEL_IM_V_PULSE1, V_Pulse1);
		SetCtrlVal (PanelHandleIM, PANEL_IM_I_PULSE1, I_Pulse1);
		Delay(0.06);  
		
		// Pulse counting board 5V
		ComWrt (4, BufferPowerTest5V3, 8);
		ComRd (4, BufferPowerRead5V3, 9);
		V_Pulse2 = (BufferPowerRead5V3[3]*16*16+BufferPowerRead5V3[4])/1000.00;
		I_Pulse2 = (BufferPowerRead5V3[5]*16*16+BufferPowerRead5V3[6])/1000.00;	
		SetCtrlVal (PanelHandleIM, PANEL_IM_V_PULSE2, V_Pulse2);
		SetCtrlVal (PanelHandleIM, PANEL_IM_I_PULSE2, I_Pulse2);		
		Delay(0.06);  		
		
		// Power on time
		if (FlagIMpulse == 1)
		{
			SetCtrlVal (PanelHandleIM, PANEL_IM_TIME_PULSE, clock() / CLOCKS_PER_SEC - TimeStartIMpulse);
		}
    }
	return 0;
}

//Power on IMU (IM)
int PowerOnIMimu()
{
	char tempdata[8]={0};  
	ComWrt (3, BufferPowerOn27, 8);
	ComRd (3, tempdata, 8); 
	
  	SetCtrlVal (PanelHandleIM, PANEL_IM_LED1, 1);
	
	// Disable quit button
	SetCtrlAttribute (PanelHandleIM, PANEL_IM_QUITBUTTON, ATTR_DIMMED, 1);
	
	// Set time flag
	FlagIMimugnss = 1;
	TimeStartIMimugnss = clock() / CLOCKS_PER_SEC;
	SetCtrlVal (PanelHandleIM, PANEL_IM_TIME_IMU_GNSS, 0.0);
	
  	Delay(0.1);  	
	return 0;
}

//Power on GNSS (IM)
int PowerOnIMgnss()
{
	char tempdata[8]={0}; 
  	ComWrt (4, BufferPowerOn5V4, 8); 
	ComRd (4, tempdata, 8);
  	Delay(0.06); 
	return 0;
}

//Power off IMU (IM)
int PowerOffIMimu()
{	  
	char tempdata[8]={0}; 	   
	ComWrt (3, BufferPowerOff27, 8);
	ComRd (3, tempdata, 8);   	
   	SetCtrlVal (PanelHandleIM, PANEL_IM_LED1, 0);  
	// Enable quit button
	if ((StatusPower27V == 0) && (StatusPower5V == 0))
		SetCtrlAttribute (PanelHandleIM, PANEL_IM_QUITBUTTON, ATTR_DIMMED, 0);
	
	// Clear time flag
	FlagIMimugnss = 0;
  	Delay(0.1);	
	return 0;
}

//Power off GNSS (IM)  
int PowerOffIMgnss() 
{
	char tempdata[8]={0}; 
  	ComWrt (4, BufferPowerOff5V4, 8);
 	ComRd (4, tempdata, 8);
  	Delay(0.06); 	
	return 0;
}

//Power on pulse counting board (IM)
int PowerOnIMpulse()
{
	char tempdata[8]={0}; 
	ComWrt (4, BufferPowerOn5V2, 8);
	ComRd (4, tempdata, 8); 	
	Delay(0.1);
  	ComWrt (4, BufferPowerOn5V3, 8);
 	ComRd (4, tempdata, 8); 
	
  	SetCtrlVal (PanelHandleIM, PANEL_IM_LED2, 1);
	
	// Disable quit button
	SetCtrlAttribute (PanelHandleIM, PANEL_IM_QUITBUTTON, ATTR_DIMMED, 1);
	
	// Set time flag
	FlagIMpulse = 1;
	TimeStartIMpulse = clock() / CLOCKS_PER_SEC;
	SetCtrlVal (PanelHandleIM, PANEL_IM_TIME_PULSE, 0.0);
  	
	Delay(0.1);	
	return 0;
}

//Power off pulse counting board (IM)
int PowerOffIMpulse()
{
	char tempdata[8]={0}; 
	ComWrt (4, BufferPowerOff5V2, 8);	
	ComRd (4, tempdata, 8); 
	Delay(0.1);    	
	ComWrt (4, BufferPowerOff5V3, 8);
	ComRd (4, tempdata, 8); 
	
  	SetCtrlVal (PanelHandleIM, PANEL_IM_LED2, 0);
	
	// Enable quit button
	if ((StatusPower27V == 0) && (StatusPower5V == 0))
		SetCtrlAttribute (PanelHandleIM, PANEL_IM_QUITBUTTON, ATTR_DIMMED, 0);
	
	// Clear time flag
	FlagIMpulse = 0;
	
  	Delay(0.1);	
	return 0;
}

//GNSS��IMU�ϵ翪�ػص�����
int CVICALLBACK PowerSwitchIM27V (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:
			GetCtrlVal (PanelHandleIM, PANEL_IM_POWERSWITCH, &StatusPower27V);
			GetCtrlVal (PanelHandleIM, PANEL_IM_BOARDPOWERSWITCH, &StatusPower5V);
			switch(StatusPower27V)
			{
				case 1:	
					Flag_PowerIM_imu_On = 1;
					Flag_PowerIM_gnss_On = 1;
					break;
			    case 0:
				  	Flag_PowerIM_imu_Off = 1; 
					Flag_PowerIM_gnss_Off = 1;  
					break;
			}
			break;
	}
	return 0;
}

//����������ϵ翪�ػص�����   
int CVICALLBACK PowerSwitchIM5V (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:
			GetCtrlVal (PanelHandleIM, PANEL_IM_POWERSWITCH, &StatusPower27V);
			GetCtrlVal (PanelHandleIM, PANEL_IM_BOARDPOWERSWITCH, &StatusPower5V);
			switch(StatusPower5V)
			{
				case 1:
					Flag_PowerIM_Board_On = 1; 
			    	break;
				
			    case 0:
				  	Flag_PowerIM_Board_Off = 1; 
					break;
			}
			break;
	}
	return 0;
}


/*****���ݴ�������*****/   


//��ʾPPS����
void SetPPSData(void)
{
	SetCtrlVal (PanelHandleIM, PANEL_IM_PPSTIME, DataHost.pps_time);
	//fprintf (FileHandleHostPPS, "%f ", DataHost.pps_time);  
	//fprintf (FileHandleHostPPS, "\r\n");	
}

//��ʾ������IMU����
void SetPulseData(void)
{
	SetCtrlVal (PanelHandleIM, PANEL_IM_ASXP, DataHost.accumGxp);
	SetCtrlVal (PanelHandleIM, PANEL_IM_ASXN, DataHost.accumGxn);
	SetCtrlVal (PanelHandleIM, PANEL_IM_ASYP, DataHost.accumGyp);
	SetCtrlVal (PanelHandleIM, PANEL_IM_ASYN, DataHost.accumGyn);
	SetCtrlVal (PanelHandleIM, PANEL_IM_ASZP, DataHost.accumGzp);
	SetCtrlVal (PanelHandleIM, PANEL_IM_ASZN, DataHost.accumGzn);
	
	SetCtrlVal (PanelHandleIM, PANEL_IM_LAXP, DataHost.accumAxp);
	SetCtrlVal (PanelHandleIM, PANEL_IM_LAXN, DataHost.accumAxn);
	SetCtrlVal (PanelHandleIM, PANEL_IM_LAYP, DataHost.accumAyp);
	SetCtrlVal (PanelHandleIM, PANEL_IM_LAYN, DataHost.accumAyn);
	SetCtrlVal (PanelHandleIM, PANEL_IM_LAZP, DataHost.accumAzp);
	SetCtrlVal (PanelHandleIM, PANEL_IM_LAZN, DataHost.accumAzn);
	SetCtrlVal (PanelHandleIM, PANEL_IM_PULSETIME, DataHost.pulse_time);
	
	/*fprintf(FileHandleHostPulse,"%f\t", DataHost.pulse_time);   
	fprintf(FileHandleHostPulse,"%d\t", DataHost.asxp);  
	fprintf(FileHandleHostPulse,"%d\t", DataHost.asxn); 
	fprintf(FileHandleHostPulse,"%d\t", DataHost.asyp); 
	fprintf(FileHandleHostPulse,"%d\t", DataHost.asyn); 
	fprintf(FileHandleHostPulse,"%d\t", DataHost.aszp); 
	fprintf(FileHandleHostPulse,"%d\t", DataHost.aszn);

	fprintf(FileHandleHostPulse,"%d\t", DataHost.laxp);  
	fprintf(FileHandleHostPulse,"%d\t", DataHost.laxn); 
	fprintf(FileHandleHostPulse,"%d\t", DataHost.layp); 
	fprintf(FileHandleHostPulse,"%d\t", DataHost.layn); 
	fprintf(FileHandleHostPulse,"%d\t", DataHost.lazp); 
	fprintf(FileHandleHostPulse,"%d\t", DataHost.lazn); 
	fprintf(FileHandleHostPulse, "\r\n");*/ 
	
}

//��ʾ������GPS����
void SetGNSS429Data(void)
{
	int i;
	
	int FixQuality = 0;
	
	SetCtrlVal (PanelHandleIM, PANEL_IM_GPSTIME, DataHost.gps_time);
	SetCtrlVal (PanelHandleIM, PANEL_IM_GPSFIRSTDATA, DataHost.gps_firstdata);
	SetCtrlVal (PanelHandleIM, PANEL_IM_RCVTIME, DataHost.RcvTime);
	
	SetCtrlVal (PanelHandleIM, PANEL_IM_LON, DataHost.Lon);
	SetCtrlVal (PanelHandleIM, PANEL_IM_LAT, DataHost.Lat); 
	SetCtrlVal (PanelHandleIM, PANEL_IM_ALT, DataHost.Alt);
	
	SetCtrlVal (PanelHandleIM, PANEL_IM_PDOP, DataHost.PDOP);
	
	SetCtrlVal (PanelHandleIM, PANEL_IM_POSITION_X, DataHost.X);
	SetCtrlVal (PanelHandleIM, PANEL_IM_POSITION_Y, DataHost.Y);
	SetCtrlVal (PanelHandleIM, PANEL_IM_POSITION_Z, DataHost.Z);
	
	SetCtrlVal (PanelHandleIM, PANEL_IM_VELOCITY_X, DataHost.Vx);
	SetCtrlVal (PanelHandleIM, PANEL_IM_VELOCITY_Y, DataHost.Vy);
	SetCtrlVal (PanelHandleIM, PANEL_IM_VELOCITY_Z, DataHost.Vz);
	
	SetCtrlVal (PanelHandleIM, PANEL_IM_SVS, DataHost.SVs);
	
	SetCtrlVal (PanelHandleIM, PANEL_IM_Sat_ErrorX, DataHost.Error84_X);   	
	SetCtrlVal (PanelHandleIM, PANEL_IM_Sat_ErrorY, DataHost.Error84_Y); 	
	SetCtrlVal (PanelHandleIM, PANEL_IM_Sat_ErrorZ, DataHost.Error84_Z); 
	
	// ��λģʽ��ʾ 
	SetCtrlAttribute (PanelHandleIM, PANEL_IM_FIX_MODE, ATTR_CTRL_VAL, DataHost.FixMode);
	
	// ��λ������ʾ
	if ((DataHost.sFixQuality[0] == '0') && (DataHost.sFixQuality[1] == '0'))
	{
		SetCtrlVal (PanelHandleIM, PANEL_IM_FIX_QUALITY1, 0);
		SetCtrlVal (PanelHandleIM, PANEL_IM_FIX_QUALITY2, 0);
		SetCtrlVal (PanelHandleIM, PANEL_IM_FIX_QUALITY3, 0);
		FixQuality = 0;
	}
	else if ((DataHost.sFixQuality[0] == '0') && (DataHost.sFixQuality[1] == '1'))
	{
		SetCtrlVal (PanelHandleIM, PANEL_IM_FIX_QUALITY1, 0);
		SetCtrlVal (PanelHandleIM, PANEL_IM_FIX_QUALITY2, 0);
		SetCtrlVal (PanelHandleIM, PANEL_IM_FIX_QUALITY3, 1);
		FixQuality = 1;
	}
	else if ((DataHost.sFixQuality[0] == '1') && (DataHost.sFixQuality[1] == '0'))
	{
		SetCtrlVal (PanelHandleIM, PANEL_IM_FIX_QUALITY1, 0);
		SetCtrlVal (PanelHandleIM, PANEL_IM_FIX_QUALITY2, 1);
		SetCtrlVal (PanelHandleIM, PANEL_IM_FIX_QUALITY3, 1);
		FixQuality = 2;
	}
	else if ((DataHost.sFixQuality[0] == '1') && (DataHost.sFixQuality[1] == '1'))
	{
		SetCtrlVal (PanelHandleIM, PANEL_IM_FIX_QUALITY1, 1);
		SetCtrlVal (PanelHandleIM, PANEL_IM_FIX_QUALITY2, 1);
		SetCtrlVal (PanelHandleIM, PANEL_IM_FIX_QUALITY3, 1);
		FixQuality = 3;
	}
	else;
	
	
	// ��ͨ�����Ƕ�λ�����ʾ
	SetCtrlVal (PanelHandleIM, PANEL_IM_SVNO_1, DataHost.m_SVsInfo[0].nNo);
	SetCtrlVal (PanelHandleIM, PANEL_IM_WEIJU_1, DataHost.m_SVsInfo[0].weiju);
	SetCtrlVal (PanelHandleIM, PANEL_IM_WEIJULV_1, DataHost.m_SVsInfo[0].weijulv);
	SetCtrlVal (PanelHandleIM, PANEL_IM_POSITION_X_1, DataHost.m_SVsInfo[0].X);
	SetCtrlVal (PanelHandleIM, PANEL_IM_POSITION_Y_1, DataHost.m_SVsInfo[0].Y);
	SetCtrlVal (PanelHandleIM, PANEL_IM_POSITION_Z_1, DataHost.m_SVsInfo[0].Z);
	SetCtrlVal (PanelHandleIM, PANEL_IM_VELOCITY_X_1, DataHost.m_SVsInfo[0].Vx);
	SetCtrlVal (PanelHandleIM, PANEL_IM_VELOCITY_Y_1, DataHost.m_SVsInfo[0].Vy);
	SetCtrlVal (PanelHandleIM, PANEL_IM_VELOCITY_Z_1, DataHost.m_SVsInfo[0].Vz);
	SetCtrlVal (PanelHandleIM, PANEL_IM_SNR_1, DataHost.m_SVsInfo[0].SNR);
	
	SetCtrlVal (PanelHandleIM, PANEL_IM_SVNO_2, DataHost.m_SVsInfo[1].nNo);
	SetCtrlVal (PanelHandleIM, PANEL_IM_WEIJU_2, DataHost.m_SVsInfo[1].weiju);
	SetCtrlVal (PanelHandleIM, PANEL_IM_WEIJULV_2, DataHost.m_SVsInfo[1].weijulv);
	SetCtrlVal (PanelHandleIM, PANEL_IM_POSITION_X_2, DataHost.m_SVsInfo[1].X);
	SetCtrlVal (PanelHandleIM, PANEL_IM_POSITION_Y_2, DataHost.m_SVsInfo[1].Y);
	SetCtrlVal (PanelHandleIM, PANEL_IM_POSITION_Z_2, DataHost.m_SVsInfo[1].Z);
	SetCtrlVal (PanelHandleIM, PANEL_IM_VELOCITY_X_2, DataHost.m_SVsInfo[1].Vx);
	SetCtrlVal (PanelHandleIM, PANEL_IM_VELOCITY_Y_2, DataHost.m_SVsInfo[1].Vy);
	SetCtrlVal (PanelHandleIM, PANEL_IM_VELOCITY_Z_2, DataHost.m_SVsInfo[1].Vz);
	SetCtrlVal (PanelHandleIM, PANEL_IM_SNR_2, DataHost.m_SVsInfo[1].SNR);
	
	SetCtrlVal (PanelHandleIM, PANEL_IM_SVNO_3, DataHost.m_SVsInfo[2].nNo);
	SetCtrlVal (PanelHandleIM, PANEL_IM_WEIJU_3, DataHost.m_SVsInfo[2].weiju);
	SetCtrlVal (PanelHandleIM, PANEL_IM_WEIJULV_3, DataHost.m_SVsInfo[2].weijulv);
	SetCtrlVal (PanelHandleIM, PANEL_IM_POSITION_X_3, DataHost.m_SVsInfo[2].X);
	SetCtrlVal (PanelHandleIM, PANEL_IM_POSITION_Y_3, DataHost.m_SVsInfo[2].Y);
	SetCtrlVal (PanelHandleIM, PANEL_IM_POSITION_Z_3, DataHost.m_SVsInfo[2].Z);
	SetCtrlVal (PanelHandleIM, PANEL_IM_VELOCITY_X_3, DataHost.m_SVsInfo[2].Vx);
	SetCtrlVal (PanelHandleIM, PANEL_IM_VELOCITY_Y_3, DataHost.m_SVsInfo[2].Vy);
	SetCtrlVal (PanelHandleIM, PANEL_IM_VELOCITY_Z_3, DataHost.m_SVsInfo[2].Vz);
	SetCtrlVal (PanelHandleIM, PANEL_IM_SNR_3, DataHost.m_SVsInfo[2].SNR);
	
	SetCtrlVal (PanelHandleIM, PANEL_IM_SVNO_4, DataHost.m_SVsInfo[3].nNo);
	SetCtrlVal (PanelHandleIM, PANEL_IM_WEIJU_4, DataHost.m_SVsInfo[3].weiju);
	SetCtrlVal (PanelHandleIM, PANEL_IM_WEIJULV_4, DataHost.m_SVsInfo[3].weijulv);
	SetCtrlVal (PanelHandleIM, PANEL_IM_POSITION_X_4, DataHost.m_SVsInfo[3].X);
	SetCtrlVal (PanelHandleIM, PANEL_IM_POSITION_Y_4, DataHost.m_SVsInfo[3].Y);
	SetCtrlVal (PanelHandleIM, PANEL_IM_POSITION_Z_4, DataHost.m_SVsInfo[3].Z);
	SetCtrlVal (PanelHandleIM, PANEL_IM_VELOCITY_X_4, DataHost.m_SVsInfo[3].Vx);
	SetCtrlVal (PanelHandleIM, PANEL_IM_VELOCITY_Y_4, DataHost.m_SVsInfo[3].Vy);
	SetCtrlVal (PanelHandleIM, PANEL_IM_VELOCITY_Z_4, DataHost.m_SVsInfo[3].Vz);
	SetCtrlVal (PanelHandleIM, PANEL_IM_SNR_4, DataHost.m_SVsInfo[3].SNR);
	
	SetCtrlVal (PanelHandleIM, PANEL_IM_SVNO_5, DataHost.m_SVsInfo[4].nNo);
	SetCtrlVal (PanelHandleIM, PANEL_IM_WEIJU_5, DataHost.m_SVsInfo[4].weiju);
	SetCtrlVal (PanelHandleIM, PANEL_IM_WEIJULV_5, DataHost.m_SVsInfo[4].weijulv);
	SetCtrlVal (PanelHandleIM, PANEL_IM_POSITION_X_5, DataHost.m_SVsInfo[4].X);
	SetCtrlVal (PanelHandleIM, PANEL_IM_POSITION_Y_5, DataHost.m_SVsInfo[4].Y);
	SetCtrlVal (PanelHandleIM, PANEL_IM_POSITION_Z_5, DataHost.m_SVsInfo[4].Z);
	SetCtrlVal (PanelHandleIM, PANEL_IM_VELOCITY_X_5, DataHost.m_SVsInfo[4].Vx);
	SetCtrlVal (PanelHandleIM, PANEL_IM_VELOCITY_Y_5, DataHost.m_SVsInfo[4].Vy);
	SetCtrlVal (PanelHandleIM, PANEL_IM_VELOCITY_Z_5, DataHost.m_SVsInfo[4].Vz);
	SetCtrlVal (PanelHandleIM, PANEL_IM_SNR_5, DataHost.m_SVsInfo[4].SNR);
	
	SetCtrlVal (PanelHandleIM, PANEL_IM_SVNO_6, DataHost.m_SVsInfo[5].nNo);
	SetCtrlVal (PanelHandleIM, PANEL_IM_WEIJU_6, DataHost.m_SVsInfo[5].weiju);
	SetCtrlVal (PanelHandleIM, PANEL_IM_WEIJULV_6, DataHost.m_SVsInfo[5].weijulv);
	SetCtrlVal (PanelHandleIM, PANEL_IM_POSITION_X_6, DataHost.m_SVsInfo[5].X);
	SetCtrlVal (PanelHandleIM, PANEL_IM_POSITION_Y_6, DataHost.m_SVsInfo[5].Y);
	SetCtrlVal (PanelHandleIM, PANEL_IM_POSITION_Z_6, DataHost.m_SVsInfo[5].Z);
	SetCtrlVal (PanelHandleIM, PANEL_IM_VELOCITY_X_6, DataHost.m_SVsInfo[5].Vx);
	SetCtrlVal (PanelHandleIM, PANEL_IM_VELOCITY_Y_6, DataHost.m_SVsInfo[5].Vy);
	SetCtrlVal (PanelHandleIM, PANEL_IM_VELOCITY_Z_6, DataHost.m_SVsInfo[5].Vz);
	SetCtrlVal (PanelHandleIM, PANEL_IM_SNR_6, DataHost.m_SVsInfo[5].SNR);
	
	SetCtrlVal (PanelHandleIM, PANEL_IM_SVNO_7, DataHost.m_SVsInfo[6].nNo);
	SetCtrlVal (PanelHandleIM, PANEL_IM_WEIJU_7, DataHost.m_SVsInfo[6].weiju);
	SetCtrlVal (PanelHandleIM, PANEL_IM_WEIJULV_7, DataHost.m_SVsInfo[6].weijulv);
	SetCtrlVal (PanelHandleIM, PANEL_IM_POSITION_X_7, DataHost.m_SVsInfo[6].X);
	SetCtrlVal (PanelHandleIM, PANEL_IM_POSITION_Y_7, DataHost.m_SVsInfo[6].Y);
	SetCtrlVal (PanelHandleIM, PANEL_IM_POSITION_Z_7, DataHost.m_SVsInfo[6].Z);
	SetCtrlVal (PanelHandleIM, PANEL_IM_VELOCITY_X_7, DataHost.m_SVsInfo[6].Vx);
	SetCtrlVal (PanelHandleIM, PANEL_IM_VELOCITY_Y_7, DataHost.m_SVsInfo[6].Vy);
	SetCtrlVal (PanelHandleIM, PANEL_IM_VELOCITY_Z_7, DataHost.m_SVsInfo[6].Vz);
	SetCtrlVal (PanelHandleIM, PANEL_IM_SNR_7, DataHost.m_SVsInfo[6].SNR);
	
	SetCtrlVal (PanelHandleIM, PANEL_IM_SVNO_8, DataHost.m_SVsInfo[7].nNo);
	SetCtrlVal (PanelHandleIM, PANEL_IM_WEIJU_8, DataHost.m_SVsInfo[7].weiju);
	SetCtrlVal (PanelHandleIM, PANEL_IM_WEIJULV_8, DataHost.m_SVsInfo[7].weijulv);
	SetCtrlVal (PanelHandleIM, PANEL_IM_POSITION_X_8, DataHost.m_SVsInfo[7].X);
	SetCtrlVal (PanelHandleIM, PANEL_IM_POSITION_Y_8, DataHost.m_SVsInfo[7].Y);
	SetCtrlVal (PanelHandleIM, PANEL_IM_POSITION_Z_8, DataHost.m_SVsInfo[7].Z);
	SetCtrlVal (PanelHandleIM, PANEL_IM_VELOCITY_X_8, DataHost.m_SVsInfo[7].Vx);
	SetCtrlVal (PanelHandleIM, PANEL_IM_VELOCITY_Y_8, DataHost.m_SVsInfo[7].Vy);
	SetCtrlVal (PanelHandleIM, PANEL_IM_VELOCITY_Z_8, DataHost.m_SVsInfo[7].Vz);
	SetCtrlVal (PanelHandleIM, PANEL_IM_SNR_8, DataHost.m_SVsInfo[7].SNR);
	
	SetCtrlVal (PanelHandleIM, PANEL_IM_SVNO_9, DataHost.m_SVsInfo[8].nNo);
	SetCtrlVal (PanelHandleIM, PANEL_IM_WEIJU_9, DataHost.m_SVsInfo[8].weiju);
	SetCtrlVal (PanelHandleIM, PANEL_IM_WEIJULV_9, DataHost.m_SVsInfo[8].weijulv);
	SetCtrlVal (PanelHandleIM, PANEL_IM_POSITION_X_9, DataHost.m_SVsInfo[8].X);
	SetCtrlVal (PanelHandleIM, PANEL_IM_POSITION_Y_9, DataHost.m_SVsInfo[8].Y);
	SetCtrlVal (PanelHandleIM, PANEL_IM_POSITION_Z_9, DataHost.m_SVsInfo[8].Z);
	SetCtrlVal (PanelHandleIM, PANEL_IM_VELOCITY_X_9, DataHost.m_SVsInfo[8].Vx);
	SetCtrlVal (PanelHandleIM, PANEL_IM_VELOCITY_Y_9, DataHost.m_SVsInfo[8].Vy);
	SetCtrlVal (PanelHandleIM, PANEL_IM_VELOCITY_Z_9, DataHost.m_SVsInfo[8].Vz);
	SetCtrlVal (PanelHandleIM, PANEL_IM_SNR_9, DataHost.m_SVsInfo[8].SNR);
	
	SetCtrlVal (PanelHandleIM, PANEL_IM_SVNO_10, DataHost.m_SVsInfo[9].nNo);
	SetCtrlVal (PanelHandleIM, PANEL_IM_WEIJU_10, DataHost.m_SVsInfo[9].weiju);
	SetCtrlVal (PanelHandleIM, PANEL_IM_WEIJULV_10, DataHost.m_SVsInfo[9].weijulv);
	SetCtrlVal (PanelHandleIM, PANEL_IM_POSITION_X_10, DataHost.m_SVsInfo[9].X);
	SetCtrlVal (PanelHandleIM, PANEL_IM_POSITION_Y_10, DataHost.m_SVsInfo[9].Y);
	SetCtrlVal (PanelHandleIM, PANEL_IM_POSITION_Z_10, DataHost.m_SVsInfo[9].Z);
	SetCtrlVal (PanelHandleIM, PANEL_IM_VELOCITY_X_10, DataHost.m_SVsInfo[9].Vx);
	SetCtrlVal (PanelHandleIM, PANEL_IM_VELOCITY_Y_10, DataHost.m_SVsInfo[9].Vy);
	SetCtrlVal (PanelHandleIM, PANEL_IM_VELOCITY_Z_10, DataHost.m_SVsInfo[9].Vz);
	SetCtrlVal (PanelHandleIM, PANEL_IM_SNR_10, DataHost.m_SVsInfo[9].SNR);
}



/*******************************   ���طɿ�Host Panel Callback ****************************/


/*****�ؼ��ص�����*****/


//Start flight control all function
int CVICALLBACK buttonStartFC (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	int mode;
	switch (event)
	{
		case EVENT_COMMIT:
			// Get fire control mode
			GetCtrlVal (PanelHandleFC, PANEL_FC_SWITCH_FIRE_CONTROL, &mode);
			switch(mode)
			{
				case 0:											 
					CmdHost.modeFireControl = MODE_FIRECONTROL_STATIC;
					break;
			    case 1:
					CmdHost.modeFireControl = MODE_FIRECONTROL_DYNAMIC;
					break;
			}
			
			CmdHost.command = FC_START_COMMAND;
			
			ClientTCPWrite (StatusTcpHost, &CmdHost, sizeof(CmdHost), 5000);
			break;
	}
	return 0;
}

//Stop flight control all function
int CVICALLBACK buttonStopFC (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:
 
			CmdHost.command = FC_STOP_COMMAND; 
			ClientTCPWrite (StatusTcpHost, &CmdHost, sizeof(CmdHost), 5000);  
			SetCtrlVal (PanelHandleFC, PANEL_FC_LED9, 0);
			break;
	}
	return 0;
}

//Quit flight control callback
int CVICALLBACK buttonQuitFC (int panel, int control, int event,
	void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:
			
 			FlagPowerWatchFC = 0;
			
			CmtWaitForThreadPoolFunctionCompletion (HOST_ThreadPool, ThreadFunctionIdPowerFC, OPT_TP_PROCESS_EVENTS_WHILE_WAITING);
			CmtReleaseThreadPoolFunctionID (HOST_ThreadPool, ThreadFunctionIdPowerFC);
			//ֹͣ��λ��������ݽ����߳�
			CmdHost.command = FIRECONTROLDATA_REV_STOP;
			ClientTCPWrite (StatusTcpHost, &CmdHost, sizeof(CmdHost), 3000);  
			
			DiscardPanel (PanelHandleFC);
			PanelHandleFC = 0;

			break;
	}
	return 0;
}

//Selftest
int CVICALLBACK buttonSelftestFC (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:
			CmdHost.command = SELFTEST_COMMAND;
			ClientTCPWrite (StatusTcpHost, &CmdHost, sizeof(CmdHost), 5000);  
			//MessagePopup ("", "ϵͳ�Լ���,���Ժ�...");
			SetCtrlAttribute (PanelHandleIM, PANEL_IM_SELFTESTBUTTON, ATTR_LABEL_TEXT, "�Լ���...");
			break;
	}
	return 0;
}

//Start/Stop GNSS 422 (Fire control) callback
int CVICALLBACK buttonGNSSFC422 (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{

	int test_flag;
	switch (event)
	{
		case EVENT_COMMIT:
			GetCtrlVal(PanelHandleFC, PANEL_FC_GPSBUTTON,&test_flag);
			CmdHost.command = FC_GPSRECEIVE_COMMAND;
			CmdHost.statusGNSS422FC = test_flag;
			ClientTCPWrite (StatusTcpHost, &CmdHost, sizeof(CmdHost), 5000);
			break;
	}
	return 0;
}

//��ʼ��ֹͣң��LVDSת422����
int CVICALLBACK buttonYC (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	int test_flag;
	switch (event)
	{
		case EVENT_COMMIT:
			GetCtrlVal(PanelHandleFC, PANEL_FC_YCBUTTON, &test_flag);
			CmdHost.command = FC_YCRECEIVE_COMMAND;
			CmdHost.statusYC = test_flag;
			ClientTCPWrite (StatusTcpHost, &CmdHost, sizeof(CmdHost), 5000);
			break;
	}
	return 0;
}

//��ʼ��ֹͣ��ز���
int CVICALLBACK buttonFireControl (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	int test_flag;
	int mode;
	switch (event)
	{
		case EVENT_COMMIT:
			// Get fire control mode
			GetCtrlVal (PanelHandleFC, PANEL_FC_SWITCH_FIRE_CONTROL, &mode);
			switch(mode)
			{
				case 0:											 
					CmdHost.modeFireControl = MODE_FIRECONTROL_STATIC;
					break;
			    case 1:
					CmdHost.modeFireControl = MODE_FIRECONTROL_DYNAMIC;
					break;
			}
			
			// Start / stop flag
			GetCtrlVal(PanelHandleFC, PANEL_FC_T1553BUTTON, &test_flag);
			if(!test_flag)
			  	SetCtrlVal (PanelHandleFC, PANEL_FC_LED9, 0); 
				
			CmdHost.statusFireControl = test_flag;
			
			CmdHost.command = FC_FIRE_CONTROL_COMMAND;
			
			ClientTCPWrite (StatusTcpHost, &CmdHost, sizeof(CmdHost), 5000);
			break;
	}
	return 0;
}

//�Զ����ֶ�ģʽѡ��
int CVICALLBACK switchModeFC (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	int mode;
	
	switch (event)
	{
		case EVENT_COMMIT:

			GetCtrlVal (PanelHandleFC, PANEL_FC_MODULESWITCH, &mode);
			switch(mode)
			{
				case 1:	
					//�Զ�ģʽ���óɶ�̬�ɿز���
					SetCtrlVal (PanelHandleFC, PANEL_FC_SWITCH_FIRE_CONTROL, 1);
					CmdHost.modeFireControl = MODE_FIRECONTROL_DYNAMIC; 
					
				  	CmdHost.command = FC_AUTOSTART_COMMAND;
					CmdHost.statusAutostartFC = 1;
				  	ClientTCPWrite (StatusTcpHost, &CmdHost, sizeof(CmdHost), 1000);
				  	SetCtrlVal (PanelHandleFC, PANEL_FC_LED3, 1);
					
					SetCtrlAttribute (PanelHandleFC, PANEL_FC_GPSBUTTON, ATTR_DIMMED, 1);
					SetCtrlAttribute (PanelHandleFC, PANEL_FC_T1553BUTTON, ATTR_DIMMED, 1);
					SetCtrlAttribute (PanelHandleFC, PANEL_FC_YCBUTTON, ATTR_DIMMED, 1);
					SetCtrlAttribute (PanelHandleFC, PANEL_FC_STARTBUTTON, ATTR_DIMMED, 1);	   
					SetCtrlAttribute (PanelHandleFC, PANEL_FC_STOPBUTTON, ATTR_DIMMED, 1);
					SetCtrlAttribute (PanelHandleFC, PANEL_FC_QUITBUTTON, ATTR_DIMMED, 1);
					SetCtrlAttribute (PanelHandleFC, PANEL_FC_SELFTESTBUTTON, ATTR_DIMMED, 1);
					SetCtrlAttribute (PanelHandleFC, PANEL_FC_POWERSWITCH, ATTR_DIMMED, 1);
					SetCtrlAttribute (PanelHandleFC, PANEL_FC_BOARDPOWERSWITCH, ATTR_DIMMED, 1);
					break;
			    case 0:
					CmdHost.command = FC_AUTOSTART_COMMAND;
					CmdHost.statusAutostartFC = 0;
				  	ClientTCPWrite (StatusTcpHost, &CmdHost, sizeof(CmdHost), 5000);
				  	SetCtrlVal (PanelHandleFC, PANEL_FC_LED3, 0);
					
					SetCtrlAttribute (PanelHandleFC, PANEL_FC_GPSBUTTON, ATTR_DIMMED, 0);
					SetCtrlAttribute (PanelHandleFC, PANEL_FC_T1553BUTTON, ATTR_DIMMED, 0);
					SetCtrlAttribute (PanelHandleFC, PANEL_FC_YCBUTTON, ATTR_DIMMED, 0);
					SetCtrlAttribute (PanelHandleFC, PANEL_FC_STARTBUTTON, ATTR_DIMMED, 0);	   
					SetCtrlAttribute (PanelHandleFC, PANEL_FC_STOPBUTTON, ATTR_DIMMED, 0);
					SetCtrlAttribute (PanelHandleFC, PANEL_FC_QUITBUTTON, ATTR_DIMMED, 0);
					SetCtrlAttribute (PanelHandleFC, PANEL_FC_SELFTESTBUTTON, ATTR_DIMMED, 0);
					SetCtrlAttribute (PanelHandleFC, PANEL_FC_POWERSWITCH, ATTR_DIMMED, 0);
					SetCtrlAttribute (PanelHandleFC, PANEL_FC_BOARDPOWERSWITCH, ATTR_DIMMED, 0);
					break;
			}
			break;
	}
	return 0;
}


/*****��Դ���ƺ���*****/    


//��Դ��ء����ƺ���(�ɿ�) 
static int CVICALLBACK ThreadFunctionPowerFC(void *functionData)
{
	float V_FC, V_LVDS422, I_FC, I_LVDS422;  
	char tempdata[8]={0};  

	while(FlagPowerWatchFC)
	{

		//����ѭ�������ñ�־�ķ�ʽ��ֹ���ֲ�����ԴCOM���ڼ���
		if(Flag_Power5V4On)
		{   
			PowerOnFClvds422();  
	 		Flag_Power5V4On = 0;
		}
		
		if(Flag_Power5V4Off)
		{   
			PowerOffFClvds422();
	 		Flag_Power5V4Off = 0;
		}

		if(Flag_Power27On)
		{   
			PowerOnFCfc();  
	 		Flag_Power27On = 0;
		}
		
		if(Flag_Power27Off)
		{   
			PowerOffFCfc();
	 		Flag_Power27Off = 0;
		}
		
		// LVDS to 422 board 5V
		ComWrt (4, BufferPowerTest5V4, 8);
		ComRd (4, BufferPowerRead5V4, 9);
		//д�����̫��ᵼ�µ�ԴӦ�𲻹���
		Delay(0.05);			
		V_LVDS422 = (BufferPowerRead5V4[3]*16*16+BufferPowerRead5V4[4])/1000.00;
		I_LVDS422 = (BufferPowerRead5V4[5]*16*16+BufferPowerRead5V4[6])/1000.00;	
		SetCtrlVal (PanelHandleFC, PANEL_FC_V_BK, V_LVDS422);
		SetCtrlVal (PanelHandleFC, PANEL_FC_I_BK, I_LVDS422);
		if (FlagFClvds422 == 1)
		{
			SetCtrlVal (PanelHandleFC, PANEL_FC_TIME_BK, clock() / CLOCKS_PER_SEC - TimeStartFClvds422);	
		}

		// Flight control 27V
		ComWrt (3, BufferPowerTest27, 8);
		ComRd (3, BufferPowerRead27, 9);
		//д�����̫��ᵼ�µ�ԴӦ�𲻹���
		Delay(0.05);			
		V_FC = (BufferPowerRead27[3]*16*16+BufferPowerRead27[4])/1000.00;
		I_FC = (BufferPowerRead27[5]*16*16+BufferPowerRead27[6])/1000.00;	
		SetCtrlVal (PanelHandleFC, PANEL_FC_V_FC, V_FC);
		SetCtrlVal (PanelHandleFC, PANEL_FC_I_FC, I_FC);

		// Power on time
		if (FlagFCfc == 1)
		{
			SetCtrlVal (PanelHandleFC, PANEL_FC_TIME_FC, clock() / CLOCKS_PER_SEC - TimeStartFCfc);	
		}
	}
	return 0;
}

//Power on flight control (FC)
int PowerOnFCfc()
{
	char tempdata[8]={0};  	
	ComWrt (3, BufferPowerOn27, 8);
	ComRd (3, tempdata, 8);     	
  	SetCtrlVal (PanelHandleFC, PANEL_FC_LED1, 1); 
	// Disable quit button
	SetCtrlAttribute (PanelHandleFC, PANEL_FC_QUITBUTTON, ATTR_DIMMED, 1);
	// Set time flag
	FlagFCfc = 1;
	TimeStartFCfc = clock() / CLOCKS_PER_SEC;
	SetCtrlVal (PanelHandleFC, PANEL_FC_TIME_FC, 0.0);
	//��Դ�����ز����������ö����ӳ��ٽ������ݶ�ȡ������������ݽ��ղ���
	Delay(0.1); 
	return 0;     	
}

//Power off flight control (FC)
int PowerOffFCfc()
{
	char tempdata[8]={0};  
	ComWrt (3, BufferPowerOff27, 8);
	ComRd (3, tempdata, 8);  	
  	SetCtrlVal (PanelHandleFC, PANEL_FC_LED1, 0);
	// Enable quit button
	if ((StatusPower27V == 0) && (StatusPower5V == 0))
		SetCtrlAttribute (PanelHandleFC, PANEL_FC_QUITBUTTON, ATTR_DIMMED, 0);
	// Clear time flag
	FlagFCfc = 0;
	//��Դ�����ز����������ö����ӳ��ٽ������ݶ�ȡ������������ݽ��ղ���
	Delay(0.1); 	
	return 0;
	
}

//Power on lvds to 422 board (FC)
int PowerOnFClvds422()
{
	char tempdata[8]={0};
	ComWrt (4, BufferPowerOn5V4, 8); 
	ComRd (4, tempdata, 8); 
  	SetCtrlVal (PanelHandleFC, PANEL_FC_LED2, 1);
	
	// Disable quit button
	SetCtrlAttribute (PanelHandleFC, PANEL_FC_QUITBUTTON, ATTR_DIMMED, 1);
	
	// Set time flag
	FlagFClvds422 = 1;
	TimeStartFClvds422 = clock() / CLOCKS_PER_SEC;
	SetCtrlVal (PanelHandleFC, PANEL_FC_TIME_BK, 0.0);
	//��Դ�����ز����������ö����ӳ��ٽ������ݶ�ȡ������������ݽ��ղ���
	Delay(0.1); 
	return 0;
}

//Power off lvds to 422 board (FC)
int PowerOffFClvds422()
{
	char tempdata[8] = {0};
	ComWrt (4, BufferPowerOff5V4, 8);
	ComRd (4, tempdata, 8);   
	SetCtrlVal (PanelHandleFC, PANEL_FC_LED2, 0);

	// Enable quit button
	if ((StatusPower27V == 0) && (StatusPower5V == 0))
		SetCtrlAttribute (PanelHandleFC, PANEL_FC_QUITBUTTON, ATTR_DIMMED, 0);

	// Clear time flag
	FlagFClvds422 = 0;
	//��Դ�����ز����������ö����ӳ��ٽ������ݶ�ȡ������������ݽ��ղ���
	Delay(0.1); 
	return 0;
}

//�ɿ�ģ���ϵ翪�ػص�����
int CVICALLBACK PowerSwitchFC27V (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:
			GetCtrlVal (PanelHandleFC, PANEL_FC_POWERSWITCH, &StatusPower27V);
			GetCtrlVal (PanelHandleFC, PANEL_FC_BOARDPOWERSWITCH, &StatusPower5V);
			switch(StatusPower27V)
			{
				case 1:	
		 		    Flag_Power27On = 1; 
					break;
			    case 0:
		 		    Flag_Power27Off = 1;  
					break;
			}
			break;
	}
	return 0;
}

//LVDSת422�忨�ϵ翪�ػص�����
int CVICALLBACK PowerSwitchFC5V (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:
			GetCtrlVal (PanelHandleFC, PANEL_FC_POWERSWITCH, &StatusPower27V);
			GetCtrlVal (PanelHandleFC, PANEL_FC_BOARDPOWERSWITCH, &StatusPower5V);
			switch(StatusPower5V)
			{
				case 1:	
		 		    Flag_Power5V4On = 1;  
					break;
			    case 0:
					Flag_Power5V4Off = 1; 
					break;
			}
			break;
	}
	return 0;
}


/*****���ݴ�������*****/   


//����ң������
void SetYCData(void)
{
	//YC decode data
	double YCDE_Px;
	double YCDE_Py; 
	double YCDE_Pz; 
	double YCDE_Vx; 
	double YCDE_Vy; 
	double YCDE_Vz; 
	
	double R0;
	double R1;
	double R2;
	double R3;
		
	double YCDE_Yaw; 
	double YCDE_Pitch; 
	double YCDE_Roll; 
	
	double T0;
	
	SetCtrlVal (PanelHandleFC, PANEL_FC_YCTIME, DataHost.timeIntervalYC);
				
	YCDE_Px = IntToDouble(DataHost.dataYC[0x76], 204800);  
	YCDE_Py = IntToDouble(DataHost.dataYC[0x77], 204800);    
	YCDE_Pz = IntToDouble(DataHost.dataYC[0x78], 204800);    

	YCDE_Vx = IntToDouble(DataHost.dataYC[0x5A], 3200);
	YCDE_Vy = IntToDouble(DataHost.dataYC[0x5B], 3200); 
	YCDE_Vz = IntToDouble(DataHost.dataYC[0x5C], 3200); 	

	R0 = IntToDouble(DataHost.dataYC[0x79], 1);     
	R1 = IntToDouble(DataHost.dataYC[0x7A], 1);     	
	R2 = IntToDouble(DataHost.dataYC[0x7B], 1);     	
	R3 = IntToDouble(DataHost.dataYC[0x7C], 1);     	
	                                                                	
	YCDE_Yaw   =-atan2(2*(R1*R3-R2*R0),R0*R0+R1*R1-R2*R2-R3*R3)*180/pi;  	
	YCDE_Pitch = asin(2*(R1*R2+R0*R3))*180/pi;                           	
	YCDE_Roll  =-atan2(2*(R2*R3-R1*R0),R0*R0-R1*R1+R2*R2-R3*R3)*180/pi; 
	
	T0 = IntToDouble(DataHost.dataYC[0x3D], 2048); 
	
	SetCtrlVal (PanelHandleFC, PANEL_FC_XR, YCDE_Px);  	
	SetCtrlVal (PanelHandleFC, PANEL_FC_YR, YCDE_Py);  	
	SetCtrlVal (PanelHandleFC, PANEL_FC_ZR, YCDE_Pz);  
	
	SetCtrlVal (PanelHandleFC, PANEL_FC_VRX, YCDE_Vx);  
	SetCtrlVal (PanelHandleFC, PANEL_FC_VRY, YCDE_Vy);  
	SetCtrlVal (PanelHandleFC, PANEL_FC_VRZ, YCDE_Vz);  
	
	SetCtrlVal (PanelHandleFC, PANEL_FC_YAW, YCDE_Yaw);  
	SetCtrlVal (PanelHandleFC, PANEL_FC_PITCH, YCDE_Pitch);  
	SetCtrlVal (PanelHandleFC, PANEL_FC_ROLL, YCDE_Roll); 
	
	SetCtrlVal (PanelHandleFC, PANEL_FC_T0, T0); 	
}

//����GPS��������
void SetGNSSFC422Data(void)
{
	int i;
	
	SetCtrlVal (PanelHandleFC, PANEL_FC_GPSTIME, DataHost.gps_time);
	//SetCtrlVal (PanelHandleFC, PANEL_GPSFIRSTDATA, DataHost.gps_firstdata);  
	//SetCtrlVal (PanelHandleFC, PANEL_LON, DataHost.Lon);
	//SetCtrlVal (PanelHandleFC, PANEL_LAT, DataHost.Lat); 
	//SetCtrlVal (PanelHandleFC, PANEL_ALT, DataHost.Alt);
	//SetCtrlVal (PanelHandleFC, PANEL_PDOP, DataHost.PDOP);
	
	/*fprintf(FileHandleGNSSFC422, "%f\t", DataHost.gps_time);
	for (i = 0; i < 339; i ++)
	{
		fprintf(FileHandleGNSSFC422, "%02x\t", DataHost.gnss422Data[i]);
	}
	fprintf(FileHandleGNSSFC422, "\r\n");*/ 
}

//1553���ݱ�����ʾ
void SetFC1553Data(void)
{
	int i, j;
	int TableType;
	Point PointTemp;
	
	if ((DataHost.dataType[1] == 'T') || (DataHost.dataType[2] == 'T'))
	{
		TableType = 1;
		PointTemp.x = 1;
		PointTemp.y = 1;	
	   	SetTableCellAttribute (PanelHandleFC, PANEL_FC_TABLE_1553RECEIVE, PointTemp, ATTR_CTRL_VAL, DataHost.dataType);
	}
	else if((DataHost.dataType[1] == 'R') || (DataHost.dataType[2] == 'R'))
	{
		TableType = 0;	
		if((DataHost.dataType[0] == '3') && (DataHost.dataType[1] == '0'))
		{
			PointTemp.x = 1;
			PointTemp.y = 2;	
		   	SetTableCellAttribute (PanelHandleFC, PANEL_FC_TABLE_1553SEND, PointTemp, ATTR_CTRL_VAL, DataHost.dataType);		
		}
		else
		{
			PointTemp.x = 1;
			PointTemp.y = 1;	
		   	SetTableCellAttribute (PanelHandleFC, PANEL_FC_TABLE_1553SEND, PointTemp, ATTR_CTRL_VAL, DataHost.dataType);		
		}
	}
	else
		TableType = -1;

	for(i = 0; i < 30; i ++ )
	{
		PointTemp.x = i + 2;
		if((DataHost.dataType[0] == '3') && (DataHost.dataType[1] == '0')) 
			PointTemp.y = 2;
		else
			PointTemp.y = 1;		
		
		if(TableType == 0)
			SetTableCellAttribute (PanelHandleFC, PANEL_FC_TABLE_1553SEND, PointTemp, ATTR_CTRL_VAL, DataHost.dataFlightControl[i]);	
		else if(TableType == 1)
			SetTableCellAttribute (PanelHandleFC, PANEL_FC_TABLE_1553RECEIVE, PointTemp, ATTR_CTRL_VAL, DataHost.dataFlightControl[i]);	
		else;
	}
}


/*******************************  ʵ�������������Host Panel Callback ****************************/ 
int CVICALLBACK TestAnalysis (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:
			
			PanelHandleTestAnalysis = LoadPanel (PanelHandleTestAnalysis, "ʵ����������Host.uir", PANELANA);
			
			SetPanelAttribute (PanelHandleTestAnalysis, ATTR_WINDOW_ZOOM, VAL_MAXIMIZE);
			
			DisplayPanel(PanelHandleTestAnalysis);			
			
			break;
	}
	return 0;
}

int CVICALLBACK QUIT_TestAnalysis (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:
			DiscardPanel (PanelHandleTestAnalysis);
			PanelHandleTestAnalysis = 0;
			break;
	}
	return 0;
}

int CVICALLBACK Read_IMU_Simulation (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:
			
            stateSimulationIMUSetFileSelectPopup=FileSelectPopup ("c:\\", "*.txt", "*.txt", 
				 "��ȡ��׼�켣���������ļ�",  VAL_OK_BUTTON , 0, 0, 1, 0, IMUSimSetFilePath);
			 
			SetCtrlVal (PanelHandleTestAnalysis, PANELANA_IMUSimulation_Read, IMUSimSetFilePath);
			
			break;
	}
	return 0;
}

int CVICALLBACK Read_IMU_Test (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:
             stateTestIMUSetFileSelectPopup=FileSelectPopup ("c:\\", "*.txt", "*.txt", 
				 "��ȡ��׼�켣���������ļ�",  VAL_OK_BUTTON , 0, 0,1, 0, IMUTestSetFilePath);
			 
			SetCtrlVal (PanelHandleTestAnalysis, PANELANA_IMUTest_Read, IMUTestSetFilePath);
			break;
	}
	return 0;
}

int CVICALLBACK Read_FC_Test (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:
             stateTestFCSetFileSelectPopup=FileSelectPopup ("c:\\", "*.txt", "*.txt", 
				 "��ȡ��׼�켣���������ļ�",  VAL_OK_BUTTON , 0, 0,1, 0, FCTestSetFilePath);
			 
			SetCtrlVal (PanelHandleTestAnalysis, PANELANA_FCTest_Read, FCTestSetFilePath);
			break;
	}
	return 0;
}

int CVICALLBACK Read_GNSS_Test (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:
             stateTestGNSSSetFileSelectPopup=FileSelectPopup ("c:\\", "*.txt", "*.txt", 
				 "��ȡ��׼�켣���������ļ�",  VAL_OK_BUTTON , 0, 0,1, 0, GNSSTestSetFilePath);
			 
			SetCtrlVal (PanelHandleTestAnalysis, PANELANA_GNSSTest_Read, GNSSTestSetFilePath);
			break;
	}
	return 0;
}

int CVICALLBACK TestAnalysis_IMU (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	double TraceTime_pulse; 		
	double Time_pulse; 
	double GyroAngleRate_pulse[3][1] ;
	double Acc_pulse[3][1]; 	
	double Angle_pulse[3][1]; 
	int GyroPulseNum_pulse[3][1];
	int AccPulseNum_pulse[3][1]; 
                          
	switch (event)
	{
		case EVENT_COMMIT:

		    NavDataFileHandle = fopen("c:\\NavData.txt","wb");
			
			TraceNumber=0;
			
			GetCtrlVal(PanelHandleIM, PANEL_IM_COUNTERTIME, &IMUSamplingInterval);  
			switch(IMUSamplingInterval)
			{
				case 1 :
			          CraftNavigationStepSize = 0.001;   //1ms 
					  break;
					
				case 2 :
			          CraftNavigationStepSize = 0.003;   //3ms 
					  break;
					  
				case 3 :
			          CraftNavigationStepSize = 0.004;   //4ms 
					  break;					  
					  
				case 4 :
			          CraftNavigationStepSize = 0.005;   //5ms 
					  break;					  
			}

			CmdHost.command = ANALYSIS_INIT_PRA_RD;	
			ClientTCPWrite (StatusTcpHost, &CmdHost, sizeof(CmdHost), 5000);  
			ClientTCPRead (StatusTcpHost, &CraftPara, sizeof(CraftPara), 5000); 
			
			pulse_FileHandle = fopen(IMUTestSetFilePath,"r");
			
			InitialVariable();
			InitialPara();
			
			double cbg[3][3];
			double alpha;
			Vec2Vec(CraftAttitude,CraftInsAttitude_Test);
			Att2DCMEnu(CraftInsAttitude_Test,cbg);
			DCM2QTN(cbg,CraftInsQtnS_Test);
			Vec2Vec(CraftVelocity,CraftInsVelocityP_Test);
			alpha=0;
//	        CalCep(&CraftPosition[0][0],&CraftPosition[1][0],&alpha,CraftInsCep_Test);
			Vec2Vec(CraftPosition,CraftInsPosition_Test);
			CraftInsAltitude_Test=CraftPosition[2][0];
			
			
 			while(pulse_FileHandle != NULL)
			{	
	
					
				if((feof(pulse_FileHandle)))
				{   			
					fclose(pulse_FileHandle);
					break;
				}
				else
				{
					fscanf(pulse_FileHandle,"%lf", &TraceTime_pulse); 			
					fscanf(pulse_FileHandle,"%lf", &Time_pulse); 	
				
					fscanf(pulse_FileHandle,"%ld", &AccPulseNum_pulse[0][0]); 			
					fscanf(pulse_FileHandle,"%ld", &AccPulseNum_pulse[1][0]); 			
					fscanf(pulse_FileHandle,"%ld", &AccPulseNum_pulse[2][0]);	
					fscanf(pulse_FileHandle,"%ld", &GyroPulseNum_pulse[0][0]); 	//���»�����ǽǶ�		
					fscanf(pulse_FileHandle,"%ld", &GyroPulseNum_pulse[1][0]); 			
					fscanf(pulse_FileHandle,"%ld", &GyroPulseNum_pulse[2][0]); 			

				
/*					fscanf(pulse_FileHandle,"%lf", &GyroAngleRate_pulse[0][0]); //���»�����ǽǶ�		
					fscanf(pulse_FileHandle,"%lf", &GyroAngleRate_pulse[1][0]); 			
					fscanf(pulse_FileHandle,"%lf", &GyroAngleRate_pulse[2][0]);			
					fscanf(pulse_FileHandle,"%lf", &Acc_pulse[0][0]); 			
					fscanf(pulse_FileHandle,"%lf", &Acc_pulse[1][0]); 			
					fscanf(pulse_FileHandle,"%lf", &Acc_pulse[2][0]);
*/				
					
					
		            SinsNavPulse_2_Trace(AccPulseNum_pulse, GyroPulseNum_pulse, CraftInsQtnS_Test, CraftInsVelocityP_Test, 
						CraftInsCep_Test, &CraftInsAltitude_Test, CraftNavigationStepSize,
						CraftInsPosition_Test, CraftInsAttitude_Test,&CraftSNavGravity_Test);
					
					AlgorithmTestResult();
					TraceNumber++;
				}	 
			}
			for(int i = 0; i <= TraceNumber - 2; i++)
			{
				fprintf(NavDataFileHandle,"%d    ", i+1);
				fprintf(NavDataFileHandle,"%f    ", CraftPositionPlot[0][i]/DEGREE);
				fprintf(NavDataFileHandle,"%f    ", CraftPositionPlot[0][i]/DEGREE);
				fprintf(NavDataFileHandle,"%f    ", CraftPositionPlot[0][i]);
				fprintf(NavDataFileHandle,"%f    ", CraftVelocityPlot[0][i]);
				fprintf(NavDataFileHandle,"%f    ", CraftVelocityPlot[0][i]);
				fprintf(NavDataFileHandle,"%f    ", CraftVelocityPlot[2][i]);
				fprintf(NavDataFileHandle,"%f    ", CraftAttitudePlot[0][i]/DEGREE);
				fprintf(NavDataFileHandle,"%f    ", CraftAttitudePlot[1][i]/DEGREE);
				fprintf(NavDataFileHandle,"%f    ", CraftAttitudePlot[2][i]/DEGREE);			
				fprintf(NavDataFileHandle, "\r\n");	
			}
			
			CraftTracePlot();
			
		    fclose(NavDataFileHandle); 	
			
/*			CraftData_FileHandle=fopen(IMUSimSetFilePath,"r");

            if(feof(CraftData_FileHandle))
			{
				fclose(CraftData_FileHandle);
				break;  
			}
			else
			{
				fscanf(CraftData_FileHandle,"%lf", &TraceTime); 			
				fscanf(CraftData_FileHandle,"%lf", &CraftPosition[0][0]); 	//���»�����ǽǶ�		
				fscanf(CraftData_FileHandle,"%lf", &CraftPosition[1][0]); 			
				fscanf(CraftData_FileHandle,"%lf", &CraftPosition[2][0]); 			
				fscanf(CraftData_FileHandle,"%lf", &CraftVelocity[0][0]); 			
				fscanf(CraftData_FileHandle,"%lf", &CraftVelocity[1][0]); 			
				fscanf(CraftData_FileHandle,"%lf", &CraftVelocity[2][0]); 			
				fscanf(CraftData_FileHandle,"%lf", &CraftAcc[0][0]); 			
				fscanf(CraftData_FileHandle,"%lf", &CraftAcc[1][0]); 			
				fscanf(CraftData_FileHandle,"%lf", &CraftAcc[2][0]); 			
				fscanf(CraftData_FileHandle,"%lf", &CraftAttitude[0][0]); 	//���»�����ǽǶ�		
				fscanf(CraftData_FileHandle,"%lf", &CraftAttitude[1][0]); 			
				fscanf(CraftData_FileHandle,"%lf", &CraftAttitude[2][0]); 			
				fscanf(CraftData_FileHandle,"%lf", &CraftAttitudeChangeRate[1][0]); 	//���»�����ǽǶ�		
				fscanf(CraftData_FileHandle,"%lf", &CraftAttitudeChangeRate[2][0]); 			
				fscanf(CraftData_FileHandle,"%lf", &CraftAttitudeChangeRate[3][0]); 			
			
				fscanf(CraftData_FileHandle,"%lf", &CraftSFB[0][0]); 			
				fscanf(CraftData_FileHandle,"%lf", &CraftSFB[1][0]); 			
				fscanf(CraftData_FileHandle,"%lf", &CraftSFB[2][0]);            
				fscanf(CraftData_FileHandle,"%lf", &CraftOmegaiBB[0][0]); 			
				fscanf(CraftData_FileHandle,"%lf", &CraftOmegaiBB[1][0]); 			
				fscanf(CraftData_FileHandle,"%lf", &CraftOmegaiBB[2][0]);
			
				fscanf(CraftData_FileHandle,"%lf", &CraftInsSFs[0][0]); 			
				fscanf(CraftData_FileHandle,"%lf", &CraftInsSFs[1][0]); 			
				fscanf(CraftData_FileHandle,"%lf", &CraftInsSFs[2][0]); 
				fscanf(CraftData_FileHandle,"%lf", &CraftInsOmegaiBBs[0][0]); 			
				fscanf(CraftData_FileHandle,"%lf", &CraftInsOmegaiBBs[1][0]); 			
				fscanf(CraftData_FileHandle,"%lf", &CraftInsOmegaiBBs[2][0]); 
				fscanf(CraftData_FileHandle,"%d", &CraftFPulseOut[0][0]); 			
				fscanf(CraftData_FileHandle,"%d", &CraftFPulseOut[1][0]); 			
				fscanf(CraftData_FileHandle,"%d", &CraftFPulseOut[2][0]); 
				fscanf(CraftData_FileHandle,"%d", &CraftGPulseOut[0][0]); 			
				fscanf(CraftData_FileHandle,"%d", &CraftGPulseOut[1][0]); 			
				fscanf(CraftData_FileHandle,"%d", &CraftGPulseOut[2][0]); 
			
				fscanf(CraftData_FileHandle,"%d", &CraftNavFlag); 			
				fscanf(CraftData_FileHandle,"%lf", &CraftInsPosition[0][0]); 	//���»�����ǽǶ�		
				fscanf(CraftData_FileHandle,"%lf", &CraftInsPosition[1][0]); 			
				fscanf(CraftData_FileHandle,"%lf", &CraftInsPosition[2][0]); 
				fscanf(CraftData_FileHandle,"%lf", &CraftInsVelocityP[0][0]); 			
				fscanf(CraftData_FileHandle,"%lf", &CraftInsVelocityP[1][0]); 			
				fscanf(CraftData_FileHandle,"%lf", &CraftInsVelocityP[0][0]); 			
				fscanf(CraftData_FileHandle,"%lf", &CraftInsAttitude[1][0]); 	//���»�����ǽǶ�		
				fscanf(CraftData_FileHandle,"%lf", &CraftInsAttitude[2][0]); 			
				fscanf(CraftData_FileHandle,"%lf", &CraftInsAttitude[2][0]); 			
                              
                              
				fscanf(CraftData_FileHandle,"%lf", &CraftPositionCha[0][0]); 			
				fscanf(CraftData_FileHandle,"%lf", &CraftPositionCha[1][0]); 			
				fscanf(CraftData_FileHandle,"%lf", &CraftPositionCha[2][0]);                              
				fscanf(CraftData_FileHandle,"%lf", &CraftVelocityCha[0][0]); 			
				fscanf(CraftData_FileHandle,"%lf", &CraftVelocityCha[1][0]); 			
				fscanf(CraftData_FileHandle,"%lf", &CraftVelocityCha[2][0]);
				fscanf(CraftData_FileHandle,"%lf", &AttCha[0][0]); 	//���»�����ǽǶ�			
				fscanf(CraftData_FileHandle,"%lf", &AttCha[1][0]); 			
				fscanf(CraftData_FileHandle,"%lf", &AttCha[2][0]);
			
				fscanf(CraftData_FileHandle,"%d", &FcsNavFlag); 			
				fscanf(CraftData_FileHandle,"%lf", &FcsPos[0][0]); 			
				fscanf(CraftData_FileHandle,"%lf", &FcsPos[1][0]); 			
				fscanf(CraftData_FileHandle,"%lf", &FcsPos[2][0]);
				fscanf(CraftData_FileHandle,"%lf", &FcsVel[0][0]); 			
				fscanf(CraftData_FileHandle,"%lf", &FcsVel[1][0]); 			
				fscanf(CraftData_FileHandle,"%lf", &FcsVel[2][0]);			
				fscanf(CraftData_FileHandle,"%lf", &FcsAttitude[0][0]); 	//���»�����ǽǶ�		
				fscanf(CraftData_FileHandle,"%lf", &FcsAttitude[1][0]); 			
				fscanf(CraftData_FileHandle,"%lf", &FcsAttitude[2][0]); 
				fscanf(CraftData_FileHandle,"%lf", &FcsQtn[0][0]); 			
				fscanf(CraftData_FileHandle,"%lf", &FcsQtn[1][0]); 			
				fscanf(CraftData_FileHandle,"%lf", &FcsQtn[2][0]); 
				fscanf(CraftData_FileHandle,"%lf", &FcsQtn[3][0]); 			
				fscanf(CraftData_FileHandle,"%lf", &FcsGravity[0][0]); 			
				fscanf(CraftData_FileHandle,"%lf", &FcsGravity[1][0]); 			
				fscanf(CraftData_FileHandle,"%lf", &FcsGravity[2][0]); 
				fscanf(CraftData_FileHandle,"%lf", &CraftSNavGravity); 
			}			
*/					
			
			
 			break;
	}
	return 0;
}

int CVICALLBACK TestAnalysis_FC (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	int AP;
	double YC_Time;
	double PSX, PSY, PSZ;
	double NBX, NBY, NBZ;
	double NWX, NWY, NWZ;
	double R0, R1, R2, R3;
	double Yaw, Pitch, Roll;
	double XR, YR, ZR;
	double VRX, VRY, VRZ;
	double PRVX, PRVY, PRVZ;
	double DVOX, DVOY, DVOZ;
	double GX, GY, GZ;
	double DR1, DR2, DR3;
	double VNX, VNY, VNZ;
	double T0; 
	float RotaryGet_Angle[3];
	float RotaryGet_AngleRate[3];
	
	switch (event)
	{
		case EVENT_COMMIT:
			
			FC_FileHandle = fopen(FCTestSetFilePath,"r");
 			while(FC_FileHandle != NULL)
			{	
				if((feof(FC_FileHandle)))
				{   			
					fclose(FC_FileHandle);
					break;
				}
				else
				{
					fscanf(FC_FileHandle,"%lf", &YC_Time); 			
					fscanf(FC_FileHandle,"%lf", &AP); 	
				
					fscanf(FC_FileHandle,"%lf", &PSX); 			
					fscanf(FC_FileHandle,"%lf", &PSY); 			
					fscanf(FC_FileHandle,"%lf", &PSZ);	
					fscanf(FC_FileHandle,"%lf", &NWX); 			
					fscanf(FC_FileHandle,"%lf", &NWY); 			
					fscanf(FC_FileHandle,"%lf", &NWZ); 			

				
					fscanf(FC_FileHandle,"%lf", &NBX); 		
					fscanf(FC_FileHandle,"%lf", &NBY); 			
					fscanf(FC_FileHandle,"%lf", &NBZ);			
					fscanf(FC_FileHandle,"%lf", &R0); 			
					fscanf(FC_FileHandle,"%lf", &R1); 			
					fscanf(FC_FileHandle,"%lf", &R2);
					fscanf(FC_FileHandle,"%lf", &R3);
					
					fscanf(FC_FileHandle,"%lf", &Yaw  ); 	
					fscanf(FC_FileHandle,"%lf", &Pitch); 			
					fscanf(FC_FileHandle,"%lf", &Roll );			
					fscanf(FC_FileHandle,"%lf", &XR); 			
					fscanf(FC_FileHandle,"%lf", &YR); 			
					fscanf(FC_FileHandle,"%lf", &ZR);					
					fscanf(FC_FileHandle,"%lf", &VRX);	
					fscanf(FC_FileHandle,"%lf", &VRY);
					fscanf(FC_FileHandle,"%lf", &VRZ);	
					
					fscanf(FC_FileHandle,"%lf", &PRVX); 		
					fscanf(FC_FileHandle,"%lf", &PRVY); 			
					fscanf(FC_FileHandle,"%lf", &PRVZ);	
					
					fscanf(FC_FileHandle,"%lf", &DVOX); 			
					fscanf(FC_FileHandle,"%lf", &DVOY); 			
					fscanf(FC_FileHandle,"%lf", &DVOZ);	
					
					fscanf(FC_FileHandle,"%lf", &GX); 		
					fscanf(FC_FileHandle,"%lf", &GY); 
					fscanf(FC_FileHandle,"%lf", &GZ); 														 
													  	 
					fscanf(FC_FileHandle,"%lf", &DR1);		
					fscanf(FC_FileHandle,"%lf", &DR2); 			
					fscanf(FC_FileHandle,"%lf", &DR3);	
					
					fscanf(FC_FileHandle,"%lf", &VNX); 			
					fscanf(FC_FileHandle,"%lf", &VNY); 			
					fscanf(FC_FileHandle,"%lf", &VNZ);	
					
					fscanf(FC_FileHandle,"%lf", &T0); 
					
					fscanf(FC_FileHandle,"%lf", &RotaryGet_Angle[0]);		
					fscanf(FC_FileHandle,"%lf", &RotaryGet_Angle[1]); 			
					fscanf(FC_FileHandle,"%lf", &RotaryGet_Angle[2]);	
					
					fscanf(FC_FileHandle,"%lf", &RotaryGet_AngleRate[0]); 			
					fscanf(FC_FileHandle,"%lf", &RotaryGet_AngleRate[1]); 			
					fscanf(FC_FileHandle,"%lf", &RotaryGet_AngleRate[2]);	
					
					CraftPositionPlot[0][TraceNumber]=XR;
					CraftPositionPlot[1][TraceNumber]=YR;
					CraftPositionPlot[2][TraceNumber]=ZR;

					CraftVelocityPlot[0][TraceNumber]=VRX;
					CraftVelocityPlot[1][TraceNumber]=VRY;
					CraftVelocityPlot[2][TraceNumber]=VRZ;

					CraftAttitudePlot[0][TraceNumber]=Yaw; //��ͼ��ʾ�Ƕ�
					CraftAttitudePlot[1][TraceNumber]=Pitch;					
					CraftAttitudePlot[2][TraceNumber]=Roll;						
					
					TraceNumber++;
				}	 
			}
			
			CraftTracePlot();			
		
			break;
	}
	return 0;
}

int CVICALLBACK TestAnalysis_GNSS (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	double PPS_Time;
	double GNSS_Time; 	
	double GNSSResearch_Time;

	double SatNum;	
	double PDOP; 				  
	double Pos_Qua; 		
		    
	double GNSS_Lon, GNSS_Lat, GNSS_Alt; 		
	double GNSS_PosX, GNSS_PosY, GNSS_PosZ; 		
	double GNSS_VelX, GNSS_VelY, GNSS_VelZ; 		

	double Sat_NumOrder[10];
	double Sat_NR[10];	
	double Sat_PseRan[10];
	double Sat_PseRanD[10]; 
	double Sat_PosX[10]; 
	double Sat_PosY[10]; 
	double Sat_PosZ[10];
	double Sat_VelX[10]; 
	double Sat_VelY[10]; 
	double Sat_VelZ[10];
	
	switch (event)
	{
		case EVENT_COMMIT:
			
			int i;
			GNSS_FileHandle = fopen(GNSSTestSetFilePath,"r");
 			while(GNSS_FileHandle != NULL)
			{	
				if((feof(GNSS_FileHandle)))
				{   			
					fclose(GNSS_FileHandle);
					break;
				}
				else
				{
					fscanf(GNSS_FileHandle,"%lf", &PPS_Time); 		            //PPS����ʱ�� 	
					fscanf(GNSS_FileHandle,"%lf", &GNSSResearch_Time); 			//GNSS����ʱ��
																	            
					fscanf(GNSS_FileHandle,"%lf", &GNSS_Time); 	    //GNSS��ʱ��   		        
					fscanf(GNSS_FileHandle,"%lf", &Pos_Qua); 		//��λ����   	                
					fscanf(GNSS_FileHandle,"%lf", &SatNum);		    //������ 	                    
					fscanf(GNSS_FileHandle,"%lf", &GNSS_Lon); 		//γ��	   
					fscanf(GNSS_FileHandle,"%lf", &GNSS_Lat); 		//����	   
					fscanf(GNSS_FileHandle,"%lf", &GNSS_Alt); 		//�߶�
					fscanf(GNSS_FileHandle,"%lf", &PDOP); 		    //PDOP
					fscanf(GNSS_FileHandle,"%lf", &GNSS_PosX); 		//����X   
					fscanf(GNSS_FileHandle,"%lf", &GNSS_PosY);		//����Y 				    
					fscanf(GNSS_FileHandle,"%lf", &GNSS_PosZ); 		//����Z   
					fscanf(GNSS_FileHandle,"%lf", &GNSS_VelX); 			//�ٶ�X   
					fscanf(GNSS_FileHandle,"%lf", &GNSS_VelY);			//�ٶ�Y   
					fscanf(GNSS_FileHandle,"%lf", &GNSS_VelZ); 			//�ٶ�Z 
					
					for(i = 0; i < 10; i ++)
					{
						fscanf(GNSS_FileHandle,"%lf", &Sat_NumOrder[i]);   //ͨ�����Ǳ�� 
						fscanf(GNSS_FileHandle,"%lf", &Sat_NR[i]);			   //ͨ�������   
						fscanf(GNSS_FileHandle,"%lf", &Sat_PseRan[i]);				   //ͨ��α��   
						fscanf(GNSS_FileHandle,"%lf", &Sat_PseRanD[i] ); 			   //ͨ��α����  
						fscanf(GNSS_FileHandle,"%lf", &Sat_PosX[i]); 			   //ͨ����������X
						fscanf(GNSS_FileHandle,"%lf", &Sat_PosY[i]); 			   //ͨ����������Y
						fscanf(GNSS_FileHandle,"%lf", &Sat_PosZ[i]);			   //ͨ����������Z
						fscanf(GNSS_FileHandle,"%lf", &Sat_VelX[i]); 			   //ͨ�������ٶ�Vx
						fscanf(GNSS_FileHandle,"%lf", &Sat_VelY[i]); 			   //ͨ�������ٶ�Vy
						fscanf(GNSS_FileHandle,"%lf", &Sat_VelZ[i]);				   //ͨ�������ٶ�Vz					
					}

					CraftPositionPlot[0][TraceNumber]=GNSS_PosX;
					CraftPositionPlot[1][TraceNumber]=GNSS_PosY;
					CraftPositionPlot[2][TraceNumber]=GNSS_PosZ;

					CraftVelocityPlot[0][TraceNumber]=GNSS_VelX;
					CraftVelocityPlot[1][TraceNumber]=GNSS_VelY;
					CraftVelocityPlot[2][TraceNumber]=GNSS_VelZ;
					
					TraceNumber++;
				}	 
			}
			
			CraftTracePlot();			
			break;
	}
	return 0;
}

void InitialPara()
{
    //��ʼ������������������λ����ʹ�ã� 
	CraftGyroQuantizationFactor_rad=CraftGyroQuantizationFactor*pi/(180*3600);
	
	CraftPosition[0][0]=CraftIniLongitude*DEGREE;   //��ת��Ϊ����
	CraftPosition[1][0]=CraftIniLatitude*DEGREE;
	CraftPosition[2][0]=CraftIniAltitude;
	
	CraftAttitude[0][0]=CraftIniYaw*DEGREE;//�ػ���̬����Ե���ϵ��(����ϵΪ������)
	CraftAttitude[1][0]=CraftIniPitch*DEGREE;
	CraftAttitude[2][0]=CraftIniRoll*DEGREE;	
	
	MissileMountAngle[0][0]=MissileMountAngle[0][0]*DEGREE;
	MissileMountAngle[1][0]=MissileMountAngle[1][0]*DEGREE;
	MissileMountAngle[2][0]=MissileMountAngle[2][0]*DEGREE;
	
	MissileMountAngleError[0][0]=MissileMountAngleError[0][0]*DEGREE;
	MissileMountAngleError[1][0]=MissileMountAngleError[1][0]*DEGREE;
	MissileMountAngleError[2][0]=MissileMountAngleError[2][0]*DEGREE;																	
	
    CraftVelocity[0][0]=CraftIniForwardVelocity*cos(CraftAttitude[1][0])*sin(CraftAttitude[0][0]);
    CraftVelocity[1][0]=CraftIniForwardVelocity*cos(CraftAttitude[1][0])*cos(CraftAttitude[0][0]);
    CraftVelocity[2][0]=CraftIniForwardVelocity*sin(CraftAttitude[1][0]);	
    
	CraftForwardVelocity=CraftIniForwardVelocity;//���ػ��������ý�����ػ�ǰ���ٶȳ�ֵ�����¸��������ػ��켣���������еı���

	CraftAccelerometerBias[0][0]=CraftAccelerometerConstBias[0][0]+CraftAccelerometerRandomBias[0][0];
	CraftAccelerometerBias[1][0]=CraftAccelerometerConstBias[1][0]+CraftAccelerometerRandomBias[1][0];
	CraftAccelerometerBias[2][0]=CraftAccelerometerConstBias[2][0]+CraftAccelerometerRandomBias[2][0];
	
	CraftGyroDrift[0][0]=CraftGyroConstDrift[0][0]+CraftGyroRandomDrift[0][0];
	CraftGyroDrift[1][0]=CraftGyroConstDrift[1][0]+CraftGyroRandomDrift[1][0];
	CraftGyroDrift[2][0]=CraftGyroConstDrift[2][0]+CraftGyroRandomDrift[2][0];	
	
	MissileAccelerometerBias[0][0]=MissileAccelerometerConstBias[0][0]+MissileAccelerometerRandomBias[0][0];
	MissileAccelerometerBias[1][0]=MissileAccelerometerConstBias[1][0]+MissileAccelerometerRandomBias[1][0];
	MissileAccelerometerBias[2][0]=MissileAccelerometerConstBias[2][0]+MissileAccelerometerRandomBias[2][0];
	
//	MissileGyroDrift[0][0]=RotaryAmp[0][0]+RotaryFre[0][0];
//	MissileGyroDrift[1][0]=RotaryAmp[1][0]+RotaryFre[1][0];
//	MissileGyroDrift[2][0]=RotaryAmp[2][0]+RotaryFre[2][0];	


    //������
    CountCraftNav=0;  //���ߵ��Ƿ���Ч�жϵļ�����
    CountFcsNav=0;//��ص����Ƿ���Ч�жϵļ�����
    CountFcsOutput=0;//�����Ϣ�����Ч�жϵļ�����
    CountMissileGyro=0; //�ӹߵ���������Ч�жϵļ�����
    CountMissileAcce=0; //�ӹߵ���������Ч�жϵļ�����
    CountMissileNav=0;  //�ӹߵ��Ƿ���Ч�жϵļ�����
    CountTa=0;    //�Ƿ��˶�׼��Ч�жϵļ�����
    TaCount=0;    //���ݶ�׼���������������һ��ʱ���ӹߵ�����У�� 

    //��Ч��ǣ���Ч������ڼ���ֵ����������ֵʱ��Ч
 	CraftInsInitialFlag=0;
	CraftTraceLoopFlag=0;
    CraftNavFlag=0;//���ߵ��������
    FcsNavFlag=0;//��ص������
    FcsOutputFlag=0;//�����Ϣ������
    MissileNavFlag=0;//�ӹߵ��������
    MissileAcceFlag=0;//�ӼӼ���Ч���
    MissileGyroFlag=0;//��������Ч���
    TaFlag=0;//���ݶ�׼��Ч���
    FcsFirstOutput=0;//�����Ϣ��һ�ν��뵽�ӹߵ�
 
    //��������ֵ
	MaxCountCraftNav=CraftNavigationStepSize/CraftTraceStepSize;//���ߵ�����
	MaxCountFcsNav=FcsNavigationStepSize/CraftTraceStepSize;//��ص���
	MaxCountFcsOutput=FcsOutputStepSize/CraftTraceStepSize;//�����Ϣ���
	MaxCountMissileGyro=MissileGyroStepSize/CraftTraceStepSize;//������
	MaxCountMissileAcce=MissileAccelerometerStepSize/CraftTraceStepSize;//�ӼӼ�
	MaxCountMissileNav=MissileNavigationStepSize/CraftTraceStepSize;//�ӵ���
	MaxCountOutput=OutputStepSize/CraftTraceStepSize;//���   

    MissileAccelerometerCrossCoupling[0][0]=0;   //���ӹߵ����ٶȼƽ�����Ͼ���ĶԽ���Ԫ�ظ���ֵ
    MissileAccelerometerCrossCoupling[1][1]=0; 
    MissileAccelerometerCrossCoupling[2][2]=0; 	
	
    MissileGyroCrossCoupling[0][0]=0;   //���ӹߵ����ݼƽ�����Ͼ���ĶԽ���Ԫ�ظ���ֵ
    MissileGyroCrossCoupling[1][1]=0; 
    MissileGyroCrossCoupling[2][2]=0; 	

    RelVel[0][0]=0;//����ٶ�
    RelVel[1][0]=0;
    RelVel[2][0]=0;	
}

void InitialVariable()
{
	CraftAccelerometerQuantizationFactor=CraftPara.CraftAccelerometerQuantizationFactor;
	CraftGyroQuantizationFactor=CraftPara.CraftGyroQuantizationFactor;	
	
	SmoothTimePercent=CraftPara.SmoothTimePercent;

	CraftIniLongitude=CraftPara.CraftIniLongitude;
	CraftIniLatitude=CraftPara.CraftIniLatitude;
	CraftIniAltitude=CraftPara.CraftIniAltitude;
    CraftIniForwardVelocity=CraftPara.CraftIniForwardVelocity;   //ǰ���ٶ��Ǳ���
	CraftIniYaw=CraftPara.CraftIniYaw;
	CraftIniPitch=CraftPara.CraftIniPitch;
	CraftIniRoll=CraftPara.CraftIniRoll;
	
    CraftPosition[0][0]=CraftPara.CraftPosition[0][0];  //��λ:��
	CraftPosition[1][0]=CraftPara.CraftPosition[1][0];
	CraftPosition[2][0]=CraftPara.CraftPosition[2][0];
	
    CraftVelocity[0][0]=CraftPara.CraftVelocity[0][0];
	CraftVelocity[1][0]=CraftPara.CraftVelocity[1][0];  
	CraftVelocity[2][0]=CraftPara.CraftVelocity[2][0];  
	
    CraftAttitude[0][0]=CraftPara.CraftAttitude[0][0];
	CraftAttitude[1][0]=CraftPara.CraftAttitude[1][0];
	CraftAttitude[2][0]=CraftPara.CraftAttitude[2][0];

    //�ػ����ߵ�����
	CraftAccelerometerBias[0][0]=CraftPara.CraftAccelerometerConstBias[0][0]+CraftPara.CraftAccelerometerRandomBias[0][0];  //�ӼƳ�ֵ��ƫ+�Ӽ������ƫ=�Ӽ�����ƫ
	CraftAccelerometerBias[1][0]=CraftPara.CraftAccelerometerConstBias[1][0]+CraftPara.CraftAccelerometerRandomBias[1][0];	
	CraftAccelerometerBias[2][0]=CraftPara.CraftAccelerometerConstBias[2][0]+CraftPara.CraftAccelerometerRandomBias[2][0];
	
	CraftAccelerometerConstBias[0][0]=CraftPara.CraftAccelerometerConstBias[0][0];//���ߵ����ٶȳ�ֵ��ƫ
	CraftAccelerometerConstBias[1][0]=CraftPara.CraftAccelerometerConstBias[1][0];
	CraftAccelerometerConstBias[2][0]=CraftPara.CraftAccelerometerConstBias[2][0];

	CraftAccelerometerRandomBias[0][0]=CraftPara.CraftAccelerometerRandomBias[0][0];//���ߵ����ٶ������ƫ
	CraftAccelerometerRandomBias[1][0]=CraftPara.CraftAccelerometerRandomBias[1][0];
	CraftAccelerometerRandomBias[2][0]=CraftPara.CraftAccelerometerRandomBias[2][0];

	CraftAccelerometerScaleFactor[0][0]=CraftPara.CraftAccelerometerScaleFactor[0][0];//���ߵ����ٶȼƿ̶�����
	CraftAccelerometerScaleFactor[1][0]=CraftPara.CraftAccelerometerScaleFactor[1][0];
	CraftAccelerometerScaleFactor[2][0]=CraftPara.CraftAccelerometerScaleFactor[2][0];

	CraftGyroDrift[0][0]=CraftPara.CraftGyroConstDrift[0][0]+CraftPara.CraftGyroRandomDrift[0][0]; //���ݳ�ֵ��ƫ+���������ƫ=��������ƫ
	CraftGyroDrift[1][0]=CraftPara.CraftGyroConstDrift[1][0]+CraftPara.CraftGyroRandomDrift[1][0];	
	CraftGyroDrift[2][0]=CraftPara.CraftGyroConstDrift[2][0]+CraftPara.CraftGyroRandomDrift[2][0];	

	CraftGyroConstDrift[0][0]=CraftPara.CraftGyroConstDrift[0][0];  //���ߵ����ݳ�ֵƯ��
	CraftGyroConstDrift[1][0]=CraftPara.CraftGyroConstDrift[1][0];
	CraftGyroConstDrift[2][0]=CraftPara.CraftGyroConstDrift[2][0];

	CraftGyroRandomDrift[0][0]=CraftPara.CraftGyroRandomDrift[0][0];//���ߵ��������Ư��
	CraftGyroRandomDrift[1][0]=CraftPara.CraftGyroRandomDrift[1][0];
	CraftGyroRandomDrift[2][0]=CraftPara.CraftGyroRandomDrift[2][0];

	CraftGyroScaleFactor[0][0]=CraftPara.CraftGyroScaleFactor[0][0];//���ߵ����ݿ̶���
	CraftGyroScaleFactor[1][0]=CraftPara.CraftGyroScaleFactor[1][0];
	CraftGyroScaleFactor[2][0]=CraftPara.CraftGyroScaleFactor[2][0];

	//�����ڻ����İ�װ����
	MissileMountAngle[0][0]=CraftPara.MissileMountAngle[0][0];//�����ڻ����İ�װ��
	MissileMountAngle[1][0]=CraftPara.MissileMountAngle[1][0];
	MissileMountAngle[2][0]=CraftPara.MissileMountAngle[2][0];

	NominalLeverArm[0][0]=CraftPara.NominalLeverArm[0][0];//��׼�˱�
	NominalLeverArm[1][0]=CraftPara.NominalLeverArm[1][0];
	NominalLeverArm[2][0]=CraftPara.NominalLeverArm[2][0];

	//���ϵͳ��������
	MissileMountAngleError[0][0]=CraftPara.MissileMountAngleError[0][0];//���ϵͳ���㰲װ���
	MissileMountAngleError[1][0]=CraftPara.MissileMountAngleError[1][0];
	MissileMountAngleError[2][0]=CraftPara.MissileMountAngleError[2][0];

	LeverArmLengthError[0][0]=CraftPara.LeverArmLengthError[0][0];//���ϵͳ����˱����
	LeverArmLengthError[1][0]=CraftPara.LeverArmLengthError[1][0];	
	LeverArmLengthError[2][0]=CraftPara.LeverArmLengthError[2][0];	

	//���������ߵ�����
	MissileAccelerometerConstBias[0][0]=CraftPara.MissileAccelerometerConstBias[0][0]; //�ӹߵ����ٶȼƳ�ֵ��ƫ��������
	MissileAccelerometerConstBias[1][0]=CraftPara.MissileAccelerometerConstBias[1][0];
	MissileAccelerometerConstBias[2][0]=CraftPara.MissileAccelerometerConstBias[2][0];

	MissileAccelerometerRandomBias[0][0]=CraftPara.MissileAccelerometerRandomBias[0][0]; //�ӹߵ����ٶȼ������ƫ��������
	MissileAccelerometerRandomBias[1][0]=CraftPara.MissileAccelerometerRandomBias[1][0];
	MissileAccelerometerRandomBias[2][0]=CraftPara.MissileAccelerometerRandomBias[2][0];

	MissileAccelerometerScaleFactor[0][0]=CraftPara.MissileAccelerometerScaleFactor[0][0];//�ӹߵ����ٶȼƿ̶�������������
	MissileAccelerometerScaleFactor[1][0]=CraftPara.MissileAccelerometerScaleFactor[1][0];
	MissileAccelerometerScaleFactor[2][0]=CraftPara.MissileAccelerometerScaleFactor[2][0];

	MissileAccelerometerCrossCoupling[0][0]=CraftPara.MissileAccelerometerCrossCoupling[0][0]; //�ӹߵ����ٶȼƽ�����ϣ�����
	MissileAccelerometerCrossCoupling[1][0]=CraftPara.MissileAccelerometerCrossCoupling[1][0];
	MissileAccelerometerCrossCoupling[2][0]=CraftPara.MissileAccelerometerCrossCoupling[2][0];

	MissileAccelerometerQuantizationFactor=CraftPara.MissileAccelerometerQuantizationFactor;  //�ӹߵ����ٶȼ��������ӣ�������

	RotaryAmp[0]=CraftPara.RotaryAmp[0];
	RotaryAmp[1]=CraftPara.RotaryAmp[1];
	RotaryAmp[2]=CraftPara.RotaryAmp[2];

	RotaryFre[0]=CraftPara.RotaryFre[0];
	RotaryFre[1]=CraftPara.RotaryFre[1];
	RotaryFre[2]=CraftPara.RotaryFre[2];

	RotaryPha[0]=CraftPara.RotaryPha[0];
	RotaryPha[1]=CraftPara.RotaryPha[1];
	RotaryPha[2]=CraftPara.RotaryPha[2];

	MissileGyroCrossCoupling[0][0]=CraftPara.MissileGyroCrossCoupling[0][0];
	MissileGyroCrossCoupling[1][0]=CraftPara.MissileGyroCrossCoupling[1][0];
	MissileGyroCrossCoupling[2][0]=CraftPara.MissileGyroCrossCoupling[2][0];

	MissileGyroQuantizationFactor=CraftPara.MissileGyroQuantizationFactor;//�ӹߵ��������������ӣ�������	

	MissileAccelerometerBias[0][0]=CraftPara.MissileAccelerometerConstBias[0][0]+CraftPara.MissileAccelerometerRandomBias[0][0];
	MissileAccelerometerBias[1][0]=CraftPara.MissileAccelerometerConstBias[1][0]+CraftPara.MissileAccelerometerRandomBias[1][0];
	MissileAccelerometerBias[2][0]=CraftPara.MissileAccelerometerConstBias[2][0]+CraftPara.MissileAccelerometerRandomBias[2][0];

	//�����㷨�ļ��㲽����ֵ 
	CraftTraceStepSize=CraftPara.CraftTraceStepSize;             //�������㲽��
//	CraftNavigationStepSize=CraftPara.CraftNavigationStepSize;       //���ߵ����㲽��
	FcsNavigationStepSize=CraftPara.FcsNavigationStepSize;   //��ص������㲽��
	FcsOutputStepSize=CraftPara.FcsOutputStepSize;           //�����Ϣ�������

	//����ʱ��
	SimulationStartTime=CraftPara.SimulationStartTime;   //����ϵͳ�ϵ�ʱ�䣻
	CraNavStartTime=CraftPara.CraNavStartTime;           //���ߵ�������ʼʱ�䣻
	CraNavEndTime=CraftPara.CraNavEndTime;               //���ߵ���������ʱ�䣻
	FcsNavStartTime=CraftPara.FcsNavStartTime;           //��ص�����ʼʱ��
	FcsNavEndTime=CraftPara.FcsNavEndTime;               //��ص�������ʱ��
	TransferAlignmentStartTime=CraftPara.TransferAlignmentStartTime; //���ݶ�׼��ʼʱ����Ϊ��
	TransferAlignmentTime=CraftPara.TransferAlignmentTime;   //���ݶ�׼����ʱ����Ϊ�� 

//*********�ṹ��CraftPara��cratra��ֵ����*********//  
   
    //��������ֵ
	MaxCountCraftNav=CraftNavigationStepSize/CraftTraceStepSize;//���ߵ�����
	MaxCountFcsNav=FcsNavigationStepSize/CraftTraceStepSize;//��ص���
	MaxCountFcsOutput=FcsOutputStepSize/CraftTraceStepSize;//�����Ϣ���
	MaxCountMissileGyro=MissileGyroStepSize/CraftTraceStepSize;//������
	MaxCountMissileAcce=MissileAccelerometerStepSize/CraftTraceStepSize;//�ӼӼ�
	MaxCountMissileNav=MissileNavigationStepSize/CraftTraceStepSize;//�ӵ���
	MaxCountOutput=OutputStepSize/CraftTraceStepSize;//���
	
}

//�ػ��켣��ͼ����
void CraftTracePlot()
{
		PlotWaveform(PanelHandleTestAnalysis,PANELANA_PosXNav,CraftPositionPlot[0],TraceNumber,VAL_DOUBLE,1,0,0,1,VAL_FAT_LINE,VAL_EMPTY_SQUARE,VAL_SOLID,1,VAL_RED);
	    PlotWaveform(PanelHandleTestAnalysis,PANELANA_PosYNav,CraftPositionPlot[1],TraceNumber,VAL_DOUBLE,1,0,0,1,VAL_FAT_LINE,VAL_EMPTY_SQUARE,VAL_SOLID,1,VAL_RED);
		PlotWaveform(PanelHandleTestAnalysis,PANELANA_PosZNav,CraftPositionPlot[2],TraceNumber,VAL_DOUBLE,1,0,0,1,VAL_FAT_LINE,VAL_EMPTY_SQUARE,VAL_SOLID,1,VAL_RED);
		PlotWaveform(PanelHandleTestAnalysis,PANELANA_VelX,CraftVelocityPlot[0],TraceNumber,VAL_DOUBLE,1,0,0,1,VAL_FAT_LINE,VAL_EMPTY_SQUARE,VAL_SOLID,1,VAL_RED);
		PlotWaveform(PanelHandleTestAnalysis,PANELANA_VelY,CraftVelocityPlot[1],TraceNumber,VAL_DOUBLE,1,0,0,1,VAL_FAT_LINE,VAL_EMPTY_SQUARE,VAL_SOLID,1,VAL_RED);
		PlotWaveform(PanelHandleTestAnalysis,PANELANA_VelZ,CraftVelocityPlot[2],TraceNumber,VAL_DOUBLE,1,0,0,1,VAL_FAT_LINE,VAL_EMPTY_SQUARE,VAL_SOLID,1,VAL_RED);
		PlotWaveform(PanelHandleTestAnalysis,PANELANA_Yaw,CraftAttitudePlot[0],TraceNumber,VAL_DOUBLE,1,0,0,1,VAL_FAT_LINE,VAL_EMPTY_SQUARE,VAL_SOLID,1,VAL_RED);
		PlotWaveform(PanelHandleTestAnalysis,PANELANA_Pitch,CraftAttitudePlot[1],TraceNumber,VAL_DOUBLE,1,0,0,1,VAL_FAT_LINE,VAL_EMPTY_SQUARE,VAL_SOLID,1,VAL_RED);
		PlotWaveform(PanelHandleTestAnalysis,PANELANA_Roll,CraftAttitudePlot[2],TraceNumber,VAL_DOUBLE,1,0,0,1,VAL_FAT_LINE,VAL_EMPTY_SQUARE,VAL_SOLID,1,VAL_RED);
}

//�ػ���ͼ����׼������
void  AlgorithmTestResult()
{
	CraftPositionPlot[0][TraceNumber]=CraftInsPosition_Test[0][0]/DEGREE;
	CraftPositionPlot[1][TraceNumber]=CraftInsPosition_Test[1][0]/DEGREE;
	CraftPositionPlot[2][TraceNumber]=CraftInsPosition_Test[2][0];
	
	CraftVelocityPlot[0][TraceNumber]=CraftInsVelocityP_Test[0][0];
	CraftVelocityPlot[1][TraceNumber]=CraftInsVelocityP_Test[1][0];
	CraftVelocityPlot[2][TraceNumber]=CraftInsVelocityP_Test[2][0];
	
	CraftAttitudePlot[0][TraceNumber]=CraftInsAttitude_Test[0][0]/DEGREE; //��ͼ��ʾ�Ƕ�
	CraftAttitudePlot[1][TraceNumber]=CraftInsAttitude_Test[1][0]/DEGREE;					
	CraftAttitudePlot[2][TraceNumber]=CraftInsAttitude_Test[2][0]/DEGREE;	
}






