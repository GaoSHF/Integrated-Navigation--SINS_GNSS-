//==============================================================================
//
// Title:		Selftest
// Purpose:		A short description of the application.
//
// Created on:	2013-7-7 at 14:30:03 by HC.
// Copyright:	buaa. All Rights Reserved.
//
//==============================================================================

//==============================================================================
// Include files

#include "RS422.h"
#include "common.h"
#include "selftest.h"
#include "rfm.h"
#include "P3531.h"
#include "P3530.h"
/*
unsigned long long starttime;
unsigned long long stoptime; 
unsigned long long time_diff;
  */

int selftest_GERFM()
{
	GERFM_DevHandle GERFM_hDev; 
	int status,i;
	ViUInt8 a[10]={0,1,2,3,4,5,6,7,8,9};
	ViUInt8 b[10]={0};

	status = GERFM_OpenDevice(&GERFM_hDev);  
	status = GERFM_EnableDMA(&GERFM_hDev,10,OPERATE_WRITE);  
	status = GERFM_DMA_Write(GERFM_hDev,0,a) ;
	status = GERFM_EnableDMA(&GERFM_hDev,10,OPERATE_READ);
	status = GERFM_DMA_Read(GERFM_hDev,0,b) ;  
	status = GERFM_SetLED(GERFM_hDev,LED_OFF);
	status = GERFM_CloseDevice(&GERFM_hDev);
	for(i=0;i<10;i++)
	{
		if(b[i]!=a[i])
		{
			return SELFFAIL_GERFM ;
		}
	}
	return SELFTEST_SUCCESS;
}

int selftest_429()
{
	PS_DevHandle   PS3531_hDev; 
	int status,i,j;
	int k=0;
	int countOfCards = 0;  
	int countOfModules = 0;
	int msgCount=0; 
	int lengthRead ;
	int a[10]={9,8,7,6,5,4,3,2,1,0};
	int b[10]={0};
	PS_DevInfoHandle pDevs = NULL; 
	status = P3531_ScanDevices(&pDevs, &countOfCards);
	if(countOfCards < 1)
	{
		return SELFFAIL_429; 
	}
	status = P3531_OpenDevice(pDevs, &PS3531_hDev);	
	if (status != PS_SUCCESS)
	{
		return SELFFAIL_429;
	}
	P3531_ReleaseDevInfo(pDevs);	// release all the device information.     
	P3531_GetCountOfModule(PS3531_hDev, &countOfModules);  // get moudles number
	for(i=0; i < countOfModules; ++i)
	{
		P3531_ResetModule(PS3531_hDev, i);
		P3531_ConfigureModule(PS3531_hDev, i, MODULE_DISABLE_SELF_TEST); // disable self-test
	}  
	// Enable Rx channel and clear Rx FIFO
	status = P3531_EnableRCVChannel(PS3531_hDev, 0, 1);	 	
	status = P3531_ResetRCVFIFO(PS3531_hDev, 0);
	status = P3531_ResetSNDFIFO(PS3531_hDev, 0); 
	
	for(j=0;j<10;j++)
	{
		status = P3531_LoadMessage(PS3531_hDev, 0, a[j]);    // transmit data	
	}
	while(msgCount!=10)
	{
		status = P3531_GetCountOfRCVDMessage(PS3531_hDev, 0, &msgCount);
		k++;
		if(k==100000)
		{
			return SELFFAIL_429;
		}
	}
	//status = P3531_ReadBlock(PS3531_hDev,0, b, 10, &lengthRead);
	for(i=0;i<10;i++)
	{
		status = P3531_ReadNextData(PS3531_hDev, 0, &b[i]);    // receive data	
	}
	for(i=0;i<10;i++)
	{
		b[i] &= 0x7FFFFFFF;
		if(b[i]!=a[i])
		{
			return SELFFAIL_429;
		}
	}
	P3531_LightenLED(PS3531_hDev,8);	// light the led 0 and 1 
	P3531_CloseDevice(PS3531_hDev); 
	return SELFTEST_SUCCESS;
}

int selftest_422() 
{
	RS422_DevHandle RS422_hDev; 
	int status,i,j;
	int k=0; 
 	char a[10]={1,3,5,7,9,11,13,15,17,19};
	char b[10]={0};
	unsigned int rev_StrLen = 0;
	CloseCom (7);
	status = OpenComConfig (7,"",1000000,0,8,1,4096,4096);
	if(!status)
	{
		FlushInQ(7);
		FlushOutQ(7);								   
	//	InstallComCallback (Uart.comValue, LWRS_RXCHAR,0, 0, (void *)uartRevData, 0);
	}
	for(i=0;i<10;i++)
	{
		ComWrtByte (7,a[i]);
	}
	while(rev_StrLen!=10)
	{
		rev_StrLen= GetInQLen (7);
		k++;
		if(k==500000)
		{
			return SELFFAIL_422;
		}
	}
	for(i=0;i<rev_StrLen;i++)
	{		
		b[i]=ComRdByte(7);
	}
	CloseCom (7); 
	for(j=0;j<10;j++)
	{
		if(b[j]!=a[j])
		{
			return SELFFAIL_422;
		}
	}

   	return SELFTEST_SUCCESS;   
}

int selftest_1553B()
{
	PS_DevHandle   PS3530_hDev; 
	//����RT
	unsigned char subAddress=1;
	unsigned int  module=1;
	unsigned char rtAddr=1;
	unsigned char wordCount=32;
	unsigned short data[32];	
	unsigned char msgCountOut=0; 
	unsigned char BCsubAddress=1;
	unsigned int BCmodule=0;
	MSG_SEND msgSend;  
	MSG_RECEIVE msgReceive;
	MSG_RECEIVE BCmsgReceive;
	unsigned int sizeofblock=9; 
	unsigned int  BCmsgCount=1; 
	unsigned int BCmsgIndex=0;   
	unsigned long flag=1; 
	unsigned char i=0;

	
	SUBADDR_LKP_TBL subaddressLookupTable;
	subaddressLookupTable.Bcst_SAn=0x400;
	subaddressLookupTable.Rx_Bcst_SAn=0x800;
	subaddressLookupTable.Tx_SAn=0x400;
	subaddressLookupTable.SACW_SAn=0x80;
	//���豸
	P3530_OpenDeviceBySlot(1,3,&PS3530_hDev);
	//��ʼ��RTģʽ
	P3530_SetMode(PS3530_hDev,module,MODE_RT);
	//��ʼ��RT��ַ
	P3530_RTSetAddr(PS3530_hDev,module,rtAddr);
	//�����Զ�������Ϣ����
	P3530_RTMTSetAutoBufferMsg(PS3530_hDev,module,0);
	//����SubaddressLookupTable(�˴���ʹ�õ��ӵ�ַΪ1,������/�㲥���յ�ַ��Ϊ���õ�ַ0x800,
	//�����͵�ַ��Ϊ0x400,�ӵ�ַ��ȡģʽ��Ϊ��ռ1K�ռ��ѭ������ģʽ.)
	P3530_RTSetSubaddressLookupTablesABySubaddress(PS3530_hDev,module,subAddress,&subaddressLookupTable);
	for(i=0;i<32;i++)
	{
		data[i]=5;
	}
	//װ������
	P3530_RTLoadData(PS3530_hDev,module,subAddress,wordCount,data);
	//��ʼ��BCģʽ
	P3530_SetMode(PS3530_hDev,BCmodule,MODE_BC);
	//��������֡��Ϣ
	msgSend.msgGapTime=0x320;
	msgSend.controlWord=0x80;
	msgSend.msgBlock[0]=0x825;//��ȡ��Ϣ
	for (int j=1;j<sizeofblock;j++)
	{
		msgSend.msgBlock[j]=5;
	}
	//��ʼ��BC�����Ϣ
	BCmsgReceive.msgTimeTag=1;
	BCmsgReceive.msgBlockStatus=1;
	for (int j=0;j<37;j++)
	{
		BCmsgReceive.msgBlock[j]=1;
	}
	//д����Ϣ	  
	P3530_BCWriteMsg(PS3530_hDev,BCmodule,0,&msgSend,sizeofblock);
	//����֡��Ϣ����#
	P3530_BCSetFrameMsgCount(PS3530_hDev,BCmodule,BCmsgCount);
	//����֡��ʼ��Ϣ����
	P3530_BCSetFrameMsgStartIndex(PS3530_hDev,BCmodule,BCmsgIndex);
	//�������Ҽ��
	//	P3530_SelfTest(hDev,1,1,200);//backup����Ϊ1���Լ�֮ǰ�Ĳ������أ�RT�յ�BC���͵���Ϣ
	P3530_SelfTest(PS3530_hDev,1,1,10);//backup����Ϊ0���Լ�֮ǰ�Ĳ��������أ�RT�ղ�����Ϣ
	//����BC
	P3530_BCMTStart(PS3530_hDev,BCmodule);
	//�ȴ���ǰ֡�������
 	while (flag)
	{
		P3530_BCIsFrmInProgress(PS3530_hDev,BCmodule,&flag);
	}
	//BC��ȡ��Ϣ
	P3530_BCReadMsg(PS3530_hDev,BCmodule,0,&BCmsgReceive);
	//RT��ȡ��Ϣ
	P3530_RTMTMsgCount(PS3530_hDev,module,&msgCountOut);
	for(i=0;i<37;i++)   
	{
		msgReceive.msgBlock[i] =0;
	}

	
	for(i=0;i<msgCountOut;i++)
	{

		P3530_RTMTReadMsg(PS3530_hDev,module,&msgReceive);

	}
	P3530_CloseDevice(PS3530_hDev);
	for(i=1;i<6;i++)
	{
		if(msgSend.msgBlock[i]!=msgReceive.msgBlock[i])
		{
			return SELFFAIL_1553B;
		}	
	}
	return SELFTEST_SUCCESS;
}

int module_selftest(void)
{
	int status;
	
//	starttime = GetTimeUS ();
	
	status = selftest_GERFM();
	if(status != SELFTEST_SUCCESS)
	{
		return status;
	}
	status = selftest_429();
	if(status != SELFTEST_SUCCESS)
	{
		return status;
	}					 
	status = selftest_422();
	if(status != SELFTEST_SUCCESS)
	{
		return status;
	}
//	status = selftest_1553B();
//	if(status != SELFTEST_SUCCESS)
//	{
//		return status;
//	}
	
//	stoptime = GetTimeUS ();
 
//	time_diff = stoptime - starttime;
	

	return SELFTEST_SUCCESS;
}		
