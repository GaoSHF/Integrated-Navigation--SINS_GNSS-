#include <utility.h>
#include <tcpsupp.h>
#include <common.h>

/* 
	Transfer data from RT to host
 */
void Update (void)
{
	CmtGetLock (gLock);
	// Create message with program state and send to host executable.
	if (StatusTcpRT != TCP_INVALID_CONNECTION)
	{
		// ServerTCPWrite does not guarantee that all Data will be transferred in
		// a single call, but this code assumes that it does for simplicity.
		ServerTCPWrite (StatusTcpRT, &DataRT, sizeof(DataRT), 5000);
	}
	CmtReleaseLock (gLock);
}


/*
	data type from 16bits int to double
 */
double IntToDouble(unsigned short data, double max)
{
	return ((short)data / 32767.0 * max);
}
