#include <ansi_c.h>

#include "Navigation.h"

void PPS_Interrupt_Nav(unsigned long long Time_PPS)
{
//	printf("Nav_PPS\n");
}

void FC_Interrupt_Nav(RFM_FireControl_Data FireControl_Nav)
{
//	printf("Nav_FC\n"); 

}

void IMU_Interrupt_Nav(IMU_Data IMU_Nav)
{
//	printf("Nav_IMU\n"); 
}

void Sat_Interrupt_Nav(Sat_Data Sat_Nav)
{
//	printf("Nav_Sat\n"); 
}
