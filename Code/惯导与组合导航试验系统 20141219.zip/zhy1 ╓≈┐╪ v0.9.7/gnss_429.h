//����RS429��P3531��δ�����GPS���ݲ�������
#ifndef _GNSS_429_H_
#define _GNSS_429_H_

#define	SV_NUM_TOTAL	32 // Total satellite number
#define	SV_NUM_RCVMAX	10 // Total channel number

extern int FlagRecordGNSS429;

extern FILE *FileHandleRTGNSS429;

extern long long CountInGNSS429;
extern long long CountOutGNSS429;

extern long long IndexInGNSS429;
extern long long IndexOutGNSS429;


void gnss429StartReceive(void);
void gnss429StopReceive(void);
ViStatus _VI_FUNCH InterruptPPS(ViSession vi , ViEventType eventType ,ViEvent ctx ,ViAddr userHdlr);

void SitelliteAccurateCallback(void); 
#endif 
