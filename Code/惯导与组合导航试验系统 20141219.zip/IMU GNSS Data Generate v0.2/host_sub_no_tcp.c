#include <formatio.h>
#include <ansi_c.h> 
#include <cvinetv.h>
#include <cvirte.h> 
#include <userint.h>
#include <tcpsupp.h> 
#include <visa.h>
#include <toolbox.h>

#include "common.h"
#include "host_sub_no_tcp.h"



/*
	Quit button callback
 */
int CVICALLBACK buttonSubTCPQuit (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:
			
			// Quit sub panel
			RemovePopup(HandleSubPanelTCP);
			
			break;
	}
	return 0;
}




