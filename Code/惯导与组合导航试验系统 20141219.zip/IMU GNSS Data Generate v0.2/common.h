#ifndef _COMMON_H_
#define _COMMON_H_


#include "GERFM.h"



#define TCP_INVALID_CONNECTION 	((unsigned int)-1) 

#define HOST_ADDRESS 			"169.254.176.1"
#define HOST_PORT 				10001


#define START_COMMAND			1
#define STOP_COMMAND			2
#define QUIT_COMMAND			3

#define SELFTEST_COMMAND        4

#define GPSRECEIVE_COMMAND      5  
#define INSRECEIVE_COMMAND      6

#define GPSSIM_COMMAND          7
#define GPSSIM_AGC_COMMAND      8
#define	GPSSIM_IO_CHANGE_COMMAND	9

#define	STATUS_ON	1
#define	STATUS_OFF	0


// Command message structure
typedef struct
{
	int countertime;
	
	int statusYCReceive;
	
	int statusINSReceive;
	
	int statusGPSReceive;
	
	int statusSimulator;
	
	int valueAGC;
	
	int	command;
} CommandMessage;


static int HandlePanel;
static int HandleSubPanelTCP;





#endif

