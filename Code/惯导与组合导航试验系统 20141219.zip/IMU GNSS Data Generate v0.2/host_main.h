/**************************************************************************/
/* LabWindows/CVI User Interface Resource (UIR) Include File              */
/* Copyright (c) National Instruments 2013. All Rights Reserved.          */
/*                                                                        */
/* WARNING: Do not add to, delete from, or otherwise modify the contents  */
/*          of this include file.                                         */
/**************************************************************************/

#include <userint.h>

#ifdef __cplusplus
    extern "C" {
#endif

     /* Panels and Controls: */

#define  PANEL                            1
#define  PANEL_BUTTON_QUIT_HOST           2       /* callback function: buttonQuitHost */
#define  PANEL_BUTTON_SET_AGC             3       /* callback function: buttonSetAGC */
#define  PANEL_BUTTON_CHANGE              4       /* callback function: buttonChange */
#define  PANEL_BUTTON_QUIT_RT             5       /* callback function: buttonQuitRT */
#define  PANEL_STRING_TCP_STATUS          6
#define  PANEL_TOGGLEBUTTON_TRACK         7       /* callback function: buttonTrack */
#define  PANEL_NUMERIC_AGC                8


     /* Menu Bars, Menus, and Menu Items: */

          /* (no menu bars in the resource file) */


     /* Callback Prototypes: */

int  CVICALLBACK buttonChange(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK buttonQuitHost(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK buttonQuitRT(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK buttonSetAGC(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK buttonTrack(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);


#ifdef __cplusplus
    }
#endif
