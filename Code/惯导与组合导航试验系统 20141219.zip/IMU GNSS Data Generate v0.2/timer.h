//==============================================================================
//
// Title:       timer.h
// Purpose:     A short description of the interface.
//
// Created on:  2013/12/23 at 10:08:17 by ZhaoHengyang.
// Copyright:   Beihang University. All Rights Reserved.
//
//==============================================================================

#ifndef __timer_H__
#define __timer_H__

#ifdef __cplusplus
    extern "C" {
#endif

//==============================================================================
// Include files

#include "cvidef.h"

//==============================================================================
// Constants

//==============================================================================
// Types

//==============================================================================
// External variables

//==============================================================================
// Global functions

int CVICALLBACK TraceTimer(int reserved, int timerId, int event, void *callbackData, int eventData1, int eventData2);

#ifdef __cplusplus
    }
#endif

#endif  /* ndef __timer_H__ */
