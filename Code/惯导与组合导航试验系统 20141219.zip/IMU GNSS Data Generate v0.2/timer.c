//==============================================================================
//
// Title:       timer.c
// Purpose:     A short description of the implementation.
//
// Created on:  2013/12/23 at 10:08:17 by ZhaoHengyang.
// Copyright:   Beihang University. All Rights Reserved.
//
//==============================================================================

//==============================================================================
// Include files
#include <userint.h> 


#include "asynctmr.h"
#include "timer.h"
#include "simulator.h"
#include "sensor_simu.h"
#include "rfm.h"

//==============================================================================
// Constants

//==============================================================================
// Types

//==============================================================================
// Static global variables

//==============================================================================
// Static functions

//==============================================================================
// Global variables

//==============================================================================
// Global functions

/// HIFN  What does your function do?
/// HIPAR x/What inputs does your function expect?
/// HIRET What does your function return?
/* 
	Timer to send data to simulator
 */
int CVICALLBACK TraceTimer(int reserved, int timerId, int event, void *callbackData, int eventData1, int eventData2)
{
	static dTrackBDT = 2000;
	static j = 0;
	int i, iPort ;//= StrToInt(EditPort->Text)
	
	long long timeNewS, timeNewMS;
	
	double temp;

	
	
	if (event == EVENT_TIMER_TICK)
	{
		
		timeNewS = TIMER_INTERVAL * (CountTrack ++);
		timeNewMS = timeNewS * 1000;
		
		// Suspend this timer after finish this time
		if (timeNewS == (TIME_LEN_STAGE1 + TIME_LEN_STAGE2 + TIME_LEN_STAGE3))
			SuspendAsyncTimerCallbacks();
		
		
		
		// Refresh position, acceleration and velocity
		ae = (timeNewS < TIME_LEN_STAGE1) ? AE_STAGE1 : ((timeNewS < TIME_LEN_STAGE1 + TIME_LEN_STAGE2) ? AE_STAGE2 : AE_STAGE3);
		an = (timeNewS < TIME_LEN_STAGE1) ? AN_STAGE1 : ((timeNewS < TIME_LEN_STAGE1 + TIME_LEN_STAGE2) ? AN_STAGE2 : AN_STAGE3);
		au = (timeNewS < TIME_LEN_STAGE1) ? AU_STAGE1 : ((timeNewS < TIME_LEN_STAGE1 + TIME_LEN_STAGE2) ? AU_STAGE2 : AU_STAGE3);
		
		sensorPgeoRefresh (&la, &lon, &h, ve, vn, vu, la, lon, h, TIMER_INTERVAL);
		sensorVenuRefresh (&ve, &vn, &vu, ae, an, au, TIMER_INTERVAL);
	
		
		
		// Refresh position, acceleration and velocity at WGS84
		sensorPgeo2xyz(&x, &y, &z, la, lon, h);
		sensorVenu2xyz(&vx, &vy, &vz, ve, vn, vu, la, lon);
		sensorAenu2xyz(&ax, &ay, &az, ae, an, au, la, lon);
		
		
		// �����ؼ��������IMU����
		/*wibb[0] = 0.121314;
		wibb[1] = 1.292827;
		wibb[2] = 2.343538;
		fb[0] = 3.414244;
		fb[1] = 4.565751;
		fb[2] = 5.676861;*/
		sensorFbRefresh (fb, ae, an, au, ve, vn, vu, la, h);
		sensorWibbRefresh (wibb, ve, vn, la, h);
		rfmIMU(wibb, fb);
		
		
		// Generate track data
        lRfmTransRec.Cmdkey = 0x0A5A5C39;
	
		lRfmTransRec.iTrackBDT = 25000 + timeNewMS;
	
		lRfmTransRec.iTrackID = 10;
	
		lRfmTransRec.dbeSimTime = 0.0;
	
		lRfmTransRec.dUserPosX = x;
		lRfmTransRec.dUserPosY = y;
		lRfmTransRec.dUserPosZ = z;
			
		lRfmTransRec.dUserVelX = vx;
		lRfmTransRec.dUserVelY = vy;
		lRfmTransRec.dUserVelZ = vz;
	
		lRfmTransRec.dUserAccX = ax;
		lRfmTransRec.dUserAccY = ay;
		lRfmTransRec.dUserAccZ = az;
	
		lRfmTransRec.iPoseBDT = 25000 + timeNewMS;
	
	    lRfmTransRec.iPoseID = 10;
	
	    lRfmTransRec.dbeSimTime2 = 0.0;
	
		lRfmTransRec.dUserJekX = 0;
		lRfmTransRec.dUserJekY = 0;
		lRfmTransRec.dUserJekZ = 0;
		
		lRfmTransRec.dUserRoll = 0;
		lRfmTransRec.dUserAzimu = 0;
		lRfmTransRec.dUserPitch = 0;
				
		lRfmTransRec.dUserRollVelX = 0;
		lRfmTransRec.dUserRollVelY = 0;
		lRfmTransRec.dUserRollVelZ = 0;
					
		lRfmTransRec.dUserRollAccX = 0.0;
	    lRfmTransRec.dUserRollAccY = 0.0;
	    lRfmTransRec.dUserRollAccZ = 0.0;

	    lRfmTransRec.dUserRollJekX = 0.0;
	    lRfmTransRec.dUserRollJekY = 0.0;
	    lRfmTransRec.dUserRollJekZ = 0.0;
			
		SendTrkData((char *)&lRfmTransRec, sizeof(struct TRfmCardTransRec));
		
	}
	
	return 0;
}



