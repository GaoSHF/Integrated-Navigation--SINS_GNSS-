#include <formatio.h>   
#include <tcpsupp.h>
#include "asynctmr.h"
#include <cvirte.h>
#include <rtutil.h>
#include <userint.h> 
#include <analysis.h>
#include <utility.h>
#include <cvinetv.h>
#include <ansi_c.h>

#include <GERFM.h>
#include "common.h"
#include "simulator.h"
#include "pxi_io.h"
#include "timer.h"
#include "rfm.h"



#define	TIMER_ON	1
#define	TIMER_OFF	0




// Inner variables

struct TRfmCardTransRec  lRfmTransRec;

unsigned int glRfmComPtkID;
unsigned int AgcPtkID;

int FlagTimer = TIMER_OFF;


IO_PARAM *ParamIO = NULL;
int StatusIO = IO_NOT_FOUND;
ViUInt8 SwitchIO = IO_RELAY_DISCRETE; // Default descrete

int CountTrack = 0;




double x, y, z;
double vx, vy, vz;
double ax, ay, az;

double la, lon, h;  // rad, rad, m
double ve, vn, vu;
double ae, an, au;



// Inner function


/* 
 * Open device
 */
int simulatorOpenDev(void)
{
	GERFM_OpenDevice(&GERFM_hDev);
	return 0;
}


/* 
 * Close device
 */
int simulatorCloseDev(void)
{
	GERFM_CloseDevice(&GERFM_hDev);
	return 0;
}


/* 
 * Init GNSS simulator
 */
int simulatorInit(void)
{
	int status;
	
	int iTemp;
	
	double temp;
	
	
	
	printf("Simulator start.\n");


    glRfmComPtkID = 0;
	AgcPtkID = 0;
	
    iTemp = 0;
	
	status = viMoveOut8 (GERFM_hDev.GERFM_instr, VI_PXI_BAR3_SPACE, 0x5200, 4,(char *)&iTemp);  
	status = viMoveIn8 (GERFM_hDev.GERFM_instr, VI_PXI_BAR3_SPACE,0x5000, 4, (char *)&glRfmComPtkID);   
	
	Delay(1);
	
	
    lRfmTransRec.Cmdkey = 0x0ABB9011;
	
	lRfmTransRec.iTrackBDT = 0;
	
	lRfmTransRec.iTrackID = 0;
	
	lRfmTransRec.dbeSimTime = 0.0;
	
	lRfmTransRec.dUserPosX = x;
	lRfmTransRec.dUserPosY = y;
	lRfmTransRec.dUserPosZ = z;
	
			
	lRfmTransRec.dUserVelX = vx;
	lRfmTransRec.dUserVelY = vy;
	lRfmTransRec.dUserVelZ = vz;
	
	lRfmTransRec.dUserAccX = ax;
	lRfmTransRec.dUserAccY = ay;
	lRfmTransRec.dUserAccZ = az;
	
	lRfmTransRec.iPoseBDT = 0;
	
    lRfmTransRec.iPoseID = 0;
	
    lRfmTransRec.dbeSimTime2 = 0.0;
	
	lRfmTransRec.dUserJekX = 0;
	lRfmTransRec.dUserJekY = 0;
	lRfmTransRec.dUserJekZ = 0;
		
	lRfmTransRec.dUserRoll = 0;
	lRfmTransRec.dUserAzimu = 0;
	lRfmTransRec.dUserPitch = 0;
				
	lRfmTransRec.dUserRollVelX = 0;
	lRfmTransRec.dUserRollVelY = 0;
	lRfmTransRec.dUserRollVelZ = 0;
					
	lRfmTransRec.dUserRollAccX = 0.0;
    lRfmTransRec.dUserRollAccY = 0.0;
    lRfmTransRec.dUserRollAccZ = 0.0;

    lRfmTransRec.dUserRollJekX = 0.0;
    lRfmTransRec.dUserRollJekY = 0.0;
    lRfmTransRec.dUserRollJekZ = 0.0;

    SendTrkData((char *)&lRfmTransRec, sizeof(struct TRfmCardTransRec));
	
	
	status = GERFM_SetLED(GERFM_hDev, LED_ON);   
	
	Delay(30);
	
	// GPS���ջ���ʱ����Ҫ�ı�ģ�������ʲ���������λ 
	simulatorSetAGC (AGC_DEFAULT_VALUE_1); // default 25dB/-125dBm
	Delay(5);
	simulatorSetAGC (AGC_DEFAULT_VALUE_2); // default 25dB/-125dBm
	
	//�첽��ʱ������ʼ���ⷴ������ִ��TimerTrkTickTimer��ʱ����
	if(NewAsyncTimer (TIMER_INTERVAL, -1, 1, TraceTimer, 0) < 0)
	{
		printf("Cannot create a async timer!\n");
		simulatorStop();
	}
	else
	{
		printf("Async timer has been created.\n");
		FlagTimer = TIMER_ON;
	}
	return 0;
}



/* 
 * Stop trace generate
 */
int simulatorStop(void)
{
	int iLen, iTemp;
	int status;
	
	if(FlagTimer == TIMER_ON)
	{
		// Close timer
		if(DiscardAsyncTimer (-1) == 0)
			printf("Async timer closed success.\n");
		else
			printf("Async timer closed unsuccess.\n");
		
		FlagTimer = TIMER_OFF;
	}
	
	iTemp = 0x123445673;
	
	status = viMoveOut8 (GERFM_hDev.GERFM_instr, VI_PXI_BAR3_SPACE, 0x5200, 4, (char *)&iTemp);    
    													
	status = GERFM_SetLED(GERFM_hDev,LED_OFF); 
	
	
	printf("Simulator stop.\n");
	
	return 0;

}








/*
   Send track data to simulator
 */
int SendTrkData(char * pData, int iDataCount)
{
    int status;
	
    glRfmComPtkID ++;
	
	status = viMoveOut8 (GERFM_hDev.GERFM_instr, VI_PXI_BAR3_SPACE, 0x5004, iDataCount, pData);  
	status = viMoveOut8 (GERFM_hDev.GERFM_instr, VI_PXI_BAR3_SPACE, 0x5000, 4, (char *)&glRfmComPtkID);
	
	return 0;

}



/* 
 * Set simulator AGC
 */
int simulatorSetAGC(int valueAGC)
{
	
	int status;
	
	// Change AGC
	AgcPtkID ++;
	status = viMoveOut8 (GERFM_hDev.GERFM_instr, VI_PXI_BAR3_SPACE, 0x50FC + 4, 4, (char*)&valueAGC);
	status = viMoveOut8 (GERFM_hDev.GERFM_instr, VI_PXI_BAR3_SPACE, 0x50FC, 4, (char*)&AgcPtkID);
	
	return 0;
	
}



/* 
 * Open IO board
 */
int ioBoardOpen()
{
	StatusIO = IO_Open (ParamIO);
	if (StatusIO == IO_NOT_FOUND)
	{
		printf("IO board not found!\n");
		return 1;
	}
	else
		return 0;
}


/* 
 * Close IO board
 */
int ioBoardClose()
{
	// Close IO board
	if (StatusIO == IO_FOUND)
		IO_Close(ParamIO);
	return 0;
}


/* 
 * Change IO relay
 */
int ioBoardChangeRelay()
{
	// Change relay
	IO_ElectroDiscrete (ParamIO, SwitchIO);
	SwitchIO = (SwitchIO == IO_RELAY_DISCRETE) ? IO_RELAY_CONNECT : IO_RELAY_DISCRETE;
	return 0;
}




