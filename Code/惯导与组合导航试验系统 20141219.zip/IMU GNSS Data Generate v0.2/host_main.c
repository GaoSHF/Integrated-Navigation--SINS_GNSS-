#include <formatio.h>
#include <ansi_c.h> 
#include <cvinetv.h>
#include <cvirte.h> 
#include <userint.h>
#include <tcpsupp.h> 
#include <visa.h>
#include <toolbox.h>


#include "common.h"
#include "host_main.h"
#include "host_sub_no_tcp.h"

// Global variables

CommandMessage Cmd;

static unsigned int	StatusTCP = TCP_INVALID_CONNECTION;

int ValueAGC;


// Global function
int CVICALLBACK TCPDataCallback (unsigned handle, int xType, int errCode, void *callbackData);

int InitPanel(void);


/*
	Host main entry
 */
int main (int argc, char *argv[])
{
     
	int error = 0;
	
    /* initialize and load resources */
    nullChk (InitCVIRTE (0, argv, 0));
    errChk (HandlePanel = LoadPanel (0, "host_main.uir", PANEL));
	
	// Create a TCP server to communicate with RT target.
    RegisterTCPServer (HOST_PORT, TCPDataCallback, 0);
	
	// Init panel
	InitPanel();
	
    /* display the panel and run the user interface */
    errChk (DisplayPanel (HandlePanel));
    errChk (RunUserInterface ());
	// Cleanup
	UnregisterTCPServer(HOST_PORT);
	
Error:
    /* clean up */
    DiscardPanel (HandlePanel);
    return 0;
}





/*
	Initiate panel
 */
int InitPanel(void)
{

	SetCtrlVal(HandlePanel, PANEL_TOGGLEBUTTON_TRACK, 0);
	
	SetCtrlVal(HandlePanel, PANEL_STRING_TCP_STATUS, "Waiting for connection.");
	
	// Disable control
	SetCtrlAttribute(HandlePanel, PANEL_NUMERIC_AGC, ATTR_DIMMED, 0);
	SetCtrlAttribute(HandlePanel, PANEL_BUTTON_CHANGE, ATTR_DIMMED, 1);
	SetCtrlAttribute(HandlePanel, PANEL_BUTTON_SET_AGC, ATTR_DIMMED, 0);
	
	return 0;
}




/*
	TCP/IP callback
 */
int CVICALLBACK TCPDataCallback (unsigned handle, int xType, int errCode, 
	void *callbackData)
{

	
	switch (xType)
    {
        case TCP_CONNECT:
            // Accept only one client connection
            if (StatusTCP != TCP_INVALID_CONNECTION)
                DisconnectTCPClient (handle);
            else
                StatusTCP = handle;
			SetCtrlVal (HandlePanel, PANEL_STRING_TCP_STATUS, "Connected.");
            break;
			
        case TCP_DISCONNECT:
            StatusTCP = TCP_INVALID_CONNECTION;
			SetCtrlVal (HandlePanel, PANEL_STRING_TCP_STATUS, "Waiting for connection.");
            break;
			
        case TCP_DATAREADY:
            break;
    }
    
    return 0;
}





/*
	Start or stop track button callback
 */
int CVICALLBACK buttonTrack (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	
	int flag;
	
	switch (event)
	{
		case EVENT_COMMIT:
			
			GetCtrlVal(HandlePanel, PANEL_TOGGLEBUTTON_TRACK, &flag);
			
			// Start generate track
			if ((StatusTCP != TCP_INVALID_CONNECTION) && (flag == 1))
			{
				Cmd.command = GPSSIM_COMMAND;
				Cmd.statusSimulator = STATUS_ON;
				ServerTCPWrite (StatusTCP, &Cmd, sizeof(Cmd), 5000); // Start simulation
				
				// Enable control
				SetCtrlAttribute(HandlePanel, PANEL_NUMERIC_AGC, ATTR_DIMMED, 0);
				SetCtrlAttribute(HandlePanel, PANEL_BUTTON_CHANGE, ATTR_DIMMED, 0);
				SetCtrlAttribute(HandlePanel, PANEL_BUTTON_SET_AGC, ATTR_DIMMED, 0);
			}
			// Stop generate track
			else if ((StatusTCP != TCP_INVALID_CONNECTION) && (flag == 0))
			{
				Cmd.command = GPSSIM_COMMAND;
				Cmd.statusSimulator = STATUS_OFF;
				ServerTCPWrite (StatusTCP, &Cmd, sizeof(Cmd), 5000); // Start simulation
				
				// Disable control
				SetCtrlAttribute(HandlePanel, PANEL_NUMERIC_AGC, ATTR_DIMMED, 1);
				SetCtrlAttribute(HandlePanel, PANEL_BUTTON_CHANGE, ATTR_DIMMED, 1);
				SetCtrlAttribute(HandlePanel, PANEL_BUTTON_SET_AGC, ATTR_DIMMED, 1);
			}
			// No TCP connection
			else if (StatusTCP == TCP_INVALID_CONNECTION)
			{
				// Install sub panel
				HandleSubPanelTCP = LoadPanel (HandlePanel, "host_sub_no_tcp.uir", PANEL_SUB1);
				// Wait until quit the sub panel
				InstallPopup (HandleSubPanelTCP); 
				
				SetCtrlVal(HandlePanel, PANEL_TOGGLEBUTTON_TRACK, 0);
			}
			else;

			break;
	}
	return 0;
}



/*
	Set simulator AGC
 */
int CVICALLBACK buttonSetAGC (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	
	switch (event)
	{
		case EVENT_COMMIT:
			
			GetCtrlVal(HandlePanel, PANEL_NUMERIC_AGC, &ValueAGC); // Get AGC value
			
			if ((StatusTCP != TCP_INVALID_CONNECTION) && ((ValueAGC >= 0) && (ValueAGC <= 60)))
			{
				Cmd.valueAGC = ValueAGC;
				Cmd.command = GPSSIM_AGC_COMMAND; 
				ServerTCPWrite (StatusTCP, &Cmd, sizeof(Cmd), 5000);
				
				SetCtrlVal(HandlePanel, PANEL_NUMERIC_AGC, ValueAGC); // Set AGC value
				
				printf("ValueAGC = %d\n", ValueAGC);
			}
			else;
			
			break;
	}
	return 0;
}



/*
	����GPSģ�����ӳ٣��ı�AGCͬʱIO���̵����л����պϻ�Ͽ���
 */
int CVICALLBACK buttonChange (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	
	int value;
	
	switch (event)
	{
		case EVENT_COMMIT:
			
			GetCtrlVal(HandlePanel, PANEL_NUMERIC_AGC, &value); // Get AGC value
			
			if (StatusTCP != TCP_INVALID_CONNECTION)
			{
				Cmd.valueAGC = (value == 25) ? 35 : 25;
				Cmd.command = GPSSIM_IO_CHANGE_COMMAND; 
				ServerTCPWrite (StatusTCP, &Cmd, sizeof(Cmd), 5000);
			}
			else;
			
			break;
	}
	return 0;
}



/*
	Quit RT button callback
 */
int CVICALLBACK buttonQuitRT (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:
			if (StatusTCP != TCP_INVALID_CONNECTION)
			{
				Cmd.command = QUIT_COMMAND;
				ServerTCPWrite (StatusTCP, &Cmd, sizeof(Cmd), 5000); // Stop simulation
			}
			else;
			
			break;
	}
	return 0;
}



/*
	Quit host button callback
 */
int CVICALLBACK buttonQuitHost (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:
			
			if (StatusTCP != TCP_INVALID_CONNECTION)
			{
				Cmd.command = QUIT_COMMAND; 
				ServerTCPWrite (StatusTCP, &Cmd, sizeof(Cmd), 5000); // Stop simulation
			}
			else;
			
			QuitUserInterface(0);
			
			break;
	}
	return 0;
}




