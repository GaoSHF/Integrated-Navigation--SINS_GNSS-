#include <formatio.h>   
#include <tcpsupp.h>
#include "asynctmr.h"
#include <cvirte.h>
#include <rtutil.h>
#include <userint.h> 
#include <analysis.h>
#include <utility.h>
#include <cvinetv.h>
#include <ansi_c.h>

#include "common.h"
#include "timer.h"
#include "sensor_simu.h"
#include "simulator.h"
#include "rfm.h"



// Global variables
static unsigned int StatusTCP	= TCP_INVALID_CONNECTION;

static int gLock;

static int gThdLock;

volatile int gDone; // Signal the main thread to exit the while loop in RTMain

CommandMessage Cmd;

static int ThreadFunctionIDSimulator = 0;



// Global function
int CVICALLBACK TCPDataCallback (unsigned handle, int xType, int errCode, void *cbData);

int GPSSIMCMDCallback(void);

int SetAGCCMDCallback(void);

int QuitCMDCallback(void);

int ChangeCMDCallback(void);





/*
	RT main entry
 */
void CVIFUNC_C RTmain (void)
{
	CNVData SelfTestFinshData;
	unsigned int prevProcessorMask = 0;
	
	if (InitCVIRTE (0, 0, 0) == 0)
		return;    /* out of memory */
	
	if (ConnectToTCPServer (&StatusTCP, HOST_PORT, HOST_ADDRESS, TCPDataCallback, 0, 5000) < 0)
		goto Done;
	
	// Configure the system processor pool to only include the first processor on the system.
	ConfigureProcessorPool (kProcessorPool_System, 0x1, &prevProcessorMask);
	// Suspend asynchronous timer callback so it can start when command is received from host application.
	//SuspendAsyncTimerCallbacks ();
	/* Your initialization code. */
	/* It is common for Real-Time applications to use multiple threads to */
	/* separate higher priority tasks from lower priority tasks. See the  */
	/* Thread Pool functions in the Utility Library and the Asynchronous  */
	/* Timer functions in <CVI>\toolslib\toolbox\asynctmr.fp.             */
	// Create lock to synchronize writing TCP data
	CmtNewLock (0, 0, &gLock);
	CmtNewLock (0, 0, &gThdLock); 
	
	
	//CmtNewThreadPool (2, &ThreadFunctionIDSimulator); // Simulator operation thread contains a timer
	

	while (!RTIsShuttingDown () && !gDone)
	{
		/* Your code. */
		/* Sleep for some amount of time to give the desired loop rate */
		/* and to allow lower priority threads to run.                 */
		ProcessSystemEvents();
		SleepUS (100);
	} 
	 
	
	// Release thread
	/*if (ThreadFunctionIDSimulator)
		CmtDiscardThreadPool (ThreadFunctionIDSimulator);*/
	
	
	// Restore the original system processor pool configuration.
	if (prevProcessorMask)
		ConfigureProcessorPool (kProcessorPool_System, prevProcessorMask, NULL);
	
	/* Your cleanup code. */
	CmtDiscardLock (gLock);
	if (StatusTCP != TCP_INVALID_CONNECTION)
		DisconnectFromTCPServer (StatusTCP);
Done:  	
	CloseCVIRTE ();
	
}





/*
	TCP callback
 */
int CVICALLBACK TCPDataCallback (unsigned handle, int xType, int errCode, void *cbData)
{

	
    switch (xType)
    {
        case TCP_DISCONNECT:
            StatusTCP = TCP_INVALID_CONNECTION;
            break;
        case TCP_DATAREADY: // Client executable sent a command.
			// ClientTCPRead does not guarantee that all data will be transferred in
			// a single call, but this code assumes that it does for simplicity.
			ClientTCPRead (StatusTCP, &Cmd, sizeof(Cmd), 5000);
			switch(Cmd.command)
			{
				
				case QUIT_COMMAND:
					QuitCMDCallback();  
					break;
				
				case GPSSIM_COMMAND:
					GPSSIMCMDCallback();  
					break;
					
				case GPSSIM_AGC_COMMAND:
					SetAGCCMDCallback();
					break;
					
				case GPSSIM_IO_CHANGE_COMMAND:
					ChangeCMDCallback();
					break;
		
			}
			
            break;
			
    }
    
    return 0;
}



/*
	Simulator TCP callback
 */
int GPSSIMCMDCallback(void)
{
    int test_flag;
	
	CmtGetLock (gLock);
	
    test_flag = Cmd.statusSimulator;
	
	// Start GNSS simulation
	if(test_flag)
	{   
		
		la = LA0;
		lon = LON0;
		h = H0;
		ve = VE0;
		vn = VN0;
		vu = VU0;
		ae = AE_STAGE1;
		an = AN_STAGE1;
		au = AU_STAGE1;
	
		sensorPgeo2xyz(&x, &y, &z, la, lon, h);
		sensorVenu2xyz(&vx, &vy, &vz, ve, vn, vu, la, lon);
		sensorAenu2xyz(&ax, &ay, &az, ae, an, au, la, lon);
		
		rfmOpenDev();
		
		rfmEnableDMA();
		
		simulatorInit();
		
		rfmStartMC();
		//ioBoardOpen();
	}
	// Stop GNSS simulation
	else
	{
		rfmStopMC();
		
		simulatorStop();
		
		rfmDisableDMA();
		
		rfmCloseDev();
		
		//ioBoardClose();
	}
	
	CmtReleaseLock (gLock);
	
	return 0;

}



/*
	Set simulator AGC callback
 */
int SetAGCCMDCallback(void)
{
	
	CmtGetLock (gLock);
	
    simulatorSetAGC(Cmd.valueAGC);
	
	printf("AGC set success.\n");
	
	CmtReleaseLock (gLock);
	
	return 0;

}


/*
	Change simulator AGC and IO board relay callback
 */
int ChangeCMDCallback(void)
{
	
	CmtGetLock (gLock);
	
    //simulatorSetAGC(Cmd.valueAGC);
	ioBoardChangeRelay();
	
	printf("Both AGC and relay changed.\n");
	
	CmtReleaseLock (gLock);
	
	return 0;

}



/*
	Quit RT programme TCP callback
 */
int QuitCMDCallback(void)
{
	
	printf("Quit RT programme success.\n");
	
	gDone = 1; // Signal the main thread to exit the while loop in RTMain
	
	return 0;
}












