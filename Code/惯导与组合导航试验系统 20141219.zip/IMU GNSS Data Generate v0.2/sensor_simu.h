//==============================================================================
//
// Title:       sensor_simu.h
// Purpose:     A short description of the interface.
//
// Created on:  2013/12/20 at 13:49:09 by ZhaoHengyang.
// Copyright:   Beihang University. All Rights Reserved.
//
//==============================================================================

#ifndef __sensor_simu_H__
#define __sensor_simu_H__

#ifdef __cplusplus
    extern "C" {
#endif

//==============================================================================
// Include files

#include "cvidef.h"

//==============================================================================
// Constants
#define	pi		3.14159265358979323846

// INS algorithm constant
#define	wie		7.292115147e-5	// rad/s
#define	Re		6378137		// m
#define	e		(1 / 298.257223563)
#define	g0		9.7803267714	// m/s^2
#define	gk1		0.00193185138639
#define	gk2		0.00669437999013
		
		
#define	LA0		(39 * pi / 180)
#define	LON0	(116 * pi / 180)
#define	H0		100
		
#define	VE0	0
#define	VN0	0
#define	VU0	0
		
#define	AE_STAGE1	0
#define	AN_STAGE1	10
#define	AU_STAGE1	0

#define	AE_STAGE2	0
#define	AN_STAGE2	40
#define	AU_STAGE2	0
		
#define	AE_STAGE3	0
#define	AN_STAGE3	0
#define	AU_STAGE3	0
		
#define	TIME_LEN_STAGE1	30
#define	TIME_LEN_STAGE2	15
#define	TIME_LEN_STAGE3	1300

		

		
		
//==============================================================================
// Types

//==============================================================================
// External variables
double wibb[3];
double fb[3];
		
		
//==============================================================================
// Global functions

int sensorVenu2xyz (double *vx, double *vy, double *vz, double ve, double vn, double vu, double la, double lon);
int sensorAenu2xyz (double *ax, double *ay, double *az, double ae, double an, double au, double la, double lon);
int sensorPgeo2xyz (double *x, double *y, double *z, double la, double lon, double h);

int sensorPgeoRefresh (double *laNew, double *lonNew, double *hNew, double ve, double vn, double vu, double la, double lon, double h, double T);
int sensorVenuRefresh (double *ve, double *vn, double *vu, double ae, double an, double au, double T);

int sensorFbRefresh (double *ft, double ae, double an, double au, double ve, double vn, double vu, double la, double h) ;
int sensorWibbRefresh (double *witt, double ve, double vn, double la, double h);


#ifdef __cplusplus
    }
#endif

#endif  /* ndef __imu_gnss_simu_H__ */
