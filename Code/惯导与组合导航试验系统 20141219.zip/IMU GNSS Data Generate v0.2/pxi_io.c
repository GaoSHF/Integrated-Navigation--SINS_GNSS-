//==============================================================================
//
// Title:       pxi_io.c
// Purpose:     A short description of the implementation.
//
// Created on:  2013-5-30 at 19:50:13 by Cindy.
// Copyright:   buaa. All Rights Reserved.
//
//==============================================================================

//==============================================================================
// Include files

#include "pxi_io.h"

//==============================================================================
// Constants

//==============================================================================
// Types

//==============================================================================
// Static global variables

//==============================================================================
// Static functions

//==============================================================================
// Global variables

ViUInt32 NumFound;
ViFindList FindList;
char InstrDescriptor[VISA_NAME_LENGTH];

ViUInt16 ManfIdGet = VI_NULL;
ViUInt16 ModelCodeGet = VI_NULL;



//==============================================================================
// Global functions

/// HIFN  What does your function do?
/// HIPAR x/What inputs does your function expect?
/// HIRET What does your function return?


/* 
 * Open IO board
 * Return value: 0 -- found;  1 -- unfound
 */
int IO_Open (IO_PARAM *ioParam) 
{
	int i, j;
	
	// **************** Refresh list and check for IO board ****************
		// First, open a VISA session.
		viOpenDefaultRM (&(ioParam->defaultRM));
	
		// Now, do an initial search.  viFindRsrc returns the instrument descriptor of the first instrument found and the number of total resources found.
		viFindRsrc (ioParam->defaultRM, "PXI?*INSTR", &FindList, &NumFound, InstrDescriptor);
	
		// List all pxi resources
		if(NumFound > 0){
			for(i = 0; i < NumFound; i ++){
				viOpen(ioParam->defaultRM, InstrDescriptor, VI_NULL, VI_NULL, &(ioParam->visaSelected));
		
				viGetAttribute(ioParam->visaSelected, VI_ATTR_MODEL_CODE, &ModelCodeGet);
				viGetAttribute(ioParam->visaSelected, VI_ATTR_MANF_ID, &ManfIdGet);
		
				// Open IO board
				if((ModelCodeGet == IO_DEFAULT_MODEL_CODE) && (ManfIdGet == IO_DEFAULT_MANF_ID)){
					viOpen(ioParam->defaultRM, InstrDescriptor, VI_NULL, VI_NULL, &(ioParam->session)); // Open IO board, get board VISA session
					
					// Get VISA name
					for(j = 0; j < VISA_NAME_LENGTH; j ++)
						*(ioParam->name + j) = *(InstrDescriptor + j); 
					
					return IO_FOUND;
				}
				
				if(i != 0)
					viFindNext(FindList, InstrDescriptor);
			}
		}
		// Not found
		return IO_NOT_FOUND;
}

/* 
 * Close IO board
 */
int IO_Close (IO_PARAM *ioParam) 
{
	viClose(ioParam->session);
	
	viClose(ioParam->visaSelected);
	viClose(ioParam->defaultRM); // Close existing VISA session
	
	return 0;
}


// ************************************************** 
// ************************************************** 

// **************** Digital output test ****************
/* 
 * Send 5V relay data on all bits
 */
int IO_TestRelay5V (IO_PARAM ioParam)
{

	// Write data
	viOut32(ioParam.session, VI_PXI_BAR0_SPACE, IO_OFFSET_O5, ioParam.dataWriteR5);

	
	return 0;
}

/* 
 * Send 27V relay data on all bits
 */
int IO_TestRelay27V (IO_PARAM ioParam)
{

	// Write data
	viOut32(ioParam.session, VI_PXI_BAR0_SPACE, IO_OFFSET_O27, ioParam.dataWriteR27);

	
	return 0;
}

/* 
 * Send OC data on all bits
 */
int IO_TestOC (IO_PARAM ioParam)
{

	// Write data
	viOut32(ioParam.session, VI_PXI_BAR0_SPACE, IO_OFFSET_OC5, ioParam.dataWriteOC);

	
	return 0;
}

// **************** Digital input test ****************
/* 
 * Read 5V isolation data on all bits
 */
int IO_TestIsolation5V (IO_PARAM *ioParam)
{
	ViUInt32 dataRead;

	// Read data
	viIn32(ioParam->session, VI_PXI_BAR0_SPACE, IO_OFFSET_I5, &dataRead);

	ioParam->dataReadI5 = dataRead & 0xFFFF; // Only need 16 bits

	
	return 0;
}

/* 
 * Read 27V isolation data on all bits
 */
int IO_TestIsolation27V (IO_PARAM *ioParam)
{
	ViUInt32 dataRead;
	
	// Read data
	viIn32(ioParam->session, VI_PXI_BAR0_SPACE, IO_OFFSET_I27, &dataRead);

	ioParam->dataReadI27 = dataRead & 0xFF; // Only need 8 bits

	
	return 0;
}

// **************** FPGA RAM test ****************
/* 
 * Write RAM on IO board FPGA
 */
int IO_WriteRAM (IO_PARAM ioParam, ViUInt32 dataWrite)
{
	
	// Write data
	viOut32(ioParam.session, VI_PXI_BAR0_SPACE, IO_OFFSET_RAM, dataWrite);
	
	return 0;
}

/* 
 * Read RAM on IO board FPGA
 */
int IO_ReadRAM (IO_PARAM ioParam, ViUInt32 *dataRead)
{
	// Read data
	viIn32(ioParam.session, VI_PXI_BAR0_SPACE, IO_OFFSET_RAM, dataRead);

	
	return 0;
}

// **************** FPGA LED test ****************
/* 
 * Turn on LED
 */
int IO_TurnOnLED (IO_PARAM ioParam)
{
	viOut32(ioParam.session, VI_PXI_BAR0_SPACE, IO_OFFSET_LED, 1);
	
	return 0;
}

/* 
 * Turn off LED
 */
int IO_TurnOffLED (IO_PARAM ioParam)
{
	viOut32(ioParam.session, VI_PXI_BAR0_SPACE, IO_OFFSET_LED, 0); 
	
	return 0;
}

// **************************************************
// ************************************************** 


// **************** 27V Relay output ****************
/* 
 * ��������
 * ioSwitch: 1 -- �̵����պ�;	0 -- �̵����Ͽ�
 */
int IO_ElectroDiscrete (IO_PARAM *ioParam, ViUInt8 ioSwitch)
{

	if(ioSwitch == IO_RELAY_CONNECT) {
		ioParam->dataWriteR27 |= ELECTRO_DISCRETE;
		viOut32(ioParam->session, VI_PXI_BAR0_SPACE, IO_OFFSET_O27, ioParam->dataWriteR27);
	}
	else if(ioSwitch == IO_RELAY_DISCRETE) {
		ioParam->dataWriteR27 &= (~ELECTRO_DISCRETE);
		viOut32(ioParam->session, VI_PXI_BAR0_SPACE, IO_OFFSET_O27, ioParam->dataWriteR27);
	}
	else;

	
	return 0;
}

/* 
 * ��������
 * ioSwitch: 1 -- �̵����պ�;	0 -- �̵����Ͽ�
 */
int IO_PhysicalDiscrete (IO_PARAM *ioParam, ViUInt8 ioSwitch)
{

	if(ioSwitch == IO_RELAY_CONNECT) {
		ioParam->dataWriteR27 |= PHYSICAL_DISCRETE;
		viOut32(ioParam->session, VI_PXI_BAR0_SPACE, IO_OFFSET_O27, ioParam->dataWriteR27);
	}
	else if(ioSwitch == IO_RELAY_DISCRETE) {
		ioParam->dataWriteR27 &= (~PHYSICAL_DISCRETE);
		viOut32(ioParam->session, VI_PXI_BAR0_SPACE, IO_OFFSET_O27, ioParam->dataWriteR27);
	}
	else;

	
	return 0;
}

// **************** 5V Relay output ****************
/* 
 * ��ص�ѹ����
 * ioSwitch: 1 -- �̵����պ�;	0 -- �̵����Ͽ�
 */
int IO_BatteryVoltageNormal (IO_PARAM *ioParam, ViUInt8 ioSwitch)
{

	if(ioSwitch == IO_RELAY_CONNECT) {
		ioParam->dataWriteR5 |= BATTERY_VOLTAGE_NORMAL;
		viOut32(ioParam->session, VI_PXI_BAR0_SPACE, IO_OFFSET_O5, ioParam->dataWriteR5);
	}
	else if(ioSwitch == IO_RELAY_DISCRETE) {
		ioParam->dataWriteR5 &= (~BATTERY_VOLTAGE_NORMAL);
		viOut32(ioParam->session, VI_PXI_BAR0_SPACE, IO_OFFSET_O5, ioParam->dataWriteR5);
	}
	else;

	
	return 0;
}

/* 
 * ��ؼ����ź�
 * ioSwitch: 1 -- �̵����պ�;	0 -- �̵����Ͽ�
 */
int IO_BatteryActivate (IO_PARAM *ioParam, ViUInt8 ioSwitch)
{

	if(ioSwitch == IO_RELAY_CONNECT) {
		ioParam->dataWriteR5 |= BATTERY_ACTIVATE;
		viOut32(ioParam->session, VI_PXI_BAR0_SPACE, IO_OFFSET_O5, ioParam->dataWriteR5);
	}
	else if(ioSwitch == IO_RELAY_DISCRETE) {
		ioParam->dataWriteR5 &= (~BATTERY_ACTIVATE);
		viOut32(ioParam->session, VI_PXI_BAR0_SPACE, IO_OFFSET_O5, ioParam->dataWriteR5);
	}
	else;

	
	return 0;
}

/* 
 * ����ϵͳ��ȫ�źţ�һ����ָ��� 
 * ioSwitch: 1 -- �̵����պ�;	0 -- �̵����Ͽ�
 */
int IO_SecuritySystem (IO_PARAM *ioParam, ViUInt8 ioSwitch)
{

	if(ioSwitch == IO_RELAY_CONNECT) {
		ioParam->dataWriteR5 |= SECURITY_SYSTEM;
		viOut32(ioParam->session, VI_PXI_BAR0_SPACE, IO_OFFSET_O5, ioParam->dataWriteR5);
	}
	else if(ioSwitch == IO_RELAY_DISCRETE) {
		ioParam->dataWriteR5 &= (~SECURITY_SYSTEM);
		viOut32(ioParam->session, VI_PXI_BAR0_SPACE, IO_OFFSET_O5, ioParam->dataWriteR5);
	}
	else;

	
	return 0;
}



// **************** 5V isolation input ****************
/* 
 * K2
 * Return value: 0 -- �͵�ƽ;  1 -- �ߵ�ƽ 
 */
int IO_K2 (IO_PARAM *ioParam)
{
	
	viIn32(ioParam->session, VI_PXI_BAR0_SPACE, IO_OFFSET_I5, &(ioParam->dataReadI5));

	if((ioParam->dataReadI5 & K2) == 0)
		return IO_ISOLATION_LOW;
	else
		return IO_ISOLATION_HIGH;
}

/* 
 * ����׼��
 * Return value: 0 -- �͵�ƽ;  1 -- �ߵ�ƽ 
 */
int IO_MissilePrepare (IO_PARAM *ioParam)
{

	viIn32(ioParam->session, VI_PXI_BAR0_SPACE, IO_OFFSET_I5, &(ioParam->dataReadI5));

	if((ioParam->dataReadI5 & MISSILE_PREPARE) == 0)
		return IO_ISOLATION_LOW;
	else
		return IO_ISOLATION_HIGH;
}

/* 
 * ����ͷ�Ӹ�ѹ 
 * Return value: 0 -- �͵�ƽ;  1 -- �ߵ�ƽ 
 */
int IO_GuiderHighPressure (IO_PARAM *ioParam)
{
	
	viIn32(ioParam->session, VI_PXI_BAR0_SPACE, IO_OFFSET_I5, &(ioParam->dataReadI5));

	if((ioParam->dataReadI5 & GUIDER_HIGH_PRESSURE) == 0)
		return IO_ISOLATION_LOW;
	else
		return IO_ISOLATION_HIGH;
}


/* 
 * �ɿؼ�����Լ����� 
 * Return value: 0 -- �͵�ƽ;  1 -- �ߵ�ƽ 
 */
int IO_FlightControlSelfTestNormal (IO_PARAM *ioParam)
{
	
	viIn32(ioParam->session, VI_PXI_BAR0_SPACE, IO_OFFSET_I5, &(ioParam->dataReadI5));

	if((ioParam->dataReadI5 & FLIGHT_CONTROL_SELF_TEST_NORMAL) == 0)
		return IO_ISOLATION_LOW;
	else
		return IO_ISOLATION_HIGH;
}










/* 
 * Enable PCI interrupt on hardware level (refer to FPGA PCI host code, write address 0x4 with 0x10) 
 */
int IO_EnableIntPCI (IO_PARAM ioParam, ViHndlr intHandlerPCI)
{
	
	viOut32(ioParam.session, VI_PXI_BAR0_SPACE, 0x4, 0x10); // write address 0x4 with 0x10
	
	viInstallHandler (ioParam.session, VI_EVENT_PXI_INTR, intHandlerPCI, (ViAddr)10 ); // Handler enable
	
	viEnableEvent(ioParam.session, VI_EVENT_PXI_INTR, VI_HNDLR, VI_NULL); // Enable interrupt event

	return 1;
}

/* 
 * Disable PCI interrupt on hardware level (refer to FPGA PCI host code, write address 0x4 with 0x0) 
 */
int IO_DisableIntPCI (IO_PARAM ioParam, ViHndlr intHandlerPCI)
{
	
	viOut32(ioParam.session, VI_PXI_BAR0_SPACE, 0x4, 0x0); // write address 0x4 with 0x0
	
	viDisableEvent(ioParam.session, VI_EVENT_PXI_INTR, VI_HNDLR); // Event disable
	
	viUninstallHandler(ioParam.session, VI_EVENT_PXI_INTR, intHandlerPCI, (ViAddr)10); // Handler disable

	return 1;
}




