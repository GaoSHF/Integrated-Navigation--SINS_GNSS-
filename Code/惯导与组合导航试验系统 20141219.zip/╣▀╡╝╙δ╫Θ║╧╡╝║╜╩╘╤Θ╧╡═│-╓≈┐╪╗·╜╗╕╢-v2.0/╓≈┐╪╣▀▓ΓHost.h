/**************************************************************************/
/* LabWindows/CVI User Interface Resource (UIR) Include File              */
/* Copyright (c) National Instruments 2014. All Rights Reserved.          */
/*                                                                        */
/* WARNING: Do not add to, delete from, or otherwise modify the contents  */
/*          of this include file.                                         */
/**************************************************************************/

#include <userint.h>

#ifdef __cplusplus
    extern "C" {
#endif

     /* Panels and Controls: */

#define  PANEL_IM                         1
#define  PANEL_IM_STOPBUTTON              2       /* callback function: buttonStopIM */
#define  PANEL_IM_STARTBUTTON             3       /* callback function: buttonStartIM */
#define  PANEL_IM_QUITBUTTON              4       /* callback function: buttonQuitIM */
#define  PANEL_IM_SELFTESTBUTTON          5       /* callback function: buttonSelftestIM */
#define  PANEL_IM_INSBUTTON               6       /* callback function: buttonPulse */
#define  PANEL_IM_GPSBUTTON               7       /* callback function: buttonGNSS429 */
#define  PANEL_IM_FIX_MODE                8
#define  PANEL_IM_SVNO_10                 9
#define  PANEL_IM_SVNO_9                  10
#define  PANEL_IM_SVNO_8                  11
#define  PANEL_IM_SVNO_7                  12
#define  PANEL_IM_SVNO_6                  13
#define  PANEL_IM_SVNO_5                  14
#define  PANEL_IM_SVNO_4                  15
#define  PANEL_IM_SVNO_3                  16
#define  PANEL_IM_SVNO_2                  17
#define  PANEL_IM_WEIJU_10                18
#define  PANEL_IM_WEIJU_9                 19
#define  PANEL_IM_WEIJU_8                 20
#define  PANEL_IM_WEIJU_7                 21
#define  PANEL_IM_WEIJU_6                 22
#define  PANEL_IM_WEIJU_5                 23
#define  PANEL_IM_WEIJU_4                 24
#define  PANEL_IM_WEIJU_3                 25
#define  PANEL_IM_WEIJU_2                 26
#define  PANEL_IM_WEIJULV_10              27
#define  PANEL_IM_WEIJULV_9               28
#define  PANEL_IM_WEIJULV_8               29
#define  PANEL_IM_WEIJULV_7               30
#define  PANEL_IM_WEIJULV_6               31
#define  PANEL_IM_WEIJULV_5               32
#define  PANEL_IM_WEIJULV_4               33
#define  PANEL_IM_WEIJULV_3               34
#define  PANEL_IM_WEIJULV_2               35
#define  PANEL_IM_POSITION_X_10           36
#define  PANEL_IM_POSITION_X_9            37
#define  PANEL_IM_POSITION_X_8            38
#define  PANEL_IM_POSITION_X_7            39
#define  PANEL_IM_POSITION_X_6            40
#define  PANEL_IM_POSITION_X_5            41
#define  PANEL_IM_POSITION_X_4            42
#define  PANEL_IM_POSITION_X_3            43
#define  PANEL_IM_POSITION_Y_10           44
#define  PANEL_IM_POSITION_Y_9            45
#define  PANEL_IM_POSITION_Y_8            46
#define  PANEL_IM_POSITION_Y_7            47
#define  PANEL_IM_POSITION_Y_6            48
#define  PANEL_IM_POSITION_Y_5            49
#define  PANEL_IM_POSITION_Y_4            50
#define  PANEL_IM_POSITION_Y_3            51
#define  PANEL_IM_POSITION_Z_10           52
#define  PANEL_IM_POSITION_Z_9            53
#define  PANEL_IM_POSITION_Z_8            54
#define  PANEL_IM_POSITION_Z_7            55
#define  PANEL_IM_POSITION_Z_6            56
#define  PANEL_IM_POSITION_Z_5            57
#define  PANEL_IM_POSITION_Z_4            58
#define  PANEL_IM_POSITION_Z_3            59
#define  PANEL_IM_POSITION_Z_2            60
#define  PANEL_IM_POSITION_Y_2            61
#define  PANEL_IM_POSITION_X_2            62
#define  PANEL_IM_VELOCITY_X_10           63
#define  PANEL_IM_VELOCITY_X_9            64
#define  PANEL_IM_VELOCITY_X_8            65
#define  PANEL_IM_VELOCITY_X_7            66
#define  PANEL_IM_VELOCITY_X_6            67
#define  PANEL_IM_VELOCITY_X_5            68
#define  PANEL_IM_VELOCITY_X_4            69
#define  PANEL_IM_VELOCITY_X_3            70
#define  PANEL_IM_VELOCITY_X_2            71
#define  PANEL_IM_VELOCITY_Y_10           72
#define  PANEL_IM_VELOCITY_Y_9            73
#define  PANEL_IM_VELOCITY_Y_8            74
#define  PANEL_IM_VELOCITY_Y_7            75
#define  PANEL_IM_VELOCITY_Y_6            76
#define  PANEL_IM_VELOCITY_Y_5            77
#define  PANEL_IM_VELOCITY_Y_4            78
#define  PANEL_IM_VELOCITY_Y_3            79
#define  PANEL_IM_VELOCITY_Y_2            80
#define  PANEL_IM_VELOCITY_Z_10           81
#define  PANEL_IM_VELOCITY_Z_9            82
#define  PANEL_IM_VELOCITY_Z_8            83
#define  PANEL_IM_VELOCITY_Z_7            84
#define  PANEL_IM_VELOCITY_Z_6            85
#define  PANEL_IM_VELOCITY_Z_5            86
#define  PANEL_IM_VELOCITY_Z_4            87
#define  PANEL_IM_VELOCITY_Z_3            88
#define  PANEL_IM_VELOCITY_Z_2            89
#define  PANEL_IM_VELOCITY_Z_1            90
#define  PANEL_IM_VELOCITY_Y_1            91
#define  PANEL_IM_VELOCITY_X_1            92
#define  PANEL_IM_POSITION_Z_1            93
#define  PANEL_IM_POSITION_Y_1            94
#define  PANEL_IM_POSITION_X_1            95
#define  PANEL_IM_WEIJULV_1               96
#define  PANEL_IM_WEIJU_1                 97
#define  PANEL_IM_SVNO_1                  98
#define  PANEL_IM_SVS                     99
#define  PANEL_IM_PDOP                    100
#define  PANEL_IM_ALT                     101
#define  PANEL_IM_LAT                     102
#define  PANEL_IM_RCVTIME                 103
#define  PANEL_IM_POSITION_Z              104
#define  PANEL_IM_POSITION_Y              105
#define  PANEL_IM_VELOCITY_Z              106
#define  PANEL_IM_VELOCITY_Y              107
#define  PANEL_IM_VELOCITY_X              108
#define  PANEL_IM_POSITION_X              109
#define  PANEL_IM_LON                     110
#define  PANEL_IM_LAZN                    111
#define  PANEL_IM_LAZP                    112
#define  PANEL_IM_LAYN                    113
#define  PANEL_IM_LAYP                    114
#define  PANEL_IM_LAXN                    115
#define  PANEL_IM_LAXP                    116
#define  PANEL_IM_ASZN                    117
#define  PANEL_IM_ASZP                    118
#define  PANEL_IM_ASYN                    119
#define  PANEL_IM_ASYP                    120
#define  PANEL_IM_ASXN                    121
#define  PANEL_IM_ASXP                    122
#define  PANEL_IM_GPSFIRSTDATA            123
#define  PANEL_IM_PPSTIME                 124
#define  PANEL_IM_GPSTIME                 125
#define  PANEL_IM_PULSETIME               126
#define  PANEL_IM_TEXTMSG                 127
#define  PANEL_IM_COUNTERTIME             128
#define  PANEL_IM_LED3                    129
#define  PANEL_IM_LED2                    130
#define  PANEL_IM_FIX_QUALITY3            131
#define  PANEL_IM_FIX_QUALITY2            132
#define  PANEL_IM_FIX_QUALITY1            133
#define  PANEL_IM_LED1                    134
#define  PANEL_IM_BOARDPOWERSWITCH        135     /* callback function: PowerSwitchIM5V */
#define  PANEL_IM_POWERSWITCH             136     /* callback function: PowerSwitchIM27V */
#define  PANEL_IM_TEXTMSG_2               137
#define  PANEL_IM_DECORATION              138
#define  PANEL_IM_TEXTMSG_3               139
#define  PANEL_IM_POWER_3                 140
#define  PANEL_IM_POWER_18                141
#define  PANEL_IM_POWER_4                 142
#define  PANEL_IM_POWER_2                 143
#define  PANEL_IM_POWER_19                144
#define  PANEL_IM_POWER                   145
#define  PANEL_IM_DECORATION_8            146
#define  PANEL_IM_I_GPS                   147
#define  PANEL_IM_TIME_PULSE              148
#define  PANEL_IM_TIME_IMU_GNSS           149
#define  PANEL_IM_I_INS                   150
#define  PANEL_IM_V_GPS                   151
#define  PANEL_IM_TIMER                   152     /* callback function: timerIM */
#define  PANEL_IM_I_PULSE2                153
#define  PANEL_IM_I_PULSE1                154
#define  PANEL_IM_V_PULSE2                155
#define  PANEL_IM_V_PULSE1                156
#define  PANEL_IM_V_INS                   157
#define  PANEL_IM_DECORATION_9            158
#define  PANEL_IM_DECORATION_7            159
#define  PANEL_IM_DECORATION_6            160
#define  PANEL_IM_DECORATION_10           161
#define  PANEL_IM_DECORATION_3            162
#define  PANEL_IM_MODULESWITCH            163     /* callback function: switchModeIM */
#define  PANEL_IM_SNR_10                  164
#define  PANEL_IM_SNR_9                   165
#define  PANEL_IM_SNR_8                   166
#define  PANEL_IM_SNR_7                   167
#define  PANEL_IM_SNR_6                   168
#define  PANEL_IM_SNR_5                   169
#define  PANEL_IM_SNR_4                   170
#define  PANEL_IM_SNR_3                   171
#define  PANEL_IM_SNR_2                   172
#define  PANEL_IM_SNR_1                   173


     /* Menu Bars, Menus, and Menu Items: */

          /* (no menu bars in the resource file) */


     /* Callback Prototypes: */

int  CVICALLBACK buttonGNSS429(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK buttonPulse(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK buttonQuitIM(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK buttonSelftestIM(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK buttonStartIM(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK buttonStopIM(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK PowerSwitchIM27V(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK PowerSwitchIM5V(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK switchModeIM(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK timerIM(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);


#ifdef __cplusplus
    }
#endif
