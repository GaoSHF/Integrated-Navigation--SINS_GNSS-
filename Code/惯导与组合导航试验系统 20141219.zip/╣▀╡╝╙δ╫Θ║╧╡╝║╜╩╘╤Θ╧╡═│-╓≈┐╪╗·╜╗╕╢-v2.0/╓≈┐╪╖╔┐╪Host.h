/**************************************************************************/
/* LabWindows/CVI User Interface Resource (UIR) Include File              */
/* Copyright (c) National Instruments 2014. All Rights Reserved.          */
/*                                                                        */
/* WARNING: Do not add to, delete from, or otherwise modify the contents  */
/*          of this include file.                                         */
/**************************************************************************/

#include <userint.h>

#ifdef __cplusplus
    extern "C" {
#endif

     /* Panels and Controls: */

#define  PANEL_FC                         1
#define  PANEL_FC_STOPBUTTON              2       /* callback function: buttonStopFC */
#define  PANEL_FC_STARTBUTTON             3       /* callback function: buttonStartFC */
#define  PANEL_FC_QUITBUTTON              4       /* callback function: buttonQuitFC */
#define  PANEL_FC_SELFTESTBUTTON          5       /* callback function: buttonSelftestFC */
#define  PANEL_FC_T1553BUTTON             6       /* callback function: buttonFireControl */
#define  PANEL_FC_YCBUTTON                7       /* callback function: buttonYC */
#define  PANEL_FC_GPSBUTTON               8       /* callback function: buttonGNSSFC422 */
#define  PANEL_FC_GPSFIRSTDATA            9
#define  PANEL_FC_PPSTIME                 10
#define  PANEL_FC_GPSTIME                 11
#define  PANEL_FC_TIME_BK                 12
#define  PANEL_FC_I_BK                    13
#define  PANEL_FC_TIME_FC                 14
#define  PANEL_FC_I_FC                    15
#define  PANEL_FC_V_BK                    16
#define  PANEL_FC_V_FC                    17
#define  PANEL_FC_ROLL                    18
#define  PANEL_FC_PITCH                   19
#define  PANEL_FC_T0                      20
#define  PANEL_FC_YAW                     21
#define  PANEL_FC_VRZ                     22
#define  PANEL_FC_VRY                     23
#define  PANEL_FC_GRAPH                   24
#define  PANEL_FC_VRX                     25
#define  PANEL_FC_ZR                      26
#define  PANEL_FC_YR                      27
#define  PANEL_FC_XR                      28
#define  PANEL_FC_YCTIME                  29
#define  PANEL_FC_LED2                    30
#define  PANEL_FC_LED10                   31
#define  PANEL_FC_LED9                    32
#define  PANEL_FC_LED8                    33
#define  PANEL_FC_LED6                    34
#define  PANEL_FC_LED5                    35
#define  PANEL_FC_LED4                    36
#define  PANEL_FC_LED3                    37
#define  PANEL_FC_LED1                    38
#define  PANEL_FC_BOARDPOWERSWITCH        39      /* callback function: PowerSwitchFC5V */
#define  PANEL_FC_POWERSWITCH             40      /* callback function: PowerSwitchFC27V */
#define  PANEL_FC_TEXTMSG_58              41
#define  PANEL_FC_TEXTMSG_69              42
#define  PANEL_FC_TEXTMSG_68              43
#define  PANEL_FC_TEXTMSG_67              44
#define  PANEL_FC_TEXTMSG_66              45
#define  PANEL_FC_TEXTMSG_64              46
#define  PANEL_FC_TEXTMSG_59              47
#define  PANEL_FC_TEXTMSG_70              48
#define  PANEL_FC_TEXTMSG_62              49
#define  PANEL_FC_TEXTMSG_57              50
#define  PANEL_FC_DECORATION_11           51
#define  PANEL_FC_DECORATION_16           52
#define  PANEL_FC_DECORATION_18           53
#define  PANEL_FC_DECORATION_17           54
#define  PANEL_FC_DECORATION_14           55
#define  PANEL_FC_DECORATION_15           56
#define  PANEL_FC_DECORATION_4            57
#define  PANEL_FC_SWITCH_FIRE_CONTROL     58
#define  PANEL_FC_MODULESWITCH            59      /* callback function: switchModeFC */
#define  PANEL_FC_TIMER                   60      /* callback function: timerFC */
#define  PANEL_FC_DECORATION_12           61
#define  PANEL_FC_POWER_5                 62
#define  PANEL_FC_DECORATION_13           63
#define  PANEL_FC_POWER_6                 64
#define  PANEL_FC_POWER_2                 65
#define  PANEL_FC_POWER_7                 66
#define  PANEL_FC_TEXTMSG_53              67
#define  PANEL_FC_TEXTMSG_56              68
#define  PANEL_FC_TEXTMSG_55              69
#define  PANEL_FC_TEXTMSG_54              70
#define  PANEL_FC_TABLE_1553RECEIVE       71
#define  PANEL_FC_TABLE_1553SEND          72


     /* Menu Bars, Menus, and Menu Items: */

          /* (no menu bars in the resource file) */


     /* Callback Prototypes: */

int  CVICALLBACK buttonFireControl(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK buttonGNSSFC422(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK buttonQuitFC(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK buttonSelftestFC(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK buttonStartFC(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK buttonStopFC(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK buttonYC(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK PowerSwitchFC27V(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK PowerSwitchFC5V(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK switchModeFC(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK timerFC(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);


#ifdef __cplusplus
    }
#endif
