//-----------------------------------------------------------------------------
// CVI RealTime Network Variable example.
//-----------------------------------------------------------------------------

#ifndef _COMMON_H_
#define _COMMON_H_

#include "pxi_io.h"


// 100s / 0.001ms = 100000
// maximum sizeof(DataMessage) = 500 * 8 bytes
// 100000 * 500 * 8 bytes = 400 MB
#define	MEMORY_BANK_SIZE		100000 

#define	HOST_USERNAME			"Administrator"
#define	HOST_PASSWORD			"mmmmmm"


#define HOST_ADDRESS 			"169.254.121.1"
#define RT_ADDRESS 				"169.254.176.211"
//#define RT_ADDRESS 				"169.254.121.139"
#define HOST_PORT 				10001
#define TCP_INVALID_CONNECTION 	((unsigned int)-1)

#define	pi							3.141592653589793


#define SELFTEST_STATE				1
#define PULSE_STATE	    			2 
#define GNSS429_STATE	    		3 
#define PPS_STATE	    			4
#define	IMU_STATE					5
#define YC_STATE	    			6
#define FCGNSS422_STATE	    		7
#define FTP_STATE	    			8
#define AUTO_STATE	    			9
#define FC1553_STATE	    		10

// ************************* Power command
#define	AUTO_STATUS_IM_OFF			0
#define	AUTO_STATUS_IM_ON			1
#define	AUTO_STATUS_FC_OFF			2
#define	AUTO_STATUS_FC_ON			3
// ************************* Panel control 
#define	AUTO_PANEL_RESET			4 
// ************************** Fire control data type
#define	DATA_CONTENT_1R		001
#define	DATA_CONTENT_1T		101
#define	DATA_CONTENT_2R		002
#define	DATA_CONTENT_2T		102
#define	DATA_CONTENT_3R		003
#define	DATA_CONTENT_3T		103
#define	DATA_CONTENT_4R		004
#define	DATA_CONTENT_4T		104
#define	DATA_CONTENT_10R	010

// ************** Satellite parameter at each receiver channel
typedef struct _SVsInfo
{
	int nNo;
	double weiju;
	double weijulv;
	double X;
	double Y;
	double Z;
	double Vx;
	double Vy;
	double Vz;
	
	unsigned char SNR;
} SVsInfo;


// ************** Data struct from RT to HOST
typedef struct
{
	// Pulse parameters
    unsigned long laxp ;
	unsigned long laxn ; 
	unsigned long layp ; 
	unsigned long layn ; 
	unsigned long lazp ; 
	unsigned long lazn ; 
	
	unsigned long asxp ;
	unsigned long asxn ; 
	unsigned long asyp ; 
	unsigned long asyn ; 
	unsigned long aszp ; 
	unsigned long aszn ;
	
	unsigned long accumAxp;
	unsigned long accumAxn;
	unsigned long accumAyp;
	unsigned long accumAyn;
	unsigned long accumAzp;
	unsigned long accumAzn;
	
	unsigned long accumGxp;
	unsigned long accumGxn;
	unsigned long accumGyp;
	unsigned long accumGyn;
	unsigned long accumGzp;
	unsigned long accumGzn;
	
	double pulse_time;
	
	int flagPulseAccum;
	
	
	
	// GNSS parameters
	char sFixQuality[2]; // ��λ����
	int FixQuality;
	char FixMode[20]; // ��λģʽ
	
	double RcvTime; // ���ջ���ʱ��
	unsigned char SVs; // ������Ŀ
	double PDOP;
	
	double Lon;
	double Lat;
	double Alt;
	
	double X;
	double Y;
	double Z;
	
	double Vx;
	double Vy;
	double Vz;
	
	SVsInfo m_SVsInfo[10]; // ÿ��ͨ�����ǵĲ���
	
	int sRec_OK; // �Լ�OK

	double gps_time;
	double pps_time;
	double pps_time_cha; 
	unsigned long gps_firstdata;
	//unsigned long gpsdata[128];
	
	
	// YC LVDS to 422 parameters
	double timeYC;
	double timeIntervalYC;
	unsigned short dataYC[256];
	
	// 422 GNSS paramters
	//unsigned char gnss422Data[340];
	
	// Flight control data (16 bits)
	unsigned short dataFlightControl[30];
	unsigned char dataType[5];
	double timeFC1553;
	
	// Fire control data from data simulation computer
	double TraceTime;
	double CraftPosition[3];
	int CraftGPulseOut[3];
	int CraftFPulseOut[3];
	
	// IMU data
	double timeIMU;
	double wibb[3];
	double fb[3];
	
	// Others
	int selftest_status;
	int state;
	int statusAuto;

} DataMessage;





// ************** command for CommandMessage
#define RT_QUIT_COMMAND					1 
#define SELFTEST_COMMAND        		2

#define IM_START_COMMAND				3
#define IM_STOP_COMMAND					4
#define IM_GPSRECEIVE_COMMAND     		5  
#define IM_INSRECEIVE_COMMAND     		6 
#define IM_AUTOSTART_COMMAND			7

#define RECORD_IMU_DATA_COMMAND			8

#define FC_START_COMMAND				9
#define FC_STOP_COMMAND					10
#define FC_GPSRECEIVE_COMMAND      		11
#define FC_YCRECEIVE_COMMAND   	   		12
#define FC_FIRE_CONTROL_COMMAND   	   	13
#define FC_AUTOSTART_COMMAND			14

#define FTP_COMMAND						15

#define RT_QUIT_SUCCESS					16

// ************** Test mode for fire control
#define	MODE_FIRECONTROL_DYNAMIC		0
#define	MODE_FIRECONTROL_STATIC			1


// ************** Command sent from Host to RT
typedef struct
{
	int pulseCountTime; // �����������

	int statusPulse; // ���������ʼ/ֹͣ
	int statusGNSS429; // GNSS429��ʼ/ֹͣ
	
	int statusGNSS422FC; // �ɿ�ģʽGNSS422��ʼ/ֹͣ
	int statusYC; // ң�⿪ʼ/ֹͣ
	int statusFireControl; // ��ؿ�ʼ/ֹͣ
	int modeFireControl; //��ز���ģʽ (Dynamic / Static)
	
	int statusAutostartIM; // Inertial measuremet autostart
	int statusAutostartFC; // Flight control autostart
	
	int statusFileFTP; // File to send through FTP
	char hostUserName[30];
	char hostPassword[30];
	char hostFolderPath[100];
	
	int	command;
} CommandMessage;



// ************** File path on real-time target
#define FILE_PATH_RT_GNSS429 		"c:\\gnss429.txt" 
#define FILE_PATH_RT_PULSE 			"c:\\pulse.txt" // File path on real-time target
#define FILE_PATH_RT_RAM 			"c:\\ramdata.txt" // File path on real-time target  
#define FILE_PATH_RT_PPS 			"c:\\pps.txt" // File path on real-time target
#define FILE_PATH_RT_FCGNSS422 		"c:\\gnss422fc.txt"
#define FILE_PATH_RT_YC 			"c:\\yc.txt"
#define FILE_PATH_RT_FC1553 		"c:\\fc1553.txt"
#define FILE_PATH_RT_YC_DECODE 			"c:\\yc_decode.txt" 

// ************** File path on host
#define FILE_PATH_HOST_GNSS429 		"gnss429.txt" 
#define FILE_PATH_HOST_PULSE 		"pulse.txt" // File path on real-time target
#define FILE_PATH_HOST_RAM 			"ramdata.txt" // File path on real-time target  
#define FILE_PATH_HOST_PPS 			"pps.txt" // File path on real-time target 
#define FILE_PATH_HOST_GNSS429_RAW 	"gnss429_raw.txt" // File path on real-time target
#define FILE_PATH_HOST_IMU 			"imu.txt"
#define FILE_PATH_HOST_FCGNSS422 	"gnss422fc.txt"
#define FILE_PATH_HOST_YC 			"yc.txt"
#define FILE_PATH_HOST_FC1553 		"fc1553.txt"
#define FILE_PATH_HOST_YC_DECODE 			"yc_decode.txt"

// *************** File record type
#define	FILE_RECORD_START			0
#define	FILE_RECORD_ACTIVE			1
#define	FILE_RECORD_STOP			2
#define	FILE_RECORD_INACTIVE		3


#define SELFTEST_SUCCESS	    0 
#define SELFFAIL_429        	1 
#define SELFFAIL_422         	2  
#define SELFFAIL_GERFM        	3  
#define SELFFAIL_1553B        	4

#define MODE_IMU_MESURE			0
#define MODE_FLIGHT_CONTROL		1

#define MAX_PATHNAME_LEN  260    /* includes nul byte */
char IMUSimSetFilePath[MAX_PATHNAME_LEN];
char IMUTestSetFilePath[MAX_PATHNAME_LEN];
char FCTestSetFilePath[MAX_PATHNAME_LEN]; 
char GNSSTestSetFilePath[MAX_PATHNAME_LEN];

// ****************************  Global variables
unsigned int StatusTcpRT;
unsigned int StatusTcpHost;

DataMessage DataRT;
DataMessage DataHost;

CommandMessage CmdRT;
CommandMessage CmdHost;

int gLock;

int gThreadPool;

DataMessage *DataTemp; // Temporary data FIFO

IO_PARAM ParamIO; // IO�忨������������� 
int FlagFoundIO; // IO�忨���ֱ�־


// ****************************  Global functions
void Update (void);

double IntToDouble(unsigned short data, double max);

//CraftData����
double TraceTime;//��ǰ�켣ʱ��
double CraftPosition[3][1]; 
double CraftVelocity[3][1];
double CraftAcc[3][1];

double CraftAttitude[3][1]; 
double CraftAttitudeChangeRate[3][1];   		//�ػ����ٶ�

double CraftSFB[3][1];							//�ػ�����ϵ�µ��������
double CraftOmegaiBB[3][1];						//�ػ���Թ���ϵ���ٶ����ػ�����ϵ��ͶӰ
double CraftInsOmegaipp[3][1]; 					//����ƽ̨ϵ�����ٵĵ���ϵ����ת���ٶ�
double CraftInsSFs[3][1];  			//���ߵ������ߵ�����
double CraftInsOmegaiBBs[3][1]; 	//���ߵ������ߵ����ٶ�
int CraftFPulseOut[3][1];
int CraftGPulseOut[3][1]; 

int CraftNavFlag;		//���ߵ��������
int FcsNavFlag;			//��ص������
double CraftInsPosition[3][1];
double CraftInsVelocityP[3][1];	   	//���ߵ������ƽ̨�ٶȣ���INS�Ķ��ǽ����ߵ������Ľ����
double CraftInsAttitude[3][1];		//���ߵ���̬
double AttCha[3][1],CraftVelocityCha[3][1],CraftPositionCha[3][1];  

double FcsPos[3][1];			//���ϵͳλ��
double FcsQtn[4][1];			//���ϵͳ��Ԫ��
double FcsVel[3][1];			//���ϵͳ�ٶ�
double FcsAttitude[3][1];		//�����̬
double FcsGravity[3][1];		//�������
double CraftSNavGravity; 

//
double TraceTime_pulse; 		
double Time_pulse; 			  
                          
int GyroPulseNum_pulse[3][1];
int AccPulseNum_pulse[3][1]; 

                          
double GyroAngleRate_pulse[3][1] ;

double Acc_pulse[3][1]; 	//����
        
double Angle_pulse[3][1]; 	
 
int RFM_ReadOver_Flag;

int time111;
int time222;
int time333;

#endif


