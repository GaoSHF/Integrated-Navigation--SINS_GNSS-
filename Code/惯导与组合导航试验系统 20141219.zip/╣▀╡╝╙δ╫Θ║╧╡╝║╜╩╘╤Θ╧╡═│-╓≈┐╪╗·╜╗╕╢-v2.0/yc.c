//==============================================================================
//
// Title:       yc.c
// Purpose:     A short description of the implementation.
//
// Created on:  2014/1/21 at 15:31:32 by ZhaoHengyang.
// Copyright:   Beihang University. All Rights Reserved.
//
//==============================================================================

//==============================================================================
// Include files
#include <rtutil.h>
#include "asynctmr.h"
#include <ansi_c.h>
#include <utility.h>
#include <userint.h>

#include "RS422.h"
#include "yc.h"
#include "common.h"


//==============================================================================
// Constants

//==============================================================================
// Types

//==============================================================================
// Static global variables

//==============================================================================
// Static functions

//==============================================================================
// Global variables

int TimerIDYC;

FILE *FileHandleRTYC = NULL;

int FlagRecordYC = 0; // Enable record flag

long long CountInYC = 0;
long long CountOutYC = 0;

long long IndexInYC = 0;
long long IndexOutYC = 0;

RS422_DevHandle DeviceHandleYC;
RS422_DevHandle DeviceHandleGPS422;

int FlagFirstDataYC = 0;
double TimeFirstYC = 0;


//==============================================================================
// Global functions
int CVICALLBACK TimerYC(int reserved, int timerId, int event, void *callbackData, int eventData1, int eventData2);

//��ʼң�����
int ycStartReceive(void)
{
	DeviceHandleYC.bps = YC_SERIAL_BPS;
	DeviceHandleYC.comValue = COM3;
	DeviceHandleYC.check = NOPARITY;
	DeviceHandleYC.data = 8;
	DeviceHandleYC.stop = 1;
	RS422_Close(DeviceHandleYC); 
	if (!RS422_OpenConfig(DeviceHandleYC))
	{
		RS422_Close(DeviceHandleYC);
		return 1;
	}
//	InstallComCallback (DeviceHandleYC.comValue, LWRS_RECEIVE,256, 0, (void *)uartRevLVDS, 0);
	
//	TimerIDYC = NewAsyncTimer (0.001, -1, 0, TimerYC, 0);
	
	TimerIDYC = NewAsyncTimerWithPriority (0.003, -1, 0, TimerYC, 0, 9);
	
	SetAsyncTimerAttribute (TimerIDYC, ASYNC_ATTR_ENABLED, 1);
	
	//һ�ο��ܻ����ղ��������⣬������
	ComWrtByte (DeviceHandleYC.comValue, START256_COMMAND); 
	ComWrtByte (DeviceHandleYC.comValue, START256_COMMAND);
	
	// Enable data file record
	FlagRecordYC = FILE_RECORD_START;
	
	FlagFirstDataYC = 0;
	
	printf("YC 422: Open success!\n");
	return 0;
}

//ֹͣң�����
int ycStopReceive(void)
{
	//һ�ο��ܻ����ղ��������⣬������ 
	ComWrtByte (DeviceHandleYC.comValue, STOPSERIAL_COMMAND); 
	ComWrtByte (DeviceHandleYC.comValue, STOPSERIAL_COMMAND);

	SetAsyncTimerAttribute (TimerIDYC, ASYNC_ATTR_ENABLED, 0);
	DiscardAsyncTimer(TimerIDYC); 
	
//	SuspendAsyncTimerCallbacks ();
	
	RS422_Close(DeviceHandleYC);
		
	// Disable record
	FlagRecordYC = FILE_RECORD_STOP;
	
	printf("YC 422: Close success!\n");
	return 0;
}

//ң�ⶨʱ�� 1ms
int CVICALLBACK TimerYC(int reserved, int timerId, int event, void *callbackData, int eventData1, int eventData2)
{
	unsigned int i;
	unsigned int j;  
    static unsigned char rev_Data[4096] = {0};		//��ʱ���ݽ���
	unsigned int rev_StrLen = 0;//�������ݳ���
	unsigned int bytesread = 0;
	static unsigned long FrameCount = 0 ;
	
	static unsigned char read_flag = 0;
	
	unsigned long long yctime;
 	static	double preyctimeMS = 0;
	static	double intervalMS = 0;
	
	long long timeUS;
	double timeMS;
	
	unsigned short BmkData;

	if (event == EVENT_TIMER_TICK)
	{
		//��Ƹö�ʱ��������CPU2����
		SetProcessorAffinityForThread (kProcessorPool_None, 1, NULL, NULL); 
		
		rev_StrLen = GetInQLen (DeviceHandleYC.comValue);
		
		if(rev_StrLen >= YC_LENGTH_BYTE && !read_flag)
		{	
			CmtGetLock (gLock);
			read_flag = 1;
			for(i = 0; i < YC_LENGTH_BYTE; i++)
			{			
				//�����ֽڶ�  
				rev_Data[i] = ComRdByte(DeviceHandleYC.comValue);
			} 
			CmtReleaseLock (gLock);
		}
		else if(read_flag)
		{
			read_flag = 0;
			
			// Get time interval
			timeUS = GetTimeUS (); 
			timeMS = (double)timeUS / 1000;
			intervalMS = timeMS - preyctimeMS;
			if (FlagFirstDataYC == 0)
			{
				FlagFirstDataYC = 1;
				intervalMS = 12.0;
				TimeFirstYC = timeMS;
			}
			preyctimeMS = timeMS;
			(DataTemp + IndexInYC)->timeYC = RoundRealToNearestInteger (timeMS - TimeFirstYC) / 1000.0;
			(DataTemp + IndexInYC)->timeIntervalYC = intervalMS;
			
			for(i = 0; i < YC_LENGTH_BYTE; i = i + 2)
			{			
				BmkData = ((unsigned short)rev_Data[i] << 8) + rev_Data[i + 1];  
				(DataTemp + IndexInYC)->dataYC[i / 2] = BmkData;
			}
			  
			// FIFO check
			CountInYC ++;
			IndexInYC ++;
			if (IndexInYC >= MEMORY_BANK_SIZE)
				IndexInYC = 0;

		}

	}
	return 0;
}







