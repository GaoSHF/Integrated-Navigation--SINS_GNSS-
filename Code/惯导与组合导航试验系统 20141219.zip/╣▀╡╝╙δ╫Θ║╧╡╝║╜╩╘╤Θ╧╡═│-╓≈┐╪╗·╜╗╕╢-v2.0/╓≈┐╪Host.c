//==============================================================================
//
// Title:       ���ز���Host
// Purpose:     A short description of the application.
//
// Created on:  2013-7-7 at 14:32:26 by BUAA.
// Copyright:   buaa. All Rights Reserved.
//
//==============================================================================

//==============================================================================
// Include files

#include "asynctmr.h"
#include <cvintwrk.h>
#include <rs232.h>
#include <formatio.h>
#include <ansi_c.h> 
#include <cvinetv.h>
#include <cvirte.h> 
#include <userint.h>
#include <tcpsupp.h> 
#include <visa.h>
#include "toolbox.h" 

#include "����Host.h"
#include "���ع߲�Host.h"
#include "���طɿ�Host.h"
#include "WAIT_PANEL.h"
#include "ʵ����������Host.h"

#include "common.h"


//==============================================================================
// Constants

//==============================================================================
// Types


//==============================================================================
// Static global variables
static int PanelHandle;
static int PanelHandleIM;
static int PanelHandleFC;
static int PanelHandleWait; 
static int TimerHandleWait;
static int PanelHandleTestAnalysis;

double stateSimulationIMUSetFileSelectPopup;
double stateTestIMUSetFileSelectPopup;
double stateTestFCSetFileSelectPopup;
double stateTestGNSSSetFileSelectPopup;

FILE *CraftData_FileHandle;
FILE *pulse_FileHandle;


char FolderPath[260];

int StatusCheckBoxIM = 0;
int StatusCheckBoxFC = 0;
int StatusCheckBoxTR = 0;  

int StatusPower27V;
int StatusPower5V;

double TimeStartIMimugnss = 0;
double TimeStartIMpulse = 0;
double TimeStartFCfc = 0;
double TimeStartFClvds422 = 0;
int FlagIMimugnss = 0;
int FlagIMpulse = 0;
int FlagFCfc = 0;
int FlagFClvds422 = 0;

int waittimecounter = 0;

int testmodeflag = -1;
//==============================================================================
// Global variables
//���ڷ���ָ��̶� CRCУ����ֱ����Ϊ���ݷ��� 
unsigned char BufferPowerOn27[8]  ={0x02, 0x05, 0x00, 0x00, 0xFF, 0x00, 0x8C, 0x09};		 //����
unsigned char BufferPowerOff27[8] ={0x02, 0x05, 0x00, 0x00, 0x00, 0x00, 0xCD, 0xF9};         //�ϵ�
unsigned char BufferPowerTest27[8]={0x02, 0x03, 0x00, 0x00, 0x00, 0x02, 0xC4, 0x38}; 		 //�ض���ѹ����

unsigned char BufferPowerOn5V2[8]  ={0x02, 0x05, 0x00, 0x00, 0xFF, 0x00, 0x8C, 0x09};		 
unsigned char BufferPowerOff5V2[8] ={0x02, 0x05, 0x00, 0x00, 0x00, 0x00, 0xCD, 0xF9};       
unsigned char BufferPowerTest5V2[8]={0x02, 0x03, 0x00, 0x00, 0x00, 0x02, 0xC4, 0x38}; 

unsigned char BufferPowerOn5V3[8]  ={0x03, 0x05, 0x00, 0x00, 0xFF, 0x00, 0x8D, 0xD8};		 
unsigned char BufferPowerOff5V3[8] ={0x03, 0x05, 0x00, 0x00, 0x00, 0x00, 0xCC, 0x28};       
unsigned char BufferPowerTest5V3[8]={0x03, 0x03, 0x00, 0x00, 0x00, 0x02, 0xC5, 0xE9}; 

unsigned char BufferPowerOn5V4[8]  ={0x04, 0x05, 0x00, 0x00, 0xFF, 0x00, 0x8C, 0x6F};		 
unsigned char BufferPowerOff5V4[8] ={0x04, 0x05, 0x00, 0x00, 0x00, 0x00, 0xCD, 0x9F};       
unsigned char BufferPowerTest5V4[8]={0x04, 0x03, 0x00, 0x00, 0x00, 0x02, 0xC4, 0x5E}; 

unsigned char BufferPowerRead[9]={1};



// INS pulse count interval
int IMUSamplingInterval = 0;


// File handle
FILE 	*FileHandleHostGNSS429;
FILE 	*FileHandleHostPulse;
FILE 	*FileHandleHostGNSS429Raw;

FILE 	*FileHandleHostPPS;

FILE 	*FileHandleYC;
FILE 	*FileHandleGNSSFC422;

FILE	*FileHandleHostIMU;

//==============================================================================
// Static functions

/* Function prototypes */
int CVICALLBACK TCPDataCallback (unsigned handle, int xType, int errCode, void *callbackData);

void SelftestFinishCallback(void);
void SetPulseData(void); 
void SetGNSS429Data(void);

void SetPPSData(void);

void SetYCData(void);
void SetGNSSFC422Data(void);
void SetFC1553Data(void);

void CreateFolder(void);

void Powerinit(void);
void Powerclose(void);
int PowerOnIMimugnss(void);
int PowerOffIMimugnss(void);
int PowerOnIMpulse(void);
int PowerOffIMpulse(void);
int PowerOnFCfc(void);
int PowerOffFCfc(void);
int PowerOnFClvds422(void);
int PowerOffFClvds422(void);
int GetTraceDataFromDS_Computer(char Path_temp[260]); 


//main entry
int main (int argc, char *argv[])
{
    int error = 0;
	
	StatusTcpHost = TCP_INVALID_CONNECTION;
	
    /* initialize and load resources */
    nullChk (InitCVIRTE (0, argv, 0));
    errChk (PanelHandle = LoadPanel (0, "����Host.uir", PANEL));

	
	// Connect TCP at first
	ConnectToTCPServer (&StatusTcpHost, HOST_PORT, RT_ADDRESS, TCPDataCallback, 0, 1000);
	if (StatusTcpHost != TCP_INVALID_CONNECTION)
	{
		SetCtrlVal (PanelHandle, PANEL_STATUS, "����������ʵʱ����");
		SetCtrlVal (PanelHandle, PANEL_BUTTON_CONNECT, 1);
	}
	
	Powerinit();
	
	// Create new files
	/*FileHandleHostPulse = fopen (FILE_PATH_HOST_PULSE, "wb"); 
	FileHandleHostGNSS429 = fopen (FILE_PATH_HOST_GNSS429, "wb"); 
	FileHandleHostPPS = fopen (FILE_PATH_HOST_PPS, "wb");
	//FileHandleHostGNSS429Raw = fopen (FILE_PATH_HOST_GNSS429_RAW, "wb");
	//FileHandleHostIMU = fopen (FILE_PATH_HOST_IMU, "wb");
	
	FileHandleYC = fopen (FILE_PATH_HOST_YC, "wb");
	FileHandleGNSSFC422 = fopen (FILE_PATH_HOST_FCGNSS422, "wb");*/
	
	
    /* display the panel and run the user interface */
    errChk (DisplayPanel (PanelHandle));
    errChk (RunUserInterface ());
	
	Powerclose();


	if (StatusTcpHost != TCP_INVALID_CONNECTION)
		DisconnectFromTCPServer (StatusTcpHost);
	
	// Close files
	/*fclose (FileHandleHostPulse);
	fclose (FileHandleHostGNSS429);
	fclose (FileHandleHostPPS);
	//fclose (FileHandleHostGNSS429Raw);
	//fclose (FileHandleHostIMU);
	
	fclose (FileHandleYC);
	fclose (FileHandleGNSSFC422);*/
	
	
Error:
    /* clean up */
    DiscardPanel (PanelHandle);
    return 0;
}


//������Ӧʱ�����ڵ��ļ���
void CreateFolder(void)
{
	int month;
	int day;  
	int year;  
	int hours;
	int minutes;  
	int seconds;  
	char time[100];
	char dir[200];
	char g_dir[200];
	
	int f_exist;
	
	GetSystemDate (&month, &day, &year);
	GetSystemTime (&hours, &minutes, &seconds);
	sprintf(time,"%04d%02d%02d%02d%02d", year, month, day,hours,minutes);
	Fmt (dir, "%s<%100c", time); 
	f_exist = FileExists("C:\\test",0);
	
	if(f_exist == 0)              //ͬ���ļ��в�����
	{
		MakeDir("C:\\test"); 	  //�����ļ���
		SetDir("C:\\test"); 	  //���ø��ļ���Ϊ��ǰ�����ļ���
		MakeDir(dir);
		SetDir(dir);     
	}
	else		   
	{
		SetDir("C:\\test");       //�����²�ʱ�������ļ���
		Fmt (g_dir, "C:\\test\\");  
		strcat(g_dir,time);
		f_exist = FileExists(g_dir,0); 
		if(f_exist == 0)
		{
			MakeDir(dir);
			SetDir(dir);		
		}
	}
	// Get folder path for FTP operation
	strcpy(FolderPath, "test\\");
	strcat(FolderPath, time);
	strcat(FolderPath, "\\");
}


//��ԴCOM�ڳ�ʼ��
void Powerinit(void)
{
	OpenComConfig (3, "", 19200, 0, 8, 1, 512, 512);  //Com3����27����Դ
	OpenComConfig (4, "", 19200, 0, 8, 1, 512, 512);  //Com4����5����Դ
}


//�رյ�ԴCOM��
void Powerclose(void)
{
	CloseCom (3);
	CloseCom (4);
}


//TCP callback
int CVICALLBACK TCPDataCallback (unsigned handle, int xType, int errCode, 
	void *callbackData)
{
	switch (xType)
    {
        case TCP_CONNECT:
            // Accept only one client connection
            /*if (StatusTcpHost != TCP_INVALID_CONNECTION)
                DisconnectTCPClient (handle);
            else
                StatusTcpHost = handle;*/
			StatusTcpHost = handle;
			
            break;
        case TCP_DISCONNECT:
            StatusTcpHost = TCP_INVALID_CONNECTION;
			SetCtrlVal (PanelHandle, PANEL_STATUS, "�ѶϿ�����ʵʱ��!");
			SetCtrlVal (PanelHandle, PANEL_BUTTON_CONNECT, 0);
			
			SetCtrlAttribute (PanelHandle, PANEL_BUTTON_IM, ATTR_DIMMED, 1);
			SetCtrlAttribute (PanelHandle, PANEL_BUTTON_FC, ATTR_DIMMED, 1);   
			SetCtrlAttribute (PanelHandle, PANEL_BUTTON_Test_Analysis, ATTR_DIMMED, 1);   
			SetCtrlAttribute (PanelHandle, PANEL_BUTTON_SAVE_DATA, ATTR_DIMMED, 1);   
			SetCtrlAttribute (PanelHandle, PANEL_CHECKBOX_IM, ATTR_DIMMED, 1);   
			SetCtrlAttribute (PanelHandle, PANEL_CHECKBOX_FC, ATTR_DIMMED, 1);   
			SetCtrlAttribute (PanelHandle, PANEL_CHECKBOX_TRACE, ATTR_DIMMED, 1); 
			SetCtrlAttribute (PanelHandle, PANEL_RT_QuitButton, ATTR_DIMMED, 1);

            break;
        case TCP_DATAREADY:
			// ClientTCPRead does not guarantee that all DataHost will be transferred in
			// a single call, but this code assumes that it does for simplicity.
			ClientTCPRead (StatusTcpHost, &DataHost, sizeof(DataHost), 5000);  //��ȡTCP����״̬�ṹ�� ִ����Ӧ����
			
			// Selftest
			if (DataHost.state == SELFTEST_STATE)
				SelftestFinishCallback();
			
			// FTP files sending over
			else if (DataHost.state == FTP_STATE)
			{
				DiscardAsyncTimer (TimerHandleWait); 
				DiscardPanel (PanelHandleWait);
			}
			
			// Auto mode
			else if (DataHost.state == AUTO_STATE)
			{
				// Power off IM
				if (DataHost.statusAuto == AUTO_STATUS_IM_OFF)
				{
					if (FlagIMimugnss == 1)
					{
						SetCtrlVal (PanelHandleIM, PANEL_IM_POWERSWITCH, 0); 
						PowerOffIMimugnss();
					}
					if (FlagIMpulse == 1)
					{
						SetCtrlVal (PanelHandleIM, PANEL_IM_BOARDPOWERSWITCH, 0); 					
						PowerOffIMpulse();
					}
					SetCtrlAttribute (PanelHandleIM, PANEL_IM_QUITBUTTON, ATTR_DIMMED, 1);
				}
				// Power on IM
				else if (DataHost.statusAuto == AUTO_STATUS_IM_ON)
				{
					if (FlagIMimugnss == 0)
					{
						SetCtrlVal (PanelHandleIM, PANEL_IM_POWERSWITCH, 1);						
						PowerOnIMimugnss();
					}
					if (FlagIMpulse == 0)
					{
						SetCtrlVal (PanelHandleIM, PANEL_IM_BOARDPOWERSWITCH, 1);						
						PowerOnIMpulse();
					}
				}
				// Power off FC
				else if (DataHost.statusAuto == AUTO_STATUS_FC_OFF)
				{
					if (FlagFCfc == 1)
					{
						PowerOffFCfc();
						SetCtrlVal (PanelHandleFC, PANEL_FC_POWERSWITCH, 0);
					}
					if (FlagFClvds422 == 1)
					{
						PowerOffFClvds422();
						SetCtrlVal (PanelHandleFC, PANEL_FC_BOARDPOWERSWITCH, 0);
					}
					SetCtrlAttribute (PanelHandleFC, PANEL_FC_QUITBUTTON, ATTR_DIMMED, 1);
				}
				// Power on FC
				else if (DataHost.statusAuto == AUTO_STATUS_FC_ON)
				{
					if (FlagFCfc == 0)
					{
						PowerOnFCfc();
						SetCtrlVal (PanelHandleFC, PANEL_FC_POWERSWITCH, 1);	
					}
					if (FlagFClvds422 == 0)
					{
						PowerOnFClvds422();
						SetCtrlVal (PanelHandleFC, PANEL_FC_BOARDPOWERSWITCH, 1);	
					}
				}
				else if (DataHost.statusAuto == AUTO_PANEL_RESET)
				{
					if(testmodeflag == MODE_IMU_MESURE)
					{
					  	CmdHost.statusAutostartIM = 0; 
						SetCtrlVal (PanelHandleIM, PANEL_IM_LED3, 0);
					
						SetCtrlVal (PanelHandleIM, PANEL_IM_MODULESWITCH, 0); 
						SetCtrlAttribute (PanelHandleIM, PANEL_IM_GPSBUTTON, ATTR_DIMMED, 0);
						SetCtrlAttribute (PanelHandleIM, PANEL_IM_INSBUTTON, ATTR_DIMMED, 0);
						SetCtrlAttribute (PanelHandleIM, PANEL_IM_STARTBUTTON, ATTR_DIMMED, 0);	   
						SetCtrlAttribute (PanelHandleIM, PANEL_IM_STOPBUTTON, ATTR_DIMMED, 0);
						SetCtrlAttribute (PanelHandleIM, PANEL_IM_SELFTESTBUTTON, ATTR_DIMMED, 0);
						SetCtrlAttribute (PanelHandleIM, PANEL_IM_QUITBUTTON, ATTR_DIMMED, 0);
						SetCtrlAttribute (PanelHandleIM, PANEL_IM_POWERSWITCH, ATTR_DIMMED, 0);
						SetCtrlAttribute (PanelHandleIM, PANEL_IM_BOARDPOWERSWITCH, ATTR_DIMMED, 0);
					}	
					else if(testmodeflag == MODE_FLIGHT_CONTROL)
					{
						CmdHost.statusAutostartFC = 0;
						SetCtrlVal (PanelHandleFC, PANEL_FC_LED3, 0);  
					
						SetCtrlVal (PanelHandleFC, PANEL_FC_MODULESWITCH, 0);
						SetCtrlAttribute (PanelHandleFC, PANEL_FC_GPSBUTTON, ATTR_DIMMED, 0);
						SetCtrlAttribute (PanelHandleFC, PANEL_FC_T1553BUTTON, ATTR_DIMMED, 0);
						SetCtrlAttribute (PanelHandleFC, PANEL_FC_YCBUTTON, ATTR_DIMMED, 0);
						SetCtrlAttribute (PanelHandleFC, PANEL_FC_STARTBUTTON, ATTR_DIMMED, 0);	   
						SetCtrlAttribute (PanelHandleFC, PANEL_FC_STOPBUTTON, ATTR_DIMMED, 0);
						SetCtrlAttribute (PanelHandleFC, PANEL_FC_QUITBUTTON, ATTR_DIMMED, 0);
						SetCtrlAttribute (PanelHandleFC, PANEL_FC_SELFTESTBUTTON, ATTR_DIMMED, 0);
						SetCtrlAttribute (PanelHandleFC, PANEL_FC_POWERSWITCH, ATTR_DIMMED, 0);
						SetCtrlAttribute (PanelHandleFC, PANEL_FC_BOARDPOWERSWITCH, ATTR_DIMMED, 0);					
					}
				}
			}
			
			// IM mode
			else if (DataHost.state == PULSE_STATE)
				SetPulseData(); 
			else if (DataHost.state == GNSS429_STATE)
				SetGNSS429Data(); 
			else if (DataHost.state == PPS_STATE)
				SetPPSData();
			
			// FC mode
			else if (DataHost.state == YC_STATE)
				SetYCData();
			else if (DataHost.state == FCGNSS422_STATE)
				SetGNSSFC422Data();
			else if (DataHost.state == FC1553_STATE)
				SetFC1553Data();
			
			
			else if (DataHost.state == IMU_STATE)
			{
				// Record IMU data received at RFM
				/*fprintf(FileHandleHostIMU, "%f\t", DataHost.timeIMU);
				fprintf(FileHandleHostIMU, "%f\t", DataHost.wibb[0]);
				fprintf(FileHandleHostIMU, "%f\t", DataHost.wibb[1]);
				fprintf(FileHandleHostIMU, "%f\t", DataHost.wibb[2]);
				fprintf(FileHandleHostIMU, "%f\t", DataHost.fb[0]);
				fprintf(FileHandleHostIMU, "%f\t", DataHost.fb[1]);
				fprintf(FileHandleHostIMU, "%f\r\n", DataHost.fb[2]);*/
			}
            break;
    }
    
    return 0;
}



//Selftest
void SelftestFinishCallback(void)
{
    int selftest; 
	selftest = DataHost.selftest_status;
	SetCtrlAttribute (PanelHandleIM, PANEL_IM_SELFTESTBUTTON, ATTR_LABEL_TEXT, "ϵͳ�Լ�"); 
	if(selftest == SELFTEST_SUCCESS)
	{
		MessagePopup ("", "�Լ�ɹ���"); 
	}
	else if(selftest == SELFFAIL_GERFM)
	{
		MessagePopup ("ERROR", "�����ڴ濨�Լ�ʧ�ܣ�");
	}
	else if(selftest == SELFFAIL_429)
	{
		MessagePopup ("ERROR", "429���Լ�ʧ�ܣ�");
	}
	else if(selftest == SELFFAIL_422)
	{
		MessagePopup ("ERROR", "422���Լ�ʧ�ܣ�");
	}
/*	else if(selftest == SELFFAIL_1553B)
	{
		MessagePopup ("ERROR", "1553B���Լ�ʧ�ܣ�");
	}	 */
}


/*******************************   ����Host Panel Callback ****************************/


//Connect target TCP callback
int CVICALLBACK buttonConnect (int panel, int control, int event,
	void *callbackData, int eventData1, int eventData2)
{
	int StateButton = 0;
	
	switch (event)
	{
		case EVENT_COMMIT:
			 
			GetCtrlVal (PanelHandle, PANEL_BUTTON_CONNECT, &StateButton);
			
			if ((StateButton == 0) && (StatusTcpHost != TCP_INVALID_CONNECTION))
			{
				DisconnectFromTCPServer (StatusTcpHost);
				StatusTcpHost = TCP_INVALID_CONNECTION;
				SetCtrlVal (PanelHandle, PANEL_STATUS, "�ѶϿ�����ʵʱ����");
			}
			else if ((StateButton == 1) && (StatusTcpHost == TCP_INVALID_CONNECTION))
			{
				ConnectToTCPServer (&StatusTcpHost, HOST_PORT, RT_ADDRESS, TCPDataCallback, 0, 5000);
				if (StatusTcpHost != TCP_INVALID_CONNECTION)
				{
					SetCtrlVal (PanelHandle, PANEL_STATUS, "����������ʵʱ����");
				}
			}
			
			break;
	}
	return 0;
}


//Start inertial measurement callback
int CVICALLBACK buttonIM (int panel, int control, int event,
	void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:
			testmodeflag = MODE_IMU_MESURE; 
			// Install sub panel
			PanelHandleIM = LoadPanel (PanelHandleIM, "���ع߲�Host.uir", PANEL_IM);
			// Wait until quit the sub panel
			//InstallPopup (PanelHandleIM);
			SetPanelAttribute (PanelHandleIM, ATTR_WINDOW_ZOOM, VAL_MAXIMIZE);
			DisplayPanel(PanelHandleIM);			
			break;
	}
	return 0;
}


//Start flight control callback
int CVICALLBACK buttonFC (int panel, int control, int event,
	void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:
			testmodeflag = MODE_FLIGHT_CONTROL; 
			// Install sub panel
			PanelHandleFC = LoadPanel (PanelHandleFC, "���طɿ�Host.uir", PANEL_FC);
			// Wait until quit the sub panel
			//InstallPopup (PanelHandleFC);
			SetPanelAttribute (PanelHandleFC, ATTR_WINDOW_ZOOM, VAL_MAXIMIZE);
			DisplayPanel(PanelHandleFC);

			break;
	}
	return 0;
}


//Save measurement data from RT control callback
int CVICALLBACK buttonSaveData (int panel, int control, int event,
	void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:
		//	if (StatusTcpHost != TCP_INVALID_CONNECTION)
		//	{
				GetCtrlVal (PanelHandle, PANEL_CHECKBOX_IM, &StatusCheckBoxIM);
				GetCtrlVal (PanelHandle, PANEL_CHECKBOX_FC, &StatusCheckBoxFC);
				GetCtrlVal (PanelHandle, PANEL_CHECKBOX_TRACE, &StatusCheckBoxTR); 
				
				// Create folder
				CreateFolder();				
				//Wait panel refresh asyncTimer
				TimerHandleWait = NewAsyncTimer (0.3, -1, 1, WaitingTimeCallback, 0);
				//Load wait panel
				PanelHandleWait = LoadPanel (0, "WAIT_PANEL.uir", WAIT_PANEL);
				InstallPopup (PanelHandleWait);
				
				if(StatusCheckBoxTR != 0)
				{
					//Retrieve trace data file from data simulation computer
					GetTraceDataFromDS_Computer(FolderPath);

					if((StatusCheckBoxFC || StatusCheckBoxIM) == 0)
					{
						DiscardAsyncTimer (TimerHandleWait); 
						DiscardPanel (PanelHandleWait);						
					}
				}				
				if ((StatusCheckBoxIM != 0) || (StatusCheckBoxFC != 0))
				{
					// Send command
				    if ((StatusCheckBoxIM != 0) && (StatusCheckBoxFC != 0))
						CmdHost.statusFileFTP = 2;					
					else if (StatusCheckBoxIM != 0)
						CmdHost.statusFileFTP = 0;
					else if (StatusCheckBoxFC != 0)
						CmdHost.statusFileFTP = 1;
					
					strcpy(CmdHost.hostUserName, HOST_USERNAME);
					strcpy(CmdHost.hostPassword, HOST_PASSWORD);
					strcpy(CmdHost.hostFolderPath, FolderPath);
					CmdHost.command = FTP_COMMAND; 
					ClientTCPWrite (StatusTcpHost, &CmdHost, sizeof(CmdHost), 3000);
				}
		//	} 
			break;
	}
	return 0;
}


//Quit UI callback
int CVICALLBACK buttonHostQuit (int panel, int control, int event,
	void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:
				QuitUserInterface(0);  
			break;
	}
	return 0;
}

//Quit RT callback 
int CVICALLBACK RT_Quit (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:
			
			if (StatusTcpHost != TCP_INVALID_CONNECTION)
			{
				CmdHost.command = RT_QUIT_COMMAND; 
				ClientTCPWrite (StatusTcpHost, &CmdHost, sizeof(CmdHost), 1000);
				
				QuitUserInterface(0);  
			}
			break;
	}
	return 0;
}


//���������Ͻǹرջص�����
int CVICALLBACK panelCallBack (int panel, int event, void *callbackData,   //���ص�����
        int eventData1, int eventData2)
{
    if (event == EVENT_CLOSE)
	{
        QuitUserInterface (0);
	}
    return 0;
}




/******************************* ���ع߲�Host Panel Callback ****************************/

//Start inertial measurement all function
int CVICALLBACK buttonStartIM (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:
			// Get pulse count interval
			GetCtrlVal(PanelHandleIM, PANEL_IM_COUNTERTIME, &IMUSamplingInterval);  
			CmdHost.pulseCountTime = IMUSamplingInterval;
			
			CmdHost.command = IM_START_COMMAND;
			
			ClientTCPWrite (StatusTcpHost, &CmdHost, sizeof(CmdHost), 5000);
			break;
	}
	return 0;
}

//stop inertial measurement all function
int CVICALLBACK buttonStopIM (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:
			CmdHost.command = IM_STOP_COMMAND; 
			ClientTCPWrite (StatusTcpHost, &CmdHost, sizeof(CmdHost), 5000); 
			break;
	}
	return 0;
}

//Quit inertial measurement callback
int CVICALLBACK buttonQuitIM (int panel, int control, int event,
	void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:
			
			// Quit sub panel
		//	RemovePopup(PanelHandleIM);
			DiscardPanel (PanelHandleIM);
			PanelHandleIM = 0;
			break;
	}
	return 0;
}

//Selftest
int CVICALLBACK buttonSelftestIM (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:
			CmdHost.command = SELFTEST_COMMAND;
			ClientTCPWrite (StatusTcpHost, &CmdHost, sizeof(CmdHost), 5000);  
			//MessagePopup ("", "ϵͳ�Լ���,���Ժ�...");
			SetCtrlAttribute (PanelHandleIM, PANEL_IM_SELFTESTBUTTON, ATTR_LABEL_TEXT, "�Լ���...");
			break;
	}
	return 0;
}

//gnss429 receive
int CVICALLBACK buttonGNSS429 (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{

	int flagTest;
	switch (event)
	{
		case EVENT_COMMIT:
			GetCtrlVal(PanelHandleIM,PANEL_IM_GPSBUTTON,&flagTest);
			CmdHost.command = IM_GPSRECEIVE_COMMAND;

			CmdHost.statusGNSS429 = flagTest;
			ClientTCPWrite (StatusTcpHost, &CmdHost, sizeof(CmdHost), 5000);
			
			break;
	}
	return 0;
}

//pulse receive
int CVICALLBACK buttonPulse (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{

	int flagTest;
	switch (event)
	{
		case EVENT_COMMIT:
			GetCtrlVal(PanelHandleIM,PANEL_IM_INSBUTTON,&flagTest);
			CmdHost.statusPulse = flagTest;
			
			CmdHost.command = IM_INSRECEIVE_COMMAND;
			
			// Get pulse count interval
			GetCtrlVal(PanelHandleIM, PANEL_IM_COUNTERTIME, &IMUSamplingInterval);  
			CmdHost.pulseCountTime = IMUSamplingInterval;
			
			ClientTCPWrite (StatusTcpHost, &CmdHost, sizeof(CmdHost), 5000);
			break;
	}
	return 0;
}

//Power on IMU/GNSS (IM)
int PowerOnIMimugnss()
{
	ComWrt (3, BufferPowerOn27, 8);
  	Delay(0.05);
  	ComWrt (4, BufferPowerOn5V4, 8); 
  	Delay(0.05);
	ComWrt (4, BufferPowerOn5V4, 8); 
  	Delay(0.05);
  	SetCtrlVal (PanelHandleIM, PANEL_IM_LED1, 1);
	
	// Disable quit button
	SetCtrlAttribute (PanelHandleIM, PANEL_IM_QUITBUTTON, ATTR_DIMMED, 1);
	
	// Set time flag
	FlagIMimugnss = 1;
	TimeStartIMimugnss = clock() / CLOCKS_PER_SEC;
	SetCtrlVal (PanelHandleIM, PANEL_IM_TIME_IMU_GNSS, 0.0);
	return 0;
}

//Power off IMU/GNSS (IM)
int PowerOffIMimugnss()
{
	ComWrt (3, BufferPowerOff27, 8);
	Delay(0.05);
  	ComWrt (4, BufferPowerOff5V4, 8);
	Delay(0.05);
	ComWrt (4, BufferPowerOff5V4, 8);
	Delay(0.05);
  	SetCtrlVal (PanelHandleIM, PANEL_IM_LED1, 0);
	
	// Enable quit button
	if ((StatusPower27V == 0) && (StatusPower5V == 0))
		SetCtrlAttribute (PanelHandleIM, PANEL_IM_QUITBUTTON, ATTR_DIMMED, 0);
	
	// Clear time flag
	FlagIMimugnss = 0;
	return 0;
}

//Power on pulse counting board (IM)
int PowerOnIMpulse()
{
	ComWrt (4, BufferPowerOn5V2, 8);	
	Delay(0.05);
	ComWrt (4, BufferPowerOn5V2, 8);	
	Delay(0.05);
  	ComWrt (4, BufferPowerOn5V3, 8);
  	Delay(0.05);
	ComWrt (4, BufferPowerOn5V3, 8);
  	Delay(0.05);
  	SetCtrlVal (PanelHandleIM, PANEL_IM_LED2, 1);
	
	// Disable quit button
	SetCtrlAttribute (PanelHandleIM, PANEL_IM_QUITBUTTON, ATTR_DIMMED, 1);
	
	// Set time flag
	FlagIMpulse = 1;
	TimeStartIMpulse = clock() / CLOCKS_PER_SEC;
	SetCtrlVal (PanelHandleIM, PANEL_IM_TIME_PULSE, 0.0);
	return 0;
}

//Power off pulse counting board (IM)
int PowerOffIMpulse()
{
	ComWrt (4, BufferPowerOff5V2, 8);	
  	Delay(0.05);
	ComWrt (4, BufferPowerOff5V2, 8);	
  	Delay(0.05);
  	ComWrt (4, BufferPowerOff5V3, 8);
  	Delay(0.05);
	ComWrt (4, BufferPowerOff5V3, 8);
  	Delay(0.05);
  	SetCtrlVal (PanelHandleIM, PANEL_IM_LED2, 0);
	
	// Enable quit button
	if ((StatusPower27V == 0) && (StatusPower5V == 0))
		SetCtrlAttribute (PanelHandleIM, PANEL_IM_QUITBUTTON, ATTR_DIMMED, 0);
	
	// Clear time flag
	FlagIMpulse = 0;
	return 0;
}

//Turn on/off GNSS and IMU power (Inertial measurement)
int CVICALLBACK PowerSwitchIM27V (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:
			GetCtrlVal (PanelHandleIM, PANEL_IM_POWERSWITCH, &StatusPower27V);
			GetCtrlVal (PanelHandleIM, PANEL_IM_BOARDPOWERSWITCH, &StatusPower5V);
			switch(StatusPower27V)
			{
				case 1:											 
					PowerOnIMimugnss();
					break;
			    case 0:
				  	PowerOffIMimugnss();
					break;
			}
			break;
	}
	return 0;
}

//Turn on/off pulse receiver power (Inertial measurement)
int CVICALLBACK PowerSwitchIM5V (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:
			GetCtrlVal (PanelHandleIM, PANEL_IM_POWERSWITCH, &StatusPower27V);
			GetCtrlVal (PanelHandleIM, PANEL_IM_BOARDPOWERSWITCH, &StatusPower5V);
			switch(StatusPower5V)
			{
				case 1:
					PowerOnIMpulse();
			    	break;
				
			    case 0:
				  	PowerOffIMpulse();
					break;
			}
			break;
	}
	return 0;
}

//��ʾ������PPS����
void SetPPSData(void)
{
	SetCtrlVal (PanelHandleIM, PANEL_IM_PPSTIME, DataHost.pps_time_cha);
	//fprintf (FileHandleHostPPS, "%f ", DataHost.pps_time);  
	//fprintf (FileHandleHostPPS, "\r\n");	
}

//��Դ��ض�ʱ����(�߲�)
int CVICALLBACK timerIM (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	float V_INS,V_GPS,I_INS,I_GPS; 
	float V_Pulse1, V_Pulse2, I_Pulse1, I_Pulse2;
	switch (event)
	{
		case EVENT_TIMER_TICK:
			// IMU 27 
		    FlushInQ (3); 
			ComWrt (3, BufferPowerTest27, 8);
			ComRd (3, BufferPowerRead, 9);
			V_INS = (BufferPowerRead[3]*16*16+BufferPowerRead[4])/1000.00;
			I_INS = (BufferPowerRead[5]*16*16+BufferPowerRead[6])/1000.00;	
			SetCtrlVal (PanelHandleIM, PANEL_IM_V_INS, V_INS);
			SetCtrlVal (PanelHandleIM, PANEL_IM_I_INS, I_INS);
		 
			// GNSS receiver 5V
			Delay(0.05);
			FlushInQ (4);
			ComWrt (4, BufferPowerTest5V4, 8);
			ComRd (4, BufferPowerRead, 9);
			V_GPS = (BufferPowerRead[3]*16*16+BufferPowerRead[4])/1000.00;
			I_GPS = (BufferPowerRead[5]*16*16+BufferPowerRead[6])/1000.00;	
			SetCtrlVal (PanelHandleIM, PANEL_IM_V_GPS, V_GPS);
			SetCtrlVal (PanelHandleIM, PANEL_IM_I_GPS, I_GPS);
			
			// Pulse counting board 5V
			Delay(0.05);
			FlushInQ (4);
			ComWrt (4, BufferPowerTest5V2, 8);
			ComRd (4, BufferPowerRead, 9);
			V_Pulse1 = (BufferPowerRead[3]*16*16+BufferPowerRead[4])/1000.00;
			I_Pulse1 = (BufferPowerRead[5]*16*16+BufferPowerRead[6])/1000.00;	
			SetCtrlVal (PanelHandleIM, PANEL_IM_V_PULSE1, V_Pulse1);
			SetCtrlVal (PanelHandleIM, PANEL_IM_I_PULSE1, I_Pulse1);
			
			// Pulse counting board 5V
			Delay(0.05);
			FlushInQ (4);
			ComWrt (4, BufferPowerTest5V3, 8);
			ComRd (4, BufferPowerRead, 9);
			V_Pulse2 = (BufferPowerRead[3]*16*16+BufferPowerRead[4])/1000.00;
			I_Pulse2 = (BufferPowerRead[5]*16*16+BufferPowerRead[6])/1000.00;	
			SetCtrlVal (PanelHandleIM, PANEL_IM_V_PULSE2, V_Pulse2);
			SetCtrlVal (PanelHandleIM, PANEL_IM_I_PULSE2, I_Pulse2);
 
			// Power on time
			if (FlagIMimugnss == 1)
			{
				SetCtrlVal (PanelHandleIM, PANEL_IM_TIME_IMU_GNSS, clock() / CLOCKS_PER_SEC - TimeStartIMimugnss);
			}
			if (FlagIMpulse == 1)
			{
				SetCtrlVal (PanelHandleIM, PANEL_IM_TIME_PULSE, clock() / CLOCKS_PER_SEC - TimeStartIMpulse);
			}
			
			break;
	}
	return 0;
}

//�Զ��ֶ�ģʽ���ػص�����
int CVICALLBACK switchModeIM (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:
			int Module_State;
			GetCtrlVal (PanelHandleIM, PANEL_IM_MODULESWITCH, &Module_State);
			switch(Module_State)
			{
				case 1:											 
				  	CmdHost.command = IM_AUTOSTART_COMMAND;
					CmdHost.statusAutostartIM = 1;
				  	ClientTCPWrite (StatusTcpHost, &CmdHost, sizeof(CmdHost), 5000);
				  	SetCtrlVal (PanelHandleIM, PANEL_IM_LED3, 1);
					
					SetCtrlAttribute (PanelHandleIM, PANEL_IM_GPSBUTTON, ATTR_DIMMED, 1);
					SetCtrlAttribute (PanelHandleIM, PANEL_IM_INSBUTTON, ATTR_DIMMED, 1);
					SetCtrlAttribute (PanelHandleIM, PANEL_IM_STARTBUTTON, ATTR_DIMMED, 1);	   
					SetCtrlAttribute (PanelHandleIM, PANEL_IM_STOPBUTTON, ATTR_DIMMED, 1);
					SetCtrlAttribute (PanelHandleIM, PANEL_IM_SELFTESTBUTTON, ATTR_DIMMED, 1);
					SetCtrlAttribute (PanelHandleIM, PANEL_IM_QUITBUTTON, ATTR_DIMMED, 1);
					SetCtrlAttribute (PanelHandleIM, PANEL_IM_POWERSWITCH, ATTR_DIMMED, 1);
					SetCtrlAttribute (PanelHandleIM, PANEL_IM_BOARDPOWERSWITCH, ATTR_DIMMED, 1);
					break;
			    case 0:
					CmdHost.command = IM_AUTOSTART_COMMAND;
					CmdHost.statusAutostartIM = 0;
				  	ClientTCPWrite (StatusTcpHost, &CmdHost, sizeof(CmdHost), 5000);
				  	SetCtrlVal (PanelHandleIM, PANEL_IM_LED3, 0);
					
					SetCtrlAttribute (PanelHandleIM, PANEL_IM_GPSBUTTON, ATTR_DIMMED, 0);
					SetCtrlAttribute (PanelHandleIM, PANEL_IM_INSBUTTON, ATTR_DIMMED, 0);
					SetCtrlAttribute (PanelHandleIM, PANEL_IM_STARTBUTTON, ATTR_DIMMED, 0);	   
					SetCtrlAttribute (PanelHandleIM, PANEL_IM_STOPBUTTON, ATTR_DIMMED, 0);
					SetCtrlAttribute (PanelHandleIM, PANEL_IM_SELFTESTBUTTON, ATTR_DIMMED, 0);
					SetCtrlAttribute (PanelHandleIM, PANEL_IM_QUITBUTTON, ATTR_DIMMED, 0);
					SetCtrlAttribute (PanelHandleIM, PANEL_IM_POWERSWITCH, ATTR_DIMMED, 0);
					SetCtrlAttribute (PanelHandleIM, PANEL_IM_BOARDPOWERSWITCH, ATTR_DIMMED, 0);
					break;
			}
			break;
	}
	return 0;
}

//��ʾ������IMU����
void SetPulseData(void)
{
	SetCtrlVal (PanelHandleIM, PANEL_IM_ASXP, DataHost.accumGxp);
	SetCtrlVal (PanelHandleIM, PANEL_IM_ASXN, DataHost.accumGxn);
	SetCtrlVal (PanelHandleIM, PANEL_IM_ASYP, DataHost.accumGyp);
	SetCtrlVal (PanelHandleIM, PANEL_IM_ASYN, DataHost.accumGyn);
	SetCtrlVal (PanelHandleIM, PANEL_IM_ASZP, DataHost.accumGzp);
	SetCtrlVal (PanelHandleIM, PANEL_IM_ASZN, DataHost.accumGzn);
	
	SetCtrlVal (PanelHandleIM, PANEL_IM_LAXP, DataHost.accumAxp);
	SetCtrlVal (PanelHandleIM, PANEL_IM_LAXN, DataHost.accumAxn);
	SetCtrlVal (PanelHandleIM, PANEL_IM_LAYP, DataHost.accumAyp);
	SetCtrlVal (PanelHandleIM, PANEL_IM_LAYN, DataHost.accumAyn);
	SetCtrlVal (PanelHandleIM, PANEL_IM_LAZP, DataHost.accumAzp);
	SetCtrlVal (PanelHandleIM, PANEL_IM_LAZN, DataHost.accumAzn);
	SetCtrlVal (PanelHandleIM, PANEL_IM_PULSETIME, DataHost.pulse_time);
	
	/*fprintf(FileHandleHostPulse,"%f\t", DataHost.pulse_time);   
	fprintf(FileHandleHostPulse,"%d\t", DataHost.asxp);  
	fprintf(FileHandleHostPulse,"%d\t", DataHost.asxn); 
	fprintf(FileHandleHostPulse,"%d\t", DataHost.asyp); 
	fprintf(FileHandleHostPulse,"%d\t", DataHost.asyn); 
	fprintf(FileHandleHostPulse,"%d\t", DataHost.aszp); 
	fprintf(FileHandleHostPulse,"%d\t", DataHost.aszn);

	fprintf(FileHandleHostPulse,"%d\t", DataHost.laxp);  
	fprintf(FileHandleHostPulse,"%d\t", DataHost.laxn); 
	fprintf(FileHandleHostPulse,"%d\t", DataHost.layp); 
	fprintf(FileHandleHostPulse,"%d\t", DataHost.layn); 
	fprintf(FileHandleHostPulse,"%d\t", DataHost.lazp); 
	fprintf(FileHandleHostPulse,"%d\t", DataHost.lazn); 
	fprintf(FileHandleHostPulse, "\r\n");*/ 
	
}

//��ʾ������GPS����
void SetGNSS429Data(void)
{
	int i;
	
	int FixQuality = 0;
	
	
	SetCtrlVal (PanelHandleIM, PANEL_IM_GPSTIME, DataHost.gps_time);
	SetCtrlVal (PanelHandleIM, PANEL_IM_GPSFIRSTDATA, DataHost.gps_firstdata);
	SetCtrlVal (PanelHandleIM, PANEL_IM_RCVTIME, DataHost.RcvTime);
	
	SetCtrlVal (PanelHandleIM, PANEL_IM_LON, DataHost.Lon);
	SetCtrlVal (PanelHandleIM, PANEL_IM_LAT, DataHost.Lat); 
	SetCtrlVal (PanelHandleIM, PANEL_IM_ALT, DataHost.Alt);
	
	SetCtrlVal (PanelHandleIM, PANEL_IM_PDOP, DataHost.PDOP);
	
	SetCtrlVal (PanelHandleIM, PANEL_IM_POSITION_X, DataHost.X);
	SetCtrlVal (PanelHandleIM, PANEL_IM_POSITION_Y, DataHost.Y);
	SetCtrlVal (PanelHandleIM, PANEL_IM_POSITION_Z, DataHost.Z);
	
	SetCtrlVal (PanelHandleIM, PANEL_IM_VELOCITY_X, DataHost.Vx);
	SetCtrlVal (PanelHandleIM, PANEL_IM_VELOCITY_Y, DataHost.Vy);
	SetCtrlVal (PanelHandleIM, PANEL_IM_VELOCITY_Z, DataHost.Vz);
	
	SetCtrlVal (PanelHandleIM, PANEL_IM_SVS, DataHost.SVs);
	
	// ��λģʽ��ʾ 
	SetCtrlAttribute (PanelHandleIM, PANEL_IM_FIX_MODE, ATTR_CTRL_VAL, DataHost.FixMode);
	
	// ��λ������ʾ
	if ((DataHost.sFixQuality[0] == '0') && (DataHost.sFixQuality[1] == '0'))
	{
		SetCtrlVal (PanelHandleIM, PANEL_IM_FIX_QUALITY1, 0);
		SetCtrlVal (PanelHandleIM, PANEL_IM_FIX_QUALITY2, 0);
		SetCtrlVal (PanelHandleIM, PANEL_IM_FIX_QUALITY3, 0);
		FixQuality = 0;
	}
	else if ((DataHost.sFixQuality[0] == '0') && (DataHost.sFixQuality[1] == '1'))
	{
		SetCtrlVal (PanelHandleIM, PANEL_IM_FIX_QUALITY1, 0);
		SetCtrlVal (PanelHandleIM, PANEL_IM_FIX_QUALITY2, 0);
		SetCtrlVal (PanelHandleIM, PANEL_IM_FIX_QUALITY3, 1);
		FixQuality = 1;
	}
	else if ((DataHost.sFixQuality[0] == '1') && (DataHost.sFixQuality[1] == '0'))
	{
		SetCtrlVal (PanelHandleIM, PANEL_IM_FIX_QUALITY1, 0);
		SetCtrlVal (PanelHandleIM, PANEL_IM_FIX_QUALITY2, 1);
		SetCtrlVal (PanelHandleIM, PANEL_IM_FIX_QUALITY3, 1);
		FixQuality = 2;
	}
	else if ((DataHost.sFixQuality[0] == '1') && (DataHost.sFixQuality[1] == '1'))
	{
		SetCtrlVal (PanelHandleIM, PANEL_IM_FIX_QUALITY1, 1);
		SetCtrlVal (PanelHandleIM, PANEL_IM_FIX_QUALITY2, 1);
		SetCtrlVal (PanelHandleIM, PANEL_IM_FIX_QUALITY3, 1);
		FixQuality = 3;
	}
	else;
	
	
	// ��ͨ�����Ƕ�λ�����ʾ
	SetCtrlVal (PanelHandleIM, PANEL_IM_SVNO_1, DataHost.m_SVsInfo[0].nNo);
	SetCtrlVal (PanelHandleIM, PANEL_IM_WEIJU_1, DataHost.m_SVsInfo[0].weiju);
	SetCtrlVal (PanelHandleIM, PANEL_IM_WEIJULV_1, DataHost.m_SVsInfo[0].weijulv);
	SetCtrlVal (PanelHandleIM, PANEL_IM_POSITION_X_1, DataHost.m_SVsInfo[0].X);
	SetCtrlVal (PanelHandleIM, PANEL_IM_POSITION_Y_1, DataHost.m_SVsInfo[0].Y);
	SetCtrlVal (PanelHandleIM, PANEL_IM_POSITION_Z_1, DataHost.m_SVsInfo[0].Z);
	SetCtrlVal (PanelHandleIM, PANEL_IM_VELOCITY_X_1, DataHost.m_SVsInfo[0].Vx);
	SetCtrlVal (PanelHandleIM, PANEL_IM_VELOCITY_Y_1, DataHost.m_SVsInfo[0].Vy);
	SetCtrlVal (PanelHandleIM, PANEL_IM_VELOCITY_Z_1, DataHost.m_SVsInfo[0].Vz);
	SetCtrlVal (PanelHandleIM, PANEL_IM_SNR_1, DataHost.m_SVsInfo[0].SNR);
	
	SetCtrlVal (PanelHandleIM, PANEL_IM_SVNO_2, DataHost.m_SVsInfo[1].nNo);
	SetCtrlVal (PanelHandleIM, PANEL_IM_WEIJU_2, DataHost.m_SVsInfo[1].weiju);
	SetCtrlVal (PanelHandleIM, PANEL_IM_WEIJULV_2, DataHost.m_SVsInfo[1].weijulv);
	SetCtrlVal (PanelHandleIM, PANEL_IM_POSITION_X_2, DataHost.m_SVsInfo[1].X);
	SetCtrlVal (PanelHandleIM, PANEL_IM_POSITION_Y_2, DataHost.m_SVsInfo[1].Y);
	SetCtrlVal (PanelHandleIM, PANEL_IM_POSITION_Z_2, DataHost.m_SVsInfo[1].Z);
	SetCtrlVal (PanelHandleIM, PANEL_IM_VELOCITY_X_2, DataHost.m_SVsInfo[1].Vx);
	SetCtrlVal (PanelHandleIM, PANEL_IM_VELOCITY_Y_2, DataHost.m_SVsInfo[1].Vy);
	SetCtrlVal (PanelHandleIM, PANEL_IM_VELOCITY_Z_2, DataHost.m_SVsInfo[1].Vz);
	SetCtrlVal (PanelHandleIM, PANEL_IM_SNR_2, DataHost.m_SVsInfo[1].SNR);
	
	SetCtrlVal (PanelHandleIM, PANEL_IM_SVNO_3, DataHost.m_SVsInfo[2].nNo);
	SetCtrlVal (PanelHandleIM, PANEL_IM_WEIJU_3, DataHost.m_SVsInfo[2].weiju);
	SetCtrlVal (PanelHandleIM, PANEL_IM_WEIJULV_3, DataHost.m_SVsInfo[2].weijulv);
	SetCtrlVal (PanelHandleIM, PANEL_IM_POSITION_X_3, DataHost.m_SVsInfo[2].X);
	SetCtrlVal (PanelHandleIM, PANEL_IM_POSITION_Y_3, DataHost.m_SVsInfo[2].Y);
	SetCtrlVal (PanelHandleIM, PANEL_IM_POSITION_Z_3, DataHost.m_SVsInfo[2].Z);
	SetCtrlVal (PanelHandleIM, PANEL_IM_VELOCITY_X_3, DataHost.m_SVsInfo[2].Vx);
	SetCtrlVal (PanelHandleIM, PANEL_IM_VELOCITY_Y_3, DataHost.m_SVsInfo[2].Vy);
	SetCtrlVal (PanelHandleIM, PANEL_IM_VELOCITY_Z_3, DataHost.m_SVsInfo[2].Vz);
	SetCtrlVal (PanelHandleIM, PANEL_IM_SNR_3, DataHost.m_SVsInfo[2].SNR);
	
	SetCtrlVal (PanelHandleIM, PANEL_IM_SVNO_4, DataHost.m_SVsInfo[3].nNo);
	SetCtrlVal (PanelHandleIM, PANEL_IM_WEIJU_4, DataHost.m_SVsInfo[3].weiju);
	SetCtrlVal (PanelHandleIM, PANEL_IM_WEIJULV_4, DataHost.m_SVsInfo[3].weijulv);
	SetCtrlVal (PanelHandleIM, PANEL_IM_POSITION_X_4, DataHost.m_SVsInfo[3].X);
	SetCtrlVal (PanelHandleIM, PANEL_IM_POSITION_Y_4, DataHost.m_SVsInfo[3].Y);
	SetCtrlVal (PanelHandleIM, PANEL_IM_POSITION_Z_4, DataHost.m_SVsInfo[3].Z);
	SetCtrlVal (PanelHandleIM, PANEL_IM_VELOCITY_X_4, DataHost.m_SVsInfo[3].Vx);
	SetCtrlVal (PanelHandleIM, PANEL_IM_VELOCITY_Y_4, DataHost.m_SVsInfo[3].Vy);
	SetCtrlVal (PanelHandleIM, PANEL_IM_VELOCITY_Z_4, DataHost.m_SVsInfo[3].Vz);
	SetCtrlVal (PanelHandleIM, PANEL_IM_SNR_4, DataHost.m_SVsInfo[3].SNR);
	
	SetCtrlVal (PanelHandleIM, PANEL_IM_SVNO_5, DataHost.m_SVsInfo[4].nNo);
	SetCtrlVal (PanelHandleIM, PANEL_IM_WEIJU_5, DataHost.m_SVsInfo[4].weiju);
	SetCtrlVal (PanelHandleIM, PANEL_IM_WEIJULV_5, DataHost.m_SVsInfo[4].weijulv);
	SetCtrlVal (PanelHandleIM, PANEL_IM_POSITION_X_5, DataHost.m_SVsInfo[4].X);
	SetCtrlVal (PanelHandleIM, PANEL_IM_POSITION_Y_5, DataHost.m_SVsInfo[4].Y);
	SetCtrlVal (PanelHandleIM, PANEL_IM_POSITION_Z_5, DataHost.m_SVsInfo[4].Z);
	SetCtrlVal (PanelHandleIM, PANEL_IM_VELOCITY_X_5, DataHost.m_SVsInfo[4].Vx);
	SetCtrlVal (PanelHandleIM, PANEL_IM_VELOCITY_Y_5, DataHost.m_SVsInfo[4].Vy);
	SetCtrlVal (PanelHandleIM, PANEL_IM_VELOCITY_Z_5, DataHost.m_SVsInfo[4].Vz);
	SetCtrlVal (PanelHandleIM, PANEL_IM_SNR_5, DataHost.m_SVsInfo[4].SNR);
	
	SetCtrlVal (PanelHandleIM, PANEL_IM_SVNO_6, DataHost.m_SVsInfo[5].nNo);
	SetCtrlVal (PanelHandleIM, PANEL_IM_WEIJU_6, DataHost.m_SVsInfo[5].weiju);
	SetCtrlVal (PanelHandleIM, PANEL_IM_WEIJULV_6, DataHost.m_SVsInfo[5].weijulv);
	SetCtrlVal (PanelHandleIM, PANEL_IM_POSITION_X_6, DataHost.m_SVsInfo[5].X);
	SetCtrlVal (PanelHandleIM, PANEL_IM_POSITION_Y_6, DataHost.m_SVsInfo[5].Y);
	SetCtrlVal (PanelHandleIM, PANEL_IM_POSITION_Z_6, DataHost.m_SVsInfo[5].Z);
	SetCtrlVal (PanelHandleIM, PANEL_IM_VELOCITY_X_6, DataHost.m_SVsInfo[5].Vx);
	SetCtrlVal (PanelHandleIM, PANEL_IM_VELOCITY_Y_6, DataHost.m_SVsInfo[5].Vy);
	SetCtrlVal (PanelHandleIM, PANEL_IM_VELOCITY_Z_6, DataHost.m_SVsInfo[5].Vz);
	SetCtrlVal (PanelHandleIM, PANEL_IM_SNR_6, DataHost.m_SVsInfo[5].SNR);
	
	SetCtrlVal (PanelHandleIM, PANEL_IM_SVNO_7, DataHost.m_SVsInfo[6].nNo);
	SetCtrlVal (PanelHandleIM, PANEL_IM_WEIJU_7, DataHost.m_SVsInfo[6].weiju);
	SetCtrlVal (PanelHandleIM, PANEL_IM_WEIJULV_7, DataHost.m_SVsInfo[6].weijulv);
	SetCtrlVal (PanelHandleIM, PANEL_IM_POSITION_X_7, DataHost.m_SVsInfo[6].X);
	SetCtrlVal (PanelHandleIM, PANEL_IM_POSITION_Y_7, DataHost.m_SVsInfo[6].Y);
	SetCtrlVal (PanelHandleIM, PANEL_IM_POSITION_Z_7, DataHost.m_SVsInfo[6].Z);
	SetCtrlVal (PanelHandleIM, PANEL_IM_VELOCITY_X_7, DataHost.m_SVsInfo[6].Vx);
	SetCtrlVal (PanelHandleIM, PANEL_IM_VELOCITY_Y_7, DataHost.m_SVsInfo[6].Vy);
	SetCtrlVal (PanelHandleIM, PANEL_IM_VELOCITY_Z_7, DataHost.m_SVsInfo[6].Vz);
	SetCtrlVal (PanelHandleIM, PANEL_IM_SNR_7, DataHost.m_SVsInfo[6].SNR);
	
	SetCtrlVal (PanelHandleIM, PANEL_IM_SVNO_8, DataHost.m_SVsInfo[7].nNo);
	SetCtrlVal (PanelHandleIM, PANEL_IM_WEIJU_8, DataHost.m_SVsInfo[7].weiju);
	SetCtrlVal (PanelHandleIM, PANEL_IM_WEIJULV_8, DataHost.m_SVsInfo[7].weijulv);
	SetCtrlVal (PanelHandleIM, PANEL_IM_POSITION_X_8, DataHost.m_SVsInfo[7].X);
	SetCtrlVal (PanelHandleIM, PANEL_IM_POSITION_Y_8, DataHost.m_SVsInfo[7].Y);
	SetCtrlVal (PanelHandleIM, PANEL_IM_POSITION_Z_8, DataHost.m_SVsInfo[7].Z);
	SetCtrlVal (PanelHandleIM, PANEL_IM_VELOCITY_X_8, DataHost.m_SVsInfo[7].Vx);
	SetCtrlVal (PanelHandleIM, PANEL_IM_VELOCITY_Y_8, DataHost.m_SVsInfo[7].Vy);
	SetCtrlVal (PanelHandleIM, PANEL_IM_VELOCITY_Z_8, DataHost.m_SVsInfo[7].Vz);
	SetCtrlVal (PanelHandleIM, PANEL_IM_SNR_8, DataHost.m_SVsInfo[7].SNR);
	
	SetCtrlVal (PanelHandleIM, PANEL_IM_SVNO_9, DataHost.m_SVsInfo[8].nNo);
	SetCtrlVal (PanelHandleIM, PANEL_IM_WEIJU_9, DataHost.m_SVsInfo[8].weiju);
	SetCtrlVal (PanelHandleIM, PANEL_IM_WEIJULV_9, DataHost.m_SVsInfo[8].weijulv);
	SetCtrlVal (PanelHandleIM, PANEL_IM_POSITION_X_9, DataHost.m_SVsInfo[8].X);
	SetCtrlVal (PanelHandleIM, PANEL_IM_POSITION_Y_9, DataHost.m_SVsInfo[8].Y);
	SetCtrlVal (PanelHandleIM, PANEL_IM_POSITION_Z_9, DataHost.m_SVsInfo[8].Z);
	SetCtrlVal (PanelHandleIM, PANEL_IM_VELOCITY_X_9, DataHost.m_SVsInfo[8].Vx);
	SetCtrlVal (PanelHandleIM, PANEL_IM_VELOCITY_Y_9, DataHost.m_SVsInfo[8].Vy);
	SetCtrlVal (PanelHandleIM, PANEL_IM_VELOCITY_Z_9, DataHost.m_SVsInfo[8].Vz);
	SetCtrlVal (PanelHandleIM, PANEL_IM_SNR_9, DataHost.m_SVsInfo[8].SNR);
	
	SetCtrlVal (PanelHandleIM, PANEL_IM_SVNO_10, DataHost.m_SVsInfo[9].nNo);
	SetCtrlVal (PanelHandleIM, PANEL_IM_WEIJU_10, DataHost.m_SVsInfo[9].weiju);
	SetCtrlVal (PanelHandleIM, PANEL_IM_WEIJULV_10, DataHost.m_SVsInfo[9].weijulv);
	SetCtrlVal (PanelHandleIM, PANEL_IM_POSITION_X_10, DataHost.m_SVsInfo[9].X);
	SetCtrlVal (PanelHandleIM, PANEL_IM_POSITION_Y_10, DataHost.m_SVsInfo[9].Y);
	SetCtrlVal (PanelHandleIM, PANEL_IM_POSITION_Z_10, DataHost.m_SVsInfo[9].Z);
	SetCtrlVal (PanelHandleIM, PANEL_IM_VELOCITY_X_10, DataHost.m_SVsInfo[9].Vx);
	SetCtrlVal (PanelHandleIM, PANEL_IM_VELOCITY_Y_10, DataHost.m_SVsInfo[9].Vy);
	SetCtrlVal (PanelHandleIM, PANEL_IM_VELOCITY_Z_10, DataHost.m_SVsInfo[9].Vz);
	SetCtrlVal (PanelHandleIM, PANEL_IM_SNR_10, DataHost.m_SVsInfo[9].SNR);
	
	
	

	
	// Record decoded GPS data
	/*fprintf(FileHandleHostGNSS429,"%f\t", DataHost.gps_time);  			

	fprintf(FileHandleHostGNSS429,"%f\t", DataHost.RcvTime);
	
	fprintf(FileHandleHostGNSS429, "%d\t", FixQuality);
	
	fprintf(FileHandleHostGNSS429, "%d\t", (int)DataHost.SVs);
	
	fprintf(FileHandleHostGNSS429,"%f\t", DataHost.Lat);
	fprintf(FileHandleHostGNSS429,"%f\t", DataHost.Lon);
	fprintf(FileHandleHostGNSS429,"%f\t", DataHost.Alt);
	fprintf(FileHandleHostGNSS429,"%f\t", DataHost.PDOP);
	
	fprintf(FileHandleHostGNSS429,"%f\t", DataHost.X);
	fprintf(FileHandleHostGNSS429,"%f\t", DataHost.Y);
	fprintf(FileHandleHostGNSS429,"%f\t", DataHost.Z);
	
	fprintf(FileHandleHostGNSS429,"%f\t", DataHost.Vx);
	fprintf(FileHandleHostGNSS429,"%f\t", DataHost.Vy);
	fprintf(FileHandleHostGNSS429,"%f\t", DataHost.Vz);
	
	for (i = 0; i < SV_NUM_RCVMAX; i ++) 
	{
		fprintf(FileHandleHostGNSS429,"%d\t", DataHost.m_SVsInfo[i].nNo);
		fprintf(FileHandleHostGNSS429,"%d\t", (int)DataHost.m_SVsInfo[i].SNR);
		fprintf(FileHandleHostGNSS429,"%f\t", DataHost.m_SVsInfo[i].weiju);
		fprintf(FileHandleHostGNSS429,"%f\t", DataHost.m_SVsInfo[i].weijulv);
		fprintf(FileHandleHostGNSS429,"%f\t", DataHost.m_SVsInfo[i].X);
		fprintf(FileHandleHostGNSS429,"%f\t", DataHost.m_SVsInfo[i].Y);
		fprintf(FileHandleHostGNSS429,"%f\t", DataHost.m_SVsInfo[i].Z);
		fprintf(FileHandleHostGNSS429,"%f\t", DataHost.m_SVsInfo[i].Vx);
		fprintf(FileHandleHostGNSS429,"%f\t", DataHost.m_SVsInfo[i].Vy);
		fprintf(FileHandleHostGNSS429,"%f\t", DataHost.m_SVsInfo[i].Vz);
	}
	
	fprintf(FileHandleHostGNSS429, "\r\n");*/
	
	
	
	// Record raw GPS data
	/*fprintf(FileHandleHostGNSS429Raw,"%f\t", DataHost.gps_time);  			
	for (i = 0; i < 128; i ++)   
	{
		fprintf (FileHandleHostGNSS429Raw, "%32x ", DataHost.gpsdata[i]); 
	}
	fprintf(FileHandleHostGNSS429Raw, "\r\n");*/

}



/*******************************   ���طɿ�Host Panel Callback ****************************/

//Start flight control all function
int CVICALLBACK buttonStartFC (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	int mode;
	switch (event)
	{
		case EVENT_COMMIT:
			// Get fire control mode
			GetCtrlVal (PanelHandleFC, PANEL_FC_SWITCH_FIRE_CONTROL, &mode);
			switch(mode)
			{
				case 0:											 
					CmdHost.modeFireControl = MODE_FIRECONTROL_STATIC;
					break;
			    case 1:
					CmdHost.modeFireControl = MODE_FIRECONTROL_DYNAMIC;
					break;
			}
			
			CmdHost.command = FC_START_COMMAND;
			
			ClientTCPWrite (StatusTcpHost, &CmdHost, sizeof(CmdHost), 5000);
			break;
	}
	return 0;
}


//Stop flight control all function
int CVICALLBACK buttonStopFC (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:
			CmdHost.command = FC_STOP_COMMAND; 
			ClientTCPWrite (StatusTcpHost, &CmdHost, sizeof(CmdHost), 5000);  
			break;
	}
	return 0;
}


//Quit flight control callback
int CVICALLBACK buttonQuitFC (int panel, int control, int event,
	void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:
			
			// Quit sub panel
		//	RemovePopup(PanelHandleFC);
			DiscardPanel (PanelHandleFC);
			PanelHandleFC = 0;
			break;
	}
	return 0;
}


//Selftest
int CVICALLBACK buttonSelftestFC (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:
			CmdHost.command = SELFTEST_COMMAND;
			ClientTCPWrite (StatusTcpHost, &CmdHost, sizeof(CmdHost), 5000);  
			//MessagePopup ("", "ϵͳ�Լ���,���Ժ�...");
			SetCtrlAttribute (PanelHandleIM, PANEL_IM_SELFTESTBUTTON, ATTR_LABEL_TEXT, "�Լ���...");
			break;
	}
	return 0;
}


//Start/Stop GNSS 422 (Fire control) callback
int CVICALLBACK buttonGNSSFC422 (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{

	int test_flag;
	switch (event)
	{
		case EVENT_COMMIT:
			GetCtrlVal(PanelHandleFC, PANEL_FC_GPSBUTTON,&test_flag);
			CmdHost.command = FC_GPSRECEIVE_COMMAND;
			CmdHost.statusGNSS422FC = test_flag;
			ClientTCPWrite (StatusTcpHost, &CmdHost, sizeof(CmdHost), 5000);
			break;
	}
	return 0;
}


//��ʼ��ֹͣң��LVDSת422����
int CVICALLBACK buttonYC (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	int test_flag;
	switch (event)
	{
		case EVENT_COMMIT:
			GetCtrlVal(PanelHandleFC, PANEL_FC_YCBUTTON, &test_flag);
			CmdHost.command = FC_YCRECEIVE_COMMAND;
			CmdHost.statusYC = test_flag;
			ClientTCPWrite (StatusTcpHost, &CmdHost, sizeof(CmdHost), 5000);
			break;
	}
	return 0;
}


//��ʼ��ֹͣ��ز���
int CVICALLBACK buttonFireControl (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	int test_flag;
	int mode;
	switch (event)
	{
		case EVENT_COMMIT:
			// Get fire control mode
			GetCtrlVal (PanelHandleFC, PANEL_FC_SWITCH_FIRE_CONTROL, &mode);
			switch(mode)
			{
				case 0:											 
					CmdHost.modeFireControl = MODE_FIRECONTROL_STATIC;
					break;
			    case 1:
					CmdHost.modeFireControl = MODE_FIRECONTROL_DYNAMIC;
					break;
			}
			
			// Start / stop flag
			GetCtrlVal(PanelHandleFC, PANEL_FC_T1553BUTTON, &test_flag);
			CmdHost.statusFireControl = test_flag;
			
			CmdHost.command = FC_FIRE_CONTROL_COMMAND;
			
			ClientTCPWrite (StatusTcpHost, &CmdHost, sizeof(CmdHost), 5000);
			break;
	}
	return 0;
}


//����ң������
void SetYCData(void)
{
	//YC decode data
	double YCDE_Px;
	double YCDE_Py; 
	double YCDE_Pz; 
	double YCDE_Vx; 
	double YCDE_Vy; 
	double YCDE_Vz; 
	
	double R0;
	double R1;
	double R2;
	double R3;
		
	double YCDE_Yaw; 
	double YCDE_Pitch; 
	double YCDE_Roll; 
	
	double T0;
	
	SetCtrlVal (PanelHandleFC, PANEL_FC_YCTIME, DataHost.timeIntervalYC);
				
	YCDE_Px = IntToDouble(DataHost.dataYC[0x76], 204800);  
	YCDE_Py = IntToDouble(DataHost.dataYC[0x77], 204800);    
	YCDE_Pz = IntToDouble(DataHost.dataYC[0x78], 204800);    

	YCDE_Vx = IntToDouble(DataHost.dataYC[0x5A], 3200);
	YCDE_Vy = IntToDouble(DataHost.dataYC[0x5B], 3200); 
	YCDE_Vz = IntToDouble(DataHost.dataYC[0x5C], 3200); 	

	R0 = IntToDouble(DataHost.dataYC[0x79], 1);     
	R1 = IntToDouble(DataHost.dataYC[0x7A], 1);     	
	R2 = IntToDouble(DataHost.dataYC[0x7B], 1);     	
	R3 = IntToDouble(DataHost.dataYC[0x7C], 1);     	
	                                                                	
	YCDE_Yaw   =-atan2(2*(R1*R3-R2*R0),R0*R0+R1*R1-R2*R2-R3*R3)*180/pi;  	
	YCDE_Pitch = asin(2*(R1*R2+R0*R3))*180/pi;                           	
	YCDE_Roll  =-atan2(2*(R2*R3-R1*R0),R0*R0-R1*R1+R2*R2-R3*R3)*180/pi; 
	
	T0 = IntToDouble(DataHost.dataYC[0x3D], 2048); 
	
	SetCtrlVal (PanelHandleFC, PANEL_FC_XR, YCDE_Px);  	
	SetCtrlVal (PanelHandleFC, PANEL_FC_YR, YCDE_Py);  	
	SetCtrlVal (PanelHandleFC, PANEL_FC_ZR, YCDE_Pz);  
	
	SetCtrlVal (PanelHandleFC, PANEL_FC_VRX, YCDE_Vx);  
	SetCtrlVal (PanelHandleFC, PANEL_FC_VRY, YCDE_Vy);  
	SetCtrlVal (PanelHandleFC, PANEL_FC_VRZ, YCDE_Vz);  
	
	SetCtrlVal (PanelHandleFC, PANEL_FC_YAW, YCDE_Yaw);  
	SetCtrlVal (PanelHandleFC, PANEL_FC_PITCH, YCDE_Pitch);  
	SetCtrlVal (PanelHandleFC, PANEL_FC_ROLL, YCDE_Roll); 
	
	SetCtrlVal (PanelHandleFC, PANEL_FC_T0, T0); 	
}


//����GPS��������
void SetGNSSFC422Data(void)
{
	int i;
	
	SetCtrlVal (PanelHandleFC, PANEL_FC_GPSTIME, DataHost.gps_time);
	//SetCtrlVal (PanelHandleFC, PANEL_GPSFIRSTDATA, DataHost.gps_firstdata);  
	//SetCtrlVal (PanelHandleFC, PANEL_LON, DataHost.Lon);
	//SetCtrlVal (PanelHandleFC, PANEL_LAT, DataHost.Lat); 
	//SetCtrlVal (PanelHandleFC, PANEL_ALT, DataHost.Alt);
	//SetCtrlVal (PanelHandleFC, PANEL_PDOP, DataHost.PDOP);
	
	/*fprintf(FileHandleGNSSFC422, "%f\t", DataHost.gps_time);
	for (i = 0; i < 339; i ++)
	{
		fprintf(FileHandleGNSSFC422, "%02x\t", DataHost.gnss422Data[i]);
	}
	fprintf(FileHandleGNSSFC422, "\r\n");*/ 
}


//1553���ݱ�����ʾ
void SetFC1553Data(void)
{
	int i, j;
	int TableType;
	Point PointTemp;
	
	if ((DataHost.dataType[1] == 'R') || (DataHost.dataType[2] == 'R'))
		TableType = 0;
	else if ((DataHost.dataType[1] == 'T') || (DataHost.dataType[2] == 'T'))
		TableType = 1;
	else
		TableType = -1;

	for(i = 0; i < 30; i ++ )
	{
		PointTemp.x = i + 1;
		PointTemp.y = 1;		
		
		if(TableType == 0)
			SetTableCellAttribute (PanelHandleFC, PANEL_FC_TABLE_1553SEND, PointTemp, ATTR_CTRL_VAL, DataHost.dataFlightControl[i]);	
		else if(TableType == 1)
			SetTableCellAttribute (PanelHandleFC, PANEL_FC_TABLE_1553RECEIVE, PointTemp, ATTR_CTRL_VAL, DataHost.dataFlightControl[i]);	
		else;
	}
}

	
//��Դ��ض�ʱ����(�ɿ�)
int CVICALLBACK timerFC (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	float V_FC, V_LVDS422, I_FC, I_LVDS422; 
	switch (event)
	{
		case EVENT_TIMER_TICK:
			// Flight control 27V
		    FlushInQ (3); 
			ComWrt (3, BufferPowerTest27, 8);
			ComRd (3, BufferPowerRead, 9);
			V_FC=(BufferPowerRead[3]*16*16+BufferPowerRead[4])/1000.00;
			I_FC=(BufferPowerRead[5]*16*16+BufferPowerRead[6])/1000.00;	
			SetCtrlVal (PanelHandleFC, PANEL_FC_V_FC, V_FC);
			SetCtrlVal (PanelHandleFC, PANEL_FC_I_FC, I_FC);
		 
			// LVDS to 422 board 5V
			FlushInQ (4);
			ComWrt (4, BufferPowerTest5V4, 8);
			ComRd (4, BufferPowerRead, 9);
			V_LVDS422=(BufferPowerRead[3]*16*16+BufferPowerRead[4])/1000.00;
			I_LVDS422=(BufferPowerRead[5]*16*16+BufferPowerRead[6])/1000.00;	
			SetCtrlVal (PanelHandleFC, PANEL_FC_V_BK, V_LVDS422);
			SetCtrlVal (PanelHandleFC, PANEL_FC_I_BK, I_LVDS422);
 
			// Power on time
			if (FlagFCfc == 1)
			{
				SetCtrlVal (PanelHandleFC, PANEL_FC_TIME_FC, clock() / CLOCKS_PER_SEC - TimeStartFCfc);	
			}
			if (FlagFClvds422 == 1)
			{
				SetCtrlVal (PanelHandleFC, PANEL_FC_TIME_BK, clock() / CLOCKS_PER_SEC - TimeStartFClvds422);	
			}
			
			break;
	}
	return 0;
}


//�Զ����ֶ�ģʽѡ��
int CVICALLBACK switchModeFC (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	int mode;
	
	switch (event)
	{
		case EVENT_COMMIT:

			GetCtrlVal (PanelHandleFC, PANEL_FC_MODULESWITCH, &mode);
			switch(mode)
			{
				case 1:	
					//�Զ�ģʽ���óɶ�̬�ɿز���
					SetCtrlVal (PanelHandleFC, PANEL_FC_SWITCH_FIRE_CONTROL, 1);
					CmdHost.modeFireControl = MODE_FIRECONTROL_DYNAMIC; 
					
				  	CmdHost.command = FC_AUTOSTART_COMMAND;
					CmdHost.statusAutostartFC = 1;
				  	ClientTCPWrite (StatusTcpHost, &CmdHost, sizeof(CmdHost), 5000);
				  	SetCtrlVal (PanelHandleFC, PANEL_FC_LED3, 1);
					
					SetCtrlAttribute (PanelHandleFC, PANEL_FC_GPSBUTTON, ATTR_DIMMED, 1);
					SetCtrlAttribute (PanelHandleFC, PANEL_FC_T1553BUTTON, ATTR_DIMMED, 1);
					SetCtrlAttribute (PanelHandleFC, PANEL_FC_YCBUTTON, ATTR_DIMMED, 1);
					SetCtrlAttribute (PanelHandleFC, PANEL_FC_STARTBUTTON, ATTR_DIMMED, 1);	   
					SetCtrlAttribute (PanelHandleFC, PANEL_FC_STOPBUTTON, ATTR_DIMMED, 1);
					SetCtrlAttribute (PanelHandleFC, PANEL_FC_QUITBUTTON, ATTR_DIMMED, 1);
					SetCtrlAttribute (PanelHandleFC, PANEL_FC_SELFTESTBUTTON, ATTR_DIMMED, 1);
					SetCtrlAttribute (PanelHandleFC, PANEL_FC_POWERSWITCH, ATTR_DIMMED, 1);
					SetCtrlAttribute (PanelHandleFC, PANEL_FC_BOARDPOWERSWITCH, ATTR_DIMMED, 1);
					break;
			    case 0:
					CmdHost.command = FC_AUTOSTART_COMMAND;
					CmdHost.statusAutostartFC = 0;
				  	ClientTCPWrite (StatusTcpHost, &CmdHost, sizeof(CmdHost), 5000);
				  	SetCtrlVal (PanelHandleFC, PANEL_FC_LED3, 0);
					
					SetCtrlAttribute (PanelHandleFC, PANEL_FC_GPSBUTTON, ATTR_DIMMED, 0);
					SetCtrlAttribute (PanelHandleFC, PANEL_FC_T1553BUTTON, ATTR_DIMMED, 0);
					SetCtrlAttribute (PanelHandleFC, PANEL_FC_YCBUTTON, ATTR_DIMMED, 0);
					SetCtrlAttribute (PanelHandleFC, PANEL_FC_STARTBUTTON, ATTR_DIMMED, 0);	   
					SetCtrlAttribute (PanelHandleFC, PANEL_FC_STOPBUTTON, ATTR_DIMMED, 0);
					SetCtrlAttribute (PanelHandleFC, PANEL_FC_QUITBUTTON, ATTR_DIMMED, 0);
					SetCtrlAttribute (PanelHandleFC, PANEL_FC_SELFTESTBUTTON, ATTR_DIMMED, 0);
					SetCtrlAttribute (PanelHandleFC, PANEL_FC_POWERSWITCH, ATTR_DIMMED, 0);
					SetCtrlAttribute (PanelHandleFC, PANEL_FC_BOARDPOWERSWITCH, ATTR_DIMMED, 0);
					break;
			}
			break;
	}
	return 0;
}


//Power on flight control (FC)
int PowerOnFCfc()
{
	ComWrt (3, BufferPowerOn27, 8);
  	Delay(0.05);
  	SetCtrlVal (PanelHandleFC, PANEL_FC_LED1, 1); 
	
	// Disable quit button
	SetCtrlAttribute (PanelHandleFC, PANEL_FC_QUITBUTTON, ATTR_DIMMED, 1);
	
	// Set time flag
	FlagFCfc = 1;
	TimeStartFCfc = clock() / CLOCKS_PER_SEC;
	SetCtrlVal (PanelHandleFC, PANEL_FC_TIME_FC, 0.0);
	return 0;
}


//Power off flight control (FC)
int PowerOffFCfc()
{
	ComWrt (3, BufferPowerOff27, 8);
	Delay(0.05);
  	SetCtrlVal (PanelHandleFC, PANEL_FC_LED1, 0);
	
	// Enable quit button
	if ((StatusPower27V == 0) && (StatusPower5V == 0))
		SetCtrlAttribute (PanelHandleFC, PANEL_FC_QUITBUTTON, ATTR_DIMMED, 0);
	
	// Clear time flag
	FlagFCfc = 0;
	return 0;
}


//Power on lvds to 422 board (FC)
int PowerOnFClvds422()
{
	ComWrt (4, BufferPowerOn5V4, 8); 
  	Delay(0.05);  
  	SetCtrlVal (PanelHandleFC, PANEL_FC_LED2, 1);
	
	// Disable quit button
	SetCtrlAttribute (PanelHandleFC, PANEL_FC_QUITBUTTON, ATTR_DIMMED, 1);
	
	// Set time flag
	FlagFClvds422 = 1;
	TimeStartFClvds422 = clock() / CLOCKS_PER_SEC;
	SetCtrlVal (PanelHandleFC, PANEL_FC_TIME_BK, 0.0);
	return 0;
}


//Power off lvds to 422 board (FC)
int PowerOffFClvds422()
{
	ComWrt (4, BufferPowerOff5V4, 8);
	Delay(0.05);
	SetCtrlVal (PanelHandleFC, PANEL_FC_LED2, 0);

	// Enable quit button
	if ((StatusPower27V == 0) && (StatusPower5V == 0))
		SetCtrlAttribute (PanelHandleFC, PANEL_FC_QUITBUTTON, ATTR_DIMMED, 0);

	// Clear time flag
	FlagFClvds422 = 0;
	return 0;
}


//�ɿ�ģ���ϵ�
int CVICALLBACK PowerSwitchFC27V (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:
			GetCtrlVal (PanelHandleFC, PANEL_FC_POWERSWITCH, &StatusPower27V);
			GetCtrlVal (PanelHandleFC, PANEL_FC_BOARDPOWERSWITCH, &StatusPower5V);
			switch(StatusPower27V)
			{
				case 1:											 
				  	PowerOnFCfc();
					break;
			    case 0:
				  	PowerOffFCfc();
					break;
			}
			break;
	}
	return 0;
}


//LVDSת422�忨�ϵ�
int CVICALLBACK PowerSwitchFC5V (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:
			GetCtrlVal (PanelHandleFC, PANEL_FC_POWERSWITCH, &StatusPower27V);
			GetCtrlVal (PanelHandleFC, PANEL_FC_BOARDPOWERSWITCH, &StatusPower5V);
			switch(StatusPower5V)
			{
				case 1:											 
				  	PowerOnFClvds422();
					break;
			    case 0:
				  	PowerOffFClvds422();
					break;
			}
			break;
	}
	return 0;
}


int GetTraceDataFromDS_Computer(char Path_temp[260]) 
{
/*	int error;
	int FTP_ReceiveHandle;
	char Path_tempTemp[260] = {0};
	char Path_tempTempHead[260] = {0};
	
	strcpy(Path_tempTempHead, "c:\\"); 						
	strcpy(Path_tempTemp, strcat(Path_tempTempHead, Path_temp)); 
	strcat(Path_tempTemp, "CraftData.txt");	  						
	
	FTP_ReceiveHandle = InetFTPLoginEx ("192.168.0.2", "Administrator", "mmmmmm", 2000); //2s Timeout 
	if(FTP_ReceiveHandle < 0)
		printf("Error_login: %s\n", InetGetErrorMessage(FTP_ReceiveHandle));
	
	error = InetFTPRetrieveFile (FTP_ReceiveHandle, Path_tempTemp, 
		                         "CraftData.txt", INET_FTP_FILE_TYPE_BINARY);
	if(error < 0)
		printf("Error_retrieve_file: %s\n", InetGetErrorMessage(error));
	return error;
 */	 	 
	
	int error;
	char Path_tempTemp[260] = {0};
	char Path_tempTempHead[260] = {0};
	
	strcpy(Path_tempTempHead, "c:\\");
	
	strcpy(Path_tempTemp, strcat(Path_tempTempHead, Path_temp));

	strcat(Path_tempTemp, "CraftData.txt");	

	error = InetFTPAutoRetrieve ("192.168.0.2", "Administrator", "mmmmmm", 
		                          Path_tempTemp, "CraftData.txt", INET_FTP_FILE_TYPE_BINARY);
	if(error < 0)
		MessagePopup ("����", InetGetErrorMessage(error));
	return error; 
}

int CVICALLBACK WaitingTimeCallback (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{  
		case EVENT_TIMER_TICK:
			//6 s ��ʱ  20�� 
			if(waittimecounter >= 20)
			{
				MessagePopup ("������ʾ", "�ļ��ϴ���ʱ���������ϴ���"); 
				DiscardPanel (PanelHandleWait);    
				DiscardAsyncTimer (TimerHandleWait);  
				waittimecounter = 0;    
			}
			else
			{
				if(waittimecounter % 4 == 0)
			    	SetCtrlVal (PanelHandleWait, WAIT_PANEL_TEXTMSG , "���ݴ�����."); 
				else if(waittimecounter % 4 == 1)
					SetCtrlVal (PanelHandleWait, WAIT_PANEL_TEXTMSG , "���ݴ�����.."); 
				else if(waittimecounter % 4 == 2)
					SetCtrlVal (PanelHandleWait, WAIT_PANEL_TEXTMSG , "���ݴ�����..."); 	
				else if(waittimecounter % 4 == 3)
					SetCtrlVal (PanelHandleWait, WAIT_PANEL_TEXTMSG , "���ݴ�����"); 
				waittimecounter++;	
			} 
			break;
	}
	return 0;
}


/*******************************  ʵ�������������Host Panel Callback ****************************/ 
int CVICALLBACK TestAnalysis (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:
			
			PanelHandleTestAnalysis = LoadPanel (PanelHandleTestAnalysis, "ʵ����������Host.uir", PANELANA);
			
			SetPanelAttribute (PanelHandleTestAnalysis, ATTR_WINDOW_ZOOM, VAL_MAXIMIZE);
			
			DisplayPanel(PanelHandleTestAnalysis);			
			
			break;
	}
	return 0;
}

int CVICALLBACK QUIT_TestAnalysis (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:
			DiscardPanel (PanelHandleTestAnalysis);
			PanelHandleTestAnalysis = 0;
			break;
	}
	return 0;
}

int CVICALLBACK Read_IMU_Simulation (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:
			
            stateSimulationIMUSetFileSelectPopup=FileSelectPopup ("c:\\", "*.txt", "*.txt", 
				 "��ȡ��׼�켣���������ļ�",  VAL_OK_BUTTON , 0, 0,1, 0, IMUSimSetFilePath);
			 
			SetCtrlVal (PanelHandleTestAnalysis, PANELANA_IMUSimulation_Read, IMUSimSetFilePath);
			
			CraftData_FileHandle=fopen(IMUSimSetFilePath,"r");
 
			fscanf(CraftData_FileHandle,"%lf", &TraceTime); 			
			fscanf(CraftData_FileHandle,"%lf", &CraftPosition[0][0]); 	//���»�����ǽǶ�		
			fscanf(CraftData_FileHandle,"%lf", &CraftPosition[1][0]); 			
			fscanf(CraftData_FileHandle,"%lf", &CraftPosition[2][0]); 			
			fscanf(CraftData_FileHandle,"%lf", &CraftVelocity[0][0]); 			
			fscanf(CraftData_FileHandle,"%lf", &CraftVelocity[1][0]); 			
			fscanf(CraftData_FileHandle,"%lf", &CraftVelocity[2][0]); 			
			fscanf(CraftData_FileHandle,"%lf", &CraftAcc[0][0]); 			
			fscanf(CraftData_FileHandle,"%lf", &CraftAcc[1][0]); 			
			fscanf(CraftData_FileHandle,"%lf", &CraftAcc[2][0]); 			
			fscanf(CraftData_FileHandle,"%lf", &CraftAttitude[0][0]); 	//���»�����ǽǶ�		
			fscanf(CraftData_FileHandle,"%lf", &CraftAttitude[1][0]); 			
			fscanf(CraftData_FileHandle,"%lf", &CraftAttitude[2][0]); 			
			fscanf(CraftData_FileHandle,"%lf", &CraftAttitudeChangeRate[1][0]); 	//���»�����ǽǶ�		
			fscanf(CraftData_FileHandle,"%lf", &CraftAttitudeChangeRate[2][0]); 			
			fscanf(CraftData_FileHandle,"%lf", &CraftAttitudeChangeRate[3][0]); 			
			
			fscanf(CraftData_FileHandle,"%lf", &CraftSFB[0][0]); 			
			fscanf(CraftData_FileHandle,"%lf", &CraftSFB[1][0]); 			
			fscanf(CraftData_FileHandle,"%lf", &CraftSFB[2][0]);            
			fscanf(CraftData_FileHandle,"%lf", &CraftOmegaiBB[0][0]); 			
			fscanf(CraftData_FileHandle,"%lf", &CraftOmegaiBB[1][0]); 			
			fscanf(CraftData_FileHandle,"%lf", &CraftOmegaiBB[2][0]);
			
			fscanf(CraftData_FileHandle,"%lf", &CraftInsSFs[0][0]); 			
			fscanf(CraftData_FileHandle,"%lf", &CraftInsSFs[1][0]); 			
			fscanf(CraftData_FileHandle,"%lf", &CraftInsSFs[2][0]); 
			fscanf(CraftData_FileHandle,"%lf", &CraftInsOmegaiBBs[0][0]); 			
			fscanf(CraftData_FileHandle,"%lf", &CraftInsOmegaiBBs[1][0]); 			
			fscanf(CraftData_FileHandle,"%lf", &CraftInsOmegaiBBs[2][0]); 
			fscanf(CraftData_FileHandle,"%d", &CraftFPulseOut[0][0]); 			
			fscanf(CraftData_FileHandle,"%d", &CraftFPulseOut[1][0]); 			
			fscanf(CraftData_FileHandle,"%d", &CraftFPulseOut[2][0]); 
			fscanf(CraftData_FileHandle,"%d", &CraftGPulseOut[0][0]); 			
			fscanf(CraftData_FileHandle,"%d", &CraftGPulseOut[1][0]); 			
			fscanf(CraftData_FileHandle,"%d", &CraftGPulseOut[2][0]); 
			
			fscanf(CraftData_FileHandle,"%d", &CraftNavFlag); 			
			fscanf(CraftData_FileHandle,"%lf", &CraftInsPosition[0][0]); 	//���»�����ǽǶ�		
			fscanf(CraftData_FileHandle,"%lf", &CraftInsPosition[1][0]); 			
			fscanf(CraftData_FileHandle,"%lf", &CraftInsPosition[2][0]); 
			fscanf(CraftData_FileHandle,"%lf", &CraftInsVelocityP[0][0]); 			
			fscanf(CraftData_FileHandle,"%lf", &CraftInsVelocityP[1][0]); 			
			fscanf(CraftData_FileHandle,"%lf", &CraftInsVelocityP[0][0]); 			
			fscanf(CraftData_FileHandle,"%lf", &CraftInsAttitude[1][0]); 	//���»�����ǽǶ�		
			fscanf(CraftData_FileHandle,"%lf", &CraftInsAttitude[2][0]); 			
			fscanf(CraftData_FileHandle,"%lf", &CraftInsAttitude[2][0]); 			
                              
                              
			fscanf(CraftData_FileHandle,"%lf", &CraftPositionCha[0][0]); 			
			fscanf(CraftData_FileHandle,"%lf", &CraftPositionCha[1][0]); 			
			fscanf(CraftData_FileHandle,"%lf", &CraftPositionCha[2][0]);                              
			fscanf(CraftData_FileHandle,"%lf", &CraftVelocityCha[0][0]); 			
			fscanf(CraftData_FileHandle,"%lf", &CraftVelocityCha[1][0]); 			
			fscanf(CraftData_FileHandle,"%lf", &CraftVelocityCha[2][0]);
			fscanf(CraftData_FileHandle,"%lf", &AttCha[0][0]); 	//���»�����ǽǶ�			
			fscanf(CraftData_FileHandle,"%lf", &AttCha[1][0]); 			
			fscanf(CraftData_FileHandle,"%lf", &AttCha[2][0]);
			
			fscanf(CraftData_FileHandle,"%d", &FcsNavFlag); 			
			fscanf(CraftData_FileHandle,"%lf", &FcsPos[0][0]); 			
			fscanf(CraftData_FileHandle,"%lf", &FcsPos[1][0]); 			
			fscanf(CraftData_FileHandle,"%lf", &FcsPos[2][0]);
			fscanf(CraftData_FileHandle,"%lf", &FcsVel[0][0]); 			
			fscanf(CraftData_FileHandle,"%lf", &FcsVel[1][0]); 			
			fscanf(CraftData_FileHandle,"%lf", &FcsVel[2][0]);			
			fscanf(CraftData_FileHandle,"%lf", &FcsAttitude[0][0]); 	//���»�����ǽǶ�		
			fscanf(CraftData_FileHandle,"%lf", &FcsAttitude[1][0]); 			
			fscanf(CraftData_FileHandle,"%lf", &FcsAttitude[2][0]); 
			fscanf(CraftData_FileHandle,"%lf", &FcsQtn[0][0]); 			
			fscanf(CraftData_FileHandle,"%lf", &FcsQtn[1][0]); 			
			fscanf(CraftData_FileHandle,"%lf", &FcsQtn[2][0]); 
			fscanf(CraftData_FileHandle,"%lf", &FcsQtn[3][0]); 			
			fscanf(CraftData_FileHandle,"%lf", &FcsGravity[0][0]); 			
			fscanf(CraftData_FileHandle,"%lf", &FcsGravity[1][0]); 			
			fscanf(CraftData_FileHandle,"%lf", &FcsGravity[2][0]); 
			fscanf(CraftData_FileHandle,"%lf", &CraftSNavGravity); 		
			
			break;
	}
	return 0;
}

int CVICALLBACK Read_IMU_Test (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:
             stateTestIMUSetFileSelectPopup=FileSelectPopup ("c:\\", "*.txt", "*.txt", 
				 "��ȡ��׼�켣���������ļ�",  VAL_OK_BUTTON , 0, 0,1, 0, IMUTestSetFilePath);
			 
			SetCtrlVal (PanelHandleTestAnalysis, PANELANA_IMUTest_Read, IMUTestSetFilePath);
			
			pulse_FileHandle=fopen(IMUTestSetFilePath,"r");
 
			fscanf(pulse_FileHandle,"%lf", &TraceTime_pulse); 			
			fscanf(pulse_FileHandle,"%lf", &Time_pulse); 			
	
			fscanf(pulse_FileHandle,"%lf", &GyroPulseNum_pulse[0][0]); 	//���»�����ǽǶ�		
			fscanf(pulse_FileHandle,"%lf", &GyroPulseNum_pulse[1][0]); 			
			fscanf(pulse_FileHandle,"%lf", &GyroPulseNum_pulse[2][0]); 			
			fscanf(pulse_FileHandle,"%lf", &AccPulseNum_pulse[0][0]); 	//���»�����ǽǶ�		
			fscanf(pulse_FileHandle,"%lf", &AccPulseNum_pulse[1][0]); 			
			fscanf(pulse_FileHandle,"%lf", &AccPulseNum_pulse[2][0]);
			
			fscanf(pulse_FileHandle,"%lf", &GyroAngleRate_pulse[0][0]); 	//���»�����ǽǶ�		
			fscanf(pulse_FileHandle,"%lf", &GyroAngleRate_pulse[1][0]); 			
			fscanf(pulse_FileHandle,"%lf", &GyroAngleRate_pulse[2][0]);			
			fscanf(pulse_FileHandle,"%lf", &Acc_pulse[0][0]); 	//���»�����ǽǶ�		
			fscanf(pulse_FileHandle,"%lf", &Acc_pulse[1][0]); 			
			fscanf(pulse_FileHandle,"%lf", &Acc_pulse[2][0]);
			fscanf(pulse_FileHandle,"%lf", &Angle_pulse[0][0]); 	//���»�����ǽǶ�		
			fscanf(pulse_FileHandle,"%lf", &Angle_pulse[1][0]); 			
			fscanf(pulse_FileHandle,"%lf", &Angle_pulse[2][0]);			

			break;
	}
	return 0;
}

int CVICALLBACK Read_FC_Test (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:
             stateTestFCSetFileSelectPopup=FileSelectPopup ("c:\\", "*.txt", "*.txt", 
				 "��ȡ��׼�켣���������ļ�",  VAL_OK_BUTTON , 0, 0,1, 0, FCTestSetFilePath);
			 
			SetCtrlVal (PanelHandleTestAnalysis, PANELANA_FCTest_Read, FCTestSetFilePath);
			break;
	}
	return 0;
}

int CVICALLBACK Read_GNSS_Test (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:
             stateTestGNSSSetFileSelectPopup=FileSelectPopup ("c:\\", "*.txt", "*.txt", 
				 "��ȡ��׼�켣���������ļ�",  VAL_OK_BUTTON , 0, 0,1, 0, GNSSTestSetFilePath);
			 
			SetCtrlVal (PanelHandleTestAnalysis, PANELANA_GNSSTest_Read, GNSSTestSetFilePath);
			break;
	}
	return 0;
}

int CVICALLBACK TestAnalysis_IMU (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:
			
			
			
			

			break;
	}
	return 0;
}

int CVICALLBACK TestAnalysis_FC (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:

			break;
	}
	return 0;
}

int CVICALLBACK TestAnalysis_GNSS (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:

			break;
	}
	return 0;
}
