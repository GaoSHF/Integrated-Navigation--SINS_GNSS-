//==============================================================================
//
// Title:		���ز���RT
// Purpose:		A short description of the application.
//
// Created on:	2013-7-7 at 14:30:03 by HC.
// Copyright:	buaa. All Rights Reserved.
//
//==============================================================================

//==============================================================================
#include <cvintwrk.h>
#include <formatio.h>   
#include <tcpsupp.h>
#include <cvirte.h>
#include <rtutil.h>
#include <userint.h> 
#include <analysis.h>
#include <utility.h>
#include <cvinetv.h>
#include <ansi_c.h> 
#include <asynctmr.h>
#include <time.h>

#include "common.h"
#include "����RT.h"
#include "pxi_io.h"
#include "pulse_counter.h"
#include "gnss_429.h"
#include "gnss_fc_422.h"
#include "fc1553.h"
#include "yc.h"
#include "selftest.h"
#include "rfm.h"



double QtnTest[4][1];
double AttTest[3][1];
//==============================================================================

volatile int gDone;

static int ThreadFunctionIdRecord = 0;
static int ThreadFunctionIdIM = 0;
static int ThreadFunctionIdFC = 0;

int FlagThreadRecord = 0;

int ErrorFTP = 0;
char FolderPath[100];
char FilePath[100];
char HostUserName[30];
char HostPassword[30];

FILE *FileHandleRTYCDecode = NULL; // Test file handle
FILE *FileHandleTest = NULL; // Test file handle

void CallbackSelfTest(void);
void CallbackRTQuit(void);
void CallbackSendFiles(void);

void CallbackStopIM(void);
void CallbackStartIM(void);
void CallbackGNSS429(void);  
void CallbackPulse(void);
void CallbackAutoIM(void);

void CallbackStopFC(void);
void CallbackStartFC(void);
void CallbackYC(void);
void CallbackGNSSFC422(void); 
void CallbackFireControl(void);
void CallbackAutoFC(void);

static int CVICALLBACK ThreadFunctionAutoIM(void *functionData);
static int CVICALLBACK ThreadFunctionAutoFC(void *functionData);

static int CVICALLBACK ThreadFunctionRecord(void *functionData);

int CVICALLBACK TCPDataCallback (unsigned handle, int xType, int errCode, void *cbData);


//============================================================================== 
//
//  ʵʱ�������� 
//
//============================================================================== 

void CVIFUNC_C RTmain (void)
{
	CNVData SelfTestFinshData;
	unsigned int prevProcessorMask = 0;
	
	StatusTcpRT = TCP_INVALID_CONNECTION;
	
	if (InitCVIRTE (0, 0, 0) == 0)
		return;    /* out of memory */
	
	// Configure the system processor pool to only include the first processor on the system.
	ConfigureProcessorPool (kProcessorPool_System, 0xFFFFFFFF, &prevProcessorMask);
	
	/* Your initialization code. */
	/* It is common for Real-Time applications to use multiple threads to */
	/* separate higher priority tasks from lower priority tasks. See the  */
	/* Thread Pool functions in the Utility Library and the Asynchronous  */
	/* Timer functions in <CVI>\toolslib\toolbox\asynctmr.fp.             */
	// Create lock to synchronize writing TCP DataRT
	CmtNewLock (0, 0, &gLock);
	CmtNewThreadPool (10, &gThreadPool);

//	printf("CPU total number = %d\n", CmtGetNumProcessors());
	
	printf("Start RT programme successfully!\n");
	
	// Open test file
	FileHandleTest = fopen("C:\\test.txt","w");

	// Create a TCP server to communicate with RT target.
    RegisterTCPServer (HOST_PORT, TCPDataCallback, 0);
	
	// Init RFM
	rfmInitMC();
	
	// Open I/O board
	FlagFoundIO = IO_Open(&ParamIO);
	if(FlagFoundIO == IO_FOUND) 
	{
		IO_EnableIntPCI(ParamIO, InterruptPPS);
		printf("I/O board: Opened with interrupt.\n");
	}
	
	// Create file record thread
	FlagThreadRecord = 0;
	CmtScheduleThreadPoolFunction (gThreadPool, ThreadFunctionRecord, NULL, &ThreadFunctionIdRecord);
	
	// Acquire memory
	DataTemp = (DataMessage *) malloc(sizeof(DataMessage) * MEMORY_BANK_SIZE);

	while (!RTIsShuttingDown () && !gDone)
	{
		/* Sleep for some amount of time to give the desired loop rate */
		/* and to allow lower priority threads to run.                 */
		ProcessSystemEvents();
		SleepUS (10);
	} 
	
	// Close test file
	fclose(FileHandleTest);
	
	// End file record thread
	FlagThreadRecord = 1;
	CmtWaitForThreadPoolFunctionCompletion (gThreadPool, ThreadFunctionIdRecord, OPT_TP_PROCESS_EVENTS_WHILE_WAITING);
	CmtReleaseThreadPoolFunctionID (gThreadPool, ThreadFunctionIdRecord);
	
	// Release memory
	free(DataTemp);

	// Close RFM
	rfmCloseMC();
	
	// Close I/O board
	if(FlagFoundIO == IO_FOUND) 
	{ 
		IO_DisableIntPCI(ParamIO, InterruptPPS);
		// Close I/O board
		IO_Close (&ParamIO);
		printf("I/O board: Closed.\n");
	}
	
	if (gThreadPool)
		// CmtDiscardThreadPool waits for the thread function to exit.
		CmtDiscardThreadPool (gThreadPool);
	 
	
	// Restore the original system processor pool configuration.
	if (prevProcessorMask)
		ConfigureProcessorPool (kProcessorPool_System, prevProcessorMask, NULL);
	
	/* Your cleanup code. */
	CmtDiscardLock (gLock);
	
	
	// Cleanup
	UnregisterTCPServer(HOST_PORT);
	
Done:  	
	CloseCVIRTE ();
}

/****TCPͨѶ�ص�����****/ 
int CVICALLBACK TCPDataCallback (unsigned handle, int xType, int errCode, void *cbData)
{
    switch (xType)
    {
		case TCP_CONNECT:
			StatusTcpRT = handle;
			printf("TCP connected!\n");
            break;
        case TCP_DISCONNECT:
            StatusTcpRT = TCP_INVALID_CONNECTION;
			printf("TCP disconnected!\n");
            break;
        case TCP_DATAREADY: //ʵʱ������ָ�� 

			ServerTCPRead (StatusTcpRT, &CmdRT, sizeof(CmdRT), 5000);
			switch(CmdRT.command)
			{
				case SELFTEST_COMMAND:
					CallbackSelfTest();    
					break;
				case FTP_COMMAND:
					CallbackSendFiles();
					break;
				case RT_QUIT_COMMAND:
					CallbackRTQuit();
					break;				
					
		
				case IM_START_COMMAND:
					CallbackStartIM();  
					break;
				case IM_STOP_COMMAND:
					CallbackStopIM();    
					break; 
				case IM_GPSRECEIVE_COMMAND:
					CallbackGNSS429();    
					break; 	
				case IM_INSRECEIVE_COMMAND:
					CallbackPulse(); 
					break;
				case IM_AUTOSTART_COMMAND:
					CallbackAutoIM();  
					break;
					
					
				case FC_START_COMMAND:
					CallbackStartFC();  
					break;
				case FC_STOP_COMMAND:
					CallbackStopFC();    
					break; 
				case FC_GPSRECEIVE_COMMAND:
					CallbackGNSSFC422();    
					break; 	
				case FC_YCRECEIVE_COMMAND:
					CallbackYC(); 
					break;
				case FC_FIRE_CONTROL_COMMAND:
					CallbackFireControl(); 
					break;
				case FC_AUTOSTART_COMMAND:
					CallbackAutoFC();  
					break;
			}
            break;
    }
    return 0;
}

/****�忨�Լ�****/  
void CallbackSelfTest(void)
{
	int selftest_status;  
	selftest_status = module_selftest();
	DataRT.state = SELFTEST_STATE; 
	DataRT.selftest_status = selftest_status;
	Update();
}

/****�˳�ʵʱ������****/ 
void CallbackRTQuit(void)
{
	gDone = 1;
	printf("Quit RT program successfully.\n");
}

/****��λ������λ�����Ͳ��������ļ�****/
void CallbackSendFiles(void)
{
	strcpy(HostUserName, CmdRT.hostUserName);
	strcpy(HostPassword, CmdRT.hostPassword);
	strcpy(FolderPath, CmdRT.hostFolderPath);
	
	//�߲�ģʽ�洢�ļ� 
	if ((CmdRT.statusFileFTP == 0) || (CmdRT.statusFileFTP == 2))
	{
		//�����źŴ洢��429��
		strcpy(FilePath, FolderPath);
		strcat(FilePath, FILE_PATH_HOST_GNSS429);
		ErrorFTP = InetFTPAutoSend(HOST_ADDRESS, HostUserName, HostPassword, FILE_PATH_RT_GNSS429, FilePath, INET_FTP_FILE_TYPE_BINARY);
		if(ErrorFTP < 0)
		{
			printf("Error %d in sending files: GNSS429\n", ErrorFTP);
		}
		
		//����������źŴ洢
		strcpy(FilePath, FolderPath);
		strcat(FilePath, FILE_PATH_HOST_PULSE);
		ErrorFTP = InetFTPAutoSend(HOST_ADDRESS, HostUserName, HostPassword, FILE_PATH_RT_PULSE, FilePath, INET_FTP_FILE_TYPE_BINARY);
		if(ErrorFTP < 0)
		{
			printf("Error %d in sending files: Pulse\n", ErrorFTP);
		}
		
		//�ߵ����RAM�źŴ洢
		strcpy(FilePath, FolderPath);
		strcat(FilePath, FILE_PATH_HOST_RAM);
		ErrorFTP = InetFTPAutoSend(HOST_ADDRESS, HostUserName, HostPassword, FILE_PATH_RT_RAM, FilePath, INET_FTP_FILE_TYPE_BINARY);
		if(ErrorFTP < 0)
		{
			printf("Error %d in sending files: RAM\n", ErrorFTP);
		}
	}
	
	//�ɿ�ģʽ�ļ��洢
	if ((CmdRT.statusFileFTP == 1) || (CmdRT.statusFileFTP == 2))
	{
		/*
		strcpy(FilePath, FolderPath);
		strcat(FilePath, FILE_PATH_HOST_FCGNSS422);
		ErrorFTP = InetFTPAutoSend(HOST_ADDRESS, HostUserName, HostPassword, FILE_PATH_RT_FCGNSS422, FilePath, INET_FTP_FILE_TYPE_BINARY);
		if(ErrorFTP < 0)
		{
			printf("Error %d in sending files: GNSS422 Flight Control\n", ErrorFTP);
		}		
	
		
		//422���ݳ��ȼ���ļ�
		strcpy(FilePath, FolderPath);
		strcat(FilePath, "YC_Lenth_Test.txt");				
		ErrorFTP = InetFTPAutoSend(HOST_ADDRESS, HostUserName, HostPassword, "c:\\YC_Lenth_Test.txt", FilePath, INET_FTP_FILE_TYPE_BINARY);
		if(ErrorFTP < 0)
		{
			printf("Error %d in sending files: YC_Lenth_Test\n", ErrorFTP);
		}		
			*/ 
		
		//ң��ԭʼ�źŴ洢��LVDS TO 422��
		strcpy(FilePath, FolderPath);
		strcat(FilePath, FILE_PATH_HOST_YC);
		ErrorFTP = InetFTPAutoSend(HOST_ADDRESS, HostUserName, HostPassword, FILE_PATH_RT_YC, FilePath, INET_FTP_FILE_TYPE_BINARY);
		if(ErrorFTP < 0)
		{
			printf("Error %d in sending files: YC\n", ErrorFTP);
		}
		
		//�ɿ��źŴ洢
		strcpy(FilePath, FolderPath);
		strcat(FilePath, FILE_PATH_HOST_FC1553);
		ErrorFTP = InetFTPAutoSend(HOST_ADDRESS, HostUserName, HostPassword, FILE_PATH_RT_FC1553, FilePath, INET_FTP_FILE_TYPE_BINARY);
		if(ErrorFTP < 0)
		{
			printf("Error %d in sending files: FC1553\n", ErrorFTP);
		}
		
		//ң��ԭʼ�źŽ����洢
		strcpy(FilePath, FolderPath);
		strcat(FilePath, FILE_PATH_HOST_YC_DECODE);
		ErrorFTP = InetFTPAutoSend(HOST_ADDRESS, HostUserName, HostPassword, FILE_PATH_RT_YC_DECODE, FilePath, INET_FTP_FILE_TYPE_BINARY);
		if(ErrorFTP < 0)
		{
			printf("Error %d in sending files: YC decode\n", ErrorFTP);
		}
	}
	//������Ϸ���ָ��
	if (StatusTcpRT != TCP_INVALID_CONNECTION)
	{
		DataRT.state = FTP_STATE; 
		ServerTCPWrite (StatusTcpRT, &DataRT, sizeof(DataRT), 5000);
	}
}


/****����FIFO�в�����������Ӧ�ļ����߳�****/


 
static int CVICALLBACK ThreadFunctionRecord(void *functionData)
{
	int i, j;
 	int k = 0;  
	//����״̬��ʶ
	int Ap;
	unsigned int BmkData;

	//ң��������
	double NBX, NBY, NBZ;
	double NWX, NWY, NWZ;
	double R0, R1, R2, R3;
	double Yaw, Pitch, Roll;
	double XR, YR, ZR;
	double VRX, VRY, VRZ;
	double PRVX, PRVY, PRVZ;
	double DVOX, DVOY, DVOZ;
	double GX, GY, GZ;
	double T0;
	
	SetProcessorAffinityForThread (kProcessorPool_None, 1, NULL, NULL);
	
	while (!FlagThreadRecord)
	{
		SleepUS (10);
/*		if(k == 100000)
		{
			printf("CountInYC = %lld\t, CountOutYC = %lld\n", CountInYC, CountOutYC);   
			k = 0;
		}
		k++;	
*/		//�洢����429�ź�
		if (CountOutGNSS429 < CountInGNSS429)
		{
			
			if (FlagRecordGNSS429 == FILE_RECORD_START)
			{
				FlagRecordGNSS429 = FILE_RECORD_ACTIVE;
				
				FileHandleRTGNSS429 = fopen (FILE_PATH_RT_GNSS429, "wb");
	
				fprintf(FileHandleRTGNSS429, "PPS����ʱ��\t");
				fprintf(FileHandleRTGNSS429, "GNSS����ʱ��\t");
				fprintf(FileHandleRTGNSS429, "GNSS��ʱ��\t");
				fprintf(FileHandleRTGNSS429, "��λ����\t");
				fprintf(FileHandleRTGNSS429, "������\t");
				fprintf(FileHandleRTGNSS429, "γ��\t");
				fprintf(FileHandleRTGNSS429, "����\t");
				fprintf(FileHandleRTGNSS429, "�߶�\t");
				fprintf(FileHandleRTGNSS429, "PDOP\t");
				fprintf(FileHandleRTGNSS429, "����X\t");
				fprintf(FileHandleRTGNSS429, "����Y\t");
				fprintf(FileHandleRTGNSS429, "����Z\t");
				fprintf(FileHandleRTGNSS429, "�ٶ�Vx\t");
				fprintf(FileHandleRTGNSS429, "�ٶ�Vy\t");
				fprintf(FileHandleRTGNSS429, "�ٶ�Vz\t");
				for (i = 0; i < SV_NUM_RCVMAX; i ++) 
				{
					fprintf(FileHandleRTGNSS429, "ͨ��%d���Ǳ��\t", i+1);
					fprintf(FileHandleRTGNSS429, "ͨ��%d�����\t", i+1);
					fprintf(FileHandleRTGNSS429, "ͨ��%dα��\t", i+1);
					fprintf(FileHandleRTGNSS429, "ͨ��%dα����\t", i+1);
					fprintf(FileHandleRTGNSS429, "ͨ��%d��������X\t", i+1);
					fprintf(FileHandleRTGNSS429, "ͨ��%d��������Y\t", i+1);
					fprintf(FileHandleRTGNSS429, "ͨ��%d��������Z\t", i+1);
					fprintf(FileHandleRTGNSS429, "ͨ��%d�����ٶ�Vx\t", i+1);
					fprintf(FileHandleRTGNSS429, "ͨ��%d�����ٶ�Vy\t", i+1);
					fprintf(FileHandleRTGNSS429, "ͨ��%d�����ٶ�Vz\t", i+1);
				}
				fprintf(FileHandleRTGNSS429, "\r\n");
				
				printf("File record: GNSS429 start.\n");
			}
			
			if (IndexOutGNSS429 % 10 == 0)   //���� 
			{
				DataRT = *(DataTemp + IndexOutGNSS429);
				DataRT.state = GNSS429_STATE;
				Update();
			}
			
			fprintf(FileHandleRTGNSS429, "%f\t", (DataTemp + IndexOutGNSS429)->pps_time);
			
			fprintf(FileHandleRTGNSS429,"%f\t", (DataTemp + IndexOutGNSS429)->gps_time);  			

			fprintf(FileHandleRTGNSS429,"%f\t", (DataTemp + IndexOutGNSS429)->RcvTime);

			//���Ƕ�λ����
			if (((DataTemp + IndexOutGNSS429)->sFixQuality[0] == '0') && ((DataTemp + IndexOutGNSS429)->sFixQuality[1] == '0'))
			{
				(DataTemp + IndexOutGNSS429)->FixQuality = 0;
			}
			else if (((DataTemp + IndexOutGNSS429)->sFixQuality[0] == '0') && ((DataTemp + IndexOutGNSS429)->sFixQuality[1] == '1'))
			{
				(DataTemp + IndexOutGNSS429)->FixQuality = 1;
			}
			else if (((DataTemp + IndexOutGNSS429)->sFixQuality[0] == '1') && ((DataTemp + IndexOutGNSS429)->sFixQuality[1] == '0'))
			{
				(DataTemp + IndexOutGNSS429)->FixQuality = 2;
			}
			else if (((DataTemp + IndexOutGNSS429)->sFixQuality[0] == '1') && ((DataTemp + IndexOutGNSS429)->sFixQuality[1] == '1'))
			{
				(DataTemp + IndexOutGNSS429)->FixQuality = 3;
			}
			else;
			fprintf(FileHandleRTGNSS429, "%d\t", (DataTemp + IndexOutGNSS429)->FixQuality);

			fprintf(FileHandleRTGNSS429, "%d\t", (int)(DataTemp + IndexOutGNSS429)->SVs);

			fprintf(FileHandleRTGNSS429,"%f\t", (DataTemp + IndexOutGNSS429)->Lat);
			fprintf(FileHandleRTGNSS429,"%f\t", (DataTemp + IndexOutGNSS429)->Lon);
			fprintf(FileHandleRTGNSS429,"%f\t", (DataTemp + IndexOutGNSS429)->Alt);
			fprintf(FileHandleRTGNSS429,"%f\t", (DataTemp + IndexOutGNSS429)->PDOP);

			fprintf(FileHandleRTGNSS429,"%f\t", (DataTemp + IndexOutGNSS429)->X);
			fprintf(FileHandleRTGNSS429,"%f\t", (DataTemp + IndexOutGNSS429)->Y);
			fprintf(FileHandleRTGNSS429,"%f\t", (DataTemp + IndexOutGNSS429)->Z);

			fprintf(FileHandleRTGNSS429,"%f\t", (DataTemp + IndexOutGNSS429)->Vx);
			fprintf(FileHandleRTGNSS429,"%f\t", (DataTemp + IndexOutGNSS429)->Vy);
			fprintf(FileHandleRTGNSS429,"%f\t", (DataTemp + IndexOutGNSS429)->Vz);

			for (i = 0; i < SV_NUM_RCVMAX; i ++) 
			{
				fprintf(FileHandleRTGNSS429,"%d\t", (DataTemp + IndexOutGNSS429)->m_SVsInfo[i].nNo);
				fprintf(FileHandleRTGNSS429,"%d\t", (int)(DataTemp + IndexOutGNSS429)->m_SVsInfo[i].SNR);
				fprintf(FileHandleRTGNSS429,"%f\t", (DataTemp + IndexOutGNSS429)->m_SVsInfo[i].weiju);
				fprintf(FileHandleRTGNSS429,"%f\t", (DataTemp + IndexOutGNSS429)->m_SVsInfo[i].weijulv);
				fprintf(FileHandleRTGNSS429,"%f\t", (DataTemp + IndexOutGNSS429)->m_SVsInfo[i].X);
				fprintf(FileHandleRTGNSS429,"%f\t", (DataTemp + IndexOutGNSS429)->m_SVsInfo[i].Y);
				fprintf(FileHandleRTGNSS429,"%f\t", (DataTemp + IndexOutGNSS429)->m_SVsInfo[i].Z);
				fprintf(FileHandleRTGNSS429,"%f\t", (DataTemp + IndexOutGNSS429)->m_SVsInfo[i].Vx);
				fprintf(FileHandleRTGNSS429,"%f\t", (DataTemp + IndexOutGNSS429)->m_SVsInfo[i].Vy);
				fprintf(FileHandleRTGNSS429,"%f\t", (DataTemp + IndexOutGNSS429)->m_SVsInfo[i].Vz);
			}

			fprintf(FileHandleRTGNSS429, "\r\n");
			
			//FIFO���
			CountOutGNSS429 ++;
			IndexOutGNSS429 ++;
			if (IndexOutGNSS429 >= MEMORY_BANK_SIZE)
				IndexOutGNSS429 = 0;
			
		}
		else
		{
			if (FlagRecordGNSS429 == FILE_RECORD_STOP)
			{
				FlagRecordGNSS429 = FILE_RECORD_INACTIVE;
				
				CountOutGNSS429 = 0;
				CountInGNSS429 = 0;
				
				if(FileHandleRTGNSS429 != NULL)
				{
					fclose (FileHandleRTGNSS429);
					printf("File record: GNSS429 over.\n");				
				}
			}	
		}
		
		
		//��¼�ߵ������ź�
		if (CountOutPulse < CountInPulse)
		{
			if (FlagRecordPulse == FILE_RECORD_START)
			{
				FlagRecordPulse = FILE_RECORD_ACTIVE;
				
    			FileHandleRTPulse = fopen (FILE_PATH_RT_PULSE, "wb");
				
				fprintf(FileHandleRTPulse, "�켣ʱ��\t");
				fprintf(FileHandleRTPulse, "���嵽��ʱ��\t");
				
				fprintf(FileHandleRTPulse, "����������X\t");
				fprintf(FileHandleRTPulse, "����������Y\t");
				fprintf(FileHandleRTPulse, "����������Z\t");
				fprintf(FileHandleRTPulse, "�Ӽ�������X\t");
				fprintf(FileHandleRTPulse, "�Ӽ�������Y\t");
				fprintf(FileHandleRTPulse, "�Ӽ�������Z\t");				
				
				fprintf(FileHandleRTPulse, "���ݽ�����X\t");
				fprintf(FileHandleRTPulse, "���ݽ�����Y\t");
				fprintf(FileHandleRTPulse, "���ݽ�����Z\t");
				fprintf(FileHandleRTPulse, "���ٶ�X\t");
				fprintf(FileHandleRTPulse, "���ٶ�Y\t");
				fprintf(FileHandleRTPulse, "���ٶ�Z\t");
				fprintf(FileHandleRTPulse, "λ��X\t");
				fprintf(FileHandleRTPulse, "λ��Y\t");
				fprintf(FileHandleRTPulse, "λ��Z\t");
				fprintf(FileHandleRTPulse, "��������(����)X\t");
				fprintf(FileHandleRTPulse, "��������(����)Y\t");
				fprintf(FileHandleRTPulse, "��������(����)Z\t");
				fprintf(FileHandleRTPulse, "�Ӽ�����(����)X\t");
				fprintf(FileHandleRTPulse, "�Ӽ�����(����)Y\t");
				fprintf(FileHandleRTPulse, "�Ӽ�����(����)Z\t");
				fprintf(FileHandleRTPulse, "\r\n");
				
				printf("File record: Pulse start.\n");
			}
			
			// Update
			if ((DataTemp + IndexOutPulse)->flagPulseAccum == 1)
			{
				DataRT = *(DataTemp + IndexOutPulse);
				DataRT.state = PULSE_STATE;
				Update();
			}
			
			fprintf(FileHandleRTPulse,"%f\t", (DataTemp + IndexOutPulse)->TraceTime);
			
			fprintf(FileHandleRTPulse,"%f\t", (DataTemp + IndexOutPulse)->pulse_time);   
			
			fprintf(FileHandleRTPulse,"%d\t", ((DataTemp + IndexOutPulse)->asxp - (DataTemp + IndexOutPulse)->asxn) );
			fprintf(FileHandleRTPulse,"%d\t", ((DataTemp + IndexOutPulse)->asyp - (DataTemp + IndexOutPulse)->asyn) );
			fprintf(FileHandleRTPulse,"%d\t", ((DataTemp + IndexOutPulse)->aszp - (DataTemp + IndexOutPulse)->aszn) );
			fprintf(FileHandleRTPulse,"%d\t", ((DataTemp + IndexOutPulse)->laxp - (DataTemp + IndexOutPulse)->laxn) );
			fprintf(FileHandleRTPulse,"%d\t", ((DataTemp + IndexOutPulse)->layp - (DataTemp + IndexOutPulse)->layn) );
			fprintf(FileHandleRTPulse,"%d\t", ((DataTemp + IndexOutPulse)->lazp - (DataTemp + IndexOutPulse)->lazn) );			
			
			fprintf(FileHandleRTPulse,"%f\t", ((double)(DataTemp + IndexOutPulse)->asxp - (double)(DataTemp + IndexOutPulse)->asxn) * 3.33 / 3600.0 / 0.005);
			fprintf(FileHandleRTPulse,"%f\t", ((double)(DataTemp + IndexOutPulse)->asyp - (double)(DataTemp + IndexOutPulse)->asyn) * 3.33 / 3600.0 / 0.005);
			fprintf(FileHandleRTPulse,"%f\t", ((double)(DataTemp + IndexOutPulse)->aszp - (double)(DataTemp + IndexOutPulse)->aszn) * 3.33 / 3600.0 / 0.005);
			fprintf(FileHandleRTPulse,"%f\t", ((double)(DataTemp + IndexOutPulse)->laxp - (double)(DataTemp + IndexOutPulse)->laxn) * 0.016/ 0.005);
			fprintf(FileHandleRTPulse,"%f\t", ((double)(DataTemp + IndexOutPulse)->layp - (double)(DataTemp + IndexOutPulse)->layn) * 0.016/ 0.005);
			fprintf(FileHandleRTPulse,"%f\t", ((double)(DataTemp + IndexOutPulse)->lazp - (double)(DataTemp + IndexOutPulse)->lazn) * 0.016/ 0.005);
			
			
			fprintf(FileHandleRTPulse,"%f\t", (DataTemp + IndexOutPulse)->CraftPosition[0]);
			fprintf(FileHandleRTPulse,"%f\t", (DataTemp + IndexOutPulse)->CraftPosition[1]);
			fprintf(FileHandleRTPulse,"%f\t", (DataTemp + IndexOutPulse)->CraftPosition[2]);
			fprintf(FileHandleRTPulse,"%d\t", (DataTemp + IndexOutPulse)->CraftGPulseOut[0]);
			fprintf(FileHandleRTPulse,"%d\t", (DataTemp + IndexOutPulse)->CraftGPulseOut[1]);
			fprintf(FileHandleRTPulse,"%d\t", (DataTemp + IndexOutPulse)->CraftGPulseOut[2]);
			fprintf(FileHandleRTPulse,"%d\t", (DataTemp + IndexOutPulse)->CraftFPulseOut[0]);
			fprintf(FileHandleRTPulse,"%d\t", (DataTemp + IndexOutPulse)->CraftFPulseOut[1]);
			fprintf(FileHandleRTPulse,"%d\t", (DataTemp + IndexOutPulse)->CraftFPulseOut[2]);
			
			fprintf(FileHandleRTPulse, "\r\n");
			
			// FIFO check
			CountOutPulse ++;
			IndexOutPulse ++;
			if (IndexOutPulse >= MEMORY_BANK_SIZE)
				IndexOutPulse = 0;
		}
		else
		{
			if (FlagRecordPulse == FILE_RECORD_STOP)
			{
				FlagRecordPulse = FILE_RECORD_INACTIVE;
				
				CountOutPulse = 0;
				CountInPulse = 0;
				
				if(FileHandleRTPulse != NULL)
				{
					fclose (FileHandleRTPulse);
					printf("File record: Pulse over.\n");				
				}
			}	
		}
		
		//��¼ң�����ݼ���������
		if (CountOutYC < CountInYC)
		{		  
			if (FlagRecordYC == FILE_RECORD_START)
			{
				FlagRecordYC = FILE_RECORD_ACTIVE;
				
    			FileHandleRTYC = fopen (FILE_PATH_RT_YC, "wb");
			
				for(int i = 0; i < 256; i++)
				{
					fprintf(FileHandleRTYC, "Ox%02x\t", i);				
				}				
			
				FileHandleRTYCDecode = fopen (FILE_PATH_RT_YC_DECODE, "wb");  				

				fprintf(FileHandleRTYCDecode, "%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t",
					    "ʱ���־","��תʧ׼��","ƫ��ʧ׼��","����ʧ׼��","12ms�Ӽ�����","12ms�Ӽ�����","12ms�Ӽ�����",
						"12ms��������","12ms��������","12ms��������");

				fprintf(FileHandleRTYCDecode, "%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t",
					    "��Ԫ��R0","��Ԫ��R1","��Ԫ��R2","��Ԫ��R3",
						"��̬Yaw","��̬Pitch","��̬Roll","λ��X","λ��Y","λ��Z");		
		
				fprintf(FileHandleRTYCDecode, "%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\n",
					    "�ٶ�X","�ٶ�Y","�ٶ�Z","PRVX","PRVY","PRVZ","DVOX","DVOY","DVOZ",
						"�������ٶ�0","�������ٶ�1","�������ٶ�2","T0");		
						
				printf("File record: YC start.\n");
			}
			

			//ң�����ݽ���
			NBX = IntToDouble((DataTemp + IndexOutYC)->dataYC[0x61], 32768);  
			NBY = IntToDouble((DataTemp + IndexOutYC)->dataYC[0x62], 32768);  
			NBZ = IntToDouble((DataTemp + IndexOutYC)->dataYC[0x63], 32768);  
		
			NWX = IntToDouble((DataTemp + IndexOutYC)->dataYC[0x64], 32768);
			NWY = IntToDouble((DataTemp + IndexOutYC)->dataYC[0x65], 32768);
			NWZ = IntToDouble((DataTemp + IndexOutYC)->dataYC[0x66], 32768);
			
			R0 = IntToDouble((DataTemp + IndexOutYC)->dataYC[0x79], 1);
			R1 = IntToDouble((DataTemp + IndexOutYC)->dataYC[0x7A], 1);
			R2 = IntToDouble((DataTemp + IndexOutYC)->dataYC[0x7B], 1);
			R3 = IntToDouble((DataTemp + IndexOutYC)->dataYC[0x7C], 1);
			
			Yaw   =-atan2(2*(R1*R3-R2*R0),R0*R0+R1*R1-R2*R2-R3*R3)*180/pi;  			
			Pitch = asin(2*(R1*R2+R0*R3))*180/pi;                           			
			Roll  =-atan2(2*(R2*R3-R1*R0),R0*R0-R1*R1+R2*R2-R3*R3)*180/pi;  			
			
			XR = IntToDouble((DataTemp + IndexOutYC)->dataYC[0x76], 204800);
			YR = IntToDouble((DataTemp + IndexOutYC)->dataYC[0x77], 204800);
			ZR = IntToDouble((DataTemp + IndexOutYC)->dataYC[0x78], 204800);
			
			VRX = IntToDouble((DataTemp + IndexOutYC)->dataYC[0x5A], 3200);
			VRY = IntToDouble((DataTemp + IndexOutYC)->dataYC[0x5B], 3200);
			VRZ = IntToDouble((DataTemp + IndexOutYC)->dataYC[0x5C], 3200);
			
			PRVX = IntToDouble((DataTemp + IndexOutYC)->dataYC[0x30], 200);
			PRVY = IntToDouble((DataTemp + IndexOutYC)->dataYC[0x31], 200);
			PRVZ = IntToDouble((DataTemp + IndexOutYC)->dataYC[0x32], 200);
			
			DVOX = IntToDouble((DataTemp + IndexOutYC)->dataYC[0x0F], 200);
			DVOY = IntToDouble((DataTemp + IndexOutYC)->dataYC[0x10], 200); 
			DVOZ = IntToDouble((DataTemp + IndexOutYC)->dataYC[0x11], 200);
			
			GX = IntToDouble((DataTemp + IndexOutYC)->dataYC[0x23], 12.5);
			GY = IntToDouble((DataTemp + IndexOutYC)->dataYC[0x24], 12.5);
			GZ = IntToDouble((DataTemp + IndexOutYC)->dataYC[0x25], 12.5);	
			
			T0 = IntToDouble((DataTemp + IndexOutYC)->dataYC[0x3D], 2048);
			
			// Update
			if (IndexOutYC % 100 == 0)
			{
				DataRT = *(DataTemp + IndexOutYC);
				
				DataRT.state = YC_STATE;
				Update();
			}
		
			//ң�������ļ��洢
			fprintf(FileHandleRTYC,"%.3f\t", (DataTemp + IndexOutYC)->timeYC);
			
			for(j = 0; j < YC_LENGTH_BYTE / 2 - 1; j++)
			{
				fprintf (FileHandleRTYC, "%04x\t", (DataTemp + IndexOutYC)->dataYC[j]); 
			}
			
			fprintf(FileHandleRTYC, "\r\n");    
			
			//�ҷɶ����������ֱ�־
	//		Ap = (((DataTemp + IndexOutYC)->dataYC[0x00]) & 0x8000)>>15;
			//ʱ��
			fprintf(FileHandleRTYCDecode, "%.3f\t", (DataTemp + IndexOutYC)->timeYC);   
			
	//		if(!Ap)
	//		{
				//ʧ׼�ǹ���
				fprintf(FileHandleRTYCDecode, "%f\t", IntToDouble((DataTemp + IndexOutYC)->dataYC[0x12], (180.0 / pi)));
				fprintf(FileHandleRTYCDecode, "%f\t", IntToDouble((DataTemp + IndexOutYC)->dataYC[0x13], (180.0 / pi)));
				fprintf(FileHandleRTYCDecode, "%f\t", IntToDouble((DataTemp + IndexOutYC)->dataYC[0x14], (180.0 / pi)));
			
				//12ms���ٶȼ�������
				fprintf(FileHandleRTYCDecode, "%f\t", NWX);
				fprintf(FileHandleRTYCDecode, "%f\t", NWY);
				fprintf(FileHandleRTYCDecode, "%f\t", NWZ);
				
				//12ms���������� 
				fprintf(FileHandleRTYCDecode, "%f\t", NBX);
				fprintf(FileHandleRTYCDecode, "%f\t", NBY);
				fprintf(FileHandleRTYCDecode, "%f\t", NBZ);				
	
				//��Ԫ��
				fprintf(FileHandleRTYCDecode, "%f\t", R0);
				fprintf(FileHandleRTYCDecode, "%f\t", R1);
				fprintf(FileHandleRTYCDecode, "%f\t", R2);		
				fprintf(FileHandleRTYCDecode, "%f\t", R3);
			
				//��̬
				fprintf(FileHandleRTYCDecode, "%f\t", Yaw  );
				fprintf(FileHandleRTYCDecode, "%f\t", Pitch);
				fprintf(FileHandleRTYCDecode, "%f\t", Roll );
			  				
				//λ��		XR YR ZR
				fprintf(FileHandleRTYCDecode, "%f\t", XR);
				fprintf(FileHandleRTYCDecode, "%f\t", YR);
				fprintf(FileHandleRTYCDecode, "%f\t", ZR);	
				
				//�ٶ�		VRX 
				fprintf(FileHandleRTYCDecode, "%f\t", VRX);
				fprintf(FileHandleRTYCDecode, "%f\t", VRY);
				fprintf(FileHandleRTYCDecode, "%f\t", VRZ);
				
				//PRVX
				fprintf(FileHandleRTYCDecode, "%f\t", PRVX);
				fprintf(FileHandleRTYCDecode, "%f\t", PRVY);
				fprintf(FileHandleRTYCDecode, "%f\t", PRVZ);
			
				//DVOX
				fprintf(FileHandleRTYCDecode, "%f\t", DVOX);
				fprintf(FileHandleRTYCDecode, "%f\t", DVOY);
				fprintf(FileHandleRTYCDecode, "%f\t", DVOZ);	
				//G
				fprintf(FileHandleRTYCDecode, "%f\t", GX);
				fprintf(FileHandleRTYCDecode, "%f\t", GY);
				fprintf(FileHandleRTYCDecode, "%f\t", GZ);					
				
				fprintf(FileHandleRTYCDecode, "%f\t", T0);
				
				fprintf(FileHandleRTYCDecode, "\n");     			   		 
	/*		}
			else
			{
				//��ϵ����ٶ�
				fprintf(FileHandleRTYCDecode, "%f\t", IntToDouble((DataTemp + IndexOutYC)->dataYC[0x5A], 1600));   
				fprintf(FileHandleRTYCDecode, "%f\t", IntToDouble((DataTemp + IndexOutYC)->dataYC[0x5B], 1600));
				fprintf(FileHandleRTYCDecode, "%f\t", IntToDouble((DataTemp + IndexOutYC)->dataYC[0x5C], 1600));

				//�ߵ��ٶ�
				fprintf(FileHandleRTYCDecode, "%f\t", IntToDouble((DataTemp + IndexOutYC)->dataYC[0x9F], 1600));
				fprintf(FileHandleRTYCDecode, "%f\t", IntToDouble((DataTemp + IndexOutYC)->dataYC[0xA0], 1600));
				fprintf(FileHandleRTYCDecode, "%f\t", IntToDouble((DataTemp + IndexOutYC)->dataYC[0xA1], 1600));
				
				fprintf(FileHandleRTYCDecode, "\n"); 
			}
	 */
			// FIFO check
			CountOutYC ++;
			IndexOutYC ++;
			if (IndexOutYC >= MEMORY_BANK_SIZE)
				IndexOutYC = 0;
		}
		else
		{
			if (FlagRecordYC == FILE_RECORD_STOP)
			{
				FlagRecordYC = FILE_RECORD_INACTIVE;
				
				CountOutYC = 0;
				CountInYC = 0;
				IndexOutYC = 0;
				
				if( (FileHandleRTYC != NULL) && (FileHandleRTYCDecode != NULL))
				{
					fclose (FileHandleRTYC);
					fclose (FileHandleRTYCDecode);
				
					printf("File record: YC over.\n");				
				}
			}	
		}
		
		
		//��¼�������
		if (CountOutFC1553 < CountInFC1553)
		{
			if (FlagRecordFC1553 == FILE_RECORD_START)
			{
				FlagRecordFC1553 = FILE_RECORD_ACTIVE;
				
    			FileHandleRTFC1553 = fopen (FILE_PATH_RT_FC1553, "wb");
				
				printf("File record: FC1553 start.\n");
			}
			
			// Update
			DataRT = *(DataTemp + IndexOutFC1553);
			DataRT.state = FC1553_STATE;
			Update();
			
			fprintf(FileHandleRTFC1553, "%f\t", (DataTemp + IndexOutFC1553)->timeFC1553);
			fprintf(FileHandleRTFC1553, "%s\t", (DataTemp + IndexOutFC1553)->dataType);
		
			if(strcmp((DataTemp + IndexOutFC1553)->dataType, "30R") == 0)
			{   
				fprintf(FileHandleRTFC1553, "%d\t", 30); 
				for (i = 0; i < 29; i ++)
				{
					fprintf(FileHandleRTFC1553, "%d\t", (DataTemp + IndexOutFC1553)->dataFlightControl[i]);
				}			
			}
			for (i = 0; i < 30; i ++)
			{
				fprintf(FileHandleRTFC1553, "%d\t", (DataTemp + IndexOutFC1553)->dataFlightControl[i]);
			}
			fprintf(FileHandleRTFC1553, "\r\n");
			
			// FIFO check
			CountOutFC1553 ++;
			IndexOutFC1553 ++;
			if (IndexOutFC1553 >= MEMORY_BANK_SIZE)
				IndexOutFC1553 = 0;
		}
		else
		{
			if (FlagRecordFC1553 == FILE_RECORD_STOP)
			{
				FlagRecordFC1553 = FILE_RECORD_INACTIVE;
				
				CountOutFC1553 = 0;
				CountInFC1553 = 0;
				
				if(FileHandleRTFC1553 != NULL)
				{
					fclose (FileHandleRTFC1553);
					printf("File record: FC1553 over.\n");				
				}
			}	
		}
		
	} // while
	return 0;
}
//============================================================================== 



//============================================================================== 
//
//  �߲�����ģʽ
//
//============================================================================== 

/****��ʼ�߲�����****/

void CallbackStartIM(void)
{
	printf("IM: Start\n");
	// Start 422 pulse first will generate error
	gnss429StartReceive();
	Delay(1);
	pulseStartReceive();

}

/****ֹͣ�߲�����****/

void CallbackStopIM(void)
{
	printf("IM: Stop\n");
	gnss429StopReceive();
	Delay(1);
	pulseStopReceive();
}


/****�߲�ģʽ�Զ���ʼ�����****/

void CallbackAutoIM(void)
{
	if (CmdRT.statusAutostartIM == 1)
	{
		RFMMCThreadEnd = 0;
		
		CmtScheduleThreadPoolFunction (gThreadPool, ThreadFunctionAutoIM, NULL, &ThreadFunctionIdIM);
		
		printf("Auto mode start. (IM)\n");
	}
	else
	{
		RFMMCThreadEnd = 1;
		
		CmtWaitForThreadPoolFunctionCompletion (gThreadPool, ThreadFunctionIdIM, OPT_TP_PROCESS_EVENTS_WHILE_WAITING);
		CmtReleaseThreadPoolFunctionID (gThreadPool, ThreadFunctionIdIM);
		
		printf("Auto mode stop. (IM)\n");
	}
}


/****�߲�ģʽ�Զ������߳�****/

static int CVICALLBACK ThreadFunctionAutoIM(void *functionData)
{
	unsigned long long timeUS;
	double timeMS;
	
	SetProcessorAffinityForThread (kProcessorPool_None, 1, NULL, NULL);
	
	while (!RFMMCThreadEnd)
	{
		SleepUS (100);
		
		// ��ʼ�Զ�����
		if (RFMMCIntRcv == RFM_CMD_MC_START)
		{
			RFMMCIntRcv = RFM_CMD_MC_NULL;
			
			// Send auto start signal
			if (StatusTcpRT != TCP_INVALID_CONNECTION)
			{
				DataRT.state = AUTO_STATE;
				DataRT.statusAuto = AUTO_STATUS_IM_ON;
				ServerTCPWrite (StatusTcpRT, &DataRT, sizeof(DataRT), 5000);
			}
			Delay(1);
			CallbackStartIM();
		}
		// �����Զ�����
		else if (RFMMCIntRcv == RFM_CMD_MC_STOP)
		{
			RFMMCIntRcv = RFM_CMD_MC_NULL;
			
			// Send auto stop signal
			if (StatusTcpRT != TCP_INVALID_CONNECTION)
			{
				DataRT.state = AUTO_STATE;
				DataRT.statusAuto = AUTO_STATUS_IM_OFF;
				ServerTCPWrite (StatusTcpRT, &DataRT, sizeof(DataRT), 5000);
			}
			Delay(1);
			CallbackStopIM();
			
			DataRT.state = AUTO_STATE;  
			DataRT.statusAuto = AUTO_PANEL_RESET;
			ServerTCPWrite (StatusTcpRT, &DataRT, sizeof(DataRT), 5000);
			
			RFMMCThreadEnd = 1;
			CmtReleaseThreadPoolFunctionID (gThreadPool, ThreadFunctionIdIM);
		
			printf("Auto mode stop. (IM)\n");
		}
		// ��ʼ�������»���IMU����
		else if (RFMMCIntRcv == RFM_CMD_MC_IMU)
		{
			RFMMCIntRcv = RFM_CMD_MC_NULL;
			
			DataRT.wibb[0] = RFMFireControlDataRx.wibb[0];
			DataRT.wibb[1] = RFMFireControlDataRx.wibb[1];
			DataRT.wibb[2] = RFMFireControlDataRx.wibb[2];
			
			DataRT.fb[0] = RFMFireControlDataRx.fb[0];
			DataRT.fb[1] = RFMFireControlDataRx.fb[1];
			DataRT.fb[2] = RFMFireControlDataRx.fb[2];
			
			timeUS = GetTimeUS (); 
			timeMS = (double)timeUS / 1000.0;
			DataRT.timeIMU = timeMS;
			DataRT.state = IMU_STATE;
			
			Update();
		}
		else;
	}
	
	return 0;
}


/****����429�źŽ���****/

void CallbackGNSS429(void)
{
    int flagTest;
	int status;
	int send_byte; 	
    flagTest = CmdRT.statusGNSS429;
	if(flagTest)
	{   
		gnss429StartReceive();   //��ʼ���������ź�
	}
	else
	{
		gnss429StopReceive();	 //ֹͣ���������ź�
	}
 	 
	//InstallComCallback (Uart.comValue, LWRS_RXCHAR,0, 0, (void *)uartRevData, 0);
}

/****�ߵ���Ʒ�����źŽ���****/
void CallbackPulse(void)
{
    int flagTest;
	int status;
	int send_byte; 	
	
    flagTest = CmdRT.statusPulse;
	if(flagTest)
	{   
		pulseStartReceive(); 	   //��ʼ���������ź�
	}
	else
	{							   
		pulseStopReceive();		   //ֹͣ���������ź�  
	}
	//InstallComCallback (Uart.comValue, LWRS_RXCHAR,0, 0, (void *)uartRevData, 0);
}

//==============================================================================




//==============================================================================
//
// �ɿ�����ģʽ 
//
//==============================================================================

/****��ʼ���в���****/
void CallbackStartFC(void)
{
	//gnssfc422StartReceive();
	
	ycStartReceive();
	
	FlagFireControlMode = CmdRT.modeFireControl;
	
	fc1553Start(); 
}

/****ֹͣ���в���****/
void CallbackStopFC(void)
{
    //gnssfc422StopReceive();
	
	FlagFireControlMode = CmdRT.modeFireControl;
	fc1553Stop();
	
	ycStopReceive();
	
    FileHandleLenthTest = fopen ("c:\\YC_Lenth_Test.txt", "wb");
	
	fclose(FileHandleLenthTest);
}

/****�Զ����ֶ�ģʽѡ��****/
void CallbackAutoFC(void)
{
	if (CmdRT.statusAutostartFC == 1)
	{
		RFMMCThreadEnd = 0;
		
		CmtScheduleThreadPoolFunction (gThreadPool, ThreadFunctionAutoFC, NULL, &ThreadFunctionIdFC);
		
		printf("Auto mode start. (FC)\n");
	}
	else
	{
		RFMMCThreadEnd = 1;
		
		CmtWaitForThreadPoolFunctionCompletion (gThreadPool, ThreadFunctionIdFC, OPT_TP_PROCESS_EVENTS_WHILE_WAITING);
		CmtReleaseThreadPoolFunctionID (gThreadPool, ThreadFunctionIdFC);
		
		printf("Auto mode stop. (FC)\n");
	}
	
}

/****�Զ������߳� (FC)****/
static int CVICALLBACK ThreadFunctionAutoFC(void *functionData)
{
	unsigned long long timeUS;
	double timeMS;
	
	//CPU1
	SetProcessorAffinityForThread (kProcessorPool_None, 1, NULL, NULL);
	
	while (!RFMMCThreadEnd)
	{
		SleepUS (10);
		
		// ��ʼ�Զ�����
		if (RFMMCIntRcv == RFM_CMD_MC_START)
		{
			RFMMCIntRcv = RFM_CMD_MC_NULL;
			
			// Send auto start signal
			if (StatusTcpRT != TCP_INVALID_CONNECTION)
			{
				DataRT.state = AUTO_STATE;
				DataRT.statusAuto = AUTO_STATUS_FC_ON;
				ServerTCPWrite (StatusTcpRT, &DataRT, sizeof(DataRT), 5000);
			}
			Delay(3);
			CallbackStartFC();
		}
		// �����Զ�����
		else if (RFMMCIntRcv == RFM_CMD_MC_STOP)
		{
			RFMMCIntRcv = RFM_CMD_MC_NULL;
			
			// Send auto stop signal
			if (StatusTcpRT != TCP_INVALID_CONNECTION)
			{
				DataRT.state = AUTO_STATE;
				DataRT.statusAuto = AUTO_STATUS_FC_OFF;
				ServerTCPWrite (StatusTcpRT, &DataRT, sizeof(DataRT), 5000);
			}
			Delay(1);
			CallbackStopFC();
			//��λ��������
			DataRT.state = AUTO_STATE;  
			DataRT.statusAuto = AUTO_PANEL_RESET;
			ServerTCPWrite (StatusTcpRT, &DataRT, sizeof(DataRT), 5000);
			
			CmdRT.statusAutostartFC = 0;
			
			RFMMCThreadEnd = 1;
		
			CmtReleaseThreadPoolFunctionID (gThreadPool, ThreadFunctionIdFC);
		
			printf("Auto mode stop. (FC)\n");
		}
		// ��ʼ�������»���IMU����
		else if (RFMMCIntRcv == RFM_CMD_MC_IMU)
		{
			RFMMCIntRcv = RFM_CMD_MC_NULL;
		}
		// ��ʼ�������»���Fire Control����
		else if (RFMMCIntRcv == RFM_CMD_MC_FIRE_CONTROL)
		{
			RFMMCIntRcv = RFM_CMD_MC_NULL;		
			
			fprintf(FileHandleTest, "%f\t", RFMFireControlDataRx.CraftNavigationStepSize);
			fprintf(FileHandleTest, "%f\t", RFMFireControlDataRx.FcsPos[0][0]);
			fprintf(FileHandleTest, "%f\t", RFMFireControlDataRx.FcsPos[1][0]);
			fprintf(FileHandleTest, "%f\t", RFMFireControlDataRx.FcsPos[2][0]);			
			fprintf(FileHandleTest, "%f\t", RFMFireControlDataRx.FcsVel[0][0]);
			fprintf(FileHandleTest, "%f\t", RFMFireControlDataRx.FcsVel[1][0]);
			fprintf(FileHandleTest, "%f\t", RFMFireControlDataRx.FcsVel[2][0]);
			fprintf(FileHandleTest, "%f\t", RFMFireControlDataRx.FcsQtn[0][0]);
			fprintf(FileHandleTest, "%f\t", RFMFireControlDataRx.FcsQtn[1][0]);
			fprintf(FileHandleTest, "%f\t", RFMFireControlDataRx.FcsQtn[2][0]);
			fprintf(FileHandleTest, "%f\t", RFMFireControlDataRx.FcsQtn[3][0]);
			fprintf(FileHandleTest, "%f\t", RFMFireControlDataRx.JieHuoJuLi);
			fprintf(FileHandleTest, "%f\t", RFMFireControlDataRx.TeZhongDanDaoJiaoDu);
			fprintf(FileHandleTest, "%f\t", RFMFireControlDataRx.MissileMountPosition[0][0]);
			fprintf(FileHandleTest, "%f\t", RFMFireControlDataRx.MissileMountPosition[1][0]);
			fprintf(FileHandleTest, "%f\t", RFMFireControlDataRx.MissileMountPosition[2][0]);
			fprintf(FileHandleTest, "%f\t", RFMFireControlDataRx.FcsGravity[0][0]);
			fprintf(FileHandleTest, "%f\t", RFMFireControlDataRx.FcsGravity[1][0]); 
			fprintf(FileHandleTest, "%f\t", RFMFireControlDataRx.FcsGravity[2][0]);
			fprintf(FileHandleTest, "%f\t", RFMFireControlDataRx.FcsLongitude);
			fprintf(FileHandleTest, "%f\t", RFMFireControlDataRx.FcsLatitude);
			
			fprintf(FileHandleTest, "%f\n", RFMFireControlDataRx.TuoLiGuoZai); 
			
		}
		else;
	}
	
	return 0;
}

/****���ͻ������****/
void CallbackFireControl(void)
{
    int test_flag;
	int status;
	int send_byte; 	
    test_flag = CmdRT.statusFireControl;
	if(test_flag)
	{   
		FlagFireControlMode = CmdRT.modeFireControl;
		fc1553Start();	   //��ʼ���ͻ������ 
	}
	else
	{
		FlagFireControlMode = CmdRT.modeFireControl;
		fc1553Stop();	   //ֹͣ���ͻ������
	}

}

/****����ң������****/ 
void CallbackYC(void)
{
    int test_flag;
	int status;
	int send_byte; 	
    test_flag = CmdRT.statusYC;
	if(test_flag)
	{   
		ycStartReceive(); 	  //��ʼ����ң������
	}
	else
	{
		ycStopReceive();	  //ֹͣ����ң������
	}
}
  
/****���������ź� 422****/
void CallbackGNSSFC422(void)
{
    int test_flag;
	int status;
	int send_byte; 	
    test_flag = CmdRT.statusGNSS422FC;
	if(test_flag)
	{   
		gnssfc422StartReceive(); 
	}
	else
	{
		gnssfc422StopReceive();
	}
}

//==============================================================================
