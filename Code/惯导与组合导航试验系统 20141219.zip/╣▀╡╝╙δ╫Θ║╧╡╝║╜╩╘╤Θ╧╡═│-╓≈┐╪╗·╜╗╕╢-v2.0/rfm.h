//==============================================================================
//
// Title:       rfm.h
// Purpose:     A short description of the interface.
//
// Created on:  2013/12/16 at 10:06:34 by ZhaoHengyang.
// Copyright:   Beihang University. All Rights Reserved.
//
//==============================================================================

#ifndef __rfm_H__
#define __rfm_H__

#ifdef __cplusplus
    extern "C" {
#endif

//==============================================================================
// Include files

#include "cvidef.h"
#include "GERFM.h"

//==============================================================================
// Constants
#define	RFM_NODE_MC	8		//���ػ��ⷴ������
#define	RFM_NODE_DS	0		//���»��ⷴ������  		
#define	RFM_NODE_ROTARY	3   //ת̨�ⷴ������
		
		
#define	RFM_CMD_MC_NULL		-1
#define	RFM_CMD_MC_START	8
#define	RFM_CMD_MC_STOP		4
#define	RFM_CMD_MC_IMU		1
#define RFM_CMD_MC_FIRE_CONTROL  5


#define	RFM_DATA_UINT8_SIZE		(sizeof(RFM_FireControl_Data))
		
		
#define	RFM_ROTARY_CMD_SIZE	32
#define	RFM_ROTARY_STATUS_SIZE	32
		
		
//==============================================================================
// Types
typedef struct
{
	unsigned char cmdFlag;
	unsigned char cmdCode;
	unsigned char cmdParamLength;
	unsigned char cmdParamCheck;
	unsigned char cmdParam[RFM_ROTARY_CMD_SIZE - 4];
}RFM_ROTARY_CMD;

typedef struct
{
	unsigned char statusFlag;
	unsigned char statusCode;
	unsigned char statusParamLength;
	unsigned char statusParamCheck;
	unsigned char statusParam[RFM_ROTARY_STATUS_SIZE - 4];
}RFM_ROTARY_STATUS;
		
		
//==============================================================================


//============================================================================== 
typedef struct 
{
	long long FC_TimeUS;
	//3R 
	double  CraftNavigationStepSize;
	double  FcsVel[3][1];
	double  FcsQtn[4][1];
	double  JieHuoJuLi;
	double  TeZhongDanDaoJiaoDu;
	double  MissileMountPosition[3][1];
	double  FcsGravity[3][1];
	double  FcsLongitude;
	double  FcsLatitude;

	//4R
    double  FcsPos[3][1];
	double  CraftTragetRange[3][1];
	double  CraftTragetVelocity[3][1];
	double  CraftAltitude;
	double  DuoMianYuPianAngle;
	double  DuoMianYuPianTime;
	double  TuoLiGuoZaiTime;
	double  TuoLiGuoZai;

	// IMU data
	double wibb[3];
	double fb[3];
	
	double TraceTime;
	double CraftPosition[3][1];   //�켣��׼���
	double CraftVelocity[3][1];
	double CraftAcc[3][1];
	double CraftAttitude[3][1];
	double CraftAttitudeChangeRate[3][1];
	
    double CraftSFB[3][1];		//�ػ��Ӽ�����
	double CraftOmegaiBB[3][1]; //�ػ��ߵ�����(��������ת��ƫ�������ػ�����ǰ��ϵ
	double CraftInsSFs[3][1];   //�ػ��Ӽ����
	double CraftInsOmegaiBBs[3][1];  //�ػ��������
	
	int CraftFPulseOut[3][1];
	int CraftGPulseOut[3][1];
	
	double CraftInsPosition[3][1];  //������������ߵ������
	double CraftInsVelocityP[3][1];
	double CraftInsAttitude[3][1];

	
	
}RFM_FireControl_Data;
//============================================================================== 

// External variables
extern int RFMMCThreadEnd;

extern int RFMMCIntRcv;


extern RFM_FireControl_Data  RFMFireControlDataTx;
extern RFM_FireControl_Data  RFMFireControlDataRx;

extern RFM_ROTARY_CMD		RFMStructCmd;
extern RFM_ROTARY_STATUS 	RFMStructStatus;


extern GERFM_DevHandle GERFM_hDev;


//==============================================================================
// Global functions
int rfmOpenDev(void);
int rfmCloseDev(void);

int rfmEnableDMA(void); 
int rfmDisableDMA(void); 


int rfmStartMC (void);
int rfmStopMC (void);



int rfmInitMC(void);
int rfmCloseMC(void);
int rfmInitDS(void);
int rfmCloseDS(void);


int rfmIMU(double *w, double *f);
int rfmFireControl_Interrupt(void);

int rfmRotaryClimb(float *initAngle, float *initRate, float *initAngleGet, float *initRateGet, int step);
int rfmRotaryTrack(float *angle, float *rate, float *angleGet, float *rateGet);





#ifdef __cplusplus
    }
#endif

#endif  /* ndef __rfm_H__ */
