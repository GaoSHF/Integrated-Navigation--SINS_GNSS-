/**************************************************************************/
/* LabWindows/CVI User Interface Resource (UIR) Include File              */
/* Copyright (c) National Instruments 2014. All Rights Reserved.          */
/*                                                                        */
/* WARNING: Do not add to, delete from, or otherwise modify the contents  */
/*          of this include file.                                         */
/**************************************************************************/

#include <userint.h>

#ifdef __cplusplus
    extern "C" {
#endif

     /* Panels and Controls: */

#define  PANEL                            1       /* callback function: panelCallBack */
#define  PANEL_BUTTON_SAVE_DATA           2       /* callback function: buttonSaveData */
#define  PANEL_RT_QuitButton              3       /* callback function: RT_Quit */
#define  PANEL_BUTTON_QUIT                4       /* callback function: buttonHostQuit */
#define  PANEL_BUTTON_FC                  5       /* callback function: buttonFC */
#define  PANEL_BUTTON_Test_Analysis       6       /* callback function: TestAnalysis */
#define  PANEL_BUTTON_IM                  7       /* callback function: buttonIM */
#define  PANEL_STATUS                     8
#define  PANEL_BUTTON_CONNECT             9       /* callback function: buttonConnect */
#define  PANEL_CHECKBOX_TRACE             10
#define  PANEL_CHECKBOX_FC                11
#define  PANEL_CHECKBOX_IM                12
#define  PANEL_PICTURE                    13


     /* Menu Bars, Menus, and Menu Items: */

          /* (no menu bars in the resource file) */


     /* Callback Prototypes: */

int  CVICALLBACK buttonConnect(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK buttonFC(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK buttonHostQuit(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK buttonIM(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK buttonSaveData(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK panelCallBack(int panel, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK RT_Quit(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK TestAnalysis(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);


#ifdef __cplusplus
    }
#endif
