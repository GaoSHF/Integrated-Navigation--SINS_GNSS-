#ifndef _FIRE_CONTROL_H_
#define _FIRE_CONTROL_H_
#include "P3530.h"

extern int FlagRecordFC1553;

extern long long CountInFC1553;
extern long long CountOutFC1553;

extern long long IndexInFC1553;
extern long long IndexOutFC1553;


extern double Gsuo[3];
extern double Vout[3];
extern double Rout[3];
extern double RRELsuo[3];
extern double QUATsuo[4];
extern double lattemp,lontemp;

extern FILE *FileHandleRTFC1553; //  File handle

extern int FlagFireControlMode; // Flag of fire control mode (Dynamic / Static)




int fireControlStart(void);
int fireControlStop(void);






#endif 
