#include <utility.h>
#include <rtutil.h>
#include <ansi_c.h>

#include "P3531.h"
#include "pxi_io.h"
#include "gnss_429.h"
#include "common.h"

static int FlagExitThread429 = 0; // �˳�GPS�����̵߳ı�־

int FlagPPS = 0; // PPS received flag
double TimePPS = 0.0; // PPS received time

int FlagRecordGNSS429 = 0; // File record flag GNSS 429

long long CountInGNSS429 = 0;
long long CountOutGNSS429 = 0;

long long IndexInGNSS429 = 0;
long long IndexOutGNSS429 = 0;

FILE *FileHandleRTGNSS429 = NULL; //  File handle

PS_DevHandle   DeviceHandle429; // 429�忨PXI-3531���

MESSAGE429 DataRx[128]; // 429 board data 

double RcvTime;

double PDOP;
double Lat; 		//γ��
double Lon;			//����
double Alt;			//�߶�

SVsInfo m_SVsInfo[32]; // ������Ϣ

double Vx, Vy, Vz;
double Px, Py, Pz;

char FixMode[100];
int sRec_OK;
unsigned char SVs;
char sFixQuality[100];

int FixQuality = 0;

static int ThreadFunctionID429 = 0;   





/*
	�źŽ��յ���ʱ��
 */
void GetRcvTime(void)
{
	unsigned int nTemp;
	double dMiddleData;
	
	memcpy(&nTemp, &DataRx[11].message, 4);
	nTemp = nTemp >> 8;
	dMiddleData = nTemp & 0x1fffff;
	
	memcpy(&nTemp, &DataRx[10].message, 4);
	nTemp = nTemp >> 16;
	nTemp= nTemp & 0xff;
	
	RcvTime = dMiddleData * 256 + nTemp;
	RcvTime = RcvTime * 0.01;
	
}

/*
	PDOP
 */
void GetPDOP(void)
{
	unsigned int nTemp;
	double dMiddleData;
	
	//PDOP
	memcpy(&nTemp,&(DataRx[12].message),4);
	nTemp = nTemp >>8;
	nTemp &=0xff;
	dMiddleData =nTemp;
	PDOP = dMiddleData*16/pow(2,8);
	
}

/*
	γ��
 */
void GetLat(void)
{
	unsigned int nTemp,nLowTemp;
	long lTemp;
	double dMiddleData;
	
	//Lat
	memcpy(&nLowTemp, &(DataRx[8].message), 4);
	nLowTemp = nLowTemp >> 8;
	nLowTemp &= 0xff;

	memcpy(&nTemp, &(DataRx[7].message), 4);
	if((nTemp&0x60000000) == 0x60000000) //����
	{
		nTemp = (nLowTemp >> 8) & 0x1fffff;
		nTemp = nTemp * 256 + nLowTemp;
		nTemp |= 0xe0000000;
		lTemp = nTemp;
		Lat = -(~(lTemp) + 1);
		Lat = Lat * 2 / pow(2, 29) * 57.29578;
	}
	else
	{
		nTemp = (nTemp >> 8) & 0x1fffff;
		nTemp = nTemp * 256 + nLowTemp;
		dMiddleData = nTemp;
		Lat = dMiddleData * 2 / pow(2, 29) * 57.29578; 
	}
	
}

/*
	����
 */
void GetLon(void)
{
	unsigned int nTemp,nLowTemp;
	long lTemp;
	double dMiddleData;
	
	//Lon
	memcpy(&nLowTemp,&(DataRx[10].message),4);
	nLowTemp = nLowTemp >>8;
	nLowTemp &=0xff;

	memcpy(&nTemp,&(DataRx[9].message),4);
	if((nTemp&0x60000000)==0x60000000) //����
	{
		nTemp = (nLowTemp >>8)&0x1fffff;
		nTemp = nTemp*256 + nLowTemp;
		nTemp |= 0xe0000000;
		lTemp = nTemp;
		Lon = -(~(lTemp)+1);
		Lon = Lon * 4/pow(2,29)*57.29578;
	}
	else
	{
		nTemp = (nTemp>>8)&0x1fffff;
		nTemp = nTemp*256 + nLowTemp;
		dMiddleData = nTemp;
		Lon = dMiddleData * 4/pow(2,29)*57.29578; 
	}
	
}

/*
	�߶�
 */
void GetAlt(void)
{
	unsigned int nTemp;
	long lTemp;
	double dMiddleData;
	
	//Alt
	memcpy(&nTemp,&(DataRx[6].message),4);
	if((nTemp&0x60000000)==0x60000000) //����
	{
		nTemp = (nTemp >>8)&0x1fffff;
		nTemp = nTemp|0xffe00000;
		lTemp = nTemp;
		dMiddleData = -(~(lTemp)+1);
		Alt = dMiddleData/pow(2,6);
	}
	else
	{
		nTemp = (nTemp>>8)&0x1fffff;
		dMiddleData = nTemp;
		Alt = dMiddleData/pow(2,6); 
	}
	
}



/*
	���㵥�����ǵ�α�ࡢλ�ã�nScaleΪ������ϵ����������ʱ2��nScale�η�
 */
double GetSVsInfoType1(int nLowIndex, int nHighIndex, int nLowIndexBegin, int nScale)
{
	double ReturnValue;
	unsigned int nTemp, nLowTemp;
	double dMiddleData;
	long lTemp;
	
	memcpy(&nLowTemp, &DataRx[nLowIndex - 1].message, 4);
	nLowTemp = nLowTemp >> (nLowIndexBegin - 1);
	nLowTemp &= 0x3ff;
	
	memcpy(&nTemp, &DataRx[nHighIndex - 1].message, 4);
	
	// �жϷ���λ
	if((nTemp & 0x60000000) == 0x60000000) //����
	{
		nTemp = (nTemp >> 8) & 0x1fffff;
		nTemp = nTemp * 1024 + nLowTemp;
		
		nTemp = nTemp | 0x80000000;
		lTemp = nTemp;
		dMiddleData = -(~(lTemp) + 1);
		ReturnValue = dMiddleData / pow(2, (31 - nScale));
	}
	else
	{
		nTemp = (nTemp >> 8) & 0x1fffff;
		nTemp = nTemp * 1024 + nLowTemp;
		
		dMiddleData = nTemp;
		ReturnValue = dMiddleData / pow(2, (31 - nScale)); 
	}
	
	return ReturnValue;
}


/*
	���㵥�����ǵ�α���ʡ��ٶȣ�nScaleΪ������ϵ����������ʱ2��nScale�η�
 */
double GetSVsInfoType2(int nIndex, int nScale)
{
	double ReturnValue;
	unsigned int nTemp;
	double dMiddleData;
	long lTemp;
	
	memcpy(&nTemp, &DataRx[nIndex - 1].message, 4);
	
	// �жϷ���λ
	if((nTemp & 0x60000000) == 0x60000000) //����
	{
		nTemp = (nTemp >> 8) & 0x1fffff;
		nTemp = nTemp | 0xffe00000;
		lTemp = nTemp;
		dMiddleData = -(~(lTemp) + 1);
		ReturnValue = dMiddleData / pow(2, (21 - nScale));
	}
	else
	{
		nTemp = (nTemp>> 8) & 0x1fffff;
		dMiddleData = nTemp;
		ReturnValue = dMiddleData / pow(2, (21 - nScale)); 
	}
	
	return ReturnValue;
	
}

/*
	���㵥�����ǵ�����ȣ�frameIndex��ʾ�ڼ�֡���ݣ�1��128����bitIndex��ʾ�ڼ�λ��1��32��
 */
unsigned char GetSVsSNR(int frameIndex, int bitIndex)
{
	unsigned char ReturnValue;
	unsigned int nTemp;
	
	memcpy(&nTemp, &DataRx[frameIndex - 1].message, 4);

	nTemp = (nTemp >> bitIndex - 1) & 0xff;
	
	ReturnValue = (unsigned char)nTemp;
	
	return ReturnValue;
	
}



/*
	���ߵ��WGS84����ϵ�ٶ�ͶӰ����
 */
void GetV(void)
{
	unsigned int nTemp, nLowTemp;
	int lTemp;
	double dMiddleData;
	
	// Vz
	memcpy(&nTemp, &DataRx[5].message, 4);
	
	if((nTemp & 0x60000000) == 0x60000000) //����
	{
		nTemp = (nTemp >> 12) & 0x1ffff;
		nTemp = nTemp | 0xfffe0000;
		lTemp = nTemp;
		dMiddleData = -(~(lTemp) + 1);
		Vz = dMiddleData * 3200 / pow(2, 17);
	}
	else
	{
		nTemp = (nTemp>> 12) & 0x1ffff;
		dMiddleData = nTemp;
		Vz = dMiddleData * 3200 / pow(2, 17); 
	}
	
	// Vy
	memcpy(&nTemp, &DataRx[4].message, 4);
	
	if((nTemp & 0x60000000) == 0x60000000) //����
	{
		nTemp = (nTemp >> 12) & 0x1ffff;
		nTemp = nTemp | 0xfffe0000;
		lTemp = nTemp;
		dMiddleData = -(~(lTemp) + 1);
		Vy = dMiddleData * 3200 / pow(2, 17);
	}
	else
	{
		nTemp = (nTemp>> 12) & 0x1ffff;
		dMiddleData = nTemp;
		Vy = dMiddleData * 3200 / pow(2, 17); 
	}
	
	// Vx
	memcpy(&nTemp, &DataRx[3].message, 4);
	
	if((nTemp & 0x60000000) == 0x60000000) //����
	{
		nTemp = (nTemp >> 12) & 0x1ffff;
		nTemp = nTemp | 0xfffe0000;
		lTemp = nTemp;
		dMiddleData = -(~(lTemp) + 1);
		Vx = dMiddleData * 3200 / pow(2, 17);
	}
	else
	{
		nTemp = (nTemp>> 12) & 0x1ffff;
		dMiddleData = nTemp;
		Vx = dMiddleData * 3200 / pow(2, 17); 
	}
}


/*
	���ߵ��WGS84����ϵλ�ý���
 */
void GetP(void)
{
	unsigned int nTemp, nLowTemp;
	int lTemp;
	double dMiddleData;
	
	// Pz
	memcpy(&nTemp, &DataRx[5].message, 4);
	nLowTemp = nTemp >> 8;
	nLowTemp &= 0xf;
	
	memcpy(&nTemp, &DataRx[2].message, 4);
	if((nTemp & 0x60000000) == 0x60000000) //����
	{
		nTemp = (nTemp >> 8) & 0x1fffff;
		nTemp = nTemp * 16 + nLowTemp;
		nTemp = nTemp | 0xfe000000;
		lTemp = nTemp;
		dMiddleData = -(~(lTemp) + 1);
		Pz = dMiddleData / pow(2, 2);
	}
	else
	{
		nTemp = (nTemp>> 8) & 0x1fffff;
		nTemp = nTemp * 16 + nLowTemp;
		dMiddleData = nTemp;
		Pz = dMiddleData / pow(2, 2); 
	}
	
	// Py
	memcpy(&nTemp, &DataRx[4].message, 4);
	nLowTemp = nTemp >> 8;
	nLowTemp &= 0xf;
	
	memcpy(&nTemp, &DataRx[1].message, 4);
	if((nTemp & 0x60000000) == 0x60000000) //����
	{
		nTemp = (nTemp >> 8) & 0x1fffff;
		nTemp = nTemp * 16 + nLowTemp;
		nTemp = nTemp | 0xfe000000;
		lTemp = nTemp;
		dMiddleData = -(~(lTemp) + 1);
		Py = dMiddleData / pow(2, 2);
	}
	else
	{
		nTemp = (nTemp>> 8) & 0x1fffff;
		nTemp = nTemp * 16 + nLowTemp;
		dMiddleData = nTemp;
		Py = dMiddleData / pow(2, 2); 
	}
	
	// Px
	memcpy(&nTemp, &DataRx[3].message, 4);
	nLowTemp = nTemp >> 8;
	nLowTemp &= 0xf;
	
	memcpy(&nTemp, &DataRx[0].message, 4);
	if((nTemp & 0x60000000) == 0x60000000) //����
	{
		nTemp = (nTemp >> 8) & 0x1fffff;
		nTemp = nTemp * 16 + nLowTemp;
		nTemp = nTemp | 0xfe000000;
		lTemp = nTemp;
		dMiddleData = -(~(lTemp) + 1);
		Px = dMiddleData / pow(2, 2);
	}
	else
	{
		nTemp = (nTemp>> 8) & 0x1fffff;
		nTemp = nTemp * 16 + nLowTemp;
		dMiddleData = nTemp;
		Px = dMiddleData / pow(2, 2); 
	}
}

/*
	��λ��������
 */
void ParamProcess(void)
{
	char sTemp[10];
	unsigned int nTemp;
	
	// Fixmode ��λģʽ
	memcpy(sTemp, &DataRx[12].message, 4);
	switch(sTemp[3] & 0x3)
	{
	case 0:		// 00
		strcpy(FixMode, "GPS");
		break;
	case 0x08:	// 01
		strcpy(FixMode, "GLONASS+BD1");
		break;
	case 0x10:
		strcpy(FixMode, "GLONASS");
		break;
	case 0x18:
		strcpy(FixMode, "INVALID");
		break;
	}
	
	// sRec_OK �Լ�����
	switch(sTemp[2] & 0x8)
	{
	case 0:
		sRec_OK = 0;
		break;
	default:
		sRec_OK = 1;
	}
	
	// SVs ������
	memcpy(&nTemp, &DataRx[12].message, 4);
	nTemp = nTemp >> 18;
	nTemp = nTemp & 0x1f;
	SVs = nTemp;
	
	// FixQuality ��λ����
	memcpy(&nTemp, &DataRx[12].message, 4);
	nTemp = nTemp >> 16;
	nTemp = nTemp & 0x3;
	switch(nTemp)
	{
	case 0:
		strcpy(sFixQuality, "00");
		break;
	case 1:
		strcpy(sFixQuality, "01");
		break;
	case 3:
		strcpy(sFixQuality, "11");
		break;
	default:
		strcpy(sFixQuality, "10");
	}
	
}


/*
	�����Ƕ�λ�������
 */
void GetSVsInfo(void)
{
	unsigned int nTemp;
	int i;
	
	// ����1
	memcpy(&nTemp, &DataRx[13].message, 4);
	nTemp = nTemp >> 8;
	
	m_SVsInfo[0].nNo = nTemp & 0x3f;
	m_SVsInfo[0].weiju = GetSVsInfoType1(16, 15, 9, 26);
	m_SVsInfo[0].weijulv = GetSVsInfoType2(21, 12);
	m_SVsInfo[0].X = GetSVsInfoType1(26, 25, 9, 26);
	m_SVsInfo[0].Y = GetSVsInfoType1(26, 27, 19, 26); 
	m_SVsInfo[0].Z = GetSVsInfoType1(29, 28, 9, 26);
	m_SVsInfo[0].Vx = GetSVsInfoType2(43, 13);
	m_SVsInfo[0].Vy = GetSVsInfoType2(44, 13);
	m_SVsInfo[0].Vz = GetSVsInfoType2(45, 13);
	m_SVsInfo[0].SNR = ((m_SVsInfo[0].nNo == 0) ? 0 : GetSVsSNR(118, 9));
	
	// ����2
	memcpy(&nTemp, &DataRx[13].message, 4);
	nTemp = nTemp >> 14;
	
	m_SVsInfo[1].nNo = nTemp & 0x3f;
	m_SVsInfo[1].weiju = GetSVsInfoType1(16, 17, 19, 26);
	m_SVsInfo[1].weijulv = GetSVsInfoType2(22, 12);
	m_SVsInfo[1].X = GetSVsInfoType1(29, 30, 19, 26);
	m_SVsInfo[1].Y = GetSVsInfoType1(32, 31, 9, 26); 
	m_SVsInfo[1].Z = GetSVsInfoType1(32, 33, 19, 26);
	m_SVsInfo[1].Vx = GetSVsInfoType2(46, 13);
	m_SVsInfo[1].Vy = GetSVsInfoType2(47, 13);
	m_SVsInfo[1].Vz = GetSVsInfoType2(48, 13);
	m_SVsInfo[1].SNR = ((m_SVsInfo[1].nNo == 0) ? 0 : GetSVsSNR(118, 17));
	
	// ����3
	memcpy(&nTemp, &DataRx[13].message, 4);
	nTemp = nTemp >> 20;
	
	m_SVsInfo[2].nNo = nTemp & 0x3f;
	m_SVsInfo[2].weiju = GetSVsInfoType1(19, 18, 9, 26);
	m_SVsInfo[2].weijulv = GetSVsInfoType2(23, 12);
	m_SVsInfo[2].X = GetSVsInfoType1(35, 34, 9, 26);
	m_SVsInfo[2].Y = GetSVsInfoType1(35, 36, 19, 26); 
	m_SVsInfo[2].Z = GetSVsInfoType1(38, 37, 9, 26);
	m_SVsInfo[2].Vx = GetSVsInfoType2(49, 13);
	m_SVsInfo[2].Vy = GetSVsInfoType2(50, 13);
	m_SVsInfo[2].Vz = GetSVsInfoType2(51, 13);
	m_SVsInfo[2].SNR = ((m_SVsInfo[2].nNo == 0) ? 0 : GetSVsSNR(119, 9));
	
	// ����4
	memcpy(&nTemp, &DataRx[54].message, 4);
	nTemp = nTemp >> 8;
	
	m_SVsInfo[3].nNo = nTemp & 0x3f;
	m_SVsInfo[3].weiju = GetSVsInfoType1(19, 20, 19, 26);
	m_SVsInfo[3].weijulv = GetSVsInfoType2(24, 12);
	m_SVsInfo[3].X = GetSVsInfoType1(38, 39, 19, 26);
	m_SVsInfo[3].Y = GetSVsInfoType1(41, 40, 9, 26); 
	m_SVsInfo[3].Z = GetSVsInfoType1(41, 42, 19, 26);
	m_SVsInfo[3].Vx = GetSVsInfoType2(52, 13);
	m_SVsInfo[3].Vy = GetSVsInfoType2(53, 13);
	m_SVsInfo[3].Vz = GetSVsInfoType2(54, 13);
	m_SVsInfo[3].SNR = ((m_SVsInfo[3].nNo == 0) ? 0 : GetSVsSNR(119, 17));
	
	// ����5
	memcpy(&nTemp, &DataRx[54].message, 4);
	nTemp = nTemp >> 14;
	
	m_SVsInfo[4].nNo = nTemp & 0x3f;
	m_SVsInfo[4].weiju = GetSVsInfoType1(57, 56, 9, 26);
	m_SVsInfo[4].weijulv = GetSVsInfoType2(62, 12);
	m_SVsInfo[4].X = GetSVsInfoType1(68, 67, 9, 26);
	m_SVsInfo[4].Y = GetSVsInfoType1(68, 69, 19, 26); 
	m_SVsInfo[4].Z = GetSVsInfoType1(71, 70, 9, 26);
	m_SVsInfo[4].Vx = GetSVsInfoType2(85, 13);
	m_SVsInfo[4].Vy = GetSVsInfoType2(86, 13);
	m_SVsInfo[4].Vz = GetSVsInfoType2(87, 13);
	m_SVsInfo[4].SNR = ((m_SVsInfo[4].nNo == 0) ? 0 : GetSVsSNR(120, 9));
	
	// ����6
	memcpy(&nTemp, &DataRx[54].message, 4);
	nTemp = nTemp >> 20;
	
	m_SVsInfo[5].nNo = nTemp & 0x3f;
	m_SVsInfo[5].weiju = GetSVsInfoType1(57, 58, 19, 26);
	m_SVsInfo[5].weijulv = GetSVsInfoType2(63, 12);
	m_SVsInfo[5].X = GetSVsInfoType1(71, 72, 19, 26);
	m_SVsInfo[5].Y = GetSVsInfoType1(74, 73, 9, 26); 
	m_SVsInfo[5].Z = GetSVsInfoType1(74, 75, 19, 26);
	m_SVsInfo[5].Vx = GetSVsInfoType2(88, 13);
	m_SVsInfo[5].Vy = GetSVsInfoType2(89, 13);
	m_SVsInfo[5].Vz = GetSVsInfoType2(90, 13);
	m_SVsInfo[5].SNR = ((m_SVsInfo[5].nNo == 0) ? 0 : GetSVsSNR(120, 17));
	
	// ����7
	memcpy(&nTemp, &DataRx[63].message, 4);
	nTemp = nTemp >> 8;
	
	m_SVsInfo[6].nNo = nTemp & 0x3f;
	m_SVsInfo[6].weiju = GetSVsInfoType1(60, 59, 9, 26);
	m_SVsInfo[6].weijulv = GetSVsInfoType2(65, 12);
	m_SVsInfo[6].X = GetSVsInfoType1(77, 76, 9, 26);
	m_SVsInfo[6].Y = GetSVsInfoType1(77, 78, 19, 26); 
	m_SVsInfo[6].Z = GetSVsInfoType1(80, 79, 9, 26);
	m_SVsInfo[6].Vx = GetSVsInfoType2(91, 13);
	m_SVsInfo[6].Vy = GetSVsInfoType2(92, 13);
	m_SVsInfo[6].Vz = GetSVsInfoType2(93, 13);
	m_SVsInfo[6].SNR = ((m_SVsInfo[6].nNo == 0) ? 0 : GetSVsSNR(121, 9));
	
	// ����8
	memcpy(&nTemp, &DataRx[63].message, 4);
	nTemp = nTemp >> 14;
	
	m_SVsInfo[7].nNo = nTemp & 0x3f;
	m_SVsInfo[7].weiju = GetSVsInfoType1(60, 61, 19, 26);
	m_SVsInfo[7].weijulv = GetSVsInfoType2(66, 12);
	m_SVsInfo[7].X = GetSVsInfoType1(80, 81, 19, 26);
	m_SVsInfo[7].Y = GetSVsInfoType1(83, 82, 9, 26); 
	m_SVsInfo[7].Z = GetSVsInfoType1(83, 84, 19, 26);
	m_SVsInfo[7].Vx = GetSVsInfoType2(94, 13);
	m_SVsInfo[7].Vy = GetSVsInfoType2(95, 13);
	m_SVsInfo[7].Vz = GetSVsInfoType2(96, 13);
	m_SVsInfo[7].SNR = ((m_SVsInfo[7].nNo == 0) ? 0 : GetSVsSNR(121, 17));
	
	// ����9
	memcpy(&nTemp, &DataRx[63].message, 4);
	nTemp = nTemp >> 20;
	
	m_SVsInfo[8].nNo = nTemp & 0x3f;
	m_SVsInfo[8].weiju = GetSVsInfoType1(99, 98, 9, 26);
	m_SVsInfo[8].weijulv = GetSVsInfoType2(101, 12);
	m_SVsInfo[8].X = GetSVsInfoType1(104, 103, 9, 26);
	m_SVsInfo[8].Y = GetSVsInfoType1(104, 105, 19, 26); 
	m_SVsInfo[8].Z = GetSVsInfoType1(107, 106, 9, 26);
	m_SVsInfo[8].Vx = GetSVsInfoType2(112, 13);
	m_SVsInfo[8].Vy = GetSVsInfoType2(113, 13);
	m_SVsInfo[8].Vz = GetSVsInfoType2(114, 13);
	m_SVsInfo[8].SNR = ((m_SVsInfo[8].nNo == 0) ? 0 : GetSVsSNR(122, 9));
	
	// ����10
	memcpy(&nTemp, &DataRx[96].message, 4);
	nTemp = nTemp >> 8;
	
	m_SVsInfo[9].nNo = nTemp & 0x3f;
	m_SVsInfo[9].weiju = GetSVsInfoType1(99, 100, 19, 26);
	m_SVsInfo[9].weijulv = GetSVsInfoType2(102, 12);
	m_SVsInfo[9].X = GetSVsInfoType1(107, 108, 19, 26);
	m_SVsInfo[9].Y = GetSVsInfoType1(110, 109, 9, 26); 
	m_SVsInfo[9].Z = GetSVsInfoType1(110, 111, 19, 26);
	m_SVsInfo[9].Vx = GetSVsInfoType2(115, 13);
	m_SVsInfo[9].Vy = GetSVsInfoType2(116, 13);
	m_SVsInfo[9].Vz = GetSVsInfoType2(117, 13);
	m_SVsInfo[9].SNR = ((m_SVsInfo[9].nNo == 0) ? 0 : GetSVsSNR(122, 17));
}


/*
	GPS���ݽ���
 */
void DecodeGNSS429(void)
{
	int i;
	
	ParamProcess();
	
	GetRcvTime();
		
	GetLat();
	GetLon();
	GetAlt();
	
	GetPDOP();
	
	GetP();
	GetV();
	
	GetSVsInfo();
	
	(DataTemp + IndexInGNSS429)->RcvTime = RcvTime;
	
	(DataTemp + IndexInGNSS429)->Lon = Lon;
	(DataTemp + IndexInGNSS429)->Lat = Lat;
	(DataTemp + IndexInGNSS429)->Alt = Alt;
	(DataTemp + IndexInGNSS429)->PDOP = PDOP;
	
	(DataTemp + IndexInGNSS429)->X = Px;
	(DataTemp + IndexInGNSS429)->Y = Py;
	(DataTemp + IndexInGNSS429)->Z = Pz;
	
	(DataTemp + IndexInGNSS429)->Vx = Vx;
	(DataTemp + IndexInGNSS429)->Vy = Vy;
	(DataTemp + IndexInGNSS429)->Vz = Vz;
	
	for (i = 0; i < 10; i ++)
	{
		(DataTemp + IndexInGNSS429)->m_SVsInfo[i] = m_SVsInfo[i];
	}
	
	for (i = 0; i < 20; i ++)
		(DataTemp + IndexInGNSS429)->FixMode[i] = FixMode[i];
	
	(DataTemp + IndexInGNSS429)->sRec_OK = sRec_OK;
	(DataTemp + IndexInGNSS429)->SVs = SVs;
	
	for (i = 0; i < 2; i ++)
		(DataTemp + IndexInGNSS429)->sFixQuality[i] = sFixQuality[i];
	
}

/*
	PPS�жϺ���
 */
ViStatus _VI_FUNCH InterruptPPS(ViSession vi , ViEventType eventType ,ViEvent ctx ,ViAddr userHdlr)
{
  //printf("PPS interupt\n");
	
	unsigned long long ppstime;
	double ppstime_ms;
	static unsigned char first_interrupt = 1;
	static double pre_ppstime_ms = 0;

	ppstime = GetTimeUS (); 
	ppstime_ms = (double)ppstime / 1000.0;
	if(first_interrupt)
	{
		pre_ppstime_ms = ppstime_ms;  
		first_interrupt = 0;
	}

	TimePPS = ppstime_ms;
	FlagPPS = 1;
 
	return VI_SUCCESS;
}


/*
	GNSS���ݽ����߳�
 */
static int CVICALLBACK ThreadFunctionGNSS429(void *functionData)
{	
	int i;
	MESSAGE429 RxMessage;  
	int lengthRead ;
	int nRet = PS_SUCCESS;  
	unsigned long long gpstime;
	double gpstime_ms;
	static int frame_head =0;
	static int start_flag =0;
	
	INT_CONDITION Int_condition;
	PINT_CONDITION  pInt_condition;
	
	
	while (!FlagExitThread429)
    {
       	nRet = P3531_WaitForInterrupt(DeviceHandle429, 500);
		
		gpstime = GetTimeUS (); 
		gpstime_ms = (double) gpstime / 1000.0;
		
		if(0 == start_flag)
		{
			nRet = P3531_ReadBlock(DeviceHandle429, 0, DataRx, 128, &lengthRead);
	    	for(i = 0; i < 128; i++) 
			{
				if((DataRx[i].message & 0x000000ff) == 0x00000001)
				{
					frame_head = i;
					break;
				}
			}
			if(frame_head == 0)
			{
				//printf("GNSS 429: frame_head = 0\n");
				start_flag = 2;	
			}
			else
			{
				printf("GNSS 429: frame_head = %d\n", frame_head);  
				Int_condition.intType = 0;
				Int_condition.threshold = frame_head;
				pInt_condition = &Int_condition;
				P3531_SetInterruptCond (DeviceHandle429, pInt_condition, 1); 
				start_flag = 1;
			}
		}
		else if(1 == start_flag)
		{
			nRet = P3531_ReadBlock(DeviceHandle429,0, DataRx, frame_head, &lengthRead);
			
			Int_condition.intType=0;
			Int_condition.threshold = 128;
			pInt_condition = &Int_condition;
			P3531_SetInterruptCond (DeviceHandle429, pInt_condition, 1); 
			start_flag = 2;
		}
		else if(2 == start_flag)
		{
			nRet = P3531_ReadBlock(DeviceHandle429, 0, DataRx, 128, &lengthRead);
			// ��ֹ��;��֡
			if ((DataRx[0].message & 0x000000FF) != 0x00000001)
				start_flag = 0;
			else if (lengthRead != 0)
			{
				// ******** Record data to FIFO
				// GNSS receiver parameters
				DecodeGNSS429();
				
				// GNSS time
				(DataTemp + IndexInGNSS429)->gps_firstdata = DataRx[0].message;
				(DataTemp + IndexInGNSS429)->gps_time = gpstime_ms;
				
				// PPS time
				if (FlagPPS == 1)
				{
					(DataTemp + IndexInGNSS429)->pps_time = TimePPS;
					FlagPPS = 0;
				}
				else
				{
					(DataTemp + IndexInGNSS429)->pps_time = 0.0;
				}
				
				// FIFO
				CountInGNSS429 ++;
				IndexInGNSS429 ++;
				if (IndexInGNSS429 >= MEMORY_BANK_SIZE)
					IndexInGNSS429 = 0;
			}		
		}


    } // while
    return 0;
}


/*
	��ʼ����GNSS����
 */
void gnss429StartReceive(void)
{

	int i;
	PS_DevInfoHandle  pDevs = NULL;
	int nRet = PS_SUCCESS; 
	int countOfCards = 0;
	int countOfModules = 0; 
	INT_CONDITION Int_condition;
	PINT_CONDITION  pInt_condition;
	
	printf("GNSS 429: receive init.\n");
	
	Int_condition.intType=0;
	Int_condition.threshold = 128;
	pInt_condition = &Int_condition;	
	
	
	FlagExitThread429 = 0;
	P3531_ScanDevices(&pDevs, &countOfCards);
	P3531_OpenDevice(pDevs, &DeviceHandle429);
	P3531_ReleaseDevInfo(pDevs);
	P3531_GetCountOfModule(DeviceHandle429, &countOfModules);  // get moudles number

	for(i=0; i < countOfModules; ++i)
	{
		P3531_ResetModule(DeviceHandle429, i);
		P3531_ConfigureModule(DeviceHandle429, i, MODULE_DISABLE_SELF_TEST); // disable self-test
	}  
	P3531_SetInterruptCond (DeviceHandle429, pInt_condition, 1);
	// Enable Rx channel and clear Rx FIFO
	nRet = P3531_EnableRCVChannel(DeviceHandle429, 0, 1);	 	
	nRet = P3531_ResetRCVFIFO(DeviceHandle429, 0);
	nRet = P3531_ResetSNDFIFO(DeviceHandle429, 0); 
	
	
	
	// Enable data file record
	FlagRecordGNSS429 = FILE_RECORD_START;
	
	// Create thread
	CmtScheduleThreadPoolFunction (gThreadPool,
                    ThreadFunctionGNSS429, NULL,
                    &ThreadFunctionID429);
	
	printf("GNSS 429: receive start.\n");

}


/*
	ֹͣ����GPS����
 */
void gnss429StopReceive(void)
{
	// Disable GNSS receive
	FlagExitThread429 = 1;  
 	CmtWaitForThreadPoolFunctionCompletion (gThreadPool,
                    ThreadFunctionID429,
                   OPT_TP_PROCESS_EVENTS_WHILE_WAITING);
	CmtReleaseThreadPoolFunctionID (gThreadPool, ThreadFunctionID429);
	
	P3531_CloseDevice(DeviceHandle429);
	
	// Disable data file record
	FlagRecordGNSS429 = FILE_RECORD_STOP;
	
	printf("GNSS 429: receive stop.\n");
}
