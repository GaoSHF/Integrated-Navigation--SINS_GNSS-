//==============================================================================
//
// Title:       pci_io_cvi.c
// Purpose:     A short description of the implementation.
//
// Created on:  2013-3-2 at 15:35:24 by Cindy.
// Copyright:   BUAA. All Rights Reserved.
//
//==============================================================================

//==============================================================================
// Include files
#include "pxi_io_cvi.h"
#include <userint.h>
#include <visa.h>
#include <ansi_c.h> //  For printf, malloc

#include "pxi_io.h"

//==============================================================================
// Constants, set for PCI board instead of pxi board
#define TAB_INDEX_DIGIT_OUT		0
#define TAB_INDEX_DIGIT_IN		1
#define TAB_INDEX_RAM			2
#define TAB_INDEX_LED			3
#define TAB_INDEX_OP			4

//==============================================================================
// Types

//==============================================================================
// Static global variables
static int HandlePanel;
static int HandleTab;

//==============================================================================
// Static functions
ViStatus _VI_FUNCH Interrupt(ViSession vi , ViEventType eventType ,ViEvent ctx ,ViAddr userHdlr);

//==============================================================================
// Global variables
ViUInt16 ManfIdSet = IO_DEFAULT_MANF_ID;
ViUInt16 ModelCodeSet = IO_DEFAULT_MODEL_CODE;

ViUInt32 DataWrite = 0x00001111;
ViUInt32 DataRead;

int FlagFound = 0;
int FlagCheckNum = 0;

int FlagInterrupt = 0;

IO_PARAM ParamIO;



ViPEventType OutEventType;
ViPEvent OutContext;
ViStatus Status;


//==============================================================================
// Global functions
int Init(){
	// **************** Main panel ****************
	// Numeric data type
	SetCtrlAttribute(HandlePanel, PANEL_MANF_ID, ATTR_FORMAT, VAL_HEX_FORMAT);
	SetCtrlAttribute(HandlePanel, PANEL_MODEL_CODE, ATTR_FORMAT, VAL_HEX_FORMAT);
	
	// Numeric default data value
	SetCtrlAttribute(HandlePanel, PANEL_MANF_ID, ATTR_DFLT_VALUE, 0x0000);
	SetCtrlAttribute(HandlePanel, PANEL_MODEL_CODE, ATTR_DFLT_VALUE, 0x0000);
	
	
	// **************** Tab digit out ****************
	// Creat tab page handle
	GetPanelHandleFromTabPage(HandlePanel, PANEL_TAB, TAB_INDEX_DIGIT_OUT, &HandleTab);
	
	// Set numeric data type
	SetCtrlAttribute(HandleTab, TAB_OUT_NUMERIC_O5, ATTR_DATA_TYPE, VAL_UNSIGNED_INTEGER);
	SetCtrlAttribute(HandleTab, TAB_OUT_NUMERIC_O27, ATTR_DATA_TYPE, VAL_UNSIGNED_INTEGER);
	SetCtrlAttribute(HandleTab, TAB_OUT_NUMERIC_OC5, ATTR_DATA_TYPE, VAL_UNSIGNED_INTEGER);
	
	// Set numeric maximum value
	SetCtrlAttribute(HandleTab, TAB_OUT_NUMERIC_O5, ATTR_MAX_VALUE, 255);// 8 bits
	SetCtrlAttribute(HandleTab, TAB_OUT_NUMERIC_O27, ATTR_MAX_VALUE, 255);
	SetCtrlAttribute(HandleTab, TAB_OUT_NUMERIC_OC5, ATTR_MAX_VALUE, 255);
	
	// Set numeric display format
	SetCtrlAttribute(HandleTab, TAB_OUT_NUMERIC_O5, ATTR_FORMAT, VAL_BINARY_FORMAT);
	SetCtrlAttribute(HandleTab, TAB_OUT_NUMERIC_O27, ATTR_FORMAT, VAL_BINARY_FORMAT);
	SetCtrlAttribute(HandleTab, TAB_OUT_NUMERIC_OC5, ATTR_FORMAT, VAL_BINARY_FORMAT);
	
	// Set numeric range check
	SetCtrlAttribute(HandleTab, TAB_OUT_NUMERIC_O5, ATTR_CHECK_RANGE, VAL_COERCE);
	SetCtrlAttribute(HandleTab, TAB_OUT_NUMERIC_O27, ATTR_CHECK_RANGE, VAL_COERCE);
	SetCtrlAttribute(HandleTab, TAB_OUT_NUMERIC_OC5, ATTR_CHECK_RANGE, VAL_COERCE);
	
	
	// **************** Tab digit in ****************
	// Creat tab page handle
	GetPanelHandleFromTabPage(HandlePanel, PANEL_TAB, TAB_INDEX_DIGIT_IN, &HandleTab);
	
	// Set numeric data type
	SetCtrlAttribute(HandleTab, TAB_IN_NUMERIC_I5, ATTR_DATA_TYPE, VAL_UNSIGNED_INTEGER);
	SetCtrlAttribute(HandleTab, TAB_IN_NUMERIC_I27, ATTR_DATA_TYPE, VAL_UNSIGNED_INTEGER);
	
	// Set numeric maximum value
	SetCtrlAttribute(HandleTab, TAB_IN_NUMERIC_I5, ATTR_MAX_VALUE, 65535);// 16 bits
	SetCtrlAttribute(HandleTab, TAB_IN_NUMERIC_I27, ATTR_MAX_VALUE, 255);// 8 bits    
	
	// Set numeric display format
	SetCtrlAttribute(HandleTab, TAB_IN_NUMERIC_I5, ATTR_FORMAT, VAL_BINARY_FORMAT);
	SetCtrlAttribute(HandleTab, TAB_IN_NUMERIC_I27, ATTR_FORMAT, VAL_BINARY_FORMAT);
	
	// Set numeric range check
	SetCtrlAttribute(HandleTab, TAB_IN_NUMERIC_I5, ATTR_CHECK_RANGE, VAL_COERCE);
	SetCtrlAttribute(HandleTab, TAB_IN_NUMERIC_I27, ATTR_CHECK_RANGE, VAL_COERCE);
	
	
	// **************** Tab RAM ****************
	// Creat tab page handle
	GetPanelHandleFromTabPage(HandlePanel, PANEL_TAB, TAB_INDEX_RAM, &HandleTab);
	
	// Set numeric data type
	SetCtrlAttribute(HandleTab, TAB_RAM_NUMERIC_RAM_I_BEFORE, ATTR_DATA_TYPE, VAL_UNSIGNED_INTEGER);
	SetCtrlAttribute(HandleTab, TAB_RAM_NUMERIC_RAM_O, ATTR_DATA_TYPE, VAL_UNSIGNED_INTEGER);
	SetCtrlAttribute(HandleTab, TAB_RAM_NUMERIC_RAM_I_AFTER, ATTR_DATA_TYPE, VAL_UNSIGNED_INTEGER);
	
	// Set numeric maximum value
	SetCtrlAttribute(HandleTab, TAB_RAM_NUMERIC_RAM_I_BEFORE, ATTR_MAX_VALUE, 65535);
	SetCtrlAttribute(HandleTab, TAB_RAM_NUMERIC_RAM_O, ATTR_MAX_VALUE, 65535);// 16 bits
	SetCtrlAttribute(HandleTab, TAB_RAM_NUMERIC_RAM_I_AFTER, ATTR_MAX_VALUE, 65535);    
	
	// Set numeric display format
	SetCtrlAttribute(HandleTab, TAB_RAM_NUMERIC_RAM_I_BEFORE, ATTR_FORMAT, VAL_BINARY_FORMAT);
	SetCtrlAttribute(HandleTab, TAB_RAM_NUMERIC_RAM_O, ATTR_FORMAT, VAL_BINARY_FORMAT);
	SetCtrlAttribute(HandleTab, TAB_RAM_NUMERIC_RAM_I_AFTER, ATTR_FORMAT, VAL_BINARY_FORMAT);
	
	// Set numeric range check
	SetCtrlAttribute(HandleTab, TAB_RAM_NUMERIC_RAM_I_BEFORE, ATTR_CHECK_RANGE, VAL_COERCE);
	SetCtrlAttribute(HandleTab, TAB_RAM_NUMERIC_RAM_O, ATTR_CHECK_RANGE, VAL_COERCE);
	SetCtrlAttribute(HandleTab, TAB_RAM_NUMERIC_RAM_I_AFTER, ATTR_CHECK_RANGE, VAL_COERCE);
	
	return 0;
}


/* 
 * main entry
 */
int main(int argc, char *argv[])
{
	if (InitCVIRTE(0, argv, 0) == 0) // out of memory
		return -1;
	
	// Panel handle
	if ((HandlePanel = LoadPanel(0, "pxi_io_cvi.uir", PANEL)) < 0)
		return -1;

	DisplayPanel(HandlePanel);
	
	Init();
	
	// Open I/O board 
	FlagFound = IO_Open(&ParamIO);
	
	// Enable PXI IO board interrupt
	if(FlagFound == IO_FOUND) {
		IO_EnableIntPCI(ParamIO, Interrupt);
	}
	
	RunUserInterface();
	
	if(FlagFound == IO_FOUND) { 
		IO_DisableIntPCI(ParamIO, Interrupt);
	
		// Close I/O board
		IO_Close (&ParamIO);
	}
	
	DiscardPanel(HandlePanel);
	
	return 0;
}

// ********************************************************************** Interface callback
/* 
 * Refresh operation follow the timer with some board operation
 */
int CVICALLBACK Refresh(int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	switch(event){
	case  EVENT_TIMER_TICK:
	
		// Refresh IO board found LED and name display
		if(FlagFound == IO_FOUND) {
			SetCtrlVal(HandlePanel, PANEL_LED, 1);
			SetCtrlVal(HandlePanel, PANEL_IO_BOARD_NAME, ParamIO.name); // Display VISA name
			
			SetCtrlVal(HandlePanel, PANEL_MANF_ID, IO_DEFAULT_MANF_ID);
			SetCtrlVal(HandlePanel, PANEL_MODEL_CODE, IO_DEFAULT_MODEL_CODE);
		}
		else{
			SetCtrlVal(HandlePanel, PANEL_LED, 0);
			SetCtrlVal(HandlePanel, PANEL_IO_BOARD_NAME, "Not found"); // Display not found
		}
		
		
		// **************** Refresh Real operation tab for the project ****************
		// Creat tab page handle
		if(FlagFound == IO_FOUND) {		  
			GetPanelHandleFromTabPage(HandlePanel, PANEL_TAB, TAB_INDEX_OP, &HandleTab);
			
			// **************** 27V Relay output ****************
			// ��������
			GetCtrlVal(HandleTab, TAB_OP_RELAY_27_ED, &DataRead);
			if(DataRead == 1)
				IO_ElectroDiscrete(&ParamIO, IO_RELAY_CONNECT); // Connect
			else if(DataRead == 0)
				IO_ElectroDiscrete(&ParamIO, IO_RELAY_DISCRETE); // Discrete	
			else;
			
			// ��������
			GetCtrlVal(HandleTab, TAB_OP_RELAY_27_PD, &DataRead);
			if(DataRead == 1)
				IO_PhysicalDiscrete(&ParamIO, IO_RELAY_CONNECT); // Connect
			else if(DataRead == 0)
				IO_PhysicalDiscrete(&ParamIO, IO_RELAY_DISCRETE); // Discrete	
			else;
			
			// **************** 5V Relay output ****************
			// ��ص�ѹ����
			GetCtrlVal(HandleTab, TAB_OP_RELAY_27_BVN, &DataRead);
			if(DataRead == 1)
				IO_BatteryVoltageNormal(&ParamIO, IO_RELAY_CONNECT); // Connect
			else if(DataRead == 0)
				IO_BatteryVoltageNormal(&ParamIO, IO_RELAY_DISCRETE); // Discrete	
			else;
			
			// �ɿ��������ն��ź�
			GetCtrlVal(HandleTab, TAB_OP_RELAY_27_FC2FT, &DataRead);
			if(DataRead == 1)
				IO_BatteryActivate(&ParamIO, IO_RELAY_CONNECT); // Connect
			else if(DataRead == 0)
				IO_BatteryActivate(&ParamIO, IO_RELAY_DISCRETE); // Discrete	
			else;
			
			// �ɿ������������źţ�һ����ָ���
			GetCtrlVal(HandleTab, TAB_OP_ISOLATION_5_FC2FD_OUT, &DataRead);
			if(DataRead == 1)
				IO_SecuritySystem(&ParamIO, IO_RELAY_CONNECT); // Connect
			else if(DataRead == 0)
				IO_SecuritySystem(&ParamIO, IO_RELAY_DISCRETE); // Discrete	
			else;
			
			// **************** 5V isolation input **************** 
			// K2
			DataWrite = IO_K2(&ParamIO);
			SetCtrlVal(HandleTab, TAB_OP_ISOLATION_5_K2, DataWrite);
			
			// ����׼��
			DataWrite = IO_MissilePrepare(&ParamIO);
			SetCtrlVal(HandleTab, TAB_OP_ISOLATION_5_MP, DataWrite);
			
			// ����ͷ�Ӹ�ѹ
			DataWrite = IO_GuiderHighPressure(&ParamIO);
			SetCtrlVal(HandleTab, TAB_OP_ISOLATION_5_GHP, DataWrite);
			
			// �ɿ������������źţ���һ����ָ�    
			//DataWrite = IO_FlightControlToFuseData_In (&ParamIO);
			//SetCtrlVal(HandleTab, TAB_OP_ISOLATION_5_FC2FD_IN, DataWrite);
			
			// �ɿؼ�����Լ�����
			DataWrite = IO_FlightControlSelfTestNormal(&ParamIO);
			SetCtrlVal(HandleTab, TAB_OP_ISOLATION_5_FCSTN, DataWrite);
			
			
		} // if
		
		
		
		break;
	
	default: 
		break;
	}
	
	return 0;
}

/* 
 * Quit
 */
int CVICALLBACK Quit(int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	switch (event){
	case EVENT_COMMIT:
		QuitUserInterface (0);
		break;
		
	default:
		break;		
	}
	return 0;
}

// **************** Digital output ****************
/* 
 * Send 5V relay data
 */
int CVICALLBACK SendO5 (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	switch(event){
	case  EVENT_COMMIT:
		if(FlagFound == IO_FOUND){
			// Creat tab page handle
			GetPanelHandleFromTabPage(HandlePanel, PANEL_TAB, TAB_INDEX_DIGIT_OUT, &HandleTab);
		
			// Get data to write
			GetCtrlVal(HandleTab, TAB_OUT_NUMERIC_O5, &DataWrite);
	
			// Write data
			ParamIO.dataWriteR5 = DataWrite;
			IO_TestRelay5V(ParamIO);
		}
		
		break;
		
	default: 
		break;
	}
	
	return 0;
}

/* 
 * Send 27V relay data
 */
int CVICALLBACK SendO27 (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	switch(event){
	case  EVENT_COMMIT:
		if(FlagFound == IO_FOUND){
			// Creat tab page handle
			GetPanelHandleFromTabPage(HandlePanel, PANEL_TAB, TAB_INDEX_DIGIT_OUT, &HandleTab);
		
			// Get data to write
			GetCtrlVal(HandleTab, TAB_OUT_NUMERIC_O27, &DataWrite);
	
			// Write data
			ParamIO.dataWriteR27 = DataWrite;
			IO_TestRelay27V(ParamIO);
		}
		
		break;
		
	default: 
		break;
	}
	
	return 0;
}

/* 
 * Send 5V OC data
 */
int CVICALLBACK SendOC5 (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	switch(event){
	case  EVENT_COMMIT:
		if(FlagFound == IO_FOUND){
			// Creat tab page handle
			GetPanelHandleFromTabPage(HandlePanel, PANEL_TAB, TAB_INDEX_DIGIT_OUT, &HandleTab);
		
			// Get data to write
			GetCtrlVal(HandleTab, TAB_OUT_NUMERIC_OC5, &DataWrite);
	
			// Write data
			ParamIO.dataWriteOC = DataWrite;
			IO_TestOC(ParamIO);
		}
		
		break;
		
	default: 
		break;
	}
	
	return 0;
}

// **************** Digital input ****************
/* 
 * Read 5V isolation data
 */
int CVICALLBACK ReadI5 (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	switch(event){
	case  EVENT_COMMIT:
		if(FlagFound == IO_FOUND){
			// Creat tab page handle
			GetPanelHandleFromTabPage(HandlePanel, PANEL_TAB, TAB_INDEX_DIGIT_IN, &HandleTab);
			
			// Read data
			IO_TestIsolation5V(&ParamIO);
			DataRead = ParamIO.dataReadI5;
		
			// Set data have been read
			SetCtrlVal(HandleTab, TAB_IN_NUMERIC_I5, DataRead);
			
		}
		
		break;
		
	default: 
		break;
	}
	
	return 0;
}

/* 
 * Read 27V isolation data
 */
int CVICALLBACK ReadI27 (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	switch(event){
	case  EVENT_COMMIT:
		if(FlagFound == IO_FOUND){
			// Creat tab page handle
			GetPanelHandleFromTabPage(HandlePanel, PANEL_TAB, TAB_INDEX_DIGIT_IN, &HandleTab);
			
			// Read data
			IO_TestIsolation27V(&ParamIO);
			DataRead = ParamIO.dataReadI27;
		
			// Set data have been read
			SetCtrlVal(HandleTab, TAB_IN_NUMERIC_I27, DataRead);
		}
		
		break;
		
	default: 
		break;
	}
	
	return 0;
}

// **************** FPGA RAM ****************
/* 
 * Test FPGA 32 bits RAM
 */
int CVICALLBACK TestRam (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	switch(event){
	case  EVENT_COMMIT:
		if(FlagFound == IO_FOUND){
			// Creat tab page handle
			GetPanelHandleFromTabPage(HandlePanel, PANEL_TAB, TAB_INDEX_RAM, &HandleTab);
			
			// Read RAM before
			IO_ReadRAM(ParamIO, &DataRead);
			SetCtrlVal(HandleTab, TAB_RAM_NUMERIC_RAM_I_BEFORE, DataRead);
			
			// Write RAM  
			GetCtrlVal(HandleTab, TAB_RAM_NUMERIC_RAM_O, &DataWrite);
			IO_WriteRAM(ParamIO, DataWrite);
			
			// Read RAM after
			IO_ReadRAM(ParamIO, &DataRead); 
			SetCtrlVal(HandleTab, TAB_RAM_NUMERIC_RAM_I_AFTER, DataRead);
		}
		
		break;
		
	default: 
		break;
	}
	
	return 0;
}

// **************** FPGA LED ****************
/* 
 * Turn on LED
 */
int CVICALLBACK TurnOnLed (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	switch(event){
	case  EVENT_COMMIT:
		if(FlagFound == IO_FOUND){
			// Creat tab page handle
			GetPanelHandleFromTabPage(HandlePanel, PANEL_TAB, TAB_INDEX_LED, &HandleTab);
			
			IO_TurnOnLED(ParamIO);
		}
		
		break;
		
	default: 
		break;
	}
	
	return 0;
}

/* 
 * Turn off LED
 */
int CVICALLBACK TurnOffLed (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	switch(event){
	case  EVENT_COMMIT:
		if(FlagFound == IO_FOUND){
			// Creat tab page handle
			GetPanelHandleFromTabPage(HandlePanel, PANEL_TAB, TAB_INDEX_LED, &HandleTab);
			
			IO_TurnOffLED(ParamIO);
		}
		
		break;
		
	default: 
		break;
	}
	
	return 0;
}




// ********************************************************************** Handler
/* 
 * Interrupt handler
 * 			 mode 1: Turning on and off LED are used as interrupt enable and disable on FPGA board
 * 			 mode 2: Turning on LED is used as interrupt enable, and the interrupt is automatically cleared by VISA
 */
ViStatus _VI_FUNCH Interrupt(ViSession vi , ViEventType eventType ,ViEvent ctx ,ViAddr userHdlr)
{
	FlagInterrupt = ~FlagInterrupt;
	
	SetCtrlVal(HandlePanel, PANEL_INTERRUPT, FlagInterrupt);
	
	return VI_SUCCESS;
}


