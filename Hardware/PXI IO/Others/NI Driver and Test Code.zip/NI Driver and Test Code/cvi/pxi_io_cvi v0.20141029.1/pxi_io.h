//==============================================================================
//
// Title:       pxi_io.h
// Purpose:     A short description of the interface.
//
// Created on:  2013-5-30 at 19:50:13 by Cindy.
// Copyright:   buaa. All Rights Reserved.
//
//==============================================================================

#ifndef __pxi_io_H__
#define __pxi_io_H__

#ifdef __cplusplus
    extern "C" {
#endif

//==============================================================================
// Include files
#include "visatype.h"
#include "visa.h"

//==============================================================================
// Constants
// PXI IO card found mark  
#define IO_FOUND			0
#define IO_NOT_FOUND		1

// Relay parameter
#define IO_RELAY_DISCRETE	0 
#define IO_RELAY_CONNECT	1

// Isolation state
#define IO_ISOLATION_LOW	0 
#define IO_ISOLATION_HIGH	1
		
// PCI parameter
#define IO_DEFAULT_MODEL_CODE		0x4258
#define IO_DEFAULT_MANF_ID			0x1100
#define IO_OFFSET_LED 	0x10
#define IO_OFFSET_RAM 	0x20
#define IO_OFFSET_O5 	0x80
#define IO_OFFSET_O27 	0x90 
#define IO_OFFSET_OC5 	0xA0
#define IO_OFFSET_I5 	0xB0
#define IO_OFFSET_I27 	0xC0
#define IO_OFFSET_INTERRUPT 	0x00

// VISA resource name length
#define VISA_NAME_LENGTH	256		

// Relay 27V output bit 
#define ELECTRO_DISCRETE						(1 << 0)
#define PHYSICAL_DISCRETE						(1 << 1) 
		
// Relay 5V output bit 
#define BATTERY_VOLTAGE_NORMAL					(1 << 0)
#define BATTERY_ACTIVATE			(1 << 1)
#define SECURITY_SYSTEM			(1 << 2)
#define RELAY_RES_1			(1 << 3)
#define RELAY_RES_2			(1 << 4)
		
// Isolation 5V input bit 
#define K2										(1 << 0)
#define MISSILE_PREPARE							(1 << 1) 
#define GUIDER_HIGH_PRESSURE					(1 << 2)
#define PPS										(1 << 3)
#define FLIGHT_CONTROL_SELF_TEST_NORMAL			(1 << 5) 
#define ISOLATION_RES_1			(1 << 7)

// Isolation 27V input bit
#define ISOLATION_RES_2			(1 << 0)
		
//==============================================================================
// Types
typedef struct 
{
	ViSession session; // IO PXI board VISA session
	ViSession defaultRM;
	ViSession visaSelected;
	
	char name[VISA_NAME_LENGTH];
	
	ViUInt32 dataWriteR27; // Data written to I/O board 27V relay
	ViUInt32 dataWriteR5; // Data written to I/O board 5V relay
	ViUInt32 dataWriteOC; // Data written to I/O board OC
	ViUInt32 dataReadI27; // Data read from I/O board 27V isolation
	ViUInt32 dataReadI5; // Data read from I/O board 5V isolation

} IO_PARAM;


//==============================================================================
// External variables

		
		
//==============================================================================
// Global functions
int IO_Open (IO_PARAM *ioParam);
int IO_Close (IO_PARAM *ioParam);

int IO_TestRelay5V (IO_PARAM ioParam);
int IO_TestRelay27V (IO_PARAM ioParam);
int IO_TestOC (IO_PARAM ioParam);

int IO_TestIsolation5V (IO_PARAM *ioParam);
int IO_TestIsolation27V (IO_PARAM *ioParam);

int IO_WriteRAM (IO_PARAM ioParam, ViUInt32 dataWrite);
int IO_ReadRAM (IO_PARAM ioParam, ViUInt32 *dataWrite);

int IO_TurnOnLED (IO_PARAM ioParam);
int IO_TurnOffLED (IO_PARAM ioParam);

int IO_ElectroDiscrete(IO_PARAM *ioParam, ViUInt8 ioSwitch); // ��������

int IO_PhysicalDiscrete(IO_PARAM *ioParam, ViUInt8 ioSwitch); // ��������

int IO_BatteryVoltageNormal(IO_PARAM *ioParam, ViUInt8 ioSwitch); // ��ص�ѹ����

int IO_BatteryActivate(IO_PARAM *ioParam, ViUInt8 ioSwitch); // ��ؼ���

int IO_SecuritySystem(IO_PARAM *ioParam, ViUInt8 ioSwitch); // ����������һ����ָ���

 


int IO_K2(IO_PARAM *ioParam); // K2

int IO_MissilePrepare(IO_PARAM *ioParam); // ����׼��

int IO_GuiderHighPressure(IO_PARAM *ioParam); // ����ͷ�Ӹ�ѹ

int IO_FlightControlSelfTestNormal(IO_PARAM *ioParam); // �ɿؼ�����Լ�����




int IO_EnableIntPCI (IO_PARAM ioParam, ViHndlr intHandlerPCI); // Enable PCI interrupt, PCI interrupt callback function handler
int IO_DisableIntPCI (IO_PARAM ioParam, ViHndlr intHandlerPCI); // Disable PCI interrupt


#ifdef __cplusplus
    }
#endif

#endif  /* ndef __pxi_io_H__ */
