/**************************************************************************/
/* LabWindows/CVI User Interface Resource (UIR) Include File              */
/* Copyright (c) National Instruments 2013. All Rights Reserved.          */
/*                                                                        */
/* WARNING: Do not add to, delete from, or otherwise modify the contents  */
/*          of this include file.                                         */
/**************************************************************************/

#include <userint.h>

#ifdef __cplusplus
    extern "C" {
#endif

     /* Panels and Controls: */

#define  PANEL                            1
#define  PANEL_LED                        2       /* control type: LED, callback function: (none) */
#define  PANEL_QUIT                       3       /* control type: command, callback function: Quit */
#define  PANEL_MODEL_CODE                 4       /* control type: numeric, callback function: (none) */
#define  PANEL_MANF_ID                    5       /* control type: numeric, callback function: (none) */
#define  PANEL_TAB                        6       /* control type: tab, callback function: (none) */
#define  PANEL_IO_BOARD_NAME              7       /* control type: string, callback function: (none) */
#define  PANEL_INTERRUPT                  8       /* control type: LED, callback function: (none) */
#define  PANEL_TIMER                      9       /* control type: timer, callback function: Refresh */

     /* tab page panel controls */
#define  TAB_IN_NUMERIC_I27               2       /* control type: numeric, callback function: (none) */
#define  TAB_IN_NUMERIC_I5                3       /* control type: numeric, callback function: (none) */
#define  TAB_IN_READ_I27                  4       /* control type: command, callback function: ReadI27 */
#define  TAB_IN_READ_I5                   5       /* control type: command, callback function: ReadI5 */

     /* tab page panel controls */
#define  TAB_LED_TURN_ON_LED              2       /* control type: command, callback function: TurnOnLed */
#define  TAB_LED_TURN_OFF_LED             3       /* control type: command, callback function: TurnOffLed */

     /* tab page panel controls */
#define  TAB_OP_RELAY_27_PD               2       /* control type: binary, callback function: (none) */
#define  TAB_OP_ISOLATION_5_FC2FD_OUT     3       /* control type: binary, callback function: (none) */
#define  TAB_OP_RELAY_27_FC2FT            4       /* control type: binary, callback function: (none) */
#define  TAB_OP_RELAY_27_BVN              5       /* control type: binary, callback function: (none) */
#define  TAB_OP_RELAY_27_ED               6       /* control type: binary, callback function: (none) */
#define  TAB_OP_ISOLATION_5_MP            7       /* control type: LED, callback function: (none) */
#define  TAB_OP_ISOLATION_5_GHP           8       /* control type: LED, callback function: (none) */
#define  TAB_OP_ISOLATION_5_FCSTN         9       /* control type: LED, callback function: (none) */
#define  TAB_OP_ISOLATION_5_FC2FD_IN      10      /* control type: LED, callback function: (none) */
#define  TAB_OP_ISOLATION_5_K2            11      /* control type: LED, callback function: (none) */

     /* tab page panel controls */
#define  TAB_OUT_NUMERIC_O27              2       /* control type: numeric, callback function: (none) */
#define  TAB_OUT_NUMERIC_OC5              3       /* control type: numeric, callback function: (none) */
#define  TAB_OUT_NUMERIC_O5               4       /* control type: numeric, callback function: (none) */
#define  TAB_OUT_SEND_OC5                 5       /* control type: command, callback function: SendOC5 */
#define  TAB_OUT_SEND_O27                 6       /* control type: command, callback function: SendO27 */
#define  TAB_OUT_SEND_O5                  7       /* control type: command, callback function: SendO5 */

     /* tab page panel controls */
#define  TAB_RAM_NUMERIC_RAM_I_BEFORE     2       /* control type: numeric, callback function: (none) */
#define  TAB_RAM_NUMERIC_RAM_I_AFTER      3       /* control type: numeric, callback function: (none) */
#define  TAB_RAM_NUMERIC_RAM_O            4       /* control type: numeric, callback function: (none) */
#define  TAB_RAM_TEST_RAM                 5       /* control type: command, callback function: TestRam */


     /* Control Arrays: */

          /* (no control arrays in the resource file) */


     /* Menu Bars, Menus, and Menu Items: */

          /* (no menu bars in the resource file) */


     /* Callback Prototypes: */

int  CVICALLBACK Quit(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK ReadI27(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK ReadI5(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK Refresh(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK SendO27(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK SendO5(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK SendOC5(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK TestRam(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK TurnOffLed(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK TurnOnLed(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);


#ifdef __cplusplus
    }
#endif
