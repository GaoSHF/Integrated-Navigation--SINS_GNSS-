//==============================================================================
//
// Title:       pci_io_cvi.c
// Purpose:     A short description of the implementation.
//
// Created on:  2013-3-2 at 15:35:24 by Cindy.
// Copyright:   BUAA. All Rights Reserved.
//
//==============================================================================

//==============================================================================
// Include files
#include "pxi_io_cvi.h"
#include <userint.h>
#include <visa.h>
#include <ansi_c.h> //  For printf, malloc

#include "pxi_io.h"

//==============================================================================
// Constants, set for PCI board instead of pxi board
#define TAB_INDEX_DIGIT_OUT		0
#define TAB_INDEX_DIGIT_IN		1
#define TAB_INDEX_RAM			2
#define TAB_INDEX_LED			3
#define TAB_INDEX_OP			4

//==============================================================================
// Types

//==============================================================================
// Static global variables
static int panelHandle;
static int tabPanelHandle;

//==============================================================================
// Static functions
ViStatus _VI_FUNCH Interrupt(ViSession vi , ViEventType eventType ,ViEvent ctx ,ViAddr userHdlr);

//==============================================================================
// Global variables
ViUInt16 ManfIdSet = IO_DEFAULT_MANF_ID;
ViUInt16 ModelCodeSet = IO_DEFAULT_MODEL_CODE;

ViUInt32 dataWrite = 0x00001111;
ViUInt32 dataRead;

int flagFound = 0;
int flagCheckNum = 0;

int flagInterrupt = 0;

IO_PARAM ioParam;



ViPEventType outEventType;
ViPEvent outContext;
ViStatus status;


//==============================================================================
// Global functions
int Init(){
	// **************** Main panel ****************
	// Numeric data type
	SetCtrlAttribute(panelHandle, PANEL_MANF_ID, ATTR_FORMAT, VAL_HEX_FORMAT);
	SetCtrlAttribute(panelHandle, PANEL_MODEL_CODE, ATTR_FORMAT, VAL_HEX_FORMAT);
	
	// Numeric default data value
	SetCtrlAttribute(panelHandle, PANEL_MANF_ID, ATTR_DFLT_VALUE, 0x0000);
	SetCtrlAttribute(panelHandle, PANEL_MODEL_CODE, ATTR_DFLT_VALUE, 0x0000);
	
	
	// **************** Tab digit out ****************
	// Creat tab page handle
	GetPanelHandleFromTabPage(panelHandle, PANEL_TAB, TAB_INDEX_DIGIT_OUT, &tabPanelHandle);
	
	// Set numeric data type
	SetCtrlAttribute(tabPanelHandle, TAB_OUT_NUMERIC_O5, ATTR_DATA_TYPE, VAL_UNSIGNED_INTEGER);
	SetCtrlAttribute(tabPanelHandle, TAB_OUT_NUMERIC_O27, ATTR_DATA_TYPE, VAL_UNSIGNED_INTEGER);
	SetCtrlAttribute(tabPanelHandle, TAB_OUT_NUMERIC_OC5, ATTR_DATA_TYPE, VAL_UNSIGNED_INTEGER);
	
	// Set numeric maximum value
	SetCtrlAttribute(tabPanelHandle, TAB_OUT_NUMERIC_O5, ATTR_MAX_VALUE, 255);// 8 bits
	SetCtrlAttribute(tabPanelHandle, TAB_OUT_NUMERIC_O27, ATTR_MAX_VALUE, 255);
	SetCtrlAttribute(tabPanelHandle, TAB_OUT_NUMERIC_OC5, ATTR_MAX_VALUE, 255);
	
	// Set numeric display format
	SetCtrlAttribute(tabPanelHandle, TAB_OUT_NUMERIC_O5, ATTR_FORMAT, VAL_BINARY_FORMAT);
	SetCtrlAttribute(tabPanelHandle, TAB_OUT_NUMERIC_O27, ATTR_FORMAT, VAL_BINARY_FORMAT);
	SetCtrlAttribute(tabPanelHandle, TAB_OUT_NUMERIC_OC5, ATTR_FORMAT, VAL_BINARY_FORMAT);
	
	// Set numeric range check
	SetCtrlAttribute(tabPanelHandle, TAB_OUT_NUMERIC_O5, ATTR_CHECK_RANGE, VAL_COERCE);
	SetCtrlAttribute(tabPanelHandle, TAB_OUT_NUMERIC_O27, ATTR_CHECK_RANGE, VAL_COERCE);
	SetCtrlAttribute(tabPanelHandle, TAB_OUT_NUMERIC_OC5, ATTR_CHECK_RANGE, VAL_COERCE);
	
	
	// **************** Tab digit in ****************
	// Creat tab page handle
	GetPanelHandleFromTabPage(panelHandle, PANEL_TAB, TAB_INDEX_DIGIT_IN, &tabPanelHandle);
	
	// Set numeric data type
	SetCtrlAttribute(tabPanelHandle, TAB_IN_NUMERIC_I5, ATTR_DATA_TYPE, VAL_UNSIGNED_INTEGER);
	SetCtrlAttribute(tabPanelHandle, TAB_IN_NUMERIC_I27, ATTR_DATA_TYPE, VAL_UNSIGNED_INTEGER);
	
	// Set numeric maximum value
	SetCtrlAttribute(tabPanelHandle, TAB_IN_NUMERIC_I5, ATTR_MAX_VALUE, 65535);// 16 bits
	SetCtrlAttribute(tabPanelHandle, TAB_IN_NUMERIC_I27, ATTR_MAX_VALUE, 255);// 8 bits    
	
	// Set numeric display format
	SetCtrlAttribute(tabPanelHandle, TAB_IN_NUMERIC_I5, ATTR_FORMAT, VAL_BINARY_FORMAT);
	SetCtrlAttribute(tabPanelHandle, TAB_IN_NUMERIC_I27, ATTR_FORMAT, VAL_BINARY_FORMAT);
	
	// Set numeric range check
	SetCtrlAttribute(tabPanelHandle, TAB_IN_NUMERIC_I5, ATTR_CHECK_RANGE, VAL_COERCE);
	SetCtrlAttribute(tabPanelHandle, TAB_IN_NUMERIC_I27, ATTR_CHECK_RANGE, VAL_COERCE);
	
	
	// **************** Tab RAM ****************
	// Creat tab page handle
	GetPanelHandleFromTabPage(panelHandle, PANEL_TAB, TAB_INDEX_RAM, &tabPanelHandle);
	
	// Set numeric data type
	SetCtrlAttribute(tabPanelHandle, TAB_RAM_NUMERIC_RAM_I_BEFORE, ATTR_DATA_TYPE, VAL_UNSIGNED_INTEGER);
	SetCtrlAttribute(tabPanelHandle, TAB_RAM_NUMERIC_RAM_O, ATTR_DATA_TYPE, VAL_UNSIGNED_INTEGER);
	SetCtrlAttribute(tabPanelHandle, TAB_RAM_NUMERIC_RAM_I_AFTER, ATTR_DATA_TYPE, VAL_UNSIGNED_INTEGER);
	
	// Set numeric maximum value
	SetCtrlAttribute(tabPanelHandle, TAB_RAM_NUMERIC_RAM_I_BEFORE, ATTR_MAX_VALUE, 65535);
	SetCtrlAttribute(tabPanelHandle, TAB_RAM_NUMERIC_RAM_O, ATTR_MAX_VALUE, 65535);// 16 bits
	SetCtrlAttribute(tabPanelHandle, TAB_RAM_NUMERIC_RAM_I_AFTER, ATTR_MAX_VALUE, 65535);    
	
	// Set numeric display format
	SetCtrlAttribute(tabPanelHandle, TAB_RAM_NUMERIC_RAM_I_BEFORE, ATTR_FORMAT, VAL_BINARY_FORMAT);
	SetCtrlAttribute(tabPanelHandle, TAB_RAM_NUMERIC_RAM_O, ATTR_FORMAT, VAL_BINARY_FORMAT);
	SetCtrlAttribute(tabPanelHandle, TAB_RAM_NUMERIC_RAM_I_AFTER, ATTR_FORMAT, VAL_BINARY_FORMAT);
	
	// Set numeric range check
	SetCtrlAttribute(tabPanelHandle, TAB_RAM_NUMERIC_RAM_I_BEFORE, ATTR_CHECK_RANGE, VAL_COERCE);
	SetCtrlAttribute(tabPanelHandle, TAB_RAM_NUMERIC_RAM_O, ATTR_CHECK_RANGE, VAL_COERCE);
	SetCtrlAttribute(tabPanelHandle, TAB_RAM_NUMERIC_RAM_I_AFTER, ATTR_CHECK_RANGE, VAL_COERCE);
	
	return 0;
}


/* 
 * main entry
 */
int main(int argc, char *argv[])
{
	if (InitCVIRTE(0, argv, 0) == 0) // out of memory
		return -1;
	
	// Panel handle
	if ((panelHandle = LoadPanel(0, "pxi_io_cvi.uir", PANEL)) < 0)
		return -1;

	DisplayPanel(panelHandle);
	
	Init();
	
	// Open I/O board 
	flagFound = IO_Open(&ioParam);
	
	// Enable PXI IO board interrupt
	if(flagFound == IO_FOUND) {
		IO_EnableIntPCI(ioParam, Interrupt);
	}
	
	RunUserInterface();
	
	if(flagFound == IO_FOUND) { 
		IO_DisableIntPCI(ioParam, Interrupt);
	
		// Close I/O board
		IO_Close (&ioParam);
	}
	
	DiscardPanel(panelHandle);
	
	return 0;
}

// ********************************************************************** Interface callback
/* 
 * Refresh operation follow the timer with some board operation
 */
int CVICALLBACK Refresh(int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	switch(event){
	case  EVENT_TIMER_TICK:
	
		// Refresh IO board found LED and name display
		if(flagFound == IO_FOUND) {
			SetCtrlVal(panelHandle, PANEL_LED, 1);
			SetCtrlVal(panelHandle, PANEL_IO_BOARD_NAME, ioParam.name); // Display VISA name
			
			SetCtrlVal(panelHandle, PANEL_MANF_ID, IO_DEFAULT_MANF_ID);
			SetCtrlVal(panelHandle, PANEL_MODEL_CODE, IO_DEFAULT_MODEL_CODE);
		}
		else{
			SetCtrlVal(panelHandle, PANEL_LED, 0);
			SetCtrlVal(panelHandle, PANEL_IO_BOARD_NAME, "Not found"); // Display not found
		}
		
		
		// **************** Refresh Real operation tab for the project ****************
		// Creat tab page handle
		if(flagFound == IO_FOUND) {		  
			GetPanelHandleFromTabPage(panelHandle, PANEL_TAB, TAB_INDEX_OP, &tabPanelHandle);
			
			// **************** 27V Relay output ****************
			// ��������
			GetCtrlVal(tabPanelHandle, TAB_OP_RELAY_27_ED, &dataRead);
			if(dataRead == 1)
				IO_ElectroDiscrete(&ioParam, IO_RELAY_CONNECT); // Connect
			else if(dataRead == 0)
				IO_ElectroDiscrete(&ioParam, IO_RELAY_DISCRETE); // Discrete	
			else;
			
			// ��������
			GetCtrlVal(tabPanelHandle, TAB_OP_RELAY_27_PD, &dataRead);
			if(dataRead == 1)
				IO_PhysicalDiscrete(&ioParam, IO_RELAY_CONNECT); // Connect
			else if(dataRead == 0)
				IO_PhysicalDiscrete(&ioParam, IO_RELAY_DISCRETE); // Discrete	
			else;
			
			// **************** 5V Relay output ****************
			// ��ص�ѹ����
			GetCtrlVal(tabPanelHandle, TAB_OP_RELAY_27_BVN, &dataRead);
			if(dataRead == 1)
				IO_BatteryVoltageNormal(&ioParam, IO_RELAY_CONNECT); // Connect
			else if(dataRead == 0)
				IO_BatteryVoltageNormal(&ioParam, IO_RELAY_DISCRETE); // Discrete	
			else;
			
			// �ɿ��������ն��ź�
			GetCtrlVal(tabPanelHandle, TAB_OP_RELAY_27_FC2FT, &dataRead);
			if(dataRead == 1)
				IO_BatteryActivate(&ioParam, IO_RELAY_CONNECT); // Connect
			else if(dataRead == 0)
				IO_BatteryActivate(&ioParam, IO_RELAY_DISCRETE); // Discrete	
			else;
			
			// �ɿ������������źţ�һ����ָ���
			GetCtrlVal(tabPanelHandle, TAB_OP_ISOLATION_5_FC2FD_OUT, &dataRead);
			if(dataRead == 1)
				IO_SecuritySystem(&ioParam, IO_RELAY_CONNECT); // Connect
			else if(dataRead == 0)
				IO_SecuritySystem(&ioParam, IO_RELAY_DISCRETE); // Discrete	
			else;
			
			// **************** 5V isolation input **************** 
			// K2
			dataWrite = IO_K2(&ioParam);
			SetCtrlVal(tabPanelHandle, TAB_OP_ISOLATION_5_K2, dataWrite);
			
			// ����׼��
			dataWrite = IO_MissilePrepare(&ioParam);
			SetCtrlVal(tabPanelHandle, TAB_OP_ISOLATION_5_MP, dataWrite);
			
			// ����ͷ�Ӹ�ѹ
			dataWrite = IO_GuiderHighPressure(&ioParam);
			SetCtrlVal(tabPanelHandle, TAB_OP_ISOLATION_5_GHP, dataWrite);
			
			// �ɿ������������źţ���һ����ָ�    
			dataWrite = IO_FlightControlToFuseData_In (&ioParam);
			SetCtrlVal(tabPanelHandle, TAB_OP_ISOLATION_5_FC2FD_IN, dataWrite);
			
			// �ɿؼ�����Լ�����
			dataWrite = IO_FlightControlSelfTestNormal(&ioParam);
			SetCtrlVal(tabPanelHandle, TAB_OP_ISOLATION_5_FCSTN, dataWrite);
			
			
		} // if
		
		
		
		break;
	
	default: 
		break;
	}
	
	return 0;
}

/* 
 * Quit
 */
int CVICALLBACK Quit(int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	switch (event){
	case EVENT_COMMIT:
		QuitUserInterface (0);
		break;
		
	default:
		break;		
	}
	return 0;
}

// **************** Digital output ****************
/* 
 * Send 5V relay data
 */
int CVICALLBACK SendO5 (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	switch(event){
	case  EVENT_COMMIT:
		if(flagFound == IO_FOUND){
			// Creat tab page handle
			GetPanelHandleFromTabPage(panelHandle, PANEL_TAB, TAB_INDEX_DIGIT_OUT, &tabPanelHandle);
		
			// Get data to write
			GetCtrlVal(tabPanelHandle, TAB_OUT_NUMERIC_O5, &dataWrite);
	
			// Write data
			ioParam.dataWriteR5 = dataWrite;
			IO_TestRelay5V(ioParam);
		}
		
		break;
		
	default: 
		break;
	}
	
	return 0;
}

/* 
 * Send 27V relay data
 */
int CVICALLBACK SendO27 (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	switch(event){
	case  EVENT_COMMIT:
		if(flagFound == IO_FOUND){
			// Creat tab page handle
			GetPanelHandleFromTabPage(panelHandle, PANEL_TAB, TAB_INDEX_DIGIT_OUT, &tabPanelHandle);
		
			// Get data to write
			GetCtrlVal(tabPanelHandle, TAB_OUT_NUMERIC_O27, &dataWrite);
	
			// Write data
			ioParam.dataWriteR27 = dataWrite;
			IO_TestRelay27V(ioParam);
		}
		
		break;
		
	default: 
		break;
	}
	
	return 0;
}

/* 
 * Send 5V OC data
 */
int CVICALLBACK SendOC5 (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	switch(event){
	case  EVENT_COMMIT:
		if(flagFound == IO_FOUND){
			// Creat tab page handle
			GetPanelHandleFromTabPage(panelHandle, PANEL_TAB, TAB_INDEX_DIGIT_OUT, &tabPanelHandle);
		
			// Get data to write
			GetCtrlVal(tabPanelHandle, TAB_OUT_NUMERIC_OC5, &dataWrite);
	
			// Write data
			ioParam.dataWriteOC = dataWrite;
			IO_TestOC(ioParam);
		}
		
		break;
		
	default: 
		break;
	}
	
	return 0;
}

// **************** Digital input ****************
/* 
 * Read 5V isolation data
 */
int CVICALLBACK ReadI5 (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	switch(event){
	case  EVENT_COMMIT:
		if(flagFound == IO_FOUND){
			// Creat tab page handle
			GetPanelHandleFromTabPage(panelHandle, PANEL_TAB, TAB_INDEX_DIGIT_IN, &tabPanelHandle);
			
			// Read data
			IO_TestIsolation5V(&ioParam);
			dataRead = ioParam.dataReadI5;
		
			// Set data have been read
			SetCtrlVal(tabPanelHandle, TAB_IN_NUMERIC_I5, dataRead);
			
		}
		
		break;
		
	default: 
		break;
	}
	
	return 0;
}

/* 
 * Read 27V isolation data
 */
int CVICALLBACK ReadI27 (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	switch(event){
	case  EVENT_COMMIT:
		if(flagFound == IO_FOUND){
			// Creat tab page handle
			GetPanelHandleFromTabPage(panelHandle, PANEL_TAB, TAB_INDEX_DIGIT_IN, &tabPanelHandle);
			
			// Read data
			IO_TestIsolation27V(&ioParam);
			dataRead = ioParam.dataReadI27;
		
			// Set data have been read
			SetCtrlVal(tabPanelHandle, TAB_IN_NUMERIC_I27, dataRead);
		}
		
		break;
		
	default: 
		break;
	}
	
	return 0;
}

// **************** FPGA RAM ****************
/* 
 * Test FPGA 32 bits RAM
 */
int CVICALLBACK TestRam (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	switch(event){
	case  EVENT_COMMIT:
		if(flagFound == IO_FOUND){
			// Creat tab page handle
			GetPanelHandleFromTabPage(panelHandle, PANEL_TAB, TAB_INDEX_RAM, &tabPanelHandle);
			
			// Read RAM before
			IO_ReadRAM(ioParam, &dataRead);
			SetCtrlVal(tabPanelHandle, TAB_RAM_NUMERIC_RAM_I_BEFORE, dataRead);
			
			// Write RAM  
			GetCtrlVal(tabPanelHandle, TAB_RAM_NUMERIC_RAM_O, &dataWrite);
			IO_WriteRAM(ioParam, dataWrite);
			
			// Read RAM after
			IO_ReadRAM(ioParam, &dataRead); 
			SetCtrlVal(tabPanelHandle, TAB_RAM_NUMERIC_RAM_I_AFTER, dataRead);
		}
		
		break;
		
	default: 
		break;
	}
	
	return 0;
}

// **************** FPGA LED ****************
/* 
 * Turn on LED
 */
int CVICALLBACK TurnOnLed (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	switch(event){
	case  EVENT_COMMIT:
		if(flagFound == IO_FOUND){
			// Creat tab page handle
			GetPanelHandleFromTabPage(panelHandle, PANEL_TAB, TAB_INDEX_LED, &tabPanelHandle);
			
			IO_TurnOnLED(ioParam);
		}
		
		break;
		
	default: 
		break;
	}
	
	return 0;
}

/* 
 * Turn off LED
 */
int CVICALLBACK TurnOffLed (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	switch(event){
	case  EVENT_COMMIT:
		if(flagFound == IO_FOUND){
			// Creat tab page handle
			GetPanelHandleFromTabPage(panelHandle, PANEL_TAB, TAB_INDEX_LED, &tabPanelHandle);
			
			IO_TurnOffLED(ioParam);
		}
		
		break;
		
	default: 
		break;
	}
	
	return 0;
}




// ********************************************************************** Handler
/* 
 * Interrupt handler
 * 			 mode 1: Turning on and off LED are used as interrupt enable and disable on FPGA board
 * 			 mode 2: Turning on LED is used as interrupt enable, and the interrupt is automatically cleared by VISA
 */
ViStatus _VI_FUNCH Interrupt(ViSession vi , ViEventType eventType ,ViEvent ctx ,ViAddr userHdlr)
{
	flagInterrupt = ~flagInterrupt;
	
	SetCtrlVal(panelHandle, PANEL_INTERRUPT, flagInterrupt);
	
	return VI_SUCCESS;
}


