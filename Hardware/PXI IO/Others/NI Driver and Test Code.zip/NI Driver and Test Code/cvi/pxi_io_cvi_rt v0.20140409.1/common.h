#ifndef _COMMON_H_
#define _COMMON_H_


#define TCP_INVALID_CONNECTION 	((unsigned int)-1) 

#define HOST_ADDRESS 			"169.254.121.1"
#define HOST_PORT 				10001


#define START_COMMAND			1
#define STOP_COMMAND			2
#define QUIT_COMMAND			3

#define SELFTEST_COMMAND        4

#define GPSRECEIVE_COMMAND      5  
#define INSRECEIVE_COMMAND      6

#define GPSSIM_COMMAND          7
#define GPSSIM_AGC_COMMAND      8
#define	GPSSIM_IO_CHANGE_COMMAND	9




#define	IO_COMMAND	100

#define	IO_COMMAND_FOUND	111

#define	IO_COMMAND_INT	119 

#define	SUBCMD_IO_NAME	110
#define	SUBCMD_IO_MANF_ID	112 
#define	SUBCMD_IO_MODEL_CODE	113 

#define	SUBCMD_IO_READ_ISO5	101
#define	SUBCMD_IO_READ_ISO27	102
#define	SUBCMD_IO_WRITE_REL5	103
#define	SUBCMD_IO_WRITE_REL27	104
#define	SUBCMD_IO_WRITE_OC	105

#define	SUBCMD_IO_WRITE_LED	12

#define	SUBCMD_IO_READ_RAM	13
#define	SUBCMD_IO_WRITE_RAM	14

#define	SUBCMD_IO_WRITE_ELECTRO_DISCRETE	15
#define	SUBCMD_IO_WRITE_PHYSICAL_DISCRETE	16

#define	SUBCMD_IO_WRITE_BATTERY_VOLTAGE_NORMAL	17
#define	SUBCMD_IO_WRITE_BATTERY_ACTIVATE	18
#define	SUBCMD_IO_WRITE_SECURITY_SYSTEM	19

#define	SUBCMD_IO_READ_K2	20
#define	SUBCMD_IO_READ_MISSILE_PREPARE	21
#define	SUBCMD_IO_READ_GUIDER_HIGH_PRESSURE	22
#define	SUBCMD_IO_READ_FLIGHT_CONTROL_SELF_TEST_NORMAL	24



#define	STATUS_ON	1
#define	STATUS_OFF	0


// Command message structure
typedef struct
{
	int countertime;
	
	int statusYCReceive;
	
	int statusINSReceive;
	
	int statusGPSReceive;
	
	int statusSimulator;
	
	int value;
	
	char name[30];
	
	int subcmd;
	
	int	command;
} CommandMessage;






#endif

