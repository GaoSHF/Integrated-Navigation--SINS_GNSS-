#include <stdio.h>
#include <string.h>

#include "pxi_io.h"

/* 
 * Interrupt handler
 * 			 mode 1: Turning on and off LED are used as interrupt enable and disable on FPGA board
 * 			 mode 2: Turning on LED is used as interrupt enable, and the interrupt is automatically cleared by VISA
 */
ViStatus _VI_FUNCH Interrupt(ViSession vi , ViEventType eventType ,ViEvent ctx ,ViAddr userHdlr)
{
	printf("\n\n********************* Interrupt ************************\n\n");
	
	return VI_SUCCESS;
}

/* 
 * Main entry
 */
int main()
{
	IO_PARAM ioParam;

	char temp[10];
	char flag_found;

	ViUInt32 dataWrite;
	ViUInt32 dataRead;

	ViUInt8 ioSwitch_1 = IO_RELAY_DISCRETE, ioSwitch_2 = IO_RELAY_DISCRETE, ioSwitch_3 = IO_RELAY_DISCRETE, ioSwitch_4 = IO_RELAY_DISCRETE, ioSwitch_5 = IO_RELAY_DISCRETE;


	// Open PXI I/O board
	if((flag_found = IO_Open(&ioParam)) == IO_NOT_FOUND){
		printf("PXI I/O board is not found, press any key to quit.\n");
		getchar();
		return 0;
	}

	IO_EnableIntPCI (ioParam, Interrupt); // Enable PCI interrupt



	printf("Enter any command to test PXI I/O board\n");

	printf("-- r27 1: Electro Discrete\n");
	printf("-- r27 2: Physical Discrete\n");

	printf("-- r5 1: Battery Voltage Normal\n");
	printf("-- r5 2: Flight Control To Fuse Terminal\n");
	printf("-- r5 3: Flight Control To Fuse Data (Out)\n");

	printf("-- i5 1: K2\n");
	printf("-- i5 2: Missile Prepare\n");
	printf("-- i5 3: Guider High Pressure\n");
	printf("-- i5 4: Flight Control To Fuse Data (In)\n");
	printf("-- i5 5: Flight Control Self Test Normal\n");

	printf("-- on: Turn on LED (Enable interrupt)\n");
	printf("-- off: Turn off LED (Disable interrupt)\n");

	printf("-- quit: Quit\n\n");

	while(1) {
		scanf("%s", temp);

		// Relay 27V
		if(!strcmp(temp, "r27 1")) {
			ioSwitch_1 = (ioSwitch_1 == IO_RELAY_DISCRETE) ? IO_RELAY_CONNECT : IO_RELAY_DISCRETE;
			IO_ElectroDiscrete(&ioParam, ioSwitch_1);
			printf("High or low?  %x\n", ioSwitch_1);
		}
		else if(!strcmp(temp, "r27 2")) {
			ioSwitch_2 = (ioSwitch_2 == IO_RELAY_DISCRETE) ? IO_RELAY_CONNECT : IO_RELAY_DISCRETE;
			IO_PhysicalDiscrete(&ioParam, ioSwitch_2);
			printf("High or low?  %x\n", ioSwitch_2);
		}

		// Relay 5V
		else if(!strcmp(temp, "r5 1")) {
			ioSwitch_3 = (ioSwitch_3 == IO_RELAY_DISCRETE) ? IO_RELAY_CONNECT : IO_RELAY_DISCRETE;
			IO_BatteryVoltageNormal(&ioParam, ioSwitch_3);
			printf("High or low?  %x\n", ioSwitch_3);
		}
		else if(!strcmp(temp, "r5 2")) {
			ioSwitch_4 = (ioSwitch_4 == IO_RELAY_DISCRETE) ? IO_RELAY_CONNECT : IO_RELAY_DISCRETE;
			IO_FlightControlToFuseTerminal(&ioParam, ioSwitch_4);
			printf("High or low?  %x\n", ioSwitch_4);
		}
		else if(!strcmp(temp, "r5 3")) {
			ioSwitch_5 = (ioSwitch_5 == IO_RELAY_DISCRETE) ? IO_RELAY_CONNECT : IO_RELAY_DISCRETE;
			IO_FlightControlToFuseData_Out(&ioParam, ioSwitch_5);
			printf("High or low?  %x\n", ioSwitch_5);
		}

		// Isolation 5V
		else if(!strcmp(temp, "i5 1")) {
			printf("High or low?  %x\n", IO_K2(&ioParam));
		}
		else if(!strcmp(temp, "i5 1")) {
			printf("High or low?  %x\n", IO_MissilePrepare(&ioParam));
		}
		else if(!strcmp(temp, "i5 1")) {
			printf("High or low?  %x\n", IO_GuiderHighPressure(&ioParam));
		}
		else if(!strcmp(temp, "i5 1")) {
			printf("High or low?  %x\n", IO_FlightControlToFuseData_In(&ioParam));
		}
		else if(!strcmp(temp, "i5 1")) {
			printf("High or low?  %x\n", IO_FlightControlSelfTestNormal(&ioParam));
		}
				

		// Turn on/off LED, enable/disable interrupt on FPGA PCI board
		// Interrupt will be cleared in mode 1, so disable operation is not necessery
		else if(!strcmp(temp, "on"))
			IO_TurnOnLED(ioParam);
		else if(!strcmp(temp, "off"))
			IO_TurnOffLED(ioParam);


		// Quit
		else if(!strcmp(temp, "quit"))
			break;
		else
			printf("Command error!\n");

	} // while

	IO_DisableIntPCI (ioParam, Interrupt); // Disable PCI interrupt


	// Close PXI I/O board
	IO_Close(&ioParam);

	return 0;
}