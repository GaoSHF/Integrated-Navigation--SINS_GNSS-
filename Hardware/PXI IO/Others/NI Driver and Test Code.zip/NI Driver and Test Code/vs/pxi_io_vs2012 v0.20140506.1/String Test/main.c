#include <stdio.h>
#include <string.h>

int main() {

	char temp[10];

	while(1) {
		
		scanf("%s", temp);
		
		if(!strcmp(temp, "test"))
			printf("Input got!\n");
		else if(!strcmp(temp, "quit"))
			break;
		else;

	}

	printf("Press any key to exit.\n");
	getchar();
	getchar();

	return 1;
}